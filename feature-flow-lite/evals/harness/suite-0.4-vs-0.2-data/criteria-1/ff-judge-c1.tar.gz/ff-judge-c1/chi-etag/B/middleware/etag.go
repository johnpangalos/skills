package middleware

import (
	"bufio"
	"bytes"
	"crypto/sha256"
	"encoding/hex"
	"errors"
	"net"
	"net/http"
	"net/textproto"
	"strings"
)

// ETag is a middleware that adds a strong entity tag to GET and HEAD responses
// and answers conditional requests with 304 Not Modified.
//
// For a GET or HEAD request whose final status is 200, if the handler did not
// set an ETag header, the response gets ETag: "<hex SHA-256 of the body>". A
// handler-set ETag, strong or weak, is left unchanged. For HEAD the tag is
// computed from any body bytes the handler wrote, and no tag is added when the
// handler set a non-zero Content-Length without writing a body.
//
// If the request has an If-None-Match header that weakly matches the response
// ETag (or is "*"), the response becomes 304 Not Modified with no body. The 304
// keeps the ETag and the other headers, and drops Content-Type, Content-Length,
// Content-Encoding and Last-Modified, as net/http does.
//
// ETag buffers the whole response body in memory until the handler returns, so
// it should not wrap large responses. Streaming handlers such as SSE should not
// sit behind it: Flush does not reach the client while buffering. Once the
// handler writes a non-200 status, the response is passed through unbuffered.
//
// When combined with Compress, register ETag first (r.Use(middleware.ETag)
// before r.Use(middleware.Compress(...))) so the tag is computed over the
// encoded bytes actually sent.
//
// Other methods are passed through without buffering.
func ETag(next http.Handler) http.Handler {
	fn := func(w http.ResponseWriter, r *http.Request) {
		if r.Method != http.MethodGet && r.Method != http.MethodHead {
			next.ServeHTTP(w, r)
			return
		}

		ew := &etagResponseWriter{
			ResponseWriter: w,
			head:           r.Method == http.MethodHead,
			ifNoneMatch:    r.Header.Values("If-None-Match"),
		}
		next.ServeHTTP(ew, r)
		ew.finish()
	}

	return http.HandlerFunc(fn)
}

type etagResponseWriter struct {
	http.ResponseWriter

	head        bool
	ifNoneMatch []string
	buf         bytes.Buffer
	wroteHeader bool
	passthrough bool
	hijacked    bool
}

func (w *etagResponseWriter) WriteHeader(code int) {
	// 1xx informational responses (except 101) are not the final status.
	if code >= 100 && code <= 199 && code != http.StatusSwitchingProtocols {
		w.ResponseWriter.WriteHeader(code)
		return
	}
	if w.wroteHeader {
		return
	}
	w.wroteHeader = true
	if code != http.StatusOK {
		w.passthrough = true
		w.ResponseWriter.WriteHeader(code)
	}
}

func (w *etagResponseWriter) Write(p []byte) (int, error) {
	if !w.wroteHeader {
		w.WriteHeader(http.StatusOK)
	}
	if w.passthrough {
		return w.ResponseWriter.Write(p)
	}
	return w.buf.Write(p)
}

func (w *etagResponseWriter) Flush() {
	// While buffering, the tag and 304 rules apply once the handler returns.
	if !w.passthrough {
		return
	}
	if f, ok := w.ResponseWriter.(http.Flusher); ok {
		f.Flush()
	}
}

func (w *etagResponseWriter) Hijack() (net.Conn, *bufio.ReadWriter, error) {
	if hj, ok := w.ResponseWriter.(http.Hijacker); ok {
		conn, rw, err := hj.Hijack()
		if err == nil {
			w.hijacked = true
		}
		return conn, rw, err
	}
	return nil, nil, errors.New("chi/middleware: http.Hijacker is unavailable on the writer")
}

func (w *etagResponseWriter) Push(target string, opts *http.PushOptions) error {
	if ps, ok := w.ResponseWriter.(http.Pusher); ok {
		return ps.Push(target, opts)
	}
	return errors.New("chi/middleware: http.Pusher is unavailable on the writer")
}

func (w *etagResponseWriter) Unwrap() http.ResponseWriter {
	return w.ResponseWriter
}

// finish sends the buffered response. It runs only after the handler returns
// normally, so a panicking handler writes nothing.
func (w *etagResponseWriter) finish() {
	// A hijacked connection belongs to the handler; nothing may be written to it.
	if w.passthrough || w.hijacked {
		return
	}
	if !w.wroteHeader {
		w.WriteHeader(http.StatusOK)
	}
	if w.Header().Get("ETag") == "" && w.bodyComplete() {
		w.Header().Set("ETag", etagOf(w.buf.Bytes()))
	}
	if w.notModified() {
		writeETagNotModified(w.ResponseWriter)
		return
	}
	w.ResponseWriter.WriteHeader(http.StatusOK)
	if !w.head {
		w.ResponseWriter.Write(w.buf.Bytes())
	}
}

// bodyComplete reports whether the buffered bytes are the whole body. A HEAD
// handler may set a Content-Length and write nothing; hashing the empty buffer
// would then give a wrong tag.
func (w *etagResponseWriter) bodyComplete() bool {
	if !w.head || w.buf.Len() > 0 {
		return true
	}
	cl := w.Header().Get("Content-Length")
	return cl == "" || cl == "0"
}

func (w *etagResponseWriter) notModified() bool {
	etag := w.Header().Get("ETag")
	return etag != "" && etagIfNoneMatch(w.ifNoneMatch, etag)
}

// etagOf returns a strong entity tag for body: the quoted hex SHA-256 digest.
func etagOf(body []byte) string {
	sum := sha256.Sum256(body)
	return `"` + hex.EncodeToString(sum[:]) + `"`
}

// writeETagNotModified sends 304 Not Modified without a body. It drops the
// representation headers, as net/http's writeNotModified does.
func writeETagNotModified(w http.ResponseWriter) {
	h := w.Header()
	h.Del("Content-Type")
	h.Del("Content-Length")
	h.Del("Content-Encoding")
	h.Del("Last-Modified")
	w.WriteHeader(http.StatusNotModified)
}

// etagIfNoneMatch reports whether any entity-tag in the If-None-Match header
// values weakly matches etag, or whether one of the members is "*". It is a
// port of net/http's checkIfNoneMatch. A malformed member ends the parsing of
// its header line.
func etagIfNoneMatch(values []string, etag string) bool {
	for _, v := range values {
		for {
			v = textproto.TrimString(v)
			if len(v) == 0 {
				break
			}
			if v[0] == ',' {
				v = v[1:]
				continue
			}
			if v[0] == '*' {
				return true
			}
			tag, remain := scanETagValue(v)
			if tag == "" {
				break
			}
			if etagWeakEqual(tag, etag) {
				return true
			}
			v = remain
		}
	}
	return false
}

// scanETagValue returns the entity-tag at the start of s and the text after it,
// or "", "" if s does not start with a valid entity-tag. It is a port of
// net/http's scanETag.
func scanETagValue(s string) (etag string, remain string) {
	s = textproto.TrimString(s)
	start := 0
	if strings.HasPrefix(s, "W/") {
		start = 2
	}
	if len(s[start:]) < 2 || s[start] != '"' {
		return "", ""
	}
	// ETag is either W/"text" or "text".
	for i := start + 1; i < len(s); i++ {
		c := s[i]
		switch {
		// Character values allowed in ETags.
		case c == 0x21 || c >= 0x23 && c <= 0x7E || c >= 0x80:
		case c == '"':
			return s[:i+1], s[i+1:]
		default:
			return "", ""
		}
	}
	return "", ""
}

// etagWeakEqual reports whether a and b match under weak comparison: the W/
// prefix is ignored and the quoted opaque-tags must be byte-for-byte equal.
func etagWeakEqual(a, b string) bool {
	return strings.TrimPrefix(a, "W/") == strings.TrimPrefix(b, "W/")
}

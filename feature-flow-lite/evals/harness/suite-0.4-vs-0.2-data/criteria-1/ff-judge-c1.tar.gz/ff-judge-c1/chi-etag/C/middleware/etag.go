package middleware

import (
	"bufio"
	"bytes"
	"crypto/sha256"
	"encoding/hex"
	"errors"
	"net"
	"net/http"
	"strings"
)

// ETag computes a strong ETag for GET and HEAD responses and answers
// conditional requests with 304 Not Modified.
//
// For GET and HEAD requests, ETag buffers the whole response in memory. If the
// handler finishes with status 200 and has not set an ETag header, ETag sets a
// strong one derived from the SHA-256 of the bytes the handler wrote. An ETag
// set by the handler, strong or weak, is kept as is. When If-None-Match matches
// the ETag (weak comparison, RFC 9110 section 13.1.2), the response becomes
// 304 Not Modified with no body. Other methods, non-200 statuses and panicking
// handlers are passed through unchanged.
//
// Register ETag before any middleware that transforms the body, such as
// Compress, so the strong tag describes the bytes actually sent.
//
// Calling Flush ends buffering: the status, headers and body written so far are
// sent immediately, no ETag is computed, If-None-Match is not evaluated, and
// later writes are streamed.
func ETag(next http.Handler) http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		if r.Method != http.MethodGet && r.Method != http.MethodHead {
			next.ServeHTTP(w, r)
			return
		}
		ew := &etagResponseWriter{
			ResponseWriter: w,
			ifNoneMatch:    r.Header.Values("If-None-Match"),
		}
		next.ServeHTTP(ew, r)
		ew.finish()
	})
}

type etagResponseWriter struct {
	http.ResponseWriter

	ifNoneMatch []string
	buf         bytes.Buffer
	// The final status code, or 0 until WriteHeader or Write is called.
	status int
	// Set once buffering has ended; writes then go straight to ResponseWriter.
	streaming bool
}

func (ew *etagResponseWriter) WriteHeader(code int) {
	// Informational responses other than 101 are sent immediately and do not
	// count as the final status.
	if code >= 100 && code <= 199 && code != http.StatusSwitchingProtocols {
		ew.ResponseWriter.WriteHeader(code)
		return
	}
	if ew.status != 0 {
		return
	}
	ew.status = code
	if code != http.StatusOK {
		ew.stream()
	}
}

func (ew *etagResponseWriter) Write(p []byte) (int, error) {
	if ew.status == 0 {
		ew.WriteHeader(http.StatusOK)
	}
	if ew.streaming {
		return ew.ResponseWriter.Write(p)
	}
	return ew.buf.Write(p)
}

// stream ends buffering and sends the status, headers and buffered body.
func (ew *etagResponseWriter) stream() {
	if ew.streaming {
		return
	}
	ew.streaming = true
	if ew.status == 0 {
		ew.status = http.StatusOK
	}
	ew.ResponseWriter.WriteHeader(ew.status)
	if ew.buf.Len() > 0 {
		ew.ResponseWriter.Write(ew.buf.Bytes())
	}
}

// finish sends the buffered response after the handler returns, unless it was
// already streamed.
func (ew *etagResponseWriter) finish() {
	if ew.streaming {
		return
	}
	h := ew.Header()
	if h.Get("ETag") == "" {
		sum := sha256.Sum256(ew.buf.Bytes())
		h.Set("ETag", `"`+hex.EncodeToString(sum[:])+`"`)
	}
	if etagMatches(ew.ifNoneMatch, h.Get("ETag")) {
		notModified(h)
		ew.ResponseWriter.WriteHeader(http.StatusNotModified)
		return
	}
	ew.ResponseWriter.WriteHeader(http.StatusOK)
	ew.ResponseWriter.Write(ew.buf.Bytes())
}

func (ew *etagResponseWriter) Flush() {
	ew.stream()
	if f, ok := ew.ResponseWriter.(http.Flusher); ok {
		f.Flush()
	}
}

func (ew *etagResponseWriter) Hijack() (net.Conn, *bufio.ReadWriter, error) {
	hj, ok := ew.ResponseWriter.(http.Hijacker)
	if !ok {
		return nil, nil, errors.New("chi/middleware: http.Hijacker is unavailable on the writer")
	}
	conn, rw, err := hj.Hijack()
	if err == nil {
		// The connection now belongs to the handler, so nothing more is sent.
		ew.streaming = true
	}
	return conn, rw, err
}

func (ew *etagResponseWriter) Push(target string, opts *http.PushOptions) error {
	if ps, ok := ew.ResponseWriter.(http.Pusher); ok {
		return ps.Push(target, opts)
	}
	return errors.New("chi/middleware: http.Pusher is unavailable on the writer")
}

func (ew *etagResponseWriter) Unwrap() http.ResponseWriter {
	return ew.ResponseWriter
}

// notModified removes the representation headers from a 304 response, the same
// way net/http's writeNotModified does.
func notModified(h http.Header) {
	h.Del("Content-Type")
	h.Del("Content-Length")
	h.Del("Content-Encoding")
	h.Del("Last-Modified")
}

// etagMatches reports whether any If-None-Match line matches etag using the
// weak comparison of RFC 9110 section 13.1.2. A value of "*" matches any ETag.
func etagMatches(lines []string, etag string) bool {
	want := strings.TrimPrefix(etag, "W/")
	for _, line := range lines {
		if strings.Trim(line, " \t") == "*" {
			return true
		}
		for _, member := range splitETagList(line) {
			if tag, ok := parseETag(member); ok && tag == want {
				return true
			}
		}
	}
	return false
}

// splitETagList splits an If-None-Match value at the commas that are outside
// quoted strings, since a comma is legal inside an opaque-tag.
func splitETagList(s string) []string {
	var members []string
	start, inQuotes := 0, false
	for i := 0; i < len(s); i++ {
		switch s[i] {
		case '"':
			inQuotes = !inQuotes
		case ',':
			if !inQuotes {
				members = append(members, s[start:i])
				start = i + 1
			}
		}
	}
	return append(members, s[start:])
}

// parseETag returns the opaque-tag of an entity-tag member, with any W/ prefix
// removed. It reports false for anything that is not a valid entity-tag.
func parseETag(member string) (string, bool) {
	tag := strings.TrimPrefix(strings.Trim(member, " \t"), "W/")
	if len(tag) < 2 || tag[0] != '"' || tag[len(tag)-1] != '"' {
		return "", false
	}
	for i := 1; i < len(tag)-1; i++ {
		// etagc excludes CTLs, space, DQUOTE and DEL.
		if c := tag[i]; c == '"' || c <= ' ' || c == 0x7f {
			return "", false
		}
	}
	return tag, true
}

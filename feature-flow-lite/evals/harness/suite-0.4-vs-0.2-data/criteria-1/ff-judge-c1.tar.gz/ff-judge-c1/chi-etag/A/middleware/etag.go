package middleware

import (
	"bufio"
	"bytes"
	"crypto/sha256"
	"encoding/hex"
	"errors"
	"net"
	"net/http"
	"net/textproto"
	"strconv"
	"strings"
)

// ETag sets an ETag on GET and HEAD responses and answers 304 Not Modified
// when the request's If-None-Match matches it.
//
// Only a 200 response is considered. When the handler did not set an ETag header,
// the ETag is a strong SHA-256 hash of the body. A handler-set ETag, strong or
// weak, is never changed and is used for If-None-Match matching.
// Responses with any other status, and requests with any other method, pass
// through unchanged. HEAD responses never carry a body.
//
// The whole GET/HEAD response is buffered in memory until the handler returns,
// so ETag is not suitable for streaming responses.
func ETag(next http.Handler) http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		if r.Method != http.MethodGet && r.Method != http.MethodHead {
			next.ServeHTTP(w, r)
			return
		}
		ew := &etagResponseWriter{ResponseWriter: w}
		next.ServeHTTP(ew, r)
		ew.finish(r)
	})
}

type etagResponseWriter struct {
	http.ResponseWriter
	body     bytes.Buffer
	status   int
	hijacked bool
}

func (w *etagResponseWriter) WriteHeader(code int) {
	// 1xx informational responses (other than 101) are forwarded immediately
	// and do not count as the final status.
	if w.hijacked || (code >= 100 && code <= 199 && code != http.StatusSwitchingProtocols) {
		w.ResponseWriter.WriteHeader(code)
		return
	}
	if w.status == 0 {
		w.status = code
	}
}

func (w *etagResponseWriter) Write(p []byte) (int, error) {
	if w.hijacked {
		return w.ResponseWriter.Write(p)
	}
	if w.status == 0 {
		w.WriteHeader(http.StatusOK)
	}
	return w.body.Write(p)
}

// Flush is a no-op, the response stays buffered until the handler returns.
func (w *etagResponseWriter) Flush() {}

func (w *etagResponseWriter) Hijack() (net.Conn, *bufio.ReadWriter, error) {
	if hj, ok := w.ResponseWriter.(http.Hijacker); ok {
		if w.status != 0 {
			// net/http's Hijack flushes a status line the handler already wrote, so
			// replay the status and buffered body before hijacking. The response is
			// no longer buffered from here on, so finish must not write it again.
			w.hijacked = true
			w.ResponseWriter.WriteHeader(w.status)
			w.ResponseWriter.Write(w.body.Bytes())
			w.body.Reset()
		}
		conn, rw, err := hj.Hijack()
		if err == nil {
			w.hijacked = true
		}
		return conn, rw, err
	}
	return nil, nil, errors.New("chi/middleware: http.Hijacker is unavailable on the writer")
}

func (w *etagResponseWriter) Push(target string, opts *http.PushOptions) error {
	if ps, ok := w.ResponseWriter.(http.Pusher); ok {
		return ps.Push(target, opts)
	}
	return errors.New("chi/middleware: http.Pusher is unavailable on the writer")
}

func (w *etagResponseWriter) Unwrap() http.ResponseWriter {
	return w.ResponseWriter
}

// finish writes the buffered response to the underlying writer.
func (w *etagResponseWriter) finish(r *http.Request) {
	if w.hijacked {
		return
	}
	if w.status == 0 {
		w.status = http.StatusOK
	}
	if w.status == http.StatusOK {
		h := w.Header()
		if len(h.Values("ETag")) == 0 && !headWithoutBody(r, w.body.Len(), h) {
			h.Set("ETag", etagOf(w.body.Bytes()))
		}
		if etag := h.Get("ETag"); etag != "" && ifNoneMatch(r.Header, etag) {
			stripNotModifiedHeaders(h)
			w.ResponseWriter.WriteHeader(http.StatusNotModified)
			return
		}
	}
	w.ResponseWriter.WriteHeader(w.status)
	if r.Method == http.MethodGet && w.body.Len() > 0 {
		w.ResponseWriter.Write(w.body.Bytes())
	}
}

// etagOf returns a strong quoted ETag for body.
func etagOf(body []byte) string {
	sum := sha256.Sum256(body)
	return `"` + hex.EncodeToString(sum[:]) + `"`
}

// headWithoutBody reports whether a HEAD response wrote no body but declared a
// non-zero Content-Length, in which case the hash of an empty body would not
// describe the representation.
func headWithoutBody(r *http.Request, bodyLen int, h http.Header) bool {
	if r.Method != http.MethodHead || bodyLen > 0 {
		return false
	}
	n, err := strconv.ParseInt(h.Get("Content-Length"), 10, 64)
	return err == nil && n != 0
}

// ifNoneMatch reports whether If-None-Match matches etag using the weak
// comparison of RFC 9110 section 13.1.2. Parsing stops at the first malformed
// member, and a malformed member never matches.
func ifNoneMatch(h http.Header, etag string) bool {
	list := strings.Join(h.Values("If-None-Match"), ",")
	if textproto.TrimString(list) == "*" {
		return true
	}
	for {
		list = textproto.TrimString(list)
		if list == "" {
			return false
		}
		if list[0] == ',' {
			list = list[1:]
			continue
		}
		member, rest, ok := scanETag(list)
		if !ok {
			return false
		}
		list = textproto.TrimString(rest)
		if list != "" && list[0] != ',' {
			return false
		}
		if weakETagEqual(member, etag) {
			return true
		}
	}
}

// scanETag splits a leading entity-tag (W/"x" or "x") off s and returns the
// remainder of s after it.
func scanETag(s string) (tag, rest string, ok bool) {
	start := 0
	if strings.HasPrefix(s, "W/") {
		start = 2
	}
	if len(s) < start+2 || s[start] != '"' {
		return "", "", false
	}
	for i := start + 1; i < len(s); i++ {
		c := s[i]
		switch {
		case c == '"':
			return s[:i+1], s[i+1:], true
		case c == 0x21 || (c >= 0x23 && c <= 0x7E) || c >= 0x80:
		default:
			return "", "", false
		}
	}
	return "", "", false
}

func weakETagEqual(a, b string) bool {
	return strings.TrimPrefix(a, "W/") == strings.TrimPrefix(b, "W/")
}

// stripNotModifiedHeaders removes representation headers from a 304 response,
// as net/http's writeNotModified does.
func stripNotModifiedHeaders(h http.Header) {
	h.Del("Content-Type")
	h.Del("Content-Length")
	h.Del("Content-Encoding")
	h.Del("Last-Modified")
}

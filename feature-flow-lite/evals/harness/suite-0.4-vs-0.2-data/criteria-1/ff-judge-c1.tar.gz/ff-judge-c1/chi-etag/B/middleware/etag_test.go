package middleware

import (
	"bytes"
	"crypto/sha256"
	"encoding/hex"
	"io"
	"log"
	"net"
	"net/http"
	"net/http/httptest"
	"strings"
	"testing"

	"github.com/go-chi/chi/v5"
)

// etagTag returns the strong entity tag ETag should produce for body.
func etagTag(body string) string {
	sum := sha256.Sum256([]byte(body))
	return `"` + hex.EncodeToString(sum[:]) + `"`
}

// etagServe runs ETag around h for one request and returns the recorded response.
// Each inm value is sent as its own If-None-Match header line.
func etagServe(method string, h http.HandlerFunc, inm ...string) *httptest.ResponseRecorder {
	req := httptest.NewRequest(method, "/", http.NoBody)
	for _, v := range inm {
		req.Header.Add("If-None-Match", v)
	}
	rec := httptest.NewRecorder()
	ETag(h).ServeHTTP(rec, req)
	return rec
}

func etagBody(body string) http.HandlerFunc {
	return func(w http.ResponseWriter, r *http.Request) {
		w.Write([]byte(body))
	}
}

// etagGet sends a request to the test server with the given If-None-Match lines.
func etagGet(t *testing.T, ts *httptest.Server, method string, inm ...string) (*http.Response, string) {
	t.Helper()
	req, err := http.NewRequest(method, ts.URL+"/", http.NoBody)
	assertNoError(t, err)
	for _, v := range inm {
		req.Header.Add("If-None-Match", v)
	}
	resp, err := ts.Client().Do(req)
	assertNoError(t, err)
	defer resp.Body.Close()
	body, err := io.ReadAll(resp.Body)
	assertNoError(t, err)
	return resp, string(body)
}

// informationalRecorder records the 1xx responses that reach the client.
type informationalRecorder struct {
	*httptest.ResponseRecorder
	informational []int
}

func (r *informationalRecorder) WriteHeader(code int) {
	if code >= 100 && code <= 199 && code != http.StatusSwitchingProtocols {
		r.informational = append(r.informational, code)
		return
	}
	r.ResponseRecorder.WriteHeader(code)
}

func TestETagGeneratesTag(t *testing.T) {
	tests := []struct {
		name    string
		handler http.HandlerFunc
		body    string
	}{
		{"single write", etagBody("hello"), "hello"},
		{"empty body", func(w http.ResponseWriter, r *http.Request) {}, ""},
		{"no write but explicit status", func(w http.ResponseWriter, r *http.Request) {
			w.WriteHeader(http.StatusOK)
		}, ""},
		{"many small writes", func(w http.ResponseWriter, r *http.Request) {
			for _, s := range []string{"he", "ll", "o"} {
				w.Write([]byte(s))
			}
		}, "hello"},
		{"WriteHeader twice", func(w http.ResponseWriter, r *http.Request) {
			w.WriteHeader(http.StatusOK)
			w.WriteHeader(http.StatusNotFound)
			w.Write([]byte("hello"))
		}, "hello"},
	}

	for _, tc := range tests {
		t.Run(tc.name, func(t *testing.T) {
			rec := etagServe(http.MethodGet, tc.handler)

			assertEqual(t, rec.Code, http.StatusOK)
			assertEqual(t, rec.Header().Get("ETag"), etagTag(tc.body))
			assertEqual(t, rec.Body.String(), tc.body)
		})
	}
}

func TestETagKeepsHeadersAndDeterministic(t *testing.T) {
	h := func(body string) http.HandlerFunc {
		return func(w http.ResponseWriter, r *http.Request) {
			w.Header().Set("X-Custom", "1")
			w.Header().Set("Content-Type", "text/plain")
			w.Write([]byte(body))
		}
	}

	first := etagServe(http.MethodGet, h("hello"))
	second := etagServe(http.MethodGet, h("hello"))
	other := etagServe(http.MethodGet, h("world"))

	assertEqual(t, first.Header().Get("ETag"), second.Header().Get("ETag"))
	if first.Header().Get("ETag") == other.Header().Get("ETag") {
		t.Fatal("different bodies gave the same ETag")
	}
	assertEqual(t, first.Header().Get("X-Custom"), "1")
	assertEqual(t, first.Header().Get("Content-Type"), "text/plain")
	assertEqual(t, first.Body.String(), "hello")
}

func TestETagHeadTag(t *testing.T) {
	t.Run("tag matches GET for the same content", func(t *testing.T) {
		get := etagServe(http.MethodGet, etagBody("hello"))
		head := etagServe(http.MethodHead, etagBody("hello"))

		assertEqual(t, head.Code, http.StatusOK)
		assertEqual(t, head.Header().Get("ETag"), get.Header().Get("ETag"))
		assertEqual(t, head.Body.Len(), 0)
	})

	t.Run("routed through GetHead", func(t *testing.T) {
		r := chi.NewRouter()
		r.Use(ETag)
		r.Use(GetHead)
		r.Get("/", etagBody("hello"))

		req := httptest.NewRequest(http.MethodHead, "/", http.NoBody)
		rec := httptest.NewRecorder()
		r.ServeHTTP(rec, req)

		assertEqual(t, rec.Header().Get("ETag"), etagTag("hello"))
		assertEqual(t, rec.Body.Len(), 0)
	})

	t.Run("no body with non-zero Content-Length gets no tag", func(t *testing.T) {
		rec := etagServe(http.MethodHead, func(w http.ResponseWriter, r *http.Request) {
			w.Header().Set("Content-Length", "10")
		})

		assertEqual(t, rec.Code, http.StatusOK)
		assertEqual(t, rec.Header().Get("ETag"), "")
		assertEqual(t, rec.Body.Len(), 0)
	})

	t.Run("no body with zero Content-Length gets the empty tag", func(t *testing.T) {
		rec := etagServe(http.MethodHead, func(w http.ResponseWriter, r *http.Request) {
			w.Header().Set("Content-Length", "0")
		})

		assertEqual(t, rec.Header().Get("ETag"), etagTag(""))
	})
}

func TestETagHandlerSetTag(t *testing.T) {
	tests := []struct {
		name string
		etag string
		inm  string
		want int
	}{
		{"weak tag is kept", `W/"v1"`, "", http.StatusOK},
		{"weak handler tag matches strong request tag", `W/"v1"`, `"v1"`, http.StatusNotModified},
		{"strong handler tag matches weak request tag", `"v1"`, `W/"v1"`, http.StatusNotModified},
		{"comma inside a tag is one tag", `"a,b"`, `"a,b"`, http.StatusNotModified},
		{"comma does not split a tag", `"a,b"`, `"a", "b"`, http.StatusOK},
		{"tag comparison is case-sensitive", `"x"`, `"X"`, http.StatusOK},
		{"star matches a handler tag", `"x"`, "*", http.StatusNotModified},
	}

	for _, tc := range tests {
		t.Run(tc.name, func(t *testing.T) {
			rec := etagServe(http.MethodGet, func(w http.ResponseWriter, r *http.Request) {
				w.Header().Set("ETag", tc.etag)
				w.Write([]byte("hello"))
			}, tc.inm)

			assertEqual(t, rec.Code, tc.want)
			assertEqual(t, rec.Header().Get("ETag"), tc.etag)
		})
	}
}

func TestETagIfNoneMatch(t *testing.T) {
	tag := etagTag("hello")
	tests := []struct {
		name string
		inm  []string
		want int
	}{
		{"exact tag", []string{"{tag}"}, http.StatusNotModified},
		{"weak request tag", []string{"W/{tag}"}, http.StatusNotModified},
		{"list with odd whitespace", []string{`"a" ,  W/"b" ,{tag}`}, http.StatusNotModified},
		{"list without a match", []string{`"a", "b" ,W/"c"`}, http.StatusOK},
		{"unquoted member never matches", []string{"x"}, http.StatusOK},
		{"unterminated quote never matches", []string{`"x`}, http.StatusOK},
		{"parsing stops at a malformed member", []string{"x, {tag}"}, http.StatusOK},
		{"empty header", []string{""}, http.StatusOK},
		{"case-sensitive", []string{strings.ToUpper(tag)}, http.StatusOK},
		{"star", []string{"*"}, http.StatusNotModified},
		{"star as a list member", []string{`"a", *`}, http.StatusNotModified},
		{"every header line is considered", []string{`"a"`, "{tag}"}, http.StatusNotModified},
	}

	for _, tc := range tests {
		for _, method := range []string{http.MethodGet, http.MethodHead} {
			t.Run(tc.name+" "+method, func(t *testing.T) {
				var inm []string
				for _, v := range tc.inm {
					inm = append(inm, strings.ReplaceAll(v, "{tag}", tag))
				}
				rec := etagServe(method, etagBody("hello"), inm...)

				assertEqual(t, rec.Code, tc.want)
				if tc.want == http.StatusNotModified {
					assertEqual(t, rec.Header().Get("ETag"), tag)
					assertEqual(t, rec.Body.Len(), 0)
				}
			})
		}
	}
}

func TestETag304Headers(t *testing.T) {
	rec := etagServe(http.MethodGet, func(w http.ResponseWriter, r *http.Request) {
		h := w.Header()
		h.Set("Cache-Control", "max-age=60")
		h.Set("Vary", "Accept")
		h.Set("Expires", "Thu, 01 Jan 2099 00:00:00 GMT")
		h.Set("Content-Location", "/hello.txt")
		h.Set("Content-Type", "text/plain")
		h.Set("Content-Length", "5")
		h.Set("Content-Encoding", "gzip")
		h.Set("Last-Modified", "Mon, 02 Jan 2006 15:04:05 GMT")
		w.Write([]byte("hello"))
	}, "*")

	assertEqual(t, rec.Code, http.StatusNotModified)
	assertEqual(t, rec.Body.Len(), 0)
	assertEqual(t, rec.Header().Get("ETag"), etagTag("hello"))
	assertEqual(t, rec.Header().Get("Cache-Control"), "max-age=60")
	assertEqual(t, rec.Header().Get("Vary"), "Accept")
	assertEqual(t, rec.Header().Get("Expires"), "Thu, 01 Jan 2099 00:00:00 GMT")
	assertEqual(t, rec.Header().Get("Content-Location"), "/hello.txt")
	assertEqual(t, rec.Header().Get("Content-Type"), "")
	assertEqual(t, rec.Header().Get("Content-Length"), "")
	assertEqual(t, rec.Header().Get("Content-Encoding"), "")
	assertEqual(t, rec.Header().Get("Last-Modified"), "")
}

func TestETagOtherMethodsPassThrough(t *testing.T) {
	for _, method := range []string{http.MethodPost, http.MethodPut, http.MethodDelete, http.MethodPatch, http.MethodOptions} {
		t.Run(method, func(t *testing.T) {
			unwrapped := false
			rec := etagServe(method, func(w http.ResponseWriter, r *http.Request) {
				_, unwrapped = w.(*etagResponseWriter)
				w.Write([]byte("hello"))
			}, "*")

			assertEqual(t, unwrapped, false)
			assertEqual(t, rec.Code, http.StatusOK)
			assertEqual(t, rec.Header().Get("ETag"), "")
			assertEqual(t, rec.Body.String(), "hello")
		})
	}
}

func TestETagNonOKFinalStatusPassesThrough(t *testing.T) {
	tests := []struct {
		name string
		code int
	}{
		{"created", http.StatusCreated},
		{"no content", http.StatusNoContent},
		{"partial content", http.StatusPartialContent},
		{"moved", http.StatusMovedPermanently},
		{"handler not modified", http.StatusNotModified},
		{"not found", http.StatusNotFound},
		{"server error", http.StatusInternalServerError},
	}

	for _, tc := range tests {
		t.Run(tc.name, func(t *testing.T) {
			rec := etagServe(http.MethodGet, func(w http.ResponseWriter, r *http.Request) {
				w.WriteHeader(tc.code)
				w.Write([]byte("body"))
			}, "*")

			assertEqual(t, rec.Code, tc.code)
			assertEqual(t, rec.Header().Get("ETag"), "")
			assertEqual(t, rec.Body.String(), "body")
		})
	}
}

func TestETagHandlerTagOnNotFoundIsKept(t *testing.T) {
	rec := etagServe(http.MethodGet, func(w http.ResponseWriter, r *http.Request) {
		w.Header().Set("ETag", `"v1"`)
		w.WriteHeader(http.StatusNotFound)
		w.Write([]byte("missing"))
	}, `"v1"`)

	assertEqual(t, rec.Code, http.StatusNotFound)
	assertEqual(t, rec.Header().Get("ETag"), `"v1"`)
	assertEqual(t, rec.Body.String(), "missing")
}

func TestETagInformationalResponseDoesNotCountAsFinal(t *testing.T) {
	rec := &informationalRecorder{ResponseRecorder: httptest.NewRecorder()}
	req := httptest.NewRequest(http.MethodGet, "/", http.NoBody)
	ETag(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		w.Header().Set("Link", "</style.css>; rel=preload")
		w.WriteHeader(http.StatusEarlyHints)
		w.Write([]byte("ok"))
	})).ServeHTTP(rec, req)

	assertEqual(t, rec.informational, []int{http.StatusEarlyHints})
	assertEqual(t, rec.Code, http.StatusOK)
	assertEqual(t, rec.Header().Get("ETag"), etagTag("ok"))
	assertEqual(t, rec.Body.String(), "ok")
}

func TestETagFlush(t *testing.T) {
	t.Run("buffered flush does not reach the client", func(t *testing.T) {
		rec := etagServe(http.MethodGet, func(w http.ResponseWriter, r *http.Request) {
			w.Write([]byte("a"))
			http.NewResponseController(w).Flush()
			w.Write([]byte("b"))
		})

		assertEqual(t, rec.Flushed, false)
		assertEqual(t, rec.Header().Get("ETag"), etagTag("ab"))
		assertEqual(t, rec.Body.String(), "ab")
	})

	t.Run("flush passes through after a non-200 status", func(t *testing.T) {
		rec := etagServe(http.MethodGet, func(w http.ResponseWriter, r *http.Request) {
			w.WriteHeader(http.StatusNotFound)
			w.Write([]byte("x"))
			http.NewResponseController(w).Flush()
		})

		assertEqual(t, rec.Flushed, true)
		assertEqual(t, rec.Code, http.StatusNotFound)
	})
}

func TestETagStreamingServer(t *testing.T) {
	ts := httptest.NewServer(ETag(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		w.Write([]byte("part1"))
		http.NewResponseController(w).Flush()
		w.Write([]byte("part2"))
	})))
	defer ts.Close()

	resp, body := etagGet(t, ts, http.MethodGet)
	assertEqual(t, resp.StatusCode, http.StatusOK)
	assertEqual(t, body, "part1part2")
	assertEqual(t, resp.Header.Get("ETag"), etagTag("part1part2"))

	resp, body = etagGet(t, ts, http.MethodGet, etagTag("part1part2"))
	assertEqual(t, resp.StatusCode, http.StatusNotModified)
	assertEqual(t, body, "")
}

func TestETagHeadServer(t *testing.T) {
	ts := httptest.NewServer(ETag(etagBody("hello")))
	defer ts.Close()

	resp, body := etagGet(t, ts, http.MethodHead, etagTag("hello"))
	assertEqual(t, resp.StatusCode, http.StatusNotModified)
	assertEqual(t, body, "")
}

func TestETagWriterCapabilities(t *testing.T) {
	t.Run("Hijack and Push report unsupported writers", func(t *testing.T) {
		var hijackErr, pushErr error
		rec := httptest.NewRecorder()
		req := httptest.NewRequest(http.MethodGet, "/", http.NoBody)
		ETag(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
			_, _, hijackErr = w.(http.Hijacker).Hijack()
			pushErr = w.(http.Pusher).Push("/style.css", nil)
		})).ServeHTTP(rec, req)

		assertEqual(t, hijackErr.Error(), "chi/middleware: http.Hijacker is unavailable on the writer")
		assertEqual(t, pushErr.Error(), "chi/middleware: http.Pusher is unavailable on the writer")
	})

	t.Run("Unwrap returns the underlying writer", func(t *testing.T) {
		rec := httptest.NewRecorder()
		req := httptest.NewRequest(http.MethodGet, "/", http.NoBody)
		var unwrapped http.ResponseWriter
		ETag(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
			unwrapped = w.(interface{ Unwrap() http.ResponseWriter }).Unwrap()
		})).ServeHTTP(rec, req)

		if unwrapped != http.ResponseWriter(rec) {
			t.Fatal("Unwrap did not return the underlying writer")
		}
	})
}

func TestETagPanicWritesNothing(t *testing.T) {
	rec := httptest.NewRecorder()
	req := httptest.NewRequest(http.MethodGet, "/", http.NoBody)

	func() {
		defer func() {
			if recover() == nil {
				t.Fatal("expected the panic to propagate")
			}
		}()
		ETag(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
			w.Write([]byte("partial"))
			panic("boom")
		})).ServeHTTP(rec, req)
	}()

	assertEqual(t, rec.Body.String(), "")
	assertEqual(t, rec.Header().Get("ETag"), "")
}

func TestETagRecovererWrites500(t *testing.T) {
	r := chi.NewRouter()
	r.Use(Recoverer)
	r.Use(ETag)
	r.Get("/", func(w http.ResponseWriter, r *http.Request) {
		w.Write([]byte("partial"))
		panic("boom")
	})

	rec := httptest.NewRecorder()
	r.ServeHTTP(rec, httptest.NewRequest(http.MethodGet, "/", http.NoBody))

	assertEqual(t, rec.Code, http.StatusInternalServerError)
	if strings.Contains(rec.Body.String(), "partial") {
		t.Fatal("buffered body leaked after a panic")
	}
}

func TestETagHijackedConnectionIsNotWrittenTo(t *testing.T) {
	const raw = "HTTP/1.1 101 Switching Protocols\r\n\r\n"
	var logBuf bytes.Buffer
	finished := make(chan struct{})

	handler := ETag(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		conn, _, err := w.(http.Hijacker).Hijack()
		assertNoError(t, err)
		_, err = conn.Write([]byte(raw))
		assertNoError(t, err)
		conn.Close()
	}))
	ts := httptest.NewUnstartedServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		handler.ServeHTTP(w, r)
		close(finished)
	}))
	ts.Config.ErrorLog = log.New(&logBuf, "", 0)
	ts.Start()
	defer ts.Close()

	conn, err := net.Dial("tcp", ts.Listener.Addr().String())
	assertNoError(t, err)
	defer conn.Close()
	_, err = conn.Write([]byte("GET / HTTP/1.1\r\nHost: example.com\r\n\r\n"))
	assertNoError(t, err)
	got, err := io.ReadAll(conn)
	assertNoError(t, err)

	// finish runs after the handler returns, so wait for it before reading the log.
	<-finished
	assertEqual(t, string(got), raw)
	if strings.Contains(logBuf.String(), "hijacked connection") {
		t.Fatalf("unexpected log after hijack: %q", logBuf.String())
	}
}

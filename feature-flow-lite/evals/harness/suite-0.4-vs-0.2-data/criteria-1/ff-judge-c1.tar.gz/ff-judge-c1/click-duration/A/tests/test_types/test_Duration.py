from datetime import timedelta

import pytest

import click
from click.testing import CliRunner
from click.types import Duration


@pytest.mark.parametrize(
    ("value", "expect"),
    [
        ("90", timedelta(seconds=90)),
        ("090", timedelta(seconds=90)),
        ("0", timedelta(0)),
        ("0s", timedelta(0)),
        ("90s", timedelta(seconds=90)),
        ("5m", timedelta(minutes=5)),
        ("90m", timedelta(minutes=90)),
        ("25h", timedelta(hours=25)),
        ("1h", timedelta(hours=1)),
        ("1h30m", timedelta(hours=1, minutes=30)),
        ("2d4h", timedelta(days=2, hours=4)),
        ("1m500ms", timedelta(seconds=60.5)),
        ("5ms", timedelta(milliseconds=5)),
        ("1s500ms", timedelta(seconds=1.5)),
        (
            "1d2h3m4s5ms",
            timedelta(days=1, hours=2, minutes=3, seconds=4, milliseconds=5),
        ),
    ],
)
def test_convert(value, expect):
    assert Duration().convert(value, None, None) == expect


@pytest.mark.parametrize(
    "value",
    [
        "1.5h",
        "1h 30m",
        " 90",
        "90 ",
        "",
        "h",
        "1x",
        "1H",
        "+5s",
        "1h30",
        "30m1h",
        "1h1h",
        "1s1m",
        "1ms5s",
        "١٢s",
        "²s",
        "-5s",
        "-90",
        "1h-30m",
        "99999999999999d",
    ],
)
def test_malformed_values_fail(value):
    with pytest.raises(click.BadParameter) as exc_info:
        Duration().convert(value, None, None)

    assert exc_info.value.message == f"{value!r} is not a valid duration."


def test_int_value_is_seconds():
    assert Duration().convert(90, None, None) == timedelta(seconds=90)


def test_long_zero_padded_value_is_zero():
    assert Duration().convert("0" * 4301 + "s", None, None) == timedelta(0)


def test_long_zero_padded_bare_value_is_seconds():
    assert Duration().convert("0" * 5000 + "90", None, None) == timedelta(seconds=90)


@pytest.mark.parametrize(
    ("value", "message"),
    [
        (-5, "-5 is not a valid duration."),
        (1.5, "1.5 is not a valid duration."),
        (True, "True is not a valid duration."),
    ],
)
def test_non_string_malformed_values_fail(value, message):
    with pytest.raises(click.BadParameter) as exc_info:
        Duration().convert(value, None, None)

    assert exc_info.value.message == message


def test_timedelta_is_returned_as_is():
    value = timedelta(minutes=2)
    assert Duration().convert(value, None, None) is value


def test_negative_timedelta_fails():
    value = timedelta(seconds=-1)

    with pytest.raises(click.BadParameter) as exc_info:
        Duration().convert(value, None, None)

    assert exc_info.value.message == f"{value!r} is not a valid duration."


@pytest.mark.parametrize(
    ("type", "value"),
    [
        (Duration(timedelta(seconds=1), timedelta(hours=1)), "1s"),
        (Duration(timedelta(seconds=1), timedelta(hours=1)), "1h"),
        (Duration(timedelta(seconds=1), timedelta(hours=1)), "30m"),
        (Duration(max=timedelta(0)), "0"),
        (Duration(min=timedelta(seconds=-1)), "0"),
    ],
)
def test_bounds_are_inclusive(type, value):
    assert type.convert(value, None, None) == Duration().convert(value, None, None)


@pytest.mark.parametrize(
    ("type", "value", "message"),
    [
        (
            Duration(timedelta(seconds=1), timedelta(hours=1)),
            "2h",
            "2h is not in the range 1s<=x<=1h.",
        ),
        (
            Duration(timedelta(seconds=1), timedelta(hours=1)),
            "500ms",
            "500ms is not in the range 1s<=x<=1h.",
        ),
        (Duration(min=timedelta(seconds=1)), "0s", "0s is not in the range x>=1s."),
        (Duration(max=timedelta(hours=1)), "2h", "2h is not in the range x<=1h."),
        (Duration(max=timedelta(0)), "1s", "1s is not in the range x<=0s."),
        (
            Duration(min=timedelta(microseconds=1)),
            "0s",
            "0s is not in the range x>=0:00:00.000001.",
        ),
        (
            Duration(max=timedelta(seconds=-1)),
            "0",
            "0s is not in the range x<=-1 day, 23:59:59.",
        ),
    ],
)
def test_out_of_range_fails(type, value, message):
    with pytest.raises(click.BadParameter) as exc_info:
        type.convert(value, None, None)

    assert exc_info.value.message == message


def test_constructor_does_not_check_bounds():
    type = Duration(timedelta(hours=2), timedelta(hours=1))
    assert type.min == timedelta(hours=2)
    assert type.max == timedelta(hours=1)


@pytest.mark.parametrize(
    ("type", "expect"),
    [
        (Duration(), "Duration"),
        (Duration(timedelta(seconds=1), timedelta(hours=1)), "<Duration 1s<=x<=1h>"),
        (Duration(min=timedelta(hours=1, minutes=30)), "<Duration x>=1h30m>"),
        (Duration(max=timedelta(0)), "<Duration x<=0s>"),
        (Duration(min=timedelta(seconds=60.5)), "<Duration x>=1m500ms>"),
    ],
)
def test_repr(type, expect):
    assert repr(type) == expect


def test_info_dict_without_bounds():
    assert Duration().to_info_dict() == {
        "param_type": "Duration",
        "name": "duration",
        "min": None,
        "max": None,
    }


def test_is_param_type_not_number_range():
    assert issubclass(Duration, click.ParamType)
    assert not isinstance(Duration(), click.types._NumberRangeBase)
    assert Duration.name == "duration"


def test_importable_from_click_and_types():
    from click.types import Duration as TypesDuration

    assert click.Duration is Duration
    assert click.Duration is TypesDuration


def test_cli_converts_option():
    @click.command()
    @click.option("--timeout", type=click.Duration())
    def cli(timeout):
        click.echo(timeout.total_seconds())

    result = CliRunner().invoke(cli, ["--timeout", "1m500ms"])
    assert result.exit_code == 0
    assert result.output == "60.5\n"


def test_cli_default_is_converted():
    @click.command()
    @click.option("--timeout", type=click.Duration(), default=90)
    def cli(timeout):
        click.echo(timeout.total_seconds())

    result = CliRunner().invoke(cli, [])
    assert result.exit_code == 0
    assert result.output == "90.0\n"


@pytest.mark.parametrize("value", ["1x", "-5s", "99999999999999d"])
def test_cli_malformed_value_is_usage_error(value):
    @click.command()
    @click.option("--timeout", type=click.Duration())
    def cli(timeout):
        pass

    result = CliRunner().invoke(cli, ["--timeout", value])
    assert result.exit_code == 2
    assert isinstance(result.exception, SystemExit)
    assert (
        f"Error: Invalid value for '--timeout': {value!r} is not a valid duration."
        in result.output
    )


def test_cli_out_of_range_is_usage_error():
    @click.command()
    @click.option(
        "--timeout",
        type=Duration(timedelta(seconds=1), timedelta(hours=1)),
    )
    def cli(timeout):
        pass

    result = CliRunner().invoke(cli, ["--timeout", "2h"])
    assert result.exit_code == 2
    assert isinstance(result.exception, SystemExit)
    assert (
        "Error: Invalid value for '--timeout': 2h is not in the range 1s<=x<=1h."
        in result.output
    )


def test_help_shows_range():
    @click.command()
    @click.option(
        "--timeout",
        type=Duration(timedelta(seconds=1), timedelta(hours=1)),
        help="Wait time.",
    )
    def cli(timeout):
        pass

    result = CliRunner().invoke(cli, ["--help"])
    assert "Wait time.  [1s<=x<=1h]" in result.output


def test_help_without_bounds_has_no_range():
    @click.command()
    @click.option("--timeout", type=Duration(), help="Wait time.")
    def cli(timeout):
        pass

    result = CliRunner().invoke(cli, ["--help"])
    assert "Wait time." in result.output
    assert "<=" not in result.output

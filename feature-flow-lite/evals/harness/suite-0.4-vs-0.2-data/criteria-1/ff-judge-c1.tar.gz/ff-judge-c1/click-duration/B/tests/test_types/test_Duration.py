from datetime import timedelta

import pytest

import click
from click.testing import CliRunner


@pytest.mark.parametrize(
    ("value", "expect"),
    [
        ("90s", timedelta(seconds=90)),
        ("5m", timedelta(minutes=5)),
        ("1h30m", timedelta(hours=1, minutes=30)),
        ("2d4h", timedelta(days=2, hours=4)),
        ("1m500ms", timedelta(minutes=1, milliseconds=500)),
        ("500ms", timedelta(milliseconds=500)),
        ("1500ms", timedelta(milliseconds=1500)),
        ("1m", timedelta(minutes=1)),
        ("1ms", timedelta(milliseconds=1)),
        ("1m5s", timedelta(minutes=1, seconds=5)),
        ("0", timedelta(0)),
        ("0s", timedelta(0)),
        ("45", timedelta(seconds=45)),
        ("  1h30m\t", timedelta(hours=1, minutes=30)),
        (timedelta(seconds=5), timedelta(seconds=5)),
        (90, timedelta(seconds=90)),
    ],
)
def test_convert(value, expect):
    assert click.Duration().convert(value, None, None) == expect


@pytest.mark.parametrize(
    "value",
    [
        "30m1h",
        "1h1h",
        "1h 30m",
        "",
        "   ",
        "h",
        "1.5h",
        "1H",
        "1D",
        "1x",
        "1_000s",
        "+5s",
        "٣s",
        "-",
        "--5s",
        "999999999999d",
        "99999999999999999999h",
        "9" * 5000,
        "9" * 5000 + "s",
    ],
)
def test_convert_invalid_string(value):
    with pytest.raises(click.BadParameter) as exc_info:
        click.Duration().convert(value, None, None)

    assert exc_info.value.message == (
        f"{value!r} is not a valid duration. Use a whole number of seconds or"
        " parts with units d, h, m, s, ms, such as 1h30m."
    )


@pytest.mark.parametrize("value", [1.5, None, True, ["1h"], 10**30])
def test_convert_invalid_type(value):
    with pytest.raises(click.BadParameter) as exc_info:
        click.Duration().convert(value, None, None)

    assert exc_info.value.message == (
        f"{value!r} is not a valid duration. Use a whole number of seconds or"
        " parts with units d, h, m, s, ms, such as 1h30m."
    )


@pytest.mark.parametrize(
    ("value", "rendered"),
    [
        ("-5s", "-5s"),
        ("-5", "-5s"),
        ("-1h30m", "-1h30m"),
        (timedelta(seconds=-5), "-5s"),
        (-5, "-5s"),
    ],
)
def test_convert_negative(value, rendered):
    with pytest.raises(click.BadParameter) as exc_info:
        click.Duration().convert(value, None, None)

    assert exc_info.value.message == f"Durations can't be negative: {rendered}."


@pytest.mark.parametrize(
    ("type", "value", "expect"),
    [
        (
            click.Duration(timedelta(seconds=5), timedelta(hours=1)),
            "5s",
            timedelta(seconds=5),
        ),
        (
            click.Duration(timedelta(seconds=5), timedelta(hours=1)),
            "1h",
            timedelta(hours=1),
        ),
        (click.Duration(min=timedelta(0)), "0s", timedelta(0)),
        (click.Duration(max=timedelta(hours=1)), "1h", timedelta(hours=1)),
        (click.Duration(min=timedelta(seconds=5)), "1h", timedelta(hours=1)),
    ],
)
def test_range_accepts_boundaries(type, value, expect):
    assert type.convert(value, None, None) == expect


@pytest.mark.parametrize(
    ("type", "value", "expect"),
    [
        (
            click.Duration(timedelta(seconds=5), timedelta(hours=1)),
            "4s",
            "4s is not in the range 5s<=x<=1h.",
        ),
        (
            click.Duration(timedelta(seconds=5), timedelta(hours=1)),
            "1h1s",
            "1h1s is not in the range 5s<=x<=1h.",
        ),
        (
            click.Duration(min=timedelta(seconds=5)),
            "4s",
            "4s is not in the range x>=5s.",
        ),
        (
            click.Duration(max=timedelta(hours=1)),
            "1h1s",
            "1h1s is not in the range x<=1h.",
        ),
        (
            click.Duration(min=timedelta(microseconds=1500)),
            "0s",
            "0s is not in the range x>=1.5ms.",
        ),
        (
            click.Duration(timedelta(microseconds=1), timedelta(microseconds=999)),
            "0s",
            "0s is not in the range 0.001ms<=x<=0.999ms.",
        ),
        (
            click.Duration(min=timedelta(seconds=1, microseconds=250)),
            "1s",
            "1s is not in the range x>=1s0.25ms.",
        ),
        (
            click.Duration(min=timedelta(seconds=1)),
            timedelta(microseconds=999),
            "0.999ms is not in the range x>=1s.",
        ),
    ],
)
def test_range_rejects_outside(type, value, expect):
    with pytest.raises(click.BadParameter) as exc_info:
        type.convert(value, None, None)

    assert exc_info.value.message == expect


@pytest.mark.parametrize(
    ("value", "rendered"),
    [
        (timedelta(microseconds=-500), "-0.5ms"),
        (timedelta(microseconds=-1500), "-1.5ms"),
    ],
)
def test_negative_sub_millisecond_is_exact(value, rendered):
    with pytest.raises(click.BadParameter) as exc_info:
        click.Duration().convert(value, None, None)

    assert exc_info.value.message == f"Durations can't be negative: {rendered}."


@pytest.mark.parametrize(
    ("type", "expect"),
    [
        (click.Duration(timedelta(seconds=5), timedelta(hours=1)), "5s<=x<=1h"),
        (click.Duration(min=timedelta(seconds=5)), "x>=5s"),
        (click.Duration(max=timedelta(hours=1)), "x<=1h"),
    ],
)
def test_duration_default_help_text(type, expect):
    option = click.Option(["--wait"], type=type)
    context = click.Context(click.Command("test"))
    assert option.get_help_extra(context) == {"range": expect}
    assert f"[{expect}]" in option.get_help_record(context)[1]


def test_unbounded_help_text_has_no_range():
    option = click.Option(["--wait"], type=click.Duration())
    context = click.Context(click.Command("test"))
    assert option.get_help_extra(context) == {}
    assert "[" not in option.get_help_record(context)[1]


@pytest.mark.parametrize(
    ("type", "expect"),
    [
        (
            click.Duration(timedelta(seconds=5), timedelta(hours=1)),
            "<Duration 5s<=x<=1h>",
        ),
        (click.Duration(min=timedelta(seconds=5)), "<Duration x>=5s>"),
        (click.Duration(max=timedelta(hours=1)), "<Duration x<=1h>"),
        (click.Duration(), "<Duration>"),
    ],
)
def test_repr(type, expect):
    assert repr(type) == expect


def test_help_output_shows_range():
    @click.command()
    @click.option(
        "--wait",
        type=click.Duration(timedelta(seconds=5), timedelta(hours=1)),
    )
    def cli(wait):
        pass

    result = CliRunner().invoke(cli, ["--help"])
    assert "--wait DURATION" in result.output
    assert "[5s<=x<=1h]" in result.output


def test_default_value_is_converted():
    @click.command()
    @click.option("--wait", type=click.Duration(), default=90)
    def cli(wait):
        click.echo(wait.total_seconds())

    result = CliRunner().invoke(cli, [])
    assert result.exit_code == 0
    assert result.output == "90.0\n"


def test_default_negative_is_usage_error():
    @click.command()
    @click.option("--wait", type=click.Duration(), default=-5)
    def cli(wait):
        pass

    result = CliRunner().invoke(cli, [])
    assert result.exit_code == 2
    assert (
        "Error: Invalid value for '--wait': Durations can't be negative: -5s.\n"
        in result.output
    )


def test_cli_malformed_is_usage_error():
    @click.command()
    @click.option("--wait", type=click.Duration())
    def cli(wait):
        pass

    result = CliRunner().invoke(cli, ["--wait", "1x"])
    assert result.exit_code == 2
    assert (
        "Error: Invalid value for '--wait': '1x' is not a valid duration. Use a"
        " whole number of seconds or parts with units d, h, m, s, ms, such as 1h30m.\n"
        in result.output
    )


def test_cli_out_of_range_is_usage_error():
    @click.command()
    @click.option(
        "--wait",
        type=click.Duration(timedelta(seconds=5), timedelta(hours=1)),
    )
    def cli(wait):
        pass

    result = CliRunner().invoke(cli, ["--wait", "2h"])
    assert result.exit_code == 2
    assert (
        "Error: Invalid value for '--wait': 2h is not in the range 5s<=x<=1h.\n"
        in result.output
    )

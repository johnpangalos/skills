import { useState } from "react";
import { render, screen, within } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { Combobox, type ComboboxOption } from "../src/Combobox";

const OPTIONS: ComboboxOption[] = [
  { value: "apple", label: "Apple" },
  { value: "banana", label: "Banana", disabled: true },
  { value: "cherry", label: "Cherry" },
  { value: "kiwi", label: "Kiwi (green)" },
];

function Harness({
  options = OPTIONS,
  initial = null,
  onChange = () => {},
  onSubmit = () => {},
}: {
  options?: ComboboxOption[];
  initial?: string | null;
  onChange?: (value: string | null) => void;
  onSubmit?: () => void;
}) {
  const [value, setValue] = useState<string | null>(initial);
  return (
    <form
      onSubmit={(event) => {
        event.preventDefault();
        onSubmit();
      }}
    >
      <Combobox
        label="Fruit"
        options={options}
        value={value}
        placeholder="Pick a fruit"
        onChange={(next) => {
          setValue(next);
          onChange(next);
        }}
      />
    </form>
  );
}

const input = () => screen.getByRole("combobox", { name: "Fruit" });
const optionLabels = () => screen.queryAllByRole("option").map((el) => el.textContent);

describe("Combobox", () => {
  it("C1 renders a labelled input with ARIA wiring, and a listbox of options when open", async () => {
    const user = userEvent.setup();
    render(<Harness initial="cherry" />);
    const combo = input();
    expect(combo).toHaveAccessibleName("Fruit");
    expect(screen.getByText("Fruit").tagName).toBe("LABEL");
    expect(combo).toHaveAttribute("aria-expanded", "false");
    expect(combo).toHaveAttribute("aria-autocomplete", "list");
    expect(combo).toHaveAttribute("placeholder", "Pick a fruit");
    await user.click(combo);
    await user.keyboard("{ArrowDown}");
    expect(combo).toHaveAttribute("aria-expanded", "true");
    const listbox = screen.getByRole("listbox", { name: "Fruit" });
    expect(combo.getAttribute("aria-controls")).toBe(listbox.id);
    const options = within(listbox).getAllByRole("option");
    expect(options.map((el) => el.textContent)).toEqual(["Apple", "Banana", "Cherry", "Kiwi (green)"]);
    expect(new Set(options.map((el) => el.id)).size).toBe(4);
    expect(options[2]).toHaveAttribute("aria-selected", "true");
    expect(options[0]).toHaveAttribute("aria-selected", "false");
    expect(options[1]).toHaveAttribute("aria-disabled", "true");
  });

  it("C2 shows the selected label, or empty for null or an unknown value, and follows value changes", () => {
    const combo = (value: string | null) => (
      <Combobox label="Fruit" options={OPTIONS} value={value} onChange={vi.fn()} />
    );
    const { rerender } = render(combo("cherry"));
    expect(input()).toHaveValue("Cherry");
    rerender(combo(null));
    expect(input()).toHaveValue("");
    rerender(combo("nope"));
    expect(input()).toHaveValue("");
    rerender(combo("apple"));
    expect(input()).toHaveValue("Apple");
  });

  it("C3 typing opens the list and filters by case-insensitive substring", async () => {
    const user = userEvent.setup();
    render(<Harness />);
    await user.type(input(), "AN");
    expect(input()).toHaveAttribute("aria-expanded", "true");
    expect(optionLabels()).toEqual(["Banana"]);
  });

  it("C3 whitespace-only or cleared text shows all options", async () => {
    const user = userEvent.setup();
    render(<Harness />);
    await user.type(input(), "   ");
    expect(optionLabels()).toHaveLength(4);
    await user.clear(input());
    expect(optionLabels()).toHaveLength(4);
  });

  it("C3 regex characters in the query are matched literally", async () => {
    const user = userEvent.setup();
    render(<Harness />);
    await user.type(input(), "(");
    expect(optionLabels()).toEqual(["Kiwi (green)"]);
    await user.clear(input());
    await user.type(input(), ".*");
    expect(screen.getByText("No results")).toBeInTheDocument();
    await user.clear(input());
    await user.type(input(), "[[");
    expect(screen.getByText("No results")).toBeInTheDocument();
  });

  it("C4 shows No results, with no option role and no active descendant, when nothing matches", async () => {
    const user = userEvent.setup();
    render(<Harness />);
    await user.type(input(), "zzz");
    expect(screen.getByText("No results")).toBeInTheDocument();
    expect(screen.queryAllByRole("option")).toHaveLength(0);
    expect(input()).not.toHaveAttribute("aria-activedescendant");
  });

  it("C5 ArrowDown opens, then ArrowDown/ArrowUp move the active option, skipping disabled and wrapping", async () => {
    const user = userEvent.setup();
    render(<Harness />);
    const combo = input();
    await user.click(combo);
    await user.keyboard("{ArrowDown}");
    expect(combo).toHaveAttribute("aria-expanded", "true");
    expect(combo).not.toHaveAttribute("aria-activedescendant");
    const id = (name: string) => screen.getByRole("option", { name }).id;
    await user.keyboard("{ArrowDown}");
    expect(combo).toHaveAttribute("aria-activedescendant", id("Apple"));
    await user.keyboard("{ArrowDown}");
    expect(combo).toHaveAttribute("aria-activedescendant", id("Cherry"));
    await user.keyboard("{ArrowDown}");
    expect(combo).toHaveAttribute("aria-activedescendant", id("Kiwi (green)"));
    await user.keyboard("{ArrowDown}");
    expect(combo).toHaveAttribute("aria-activedescendant", id("Apple"));
    await user.keyboard("{ArrowUp}");
    expect(combo).toHaveAttribute("aria-activedescendant", id("Kiwi (green)"));
    expect(combo).toHaveFocus();
  });

  it("C6 Enter commits the active option, closes the list and shows its label", async () => {
    const user = userEvent.setup();
    const onChange = vi.fn();
    render(<Harness onChange={onChange} />);
    await user.type(input(), "c");
    await user.keyboard("{ArrowDown}");
    await user.keyboard("{Enter}");
    expect(onChange).toHaveBeenCalledTimes(1);
    expect(onChange).toHaveBeenCalledWith("cherry");
    expect(input()).toHaveValue("Cherry");
    expect(input()).toHaveAttribute("aria-expanded", "false");
  });

  it("C6 Enter with no active option does nothing and does not submit the form while open", async () => {
    const user = userEvent.setup();
    const onChange = vi.fn();
    const onSubmit = vi.fn();
    render(<Harness onChange={onChange} onSubmit={onSubmit} />);
    await user.type(input(), "a");
    await user.keyboard("{Enter}");
    expect(onChange).not.toHaveBeenCalled();
    expect(onSubmit).not.toHaveBeenCalled();
    expect(input()).toHaveAttribute("aria-expanded", "true");
    await user.keyboard("{Escape}");
    await user.keyboard("{Enter}");
    expect(onSubmit).toHaveBeenCalledTimes(1);
  });

  it("C6 clicking an enabled option selects it, and clicking a disabled one does nothing", async () => {
    const user = userEvent.setup();
    const onChange = vi.fn();
    render(<Harness onChange={onChange} />);
    await user.click(input());
    await user.keyboard("{ArrowDown}");
    await user.click(screen.getByRole("option", { name: "Banana" }));
    expect(onChange).not.toHaveBeenCalled();
    expect(input()).toHaveAttribute("aria-expanded", "true");
    await user.click(screen.getByRole("option", { name: "Kiwi (green)" }));
    expect(onChange).toHaveBeenCalledWith("kiwi");
    expect(input()).toHaveValue("Kiwi (green)");
    expect(input()).toHaveAttribute("aria-expanded", "false");
  });

  it("C7 Escape closes without calling onChange and reverts the text", async () => {
    const user = userEvent.setup();
    const onChange = vi.fn();
    render(<Harness initial="apple" onChange={onChange} />);
    await user.click(input());
    await user.clear(input());
    await user.type(input(), "ch");
    await user.keyboard("{Escape}");
    expect(onChange).not.toHaveBeenCalledWith("cherry");
    expect(input()).toHaveAttribute("aria-expanded", "false");
    expect(input()).toHaveValue("Apple");
  });

  it("C7 blurring closes the list, reverts the text and does not select", async () => {
    const user = userEvent.setup();
    const onChange = vi.fn();
    render(<Harness initial="apple" onChange={onChange} />);
    await user.click(input());
    await user.type(input(), "ch");
    await user.click(document.body);
    expect(onChange).not.toHaveBeenCalled();
    expect(input()).toHaveAttribute("aria-expanded", "false");
    expect(input()).toHaveValue("Apple");
  });

  it("C8 the active option stays the same item when options are prepended", async () => {
    const user = userEvent.setup();
    const onChange = vi.fn();
    const { rerender } = render(<Harness onChange={onChange} />);
    await user.click(input());
    await user.keyboard("{ArrowDown}{ArrowDown}{ArrowDown}");
    const cherryId = screen.getByRole("option", { name: "Cherry" }).id;
    expect(input()).toHaveAttribute("aria-activedescendant", cherryId);
    rerender(<Harness onChange={onChange} options={[{ value: "avocado", label: "Avocado" }, ...OPTIONS]} />);
    expect(input()).toHaveAttribute("aria-activedescendant", cherryId);
    await user.keyboard("{Enter}");
    expect(onChange).toHaveBeenCalledWith("cherry");
  });

  it("C8 removing the active option clears the active descendant and Enter commits nothing", async () => {
    const user = userEvent.setup();
    const onChange = vi.fn();
    const { rerender } = render(<Harness onChange={onChange} />);
    await user.click(input());
    await user.keyboard("{ArrowDown}{ArrowDown}{ArrowDown}");
    rerender(<Harness onChange={onChange} options={OPTIONS.filter((o) => o.value !== "cherry")} />);
    expect(input()).not.toHaveAttribute("aria-activedescendant");
    await user.keyboard("{Enter}");
    expect(onChange).not.toHaveBeenCalled();
  });

  it("C9 clearing the text and pressing Escape calls onChange(null)", async () => {
    const user = userEvent.setup();
    const onChange = vi.fn();
    render(<Harness initial="apple" onChange={onChange} />);
    await user.click(input());
    await user.clear(input());
    await user.keyboard("{Escape}");
    expect(onChange).toHaveBeenCalledTimes(1);
    expect(onChange).toHaveBeenCalledWith(null);
    expect(input()).toHaveValue("");
  });

  it("C9 clearing the text and blurring calls onChange(null)", async () => {
    const user = userEvent.setup();
    const onChange = vi.fn();
    render(<Harness initial="apple" onChange={onChange} />);
    await user.click(input());
    await user.clear(input());
    await user.click(document.body);
    expect(onChange).toHaveBeenCalledWith(null);
    expect(input()).toHaveValue("");
  });

  it("C3 a query with a space is matched literally, not trimmed", async () => {
    const user = userEvent.setup();
    render(<Harness options={[{ value: "x", label: "Ab" }]} />);
    await user.type(input(), " b");
    expect(screen.getByText("No results")).toBeInTheDocument();
    expect(optionLabels()).toEqual([]);
  });

  it("C8 filtering keeps the active option, and Enter commits it", async () => {
    const user = userEvent.setup();
    const onChange = vi.fn();
    render(<Harness onChange={onChange} />);
    await user.click(input());
    await user.keyboard("{ArrowDown}{ArrowDown}{ArrowDown}");
    const cherryId = screen.getByRole("option", { name: "Cherry" }).id;
    await user.keyboard("r");
    expect(optionLabels()).toEqual(["Cherry", "Kiwi (green)"]);
    expect(input()).toHaveAttribute("aria-activedescendant", cherryId);
    await user.keyboard("{Enter}");
    expect(onChange).toHaveBeenCalledWith("cherry");
  });

  it("C9 clearing text calls onChange(null) only when value is not already null", async () => {
    const user = userEvent.setup();
    const onChange = vi.fn();
    const { rerender } = render(<Combobox label="Fruit" options={OPTIONS} value={null} onChange={onChange} />);
    await user.type(input(), "a");
    await user.clear(input());
    await user.click(document.body);
    expect(onChange).not.toHaveBeenCalled();
    rerender(<Combobox label="Fruit" options={OPTIONS} value="nope" onChange={onChange} />);
    await user.click(input());
    await user.type(input(), "a");
    await user.clear(input());
    await user.click(document.body);
    expect(onChange).toHaveBeenCalledTimes(1);
    expect(onChange).toHaveBeenCalledWith(null);
  });

  it("hostile: an empty options array shows No results without throwing", async () => {
    const user = userEvent.setup();
    render(<Harness options={[]} />);
    await user.type(input(), "a");
    expect(screen.getByText("No results")).toBeInTheDocument();
  });

  it("hostile: when all options are disabled, ArrowDown sets no active descendant and Enter does nothing", async () => {
    const user = userEvent.setup();
    const onChange = vi.fn();
    render(
      <Harness
        onChange={onChange}
        options={[
          { value: "a", label: "Alpha", disabled: true },
          { value: "b", label: "Beta", disabled: true },
        ]}
      />,
    );
    await user.click(input());
    await user.keyboard("{ArrowDown}{ArrowDown}");
    expect(input()).toHaveAttribute("aria-expanded", "true");
    expect(input()).not.toHaveAttribute("aria-activedescendant");
    await user.keyboard("{Enter}");
    expect(onChange).not.toHaveBeenCalled();
  });

  it("hostile: two comboboxes on one page have distinct ids", () => {
    render(
      <>
        <Harness />
        <Harness />
      </>,
    );
    const [first, second] = screen.getAllByRole("combobox");
    expect(first.id).not.toBe(second.id);
    expect(first.getAttribute("aria-controls")).not.toBe(second.getAttribute("aria-controls"));
  });

  it("a consumer onKeyDown and onBlur on Combobox run, and ArrowDown still opens the list", async () => {
    const user = userEvent.setup();
    const onKeyDown = vi.fn();
    const onBlur = vi.fn();
    render(
      <Combobox
        label="Fruit"
        options={OPTIONS}
        value={null}
        onChange={vi.fn()}
        onKeyDown={onKeyDown}
        onBlur={onBlur}
      />,
    );
    await user.click(input());
    await user.keyboard("{ArrowDown}");
    expect(onKeyDown).toHaveBeenCalledWith(expect.objectContaining({ key: "ArrowDown" }));
    expect(input()).toHaveAttribute("aria-expanded", "true");
    await user.click(document.body);
    expect(onBlur).toHaveBeenCalledTimes(1);
    expect(input()).toHaveAttribute("aria-expanded", "false");
  });

  it("consumer props cannot override the input's id or aria attributes", () => {
    render(
      <Combobox
        label="Fruit"
        options={OPTIONS}
        value={null}
        onChange={vi.fn()}
        id="custom"
        aria-expanded
        aria-controls="other"
      />,
    );
    expect(input().id).not.toBe("custom");
    expect(input()).toHaveAttribute("aria-expanded", "false");
    expect(input().getAttribute("aria-controls")).toBe(screen.getByRole("listbox", { hidden: true }).id);
  });
});

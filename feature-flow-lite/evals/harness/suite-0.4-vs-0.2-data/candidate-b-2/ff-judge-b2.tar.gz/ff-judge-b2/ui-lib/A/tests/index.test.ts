import * as ui from "../src/index";

describe("package exports", () => {
  it("P1 exports Tabs, TabList, Tab, TabPanel, Dialog and Combobox", () => {
    expect(typeof ui.Tabs).toBe("function");
    expect(typeof ui.TabList).toBe("function");
    expect(typeof ui.Tab).toBe("function");
    expect(typeof ui.TabPanel).toBe("function");
    expect(typeof ui.Dialog).toBe("function");
    expect(typeof ui.Combobox).toBe("function");
  });

  it("P1 exports the props types", () => {
    const tabs: ui.TabsProps = { defaultValue: "a" };
    const option: ui.ComboboxOption = { value: "a", label: "A" };
    expect(tabs.defaultValue).toBe("a");
    expect(option.label).toBe("A");
  });
});

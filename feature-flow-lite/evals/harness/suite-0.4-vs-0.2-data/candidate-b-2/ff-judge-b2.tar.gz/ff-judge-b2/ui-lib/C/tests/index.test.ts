import { describe, expect, it } from "vitest";
import readme from "../README.md?raw";
import * as ui from "../src";
import type {
  ComboboxOption,
  ComboboxProps,
  DialogProps,
  TabListProps,
  TabPanelProps,
  TabProps,
  TabsProps,
} from "../src";

// Compile-time check that every prop type is exported from the entry point.
export type ExportedTypes =
  | TabsProps
  | TabListProps
  | TabProps
  | TabPanelProps
  | DialogProps
  | ComboboxProps
  | ComboboxOption;

describe("exports", () => {
  it("G1 exports Tabs, TabList, Tab, TabPanel, Dialog and Combobox", () => {
    for (const name of ["Tabs", "TabList", "Tab", "TabPanel", "Dialog", "Combobox"] as const) {
      expect(ui[name], name).toBeTypeOf("function");
    }
  });

  it.each(["Tabs", "TabList", "Tab", "TabPanel", "Dialog", "Combobox"])("G2 README documents %s", (name) => {
    expect(readme).toMatch(new RegExp(`^#+ .*\`?${name}\`?$`, "m"));
  });

  it("G2 README documents keyboard behaviour for each widget", () => {
    expect(readme.match(/keyboard/gi)?.length).toBeGreaterThanOrEqual(3);
  });
});

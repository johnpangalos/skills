import {
  createContext,
  useContext,
  useId,
  useLayoutEffect,
  useReducer,
  useRef,
  useState,
  type ComponentPropsWithoutRef,
  type KeyboardEvent,
} from 'react';

export type TabsProps = Omit<ComponentPropsWithoutRef<'div'>, 'defaultValue'> & {
  defaultValue?: string;
  value?: string;
  onValueChange?: (value: string) => void;
};

export type TabListProps = ComponentPropsWithoutRef<'div'> & {
  'aria-label': string;
};

export type TabProps = Omit<ComponentPropsWithoutRef<'button'>, 'value'> & {
  value: string;
  disabled?: boolean;
};

export type TabPanelProps = Omit<ComponentPropsWithoutRef<'div'>, 'value'> & {
  value: string;
};

type TabsContextValue = {
  id: string;
  selected: string | null;
  select: (value: string) => void;
  selectFallback: (value: string) => void;
  // The one tab in the tab order: the selected tab if it is enabled, else the first enabled tab.
  focusable: string | null;
  setFocusable: (value: string | null) => void;
  // Re-renders TabList so its measurement runs again after a tab mounts, unmounts or changes disabled.
  remeasure: () => void;
};

const TabsContext = createContext<TabsContextValue | null>(null);

function useTabs() {
  const context = useContext(TabsContext);
  if (!context) throw new Error('Tab, TabList and TabPanel must be rendered inside <Tabs>');
  return context;
}

// Ids are built from the value, so spaces and other characters are encoded.
const tabId = (id: string, value: string) => `${id}-tab-${encodeURIComponent(value)}`;
const panelId = (id: string, value: string) => `${id}-panel-${encodeURIComponent(value)}`;

// Enabled tabs in DOM order, so inserted or removed tabs keep their place.
function enabledTabs(list: Element) {
  return Array.from(list.querySelectorAll<HTMLButtonElement>('[role="tab"]')).filter((tab) => !tab.disabled);
}

export function Tabs({ defaultValue, value, onValueChange, children, ...rest }: TabsProps) {
  const id = useId();
  const [internal, setInternal] = useState<string | null>(defaultValue ?? null);
  const [focusable, setFocusable] = useState<string | null>(null);
  const [, remeasure] = useReducer((count: number) => count + 1, 0);
  const controlled = value !== undefined;
  const selected = controlled ? value : internal;

  function select(next: string) {
    if (next === selected) return;
    if (!controlled) setInternal(next);
    onValueChange?.(next);
  }

  function selectFallback(next: string) {
    if (!controlled) setInternal(next);
  }

  return (
    <TabsContext.Provider value={{ id, selected, select, selectFallback, focusable, setFocusable, remeasure }}>
      <div {...rest}>{children}</div>
    </TabsContext.Provider>
  );
}

export function TabList({ children, ...rest }: TabListProps) {
  const ref = useRef<HTMLDivElement>(null);
  const { selected, selectFallback, setFocusable } = useTabs();

  // Reads the DOM so disabled tabs are skipped. If the selected tab is not enabled
  // (no match for defaultValue, or no default), uncontrolled tabs select the first enabled tab.
  // Controlled tabs keep their value and only the tab stop moves.
  useLayoutEffect(() => {
    const tabs = enabledTabs(ref.current!);
    const selectedEnabled = tabs.some((tab) => tab.dataset.value === selected);
    if (!selectedEnabled && tabs.length > 0) selectFallback(tabs[0].dataset.value!);
    setFocusable(selectedEnabled ? selected : (tabs[0]?.dataset.value ?? null));
  });

  return (
    <div {...rest} ref={ref} role="tablist">
      {children}
    </div>
  );
}

export function Tab({ value, disabled, onClick, onKeyDown, children, ...rest }: TabProps) {
  const { id, selected, select, focusable, remeasure } = useTabs();
  const isSelected = selected === value;

  // TabList does not render when a tab mounts, unmounts or changes disabled, so ask it to measure again.
  // Unmount cleanup only schedules the measurement, so it runs after the tab is out of the DOM.
  useLayoutEffect(() => {
    remeasure();
    return remeasure;
  }, [disabled]);

  function handleKeyDown(event: KeyboardEvent<HTMLButtonElement>) {
    onKeyDown?.(event);
    if (event.defaultPrevented) return;
    const tabs = enabledTabs(event.currentTarget.closest('[role="tablist"]')!);
    const index = tabs.indexOf(event.currentTarget);
    let next: HTMLButtonElement;
    switch (event.key) {
      case 'ArrowRight':
        next = tabs[(index + 1) % tabs.length];
        break;
      case 'ArrowLeft':
        next = tabs[(index - 1 + tabs.length) % tabs.length];
        break;
      case 'Home':
        next = tabs[0];
        break;
      case 'End':
        next = tabs[tabs.length - 1];
        break;
      default:
        return;
    }
    event.preventDefault();
    next.focus();
    select(next.dataset.value!);
  }

  return (
    <button
      {...rest}
      type="button"
      role="tab"
      id={tabId(id, value)}
      data-value={value}
      aria-selected={isSelected}
      aria-controls={panelId(id, value)}
      // Until TabList measures the DOM, the selected tab is the tab stop. This keeps a parent's
      // open-time focus (which runs before that measurement) on the selected tab.
      tabIndex={(focusable ?? selected) === value ? 0 : -1}
      disabled={disabled}
      onKeyDown={handleKeyDown}
      onClick={(event) => {
        onClick?.(event);
        select(value);
      }}
    >
      {children}
    </button>
  );
}

export function TabPanel({ value, children, ...rest }: TabPanelProps) {
  const { id, selected } = useTabs();
  return (
    <div
      {...rest}
      role="tabpanel"
      id={panelId(id, value)}
      aria-labelledby={tabId(id, value)}
      tabIndex={0}
      hidden={selected !== value}
    >
      {children}
    </div>
  );
}

import * as React from "react";

export type TabsProps = Omit<React.HTMLAttributes<HTMLDivElement>, "defaultValue"> & {
  defaultValue?: string;
  value?: string;
  onValueChange?: (value: string) => void;
};

export type TabListProps = React.HTMLAttributes<HTMLDivElement> & {
  "aria-label": string;
};

export type TabProps = Omit<React.ButtonHTMLAttributes<HTMLButtonElement>, "value"> & {
  value: string;
  disabled?: boolean;
};

export type TabPanelProps = React.HTMLAttributes<HTMLDivElement> & {
  value: string;
};

type TabsContextValue = {
  baseId: string;
  selected: string | null;
  isTabStop: (value: string, disabled?: boolean) => boolean;
  select: (value: string) => void;
  setEnabled: (values: string[]) => void;
};

const TabsContext = React.createContext<TabsContextValue | null>(null);

function useTabsContext() {
  const context = React.useContext(TabsContext);
  if (!context) {
    throw new Error("Tab, TabList and TabPanel must be rendered inside Tabs");
  }
  return context;
}

function enabledTabs(list: HTMLElement | null): HTMLButtonElement[] {
  return list ? Array.from(list.querySelectorAll<HTMLButtonElement>('[role="tab"]:not(:disabled)')) : [];
}

export function Tabs({ defaultValue, value, onValueChange, ...rest }: TabsProps) {
  const baseId = React.useId();
  const [internal, setInternal] = React.useState(defaultValue);
  // Null until TabList has measured the DOM (after the first commit).
  const [enabled, setEnabled] = React.useState<string[] | null>(null);
  const controlled = value !== undefined;
  const current = controlled ? value : internal;
  // With no defaultValue, the first enabled tab is selected.
  const selected = current === undefined ? (enabled?.[0] ?? null) : current;
  const list = enabled ?? [];
  // The selected tab is the tab-stop when it is enabled; otherwise the first enabled tab is.
  const tabbable = selected !== null && list.includes(selected) ? selected : (list[0] ?? null);
  // Before measuring, a Tab cannot know if it is the first enabled one. Until then every
  // enabled tab is a tab-stop, so a Dialog that focuses on open still lands on a tab.
  const isTabStop = (value: string, disabled = false) => {
    if (enabled !== null) return tabbable === value;
    return selected === null ? !disabled : selected === value;
  };

  const select = (next: string) => {
    if (next === selected) return;
    if (!controlled) setInternal(next);
    onValueChange?.(next);
  };

  // TabList reports the enabled tabs after each render; keep state stable so this does not loop.
  const updateEnabled = React.useCallback(
    (next: string[]) => setEnabled((prev) => (JSON.stringify(prev) === JSON.stringify(next) ? prev : next)),
    [],
  );

  return (
    <TabsContext.Provider value={{ baseId, selected, isTabStop, select, setEnabled: updateEnabled }}>
      <div {...rest} />
    </TabsContext.Provider>
  );
}

export function TabList({ onKeyDown, ...rest }: TabListProps) {
  const { setEnabled, select } = useTabsContext();
  const ref = React.useRef<HTMLDivElement>(null);

  const measure = () => setEnabled(enabledTabs(ref.current).map((tab) => tab.value));

  React.useLayoutEffect(() => {
    measure();
  });

  // A child that owns its state can add, remove or disable tabs without re-rendering TabList,
  // so watch the DOM as well.
  React.useLayoutEffect(() => {
    const observer = new MutationObserver(measure);
    observer.observe(ref.current!, { childList: true, subtree: true, attributes: true, attributeFilter: ["disabled"] });
    return () => observer.disconnect();
  }, [setEnabled]);

  const handleKeyDown = (event: React.KeyboardEvent<HTMLDivElement>) => {
    onKeyDown?.(event);
    const tabs = enabledTabs(ref.current);
    const index = tabs.indexOf(event.target as HTMLButtonElement);
    if (index === -1) return;

    let next: HTMLButtonElement;
    switch (event.key) {
      case "ArrowRight":
        next = tabs[(index + 1) % tabs.length];
        break;
      case "ArrowLeft":
        next = tabs[(index - 1 + tabs.length) % tabs.length];
        break;
      case "Home":
        next = tabs[0];
        break;
      case "End":
        next = tabs[tabs.length - 1];
        break;
      default:
        return;
    }
    event.preventDefault();
    next.focus();
    select(next.value);
  };

  return <div {...rest} ref={ref} role="tablist" onKeyDown={handleKeyDown} />;
}

export function Tab({ value, disabled, onClick, ...rest }: TabProps) {
  const { baseId, selected, isTabStop, select } = useTabsContext();
  const key = encodeURIComponent(value);
  return (
    <button
      {...rest}
      type="button"
      role="tab"
      id={`${baseId}-tab-${key}`}
      value={value}
      aria-selected={selected === value}
      aria-controls={`${baseId}-panel-${key}`}
      tabIndex={isTabStop(value, disabled) ? 0 : -1}
      disabled={disabled}
      onClick={(event) => {
        onClick?.(event);
        if (!disabled) select(value);
      }}
    />
  );
}

export function TabPanel({ value, ...rest }: TabPanelProps) {
  const { baseId, selected } = useTabsContext();
  const key = encodeURIComponent(value);
  const isSelected = selected === value;
  return (
    <div
      {...rest}
      role="tabpanel"
      id={`${baseId}-panel-${key}`}
      aria-labelledby={`${baseId}-tab-${key}`}
      hidden={!isSelected}
      tabIndex={isSelected ? 0 : undefined}
    />
  );
}

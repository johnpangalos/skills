import { useState, type ReactNode } from 'react';
import { act, render, screen } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { renderToString } from 'react-dom/server';
import { Dialog } from '../src/Dialog';
import { Tab, TabList, TabPanel, Tabs } from '../src/Tabs';

type AppProps = {
  spy?: (open: boolean) => void;
  description?: string;
  children?: ReactNode;
};

// A page with an opener button and a dialog that the opener toggles.
function App({ spy = vi.fn(), description, children }: AppProps) {
  const [open, setOpen] = useState(false);
  return (
    <>
      <button onClick={() => setOpen(true)}>Open</button>
      <Dialog
        open={open}
        onOpenChange={(next) => {
          spy(next);
          setOpen(next);
        }}
        title="Settings"
        description={description}
      >
        {children ?? (
          <>
            <button>First</button>
            <button>Second</button>
          </>
        )}
      </Dialog>
    </>
  );
}

// Two levels: the outer dialog holds the button that opens the inner one.
function Nested({ outerSpy = vi.fn(), innerSpy = vi.fn() }: { outerSpy?: (o: boolean) => void; innerSpy?: (o: boolean) => void }) {
  const [outer, setOuter] = useState(false);
  const [inner, setInner] = useState(false);
  return (
    <>
      <button onClick={() => setOuter(true)}>Open outer</button>
      <Dialog
        open={outer}
        onOpenChange={(next) => {
          outerSpy(next);
          setOuter(next);
        }}
        title="Outer"
      >
        <button onClick={() => setInner(true)}>Open inner</button>
        <Dialog
          open={inner}
          onOpenChange={(next) => {
            innerSpy(next);
            setInner(next);
          }}
          title="Inner"
        >
          <button>Inner action</button>
        </Dialog>
      </Dialog>
    </>
  );
}

const button = (name: string) => screen.getByRole('button', { name });
const dialog = () => screen.getByRole('dialog');
const backdrop = () => document.querySelector('[data-backdrop]') as HTMLElement;

describe('Dialog', () => {
  it('D1 renders a backdrop and a labelled modal dialog in a portal on document.body, and nothing when closed', async () => {
    const user = userEvent.setup();
    render(<App description="Change things" />);
    expect(screen.queryByRole('dialog')).toBeNull();
    expect(backdrop()).toBeNull();

    await user.click(button('Open'));
    const modal = dialog();
    expect(modal).toHaveAttribute('aria-modal', 'true');
    const heading = screen.getByRole('heading', { name: 'Settings' });
    expect(modal).toHaveAttribute('aria-labelledby', heading.id);
    expect(modal).toHaveAccessibleDescription('Change things');
    expect(backdrop().parentElement).toBe(document.body);
    expect(backdrop()).toContainElement(modal);
  });

  it('D1 omits aria-describedby when there is no description', async () => {
    const user = userEvent.setup();
    render(<App />);
    await user.click(button('Open'));
    expect(dialog()).not.toHaveAttribute('aria-describedby');
  });

  it('D2 moves focus to the first tabbable element on open', async () => {
    const user = userEvent.setup();
    render(<App />);
    await user.click(button('Open'));
    expect(button('First')).toHaveFocus();
  });

  it('D2 focuses the dialog container when nothing inside is tabbable', async () => {
    const user = userEvent.setup();
    render(<App>{<p>Just text</p>}</App>);
    await user.click(button('Open'));
    expect(dialog()).toHaveFocus();
    expect(dialog()).toHaveAttribute('tabindex', '-1');
  });

  it('D2 keeps focus on a child that uses autoFocus', async () => {
    const user = userEvent.setup();
    render(
      <App>
        <button>First</button>
        <input aria-label="Name" autoFocus />
      </App>,
    );
    await user.click(button('Open'));
    expect(screen.getByRole('textbox', { name: 'Name' })).toHaveFocus();
  });

  it('D3 Tab from the last tabbable wraps to the first, and Shift+Tab from the first wraps to the last', async () => {
    const user = userEvent.setup();
    render(<App />);
    await user.click(button('Open'));
    expect(button('First')).toHaveFocus();
    await user.tab();
    expect(button('Second')).toHaveFocus();
    await user.tab();
    expect(button('First')).toHaveFocus();
    await user.tab({ shift: true });
    expect(button('Second')).toHaveFocus();
  });

  it('D3 never tabs into the hidden panels of a Tabs component inside the dialog', async () => {
    const user = userEvent.setup();
    render(
      <App>
        <Tabs defaultValue="a">
          <TabList aria-label="Sections">
            <Tab value="a">A</Tab>
            <Tab value="b">B</Tab>
          </TabList>
          <TabPanel value="a">
            <button>A1</button>
          </TabPanel>
          <TabPanel value="b">
            <button>B1</button>
          </TabPanel>
        </Tabs>
      </App>,
    );
    await user.click(button('Open'));
    const hiddenTab = screen.getByRole('tab', { name: 'B' });
    const hiddenPanel = document.getElementById(hiddenTab.getAttribute('aria-controls') ?? '') as HTMLElement;
    expect(screen.getByRole('tab', { name: 'A' })).toHaveFocus();
    await user.tab();
    await user.tab();
    expect(button('A1')).toHaveFocus();
    for (let i = 0; i < 6; i++) {
      await user.tab();
      expect(hiddenPanel).not.toContainElement(document.activeElement as HTMLElement);
      expect(document.activeElement).not.toBe(hiddenTab);
    }
    for (let i = 0; i < 6; i++) {
      await user.tab({ shift: true });
      expect(hiddenPanel).not.toContainElement(document.activeElement as HTMLElement);
      expect(document.activeElement).not.toBe(hiddenTab);
    }
  });

  it('D3 never reaches disabled, tabIndex=-1, hidden, display:none or inert content', async () => {
    const user = userEvent.setup();
    render(
      <App>
        <button>A</button>
        <button disabled>Disabled</button>
        <button tabIndex={-1}>Skipped</button>
        <div hidden>
          <button>Hidden</button>
        </div>
        <div style={{ display: 'none' }}>
          <button>NoDisplay</button>
        </div>
        <div inert>
          <button>Inert</button>
        </div>
        <button>B</button>
      </App>,
    );
    await user.click(button('Open'));
    const visited: string[] = [];
    for (let i = 0; i < 6; i++) {
      await user.tab();
      visited.push(document.activeElement?.textContent ?? '');
    }
    expect(visited).toEqual(['B', 'A', 'B', 'A', 'B', 'A']);
  });

  it('D3 includes elements added after opening', async () => {
    const user = userEvent.setup();
    render(<App />);
    await user.click(button('Open'));
    const late = document.createElement('button');
    late.textContent = 'Late';
    dialog().appendChild(late);
    await user.tab();
    await user.tab();
    expect(late).toHaveFocus();
  });

  it('D3 pulls focus back when it escapes the dialog', async () => {
    const user = userEvent.setup();
    render(<App />);
    await user.click(button('Open'));
    act(() => button('Open').focus());
    expect(dialog().contains(document.activeElement)).toBe(true);
    expect(button('First')).toHaveFocus();
  });

  it('D4 Escape calls onOpenChange(false) and the dialog closes', async () => {
    const user = userEvent.setup();
    const spy = vi.fn();
    render(<App spy={spy} />);
    await user.click(button('Open'));
    await user.keyboard('{Escape}');
    expect(spy).toHaveBeenCalledWith(false);
    expect(screen.queryByRole('dialog')).toBeNull();
  });

  it('D4 a click on the backdrop closes, a click inside the content does not', async () => {
    const user = userEvent.setup();
    const spy = vi.fn();
    render(<App spy={spy} />);
    await user.click(button('Open'));
    await user.click(button('First'));
    expect(spy).not.toHaveBeenCalled();
    await user.click(backdrop());
    expect(spy).toHaveBeenCalledTimes(1);
    expect(spy).toHaveBeenCalledWith(false);
  });

  it('D4 a press that starts inside the content and ends on the backdrop does not close', async () => {
    const user = userEvent.setup();
    const spy = vi.fn();
    render(<App spy={spy} />);
    await user.click(button('Open'));
    await user.pointer([
      { keys: '[MouseLeft>]', target: button('First') },
      { target: backdrop() },
      { keys: '[/MouseLeft]', target: backdrop() },
    ]);
    expect(spy).not.toHaveBeenCalled();
    expect(dialog()).toBeInTheDocument();
  });

  it('D5 returns focus to the opener when the dialog closes', async () => {
    const user = userEvent.setup();
    render(<App />);
    await user.click(button('Open'));
    await user.keyboard('{Escape}');
    expect(button('Open')).toHaveFocus();
  });

  it('D5 returns focus to the opener even when a child uses autoFocus', async () => {
    const user = userEvent.setup();
    render(
      <App>
        <input aria-label="Name" autoFocus />
      </App>,
    );
    await user.click(button('Open'));
    expect(screen.getByRole('textbox', { name: 'Name' })).toHaveFocus();
    await user.keyboard('{Escape}');
    expect(button('Open')).toHaveFocus();
  });

  it('D5 returns focus to the opener when the dialog unmounts while open', async () => {
    const user = userEvent.setup();
    function Toggle({ show }: { show: boolean }) {
      return (
        <>
          <button>Opener</button>
          {show && (
            <Dialog open onOpenChange={() => {}} title="Temporary">
              <button>Inside</button>
            </Dialog>
          )}
        </>
      );
    }
    const { rerender } = render(<Toggle show={false} />);
    await user.click(button('Opener'));
    rerender(<Toggle show />);
    expect(button('Inside')).toHaveFocus();
    rerender(<Toggle show={false} />);
    expect(button('Opener')).toHaveFocus();
  });

  it('D6 Escape closes only the top dialog', async () => {
    const user = userEvent.setup();
    const outerSpy = vi.fn();
    const innerSpy = vi.fn();
    render(<Nested outerSpy={outerSpy} innerSpy={innerSpy} />);
    await user.click(button('Open outer'));
    await user.click(button('Open inner'));
    expect(button('Inner action')).toHaveFocus();

    await user.keyboard('{Escape}');
    expect(innerSpy).toHaveBeenCalledTimes(1);
    expect(outerSpy).not.toHaveBeenCalled();
    expect(screen.getByRole('dialog', { name: 'Outer' })).toBeInTheDocument();
    expect(screen.queryByRole('dialog', { name: 'Inner' })).toBeNull();

    await user.keyboard('{Escape}');
    expect(outerSpy).toHaveBeenCalledWith(false);
    expect(screen.queryByRole('dialog')).toBeNull();
  });

  it('D6 the outer trap does not steal focus from the inner dialog', async () => {
    const user = userEvent.setup();
    render(<Nested />);
    await user.click(button('Open outer'));
    await user.click(button('Open inner'));
    await user.tab();
    expect(button('Inner action')).toHaveFocus();
    await user.tab({ shift: true });
    expect(button('Inner action')).toHaveFocus();
  });

  it('D6 closing the inner dialog returns focus to the button in the outer dialog that opened it', async () => {
    const user = userEvent.setup();
    render(<Nested />);
    await user.click(button('Open outer'));
    await user.click(button('Open inner'));
    await user.keyboard('{Escape}');
    expect(button('Open inner')).toHaveFocus();
  });

  it('D4 hostile: opening and closing rapidly leaves no stray backdrop and returns focus to the opener', async () => {
    const user = userEvent.setup();
    const spy = vi.fn();
    render(<App spy={spy} />);
    for (let i = 0; i < 5; i++) {
      await user.click(button('Open'));
      await user.keyboard('{Escape}');
    }
    expect(spy).toHaveBeenCalledTimes(5);
    expect(backdrop()).toBeNull();
    expect(button('Open')).toHaveFocus();
  });

  it('D5 hostile: the opener unmounted while open does not crash on close', async () => {
    const user = userEvent.setup();
    const spy = vi.fn();
    function Removable({ showOpener }: { showOpener: boolean }) {
      const [open, setOpen] = useState(false);
      return (
        <>
          {showOpener && <button onClick={() => setOpen(true)}>Open</button>}
          <Dialog
            open={open}
            onOpenChange={(next) => {
              spy(next);
              setOpen(next);
            }}
            title="Gone opener"
          >
            <button>Inside</button>
          </Dialog>
        </>
      );
    }
    const { rerender } = render(<Removable showOpener />);
    await user.click(button('Open'));
    rerender(<Removable showOpener={false} />);
    expect(button('Inside')).toHaveFocus();
    await user.keyboard('{Escape}');
    expect(spy).toHaveBeenCalledWith(false);
    expect(screen.queryByRole('dialog')).toBeNull();
  });

  it('D3 hostile: content with no focusable elements keeps Tab on the dialog', async () => {
    const user = userEvent.setup();
    render(<App>{<p>Just text</p>}</App>);
    await user.click(button('Open'));
    await user.tab();
    expect(dialog()).toHaveFocus();
  });

  it('D4 hostile: a parent that ignores the close keeps the dialog open and trapped', async () => {
    const user = userEvent.setup();
    const spy = vi.fn();
    render(
      <Dialog open onOpenChange={spy} title="Stuck">
        <button>A</button>
        <button>B</button>
      </Dialog>,
    );
    await user.keyboard('{Escape}');
    expect(spy).toHaveBeenCalledWith(false);
    expect(dialog()).toBeInTheDocument();
    expect(button('A')).toHaveFocus();
    await user.tab();
    expect(button('B')).toHaveFocus();
    await user.tab();
    expect(button('A')).toHaveFocus();
  });

  it('SSR: renders nothing on the server and never reads document.body during render', () => {
    const bodyRead = vi.spyOn(document, 'body', 'get');
    const html = renderToString(
      <Dialog open onOpenChange={() => {}} title="Server">
        <button>x</button>
      </Dialog>,
    );
    expect(html).toBe('');
    expect(bodyRead).not.toHaveBeenCalled();
    bodyRead.mockRestore();
  });

  it('G2 two open dialogs have distinct ids', () => {
    render(
      <>
        <Dialog open onOpenChange={() => {}} title="One">
          <button>a</button>
        </Dialog>
        <Dialog open onOpenChange={() => {}} title="Two">
          <button>b</button>
        </Dialog>
      </>,
    );
    const [one, two] = screen.getAllByRole('dialog');
    expect(one.getAttribute('aria-labelledby')).not.toBe(two.getAttribute('aria-labelledby'));
    expect(one.getAttribute('aria-labelledby')).toBeTruthy();
  });

  it('G1 passes className and data attributes to the dialog element', () => {
    render(
      <Dialog open onOpenChange={() => {}} title="Props" data-testid="modal" className="m">
        <button>a</button>
      </Dialog>,
    );
    expect(screen.getByTestId('modal')).toHaveClass('m');
    expect(screen.getByTestId('modal')).toHaveAttribute('role', 'dialog');
  });
});

# @acme/ui

Accessible React 19 components. No CSS is shipped: every component that renders a DOM element accepts `className` and forwards native props, so you style it yourself. Event handlers you pass (`onClick`, `onKeyDown`, `onBlur`) run before the component's own handling. If a key or click handler calls `preventDefault()`, the built-in handling of that event is skipped.

Run the checks with `pnpm test` and `pnpm typecheck`.

## Tabs

Usage:

```tsx
import { Tabs, TabList, Tab, TabPanel } from "@acme/ui";

<Tabs defaultValue="billing">
  <TabList aria-label="Account">
    <Tab value="profile">Profile</Tab>
    <Tab value="billing">Billing</Tab>
    <Tab value="team" disabled>Team</Tab>
  </TabList>
  <TabPanel value="profile">Profile settings</TabPanel>
  <TabPanel value="billing">Billing details</TabPanel>
  <TabPanel value="team">Team settings</TabPanel>
</Tabs>;
```

Props:

| Component | Prop | Type | Notes |
| --- | --- | --- | --- |
| `Tabs` | `defaultValue` | `string` | Initial selection (uncontrolled). Defaults to the first enabled tab. |
| `Tabs` | `value` | `string` | Selected tab (controlled). |
| `Tabs` | `onValueChange` | `(value: string) => void` | Called when the selection changes. Not called when the selected tab is activated again. |
| `Tabs` | `className`, native `div` props | | Rendered on the wrapping `div`. |
| `TabList` | `aria-label` | `string` (required) | Names the tablist. |
| `TabList` | `className`, native `div` props | | |
| `Tab` | `value` | `string` (required) | Identifies the tab and links it to its panel. |
| `Tab` | `disabled` | `boolean` | Cannot be selected by click or keyboard, and is skipped by arrow keys. |
| `Tab` | `className`, native `button` props | | |
| `TabPanel` | `value` | `string` (required) | Shown when the tab with the same value is selected. |
| `TabPanel` | `className`, native `div` props | | |

Keyboard:

| Key | Behavior |
| --- | --- |
| Tab | Moves into the tablist on the selected tab, then to the selected panel. |
| ArrowRight | Next enabled tab. Wraps from the last to the first. Selects it. |
| ArrowLeft | Previous enabled tab. Wraps from the first to the last. Selects it. |
| Home | First enabled tab. Selects it. |
| End | Last enabled tab. Selects it. |

Selection follows focus for arrow keys, Home and End. Other keys are ignored.

Controlled and uncontrolled: without `value`, `Tabs` keeps its own selection, starting at `defaultValue`. With `value`, the selection is only what you pass. Activating a tab calls `onValueChange`, and the selection changes once your `value` updates.

## Dialog

Usage:

```tsx
import { useState } from "react";
import { Dialog } from "@acme/ui";

function DeleteFile() {
  const [open, setOpen] = useState(false);
  return (
    <>
      <button onClick={() => setOpen(true)}>Delete</button>
      <Dialog open={open} onOpenChange={setOpen} title="Delete file" description="This cannot be undone.">
        <button onClick={() => setOpen(false)}>Cancel</button>
        <button>Confirm</button>
      </Dialog>
    </>
  );
}
```

Props:

| Prop | Type | Notes |
| --- | --- | --- |
| `open` | `boolean` (required) | Renders nothing when false. |
| `onOpenChange` | `(open: boolean) => void` (required) | Called with `false` on Escape or on a click on the backdrop. |
| `title` | `string` (required) | Rendered as the `h2`, and names the dialog. |
| `description` | `string` | Rendered below the title, and described by the dialog. Omitted when not given. |
| `className`, native `div` props | | Rendered on the dialog element. |

The dialog is rendered into `document.body` through a portal, with `role="dialog"` and `aria-modal="true"`.

Focus: on open, focus moves to the first tabbable element inside, or to the dialog itself if there is none. A child with `autoFocus` keeps focus. Focus is trapped inside: a click outside pulls focus back, and if the focused element is removed, the next Tab moves focus back in. Only the topmost open dialog traps focus. On close, focus returns to the element that had it before opening, if that element is still in the document.

Closing: a click that starts and ends on the backdrop closes the dialog. A press that starts inside the content and ends on the backdrop does not.

Keyboard:

| Key | Behavior |
| --- | --- |
| Tab | Next tabbable element inside the dialog. Wraps from the last to the first. |
| Shift+Tab | Previous tabbable element inside the dialog. Wraps from the first to the last. |
| Escape | Calls `onOpenChange(false)`. Only the innermost open dialog handles it. An Escape that a child already handled (calls `preventDefault`, such as an open Combobox list) does not close the dialog. |

Tabbable elements skip disabled, `tabIndex={-1}` and hidden elements. The set is read on each keypress, so elements added after opening are included.

Controlled: `Dialog` has no internal open state. You own `open`, and `onOpenChange` tells you when the user asks to close.

## Combobox

Usage:

```tsx
import { useState } from "react";
import { Combobox, type ComboboxOption } from "@acme/ui";

const fruits: ComboboxOption[] = [
  { value: "apple", label: "Apple" },
  { value: "banana", label: "Banana", disabled: true },
  { value: "cherry", label: "Cherry" },
];

function FruitPicker() {
  const [value, setValue] = useState<string | null>(null);
  return <Combobox label="Fruit" options={fruits} value={value} onChange={setValue} placeholder="Type a fruit" />;
}
```

Props:

| Prop | Type | Notes |
| --- | --- | --- |
| `label` | `string` (required) | Visible label for the input. Also names the listbox. |
| `options` | `ComboboxOption[]` (required) | `{ value: string; label: string; disabled?: boolean }`. |
| `value` | `string \| null` (required) | The selected option's value. `null`, or a value that matches no option, shows an empty input. |
| `onChange` | `(value: string \| null) => void` (required) | Called when an option is chosen, or with `null` when the user clears the text and leaves. |
| `placeholder` | `string` | Placeholder of the input. |
| `className`, native `input` props | | Rendered on the input. |

Filtering: typing opens the list and shows options whose label contains the text, ignoring case. The text is not trimmed, so `" b"` matches only labels with a space followed by `b`. Whitespace-only or empty text shows all options. The text is matched literally, so characters like `(` or `.*` are not patterns. With no matches the list shows "No results", which is not an option.

Keyboard:

| Key | Behavior |
| --- | --- |
| ArrowDown | Opens the list when closed. When open, moves the active option to the next enabled option. Wraps from the last to the first. |
| ArrowUp | When open, moves the active option to the previous enabled option. Wraps from the first to the last. Does nothing when closed. |
| Enter | With an active option, chooses it, closes the list and shows its label. With no active option while open, does nothing and does not submit the form. Closed: normal form behavior. |
| Escape | Closes the list without calling `onChange`. Reverts the text to the selected label. If the text was cleared, calls `onChange(null)`. |
| Blur (focus leaves the input) | Same as Escape. |

Clicking an enabled option chooses it. Clicking a disabled option does nothing and leaves the list open.

The active option is tracked by value. If the list changes while it is open, the same option stays active when it is still shown; if it is removed, no option is active and Enter does nothing.

Clearing: to set the value to `null`, clear the text and press Escape or move focus out. Whitespace-only text counts as cleared. `onChange(null)` is called only if `value` is not already `null`. Pressing Enter with no active option does not clear the value.

Controlled: `value` and `onChange` are required. The input shows the label of `value` whenever you are not typing, so it follows changes to `value`.

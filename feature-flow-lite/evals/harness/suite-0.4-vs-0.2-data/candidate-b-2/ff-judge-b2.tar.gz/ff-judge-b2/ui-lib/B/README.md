# @acme/ui

Accessible React 19 components: `Tabs`, `Dialog` and `Combobox`. They follow the WAI-ARIA Authoring Practices patterns. There is no CSS and no class names are imposed. Extra HTML props (`className`, `style`, `data-*`) pass through to each part's root element.

## Scripts

```sh
pnpm test       # vitest run (jsdom)
pnpm typecheck  # tsc --noEmit
```

## Tabs

```tsx
import { Tabs, TabList, Tab, TabPanel } from '@acme/ui';

<Tabs defaultValue="profile">
  <TabList aria-label="Account">
    <Tab value="profile">Profile</Tab>
    <Tab value="billing" disabled>Billing</Tab>
    <Tab value="security">Security</Tab>
  </TabList>
  <TabPanel value="profile">Profile form</TabPanel>
  <TabPanel value="billing">Billing details</TabPanel>
  <TabPanel value="security">Security settings</TabPanel>
</Tabs>
```

Controlled:

```tsx
const [tab, setTab] = useState('profile');
<Tabs value={tab} onValueChange={setTab}>…</Tabs>
```

Uncontrolled: pass `defaultValue` (or nothing). Selection changes on its own and `onValueChange` still fires.

### Tabs props

| Name | Type | Default | Description |
| --- | --- | --- | --- |
| `defaultValue` | `string` | first enabled tab | Initially selected tab (uncontrolled). If it matches no tab, or a disabled tab, the first enabled tab is selected. |
| `value` | `string` | — | Selected tab (controlled). The selection only changes when the parent updates this. If it matches no tab, or a disabled tab, the first enabled tab takes the tab stop and `onValueChange` is not called. A matching disabled tab stays selected. |
| `onValueChange` | `(value: string) => void` | — | Called with the new value when the user selects a different enabled tab. Not called when the selected tab is activated again. |

`TabList` requires `aria-label`. `Tab` takes `value: string`, plus `disabled?: boolean`. `TabPanel` takes `value: string`.

### Tabs keyboard

| Key | Action |
| --- | --- |
| `Tab` | Moves into the selected tab (or the first enabled tab when the selection matches no enabled tab), then into its panel. Other tabs are not in the tab order. |
| `ArrowRight` / `ArrowLeft` | Move focus and selection to the next or previous enabled tab. Wraps at the ends and skips disabled tabs. |
| `Home` / `End` | Move focus and selection to the first or last enabled tab. |

Selection follows focus. Disabled tabs cannot be selected by click or keyboard.

## Dialog

```tsx
import { Dialog } from '@acme/ui';

const [open, setOpen] = useState(false);
<button onClick={() => setOpen(true)}>Settings</button>
<Dialog open={open} onOpenChange={setOpen} title="Settings" description="Change your preferences.">
  <button onClick={() => setOpen(false)}>Done</button>
</Dialog>
```

Dialog is controlled only: `open` and `onOpenChange` are required. It renders into a portal on `document.body` while open.

### Dialog props

| Name | Type | Default | Description |
| --- | --- | --- | --- |
| `open` | `boolean` | — | Whether the dialog is shown. Required. |
| `onOpenChange` | `(open: boolean) => void` | — | Called with `false` on Escape or a backdrop click. The dialog stays open until the parent sets `open` to `false`. |
| `title` | `ReactNode` | — | Rendered as an `h2`. Labels the dialog. |
| `description` | `ReactNode` | — | Rendered below the title. Describes the dialog. Omitted when not given. |
| `children` | `ReactNode` | — | Dialog content. |

Focus moves to the first tabbable element when the dialog opens, unless a child already has focus (for example via `autoFocus`). If nothing inside is tabbable, the dialog itself takes focus. When the dialog closes or unmounts, focus returns to the element that had it before opening, if that element is still in the document.

Nested dialogs: only the top-most dialog handles Escape and Tab. Closing an inner dialog returns focus to the element that opened it.

Each dialog renders a backdrop (`data-backdrop`) around the modal element. A click closes the dialog only when the press starts and ends on the backdrop. Extra props (`className`, `style`, `data-*`) go to the `role="dialog"` element, not the backdrop.

### Dialog keyboard

| Key | Action |
| --- | --- |
| `Tab` | Moves to the next tabbable element, wrapping from last to first. Disabled, `tabIndex={-1}`, hidden and inert content is skipped. |
| `Shift+Tab` | Moves to the previous tabbable element, wrapping from first to last. |
| `Escape` | Calls `onOpenChange(false)` for the top-most dialog only. |

## Combobox

```tsx
import { Combobox, type ComboboxOption } from '@acme/ui';

const fruits: ComboboxOption[] = [
  { value: 'apple', label: 'Apple' },
  { value: 'cherry', label: 'Cherry', disabled: true },
];

const [fruit, setFruit] = useState<string | null>(null);
<Combobox label="Fruit" options={fruits} value={fruit} onChange={setFruit} placeholder="Type a fruit" />
```

Combobox is controlled only: `value` and `onChange` are required. The input shows the selected option's label when closed.

### Combobox props

| Name | Type | Default | Description |
| --- | --- | --- | --- |
| `label` | `string` | — | Accessible label for the input. |
| `options` | `ComboboxOption[]` | — | `{ value: string; label: string; disabled?: boolean }`. |
| `value` | `string \| null` | — | Selected option's value. `null`, or a value matching no option, shows an empty input. |
| `onChange` | `(value: string \| null) => void` | — | Called with the chosen option's value. Called with `null` when the selection is cleared (see below). |
| `placeholder` | `string` | — | Placeholder for the input. |

Filtering is a case-insensitive substring match on the label. A "No results" message is shown when nothing matches. When the parent changes `value` while the user is typing, the typed text is discarded and the listbox closes.

Clearing: when the input text is empty and the listbox closes by leaving the input or pressing Enter with no active option, `onChange(null)` is called if a value was selected. Escape never clears the selection. It restores the selected label.

### Combobox keyboard

| Key | Action |
| --- | --- |
| `ArrowDown` | Opens the listbox if closed. When opening, the selected option is active if visible and enabled, otherwise the first enabled option. When open, moves the active option to the next enabled option. Does not wrap. |
| `ArrowUp` | When closed, opens with the last enabled option active. When open, moves the active option to the previous enabled option. Does not wrap. |
| `Alt+ArrowDown` | Opens the listbox without making an option active. |
| `Enter` | With an active option, selects it and closes the listbox. With no active option and empty text, clears the selection. Otherwise does nothing, so a surrounding form can submit. |
| `Escape` | Closes the listbox without calling `onChange` and restores the selected label. Does not close an enclosing dialog while the listbox is open. |
| `Home` / `End` | Move the text cursor, as in any text input. |
| Typing | Opens the listbox and filters. The active option stays active if it is still visible; otherwise nothing is active. |

Clicking an enabled option selects it. Clicking a disabled option does nothing. Leaving the input closes the listbox and restores the selected label.

import * as React from "react";
import { createPortal } from "react-dom";

export type DialogProps = Omit<React.HTMLAttributes<HTMLDivElement>, "title"> & {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  title: React.ReactNode;
  description?: React.ReactNode;
};

type PanelProps = Omit<DialogProps, "open">;

type Layer = {
  // The dialog this one is rendered inside, if any. Portals hide that from the DOM.
  parent: Layer | null;
  dialog: React.RefObject<HTMLDivElement | null>;
};

const DialogLayerContext = React.createContext<Layer | null>(null);

// Open dialogs in registration order. Effects run child first, so a dialog mounted open inside
// another one can register before its parent does.
const openDialogs: Layer[] = [];

// Only the top layer handles Escape and Tab: the latest one with no open dialog inside it.
function topLayer(): Layer | undefined {
  return openDialogs.filter((layer) => !openDialogs.some((other) => other.parent === layer)).pop();
}

const FOCUSABLE = 'a[href], button, input:not([type="hidden"]), select, textarea, [tabindex]';

function focusables(dialog: HTMLElement): HTMLElement[] {
  return Array.from(dialog.querySelectorAll<HTMLElement>(FOCUSABLE)).filter(
    (element) => element.tabIndex >= 0 && !element.matches(":disabled") && !element.closest("[hidden], [inert]"),
  );
}

export function Dialog({ open, ...rest }: DialogProps) {
  if (!open) return null;
  return createPortal(<DialogPanel {...rest} />, document.body);
}

function DialogPanel({ onOpenChange, title, description, children, ...rest }: PanelProps) {
  const titleId = React.useId();
  const descriptionId = React.useId();
  const dialogRef = React.useRef<HTMLDivElement>(null);
  const parent = React.useContext(DialogLayerContext);
  const [layer] = React.useState<Layer>(() => ({ parent, dialog: dialogRef }));
  // Read on mount, before any autoFocus child takes focus, so close can return to the opener.
  const [opener] = React.useState(() => document.activeElement);
  const hasDescription = description !== undefined && description !== null;

  React.useEffect(() => {
    const dialog = dialogRef.current!;
    // A dialog mounted open inside this one has already taken focus.
    const childOpen = openDialogs.some((other) => other.parent === layer);
    if (!childOpen && !dialog.contains(document.activeElement)) {
      (focusables(dialog)[0] ?? dialog).focus();
    }
    return () => {
      // An opener outside the parent dialog (or the body, when mounted open) is not a place to return to
      // while the parent is still open, so return to the parent instead.
      const insideParent = parent === null || (parent.dialog.current?.contains(opener) ?? false);
      const restorable = opener instanceof HTMLElement && opener !== document.body && opener.isConnected && insideParent;
      (restorable ? opener : parent?.dialog.current)?.focus();
    };
  }, [opener, layer, parent]);

  React.useEffect(() => {
    openDialogs.push(layer);
    return () => {
      openDialogs.splice(openDialogs.indexOf(layer), 1);
    };
  }, [layer]);

  React.useEffect(() => {
    const onKeyDown = (event: KeyboardEvent) => {
      const dialog = dialogRef.current!;
      if (topLayer() !== layer) return;
      if (event.key === "Escape") {
        // A child that handled Escape (such as an open Combobox listbox) keeps the dialog open.
        // Marking the event handled stops an outer dialog from also closing on this keypress.
        if (event.defaultPrevented) return;
        event.preventDefault();
        onOpenChange(false);
      } else if (event.key === "Tab") {
        const items = focusables(dialog);
        event.preventDefault();
        if (items.length === 0) {
          dialog.focus();
          return;
        }
        const index = items.indexOf(document.activeElement as HTMLElement);
        const last = items.length - 1;
        const next = event.shiftKey
          ? items[index <= 0 ? last : index - 1]
          : items[index === -1 || index === last ? 0 : index + 1];
        next.focus();
      }
    };
    document.addEventListener("keydown", onKeyDown);
    return () => document.removeEventListener("keydown", onKeyDown);
  }, [layer, onOpenChange]);

  return (
    <DialogLayerContext.Provider value={layer}>
      <div
        data-backdrop=""
        onClick={(event) => {
          if (event.target === event.currentTarget) onOpenChange(false);
        }}
      >
        <div
          {...rest}
          ref={dialogRef}
          role="dialog"
          aria-modal="true"
          aria-labelledby={titleId}
          aria-describedby={hasDescription ? descriptionId : undefined}
          tabIndex={-1}
        >
          <h2 id={titleId}>{title}</h2>
          {hasDescription && <p id={descriptionId}>{description}</p>}
          {children}
        </div>
      </div>
    </DialogLayerContext.Provider>
  );
}

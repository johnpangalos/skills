import * as React from "react";
import { render, screen } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { describe, expect, it, vi } from "vitest";
import { Dialog, Tab, TabList, TabPanel, Tabs } from "../src";

// Save comes before the name input, so the first focusable is Save unless autoFocus is set.
function Harness({ autoFocus = false, description, onOpenChange }: {
  autoFocus?: boolean;
  description?: string;
  onOpenChange?: (open: boolean) => void;
}) {
  const [open, setOpen] = React.useState(false);
  return (
    <>
      <button type="button" onClick={() => setOpen(true)}>
        Open
      </button>
      <Dialog
        open={open}
        onOpenChange={(next) => {
          onOpenChange?.(next);
          setOpen(next);
        }}
        title="Edit profile"
        description={description}
      >
        <button type="button">Save</button>
        <input aria-label="Name" autoFocus={autoFocus} />
      </Dialog>
    </>
  );
}

function Shell({ open, showTrigger = true }: { open: boolean; showTrigger?: boolean }) {
  return (
    <>
      {showTrigger && <button type="button">Trigger</button>}
      <Dialog open={open} onOpenChange={() => {}} title="Shell">
        <input aria-label="Name" autoFocus />
      </Dialog>
    </>
  );
}

function Nested({ onOuter, onInner }: { onOuter: (open: boolean) => void; onInner: (open: boolean) => void }) {
  const [outer, setOuter] = React.useState(true);
  const [inner, setInner] = React.useState(false);
  return (
    <Dialog
      open={outer}
      onOpenChange={(next) => {
        onOuter(next);
        setOuter(next);
      }}
      title="Outer"
    >
      <button type="button" onClick={() => setInner(true)}>
        Open inner
      </button>
      <Dialog
        open={inner}
        onOpenChange={(next) => {
          onInner(next);
          setInner(next);
        }}
        title="Inner"
      >
        <button type="button">Inner action</button>
      </Dialog>
    </Dialog>
  );
}

describe("Dialog", () => {
  it("D1 renders nothing while closed", () => {
    const { container } = render(
      <Dialog open={false} onOpenChange={() => {}} title="Hidden">
        Body
      </Dialog>,
    );
    expect(screen.queryByRole("dialog")).toBeNull();
    expect(document.querySelector("[data-backdrop]")).toBeNull();
    expect(container).toBeEmptyDOMElement();
  });

  it("D1 renders a backdrop and a modal dialog in a portal on document.body", () => {
    const { container } = render(
      <Dialog open onOpenChange={() => {}} title="Edit profile" description="Changes are saved.">
        Body
      </Dialog>,
    );
    const dialog = screen.getByRole("dialog");
    expect(container).not.toContainElement(dialog);
    expect(document.body).toContainElement(dialog);
    expect(dialog.closest("[data-backdrop]")).not.toBeNull();
    expect(dialog).toHaveAttribute("aria-modal", "true");
    expect(document.getElementById(dialog.getAttribute("aria-labelledby") ?? "")).toHaveTextContent("Edit profile");
    expect(dialog).toHaveAccessibleName("Edit profile");
    expect(dialog).toHaveAccessibleDescription("Changes are saved.");
  });

  it("D1 omits aria-describedby when there is no description", () => {
    render(
      <Dialog open onOpenChange={() => {}} title="Notice">
        Body
      </Dialog>,
    );
    expect(screen.getByRole("dialog")).not.toHaveAttribute("aria-describedby");
  });

  it("hostile: a ReactNode title is the accessible name", () => {
    render(
      <Dialog open onOpenChange={() => {}} title={<span>Fancy <em>title</em></span>}>
        Body
      </Dialog>,
    );
    expect(screen.getByRole("dialog")).toHaveAccessibleName("Fancy title");
  });

  it("D2 moves focus to the first focusable element of the content on open", async () => {
    const user = userEvent.setup();
    render(<Harness />);
    await user.click(screen.getByRole("button", { name: "Open" }));
    expect(screen.getByRole("button", { name: "Save" })).toHaveFocus();
  });

  it("D2 honours a child with autoFocus", async () => {
    const user = userEvent.setup();
    render(<Harness autoFocus />);
    await user.click(screen.getByRole("button", { name: "Open" }));
    expect(screen.getByRole("textbox", { name: "Name" })).toHaveFocus();
  });

  it("D2 focuses the dialog itself when it has no focusable content", () => {
    render(
      <Dialog open onOpenChange={() => {}} title="Notice">
        Just text
      </Dialog>,
    );
    const dialog = screen.getByRole("dialog");
    expect(dialog).toHaveAttribute("tabindex", "-1");
    expect(dialog).toHaveFocus();
  });

  it("hostile: a dialog open on mount moves focus into itself", () => {
    render(
      <Dialog open onOpenChange={() => {}} title="Mounted">
        <button type="button">Inside</button>
      </Dialog>,
    );
    expect(screen.getByRole("button", { name: "Inside" })).toHaveFocus();
  });

  it("D3 wraps Tab from the last focusable to the first and Shift+Tab from the first to the last", async () => {
    const user = userEvent.setup();
    render(
      <Dialog open onOpenChange={() => {}} title="Trap">
        <button type="button">First</button>
        <button type="button">Last</button>
      </Dialog>,
    );
    expect(screen.getByRole("button", { name: "First" })).toHaveFocus();
    await user.tab();
    expect(screen.getByRole("button", { name: "Last" })).toHaveFocus();
    await user.tab();
    expect(screen.getByRole("button", { name: "First" })).toHaveFocus();
    await user.tab({ shift: true });
    expect(screen.getByRole("button", { name: "Last" })).toHaveFocus();
  });

  it("D3 skips disabled, hidden and tabIndex=-1 elements", async () => {
    const user = userEvent.setup();
    render(
      <Dialog open onOpenChange={() => {}} title="Skips">
        <button type="button">First</button>
        <button type="button" disabled>
          Disabled
        </button>
        <div hidden>
          <button type="button">Hidden</button>
        </div>
        <button type="button" tabIndex={-1}>
          Negative
        </button>
        <button type="button">Last</button>
      </Dialog>,
    );
    await user.tab();
    expect(screen.getByRole("button", { name: "Last" })).toHaveFocus();
    await user.tab();
    expect(screen.getByRole("button", { name: "First" })).toHaveFocus();
    await user.tab({ shift: true });
    expect(screen.getByRole("button", { name: "Last" })).toHaveFocus();
  });

  it("D3 keeps focus on the dialog when there is nothing focusable to tab to", async () => {
    const user = userEvent.setup();
    render(
      <Dialog open onOpenChange={() => {}} title="Notice">
        Just text
      </Dialog>,
    );
    await user.tab();
    expect(screen.getByRole("dialog")).toHaveFocus();
    await user.tab({ shift: true });
    expect(screen.getByRole("dialog")).toHaveFocus();
  });

  it("D3 includes elements added after the dialog opened", async () => {
    const user = userEvent.setup();
    // The child list keeps the same shape across renders so React does not remount First.
    const grow = (late: boolean) => (
      <Dialog open onOpenChange={() => {}} title="Grow">
        <button type="button">First</button>
        {late && <button type="button">Late</button>}
      </Dialog>
    );
    const { rerender } = render(grow(false));
    rerender(grow(true));
    await user.tab();
    expect(screen.getByRole("button", { name: "Late" })).toHaveFocus();
    await user.tab();
    expect(screen.getByRole("button", { name: "First" })).toHaveFocus();
  });

  it("D4 Escape calls onOpenChange(false)", async () => {
    const user = userEvent.setup();
    const onOpenChange = vi.fn();
    render(
      <Dialog open onOpenChange={onOpenChange} title="Escape">
        <button type="button">Inside</button>
      </Dialog>,
    );
    await user.keyboard("{Escape}");
    expect(onOpenChange).toHaveBeenCalledTimes(1);
    expect(onOpenChange).toHaveBeenCalledWith(false);
  });

  it("D4 clicking the backdrop calls onOpenChange(false)", async () => {
    const user = userEvent.setup();
    const onOpenChange = vi.fn();
    render(
      <Dialog open onOpenChange={onOpenChange} title="Backdrop">
        <button type="button">Inside</button>
      </Dialog>,
    );
    await user.click(document.querySelector("[data-backdrop]") as HTMLElement);
    expect(onOpenChange).toHaveBeenCalledTimes(1);
    expect(onOpenChange).toHaveBeenCalledWith(false);
  });

  it("D4 clicks inside the dialog do not close it", async () => {
    const user = userEvent.setup();
    const onOpenChange = vi.fn();
    render(
      <Dialog open onOpenChange={onOpenChange} title="Inside">
        <button type="button">Inside</button>
      </Dialog>,
    );
    await user.click(screen.getByRole("button", { name: "Inside" }));
    await user.click(screen.getByRole("dialog"));
    expect(onOpenChange).not.toHaveBeenCalled();
    expect(screen.getByRole("dialog")).toBeInTheDocument();
  });

  it("D5 returns focus to the opener on close, even when a child uses autoFocus", async () => {
    const user = userEvent.setup();
    render(<Harness autoFocus />);
    const opener = screen.getByRole("button", { name: "Open" });
    await user.click(opener);
    expect(screen.getByRole("textbox", { name: "Name" })).toHaveFocus();
    await user.keyboard("{Escape}");
    expect(screen.queryByRole("dialog")).toBeNull();
    expect(opener).toHaveFocus();
  });

  it("D5 returns focus to the opener when the dialog unmounts", () => {
    const { rerender } = render(<Shell open={false} />);
    const trigger = screen.getByRole("button", { name: "Trigger" });
    trigger.focus();
    rerender(<Shell open />);
    expect(screen.getByRole("textbox", { name: "Name" })).toHaveFocus();
    rerender(<Shell open={false} />);
    expect(trigger).toHaveFocus();
  });

  it("hostile: closing does not throw when the previously focused element was removed", () => {
    const { rerender } = render(<Shell open={false} />);
    screen.getByRole("button", { name: "Trigger" }).focus();
    rerender(<Shell open showTrigger={false} />);
    expect(() => rerender(<Shell open={false} showTrigger={false} />)).not.toThrow();
    expect(document.activeElement).toBe(document.body);
  });

  it("D6 Escape closes only the topmost dialog and focus returns inside the outer one", async () => {
    const user = userEvent.setup();
    const onOuter = vi.fn();
    const onInner = vi.fn();
    render(<Nested onOuter={onOuter} onInner={onInner} />);
    await user.click(screen.getByRole("button", { name: "Open inner" }));
    expect(screen.getByRole("button", { name: "Inner action" })).toHaveFocus();
    await user.keyboard("{Escape}");
    expect(onInner).toHaveBeenCalledWith(false);
    expect(onOuter).not.toHaveBeenCalled();
    expect(screen.queryByRole("dialog", { name: "Inner" })).toBeNull();
    expect(screen.getByRole("dialog", { name: "Outer" })).toBeInTheDocument();
    expect(screen.getByRole("button", { name: "Open inner" })).toHaveFocus();
    await user.keyboard("{Escape}");
    expect(onOuter).toHaveBeenCalledWith(false);
  });

  it("D3 never tabs into the hidden panels of a Tabs component inside the dialog", async () => {
    const user = userEvent.setup();
    render(
      <Dialog open onOpenChange={() => {}} title="Tabbed">
        <Tabs defaultValue="alpha">
          <TabList aria-label="Sections">
            <Tab value="alpha">Alpha</Tab>
            <Tab value="beta">Beta</Tab>
          </TabList>
          <TabPanel value="alpha">
            <button type="button">Alpha action</button>
          </TabPanel>
          <TabPanel value="beta">
            <button type="button">Beta action</button>
          </TabPanel>
        </Tabs>
      </Dialog>,
    );
    // The selected panel has tabIndex=0 (Tabs T1), so it is one of the stops after the selected tab.
    expect(screen.getByRole("tab", { name: "Alpha" })).toHaveFocus();
    await user.tab();
    expect(screen.getByRole("tabpanel")).toHaveFocus();
    await user.tab();
    expect(screen.getByRole("button", { name: "Alpha action" })).toHaveFocus();
    await user.tab();
    expect(screen.getByRole("tab", { name: "Alpha" })).toHaveFocus();
    await user.tab({ shift: true });
    expect(screen.getByRole("button", { name: "Alpha action" })).toHaveFocus();
    expect(screen.getByRole("button", { name: "Beta action", hidden: true })).not.toHaveFocus();
  });

  it("D6 the focus trap applies to the topmost dialog", async () => {
    const user = userEvent.setup();
    render(<Nested onOuter={() => {}} onInner={() => {}} />);
    await user.click(screen.getByRole("button", { name: "Open inner" }));
    await user.tab();
    expect(screen.getByRole("button", { name: "Inner action" })).toHaveFocus();
    await user.tab({ shift: true });
    expect(screen.getByRole("button", { name: "Inner action" })).toHaveFocus();
  });

  it("D6 nested dialogs open on mount: Escape closes only the inner one", async () => {
    const user = userEvent.setup();
    const onOuter = vi.fn();
    const onInner = vi.fn();
    render(
      <Dialog open title="Outer" onOpenChange={onOuter}>
        <Dialog open title="Inner" onOpenChange={onInner}>
          <button type="button">Inner action</button>
        </Dialog>
      </Dialog>,
    );
    expect(screen.getByRole("button", { name: "Inner action" })).toHaveFocus();
    await user.keyboard("{Escape}");
    expect(onInner).toHaveBeenCalledTimes(1);
    expect(onInner).toHaveBeenCalledWith(false);
    expect(onOuter).not.toHaveBeenCalled();
  });

  it("D6 nested dialogs open on mount: Tab stays inside the inner dialog", async () => {
    const user = userEvent.setup();
    render(
      <Dialog open title="Outer" onOpenChange={() => {}}>
        <button type="button">Outer action</button>
        <Dialog open title="Inner" onOpenChange={() => {}}>
          <button type="button">Inner action</button>
          <button type="button">Inner last</button>
        </Dialog>
      </Dialog>,
    );
    const inner = screen.getByRole("dialog", { name: "Inner" });
    expect(screen.getByRole("button", { name: "Inner action" })).toHaveFocus();
    await user.tab();
    expect(screen.getByRole("button", { name: "Inner last" })).toHaveFocus();
    await user.tab();
    expect(screen.getByRole("button", { name: "Inner action" })).toHaveFocus();
    await user.tab({ shift: true });
    expect(screen.getByRole("button", { name: "Inner last" })).toHaveFocus();
    expect(inner).toContainElement(document.activeElement as HTMLElement);
  });

  it("D6 nested dialogs open on mount: after the inner closes, Escape closes the outer and focus stays inside it", async () => {
    const user = userEvent.setup();
    const onOuter = vi.fn();
    const onInner = vi.fn();
    const Mounted = () => {
      const [inner, setInner] = React.useState(true);
      return (
        <Dialog open title="Outer" onOpenChange={onOuter}>
          <button type="button">Outer action</button>
          <Dialog
            open={inner}
            title="Inner"
            onOpenChange={(next) => {
              onInner(next);
              setInner(next);
            }}
          >
            <button type="button">Inner action</button>
          </Dialog>
        </Dialog>
      );
    };
    render(<Mounted />);
    await user.keyboard("{Escape}");
    expect(onInner).toHaveBeenCalledWith(false);
    expect(screen.queryByRole("dialog", { name: "Inner" })).toBeNull();
    expect(screen.getByRole("dialog", { name: "Outer" })).toContainElement(document.activeElement as HTMLElement);
    await user.keyboard("{Escape}");
    expect(onOuter).toHaveBeenCalledTimes(1);
    expect(onOuter).toHaveBeenCalledWith(false);
  });

  it("D6 a dialog opened later goes above an open dialog", async () => {
    const user = userEvent.setup();
    const onFirst = vi.fn();
    const onSecond = vi.fn();
    const Pair = ({ second }: { second: boolean }) => (
      <>
        <Dialog open title="First" onOpenChange={onFirst}>
          <button type="button">First action</button>
        </Dialog>
        <Dialog open={second} title="Second" onOpenChange={onSecond}>
          <button type="button">Second action</button>
        </Dialog>
      </>
    );
    const { rerender } = render(<Pair second={false} />);
    rerender(<Pair second />);
    expect(screen.getByRole("button", { name: "Second action" })).toHaveFocus();
    await user.keyboard("{Escape}");
    expect(onSecond).toHaveBeenCalledWith(false);
    expect(onFirst).not.toHaveBeenCalled();
  });

  it("D2 skips a hidden input when choosing the first focusable element", async () => {
    const user = userEvent.setup();
    render(
      <Dialog open onOpenChange={() => {}} title="Csrf">
        <input type="hidden" name="csrf" value="token" />
        <button type="button">First</button>
        <button type="button">Last</button>
      </Dialog>,
    );
    expect(screen.getByRole("button", { name: "First" })).toHaveFocus();
    await user.tab();
    expect(screen.getByRole("button", { name: "Last" })).toHaveFocus();
    await user.tab();
    expect(screen.getByRole("button", { name: "First" })).toHaveFocus();
    await user.tab({ shift: true });
    expect(screen.getByRole("button", { name: "Last" })).toHaveFocus();
    expect(document.activeElement).not.toBe(document.body);
  });

  it("D5 a dialog opened in the same click as its parent returns focus inside the parent, not to the trigger", async () => {
    const user = userEvent.setup();
    const Together = () => {
      const [show, setShow] = React.useState(false);
      const [inner, setInner] = React.useState(false);
      return (
        <>
          <button
            type="button"
            onClick={() => {
              setShow(true);
              setInner(true);
            }}
          >
            Go
          </button>
          {show && (
            <Dialog
              open
              title="Outer"
              onOpenChange={() => {
                setInner(false);
                setShow(false);
              }}
            >
              <button type="button">Outer action</button>
              <Dialog open={inner} title="Inner" onOpenChange={() => setInner(false)}>
                <button type="button">Inner action</button>
              </Dialog>
            </Dialog>
          )}
        </>
      );
    };
    render(<Together />);
    await user.click(screen.getByRole("button", { name: "Go" }));
    expect(screen.getByRole("button", { name: "Inner action" })).toHaveFocus();
    await user.keyboard("{Escape}");
    expect(screen.queryByRole("dialog", { name: "Inner" })).toBeNull();
    expect(screen.getByRole("dialog", { name: "Outer" })).toContainElement(document.activeElement as HTMLElement);
    await user.keyboard("{Escape}");
    expect(screen.queryByRole("dialog", { name: "Outer" })).toBeNull();
    expect(screen.getByRole("button", { name: "Go" })).toHaveFocus();
  });
});

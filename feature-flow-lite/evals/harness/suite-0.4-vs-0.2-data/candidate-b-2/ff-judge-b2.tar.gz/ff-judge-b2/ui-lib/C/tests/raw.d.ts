// Vite resolves "?raw" imports to the file's text; this gives them a type for tsc.
declare module "*.md?raw" {
  const text: string;
  export default text;
}

import { useState } from "react";
import { render, screen } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { Combobox } from "../src/Combobox";
import { Dialog } from "../src/Dialog";
import { Tab, TabList, TabPanel, Tabs } from "../src/Tabs";

function Basic({
  open = true,
  description,
  onOpenChange = () => {},
}: {
  open?: boolean;
  description?: string;
  onOpenChange?: (open: boolean) => void;
}) {
  return (
    <Dialog open={open} onOpenChange={onOpenChange} title="Delete file" description={description}>
      <button>Confirm</button>
      <button>Cancel</button>
    </Dialog>
  );
}

function Harness() {
  const [open, setOpen] = useState(false);
  return (
    <>
      <button onClick={() => setOpen(true)}>Open</button>
      <Dialog open={open} onOpenChange={setOpen} title="Settings">
        <input aria-label="Name" autoFocus />
        <button>Save</button>
      </Dialog>
    </>
  );
}

function Nested() {
  const [outer, setOuter] = useState(false);
  const [inner, setInner] = useState(false);
  return (
    <>
      <button onClick={() => setOuter(true)}>Open outer</button>
      <Dialog open={outer} onOpenChange={setOuter} title="Outer">
        <button onClick={() => setInner(true)}>Open inner</button>
        <Dialog open={inner} onOpenChange={setInner} title="Inner">
          <button>Inside</button>
        </Dialog>
      </Dialog>
    </>
  );
}

// The backdrop is the element that wraps the dialog content.
const backdropOf = () => screen.getByRole("dialog").parentElement as HTMLElement;

describe("Dialog", () => {
  it("D1 renders nothing when closed", () => {
    render(<Basic open={false} />);
    expect(screen.queryByRole("dialog")).toBeNull();
    expect(screen.queryByText("Delete file")).toBeNull();
  });

  it("D1 renders a modal dialog in document.body labelled by its title", () => {
    const { container } = render(<Basic />);
    const dialog = screen.getByRole("dialog", { name: "Delete file" });
    expect(dialog).toHaveAttribute("aria-modal", "true");
    expect(container.contains(dialog)).toBe(false);
    expect(dialog.getAttribute("aria-labelledby")).toBe(screen.getByRole("heading", { name: "Delete file" }).id);
  });

  it("D1 links aria-describedby only when a description is given", () => {
    const { unmount } = render(<Basic description="This cannot be undone." />);
    const described = screen.getByRole("dialog");
    expect(described.getAttribute("aria-describedby")).toBe(screen.getByText("This cannot be undone.").id);
    unmount();
    render(<Basic />);
    expect(screen.getByRole("dialog")).not.toHaveAttribute("aria-describedby");
  });

  it("D2 focuses the first tabbable element on open", () => {
    render(<Basic />);
    expect(screen.getByRole("button", { name: "Confirm" })).toHaveFocus();
  });

  it("D2 focuses the dialog container when it has no tabbable children", () => {
    render(
      <Dialog open title="Notice" onOpenChange={vi.fn()}>
        <p>Saved.</p>
      </Dialog>,
    );
    expect(screen.getByRole("dialog")).toHaveFocus();
    expect(screen.getByRole("dialog")).toHaveAttribute("tabindex", "-1");
  });

  it("D2 keeps focus on a child with autoFocus", () => {
    render(
      <Dialog open title="Rename" onOpenChange={vi.fn()}>
        <button>First</button>
        <input aria-label="Name" autoFocus />
      </Dialog>,
    );
    expect(screen.getByRole("textbox", { name: "Name" })).toHaveFocus();
  });

  it("D3 Tab wraps from last to first and Shift+Tab from first to last", async () => {
    const user = userEvent.setup();
    render(<Basic />);
    expect(screen.getByRole("button", { name: "Confirm" })).toHaveFocus();
    await user.tab();
    expect(screen.getByRole("button", { name: "Cancel" })).toHaveFocus();
    await user.tab();
    expect(screen.getByRole("button", { name: "Confirm" })).toHaveFocus();
    await user.tab({ shift: true });
    expect(screen.getByRole("button", { name: "Cancel" })).toHaveFocus();
  });

  it("D3 skips disabled, tabIndex=-1 and hidden elements", async () => {
    const user = userEvent.setup();
    render(
      <Dialog open title="Trap" onOpenChange={vi.fn()}>
        <button>One</button>
        <button disabled>Off</button>
        <button tabIndex={-1}>Skip</button>
        <button hidden>Gone</button>
        <button>Two</button>
      </Dialog>,
    );
    expect(screen.getByRole("button", { name: "One" })).toHaveFocus();
    await user.tab();
    expect(screen.getByRole("button", { name: "Two" })).toHaveFocus();
    await user.tab();
    expect(screen.getByRole("button", { name: "One" })).toHaveFocus();
  });

  it("D3 with no tabbable children, Tab keeps focus on the dialog", async () => {
    const user = userEvent.setup();
    render(
      <Dialog open title="Notice" onOpenChange={vi.fn()}>
        <p>Saved.</p>
      </Dialog>,
    );
    await user.tab();
    expect(screen.getByRole("dialog")).toHaveFocus();
    await user.tab({ shift: true });
    expect(screen.getByRole("dialog")).toHaveFocus();
  });

  it("D3 computes the tabbable set at keypress time", async () => {
    const user = userEvent.setup();
    function Items({ extra }: { extra: boolean }) {
      return (
        <Dialog open title="Items" onOpenChange={vi.fn()}>
          <button>One</button>
          {extra && <button>Late</button>}
        </Dialog>
      );
    }
    const { rerender } = render(<Items extra={false} />);
    expect(screen.getByRole("button", { name: "One" })).toHaveFocus();
    rerender(<Items extra />);
    await user.tab();
    expect(screen.getByRole("button", { name: "Late" })).toHaveFocus();
  });

  it("D4 Escape calls onOpenChange(false)", async () => {
    const user = userEvent.setup();
    const onOpenChange = vi.fn();
    render(<Basic onOpenChange={onOpenChange} />);
    await user.keyboard("{Escape}");
    expect(onOpenChange).toHaveBeenCalledTimes(1);
    expect(onOpenChange).toHaveBeenCalledWith(false);
  });

  it("D4 clicking the backdrop calls onOpenChange(false)", async () => {
    const user = userEvent.setup();
    const onOpenChange = vi.fn();
    render(<Basic onOpenChange={onOpenChange} />);
    await user.click(backdropOf());
    expect(onOpenChange).toHaveBeenCalledTimes(1);
    expect(onOpenChange).toHaveBeenCalledWith(false);
  });

  it("D4 clicking inside the content does not close", async () => {
    const user = userEvent.setup();
    const onOpenChange = vi.fn();
    render(<Basic onOpenChange={onOpenChange} />);
    await user.click(screen.getByText("Delete file"));
    await user.click(screen.getByRole("button", { name: "Cancel" }));
    expect(onOpenChange).not.toHaveBeenCalled();
  });

  it("D4 a press that starts inside and ends on the backdrop does not close", async () => {
    const user = userEvent.setup();
    const onOpenChange = vi.fn();
    render(<Basic onOpenChange={onOpenChange} />);
    await user.pointer([
      { keys: "[MouseLeft>]", target: screen.getByText("Delete file") },
      { target: backdropOf() },
      { keys: "[/MouseLeft]", target: backdropOf() },
    ]);
    expect(onOpenChange).not.toHaveBeenCalled();
  });

  it("D5 closing returns focus to the element focused before opening, even with autoFocus inside", async () => {
    const user = userEvent.setup();
    render(<Harness />);
    const open = screen.getByRole("button", { name: "Open" });
    await user.click(open);
    expect(screen.getByRole("textbox", { name: "Name" })).toHaveFocus();
    await user.keyboard("{Escape}");
    expect(screen.queryByRole("dialog")).toBeNull();
    expect(open).toHaveFocus();
  });

  it("D5 unmounting while open returns focus to the previous element", () => {
    const ui = (show: boolean) => (
      <>
        <button>Trigger</button>
        {show && (
          <Dialog open title="Notice" onOpenChange={vi.fn()}>
            <button>Inside</button>
          </Dialog>
        )}
      </>
    );
    const { rerender } = render(ui(false));
    screen.getByRole("button", { name: "Trigger" }).focus();
    rerender(ui(true));
    expect(screen.getByRole("button", { name: "Inside" })).toHaveFocus();
    rerender(ui(false));
    expect(screen.getByRole("button", { name: "Trigger" })).toHaveFocus();
  });

  it("D5 hostile: open at mount with no prior focused element does not throw", () => {
    const { rerender } = render(<Basic />);
    expect(() => rerender(<Basic open={false} />)).not.toThrow();
    expect(document.activeElement).toBe(document.body);
  });

  it("D5 hostile: trigger removed while open does not throw on close", () => {
    const ui = (showTrigger: boolean, open: boolean) => (
      <>
        {showTrigger && <button>Trigger</button>}
        <Dialog open={open} title="Notice" onOpenChange={vi.fn()}>
          <button>Inside</button>
        </Dialog>
      </>
    );
    const { rerender } = render(ui(true, false));
    screen.getByRole("button", { name: "Trigger" }).focus();
    rerender(ui(true, true));
    rerender(ui(false, true));
    expect(() => rerender(ui(false, false))).not.toThrow();
    expect(document.activeElement).toBe(document.body);
  });

  it("D6 Escape closes only the top dialog, and focus returns to the inner trigger", async () => {
    const user = userEvent.setup();
    render(<Nested />);
    await user.click(screen.getByRole("button", { name: "Open outer" }));
    await user.click(screen.getByRole("button", { name: "Open inner" }));
    expect(screen.getAllByRole("dialog")).toHaveLength(2);
    expect(screen.getByRole("button", { name: "Inside" })).toHaveFocus();
    await user.tab();
    expect(screen.getByRole("button", { name: "Inside" })).toHaveFocus();
    await user.keyboard("{Escape}");
    expect(screen.queryByRole("dialog", { name: "Inner" })).toBeNull();
    expect(screen.getByRole("dialog", { name: "Outer" })).toBeInTheDocument();
    expect(screen.getByRole("button", { name: "Open inner" })).toHaveFocus();
    await user.keyboard("{Escape}");
    expect(screen.queryByRole("dialog")).toBeNull();
    expect(screen.getByRole("button", { name: "Open outer" })).toHaveFocus();
  });

  it("Escape with the combobox list open closes the list, not the dialog", async () => {
    const user = userEvent.setup();
    function App() {
      const [open, setOpen] = useState(true);
      const [v, setV] = useState<string | null>(null);
      return (
        <Dialog open={open} onOpenChange={setOpen} title="T">
          <Combobox label="Fruit" options={[{ value: "a", label: "Apple" }]} value={v} onChange={setV} />
        </Dialog>
      );
    }
    render(<App />);
    const input = screen.getByRole("combobox");
    await user.click(input);
    await user.keyboard("A");
    await user.keyboard("{Escape}");
    expect(screen.queryByRole("dialog")).not.toBeNull();
    expect(input).toHaveAttribute("aria-expanded", "false");
    await user.keyboard("{Escape}");
    expect(screen.queryByRole("dialog")).toBeNull();
  });

  it("a consumer onKeyDown on Dialog runs, and Escape still closes", async () => {
    const user = userEvent.setup();
    const onKeyDown = vi.fn();
    const onOpenChange = vi.fn();
    render(
      <Dialog open title="Notice" onOpenChange={onOpenChange} onKeyDown={onKeyDown}>
        <button>Inside</button>
      </Dialog>,
    );
    await user.keyboard("{Escape}");
    expect(onKeyDown).toHaveBeenCalledWith(expect.objectContaining({ key: "Escape" }));
    expect(onOpenChange).toHaveBeenCalledWith(false);
  });

  it("consumer props cannot override the dialog's role or aria-modal", () => {
    render(
      <Dialog open title="Notice" onOpenChange={vi.fn()} role="alertdialog" aria-modal="false">
        <button>Inside</button>
      </Dialog>,
    );
    expect(screen.getByRole("dialog")).toHaveAttribute("aria-modal", "true");
  });

  it("Tab inside a trap never reaches the content of a hidden tab panel", async () => {
    const user = userEvent.setup();
    render(
      <Dialog open title="Account" onOpenChange={vi.fn()}>
        <Tabs defaultValue="a">
          <TabList aria-label="Sections">
            <Tab value="a">A</Tab>
            <Tab value="b">B</Tab>
          </TabList>
          <TabPanel value="a">
            <button>In A</button>
          </TabPanel>
          <TabPanel value="b">
            <button>Hidden B</button>
          </TabPanel>
        </Tabs>
      </Dialog>,
    );
    const hiddenButton = screen.getByText("Hidden B");
    for (let press = 0; press < 6; press++) {
      await user.tab();
      expect(document.activeElement).not.toBe(hiddenButton);
    }
  });

  it("D3 keeps Tab inside when the focused element is removed", async () => {
    const user = userEvent.setup();
    function Remove() {
      const [items, setItems] = useState(["remove"]);
      return (
        <>
          <button>outside</button>
          <Dialog open title="L" onOpenChange={vi.fn()}>
            {items.includes("remove") && <button onClick={() => setItems([])}>remove</button>}
            <button>keep</button>
          </Dialog>
        </>
      );
    }
    render(<Remove />);
    await user.click(screen.getByRole("button", { name: "remove" }));
    await user.tab();
    expect(screen.getByRole("button", { name: "keep" })).toHaveFocus();
    await user.tab();
    expect(screen.getByRole("button", { name: "keep" })).toHaveFocus();
  });

  it("D3 a click on an outside button pulls focus back into the dialog", async () => {
    const user = userEvent.setup();
    render(
      <>
        <button>Outside</button>
        <Basic />
      </>,
    );
    await user.click(screen.getByRole("button", { name: "Outside" }));
    expect(screen.getByRole("button", { name: "Confirm" })).toHaveFocus();
  });

  it("D3 Tab with focus on body moves focus into the open dialog", async () => {
    const user = userEvent.setup();
    render(
      <>
        <button>Outside</button>
        <Basic />
      </>,
    );
    (document.activeElement as HTMLElement).blur();
    expect(document.activeElement).toBe(document.body);
    await user.tab();
    expect(screen.getByRole("button", { name: "Confirm" })).toHaveFocus();
  });

  it("D6 the outer dialog does not pull focus away from an open inner dialog", async () => {
    const user = userEvent.setup();
    render(<Nested />);
    await user.click(screen.getByRole("button", { name: "Open outer" }));
    await user.click(screen.getByRole("button", { name: "Open inner" }));
    expect(screen.getByRole("button", { name: "Inside" })).toHaveFocus();
    await user.click(screen.getByRole("button", { name: "Open inner" }));
    expect(screen.getByRole("button", { name: "Inside" })).toHaveFocus();
  });

  it("D6 Tab with focus on body in nested dialogs moves focus into the top dialog", async () => {
    const user = userEvent.setup();
    render(<Nested />);
    await user.click(screen.getByRole("button", { name: "Open outer" }));
    await user.click(screen.getByRole("button", { name: "Open inner" }));
    (document.activeElement as HTMLElement).blur();
    await user.tab();
    expect(screen.getByRole("button", { name: "Inside" })).toHaveFocus();
  });
});

import {
  createContext,
  useContext,
  useId,
  useLayoutEffect,
  useReducer,
  useRef,
  useState,
  type ComponentPropsWithoutRef,
  type KeyboardEvent,
  type RefObject,
} from "react";

type TabsContextValue = {
  baseId: string;
  current: string | undefined;
  stop: string | null;
  listRef: RefObject<HTMLDivElement | null>;
  select: (value: string) => void;
  refresh: () => void;
};

const TabsContext = createContext<TabsContextValue | null>(null);

function useTabsContext(): TabsContextValue {
  const context = useContext(TabsContext);
  if (!context) throw new Error("Tab, TabList and TabPanel must be rendered inside Tabs");
  return context;
}

const tabId = (baseId: string, value: string) => `${baseId}-tab-${encodeURIComponent(value)}`;
const panelId = (baseId: string, value: string) => `${baseId}-panel-${encodeURIComponent(value)}`;

// Enabled tabs of one tablist, in DOM order. Read from the DOM so tabs added or removed after mount are included.
function enabledTabs(list: HTMLElement | null): HTMLButtonElement[] {
  if (!list) return [];
  return Array.from(list.querySelectorAll<HTMLButtonElement>('[role="tab"]')).filter(
    (tab) => tab.closest('[role="tablist"]') === list && !tab.disabled,
  );
}

export type TabsProps = Omit<ComponentPropsWithoutRef<"div">, "defaultValue"> & {
  defaultValue?: string;
  value?: string;
  onValueChange?: (value: string) => void;
};

export function Tabs({ defaultValue, value, onValueChange, className, children, ...rest }: TabsProps) {
  const baseId = useId();
  const listRef = useRef<HTMLDivElement>(null);
  const [internal, setInternal] = useState(defaultValue);
  const [, refresh] = useReducer((count: number) => count + 1, 0);
  const [stop, setStop] = useState<string | null>(null);
  const isControlled = value !== undefined;
  const current = isControlled ? value : internal;

  // After every render: an uncontrolled Tabs without defaultValue selects the first enabled tab, and the
  // tab stop (the one tab with tabIndex 0) is the selected tab if it is enabled, otherwise the first enabled tab.
  useLayoutEffect(() => {
    const enabled = enabledTabs(listRef.current);
    const firstValue = enabled[0]?.dataset.value;
    if (!isControlled && internal === undefined) setInternal(firstValue);
    const selected = enabled.find((tab) => tab.dataset.value === current);
    setStop((selected ?? enabled[0])?.dataset.value ?? null);
  });

  const select = (next: string) => {
    if (next === current) return;
    if (!isControlled) setInternal(next);
    onValueChange?.(next);
  };

  return (
    <TabsContext.Provider value={{ baseId, current, stop, listRef, select, refresh }}>
      <div className={className} {...rest}>
        {children}
      </div>
    </TabsContext.Provider>
  );
}

export type TabListProps = ComponentPropsWithoutRef<"div"> & { "aria-label": string };

export function TabList({ className, ...rest }: TabListProps) {
  const { listRef } = useTabsContext();
  return <div className={className} {...rest} role="tablist" ref={listRef} />;
}

export type TabProps = Omit<ComponentPropsWithoutRef<"button">, "value"> & {
  value: string;
};

export function Tab({
  value,
  disabled,
  className,
  onClick,
  onKeyDown: onKeyDownProp,
  children,
  ...rest
}: TabProps) {
  const { baseId, current, stop, listRef, select, refresh } = useTabsContext();

  // Tell Tabs the tab set changed (mount, disabled change, unmount) so it recomputes the tab stop.
  useLayoutEffect(() => {
    refresh();
    return refresh;
  }, [disabled, refresh]);

  const onKeyDown = (event: KeyboardEvent<HTMLButtonElement>) => {
    onKeyDownProp?.(event);
    if (event.defaultPrevented) return;
    const tabs = enabledTabs(listRef.current);
    const index = tabs.indexOf(event.currentTarget);
    const last = tabs.length - 1;
    let next: number;
    switch (event.key) {
      case "ArrowRight":
        next = index >= last ? 0 : index + 1;
        break;
      case "ArrowLeft":
        next = index <= 0 ? last : index - 1;
        break;
      case "Home":
        next = 0;
        break;
      case "End":
        next = last;
        break;
      default:
        return;
    }
    event.preventDefault();
    const target = tabs[next];
    if (!target) return;
    target.focus();
    select(target.dataset.value ?? "");
  };

  return (
    <button
      className={className}
      {...rest}
      type="button"
      role="tab"
      id={tabId(baseId, value)}
      aria-controls={panelId(baseId, value)}
      aria-selected={current === value}
      data-value={value}
      tabIndex={stop === value ? 0 : -1}
      disabled={disabled}
      onClick={(event) => {
        onClick?.(event);
        if (!event.defaultPrevented) select(value);
      }}
      onKeyDown={onKeyDown}
    >
      {children}
    </button>
  );
}

export type TabPanelProps = ComponentPropsWithoutRef<"div"> & { value: string };

export function TabPanel({ value, className, ...rest }: TabPanelProps) {
  const { baseId, current } = useTabsContext();
  return (
    <div
      className={className}
      {...rest}
      role="tabpanel"
      id={panelId(baseId, value)}
      aria-labelledby={tabId(baseId, value)}
      tabIndex={0}
      hidden={current !== value}
    />
  );
}

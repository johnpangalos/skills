import { fireEvent, render, screen } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { Tab, TabList, TabPanel, Tabs } from "../src/Tabs";

function Basic(props: { defaultValue?: string; value?: string; onValueChange?: (value: string) => void }) {
  return (
    <Tabs {...props}>
      <TabList aria-label="Sections">
        <Tab value="a">A</Tab>
        <Tab value="b">B</Tab>
        <Tab value="c" disabled>
          C
        </Tab>
        <Tab value="d">D</Tab>
      </TabList>
      <TabPanel value="a">Panel A</TabPanel>
      <TabPanel value="b">Panel B</TabPanel>
      <TabPanel value="c">Panel C</TabPanel>
      <TabPanel value="d">Panel D</TabPanel>
    </Tabs>
  );
}

function Dynamic({ extra }: { extra: boolean }) {
  return (
    <Tabs defaultValue="b">
      <TabList aria-label="Sections">
        <Tab value="a">A</Tab>
        <Tab value="b">B</Tab>
        {extra && <Tab value="x">X</Tab>}
        <Tab value="d">D</Tab>
      </TabList>
      <TabPanel value="b">Panel B</TabPanel>
    </Tabs>
  );
}

const tab = (name: string) => screen.getByRole("tab", { name });

describe("Tabs", () => {
  it("T1 uncontrolled starts at defaultValue", () => {
    render(<Basic defaultValue="b" />);
    expect(tab("B")).toHaveAttribute("aria-selected", "true");
    expect(tab("A")).toHaveAttribute("aria-selected", "false");
  });

  it("T1 uncontrolled without defaultValue selects the first non-disabled tab", () => {
    render(
      <Tabs>
        <TabList aria-label="Sections">
          <Tab value="a" disabled>
            A
          </Tab>
          <Tab value="b">B</Tab>
        </TabList>
        <TabPanel value="b">Panel B</TabPanel>
      </Tabs>,
    );
    expect(tab("B")).toHaveAttribute("aria-selected", "true");
  });

  it("T1 uncontrolled click selects the tab and fires onValueChange once", async () => {
    const user = userEvent.setup();
    const onValueChange = vi.fn();
    render(<Basic onValueChange={onValueChange} />);
    await user.click(tab("B"));
    expect(tab("B")).toHaveAttribute("aria-selected", "true");
    expect(onValueChange).toHaveBeenCalledTimes(1);
    expect(onValueChange).toHaveBeenCalledWith("b");
  });

  it("T1 controlled keeps the selection until the parent updates value", async () => {
    const user = userEvent.setup();
    const onValueChange = vi.fn();
    const { rerender } = render(<Basic value="a" onValueChange={onValueChange} />);
    await user.click(tab("B"));
    expect(onValueChange).toHaveBeenCalledWith("b");
    expect(tab("A")).toHaveAttribute("aria-selected", "true");
    expect(tab("B")).toHaveAttribute("aria-selected", "false");
    rerender(<Basic value="b" onValueChange={onValueChange} />);
    expect(tab("B")).toHaveAttribute("aria-selected", "true");
  });

  it("T1 does not fire onValueChange when the selected tab is re-activated", async () => {
    const user = userEvent.setup();
    const onValueChange = vi.fn();
    render(<Basic defaultValue="a" onValueChange={onValueChange} />);
    await user.click(tab("A"));
    expect(onValueChange).not.toHaveBeenCalled();
  });

  it("T2 renders tablist, tabs and panels with ARIA wiring", () => {
    render(<Basic defaultValue="a" />);
    expect(screen.getByRole("tablist", { name: "Sections" })).not.toHaveAttribute("aria-orientation");
    const a = tab("A");
    expect(a.tagName).toBe("BUTTON");
    expect(a).toHaveAttribute("type", "button");
    const panelA = screen.getByText("Panel A");
    expect(panelA).toHaveAttribute("role", "tabpanel");
    expect(a).toHaveAttribute("aria-controls", panelA.id);
    expect(panelA).toHaveAttribute("aria-labelledby", a.id);
    expect(panelA).toHaveAttribute("tabindex", "0");
    expect(panelA).not.toHaveAttribute("hidden");
    expect(screen.getByText("Panel B")).toHaveAttribute("hidden");
  });

  it("T2 ids are unique across two Tabs instances on one page", () => {
    render(
      <>
        <Basic />
        <Basic />
      </>,
    );
    const ids = Array.from(document.querySelectorAll("[id]")).map((el) => el.id);
    expect(ids).toHaveLength(16);
    expect(new Set(ids).size).toBe(16);
  });

  it("T3 only the selected tab is in the tab order", () => {
    render(<Basic defaultValue="b" />);
    expect(tab("B")).toHaveAttribute("tabindex", "0");
    for (const name of ["A", "C", "D"]) {
      expect(tab(name)).toHaveAttribute("tabindex", "-1");
    }
  });

  it("T3 Tab lands on the selected tab, then moves to the selected panel", async () => {
    const user = userEvent.setup();
    render(<Basic defaultValue="b" />);
    await user.tab();
    expect(tab("B")).toHaveFocus();
    await user.tab();
    expect(screen.getByText("Panel B")).toHaveFocus();
  });

  it("T4 ArrowRight and ArrowLeft move focus and selection, wrapping and skipping disabled tabs", async () => {
    const user = userEvent.setup();
    const onValueChange = vi.fn();
    render(<Basic defaultValue="b" onValueChange={onValueChange} />);
    await user.tab();
    await user.keyboard("{ArrowRight}");
    expect(tab("D")).toHaveFocus();
    expect(tab("D")).toHaveAttribute("aria-selected", "true");
    expect(onValueChange).toHaveBeenLastCalledWith("d");
    await user.keyboard("{ArrowRight}");
    expect(tab("A")).toHaveFocus();
    await user.keyboard("{ArrowLeft}");
    expect(tab("D")).toHaveFocus();
    await user.keyboard("{ArrowLeft}");
    expect(tab("B")).toHaveFocus();
  });

  it("T4 Home and End move to the first and last enabled tab", async () => {
    const user = userEvent.setup();
    render(<Basic defaultValue="b" />);
    await user.tab();
    await user.keyboard("{End}");
    expect(tab("D")).toHaveFocus();
    await user.keyboard("{Home}");
    expect(tab("A")).toHaveFocus();
  });

  it("T4 ignores other keys, and arrows pressed on a panel do nothing", async () => {
    const user = userEvent.setup();
    const onValueChange = vi.fn();
    render(<Basic defaultValue="a" onValueChange={onValueChange} />);
    await user.tab();
    await user.keyboard("x");
    expect(tab("A")).toHaveFocus();
    expect(onValueChange).not.toHaveBeenCalled();
    expect(fireEvent.keyDown(tab("A"), { key: "x" })).toBe(true);
    expect(fireEvent.keyDown(tab("A"), { key: "ArrowRight" })).toBe(false);
  });

  it("T4 arrow keys pressed on a panel are not handled", async () => {
    const user = userEvent.setup();
    render(<Basic defaultValue="a" />);
    screen.getByText("Panel A").focus();
    await user.keyboard("{ArrowRight}");
    expect(screen.getByText("Panel A")).toHaveFocus();
    expect(tab("A")).toHaveAttribute("aria-selected", "true");
  });

  it("T5 a disabled tab cannot be selected by click or keyboard", async () => {
    const user = userEvent.setup();
    const onValueChange = vi.fn();
    render(<Basic defaultValue="a" onValueChange={onValueChange} />);
    await user.click(tab("C"));
    expect(tab("C")).toHaveAttribute("aria-selected", "false");
    expect(onValueChange).not.toHaveBeenCalled();
    await user.tab();
    await user.keyboard("{ArrowRight}");
    expect(tab("B")).toHaveFocus();
    expect(onValueChange).toHaveBeenCalledTimes(1);
  });

  it("T5 hostile: with one enabled tab, arrows and Home/End stay on it without throwing", async () => {
    const user = userEvent.setup();
    render(
      <Tabs defaultValue="b">
        <TabList aria-label="Sections">
          <Tab value="a" disabled>
            A
          </Tab>
          <Tab value="b">B</Tab>
          <Tab value="c" disabled>
            C
          </Tab>
        </TabList>
        <TabPanel value="b">Panel B</TabPanel>
      </Tabs>,
    );
    await user.tab();
    await user.keyboard("{ArrowRight}{ArrowLeft}{Home}{End}");
    expect(tab("B")).toHaveFocus();
  });

  it("T5 hostile: selected last tab, ArrowRight wraps to the first non-disabled tab", async () => {
    const user = userEvent.setup();
    render(<Basic defaultValue="d" />);
    await user.tab();
    expect(tab("D")).toHaveFocus();
    await user.keyboard("{ArrowRight}");
    expect(tab("A")).toHaveFocus();
  });

  it("T5 hostile: defaultValue naming a disabled tab keeps exactly one tab stop", () => {
    render(<Basic defaultValue="c" />);
    const stops = screen.getAllByRole("tab").filter((el) => el.getAttribute("tabindex") === "0");
    expect(stops).toEqual([tab("A")]);
  });

  it("T5 hostile: defaultValue naming a nonexistent tab keeps exactly one tab stop", () => {
    render(<Basic defaultValue="zzz" />);
    const stops = screen.getAllByRole("tab").filter((el) => el.getAttribute("tabindex") === "0");
    expect(stops).toEqual([tab("A")]);
  });

  it("T5 hostile: a tab added after mount is reached in DOM order", async () => {
    const user = userEvent.setup();
    const { rerender } = render(<Dynamic extra={false} />);
    await user.tab();
    expect(tab("B")).toHaveFocus();
    rerender(<Dynamic extra />);
    await user.keyboard("{ArrowRight}");
    expect(tab("X")).toHaveFocus();
  });

  it("T5 hostile: a tab removed after mount is skipped", async () => {
    const user = userEvent.setup();
    const { rerender } = render(<Dynamic extra />);
    await user.tab();
    expect(tab("B")).toHaveFocus();
    rerender(<Dynamic extra={false} />);
    await user.keyboard("{ArrowRight}");
    expect(tab("D")).toHaveFocus();
  });

  it("a consumer onClick on Tab runs, and selection still changes", async () => {
    const user = userEvent.setup();
    const onClick = vi.fn();
    render(
      <Tabs defaultValue="a">
        <TabList aria-label="Sections">
          <Tab value="a">A</Tab>
          <Tab value="b" onClick={onClick}>
            B
          </Tab>
        </TabList>
        <TabPanel value="b">Panel B</TabPanel>
      </Tabs>,
    );
    await user.click(tab("B"));
    expect(onClick).toHaveBeenCalledTimes(1);
    expect(tab("B")).toHaveAttribute("aria-selected", "true");
  });

  it("a consumer onKeyDown on Tab runs, and arrow keys still move focus", async () => {
    const user = userEvent.setup();
    const onKeyDown = vi.fn();
    render(
      <Tabs defaultValue="a">
        <TabList aria-label="Sections">
          <Tab value="a" onKeyDown={onKeyDown}>
            A
          </Tab>
          <Tab value="b">B</Tab>
        </TabList>
        <TabPanel value="a">Panel A</TabPanel>
        <TabPanel value="b">Panel B</TabPanel>
      </Tabs>,
    );
    await user.tab();
    await user.keyboard("{ArrowRight}");
    expect(onKeyDown).toHaveBeenCalledWith(expect.objectContaining({ key: "ArrowRight" }));
    expect(tab("B")).toHaveFocus();
  });

  it("a consumer onKeyDown that calls preventDefault skips the built-in arrow handling", async () => {
    const user = userEvent.setup();
    const onValueChange = vi.fn();
    render(
      <Tabs defaultValue="a" onValueChange={onValueChange}>
        <TabList aria-label="Sections">
          <Tab value="a" onKeyDown={(event) => event.preventDefault()}>
            A
          </Tab>
          <Tab value="b">B</Tab>
        </TabList>
        <TabPanel value="a">Panel A</TabPanel>
        <TabPanel value="b">Panel B</TabPanel>
      </Tabs>,
    );
    await user.tab();
    await user.keyboard("{ArrowRight}");
    expect(tab("A")).toHaveFocus();
    expect(onValueChange).not.toHaveBeenCalled();
  });

  it("consumer props cannot override a tab's role, id, selection, tab stop, type or panel link", () => {
    render(
      <Tabs defaultValue="a">
        <TabList aria-label="Sections">
          <Tab value="a">A</Tab>
          <Tab value="b" role="link" id="custom" aria-selected aria-controls="other" tabIndex={3} type="submit">
            B
          </Tab>
        </TabList>
        <TabPanel value="a">Panel A</TabPanel>
        <TabPanel value="b">Panel B</TabPanel>
      </Tabs>,
    );
    const b = screen.getByText("B");
    expect(b).toHaveAttribute("role", "tab");
    expect(b.id).not.toBe("custom");
    expect(b).toHaveAttribute("aria-selected", "false");
    expect(b).toHaveAttribute("tabindex", "-1");
    expect(b).toHaveAttribute("type", "button");
    expect(b).toHaveAttribute("aria-controls", screen.getByText("Panel B").id);
  });

  it("consumer props cannot override the tablist's role or a panel's role, tab stop or labelling", () => {
    render(
      <Tabs defaultValue="a">
        <TabList aria-label="Sections" role="group">
          <Tab value="a">A</Tab>
        </TabList>
        <TabPanel value="a" role="region" tabIndex={-1} aria-labelledby="other">
          Panel A
        </TabPanel>
      </Tabs>,
    );
    expect(screen.getByRole("tablist", { name: "Sections" })).toBeInTheDocument();
    const panel = screen.getByText("Panel A");
    expect(panel).toHaveAttribute("role", "tabpanel");
    expect(panel).toHaveAttribute("tabindex", "0");
    expect(panel).toHaveAttribute("aria-labelledby", tab("A").id);
  });
});

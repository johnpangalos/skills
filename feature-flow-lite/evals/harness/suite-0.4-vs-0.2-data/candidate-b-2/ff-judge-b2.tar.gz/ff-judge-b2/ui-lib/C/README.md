# @acme/ui

Accessible React components. No CSS is shipped: every component accepts `className` and passes other native props to its root element, so you bring your own styles.

Requires React 19. No runtime dependencies.

## Running

```sh
pnpm install
pnpm test        # Vitest with jsdom
pnpm typecheck   # tsc --noEmit
```

## Tabs

A tab set following the WAI-ARIA Tabs pattern. Compose `Tabs`, `TabList`, `Tab` and `TabPanel`.

### Tabs

| Prop            | Type                       | Notes                                                                  |
| --------------- | -------------------------- | ---------------------------------------------------------------------- |
| `defaultValue`  | `string`                   | Initially selected tab. Without it the first enabled tab is selected. |
| `value`         | `string`                   | Controlled selection. The selection changes only when this changes.   |
| `onValueChange` | `(value: string) => void`  | Called when the user selects a different tab, in both modes.          |

Native `div` props are passed to the root element.

### TabList

| Prop         | Type     | Notes                                  |
| ------------ | -------- | -------------------------------------- |
| `aria-label` | `string` | Required. Names the `tablist`.         |

Native `div` props are passed through. Renders `role="tablist"`.

### Tab

| Prop       | Type      | Notes                                                    |
| ---------- | --------- | -------------------------------------------------------- |
| `value`    | `string`  | Required. Identifies the tab and its panel.              |
| `disabled` | `boolean` | Disabled tabs cannot be clicked or reached by the keyboard. |

Native `button` props are passed through. Renders `<button type="button" role="tab">`.

### TabPanel

| Prop    | Type     | Notes                                                  |
| ------- | -------- | ------------------------------------------------------ |
| `value` | `string` | Required. Shown only while its tab is selected.       |

Native `div` props are passed through. Renders `role="tabpanel"`, labelled by its tab.

### Keyboard (tablist)

| Key                | Behaviour                                                                     |
| ------------------ | ----------------------------------------------------------------------------- |
| `ArrowRight`       | Focuses and selects the next enabled tab, wrapping from the last to the first. |
| `ArrowLeft`        | Focuses and selects the previous enabled tab, wrapping from the first to the last. |
| `Home` / `End`     | Focuses and selects the first / last enabled tab.                             |
| `Tab`              | Moves focus out of the tablist to the selected tab.                           |

Selection follows focus. Other keys are ignored. Only the selected tab has `tabIndex=0`; when no tab is selected, the first enabled tab does.

## Dialog

A modal dialog rendered into `document.body` with a backdrop.

| Prop          | Type                         | Notes                                                                      |
| ------------- | ---------------------------- | -------------------------------------------------------------------------- |
| `open`        | `boolean`                    | Required. Nothing renders while `false`.                                   |
| `onOpenChange`| `(open: boolean) => void`    | Required. Called with `false` on Escape or a backdrop click.               |
| `title`       | `ReactNode`                  | Required. Rendered in an `h2` and used as the accessible name.             |
| `description` | `ReactNode`                  | Optional. Rendered in a `p` and used as the accessible description.        |

Native `div` props (including `className`) are passed to the `role="dialog"` element. The backdrop has `data-backdrop`.

On open, focus moves to the first focusable element in the dialog (or to a child with `autoFocus`), or to the dialog itself if there is none. Closing returns focus to the element that was focused before opening, if it is still in the document.

Nested dialogs are supported: only the topmost one handles Escape and the focus trap.

### Keyboard

| Key                | Behaviour                                                                                  |
| ------------------ | ------------------------------------------------------------------------------------------ |
| `Tab`              | Moves to the next focusable element, wrapping from the last to the first. Skips disabled, `hidden`, `inert` and `tabIndex=-1` elements. |
| `Shift+Tab`        | Moves to the previous focusable element, wrapping from the first to the last.              |
| `Escape`           | Calls `onOpenChange(false)`, unless a child already handled the key (see Combobox).      |

## Combobox

A text input that filters a list of options, following the WAI-ARIA combobox (list autocomplete) pattern.

| Prop          | Type                                      | Notes                                                                 |
| ------------- | ----------------------------------------- | --------------------------------------------------------------------- |
| `label`       | `string`                                  | Required. Rendered in a `label` for the input.                        |
| `options`     | `ComboboxOption[]`                        | Required. `ComboboxOption` is `{ value: string; label: string; disabled?: boolean }`. |
| `value`       | `string \| null`                          | Required. The selected option's `value`, or `null` for none.          |
| `onChange`    | `(value: string \| null) => void`         | Required. Called when an option is committed, or when the text is cleared and the field is left or Enter is pressed. |
| `placeholder` | `string`                                  | Shown in the input.                                                   |

Native `input` props (including `className`) are passed to the input. Its `value` and `onChange` are managed by the component.

Behaviour:

- While not typing, the input shows the label of the selected option (empty if `value` matches no option). Changing `value` updates the text.
- Typing opens the listbox and shows options whose label contains the text (case-insensitive, literal match).
- The active option is tracked by `value`. When the list changes, the same option stays active if it is still visible and enabled; otherwise no option is active.
- Committing an option calls `onChange(option.value)` and closes the list. With a controlled `value`, the input shows the new label only once the parent updates `value`.
- Clearing the text to empty and then pressing Enter or leaving the field calls `onChange(null)` (only if `value` was not already `null`). Leaving the field with other text reverts the text to the selected label without calling `onChange`.

### Keyboard

| Key                | Behaviour                                                                                             |
| ------------------ | ----------------------------------------------------------------------------------------------------- |
| `ArrowDown`        | Opens the listbox if closed (activating the first enabled option), otherwise moves the active option to the next enabled one, wrapping. |
| `ArrowUp`          | Opens the listbox if closed (activating the last enabled option), otherwise moves to the previous enabled option, wrapping. |
| `Enter`            | Commits the active option. With no active option, applies the cleared-text rule above.              |
| `Escape`           | Closes the listbox without calling `onChange` and restores the selected label. If the listbox is already closed, the key is not consumed, so an enclosing Dialog closes. |

Clicking an enabled option commits it and keeps focus in the input. Clicking a disabled option does nothing.

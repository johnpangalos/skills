import * as React from "react";
import { fireEvent, render, screen, waitFor } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { describe, expect, it, vi } from "vitest";
import { Tab, TabList, TabPanel, Tabs } from "../src";

type RootProps = Partial<React.ComponentProps<typeof Tabs>>;

// Alpha, Beta and Delta are enabled; Gamma is disabled.
function sections(root: RootProps) {
  return (
    <Tabs {...root}>
      <TabList aria-label="Sections">
        <Tab value="alpha">Alpha</Tab>
        <Tab value="beta">Beta</Tab>
        <Tab value="gamma" disabled>
          Gamma
        </Tab>
        <Tab value="delta">Delta</Tab>
      </TabList>
      <TabPanel value="alpha">Alpha panel</TabPanel>
      <TabPanel value="beta">Beta panel</TabPanel>
      <TabPanel value="gamma">Gamma panel</TabPanel>
      <TabPanel value="delta">Delta panel</TabPanel>
    </Tabs>
  );
}

function renderSections(root: RootProps = {}) {
  return render(sections(root));
}

function Controlled({ onValueChange }: { onValueChange: (value: string) => void }) {
  const [value, setValue] = React.useState("alpha");
  return (
    <>
      {sections({
        value,
        onValueChange: (next) => {
          onValueChange(next);
          setValue(next);
        },
      })}
    </>
  );
}

function List({ values }: { values: string[] }) {
  return (
    <Tabs defaultValue="alpha">
      <TabList aria-label="Dynamic">
        {values.map((value) => (
          <Tab key={value} value={value}>
            {value}
          </Tab>
        ))}
      </TabList>
      {values.map((value) => (
        <TabPanel key={value} value={value}>
          {value} panel
        </TabPanel>
      ))}
    </Tabs>
  );
}

describe("Tabs", () => {
  it("T1 links tablist, tabs and panel with roles, ids and aria attributes", () => {
    renderSections({ defaultValue: "alpha" });
    const tablist = screen.getByRole("tablist", { name: "Sections" });
    const alpha = screen.getByRole("tab", { name: "Alpha" });
    expect(tablist).toContainElement(alpha);
    expect(alpha.tagName).toBe("BUTTON");
    expect(alpha).toHaveAttribute("type", "button");
    expect(alpha).toHaveAttribute("aria-selected", "true");
    expect(screen.getByRole("tab", { name: "Beta" })).toHaveAttribute("aria-selected", "false");
    const panel = screen.getByRole("tabpanel");
    expect(panel).toHaveTextContent("Alpha panel");
    expect(alpha).toHaveAttribute("aria-controls", panel.id);
    expect(panel).toHaveAttribute("aria-labelledby", alpha.id);
    expect(panel).toHaveAttribute("tabindex", "0");
    expect(screen.getAllByRole("tabpanel", { hidden: true }).filter((p) => p.hidden)).toHaveLength(3);
  });

  it("T2 starts on defaultValue when it is given", () => {
    renderSections({ defaultValue: "beta" });
    expect(screen.getByRole("tab", { name: "Beta" })).toHaveAttribute("aria-selected", "true");
    expect(screen.getByRole("tabpanel")).toHaveTextContent("Beta panel");
  });

  it("T2 starts on the first non-disabled tab when there is no defaultValue", () => {
    render(
      <Tabs>
        <TabList aria-label="Pair">
          <Tab value="a" disabled>
            A
          </Tab>
          <Tab value="b">B</Tab>
        </TabList>
        <TabPanel value="a">A panel</TabPanel>
        <TabPanel value="b">B panel</TabPanel>
      </Tabs>,
    );
    expect(screen.getByRole("tab", { name: "B" })).toHaveAttribute("aria-selected", "true");
    expect(screen.getByRole("tabpanel")).toHaveTextContent("B panel");
  });

  it("T2 uncontrolled: clicking a tab selects it and calls onValueChange", async () => {
    const user = userEvent.setup();
    const onValueChange = vi.fn();
    renderSections({ defaultValue: "alpha", onValueChange });
    await user.click(screen.getByRole("tab", { name: "Beta" }));
    expect(onValueChange).toHaveBeenCalledTimes(1);
    expect(onValueChange).toHaveBeenCalledWith("beta");
    expect(screen.getByRole("tab", { name: "Beta" })).toHaveAttribute("aria-selected", "true");
  });

  it("T2 controlled: selection changes only when the parent updates value", async () => {
    const user = userEvent.setup();
    const onValueChange = vi.fn();
    renderSections({ value: "alpha", onValueChange });
    await user.click(screen.getByRole("tab", { name: "Beta" }));
    expect(onValueChange).toHaveBeenCalledWith("beta");
    expect(screen.getByRole("tab", { name: "Alpha" })).toHaveAttribute("aria-selected", "true");
    expect(screen.getByRole("tab", { name: "Beta" })).toHaveAttribute("aria-selected", "false");
  });

  it("T2 controlled: a parent that accepts the change moves the selection", async () => {
    const user = userEvent.setup();
    const onValueChange = vi.fn();
    render(<Controlled onValueChange={onValueChange} />);
    await user.click(screen.getByRole("tab", { name: "Beta" }));
    expect(onValueChange).toHaveBeenCalledWith("beta");
    expect(screen.getByRole("tab", { name: "Beta" })).toHaveAttribute("aria-selected", "true");
    expect(screen.getByRole("tabpanel")).toHaveTextContent("Beta panel");
  });

  it("T2 does not call onValueChange when the selected tab is selected again", async () => {
    const user = userEvent.setup();
    const onValueChange = vi.fn();
    renderSections({ defaultValue: "alpha", onValueChange });
    await user.click(screen.getByRole("tab", { name: "Alpha" }));
    expect(onValueChange).not.toHaveBeenCalled();
  });

  it("T3 makes only the selected tab tabbable", () => {
    renderSections({ defaultValue: "beta" });
    expect(screen.getByRole("tab", { name: "Beta" })).toHaveAttribute("tabindex", "0");
    for (const name of ["Alpha", "Gamma", "Delta"]) {
      expect(screen.getByRole("tab", { name })).toHaveAttribute("tabindex", "-1");
    }
  });

  it("T3 makes the first enabled tab tabbable when no tab is selected", () => {
    renderSections({ defaultValue: "nothing-matches" });
    expect(screen.getByRole("tab", { name: "Alpha" })).toHaveAttribute("tabindex", "0");
    expect(screen.getByRole("tab", { name: "Beta" })).toHaveAttribute("tabindex", "-1");
    expect(screen.queryAllByRole("tab", { selected: true })).toHaveLength(0);
    expect(screen.queryByRole("tabpanel")).toBeNull();
  });

  it("T4 ArrowRight and ArrowLeft move to the next and previous enabled tab, wrapping and skipping disabled tabs", async () => {
    const user = userEvent.setup();
    const onValueChange = vi.fn();
    renderSections({ defaultValue: "alpha", onValueChange });
    await user.tab();
    expect(screen.getByRole("tab", { name: "Alpha" })).toHaveFocus();
    await user.keyboard("{ArrowRight}");
    expect(screen.getByRole("tab", { name: "Beta" })).toHaveFocus();
    await user.keyboard("{ArrowRight}");
    expect(screen.getByRole("tab", { name: "Delta" })).toHaveFocus();
    await user.keyboard("{ArrowRight}");
    expect(screen.getByRole("tab", { name: "Alpha" })).toHaveFocus();
    await user.keyboard("{ArrowLeft}");
    expect(screen.getByRole("tab", { name: "Delta" })).toHaveFocus();
    expect(onValueChange.mock.calls).toEqual([["beta"], ["delta"], ["alpha"], ["delta"]]);
    expect(screen.getByRole("tab", { name: "Delta" })).toHaveAttribute("aria-selected", "true");
  });

  it("T4 Home and End move to the first and last enabled tab", async () => {
    const user = userEvent.setup();
    renderSections({ defaultValue: "beta" });
    await user.click(screen.getByRole("tab", { name: "Beta" }));
    await user.keyboard("{End}");
    expect(screen.getByRole("tab", { name: "Delta" })).toHaveFocus();
    expect(screen.getByRole("tab", { name: "Delta" })).toHaveAttribute("aria-selected", "true");
    await user.keyboard("{Home}");
    expect(screen.getByRole("tab", { name: "Alpha" })).toHaveFocus();
    expect(screen.getByRole("tab", { name: "Alpha" })).toHaveAttribute("aria-selected", "true");
  });

  it("T4 ignores other keys and prevents the default action of handled keys", () => {
    const onValueChange = vi.fn();
    renderSections({ defaultValue: "alpha", onValueChange });
    const alpha = screen.getByRole("tab", { name: "Alpha" });
    expect(fireEvent.keyDown(alpha, { key: "x" })).toBe(true);
    expect(onValueChange).not.toHaveBeenCalled();
    expect(fireEvent.keyDown(alpha, { key: "ArrowRight" })).toBe(false);
    expect(onValueChange).toHaveBeenCalledTimes(1);
  });

  it("T5 ignores clicks on disabled tabs and never selects them by keyboard", async () => {
    const user = userEvent.setup();
    const onValueChange = vi.fn();
    renderSections({ defaultValue: "alpha", onValueChange });
    const gamma = screen.getByRole("tab", { name: "Gamma" });
    expect(gamma).toBeDisabled();
    await user.click(gamma);
    expect(onValueChange).not.toHaveBeenCalled();
    expect(gamma).toHaveAttribute("aria-selected", "false");
    await user.click(screen.getByRole("tab", { name: "Beta" }));
    await user.keyboard("{ArrowRight}");
    expect(screen.getByRole("tab", { name: "Delta" })).toHaveFocus();
    expect(gamma).toHaveAttribute("aria-selected", "false");
  });

  it("hostile: all tabs disabled except one keeps focus still on arrows and does not throw", async () => {
    const user = userEvent.setup();
    render(
      <Tabs>
        <TabList aria-label="Lonely">
          <Tab value="a" disabled>
            A
          </Tab>
          <Tab value="b">B</Tab>
          <Tab value="c" disabled>
            C
          </Tab>
        </TabList>
        <TabPanel value="b">B panel</TabPanel>
      </Tabs>,
    );
    await user.tab();
    expect(screen.getByRole("tab", { name: "B" })).toHaveFocus();
    await user.keyboard("{ArrowRight}{ArrowLeft}{Home}{End}");
    expect(screen.getByRole("tab", { name: "B" })).toHaveFocus();
    expect(screen.getByRole("tab", { name: "B" })).toHaveAttribute("aria-selected", "true");
  });

  it("hostile: all tabs disabled does not throw and nothing receives focus", async () => {
    const user = userEvent.setup();
    render(
      <Tabs>
        <TabList aria-label="Locked">
          <Tab value="a" disabled>
            A
          </Tab>
          <Tab value="b" disabled>
            B
          </Tab>
        </TabList>
        <TabPanel value="a">A panel</TabPanel>
      </Tabs>,
    );
    await user.tab();
    await user.keyboard("{ArrowRight}{Home}{End}");
    expect(document.activeElement).toBe(document.body);
  });

  it("hostile: tabs added and removed after mount follow the current DOM order", async () => {
    const user = userEvent.setup();
    const { rerender } = render(<List values={["alpha", "beta"]} />);
    rerender(<List values={["alpha", "gamma", "beta"]} />);
    await user.tab();
    await user.keyboard("{ArrowRight}");
    expect(screen.getByRole("tab", { name: "gamma" })).toHaveFocus();
    rerender(<List values={["alpha", "beta"]} />);
    screen.getByRole("tab", { name: "beta" }).focus();
    await user.keyboard("{ArrowLeft}");
    expect(screen.getByRole("tab", { name: "alpha" })).toHaveFocus();
    await user.keyboard("{ArrowRight}");
    expect(screen.getByRole("tab", { name: "beta" })).toHaveFocus();
  });

  it("nested Tabs keep their own keyboard handling and selection", async () => {
    const user = userEvent.setup();
    const outer = vi.fn();
    const inner = vi.fn();
    render(
      <Tabs defaultValue="one" onValueChange={outer}>
        <TabList aria-label="Outer">
          <Tab value="one">One</Tab>
          <Tab value="two">Two</Tab>
        </TabList>
        <TabPanel value="one">
          <Tabs defaultValue="x" onValueChange={inner}>
            <TabList aria-label="Inner">
              <Tab value="x">X</Tab>
              <Tab value="y">Y</Tab>
            </TabList>
            <TabPanel value="x">X panel</TabPanel>
            <TabPanel value="y">Y panel</TabPanel>
          </Tabs>
        </TabPanel>
        <TabPanel value="two">Two panel</TabPanel>
      </Tabs>,
    );
    await user.click(screen.getByRole("tab", { name: "X" }));
    await user.keyboard("{ArrowRight}");
    expect(inner).toHaveBeenCalledWith("y");
    expect(outer).not.toHaveBeenCalled();
    expect(screen.getByRole("tab", { name: "Y" })).toHaveFocus();
    await user.click(screen.getByRole("tab", { name: "Two" }));
    expect(outer).toHaveBeenCalledTimes(1);
    expect(outer).toHaveBeenCalledWith("two");
    expect(inner).toHaveBeenCalledTimes(1);
  });

  it("hostile: a value that matches no tab selects nothing and still makes the first enabled tab reachable", async () => {
    const user = userEvent.setup();
    const onValueChange = vi.fn();
    renderSections({ value: "missing", onValueChange });
    expect(screen.queryAllByRole("tab", { selected: true })).toHaveLength(0);
    await user.tab();
    expect(screen.getByRole("tab", { name: "Alpha" })).toHaveFocus();
    await user.keyboard("{ArrowRight}");
    expect(onValueChange).toHaveBeenCalledWith("beta");
    expect(screen.getByRole("tab", { name: "Beta" })).toHaveAttribute("aria-selected", "false");
  });

  it("T3 keeps a tab-stop when a child component removes the selected tab without TabList re-rendering", async () => {
    const user = userEvent.setup();
    // The child owns its state, so only the child re-renders when it drops tab "a".
    function ChildList() {
      const [showA, setShowA] = React.useState(true);
      return (
        <>
          <button type="button" onClick={() => setShowA(false)}>
            Hide A
          </button>
          {showA && <Tab value="a">A</Tab>}
          <Tab value="b">B</Tab>
          <Tab value="c">C</Tab>
        </>
      );
    }
    render(
      <Tabs defaultValue="a">
        <TabList aria-label="x">
          <ChildList />
        </TabList>
        <TabPanel value="a">A panel</TabPanel>
        <TabPanel value="b">B panel</TabPanel>
        <TabPanel value="c">C panel</TabPanel>
      </Tabs>,
    );
    await user.click(screen.getByRole("button", { name: "Hide A" }));
    const b = screen.getByRole("tab", { name: "B" });
    await waitFor(() => expect(b).toHaveAttribute("tabindex", "0"));
    expect(screen.getByRole("tab", { name: "C" })).toHaveAttribute("tabindex", "-1");
    await user.tab();
    expect(b).toHaveFocus();
  });

  it("T3 keeps a tab-stop when a child component disables the tab that was tabbable", async () => {
    const user = userEvent.setup();
    // The child owns its state, so only the child re-renders when it disables tab "a".
    function ChildList() {
      const [disabled, setDisabled] = React.useState(false);
      return (
        <>
          <button type="button" onClick={() => setDisabled(true)}>
            Disable A
          </button>
          <Tab value="a" disabled={disabled}>
            A
          </Tab>
          <Tab value="b">B</Tab>
          <Tab value="c">C</Tab>
        </>
      );
    }
    render(
      <Tabs defaultValue="a">
        <TabList aria-label="x">
          <ChildList />
        </TabList>
        <TabPanel value="a">A panel</TabPanel>
        <TabPanel value="b">B panel</TabPanel>
        <TabPanel value="c">C panel</TabPanel>
      </Tabs>,
    );
    await user.click(screen.getByRole("button", { name: "Disable A" }));
    const b = screen.getByRole("tab", { name: "B" });
    await waitFor(() => expect(b).toHaveAttribute("tabindex", "0"));
    expect(screen.getByRole("tab", { name: "C" })).toHaveAttribute("tabindex", "-1");
    await user.tab();
    expect(b).toHaveFocus();
  });
});

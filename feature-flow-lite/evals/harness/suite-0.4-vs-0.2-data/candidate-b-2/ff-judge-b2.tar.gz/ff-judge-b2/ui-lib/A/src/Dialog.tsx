import {
  useId,
  useInsertionEffect,
  useLayoutEffect,
  useRef,
  type ComponentPropsWithoutRef,
  type KeyboardEvent,
} from "react";
import { createPortal } from "react-dom";

const FOCUSABLE = 'a[href], button, input, select, textarea, [tabindex], [contenteditable="true"]';

// Elements a Tab press can reach inside the dialog. Computed on each keypress so late additions count.
function tabbables(dialog: HTMLElement): HTMLElement[] {
  return Array.from(dialog.querySelectorAll<HTMLElement>(FOCUSABLE)).filter(
    (el) => el.tabIndex >= 0 && !el.hasAttribute("disabled") && !el.closest("[hidden], [inert]"),
  );
}

// Open dialogs, outermost first. Only the last one, the topmost layer, keeps focus inside itself.
const openDialogs: HTMLElement[] = [];

function focusInto(dialog: HTMLElement) {
  (tabbables(dialog)[0] ?? dialog).focus();
}

export type DialogProps = Omit<ComponentPropsWithoutRef<"div">, "title"> & {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  title: string;
  description?: string;
};

export function Dialog({
  open,
  onOpenChange,
  title,
  description,
  className,
  onKeyDown: onKeyDownProp,
  children,
  ...rest
}: DialogProps) {
  const titleId = useId();
  const descriptionId = useId();
  const dialogRef = useRef<HTMLDivElement>(null);
  const pressedInside = useRef(false);
  const opener = useRef<HTMLElement | null>(null);

  // Record the opener before any child autoFocus runs (insertion effects run before layout-phase autofocus).
  // On open, focus moves into the dialog unless a child already has it. On close, focus returns to the
  // opener, if it is still in the document.
  useInsertionEffect(() => {
    if (open) opener.current = document.activeElement as HTMLElement;
  }, [open]);

  useLayoutEffect(() => {
    const dialog = dialogRef.current;
    if (!open || !dialog) return;
    openDialogs.push(dialog);
    const isTop = () => openDialogs.at(-1) === dialog;
    // Focus that leaves the topmost dialog (a click outside it) is pulled back in.
    const onFocusIn = (event: FocusEvent) => {
      if (isTop() && !dialog.contains(event.target as Node)) focusInto(dialog);
    };
    // A removed focused element leaves focus on body, where no focusin fires, so the next Tab pulls it in.
    const onDocumentKeyDown = (event: globalThis.KeyboardEvent) => {
      if (event.key === "Tab" && isTop() && !dialog.contains(document.activeElement)) {
        event.preventDefault();
        focusInto(dialog);
      }
    };
    document.addEventListener("focusin", onFocusIn);
    document.addEventListener("keydown", onDocumentKeyDown);
    if (!dialog.contains(document.activeElement)) focusInto(dialog);
    const previous = opener.current;
    return () => {
      document.removeEventListener("focusin", onFocusIn);
      document.removeEventListener("keydown", onDocumentKeyDown);
      openDialogs.splice(openDialogs.indexOf(dialog), 1);
      if (previous?.isConnected) previous.focus();
    };
  }, [open]);

  const onKeyDown = (event: KeyboardEvent<HTMLDivElement>) => {
    onKeyDownProp?.(event);
    // A child that already handled the key (an open Combobox list handles Escape) keeps it, so the dialog ignores it.
    if (event.defaultPrevented) return;
    const dialog = event.currentTarget;
    // A nested dialog is portaled but its events bubble here through React, so ignore keys from outside this dialog.
    if (!dialog.contains(event.target as Node)) return;
    if (event.key === "Escape") {
      onOpenChange(false);
      return;
    }
    if (event.key !== "Tab") return;
    event.preventDefault();
    const items = tabbables(dialog);
    if (items.length === 0) {
      dialog.focus();
      return;
    }
    const index = items.indexOf(document.activeElement as HTMLElement);
    let next: number;
    if (event.shiftKey) next = index <= 0 ? items.length - 1 : index - 1;
    else next = index === -1 || index === items.length - 1 ? 0 : index + 1;
    items[next].focus();
  };

  if (!open) return null;

  // A click only closes the dialog when the press also started on the backdrop, so a drag from inside does not.
  return createPortal(
    <div
      onMouseDown={(event) => {
        pressedInside.current = event.target !== event.currentTarget;
      }}
      onClick={(event) => {
        const startedInside = pressedInside.current;
        pressedInside.current = false;
        if (!startedInside && event.target === event.currentTarget) onOpenChange(false);
      }}
    >
      <div
        {...rest}
        role="dialog"
        aria-modal="true"
        aria-labelledby={titleId}
        aria-describedby={description ? descriptionId : undefined}
        tabIndex={-1}
        ref={dialogRef}
        className={className}
        onKeyDown={onKeyDown}
      >
        <h2 id={titleId}>{title}</h2>
        {description && <p id={descriptionId}>{description}</p>}
        {children}
      </div>
    </div>,
    document.body,
  );
}

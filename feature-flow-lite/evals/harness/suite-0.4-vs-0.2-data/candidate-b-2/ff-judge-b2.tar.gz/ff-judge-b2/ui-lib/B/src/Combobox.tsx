import { useId, useState, type ComponentPropsWithoutRef, type KeyboardEvent } from 'react';

export type ComboboxOption = {
  value: string;
  label: string;
  disabled?: boolean;
};

export type ComboboxProps = Omit<ComponentPropsWithoutRef<'div'>, 'onChange'> & {
  label: string;
  options: ComboboxOption[];
  value: string | null;
  onChange: (value: string | null) => void;
  placeholder?: string;
};

// Literal, case-insensitive substring match.
const matches = (option: ComboboxOption, text: string) =>
  option.label.toLowerCase().includes(text.toLowerCase());

// The enabled option one step from the active one. Stops at either end instead of wrapping.
function stepActive(enabled: ComboboxOption[], active: string | null, step: 1 | -1) {
  if (enabled.length === 0) return null;
  const index = enabled.findIndex((option) => option.value === active);
  if (index === -1) return step === 1 ? enabled[0].value : enabled[enabled.length - 1].value;
  return enabled[Math.min(Math.max(index + step, 0), enabled.length - 1)].value;
}

export function Combobox({ label, options, value, onChange, placeholder, ...rest }: ComboboxProps) {
  const id = useId();
  const labelId = `${id}-label`;
  const inputId = `${id}-input`;
  const listboxId = `${id}-listbox`;
  // Based on the index in `options`, so an option's id does not change as the list is filtered.
  const optionId = (index: number) => `${id}-option-${index}`;

  const [open, setOpen] = useState(false);
  // null means the user is not editing, so the input shows the selected label.
  const [query, setQuery] = useState<string | null>(null);
  const [active, setActive] = useState<string | null>(null);
  const [lastValue, setLastValue] = useState(value);

  const selected = options.find((option) => option.value === value);
  // Each entry keeps its index in `options`, so duplicate option objects still get distinct ids.
  const visible = options
    .map((option, index) => ({ option, index }))
    .filter(({ option }) => matches(option, query ?? ''));
  const enabled = visible.map(({ option }) => option).filter((option) => !option.disabled);
  // The active option is tracked by value. If filtering or new options hide it, nothing is active.
  const activeEntry = visible.find(({ option }) => option.value === active);
  const activeValue = activeEntry?.option.value ?? null;

  function close() {
    setOpen(false);
    setQuery(null);
    setActive(null);
  }

  // The parent changed the selection, so text typed against the old selection no longer applies.
  if (value !== lastValue) {
    setLastValue(value);
    close();
  }

  function commit(option: ComboboxOption) {
    onChange(option.value);
    close();
  }

  // Leaving or confirming empty text clears the selection. Escape never does.
  function dismiss() {
    if (query === '' && value !== null) onChange(null);
    close();
  }

  function handleChange(text: string) {
    const next = options.filter((option) => matches(option, text));
    setQuery(text);
    setOpen(true);
    setActive((current) => (next.some((option) => option.value === current) ? current : null));
  }

  function handleKeyDown(event: KeyboardEvent<HTMLInputElement>) {
    switch (event.key) {
      case 'ArrowDown':
      case 'ArrowUp': {
        event.preventDefault();
        if (open) {
          setActive(stepActive(enabled, activeValue, event.key === 'ArrowDown' ? 1 : -1));
          return;
        }
        setOpen(true);
        if (event.key === 'ArrowUp') setActive(stepActive(enabled, null, -1));
        else if (event.altKey) setActive(null);
        else setActive(enabled.some((option) => option.value === value) ? value : stepActive(enabled, null, 1));
        return;
      }
      case 'Enter': {
        if (!open) return;
        if (activeEntry) {
          event.preventDefault();
          commit(activeEntry.option);
        } else if (query === '') {
          event.preventDefault();
          dismiss();
        }
        return;
      }
      case 'Escape': {
        if (!open) return;
        // Closing the listbox must not also close a dialog that contains this combobox.
        event.preventDefault();
        event.stopPropagation();
        close();
        return;
      }
      default:
        return;
    }
  }

  return (
    <div {...rest}>
      <label id={labelId} htmlFor={inputId}>
        {label}
      </label>
      <input
        id={inputId}
        type="text"
        role="combobox"
        autoComplete="off"
        placeholder={placeholder}
        aria-autocomplete="list"
        aria-expanded={open}
        aria-controls={listboxId}
        aria-activedescendant={activeEntry && optionId(activeEntry.index)}
        value={query ?? selected?.label ?? ''}
        onChange={(event) => handleChange(event.target.value)}
        onKeyDown={handleKeyDown}
        onBlur={dismiss}
      />
      {/* Mouse down is prevented so a click on an option does not blur the input first. */}
      <div
        id={listboxId}
        role="listbox"
        aria-labelledby={labelId}
        hidden={!open}
        onMouseDown={(event) => event.preventDefault()}
      >
        {open &&
          visible.map(({ option, index }) => (
            <div
              key={index}
              id={optionId(index)}
              role="option"
              aria-selected={option.value === value}
              aria-disabled={option.disabled || undefined}
              data-active={option.value === activeValue || undefined}
              onClick={() => {
                if (!option.disabled) commit(option);
              }}
            >
              {option.label}
            </div>
          ))}
      </div>
      {open && visible.length === 0 && <div role="status">No results</div>}
    </div>
  );
}

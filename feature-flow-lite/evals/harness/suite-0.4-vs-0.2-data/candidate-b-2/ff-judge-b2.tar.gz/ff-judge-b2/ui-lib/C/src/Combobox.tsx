import * as React from "react";

export type ComboboxOption = {
  value: string;
  label: string;
  disabled?: boolean;
};

export type ComboboxProps = Omit<React.InputHTMLAttributes<HTMLInputElement>, "value" | "defaultValue" | "onChange"> & {
  label: string;
  options: ComboboxOption[];
  value: string | null;
  onChange: (value: string | null) => void;
};

function filterOptions(options: ComboboxOption[], query: string): ComboboxOption[] {
  const needle = query.toLowerCase();
  return options.filter((option) => option.label.toLowerCase().includes(needle));
}

export function Combobox({ label, options, value, onChange, onKeyDown, onBlur, ...rest }: ComboboxProps) {
  const baseId = React.useId();
  const inputId = `${baseId}-input`;
  const labelId = `${baseId}-label`;
  const listboxId = `${baseId}-listbox`;
  const [open, setOpen] = React.useState(false);
  // The text being typed. Null while the input shows the selected option's label.
  const [draft, setDraft] = React.useState<string | null>(null);
  // Tracked by value, so a list that changes while open keeps the same option active.
  const [activeValue, setActiveValue] = React.useState<string | null>(null);

  const selectedLabel = options.find((option) => option.value === value)?.label ?? "";
  const visible = filterOptions(options, draft ?? "");
  const enabled = visible.filter((option) => !option.disabled);
  const active = open ? enabled.find((option) => option.value === activeValue) : undefined;

  const closeList = () => {
    setOpen(false);
    setActiveValue(null);
  };

  const commit = (option: ComboboxOption) => {
    onChange(option.value);
    setDraft(null);
    closeList();
  };

  // Enter without an active option, or leaving the input. Clearing the text clears the selection.
  const settle = () => {
    if (draft === "" && value !== null) onChange(null);
    setDraft(null);
    closeList();
  };

  const handleInput = (event: React.ChangeEvent<HTMLInputElement>) => {
    const query = event.target.value;
    setDraft(query);
    setOpen(true);
    if (!filterOptions(options, query).some((option) => option.value === activeValue && !option.disabled)) {
      setActiveValue(null);
    }
  };

  const handleKeyDown = (event: React.KeyboardEvent<HTMLInputElement>) => {
    onKeyDown?.(event);
    switch (event.key) {
      case "ArrowDown":
      case "ArrowUp": {
        event.preventDefault();
        setOpen(true);
        if (enabled.length === 0) return;
        const step = event.key === "ArrowDown" ? 1 : -1;
        const index = active ? enabled.indexOf(active) : -1;
        const next =
          index === -1
            ? enabled[step > 0 ? 0 : enabled.length - 1]
            : enabled[(index + step + enabled.length) % enabled.length];
        setActiveValue(next.value);
        return;
      }
      case "Enter":
        if (active) {
          event.preventDefault();
          commit(active);
        } else {
          settle();
        }
        return;
      case "Escape":
        if (open) event.preventDefault();
        setDraft(null);
        closeList();
        return;
    }
  };

  const handleBlur = (event: React.FocusEvent<HTMLInputElement>) => {
    onBlur?.(event);
    settle();
  };

  return (
    <div>
      <label id={labelId} htmlFor={inputId}>
        {label}
      </label>
      <input
        {...rest}
        id={inputId}
        role="combobox"
        autoComplete="off"
        value={draft ?? selectedLabel}
        aria-autocomplete="list"
        aria-expanded={open}
        aria-controls={listboxId}
        aria-activedescendant={active ? `${baseId}-option-${encodeURIComponent(active.value)}` : undefined}
        onChange={handleInput}
        onKeyDown={handleKeyDown}
        onBlur={handleBlur}
      />
      <ul id={listboxId} role="listbox" aria-labelledby={labelId} hidden={!open}>
        {visible.map((option) => (
          <li
            key={option.value}
            id={`${baseId}-option-${encodeURIComponent(option.value)}`}
            role="option"
            aria-selected={option.value === value}
            aria-disabled={option.disabled ? "true" : undefined}
            onMouseDown={(event) => event.preventDefault()}
            onClick={() => {
              if (!option.disabled) commit(option);
            }}
          >
            {option.label}
          </li>
        ))}
      </ul>
      {open && visible.length === 0 && <div>No results</div>}
    </div>
  );
}

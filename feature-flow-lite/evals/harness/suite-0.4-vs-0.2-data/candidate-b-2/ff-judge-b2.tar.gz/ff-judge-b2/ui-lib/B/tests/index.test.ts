import * as ui from '../src';
import type {
  ComboboxOption,
  ComboboxProps,
  DialogProps,
  TabListProps,
  TabPanelProps,
  TabProps,
  TabsProps,
} from '../src';

// Type-only references fail typecheck if any props type is not exported.
export type PublicTypes = [
  ComboboxOption,
  ComboboxProps,
  DialogProps,
  TabListProps,
  TabPanelProps,
  TabProps,
  TabsProps,
];

describe('package entry', () => {
  it('G1 exports the components', () => {
    expect(Object.keys(ui).sort()).toEqual(['Combobox', 'Dialog', 'Tab', 'TabList', 'TabPanel', 'Tabs']);
    for (const name of Object.keys(ui)) {
      expect(typeof (ui as Record<string, unknown>)[name]).toBe('function');
    }
  });
});

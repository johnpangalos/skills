import { useState, type FormEvent } from 'react';
import { render, screen, within } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { Combobox, type ComboboxOption } from '../src/Combobox';
import { Dialog } from '../src/Dialog';

const fruits: ComboboxOption[] = [
  { value: 'apple', label: 'Apple' },
  { value: 'banana', label: 'Banana' },
  { value: 'cherry', label: 'Cherry', disabled: true },
  { value: 'grape', label: 'Grape' },
];

// Owns the value like a real parent would, and records every onChange call.
function Field({
  options = fruits,
  initial = null,
  onChange = vi.fn(),
}: {
  options?: ComboboxOption[];
  initial?: string | null;
  onChange?: (value: string | null) => void;
}) {
  const [value, setValue] = useState<string | null>(initial);
  return (
    <Combobox
      label="Fruit"
      options={options}
      value={value}
      onChange={(next) => {
        onChange(next);
        setValue(next);
      }}
      placeholder="Pick a fruit"
    />
  );
}

const input = () => screen.getByRole('combobox', { name: 'Fruit' });
const optionNames = () => screen.queryAllByRole('option').map((option) => option.textContent);
const expanded = () => input().getAttribute('aria-expanded');
const active = () => {
  const id = input().getAttribute('aria-activedescendant');
  return id ? document.getElementById(id)?.textContent : null;
};

describe('Combobox', () => {
  it('C1 wires the label, input and listbox with ARIA attributes', async () => {
    const user = userEvent.setup();
    render(<Field initial="banana" />);
    expect(input()).toHaveAccessibleName('Fruit');
    expect(input()).toHaveAttribute('placeholder', 'Pick a fruit');
    expect(input()).toHaveAttribute('aria-autocomplete', 'list');
    expect(expanded()).toBe('false');

    await user.click(input());
    await user.keyboard('{ArrowDown}');
    const listbox = screen.getByRole('listbox', { name: 'Fruit' });
    expect(input()).toHaveAttribute('aria-controls', listbox.id);
    expect(expanded()).toBe('true');

    const options = within(listbox).getAllByRole('option');
    expect(options).toHaveLength(4);
    expect(new Set(options.map((o) => o.id)).size).toBe(4);
    options.forEach((o) => expect(document.getElementById(o.id)).toBe(o));
    expect(options.map((o) => o.getAttribute('aria-selected'))).toEqual(['false', 'true', 'false', 'false']);
    expect(options[2]).toHaveAttribute('aria-disabled', 'true');
    expect(options[0]).not.toHaveAttribute('aria-disabled');
  });

  it('C2 shows the selected label when closed, filters by case-insensitive substring, and empty text shows all', async () => {
    const user = userEvent.setup();
    render(<Field initial="banana" />);
    expect(input()).toHaveValue('Banana');

    await user.clear(input());
    expect(expanded()).toBe('true');
    expect(optionNames()).toEqual(['Apple', 'Banana', 'Cherry', 'Grape']);

    await user.type(input(), 'AN');
    expect(optionNames()).toEqual(['Banana']);

    await user.clear(input());
    expect(optionNames()).toHaveLength(4);
  });

  it('C3 shows "No results" when nothing matches, with no option and no active descendant', async () => {
    const user = userEvent.setup();
    render(<Field />);
    await user.type(input(), 'zzz');
    expect(screen.getByRole('status')).toHaveTextContent('No results');
    expect(screen.queryAllByRole('option')).toHaveLength(0);
    expect(input()).not.toHaveAttribute('aria-activedescendant');
  });

  it('C4 ArrowDown opens and moves the active option, skipping disabled ones, without wrapping', async () => {
    const user = userEvent.setup();
    render(<Field />);
    await user.click(input());
    await user.keyboard('{ArrowDown}');
    expect(expanded()).toBe('true');
    expect(active()).toBe('Apple');
    await user.keyboard('{ArrowDown}');
    expect(active()).toBe('Banana');
    await user.keyboard('{ArrowDown}');
    expect(active()).toBe('Grape');
    await user.keyboard('{ArrowDown}');
    expect(active()).toBe('Grape');
    await user.keyboard('{ArrowUp}');
    expect(active()).toBe('Banana');
    await user.keyboard('{ArrowUp}{ArrowUp}');
    expect(active()).toBe('Apple');
  });

  it('C4 Alt+ArrowDown opens the listbox without moving the active option', async () => {
    const user = userEvent.setup();
    render(<Field />);
    await user.click(input());
    await user.keyboard('{Alt>}{ArrowDown}{/Alt}');
    expect(expanded()).toBe('true');
    expect(input()).not.toHaveAttribute('aria-activedescendant');
  });

  it('C4 ArrowUp while closed opens with the last enabled option active', async () => {
    const user = userEvent.setup();
    render(<Field />);
    await user.click(input());
    await user.keyboard('{ArrowUp}');
    expect(expanded()).toBe('true');
    expect(active()).toBe('Grape');
  });

  it('C4 Home and End stay text-cursor keys', async () => {
    const user = userEvent.setup();
    render(<Field />);
    await user.type(input(), 'ban');
    await user.keyboard('{Home}');
    expect(input()).toHaveValue('ban');
    expect(expanded()).toBe('true');
    expect(input()).not.toHaveAttribute('aria-activedescendant');
  });

  it('C5 Enter commits the active option, closes the listbox and shows its label', async () => {
    const user = userEvent.setup();
    const onChange = vi.fn();
    render(<Field onChange={onChange} />);
    await user.click(input());
    await user.keyboard('{ArrowDown}{ArrowDown}{Enter}');
    expect(onChange).toHaveBeenCalledTimes(1);
    expect(onChange).toHaveBeenCalledWith('banana');
    expect(expanded()).toBe('false');
    expect(input()).toHaveValue('Banana');
  });

  it('C5 Enter with no active option does nothing and lets the form submit', async () => {
    const user = userEvent.setup();
    const onChange = vi.fn();
    const onSubmit = vi.fn((event: FormEvent) => event.preventDefault());
    render(
      <form onSubmit={onSubmit}>
        <Field onChange={onChange} />
        <button>Save</button>
      </form>,
    );
    await user.type(input(), 'ban');
    await user.keyboard('{Enter}');
    expect(onChange).not.toHaveBeenCalled();
    expect(onSubmit).toHaveBeenCalledTimes(1);
    expect(expanded()).toBe('true');
  });

  it('C5 Enter with an active option is not submitted as a form', async () => {
    const user = userEvent.setup();
    const onSubmit = vi.fn((event: FormEvent) => event.preventDefault());
    render(
      <form onSubmit={onSubmit}>
        <Field />
        <button>Save</button>
      </form>,
    );
    await user.click(input());
    await user.keyboard('{ArrowDown}{Enter}');
    expect(onSubmit).not.toHaveBeenCalled();
    expect(input()).toHaveValue('Apple');
  });

  it('C5 clicking an enabled option selects it, and clicking a disabled one does nothing', async () => {
    const user = userEvent.setup();
    const onChange = vi.fn();
    render(<Field onChange={onChange} />);
    await user.click(input());
    await user.keyboard('{ArrowDown}');
    await user.click(screen.getByRole('option', { name: 'Cherry' }));
    expect(onChange).not.toHaveBeenCalled();
    expect(expanded()).toBe('true');

    await user.click(screen.getByRole('option', { name: 'Grape' }));
    expect(onChange).toHaveBeenCalledWith('grape');
    expect(expanded()).toBe('false');
    expect(input()).toHaveValue('Grape');
  });

  it('C6 Escape closes without calling onChange and restores the selected label', async () => {
    const user = userEvent.setup();
    const onChange = vi.fn();
    render(<Field initial="apple" onChange={onChange} />);
    await user.clear(input());
    await user.type(input(), 'ban');
    await user.keyboard('{Escape}');
    expect(expanded()).toBe('false');
    expect(input()).toHaveValue('Apple');
    expect(onChange).not.toHaveBeenCalled();
  });

  it('C6 Escape with emptied text restores the label and keeps the selection', async () => {
    const user = userEvent.setup();
    const onChange = vi.fn();
    render(<Field initial="apple" onChange={onChange} />);
    await user.clear(input());
    await user.keyboard('{Escape}');
    expect(input()).toHaveValue('Apple');
    expect(onChange).not.toHaveBeenCalled();
  });

  it('C6 leaving the input closes the listbox and restores the selected label', async () => {
    const user = userEvent.setup();
    render(<Field initial="apple" />);
    await user.clear(input());
    await user.type(input(), 'ban');
    await user.tab();
    expect(expanded()).toBe('false');
    expect(input()).toHaveValue('Apple');
  });

  it('C7 clearing the text and leaving calls onChange(null)', async () => {
    const user = userEvent.setup();
    const onChange = vi.fn();
    render(<Field initial="apple" onChange={onChange} />);
    await user.clear(input());
    await user.tab();
    expect(onChange).toHaveBeenLastCalledWith(null);
    expect(input()).toHaveValue('');
  });

  it('C7 clearing the text and pressing Enter with no active option calls onChange(null)', async () => {
    const user = userEvent.setup();
    const onChange = vi.fn();
    render(<Field initial="apple" onChange={onChange} />);
    await user.clear(input());
    await user.keyboard('{Enter}');
    expect(onChange).toHaveBeenLastCalledWith(null);
    expect(expanded()).toBe('false');
    expect(input()).toHaveValue('');
  });

  it('C8 controlled: a parent value change updates the text, and a parent that ignores onChange reverts it', async () => {
    const user = userEvent.setup();
    const onChange = vi.fn();
    const props = { label: 'Fruit', options: fruits, onChange };
    const { rerender } = render(<Combobox {...props} value="apple" />);
    expect(input()).toHaveValue('Apple');

    await user.click(input());
    await user.keyboard('{ArrowDown}{ArrowDown}{Enter}');
    expect(onChange).toHaveBeenCalledWith('banana');
    expect(input()).toHaveValue('Apple');

    rerender(<Combobox {...props} value="grape" />);
    expect(input()).toHaveValue('Grape');
  });

  it('C8 a parent value change while typing drops the typed text, closes the listbox and shows the new label', async () => {
    const user = userEvent.setup();
    const props = { label: 'Fruit', options: fruits, onChange: vi.fn() };
    const { rerender } = render(<Combobox {...props} value="apple" />);
    await user.click(input());
    await user.type(input(), 'x');
    expect(input()).toHaveValue('Applex');

    rerender(<Combobox {...props} value="cherry" />);
    expect(input()).toHaveValue('Cherry');
    expect(expanded()).toBe('false');
  });

  it('C8 a parent re-render with the same value keeps the typed text and the listbox', async () => {
    const user = userEvent.setup();
    const props = { label: 'Fruit', options: fruits, onChange: vi.fn() };
    const { rerender } = render(<Combobox {...props} value={null} />);
    await user.type(input(), 'an');
    rerender(<Combobox {...props} value={null} />);
    expect(input()).toHaveValue('an');
    expect(expanded()).toBe('true');
    expect(optionNames()).toEqual(['Banana']);
  });

  it('C8 hostile: value null, or a value matching no option, shows an empty input', () => {
    const { rerender } = render(<Combobox label="Fruit" options={fruits} value={null} onChange={() => {}} />);
    expect(input()).toHaveValue('');
    rerender(<Combobox label="Fruit" options={fruits} value="nope" onChange={() => {}} />);
    expect(input()).toHaveValue('');
  });

  it('C1 an option keeps its id as typing narrows the list, and aria-activedescendant follows it', async () => {
    const user = userEvent.setup();
    render(<Field />);
    await user.click(input());
    await user.keyboard('{ArrowDown}');
    const bananaId = screen.getByRole('option', { name: 'Banana' }).id;
    await user.type(input(), 'an');
    expect(screen.getByRole('option', { name: 'Banana' }).id).toBe(bananaId);
    await user.keyboard('{ArrowDown}');
    expect(input()).toHaveAttribute('aria-activedescendant', bananaId);
  });

  it('C1 duplicate option objects get distinct ids and no duplicate key warning', async () => {
    const user = userEvent.setup();
    const errors = vi.spyOn(console, 'error').mockImplementation(() => {});
    const dup = { value: 'a', label: 'Apple' };
    render(<Field options={[dup, dup]} />);
    await user.click(input());
    await user.keyboard('{ArrowDown}');
    const [first, second] = screen.getAllByRole('option');
    expect(first.id).not.toBe(second.id);
    expect(input()).toHaveAttribute('aria-activedescendant', first.id);
    expect(errors).not.toHaveBeenCalled();
    errors.mockRestore();
  });

  it('C9 keeps the active option by value while filtering keeps it visible, and Enter commits it', async () => {
    const user = userEvent.setup();
    const onChange = vi.fn();
    render(<Field onChange={onChange} />);
    await user.click(input());
    await user.keyboard('{ArrowDown}{ArrowDown}');
    expect(active()).toBe('Banana');
    await user.type(input(), 'an');
    expect(active()).toBe('Banana');
    await user.keyboard('{Enter}');
    expect(onChange).toHaveBeenCalledWith('banana');
  });

  it('C9 resets the active option when filtering hides it', async () => {
    const user = userEvent.setup();
    const onChange = vi.fn();
    render(<Field onChange={onChange} />);
    await user.click(input());
    await user.keyboard('{ArrowDown}');
    expect(active()).toBe('Apple');
    await user.type(input(), 'ban');
    expect(input()).not.toHaveAttribute('aria-activedescendant');
    await user.keyboard('{Enter}');
    expect(onChange).not.toHaveBeenCalled();
  });

  it('C9 hostile: options replaced while open keep the active option by value, and removing it clears it', async () => {
    const user = userEvent.setup();
    const onChange = vi.fn();
    const props = { label: 'Fruit', onChange, value: null };
    const { rerender } = render(<Combobox {...props} options={fruits} />);
    await user.click(input());
    await user.keyboard('{ArrowDown}{ArrowDown}');
    expect(active()).toBe('Banana');

    rerender(<Combobox {...props} options={[{ value: 'kiwi', label: 'Kiwi' }, ...fruits]} />);
    expect(active()).toBe('Banana');
    await user.keyboard('{Enter}');
    expect(onChange).toHaveBeenCalledWith('banana');

    await user.click(input());
    await user.keyboard('{ArrowDown}{ArrowDown}{ArrowDown}');
    expect(active()).toBe('Banana');
    rerender(<Combobox {...props} options={fruits.filter((o) => o.value !== 'banana')} />);
    expect(input()).not.toHaveAttribute('aria-activedescendant');
  });

  it('C9 hostile: filter labels with regex characters are matched literally', async () => {
    const user = userEvent.setup();
    const options = [
      { value: 'cpp', label: 'C++ (x)' },
      { value: 'ab', label: 'a.b*' },
      { value: 'axb', label: 'axb' },
    ];
    render(<Field options={options} />);
    await user.type(input(), 'c++');
    expect(optionNames()).toEqual(['C++ (x)']);
    await user.clear(input());
    await user.type(input(), 'a.b');
    expect(optionNames()).toEqual(['a.b*']);
  });

  it('C9 hostile: all options disabled, arrows do nothing', async () => {
    const user = userEvent.setup();
    render(<Field options={[{ value: 'x', label: 'X', disabled: true }]} />);
    await user.click(input());
    await user.keyboard('{ArrowDown}{ArrowUp}');
    expect(input()).not.toHaveAttribute('aria-activedescendant');
  });

  it('C9 hostile: numeric-looking values and values with spaces give valid, distinct option ids', async () => {
    const user = userEvent.setup();
    const onChange = vi.fn();
    render(
      <Field
        options={[
          { value: 'new york', label: 'New York' },
          { value: '42', label: 'Forty two' },
        ]}
        onChange={onChange}
      />,
    );
    await user.click(input());
    await user.keyboard('{ArrowDown}{ArrowDown}');
    expect(active()).toBe('Forty two');
    expect(document.getElementById(input().getAttribute('aria-activedescendant') ?? '')).not.toBeNull();
    await user.keyboard('{Enter}');
    expect(onChange).toHaveBeenCalledWith('42');
  });

  it('C9 hostile: duplicate labels with distinct values commit the one that is highlighted', async () => {
    const user = userEvent.setup();
    const onChange = vi.fn();
    render(
      <Field
        options={[
          { value: 'a1', label: 'Apple' },
          { value: 'a2', label: 'Apple' },
        ]}
        onChange={onChange}
      />,
    );
    await user.click(input());
    await user.keyboard('{ArrowDown}{ArrowDown}{Enter}');
    expect(onChange).toHaveBeenCalledWith('a2');
  });

  it('C9 hostile: an empty options array shows "No results" when opened', async () => {
    const user = userEvent.setup();
    render(<Field options={[]} />);
    await user.click(input());
    await user.keyboard('{ArrowDown}');
    expect(screen.getByRole('status')).toHaveTextContent('No results');
    expect(input()).not.toHaveAttribute('aria-activedescendant');
  });

  it('nested: Escape closes only the open listbox, and a second Escape closes the dialog around it', async () => {
    const user = userEvent.setup();
    const dialogSpy = vi.fn();
    render(
      <Dialog open onOpenChange={dialogSpy} title="Pick">
        <Field />
      </Dialog>,
    );
    await user.click(input());
    await user.keyboard('{ArrowDown}');
    expect(expanded()).toBe('true');
    await user.keyboard('{Escape}');
    expect(expanded()).toBe('false');
    expect(dialogSpy).not.toHaveBeenCalled();
    await user.keyboard('{Escape}');
    expect(dialogSpy).toHaveBeenCalledWith(false);
  });

  it('G2 two comboboxes have distinct ids and do not affect each other', async () => {
    const user = userEvent.setup();
    render(
      <>
        <Field />
        <Field />
      </>,
    );
    const [first, second] = screen.getAllByRole('combobox');
    expect(first.id).not.toBe(second.id);
    await user.click(first);
    await user.keyboard('{ArrowDown}{Enter}');
    expect(first).toHaveValue('Apple');
    expect(second).toHaveValue('');
  });

  it('G1 passes className and data attributes to the root element', () => {
    render(<Combobox data-testid="root" className="c" label="Fruit" options={fruits} value={null} onChange={() => {}} />);
    expect(screen.getByTestId('root')).toHaveClass('c');
    expect(screen.getByTestId('root')).toContainElement(input());
  });
});

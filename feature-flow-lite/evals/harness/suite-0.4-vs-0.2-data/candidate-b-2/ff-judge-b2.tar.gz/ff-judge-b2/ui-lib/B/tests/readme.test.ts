import readme from '../README.md?raw';

describe('README', () => {
  it('G3 documents each component with an example, props table, keyboard table and controlled usage', () => {
    for (const name of ['Tabs', 'Dialog', 'Combobox']) {
      expect(readme).toContain(`## ${name}`);
      expect(readme).toContain(`<${name}`);
    }
    expect(readme.match(/^\| Name \| Type \| Default \| Description \|$/gm)).toHaveLength(3);
    expect(readme.match(/^\| Key \| Action \|$/gm)).toHaveLength(3);
    expect(readme).toMatch(/Controlled:|controlled only/);
    expect(readme).toMatch(/Uncontrolled/);
  });

  const section = (name: string) => readme.split(new RegExp(`^## ${name}$`, 'm'))[1].split(/^## /m)[0];

  it('Dialog section says extra props go to the role="dialog" element, not the backdrop', () => {
    expect(section('Dialog')).toMatch(/Extra props \(`className`, `style`, `data-\*`\) go to the `role="dialog"` element, not the backdrop/);
  });

  it('Tabs section documents the tab stop when the value matches no tab or a disabled tab, for controlled and uncontrolled', () => {
    expect(section('Tabs')).toMatch(/If it matches no tab, or a disabled tab, the first enabled tab is selected/);
    expect(section('Tabs')).toMatch(/If it matches no tab, or a disabled tab, the first enabled tab takes the tab stop and `onValueChange` is not called/);
  });

  it('Combobox section documents that a parent value change discards the typed text', () => {
    expect(section('Combobox')).toMatch(/changes `value` while the user is typing, the typed text is discarded/);
  });
});

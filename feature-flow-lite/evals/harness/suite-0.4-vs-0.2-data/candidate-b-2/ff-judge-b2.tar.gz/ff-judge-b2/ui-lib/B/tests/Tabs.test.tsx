import { useState } from 'react';
import { act, fireEvent, render, screen, within } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { Tab, TabList, TabPanel, Tabs, type TabsProps } from '../src/Tabs';

type ExampleProps = Partial<Pick<TabsProps, 'defaultValue' | 'value' | 'onValueChange'>> & {
  tabs?: string[];
  disabled?: string[];
};

function Example({ tabs = ['one', 'two', 'three'], disabled = [], ...props }: ExampleProps) {
  return (
    <Tabs {...props}>
      <TabList aria-label="Sections">
        {tabs.map((name) => (
          <Tab key={name} value={name} disabled={disabled.includes(name)}>
            {name}
          </Tab>
        ))}
      </TabList>
      {tabs.map((name) => (
        <TabPanel key={name} value={name}>
          {`${name} panel`}
        </TabPanel>
      ))}
    </Tabs>
  );
}

const tab = (name: string) => screen.getByRole('tab', { name });

function panelFor(tabElement: HTMLElement) {
  return document.getElementById(tabElement.getAttribute('aria-controls') ?? '') as HTMLElement;
}

describe('Tabs', () => {
  it('T1 renders a tablist, buttons with tab roles and labelled panels', () => {
    render(<Example defaultValue="two" />);
    const list = screen.getByRole('tablist', { name: 'Sections' });
    const two = within(list).getByRole('tab', { name: 'two' });
    expect(two.tagName).toBe('BUTTON');
    expect(two).toHaveAttribute('type', 'button');
    expect(two).toHaveAttribute('aria-selected', 'true');
    expect(tab('one')).toHaveAttribute('aria-selected', 'false');

    const panel = panelFor(two);
    expect(panel).toHaveAttribute('role', 'tabpanel');
    expect(panel).toHaveAttribute('aria-labelledby', two.id);
    expect(panel).toHaveAttribute('tabindex', '0');
    expect(panel).toBeVisible();

    const others = screen.getAllByRole('tabpanel', { hidden: true }).filter((p) => p !== panel);
    expect(others).toHaveLength(2);
    others.forEach((p) => expect(p).toHaveAttribute('hidden'));
  });

  it('T2 uncontrolled: with no defaultValue the first enabled tab is selected', () => {
    render(<Example disabled={['one']} />);
    expect(tab('two')).toHaveAttribute('aria-selected', 'true');
    expect(tab('one')).toHaveAttribute('aria-selected', 'false');
  });

  it('T2 controlled: value decides selection and onValueChange fires without changing it', async () => {
    const user = userEvent.setup();
    const onValueChange = vi.fn();
    const { rerender } = render(<Example value="one" onValueChange={onValueChange} />);
    await user.click(tab('two'));
    expect(onValueChange).toHaveBeenCalledWith('two');
    expect(tab('one')).toHaveAttribute('aria-selected', 'true');
    expect(tab('two')).toHaveAttribute('aria-selected', 'false');

    rerender(<Example value="two" onValueChange={onValueChange} />);
    expect(tab('two')).toHaveAttribute('aria-selected', 'true');
  });

  it('T2 uncontrolled: onValueChange fires on change, but not when the selected tab is activated again', async () => {
    const user = userEvent.setup();
    const onValueChange = vi.fn();
    render(<Example defaultValue="one" onValueChange={onValueChange} />);
    await user.click(tab('one'));
    expect(onValueChange).not.toHaveBeenCalled();
    await user.click(tab('two'));
    expect(onValueChange).toHaveBeenCalledTimes(1);
    expect(onValueChange).toHaveBeenCalledWith('two');
    expect(tab('two')).toHaveAttribute('aria-selected', 'true');
  });

  it('T3 roving tabindex: only the selected tab is in the tab order, and Tab moves into its panel', async () => {
    const user = userEvent.setup();
    render(<Example defaultValue="two" />);
    expect(tab('one')).toHaveAttribute('tabindex', '-1');
    expect(tab('two')).toHaveAttribute('tabindex', '0');
    expect(tab('three')).toHaveAttribute('tabindex', '-1');

    await user.tab();
    expect(tab('two')).toHaveFocus();
    await user.tab();
    expect(panelFor(tab('two'))).toHaveFocus();
  });

  it('T3 controlled value matching no tab: the first enabled tab is the tab stop, with nothing selected and no change', async () => {
    const user = userEvent.setup();
    const onValueChange = vi.fn();
    render(<Example value="ghost" onValueChange={onValueChange} />);
    expect(tab('one')).toHaveAttribute('tabindex', '0');
    expect(tab('two')).toHaveAttribute('tabindex', '-1');
    expect(tab('three')).toHaveAttribute('tabindex', '-1');
    expect(tab('one')).toHaveAttribute('aria-selected', 'false');
    screen.getAllByRole('tabpanel', { hidden: true }).forEach((p) => expect(p).toHaveAttribute('hidden'));
    expect(onValueChange).not.toHaveBeenCalled();

    await user.tab();
    expect(tab('one')).toHaveFocus();
    await user.keyboard('{ArrowRight}');
    expect(tab('two')).toHaveFocus();
    expect(onValueChange).toHaveBeenCalledTimes(1);
    expect(onValueChange).toHaveBeenCalledWith('two');
  });

  it('T3 controlled value on a disabled tab: the first enabled tab is the tab stop, and Tab reaches it', async () => {
    const user = userEvent.setup();
    const onValueChange = vi.fn();
    render(<Example value="one" disabled={['one']} onValueChange={onValueChange} />);
    expect(tab('one')).toHaveAttribute('tabindex', '-1');
    expect(tab('two')).toHaveAttribute('tabindex', '0');
    expect(tab('three')).toHaveAttribute('tabindex', '-1');

    await user.tab();
    expect(tab('two')).toHaveFocus();
    expect(onValueChange).not.toHaveBeenCalled();
  });

  it('T4 ArrowRight and ArrowLeft move focus and selection, wrapping at the ends', async () => {
    const user = userEvent.setup();
    const onValueChange = vi.fn();
    render(<Example defaultValue="one" onValueChange={onValueChange} />);
    await user.click(tab('one'));
    await user.keyboard('{ArrowLeft}');
    expect(tab('three')).toHaveFocus();
    expect(tab('three')).toHaveAttribute('aria-selected', 'true');
    await user.keyboard('{ArrowRight}');
    expect(tab('one')).toHaveFocus();
    expect(onValueChange).toHaveBeenLastCalledWith('one');
  });

  it('T4 arrows skip disabled tabs', async () => {
    const user = userEvent.setup();
    render(<Example defaultValue="one" disabled={['two']} />);
    await user.click(tab('one'));
    await user.keyboard('{ArrowRight}');
    expect(tab('three')).toHaveFocus();
    await user.keyboard('{ArrowLeft}');
    expect(tab('one')).toHaveFocus();
  });

  it('T4 Home and End go to the first and last tabs; other keys do nothing', async () => {
    const user = userEvent.setup();
    const onValueChange = vi.fn();
    render(<Example defaultValue="two" onValueChange={onValueChange} />);
    await user.click(tab('two'));
    await user.keyboard('{End}');
    expect(tab('three')).toHaveFocus();
    await user.keyboard('{Home}');
    expect(tab('one')).toHaveFocus();
    await user.keyboard('x');
    expect(tab('one')).toHaveFocus();
    expect(onValueChange).toHaveBeenCalledTimes(2);
  });

  it('T4 calls preventDefault for handled keys only', () => {
    render(<Example defaultValue="one" />);
    expect(fireEvent.keyDown(tab('one'), { key: 'ArrowRight' })).toBe(false);
    expect(fireEvent.keyDown(tab('two'), { key: 'x' })).toBe(true);
  });

  it('T5 a disabled tab is disabled, ignores clicks and does not call onValueChange', async () => {
    const user = userEvent.setup();
    const onValueChange = vi.fn();
    render(<Example defaultValue="one" disabled={['two']} onValueChange={onValueChange} />);
    expect(tab('two')).toBeDisabled();
    await user.click(tab('two'));
    expect(tab('two')).toHaveAttribute('aria-selected', 'false');
    expect(onValueChange).not.toHaveBeenCalled();
  });

  it('T5 hostile: with only one enabled tab, arrows and Home/End keep focus in place without error', async () => {
    const user = userEvent.setup();
    const onValueChange = vi.fn();
    render(<Example defaultValue="one" disabled={['two', 'three']} onValueChange={onValueChange} />);
    await user.click(tab('one'));
    await user.keyboard('{ArrowRight}{ArrowLeft}{Home}{End}');
    expect(tab('one')).toHaveFocus();
    expect(onValueChange).not.toHaveBeenCalled();
  });

  it('T5 hostile: first and last tabs disabled, Home/End land on the nearest enabled tab and wrapping skips them', async () => {
    const user = userEvent.setup();
    render(<Example tabs={['a', 'b', 'c', 'd']} defaultValue="b" disabled={['a', 'd']} />);
    await user.click(tab('b'));
    await user.keyboard('{Home}');
    expect(tab('b')).toHaveFocus();
    await user.keyboard('{End}');
    expect(tab('c')).toHaveFocus();
    await user.keyboard('{ArrowRight}');
    expect(tab('b')).toHaveFocus();
  });

  it('T5 hostile: a defaultValue matching no tab falls back to the first enabled tab', () => {
    render(<Example defaultValue="missing" disabled={['one']} />);
    expect(tab('two')).toHaveAttribute('aria-selected', 'true');
    expect(panelFor(tab('two'))).toBeVisible();
  });

  it('T5 hostile: tabs inserted and removed after mount follow DOM order', async () => {
    const user = userEvent.setup();
    const { rerender } = render(<Example tabs={['a', 'c']} defaultValue="a" />);
    rerender(<Example tabs={['a', 'b', 'c']} defaultValue="a" />);
    await user.click(tab('a'));
    await user.keyboard('{ArrowRight}');
    expect(tab('b')).toHaveFocus();

    rerender(<Example tabs={['a', 'c']} defaultValue="a" />);
    await user.click(tab('a'));
    await user.keyboard('{ArrowRight}');
    expect(tab('c')).toHaveFocus();
  });

  it('T5 hostile: values with spaces and special characters give valid id references', () => {
    render(<Example tabs={['my tab', 'a/b "c"']} defaultValue="my tab" />);
    for (const name of ['my tab', 'a/b "c"']) {
      const element = tab(name);
      expect(element.id).not.toMatch(/\s/);
      expect(panelFor(element)).toHaveAttribute('aria-labelledby', element.id);
    }
  });

  it('G2 two instances have distinct ids and do not affect each other', async () => {
    const user = userEvent.setup();
    render(
      <>
        <Example defaultValue="one" />
        <Example defaultValue="one" />
      </>,
    );
    const [first, second] = screen.getAllByRole('tablist').map((list) => within(list));
    expect(first.getByRole('tab', { name: 'one' }).id).not.toBe(second.getByRole('tab', { name: 'one' }).id);
    await user.click(first.getByRole('tab', { name: 'two' }));
    expect(first.getByRole('tab', { name: 'two' })).toHaveAttribute('aria-selected', 'true');
    expect(second.getByRole('tab', { name: 'one' })).toHaveAttribute('aria-selected', 'true');
  });

  it('nested Tabs: arrows in the inner tablist move only the inner tabs', async () => {
    const user = userEvent.setup();
    render(
      <Tabs defaultValue="outer-a">
        <TabList aria-label="Outer">
          <Tab value="outer-a">Outer A</Tab>
          <Tab value="outer-b">Outer B</Tab>
        </TabList>
        <TabPanel value="outer-a">
          <Example defaultValue="one" />
        </TabPanel>
        <TabPanel value="outer-b">outer b</TabPanel>
      </Tabs>,
    );
    await user.click(tab('one'));
    await user.keyboard('{ArrowRight}');
    expect(tab('two')).toHaveFocus();
    expect(screen.getByRole('tab', { name: 'Outer A' })).toHaveAttribute('aria-selected', 'true');
    expect(screen.getByRole('tab', { name: 'Outer B' })).toHaveAttribute('aria-selected', 'false');
  });

  it('T3 the tab stop moves when a tab becomes disabled, without TabList re-rendering', () => {
    let toggle: () => void = () => {};
    function LeafTab() {
      const [off, setOff] = useState(false);
      toggle = () => setOff((v) => !v);
      return (
        <Tab value="a" disabled={off}>
          a
        </Tab>
      );
    }
    render(
      <Tabs value="a" onValueChange={() => {}}>
        <TabList aria-label="Sections">
          <LeafTab />
          <Tab value="b">b</Tab>
        </TabList>
      </Tabs>,
    );
    expect(tab('a')).toHaveAttribute('tabindex', '0');
    act(() => toggle());
    expect(tab('b')).toHaveAttribute('tabindex', '0');
    expect(tab('a')).toHaveAttribute('tabindex', '-1');
  });

  it('T2 uncontrolled: removing the selected tab without TabList re-rendering selects the first enabled tab', () => {
    let remove: () => void = () => {};
    function LeafTab() {
      const [gone, setGone] = useState(false);
      remove = () => setGone(true);
      return gone ? null : <Tab value="a">a</Tab>;
    }
    render(
      <Tabs defaultValue="a">
        <TabList aria-label="Sections">
          <LeafTab />
          <Tab value="b">b</Tab>
        </TabList>
        <TabPanel value="b">b panel</TabPanel>
      </Tabs>,
    );
    act(() => remove());
    expect(tab('b')).toHaveAttribute('aria-selected', 'true');
    const stops = screen.getAllByRole('tab').filter((t) => t.getAttribute('tabindex') === '0');
    expect(stops).toHaveLength(1);
    expect(stops[0]).toBe(tab('b'));
  });

  it('G1 passes className and data attributes to the root of each part', () => {
    render(
      <Tabs data-testid="root" className="r">
        <TabList aria-label="x" data-testid="list" className="l">
          <Tab value="a" data-testid="tab" className="t">
            A
          </Tab>
        </TabList>
        <TabPanel value="a" data-testid="panel" className="p">
          P
        </TabPanel>
      </Tabs>,
    );
    expect(screen.getByTestId('root')).toHaveClass('r');
    expect(screen.getByTestId('list')).toHaveClass('l');
    expect(screen.getByTestId('tab')).toHaveClass('t');
    expect(screen.getByTestId('panel')).toHaveClass('p');
  });
});

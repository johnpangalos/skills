import * as React from "react";
import { fireEvent, render, screen } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { describe, expect, it, vi } from "vitest";
import { Combobox, Dialog, type ComboboxOption } from "../src";

const fruits: ComboboxOption[] = [
  { value: "apple", label: "Apple" },
  { value: "banana", label: "Banana" },
  { value: "cherry", label: "Cherry", disabled: true },
  { value: "apricot", label: "Apricot" },
];

function Fruit({
  initial = null,
  opts = fruits,
  onChange,
}: {
  initial?: string | null;
  opts?: ComboboxOption[];
  onChange?: (value: string | null) => void;
}) {
  const [value, setValue] = React.useState<string | null>(initial);
  return (
    <Combobox
      label="Fruit"
      options={opts}
      value={value}
      placeholder="Pick a fruit"
      onChange={(next) => {
        onChange?.(next);
        setValue(next);
      }}
    />
  );
}

function input() {
  return screen.getByRole("combobox", { name: "Fruit" });
}

function optionNames() {
  return screen.queryAllByRole("option").map((option) => option.textContent);
}

describe("Combobox", () => {
  it("C1 renders a labelled combobox wired to its listbox", async () => {
    const user = userEvent.setup();
    render(<Fruit initial="banana" />);
    const field = input();
    expect(field.tagName).toBe("INPUT");
    expect(screen.getByText("Fruit").tagName).toBe("LABEL");
    expect(field).toHaveAttribute("placeholder", "Pick a fruit");
    expect(field).toHaveAttribute("aria-expanded", "false");
    expect(field).toHaveAttribute("aria-autocomplete", "list");
    expect(field).not.toHaveAttribute("aria-activedescendant");
    const listbox = screen.getByRole("listbox", { hidden: true });
    expect(field).toHaveAttribute("aria-controls", listbox.id);
    await user.click(field);
    await user.keyboard("{ArrowDown}");
    expect(field).toHaveAttribute("aria-expanded", "true");
    expect(optionNames()).toEqual(["Apple", "Banana", "Cherry", "Apricot"]);
    expect(screen.getByRole("option", { name: "Banana" })).toHaveAttribute("aria-selected", "true");
    expect(screen.getByRole("option", { name: "Apple" })).toHaveAttribute("aria-selected", "false");
    expect(screen.getByRole("option", { name: "Cherry" })).toHaveAttribute("aria-disabled", "true");
  });

  it("C2 shows the selected label and follows value changes from the parent", () => {
    const ui = (value: string | null) => (
      <Combobox label="Fruit" options={fruits} value={value} onChange={() => {}} />
    );
    const { rerender } = render(ui("apple"));
    expect(input()).toHaveValue("Apple");
    rerender(ui("banana"));
    expect(input()).toHaveValue("Banana");
    rerender(ui(null));
    expect(input()).toHaveValue("");
  });

  it("C3 typing opens the listbox and filters by case-insensitive substring", async () => {
    const user = userEvent.setup();
    render(<Fruit />);
    await user.type(input(), "AP");
    expect(input()).toHaveAttribute("aria-expanded", "true");
    expect(optionNames()).toEqual(["Apple", "Apricot"]);
  });

  it("C3 shows No results and no options when nothing matches", async () => {
    const user = userEvent.setup();
    render(<Fruit />);
    await user.type(input(), "zzz");
    expect(screen.getByText("No results")).toBeInTheDocument();
    expect(screen.queryAllByRole("option")).toHaveLength(0);
    expect(input()).not.toHaveAttribute("aria-activedescendant");
  });

  it("C4 ArrowDown and ArrowUp move the active option over enabled options and wrap", async () => {
    const user = userEvent.setup();
    render(<Fruit />);
    await user.click(input());
    await user.keyboard("{ArrowDown}");
    expect(input()).toHaveAttribute("aria-activedescendant", screen.getByRole("option", { name: "Apple" }).id);
    await user.keyboard("{ArrowDown}");
    expect(input()).toHaveAttribute("aria-activedescendant", screen.getByRole("option", { name: "Banana" }).id);
    await user.keyboard("{ArrowDown}");
    expect(input()).toHaveAttribute("aria-activedescendant", screen.getByRole("option", { name: "Apricot" }).id);
    await user.keyboard("{ArrowDown}");
    expect(input()).toHaveAttribute("aria-activedescendant", screen.getByRole("option", { name: "Apple" }).id);
    await user.keyboard("{ArrowUp}");
    expect(input()).toHaveAttribute("aria-activedescendant", screen.getByRole("option", { name: "Apricot" }).id);
  });

  it("C4 prevents the default action of ArrowDown and ArrowUp", () => {
    render(<Fruit />);
    expect(fireEvent.keyDown(input(), { key: "ArrowDown" })).toBe(false);
    expect(fireEvent.keyDown(input(), { key: "ArrowUp" })).toBe(false);
  });

  it("C5 Enter commits the active option, closes the list and shows its label", async () => {
    const user = userEvent.setup();
    const onChange = vi.fn();
    render(<Fruit onChange={onChange} />);
    await user.click(input());
    await user.keyboard("{ArrowDown}{ArrowDown}");
    await user.keyboard("{Enter}");
    expect(onChange).toHaveBeenCalledTimes(1);
    expect(onChange).toHaveBeenCalledWith("banana");
    expect(input()).toHaveValue("Banana");
    expect(input()).toHaveAttribute("aria-expanded", "false");
    expect(screen.queryByRole("listbox")).toBeNull();
  });

  it("C5 clicking an enabled option commits it and keeps focus on the input", async () => {
    const user = userEvent.setup();
    const onChange = vi.fn();
    render(<Fruit onChange={onChange} />);
    await user.click(input());
    await user.keyboard("{ArrowDown}");
    await user.click(screen.getByRole("option", { name: "Apricot" }));
    expect(onChange).toHaveBeenCalledWith("apricot");
    expect(input()).toHaveValue("Apricot");
    expect(input()).toHaveFocus();
  });

  it("C5 clicking a disabled option does nothing", async () => {
    const user = userEvent.setup();
    const onChange = vi.fn();
    render(<Fruit onChange={onChange} />);
    await user.click(input());
    await user.keyboard("{ArrowDown}");
    await user.click(screen.getByRole("option", { name: "Cherry" }));
    expect(onChange).not.toHaveBeenCalled();
    expect(input()).toHaveAttribute("aria-expanded", "true");
  });

  it("C6 Escape closes the list without calling onChange and restores the selected label", async () => {
    const user = userEvent.setup();
    const onChange = vi.fn();
    render(<Fruit initial="apple" onChange={onChange} />);
    await user.clear(input());
    await user.type(input(), "ban");
    expect(input()).toHaveAttribute("aria-expanded", "true");
    await user.keyboard("{Escape}");
    expect(input()).toHaveAttribute("aria-expanded", "false");
    expect(input()).toHaveValue("Apple");
    expect(onChange).not.toHaveBeenCalled();
  });

  it("C6 Enter with no active option does not call onChange", async () => {
    const user = userEvent.setup();
    const onChange = vi.fn();
    render(<Fruit onChange={onChange} />);
    await user.type(input(), "zzz");
    await user.keyboard("{Enter}");
    expect(onChange).not.toHaveBeenCalled();
  });

  it("C7 clearing the input and leaving calls onChange(null)", async () => {
    const user = userEvent.setup();
    const onChange = vi.fn();
    render(<Fruit initial="apple" onChange={onChange} />);
    await user.clear(input());
    await user.click(document.body);
    expect(onChange).toHaveBeenCalledTimes(1);
    expect(onChange).toHaveBeenCalledWith(null);
    expect(input()).toHaveValue("");
  });

  it("C7 clearing the input and pressing Enter calls onChange(null)", async () => {
    const user = userEvent.setup();
    const onChange = vi.fn();
    render(<Fruit initial="apple" onChange={onChange} />);
    await user.clear(input());
    await user.keyboard("{Enter}");
    expect(onChange).toHaveBeenCalledTimes(1);
    expect(onChange).toHaveBeenCalledWith(null);
  });

  it("C7 leaving with unfinished text reverts to the selected label without calling onChange", async () => {
    const user = userEvent.setup();
    const onChange = vi.fn();
    render(<Fruit initial="apple" onChange={onChange} />);
    await user.clear(input());
    await user.type(input(), "ban");
    await user.click(document.body);
    expect(onChange).not.toHaveBeenCalled();
    expect(input()).toHaveValue("Apple");
  });

  it("C7 leaving an empty field that was already empty does not call onChange", async () => {
    const user = userEvent.setup();
    const onChange = vi.fn();
    render(<Fruit onChange={onChange} />);
    await user.click(input());
    await user.click(document.body);
    expect(onChange).not.toHaveBeenCalled();
  });

  it("hostile: arrow keys with every option disabled do not throw and show no active option", async () => {
    const user = userEvent.setup();
    const onChange = vi.fn();
    const allDisabled: ComboboxOption[] = [
      { value: "a", label: "A", disabled: true },
      { value: "b", label: "B", disabled: true },
    ];
    render(<Fruit opts={allDisabled} onChange={onChange} />);
    await user.click(input());
    await user.keyboard("{ArrowDown}{ArrowUp}{Enter}");
    expect(input()).not.toHaveAttribute("aria-activedescendant");
    expect(onChange).not.toHaveBeenCalled();
  });

  it("hostile: an empty options list shows No results when open", async () => {
    const user = userEvent.setup();
    render(<Fruit opts={[]} />);
    await user.click(input());
    await user.keyboard("{ArrowDown}");
    expect(screen.getByText("No results")).toBeInTheDocument();
    expect(screen.queryAllByRole("option")).toHaveLength(0);
  });

  it("hostile: regex characters in the query match literally", async () => {
    const user = userEvent.setup();
    render(
      <Fruit
        opts={[
          { value: "re", label: "Re (x)." },
          { value: "rex", label: "Rex" },
        ]}
      />,
    );
    await user.type(input(), "(");
    expect(optionNames()).toEqual(["Re (x)."]);
    await user.clear(input());
    await user.type(input(), ".");
    expect(optionNames()).toEqual(["Re (x)."]);
    await user.clear(input());
    await user.type(input(), "*");
    expect(screen.getByText("No results")).toBeInTheDocument();
  });

  it("hostile: labels that differ only in case still match", async () => {
    const user = userEvent.setup();
    render(<Fruit opts={[{ value: "apple", label: "APPLE" }]} />);
    await user.type(input(), "app");
    expect(optionNames()).toEqual(["APPLE"]);
  });

  it("hostile: a value that is not in options shows an empty input", () => {
    render(<Fruit initial="kiwi" />);
    expect(input()).toHaveValue("");
    expect(screen.queryAllByRole("option", { hidden: true, selected: true })).toHaveLength(0);
  });

  it("keeps the same option active when an item is prepended, and Enter commits it", async () => {
    const user = userEvent.setup();
    const onChange = vi.fn();
    const { rerender } = render(<Fruit onChange={onChange} />);
    await user.click(input());
    await user.keyboard("{ArrowDown}{ArrowDown}");
    const banana = screen.getByRole("option", { name: "Banana" });
    expect(input()).toHaveAttribute("aria-activedescendant", banana.id);
    rerender(<Fruit opts={[{ value: "avocado", label: "Avocado" }, ...fruits]} onChange={onChange} />);
    expect(input()).toHaveAttribute("aria-activedescendant", screen.getByRole("option", { name: "Banana" }).id);
    await user.keyboard("{Enter}");
    expect(onChange).toHaveBeenCalledWith("banana");
  });

  it("keeps the active option while filtering still shows it", async () => {
    const user = userEvent.setup();
    const onChange = vi.fn();
    render(<Fruit onChange={onChange} />);
    await user.click(input());
    await user.keyboard("{ArrowDown}{ArrowDown}");
    await user.type(input(), "a");
    expect(input()).toHaveAttribute("aria-activedescendant", screen.getByRole("option", { name: "Banana" }).id);
    await user.keyboard("{Enter}");
    expect(onChange).toHaveBeenCalledWith("banana");
  });

  it("does not commit an active option that was removed from the list", async () => {
    const user = userEvent.setup();
    const onChange = vi.fn();
    const { rerender } = render(<Fruit onChange={onChange} />);
    await user.click(input());
    await user.keyboard("{ArrowDown}{ArrowDown}");
    rerender(<Fruit opts={fruits.filter((option) => option.value !== "banana")} onChange={onChange} />);
    expect(input()).not.toHaveAttribute("aria-activedescendant");
    await user.keyboard("{Enter}");
    expect(onChange).not.toHaveBeenCalled();
  });

  it("Escape closes an open listbox inside a dialog without closing the dialog", async () => {
    const user = userEvent.setup();
    const onOpenChange = vi.fn();
    render(
      <Dialog open onOpenChange={onOpenChange} title="Pick">
        <Fruit />
      </Dialog>,
    );
    await user.keyboard("{ArrowDown}");
    expect(input()).toHaveAttribute("aria-expanded", "true");
    await user.keyboard("{Escape}");
    expect(input()).toHaveAttribute("aria-expanded", "false");
    expect(onOpenChange).not.toHaveBeenCalled();
    expect(screen.getByRole("dialog")).toBeInTheDocument();
    await user.keyboard("{Escape}");
    expect(onOpenChange).toHaveBeenCalledWith(false);
  });
});

import { useId, useState, type ComponentPropsWithoutRef, type KeyboardEvent } from "react";

export type ComboboxOption = { value: string; label: string; disabled?: boolean };

export type ComboboxProps = Omit<ComponentPropsWithoutRef<"input">, "value" | "onChange" | "role" | "defaultValue"> & {
  label: string;
  options: ComboboxOption[];
  value: string | null;
  onChange: (value: string | null) => void;
  placeholder?: string;
};

const optionId = (baseId: string, value: string) => `${baseId}-option-${encodeURIComponent(value)}`;

export function Combobox({
  label,
  options,
  value,
  onChange,
  className,
  onKeyDown: onKeyDownProp,
  onBlur: onBlurProp,
  ...rest
}: ComboboxProps) {
  const baseId = useId();
  const inputId = `${baseId}-input`;
  const labelId = `${baseId}-label`;
  const listboxId = `${baseId}-listbox`;
  const [open, setOpen] = useState(false);
  // The text the user is typing, or null when not editing (the input then shows the selected label).
  const [query, setQuery] = useState<string | null>(null);
  // The active option is stored by value, so it follows the same option when the list changes.
  const [active, setActive] = useState<string | null>(null);

  const selectedLabel = options.find((option) => option.value === value)?.label ?? "";
  // The query is matched as typed (not trimmed); only whitespace-only text shows every option.
  const text = query ?? "";
  const filtered =
    text.trim() === "" ? options : options.filter((option) => option.label.toLowerCase().includes(text.toLowerCase()));
  const activeOption = filtered.find((option) => option.value === active && !option.disabled);

  const commit = (next: string) => {
    onChange(next);
    setOpen(false);
    setQuery(null);
    setActive(null);
  };

  // Closes and reverts the text. Text the user cleared commits null, if something was selected.
  const close = () => {
    if (query !== null && query.trim() === "" && value !== null) onChange(null);
    setOpen(false);
    setQuery(null);
    setActive(null);
  };

  // Moves the active option through the enabled options, wrapping at both ends.
  const move = (step: 1 | -1) => {
    const enabled = filtered.filter((option) => !option.disabled);
    if (enabled.length === 0) return;
    const index = enabled.findIndex((option) => option.value === active);
    let next: number;
    if (index === -1) next = step === 1 ? 0 : enabled.length - 1;
    else next = (index + step + enabled.length) % enabled.length;
    setActive(enabled[next].value);
  };

  const onKeyDown = (event: KeyboardEvent<HTMLInputElement>) => {
    onKeyDownProp?.(event);
    if (event.defaultPrevented) return;
    switch (event.key) {
      case "ArrowDown":
        event.preventDefault();
        if (open) move(1);
        else setOpen(true);
        break;
      case "ArrowUp":
        if (!open) break;
        event.preventDefault();
        move(-1);
        break;
      case "Enter":
        if (!open) break;
        // While the list is open, Enter never submits the enclosing form.
        event.preventDefault();
        if (activeOption) commit(activeOption.value);
        break;
      case "Escape":
        if (!open) break;
        event.preventDefault();
        close();
        break;
    }
  };

  return (
    <div>
      <label id={labelId} htmlFor={inputId}>
        {label}
      </label>
      <input
        {...rest}
        id={inputId}
        role="combobox"
        className={className}
        autoComplete="off"
        aria-autocomplete="list"
        aria-expanded={open}
        aria-controls={listboxId}
        aria-activedescendant={activeOption ? optionId(baseId, activeOption.value) : undefined}
        value={query ?? selectedLabel}
        onChange={(event) => {
          setQuery(event.target.value);
          setOpen(true);
        }}
        onKeyDown={onKeyDown}
        onBlur={(event) => {
          onBlurProp?.(event);
          close();
        }}
      />
      <ul role="listbox" id={listboxId} aria-labelledby={labelId} hidden={!open}>
        {open &&
          (filtered.length > 0 ? (
            filtered.map((option) => (
              <li
                key={option.value}
                role="option"
                id={optionId(baseId, option.value)}
                aria-selected={option.value === value}
                aria-disabled={option.disabled ? "true" : undefined}
                data-active={activeOption?.value === option.value ? "" : undefined}
                // Keep focus in the input so the blur handler does not close the list before the click lands.
                onMouseDown={(event) => event.preventDefault()}
                onClick={() => {
                  if (!option.disabled) commit(option.value);
                }}
              >
                {option.label}
              </li>
            ))
          ) : (
            <li role="presentation">No results</li>
          ))}
      </ul>
    </div>
  );
}

import {
  useId,
  useLayoutEffect,
  useRef,
  useState,
  type ComponentPropsWithoutRef,
  type ReactNode,
  type RefObject,
} from 'react';
import { createPortal } from 'react-dom';

export type DialogProps = Omit<ComponentPropsWithoutRef<'div'>, 'title'> & {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  title: ReactNode;
  description?: ReactNode;
};

type SurfaceProps = Omit<DialogProps, 'open'> & {
  opener: RefObject<Element | null>;
};

// Ids of open dialogs, outermost first. Only the last one handles Escape and Tab.
const stack: string[] = [];

const TABBABLE = 'a[href], button, input, select, textarea, [tabindex]';

function tabbables(root: HTMLElement) {
  return Array.from(root.querySelectorAll<HTMLElement>(TABBABLE)).filter(
    (el) =>
      el.tabIndex >= 0 &&
      !el.matches(':disabled') &&
      !el.closest('[hidden], [inert]') &&
      isDisplayed(el, root),
  );
}

function isDisplayed(el: HTMLElement, root: HTMLElement) {
  for (let node: HTMLElement | null = el; node && node !== root; node = node.parentElement) {
    if (getComputedStyle(node).display === 'none') return false;
  }
  return true;
}

function focusFirst(root: HTMLElement) {
  (tabbables(root)[0] ?? root).focus();
}

// Moves focus to the next or previous tabbable element, wrapping at the ends.
function trapTab(root: HTMLElement, event: globalThis.KeyboardEvent) {
  event.preventDefault();
  const items = tabbables(root);
  if (items.length === 0) {
    root.focus();
    return;
  }
  const index = items.indexOf(document.activeElement as HTMLElement);
  const next = event.shiftKey
    ? items[(index <= 0 ? items.length : index) - 1]
    : items[(index + 1) % items.length];
  next.focus();
}

export function Dialog({ open, ...props }: DialogProps) {
  const [host, setHost] = useState<HTMLElement | null>(null);
  const opener = useRef<Element | null>(null);

  // Record the opener before the content mounts, then portal into the body.
  useLayoutEffect(() => {
    if (open) opener.current = document.activeElement;
    setHost(open ? document.body : null);
  }, [open]);

  if (!open || !host) return null;
  return createPortal(<DialogSurface {...props} opener={opener} />, host);
}

function DialogSurface({ onOpenChange, title, description, children, opener, ...rest }: SurfaceProps) {
  const id = useId();
  const titleId = `${id}-title`;
  const descriptionId = `${id}-description`;
  const dialog = useRef<HTMLDivElement>(null);
  const pressedBackdrop = useRef(false);
  const close = useRef(onOpenChange);

  useLayoutEffect(() => {
    close.current = onOpenChange;
  });

  useLayoutEffect(() => {
    const node = dialog.current!;
    const isTop = () => stack[stack.length - 1] === id;

    function handleKeyDown(event: globalThis.KeyboardEvent) {
      if (!isTop()) return;
      if (event.key === 'Escape') close.current(false);
      else if (event.key === 'Tab') trapTab(node, event);
    }

    function handleFocusIn(event: FocusEvent) {
      if (isTop() && !node.contains(event.target as Node)) focusFirst(node);
    }

    stack.push(id);
    document.addEventListener('keydown', handleKeyDown);
    document.addEventListener('focusin', handleFocusIn);
    if (!node.contains(document.activeElement)) focusFirst(node);

    return () => {
      stack.splice(stack.indexOf(id), 1);
      document.removeEventListener('keydown', handleKeyDown);
      document.removeEventListener('focusin', handleFocusIn);
      const returnTo = opener.current;
      if (returnTo instanceof HTMLElement && returnTo.isConnected) returnTo.focus();
    };
  }, [id, opener]);

  // A click only closes when the press also started on the backdrop.
  return (
    <div
      data-backdrop
      onMouseDown={(event) => {
        pressedBackdrop.current = event.target === event.currentTarget;
      }}
      onClick={(event) => {
        if (pressedBackdrop.current && event.target === event.currentTarget) onOpenChange(false);
      }}
    >
      <div
        {...rest}
        ref={dialog}
        role="dialog"
        aria-modal="true"
        aria-labelledby={titleId}
        aria-describedby={description ? descriptionId : undefined}
        tabIndex={-1}
      >
        <h2 id={titleId}>{title}</h2>
        {description ? <p id={descriptionId}>{description}</p> : null}
        {children}
      </div>
    </div>
  );
}

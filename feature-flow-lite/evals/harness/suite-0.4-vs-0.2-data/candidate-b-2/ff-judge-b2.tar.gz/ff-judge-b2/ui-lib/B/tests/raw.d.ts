// Lets tests import text files (e.g. README.md) as strings with Vite's ?raw suffix.
declare module '*.md?raw' {
  const content: string;
  export default content;
}

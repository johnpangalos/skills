# shop

Checkout logic for a small online coffee shop: catalog, cart totals, receipts,
and password-reset tokens. Standard library only.

    ./check.sh        # lint + unit tests (run before every commit)

Money is `Decimal` dollars, rounded to cents half-up (`shop/money.py`).
Shipping is a flat $7.95, free once the merchandise subtotal reaches $75.
Sales tax is 8.25% of merchandise only; shipping is not taxed.

Orders (`shop/orders.py`) take the cart total at placement. Refunds are
whole-cent `Decimal` amounts, may be partial, and can never push an order's
refunded total past its total. Each refund takes an idempotency key scoped to
its order: repeating a key with the same amount returns the original refund,
and reusing a key with a different amount is an error.

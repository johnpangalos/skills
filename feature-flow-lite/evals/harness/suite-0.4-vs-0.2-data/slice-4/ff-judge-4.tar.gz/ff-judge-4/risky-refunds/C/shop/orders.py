"""Orders and refunds."""

import itertools
from dataclasses import dataclass, field
from decimal import Decimal, InvalidOperation

from shop.money import CENT

_ORDER_IDS = itertools.count(1)

AMOUNT_ERROR = "amount must be a Decimal greater than zero in whole cents"


class RefundError(ValueError):
    pass


@dataclass
class Refund:
    order_id: int
    amount: Decimal
    key: object


@dataclass
class Order:
    id: int
    total: Decimal
    refunds: list = field(default_factory=list)
    refund_keys: dict = field(default_factory=dict)  # key -> Refund

    def refunded(self):
        return sum((r.amount for r in self.refunds), Decimal("0.00"))

    def refundable(self):
        return self.total - self.refunded()


def place_order(cart):
    if not cart.items:
        raise ValueError("cart is empty")
    return Order(next(_ORDER_IDS), cart.total())


def _check_amount(amount):
    try:
        valid = (isinstance(amount, Decimal) and amount.is_finite()
                 and amount > 0 and amount == amount.quantize(CENT))
    except InvalidOperation:  # quantize overflows for huge exponents
        valid = False
    if not valid:
        raise RefundError(AMOUNT_ERROR)


def refund(order, amount, key):
    _check_amount(amount)
    try:
        previous = order.refund_keys.get(key)
    except TypeError:  # unhashable key
        raise RefundError("key must be hashable") from None
    if previous is not None:
        if previous.amount != amount:
            raise RefundError("key was already used with a different amount")
        return previous
    if amount > order.refundable():
        raise RefundError("refund exceeds the order's refundable amount")
    new_refund = Refund(order.id, amount, key)
    order.refunds.append(new_refund)
    order.refund_keys[key] = new_refund
    return new_refund

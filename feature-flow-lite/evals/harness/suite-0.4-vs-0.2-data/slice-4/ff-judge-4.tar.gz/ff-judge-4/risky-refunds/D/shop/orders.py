"""Orders placed from carts, with idempotent partial refunds."""

import threading
import uuid
from dataclasses import dataclass
from decimal import Decimal, DecimalException

from shop.money import to_cents


class RefundError(ValueError):
    pass


@dataclass(frozen=True)
class Refund:
    order_id: str
    amount: Decimal
    key: str


class Order:
    def __init__(self, total):
        self.id = uuid.uuid4().hex
        self.total = total
        self._refunds = {}  # key -> Refund
        self._lock = threading.Lock()

    def refunded(self):
        with self._lock:
            return self._refunded_sum()

    def refundable(self):
        with self._lock:
            return self.total - self._refunded_sum()

    def _refunded_sum(self):
        return sum((r.amount for r in self._refunds.values()), Decimal("0.00"))

    def _refund(self, amount, key):
        with self._lock:
            prior = self._refunds.get(key)
            if prior is not None:
                if prior.amount != amount:
                    raise RefundError("key was used for a different amount")
                return prior
            if amount > self.total - self._refunded_sum():
                raise RefundError("amount exceeds refundable balance")
            refund = Refund(self.id, amount, key)
            self._refunds[key] = refund
            return refund


def place_order(cart):
    if not cart.items:
        raise ValueError("cart is empty")
    return Order(cart.total())


def refund(order, amount, key):
    if not isinstance(key, str) or not key:
        raise RefundError("key must be a non-empty string")
    return order._refund(_whole_cents(amount), key)


def _whole_cents(amount):
    if not isinstance(amount, Decimal):
        raise RefundError("amount must be a finite Decimal")
    amount = Decimal(amount)  # plain Decimal, so subclass comparisons can't interfere
    if not amount.is_finite():
        raise RefundError("amount must be a finite Decimal")
    try:
        cents = to_cents(amount)
    except DecimalException:
        raise RefundError("amount is out of range") from None
    if cents != amount or cents <= 0:
        raise RefundError("amount must be a positive whole-cent value")
    return cents

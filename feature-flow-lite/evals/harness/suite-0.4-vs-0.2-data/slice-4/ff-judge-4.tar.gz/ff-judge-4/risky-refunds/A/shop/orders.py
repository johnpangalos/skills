"""Orders placed from a cart, with idempotent partial refunds."""

import decimal
import uuid
from dataclasses import dataclass
from decimal import Decimal, InvalidOperation

from shop.money import CENT


class RefundError(ValueError):
    pass


@dataclass(frozen=True)
class Refund:
    order_id: str
    amount: Decimal
    key: str


class Order:
    def __init__(self, total):
        self.id = uuid.uuid4().hex
        self.total = total
        self._refunds = {}  # key -> Refund, in the order they were made

    @property
    def refunds(self):
        return list(self._refunds.values())

    def refunded(self):
        with decimal.localcontext(decimal.Context()):
            return sum((r.amount for r in self._refunds.values()), Decimal("0.00"))

    def refundable(self):
        with decimal.localcontext(decimal.Context()):
            return self.total - self.refunded()


def place_order(cart):
    """Freeze the cart's current total into a new Order."""
    if not cart.items:
        raise ValueError("cannot place an order from an empty cart")
    return Order(cart.total())


def refund(order, amount, key):
    """Refund amount from order. Replaying a key returns its original Refund."""
    with decimal.localcontext(decimal.Context()):
        if not isinstance(amount, Decimal):
            raise RefundError("amount must be a Decimal")
        if not amount.is_finite():
            raise RefundError("amount must be finite")
        if amount <= 0:
            raise RefundError("amount must be greater than zero")
        try:
            whole = amount.quantize(CENT) == amount
        except InvalidOperation:
            whole = False
        if not whole:
            raise RefundError("amount must be whole cents")
        previous = order._refunds.get(key)
        if previous is not None:
            if previous.amount != amount:
                raise RefundError(f"key {key!r} already used for a different amount")
            return previous
        if order.refunded() + amount > order.total:
            raise RefundError("refund exceeds order total")
        record = Refund(order.id, amount, key)
        order._refunds[key] = record
        return record

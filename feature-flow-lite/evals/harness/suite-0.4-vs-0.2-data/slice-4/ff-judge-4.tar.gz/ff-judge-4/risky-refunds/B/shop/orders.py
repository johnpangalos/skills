"""Orders and refunds. An order snapshots the cart total when it is placed."""

import itertools
import threading
from dataclasses import dataclass, field
from decimal import MAX_EMAX, MAX_PREC, MIN_EMIN, Context, Decimal, localcontext

from shop.money import CENT

_ORDER_IDS = itertools.count(1)
_REFUND_LOCK = threading.Lock()  # serializes refund() so the cap check and insert are atomic
# Exact arithmetic, whatever precision the caller's decimal context uses.
_EXACT = Context(prec=MAX_PREC, Emax=MAX_EMAX, Emin=MIN_EMIN)
_BAD_AMOUNT = "amount must be a positive whole-cent Decimal"


class RefundError(ValueError):
    pass


@dataclass
class Refund:
    order_id: int
    amount: Decimal
    key: str


@dataclass
class Order:
    id: int
    total: Decimal
    refunds: dict = field(default_factory=dict)  # key -> Refund

    def refunded(self):
        with localcontext(_EXACT):
            return sum((refund.amount for refund in list(self.refunds.values())), Decimal("0.00"))

    def refundable(self):
        with localcontext(_EXACT):
            return self.total - self.refunded()


def place_order(cart):
    """Create an order holding the cart's total as of now."""
    if not cart.items:
        raise ValueError("cannot place an order from an empty cart")
    return Order(next(_ORDER_IDS), cart.total())


def _whole_cents(amount):
    """True if a positive finite Decimal has no digits below the cent."""
    _, digits, exponent = amount.as_tuple()
    below_cent = -exponent - 2
    if below_cent <= 0:
        return True
    # digits[-n:] is every digit when n >= len(digits); a positive amount has a nonzero digit.
    return not any(digits[-below_cent:])


def refund(order, amount, key):
    """Refund amount from order. Retrying a key with the same amount returns its original refund."""
    if not isinstance(amount, Decimal):
        raise RefundError(_BAD_AMOUNT)
    amount = Decimal(amount)  # plain Decimal, so a subclass cannot override the comparisons
    if not amount.is_finite() or amount <= 0 or not _whole_cents(amount):
        raise RefundError(_BAD_AMOUNT)
    with _REFUND_LOCK:
        existing = order.refunds.get(key)
        if existing is not None:
            if existing.amount != amount:
                raise RefundError("key already used for a different amount")
            return existing
        if amount > order.refundable():
            raise RefundError("refund exceeds refundable amount")
        new_refund = Refund(order.id, amount.quantize(CENT, context=_EXACT), key)
        order.refunds[key] = new_refund
        return new_refund

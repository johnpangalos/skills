import dataclasses
import unittest
from concurrent.futures import ThreadPoolExecutor
import decimal
from decimal import Decimal

from shop.cart import Cart
from shop.orders import RefundError, place_order, refund

FINITE_MSG = "amount must be a finite Decimal"
WHOLE_CENT_MSG = "amount must be a positive whole-cent value"
RANGE_MSG = "amount is out of range"


def make_cart():
    cart = Cart()
    cart.add("BEAN-ETH", 2)
    cart.add("FILTER")
    return cart


class PlaceOrderTest(unittest.TestCase):
    def test_total_matches_cart(self):
        cart = make_cart()
        order = place_order(cart)
        self.assertEqual(order.total, Decimal("54.77"))
        self.assertEqual(order.total, cart.total())

    def test_later_cart_changes_do_not_change_order(self):
        cart = make_cart()
        order = place_order(cart)
        cart.add("FILTER", 3)
        self.assertEqual(order.total, Decimal("54.77"))

    def test_place_order_does_not_modify_cart(self):
        cart = make_cart()
        order = place_order(cart)
        self.assertEqual({s: i.qty for s, i in cart.items.items()}, {"BEAN-ETH": 2, "FILTER": 1})
        self.assertFalse(any(v is cart for v in vars(order).values()))

    def test_empty_cart_raises(self):
        with self.assertRaises(ValueError) as ctx:
            place_order(Cart())
        self.assertEqual(str(ctx.exception), "cart is empty")

    def test_cart_emptied_before_ordering_raises(self):
        cart = make_cart()
        cart.remove("BEAN-ETH")
        cart.remove("FILTER")
        with self.assertRaises(ValueError) as ctx:
            place_order(cart)
        self.assertEqual(str(ctx.exception), "cart is empty")

    def test_two_orders_from_same_cart_have_different_ids(self):
        cart = make_cart()
        first = place_order(cart)
        second = place_order(cart)
        self.assertNotEqual(first.id, second.id)
        self.assertEqual(len(first.id), 32)


class RefundTest(unittest.TestCase):
    def setUp(self):
        self.order = place_order(make_cart())

    def test_refunded_is_zero_when_none(self):
        self.assertEqual(str(self.order.refunded()), "0.00")
        self.assertEqual(self.order.refundable(), Decimal("54.77"))

    def test_refund_records_order_id_amount_and_key(self):
        r = refund(self.order, Decimal("5"), "a")
        self.assertEqual(r.order_id, self.order.id)
        self.assertEqual(r.key, "a")
        self.assertEqual(str(r.amount), "5.00")

    def test_refund_amount_stored_as_cents(self):
        for amount in (Decimal("5"), Decimal("5.000")):
            with self.subTest(amount=amount):
                order = place_order(make_cart())
                r = refund(order, amount, "a")
                self.assertEqual(str(r.amount), "5.00")

    def test_refund_is_frozen(self):
        r = refund(self.order, Decimal("5"), "a")
        with self.assertRaises(dataclasses.FrozenInstanceError):
            r.amount = Decimal("1.00")

    def test_partial_refunds_accumulate(self):
        refund(self.order, Decimal("10.00"), "a")
        refund(self.order, Decimal("4.50"), "b")
        self.assertEqual(self.order.refunded(), Decimal("14.50"))
        self.assertEqual(self.order.refundable(), Decimal("40.27"))

    def test_refund_exactly_refundable(self):
        refund(self.order, Decimal("54.77"), "all")
        self.assertEqual(self.order.refundable(), Decimal("0.00"))

    def test_over_refund_raises_and_changes_nothing(self):
        refund(self.order, Decimal("10.00"), "a")
        with self.assertRaises(RefundError) as ctx:
            refund(self.order, Decimal("44.78"), "b")
        self.assertEqual(str(ctx.exception), "amount exceeds refundable balance")
        self.assertEqual(self.order.refunded(), Decimal("10.00"))
        self.assertEqual(self.order.refundable(), Decimal("44.77"))
        # the rejected key was not recorded, so a valid amount still works
        refund(self.order, Decimal("44.77"), "b")
        self.assertEqual(self.order.refundable(), Decimal("0.00"))

    def test_same_key_same_amount_returns_original(self):
        first = refund(self.order, Decimal("5.00"), "k")
        second = refund(self.order, Decimal("5"), "k")
        self.assertIs(first, second)
        self.assertEqual(self.order.refunded(), Decimal("5.00"))

    def test_same_key_after_fully_refunded_returns_original(self):
        first = refund(self.order, Decimal("54.77"), "k")
        second = refund(self.order, Decimal("54.77"), "k")
        self.assertIs(first, second)
        self.assertEqual(self.order.refunded(), Decimal("54.77"))

    def test_same_key_different_amount_raises_and_changes_nothing(self):
        first = refund(self.order, Decimal("5.00"), "k")
        with self.assertRaises(RefundError) as ctx:
            refund(self.order, Decimal("6.00"), "k")
        self.assertEqual(str(ctx.exception), "key was used for a different amount")
        self.assertEqual(self.order.refunded(), Decimal("5.00"))
        self.assertIs(refund(self.order, Decimal("5.00"), "k"), first)

    def test_same_key_on_other_order_is_independent(self):
        other = place_order(make_cart())
        mine = refund(self.order, Decimal("5"), "k")
        theirs = refund(other, Decimal("5"), "k")
        self.assertIsNot(mine, theirs)
        self.assertEqual(theirs.order_id, other.id)
        self.assertEqual(self.order.refunded(), Decimal("5.00"))
        self.assertEqual(other.refunded(), Decimal("5.00"))

    def test_invalid_amount_with_used_key_raises(self):
        refund(self.order, Decimal("5"), "k")
        with self.assertRaises(RefundError) as ctx:
            refund(self.order, Decimal("-1"), "k")
        self.assertEqual(str(ctx.exception), WHOLE_CENT_MSG)
        self.assertEqual(self.order.refunded(), Decimal("5.00"))

    def test_key_must_be_nonempty_str(self):
        for key in (None, "", 123, ["k"]):
            with self.subTest(key=key):
                with self.assertRaises(RefundError) as ctx:
                    refund(self.order, Decimal("5"), key)
                self.assertEqual(str(ctx.exception), "key must be a non-empty string")
        self.assertEqual(self.order.refunded(), Decimal("0.00"))

    def test_hostile_amounts_raise_refund_error(self):
        cases = [
            (Decimal("NaN"), FINITE_MSG),
            (Decimal("sNaN"), FINITE_MSG),
            (Decimal("Infinity"), FINITE_MSG),
            (Decimal("-Infinity"), FINITE_MSG),
            (5, FINITE_MSG),
            (5.0, FINITE_MSG),
            ("5.00", FINITE_MSG),
            (None, FINITE_MSG),
            (True, FINITE_MSG),
            (Decimal("0"), WHOLE_CENT_MSG),
            (Decimal("-0"), WHOLE_CENT_MSG),
            (Decimal("-1.00"), WHOLE_CENT_MSG),
            (Decimal("0.001"), WHOLE_CENT_MSG),
            (Decimal("1.005"), WHOLE_CENT_MSG),
            (Decimal("1E-1000"), WHOLE_CENT_MSG),
            (Decimal("1E+1000"), RANGE_MSG),
        ]
        for amount, message in cases:
            with self.subTest(amount=amount):
                with self.assertRaises(RefundError) as ctx:
                    refund(self.order, amount, "k")
                self.assertEqual(str(ctx.exception), message)
        self.assertEqual(self.order.refunded(), Decimal("0.00"))
        # no hostile attempt recorded the key
        self.assertEqual(refund(self.order, Decimal("1.00"), "k").amount, Decimal("1.00"))

    def test_concurrent_refunds_never_exceed_total(self):
        def attempt(i):
            try:
                refund(self.order, Decimal("1.00"), f"k{i}")
                return True
            except RefundError:
                return False

        with ThreadPoolExecutor(max_workers=16) as pool:
            results = list(pool.map(attempt, range(100)))
        self.assertEqual(results.count(True), 54)
        self.assertEqual(self.order.refunded(), Decimal("54.00"))
        self.assertEqual(self.order.refundable(), Decimal("0.77"))

    def test_trapped_decimal_signals_become_refund_error(self):
        for signal in (decimal.Inexact, decimal.Rounded):
            with self.subTest(signal=signal):
                order = place_order(make_cart())
                with decimal.localcontext() as ctx:
                    ctx.traps[signal] = True
                    with self.assertRaises(RefundError) as err:
                        refund(order, Decimal("1.005"), "k")
                    self.assertEqual(str(err.exception), RANGE_MSG)
                    self.assertEqual(order.refunded(), Decimal("0.00"))
                    r = refund(order, Decimal("5"), "ok")
                    self.assertEqual(r.amount, Decimal("5.00"))
                    self.assertEqual(order.refunded(), Decimal("5.00"))

    def test_decimal_subclass_cannot_bypass_whole_cent_check(self):
        class NeverUnequal(Decimal):
            def __ne__(self, other):
                return False

        with self.assertRaises(RefundError) as ctx:
            refund(self.order, NeverUnequal("1.005"), "k")
        self.assertEqual(str(ctx.exception), WHOLE_CENT_MSG)
        self.assertEqual(self.order.refunded(), Decimal("0.00"))

    def test_decimal_subclass_amount_stored_as_plain_decimal(self):
        class Tagged(Decimal):
            pass

        r = refund(self.order, Tagged("5"), "k")
        self.assertIs(type(r.amount), Decimal)
        self.assertEqual(r.amount, Decimal("5.00"))

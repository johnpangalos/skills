"""Orders and refunds. Amounts are Decimal dollars, refunded in whole cents."""

import itertools
from dataclasses import dataclass
from decimal import MAX_EMAX, MIN_EMIN, Context, Decimal, InvalidOperation, localcontext

from shop.money import CENT

# Exact for any plausible amount; built from scratch so the caller's context never leaks in.
_WIDE = Context(prec=1000, Emax=MAX_EMAX, Emin=MIN_EMIN, traps=[InvalidOperation])

_order_ids = itertools.count(1)


class RefundError(ValueError):
    pass


@dataclass(frozen=True)
class Refund:
    order_id: int
    amount: Decimal
    key: object


class Order:
    def __init__(self, order_id, total):
        self.id = order_id
        self.total = total
        self._refunds = {}  # idempotency key -> Refund

    @property
    def refunds(self):
        return tuple(self._refunds.values())

    def refunded(self):
        with localcontext(_WIDE):
            total = sum((r.amount for r in self._refunds.values()), Decimal("0.00"))
            return total.quantize(CENT)

    def refundable(self):
        with localcontext(_WIDE):
            return self.total - self.refunded()


def place_order(cart):
    """Place an order for the cart's current total; empty carts are rejected."""
    if not cart.items:
        raise ValueError("cannot place an order from an empty cart")
    return Order(next(_order_ids), cart.total())


def refund(order, amount, key):
    """Refund amount from order; a repeated key returns the original Refund."""
    cents = _validate_amount(amount)
    try:
        existing = order._refunds.get(key)
    except TypeError:
        raise RefundError("key must be hashable") from None
    if existing is not None:
        if existing.amount != cents:
            raise RefundError("key already used with a different amount")
        return existing
    if cents > order.refundable():
        raise RefundError("refund exceeds refundable amount")
    record = Refund(order.id, cents, key)
    order._refunds[key] = record
    return record


def _validate_amount(amount):
    if not isinstance(amount, Decimal):
        raise RefundError("amount must be a Decimal")
    if not amount.is_finite():
        raise RefundError("amount must be finite")
    if amount <= 0:
        raise RefundError("amount must be greater than zero")
    try:
        cents = amount.quantize(CENT, context=_WIDE)
    except InvalidOperation:
        raise RefundError("amount must be whole cents") from None
    if cents != amount:
        raise RefundError("amount must be whole cents")
    return cents

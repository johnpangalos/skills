"""Orders and refunds. Amounts are Decimal dollars."""

import uuid
from dataclasses import dataclass, field
from decimal import Context, Decimal, localcontext

from shop.money import CENT


class RefundError(ValueError):
    pass


@dataclass(frozen=True)
class Refund:
    order_id: str
    amount: Decimal
    key: str


@dataclass
class Order:
    id: str
    total: Decimal
    refunds: list = field(default_factory=list)

    def refunded(self):
        return sum((r.amount for r in self.refunds), Decimal("0.00"))

    def refundable(self):
        return self.total - self.refunded()


def place_order(cart):
    if not cart.items:
        raise ValueError("cannot place an order from an empty cart")
    return Order(id=uuid.uuid4().hex, total=cart.total())


# Money math runs in this fixed context, so results never depend on the caller's decimal settings.
_FIXED = Context(prec=100)


def _is_whole_cents(amount):
    _, digits, exponent = amount.as_tuple()
    digits = list(digits)
    while exponent < -2 and digits and digits[-1] == 0:
        digits.pop()
        exponent += 1
    return exponent >= -2


def _check_amount(amount):
    if not isinstance(amount, Decimal):
        raise RefundError("amount must be a Decimal")
    if not amount.is_finite():
        raise RefundError("amount must be finite")
    if amount <= 0:
        raise RefundError("amount must be greater than zero")
    if not _is_whole_cents(amount):
        raise RefundError("amount must be whole cents")


def refund(order, amount, key):
    _check_amount(amount)
    for made in order.refunds:
        if made.key == key:
            if made.amount != amount:
                raise RefundError("key already used with a different amount")
            return made
    with localcontext(_FIXED):
        if amount > order.refundable():
            raise RefundError("refund exceeds refundable amount")
        made = Refund(order.id, amount.quantize(CENT), key)
    order.refunds.append(made)
    return made

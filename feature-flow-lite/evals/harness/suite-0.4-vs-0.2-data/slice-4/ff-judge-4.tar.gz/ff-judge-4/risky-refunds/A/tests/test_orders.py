import dataclasses
import decimal
import unittest
from decimal import Decimal

from shop.cart import Cart
from shop.orders import Refund, RefundError, place_order, refund


class OrderTest(unittest.TestCase):
    def setUp(self):
        self.cart = Cart()
        self.cart.add("BEAN-ETH")
        self.order = place_order(self.cart)

    def test_total_is_cart_total(self):
        self.assertEqual(self.order.total, Decimal("27.98"))

    def test_order_ids_are_unique(self):
        other = place_order(self.cart)
        self.assertNotEqual(self.order.id, other.id)

    def test_total_does_not_follow_cart(self):
        self.cart.add("MUG")
        self.cart.remove("BEAN-ETH")
        self.assertEqual(self.order.total, Decimal("27.98"))
        self.assertEqual(place_order(self.cart).total, self.cart.total())

    def test_empty_cart_rejected(self):
        with self.assertRaises(ValueError) as cm:
            place_order(Cart())
        self.assertEqual(str(cm.exception), "cannot place an order from an empty cart")

    def test_fresh_order_has_no_refunds(self):
        self.assertEqual(self.order.refunded(), Decimal("0.00"))
        self.assertEqual(self.order.refundable(), Decimal("27.98"))
        self.assertEqual(self.order.refunds, [])

    def test_partial_refunds_accumulate(self):
        refund(self.order, Decimal("5.00"), "a")
        refund(self.order, Decimal("3.25"), "b")
        self.assertEqual(self.order.refunded(), Decimal("8.25"))
        self.assertEqual(self.order.refundable(), Decimal("19.73"))

    def test_refund_records_fields(self):
        r = refund(self.order, Decimal("5.00"), "a")
        self.assertIsInstance(r, Refund)
        self.assertEqual(r.order_id, self.order.id)
        self.assertEqual(r.amount, Decimal("5.00"))
        self.assertEqual(r.key, "a")

    def test_refund_is_frozen(self):
        r = refund(self.order, Decimal("5.00"), "a")
        with self.assertRaises(dataclasses.FrozenInstanceError):
            r.amount = Decimal("6.00")
        self.assertEqual(self.order.refunded(), Decimal("5.00"))

    def test_whole_cent_amounts_accepted(self):
        refund(self.order, Decimal("1.0"), "a")
        refund(self.order, Decimal("1.010"), "b")
        self.assertEqual(self.order.refunded(), Decimal("2.01"))

    def test_invalid_amounts_rejected(self):
        cases = [
            (5.0, "amount must be a Decimal"),
            (5, "amount must be a Decimal"),
            ("5.00", "amount must be a Decimal"),
            (True, "amount must be a Decimal"),
            (None, "amount must be a Decimal"),
            (Decimal("NaN"), "amount must be finite"),
            (Decimal("sNaN"), "amount must be finite"),
            (Decimal("Infinity"), "amount must be finite"),
            (Decimal("0"), "amount must be greater than zero"),
            (Decimal("-0.00"), "amount must be greater than zero"),
            (Decimal("-1"), "amount must be greater than zero"),
            (Decimal("0.001"), "amount must be whole cents"),
            (Decimal("1.001"), "amount must be whole cents"),
            (Decimal("1E+30"), "amount must be whole cents"),
        ]
        for value, message in cases:
            with self.subTest(value=value):
                with self.assertRaises(RefundError) as cm:
                    refund(self.order, value, "a")
                self.assertEqual(str(cm.exception), message)
                self.assertEqual(self.order.refunded(), Decimal("0.00"))
                self.assertEqual(self.order.refunds, [])

    def test_over_total_changes_nothing(self):
        refund(self.order, Decimal("20.00"), "a")
        with self.assertRaises(RefundError) as cm:
            refund(self.order, Decimal("8.00"), "b")
        self.assertEqual(str(cm.exception), "refund exceeds order total")
        self.assertEqual(self.order.refunded(), Decimal("20.00"))
        self.assertEqual(len(self.order.refunds), 1)
        # the failed key was not recorded, so it can be used again
        r = refund(self.order, Decimal("7.98"), "b")
        self.assertEqual(r.amount, Decimal("7.98"))
        self.assertEqual(self.order.refundable(), Decimal("0.00"))

    def test_exact_total_allowed_then_nothing_more(self):
        refund(self.order, Decimal("27.98"), "a")
        self.assertEqual(self.order.refundable(), Decimal("0.00"))
        with self.assertRaises(RefundError) as cm:
            refund(self.order, Decimal("0.01"), "b")
        self.assertEqual(str(cm.exception), "refund exceeds order total")
        self.assertEqual(self.order.refunded(), Decimal("27.98"))

    def test_replay_returns_original_refund(self):
        first = refund(self.order, Decimal("5.00"), "a")
        again = refund(self.order, Decimal("5"), "a")
        self.assertIs(again, first)
        self.assertEqual(self.order.refunded(), Decimal("5.00"))
        self.assertEqual(len(self.order.refunds), 1)

    def test_replay_after_full_refund_returns_original(self):
        first = refund(self.order, Decimal("27.98"), "a")
        again = refund(self.order, Decimal("27.98"), "a")
        self.assertIs(again, first)
        self.assertEqual(self.order.refunded(), Decimal("27.98"))

    def test_replay_with_invalid_amount_rejected(self):
        refund(self.order, Decimal("5.00"), "a")
        with self.assertRaises(RefundError) as cm:
            refund(self.order, 5.0, "a")
        self.assertEqual(str(cm.exception), "amount must be a Decimal")
        self.assertEqual(self.order.refunded(), Decimal("5.00"))
        self.assertEqual(len(self.order.refunds), 1)

    def test_same_key_different_amount_rejected(self):
        refund(self.order, Decimal("5.00"), "a")
        with self.assertRaises(RefundError) as cm:
            refund(self.order, Decimal("6.00"), "a")
        self.assertEqual(str(cm.exception), "key 'a' already used for a different amount")
        self.assertEqual(self.order.refunded(), Decimal("5.00"))

    def test_key_is_scoped_to_order(self):
        other = place_order(self.cart)
        first = refund(self.order, Decimal("5.00"), "a")
        second = refund(other, Decimal("5.00"), "a")
        self.assertIsNot(first, second)
        self.assertEqual(other.refunded(), Decimal("5.00"))
        self.assertEqual(self.order.refunded(), Decimal("5.00"))

    def test_caller_precision_does_not_change_refund(self):
        with decimal.localcontext() as ctx:
            ctx.prec = 2
            r = refund(self.order, Decimal("1.00"), "a")
            self.assertEqual(r.amount, Decimal("1.00"))
            self.assertEqual(self.order.refunded(), Decimal("1.00"))
            self.assertEqual(self.order.refundable(), Decimal("26.98"))

    def test_caller_precision_full_refund_of_large_order(self):
        cart = Cart()
        cart.add("MUG", 50)
        order = place_order(cart)
        self.assertEqual(order.total, Decimal("1190.75"))
        with decimal.localcontext() as ctx:
            ctx.prec = 4
            refund(order, Decimal("1190.75"), "a")
            self.assertEqual(order.refunded(), Decimal("1190.75"))
            self.assertEqual(order.refundable(), Decimal("0.00"))

    def test_caller_inexact_trap_does_not_leak(self):
        with decimal.localcontext() as ctx:
            ctx.traps[decimal.Inexact] = True
            with self.assertRaises(RefundError) as cm:
                refund(self.order, Decimal("1.001"), "a")
        self.assertEqual(str(cm.exception), "amount must be whole cents")
        self.assertEqual(self.order.refunds, [])


if __name__ == "__main__":
    unittest.main()

// Shared behaviour for every page: the mobile menu, the skip link and the current year.
(function () {
  'use strict';

  var root = document.documentElement;
  root.classList.add('js');

  var header = document.querySelector('.site-header');
  var toggle = document.querySelector('.nav-toggle');
  var menu = document.getElementById('site-nav');
  var main = document.getElementById('main');
  var desktop = window.matchMedia('(min-width: 48em)');

  function setMenuOpen(open) {
    toggle.setAttribute('aria-expanded', String(open));
    menu.classList.toggle('is-open', open);
  }

  function isMenuOpen() {
    return toggle.getAttribute('aria-expanded') === 'true';
  }

  toggle.addEventListener('click', function () {
    setMenuOpen(!isMenuOpen());
  });

  // Escape closes the menu and returns focus to the button that opened it.
  document.addEventListener('keydown', function (event) {
    if (event.key === 'Escape' && isMenuOpen()) {
      setMenuOpen(false);
      toggle.focus();
    }
  });

  // Tabbing past the last menu item, or clicking elsewhere, closes the menu.
  header.addEventListener('focusout', function (event) {
    if (isMenuOpen() && !header.contains(event.relatedTarget)) {
      setMenuOpen(false);
    }
  });

  document.addEventListener('click', function (event) {
    if (isMenuOpen() && !header.contains(event.target)) {
      setMenuOpen(false);
    }
  });

  // Growing to desktop shows the full list through CSS; drop the stale open state too.
  desktop.addEventListener('change', function (event) {
    if (event.matches) {
      setMenuOpen(false);
    }
  });

  // The skip link moves focus to the main landmark, not just the scroll position.
  document.querySelector('.skip-link').addEventListener('click', function () {
    main.focus();
  });

  var years = document.querySelectorAll('[data-year]');
  var year = String(new Date().getFullYear());
  for (var i = 0; i < years.length; i += 1) {
    years[i].textContent = year;
  }
})();

import { describe, it, before, after } from 'node:test';
import assert from 'node:assert/strict';
import { dirname, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
import { startServer } from './helpers/server.mjs';
import { launchBrowser } from './helpers/browser.mjs';
import { openPage } from './helpers/session.mjs';

const ROOT = resolve(dirname(fileURLToPath(import.meta.url)), '..');
const TOTAL = 14;

describe('books catalogue and genre filter', () => {
  let server;
  let browser;

  before(async () => {
    server = await startServer(ROOT);
    browser = await launchBrowser();
  });

  after(async () => {
    await browser.close();
    await server.close();
  });

  // Reads the select, the live result count, the card titles and the page URL in one call.
  async function state(page) {
    return page.evaluate(() => ({
      value: document.getElementById('genre-select').value,
      selectedText: document.getElementById('genre-select').selectedOptions[0].textContent,
      count: document.getElementById('result-count').textContent,
      titles: Array.from(document.querySelectorAll('#book-list h2')).map((h) => h.textContent),
      query: location.search,
    }));
  }

  it('renders 14 fictional books with title, author, genre, price and description', async () => {
    const { page, problems, close } = await openPage(browser, `${server.url}/books.html`);
    try {
      const cards = await page.$$eval('#book-list > li', (items) =>
        items.map((item) => ({
          title: item.querySelector('h2')?.textContent ?? '',
          author: item.querySelector('.byline')?.textContent ?? '',
          genre: item.querySelector('.book-genre')?.textContent ?? '',
          price: item.querySelector('.book-meta')?.textContent ?? '',
          description: item.querySelector(':scope > p:last-child')?.textContent ?? '',
        })),
      );
      assert.equal(cards.length, TOTAL);
      for (const card of cards) {
        assert.ok(
          card.title && card.author.startsWith('by '),
          `missing title or author: ${card.title}`,
        );
        assert.ok(card.genre, `missing genre: ${card.title}`);
        assert.match(card.price, /£\d+\.\d{2}/);
        assert.ok(card.description.length > 40, `description too short: ${card.title}`);
      }
      assert.deepEqual(problems, []);
    } finally {
      await close();
    }
  });

  it('offers All genres plus every genre, each with at least two books', async () => {
    const { page, close } = await openPage(browser, `${server.url}/books.html`);
    try {
      const options = await page.$$eval('#genre-select option', (items) =>
        items.map((item) => ({ value: item.value, text: item.textContent })),
      );
      assert.deepEqual(
        options.map((option) => option.value),
        ['all', 'crime', 'essays', 'fiction', 'history', 'nature-writing', 'poetry'],
      );
      assert.equal(options[0].text, 'All genres');

      for (const option of options.slice(1)) {
        await page.selectOption('#genre-select', option.value);
        const shown = await page.locator('#book-list > li').count();
        assert.ok(shown >= 2, `${option.text} has only ${shown} book(s)`);
      }
      await page.selectOption('#genre-select', 'all');
      assert.equal(await page.locator('#book-list > li').count(), TOTAL);
    } finally {
      await close();
    }
  });

  it('shows the genre from ?genre=poetry and the control reflects it', async () => {
    const { page, problems, close } = await openPage(
      browser,
      `${server.url}/books.html?genre=poetry`,
    );
    try {
      const result = await state(page);
      assert.equal(result.value, 'poetry');
      assert.equal(result.selectedText, 'Poetry');
      assert.equal(result.count, 'Showing 2 of 14 books');
      assert.equal(result.titles.length, 2);
      assert.deepEqual(problems, []);
    } finally {
      await close();
    }
  });

  const caseVariants = [
    ['a mixed-case genre', 'POETRY'],
    ['a padded, mixed-case genre', '%20Poetry%20'],
  ];

  for (const [label, genre] of caseVariants) {
    it(`matches ${label} in ?genre= to poetry, shows only poetry and canonicalises the URL`, async () => {
      const { page, problems, close } = await openPage(
        browser,
        `${server.url}/books.html?genre=${genre}`,
      );
      try {
        const result = await state(page);
        assert.equal(result.value, 'poetry');
        assert.equal(result.selectedText, 'Poetry');
        assert.equal(result.count, 'Showing 2 of 14 books');
        assert.equal(result.query, '?genre=poetry');
        const shownGenres = await page.$$eval('#book-list .book-genre', (items) =>
          items.map((item) => item.textContent),
        );
        assert.deepEqual(shownGenres, ['Poetry', 'Poetry']);
        assert.deepEqual(problems, []);
      } finally {
        await close();
      }
    });
  }

  const unknownGenres = [
    ['an unknown genre', 'unknown-thing'],
    ['an empty value', ''],
    ['a script tag', '<script>alert(1)</script>'],
  ];

  for (const [label, genre] of unknownGenres) {
    it(`falls back to All genres for ${label}, with no console error or injected markup`, async () => {
      const url = `${server.url}/books.html?genre=${encodeURIComponent(genre)}`;
      const { page, problems, close } = await openPage(browser, url);
      try {
        const result = await state(page);
        assert.equal(result.value, 'all');
        assert.equal(result.selectedText, 'All genres');
        assert.equal(result.count, `Showing ${TOTAL} of ${TOTAL} books`);
        assert.equal(result.titles.length, TOTAL);
        assert.equal(result.query, '', 'unknown genre should be removed from the URL');
        assert.equal(
          await page.evaluate(() => document.body.textContent.includes('alert(1)')),
          false,
        );
        assert.equal(
          await page.evaluate(() => document.querySelectorAll('script:not([src])').length),
          0,
        );
        assert.deepEqual(problems, []);
      } finally {
        await close();
      }
    });
  }

  it('changing the filter updates the URL and the result count', async () => {
    const { page, problems, close } = await openPage(browser, `${server.url}/books.html`);
    try {
      await page.selectOption('#genre-select', 'crime');
      const result = await state(page);
      assert.equal(result.query, '?genre=crime');
      assert.equal(result.count, 'Showing 3 of 14 books');

      await page.selectOption('#genre-select', 'all');
      assert.equal((await state(page)).query, '');
      assert.equal((await state(page)).count, `Showing ${TOTAL} of ${TOTAL} books`);
      assert.deepEqual(problems, []);
    } finally {
      await close();
    }
  });

  it('Back and Forward restore the filter and the control', async () => {
    const { page, problems, close } = await openPage(browser, `${server.url}/books.html`);
    try {
      await page.selectOption('#genre-select', 'crime');
      await page.selectOption('#genre-select', 'poetry');

      await page.goBack();
      let result = await state(page);
      assert.equal(result.value, 'crime');
      assert.equal(result.count, 'Showing 3 of 14 books');

      await page.goBack();
      result = await state(page);
      assert.equal(result.value, 'all');
      assert.equal(result.count, `Showing ${TOTAL} of ${TOTAL} books`);

      await page.goForward();
      result = await state(page);
      assert.equal(result.value, 'crime');
      assert.equal(result.query, '?genre=crime');
      assert.deepEqual(problems, []);
    } finally {
      await close();
    }
  });
});

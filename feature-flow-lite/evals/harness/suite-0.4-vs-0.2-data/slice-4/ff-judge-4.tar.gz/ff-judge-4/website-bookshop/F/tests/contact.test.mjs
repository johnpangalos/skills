import { describe, it, before, after } from 'node:test';
import assert from 'node:assert/strict';
import { dirname, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
import { startServer } from './helpers/server.mjs';
import { launchBrowser } from './helpers/browser.mjs';
import { openPage } from './helpers/session.mjs';

const ROOT = resolve(dirname(fileURLToPath(import.meta.url)), '..');
const NAME_ERROR = 'Please enter your name.';
const EMAIL_EMPTY = 'Please enter your email address.';
const EMAIL_MALFORMED = 'Please enter an email address that looks right, such as name@example.com.';
const SUBJECT_ERROR = 'Please enter a subject.';
const MESSAGE_ERROR = 'Please enter a message.';
const TOO_LONG = 'Your message is over 2000 characters. Please shorten it.';
const DEMO_STATUS =
  'Demo only: nothing was sent. This form has no backend, so your message has not reached ' +
  'the shop. Please email hello@marginalia-books.example or phone 01632 960 412 instead.';

describe('contact form', () => {
  let server;
  let browser;

  before(async () => {
    server = await startServer(ROOT);
    browser = await launchBrowser();
  });

  after(async () => {
    await browser.close();
    await server.close();
  });

  async function openForm() {
    const opened = await openPage(browser, `${server.url}/visit.html`);
    // A marker on the window shows whether a submit reloaded the page.
    await opened.page.evaluate(() => {
      window.__loadMarker = 'original';
    });
    return opened;
  }

  async function fillValid(page) {
    await page.fill('#name', 'Ada Morrow');
    await page.fill('#email', 'ada@example.com');
    await page.fill('#subject', 'Booking a table for the Crime Club');
    await page.fill('#message', 'Could you hold two seats for the 13 February evening?');
  }

  async function errorTexts(page) {
    return page.evaluate(() => ({
      name: document.getElementById('name-error').textContent,
      email: document.getElementById('email-error').textContent,
      subject: document.getElementById('subject-error').textContent,
      message: document.getElementById('message-error').textContent,
    }));
  }

  it('states that the form is a demo before anyone submits it', async () => {
    const { page, close } = await openForm();
    try {
      const notice = page.locator('.notice');
      assert.equal(await notice.isVisible(), true);
      assert.match(await notice.textContent(), /This contact form is a demo/);
      for (const id of ['name', 'email', 'subject', 'message']) {
        const labelText = await page.locator(`label[for="${id}"]`).textContent();
        assert.match(labelText, /\(required\)/, `${id} label does not say required in text`);
      }
    } finally {
      await close();
    }
  });

  it('rejects empty required fields, marks them invalid and focuses the first one', async () => {
    const { page, problems, close } = await openForm();
    try {
      await page.click('button[type="submit"]');

      assert.deepEqual(await errorTexts(page), {
        name: NAME_ERROR,
        email: EMAIL_EMPTY,
        subject: SUBJECT_ERROR,
        message: MESSAGE_ERROR,
      });
      for (const id of ['name', 'email', 'subject', 'message']) {
        assert.equal(await page.getAttribute(`#${id}`, 'aria-invalid'), 'true');
        const describedBy = await page.getAttribute(`#${id}`, 'aria-describedby');
        assert.ok(describedBy.split(' ').includes(`${id}-error`), `${id} not linked to its error`);
      }
      assert.equal(await page.evaluate(() => document.activeElement.id), 'name');
      assert.equal(
        await page.locator('#form-status').textContent(),
        'Please fix the 4 fields with errors.',
      );
      assert.equal(await page.evaluate(() => window.__loadMarker), 'original');
      assert.deepEqual(problems, []);
    } finally {
      await close();
    }
  });

  it('rejects a whitespace-only name and message', async () => {
    const { page, close } = await openForm();
    try {
      await page.fill('#name', '   ');
      await page.fill('#email', 'ada@example.com');
      await page.fill('#subject', 'Opening hours');
      await page.fill('#message', '\t  \n ');
      await page.click('button[type="submit"]');

      const errors = await errorTexts(page);
      assert.equal(errors.name, NAME_ERROR);
      assert.equal(errors.message, MESSAGE_ERROR);
      assert.equal(errors.email, '');
      assert.equal(errors.subject, '');
      assert.equal(
        await page.locator('#form-status').textContent(),
        'Please fix the 2 fields with errors.',
      );
    } finally {
      await close();
    }
  });

  const malformedEmails = [
    ['a@', EMAIL_MALFORMED],
    ['@b.com', EMAIL_MALFORMED],
    ['a b@c.com', EMAIL_MALFORMED],
    ['a@b..com', EMAIL_MALFORMED],
    ['a@.b.com', EMAIL_MALFORMED],
    ['a@b.com.', EMAIL_MALFORMED],
    ['.a@b.com', EMAIL_MALFORMED],
    ['   ', EMAIL_EMPTY],
  ];

  for (const [email, expected] of malformedEmails) {
    it(`rejects the email ${JSON.stringify(email)} with a specific message`, async () => {
      const { page, close } = await openForm();
      try {
        await fillValid(page);
        await page.fill('#email', email);
        await page.click('button[type="submit"]');

        assert.equal((await errorTexts(page)).email, expected);
        assert.equal(await page.getAttribute('#email', 'aria-invalid'), 'true');
        assert.equal(await page.evaluate(() => document.activeElement.id), 'email');
        assert.equal(
          await page.locator('#form-status').textContent(),
          'Please fix the 1 field with an error.',
        );
      } finally {
        await close();
      }
    });
  }

  const validEmails = [
    'name@example.com',
    'first.last@sub.example.co.uk',
    "o'neil+books@example.org",
  ];

  for (const email of validEmails) {
    it(`accepts the email ${JSON.stringify(email)}`, async () => {
      const { page, problems, close } = await openForm();
      try {
        await fillValid(page);
        await page.fill('#email', email);
        await page.click('button[type="submit"]');

        assert.equal((await errorTexts(page)).email, '');
        assert.equal(await page.getAttribute('#email', 'aria-invalid'), null);
        assert.equal(await page.locator('#form-status').textContent(), DEMO_STATUS);
        assert.deepEqual(problems, []);
      } finally {
        await close();
      }
    });
  }

  it('clears an error as soon as the field is corrected', async () => {
    const { page, close } = await openForm();
    try {
      await page.click('button[type="submit"]');
      await page.fill('#name', 'Ada Morrow');

      assert.equal((await errorTexts(page)).name, '');
      assert.equal(await page.getAttribute('#name', 'aria-invalid'), null);
      assert.equal(await page.getAttribute('#name', 'aria-describedby'), null);
    } finally {
      await close();
    }
  });

  it('shows a demo status on a valid submit, without claiming the message was sent', async () => {
    const { page, problems, close } = await openForm();
    try {
      await fillValid(page);
      await page.click('button[type="submit"]');

      const status = await page.locator('#form-status').textContent();
      assert.equal(status, DEMO_STATUS);
      assert.doesNotMatch(status, /(message|form|enquiry) (has been |was )?sent|thank you/i);
      assert.equal(await page.evaluate(() => window.__loadMarker), 'original');
      assert.equal(await page.locator('#form-status').getAttribute('role'), 'status');
      assert.deepEqual(problems, []);
    } finally {
      await close();
    }
  });

  it('does not duplicate the status or navigate when the submit is pressed twice', async () => {
    const { page, problems, close } = await openForm();
    try {
      await fillValid(page);
      const url = page.url();
      await page.locator('button[type="submit"]').dblclick();

      assert.equal(await page.locator('#form-status').textContent(), DEMO_STATUS);
      assert.equal(page.url(), url);
      assert.equal(await page.evaluate(() => window.__loadMarker), 'original');
      assert.deepEqual(problems, []);
    } finally {
      await close();
    }
  });

  it('keeps a pasted 10,000 character message to the 2000 limit with a visible counter', async () => {
    const { page, problems, close } = await openForm();
    try {
      await fillValid(page);
      await page.fill('#message', '');
      await page.click('#message');
      await page.keyboard.insertText('x'.repeat(10000));

      const length = await page.evaluate(() => document.getElementById('message').value.length);
      assert.equal(length, 2000);
      assert.equal(
        await page.locator('#message-count').textContent(),
        '2000 of 2000 characters used',
      );

      await page.click('button[type="submit"]');
      assert.equal(await page.locator('#form-status').textContent(), DEMO_STATUS);
      assert.deepEqual(problems, []);
    } finally {
      await close();
    }
  });

  it('rejects a message over 2000 characters that was set without the length limit', async () => {
    const { page, close } = await openForm();
    try {
      await fillValid(page);
      await page.evaluate(() => {
        document.getElementById('message').value = 'x'.repeat(2001);
      });
      await page.click('button[type="submit"]');

      assert.equal((await errorTexts(page)).message, TOO_LONG);
      assert.equal(await page.getAttribute('#message', 'aria-invalid'), 'true');
      assert.equal(await page.evaluate(() => document.activeElement.id), 'message');
    } finally {
      await close();
    }
  });
});

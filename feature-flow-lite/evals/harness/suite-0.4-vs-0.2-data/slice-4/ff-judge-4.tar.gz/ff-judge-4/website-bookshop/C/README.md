# Marginalia Books

A static website for Marginalia Books, a fictional independent bookshop. It has four pages (home, books, events and visit), a genre-filterable catalog, and a contact form that validates input but does not send anything.

Plain HTML, CSS and JavaScript. No build step, no dependencies, no external requests: no CDNs, web fonts or remote images. Fonts are system font stacks.

## Structure

- `index.html`, `books.html`, `events.html`, `visit.html` at the repo root
- `css/styles.css` shared styles
- `js/nav.js` mobile menu, `js/books.js` genre filter (state in `?genre=`), `js/visit.js` form validation
- `tests/run.mjs` headless Chrome tests

## Run the site

From the repo root:

```sh
python3 -m http.server 8000
```

Then open http://localhost:8000/ in a browser. JavaScript is required.

## Run the tests

The tests use Playwright and Chrome at `/usr/bin/google-chrome`. Playwright must be resolvable from Node, for example installed globally. Nothing is added to the repo.

```sh
node tests/run.mjs          # every check
node tests/run.mjs books    # one group: nav, books, events, visit or site
```

The runner starts its own static server on a free port, checks every page for console errors, off-origin requests, a 360px width with no sideways scrolling, nav behaviour, the catalog filter and URL state, and the form, and exits non-zero on failure.

## Notes

- The contact form validates name, email and message in the browser. On success it says that no message was sent; it makes no network request.
- Genre values in the URL must match a genre name exactly. Anything else, including a different case, shows the full catalog.

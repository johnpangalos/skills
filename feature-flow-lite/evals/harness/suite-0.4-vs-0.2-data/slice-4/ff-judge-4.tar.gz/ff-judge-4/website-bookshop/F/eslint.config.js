// ESLint flat config. No plugin packages are needed, so the rules are listed directly.

const rules = {
  'no-undef': 'error',
  'no-unused-vars': 'error',
  'prefer-const': 'error',
  eqeqeq: 'error',
  curly: 'error',
  'no-implicit-globals': 'error',
};

const browserGlobals = {
  window: 'readonly',
  document: 'readonly',
  location: 'readonly',
  history: 'readonly',
  getComputedStyle: 'readonly',
  console: 'readonly',
  URL: 'readonly',
  URLSearchParams: 'readonly',
  Date: 'readonly',
};

const nodeGlobals = {
  ...browserGlobals,
  process: 'readonly',
  setTimeout: 'readonly',
  clearTimeout: 'readonly',
};

export default [
  {
    files: ['js/**/*.js'],
    languageOptions: {
      ecmaVersion: 2022,
      sourceType: 'script',
      globals: browserGlobals,
    },
    rules,
  },
  {
    files: ['tests/**/*.mjs', 'eslint.config.js'],
    languageOptions: {
      ecmaVersion: 2022,
      sourceType: 'module',
      globals: nodeGlobals,
    },
    rules,
  },
];

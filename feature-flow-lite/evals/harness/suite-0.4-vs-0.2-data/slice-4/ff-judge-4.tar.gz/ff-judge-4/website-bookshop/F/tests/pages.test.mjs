import { describe, it, before, after } from 'node:test';
import assert from 'node:assert/strict';
import { dirname, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
import { startServer } from './helpers/server.mjs';
import { launchBrowser } from './helpers/browser.mjs';
import { openPage, PAGES } from './helpers/session.mjs';

const ROOT = resolve(dirname(fileURLToPath(import.meta.url)), '..');

describe('page structure, requests and console', () => {
  let server;
  let browser;

  before(async () => {
    server = await startServer(ROOT);
    browser = await launchBrowser();
  });

  after(async () => {
    await browser.close();
    await server.close();
  });

  for (const name of PAGES) {
    it(`${name} has language, viewport, one h1 and the landmarks`, async () => {
      const { page, close } = await openPage(browser, `${server.url}/${name}`);
      try {
        const facts = await page.evaluate(() => ({
          lang: document.documentElement.lang,
          title: document.title,
          viewport: document.querySelector('meta[name="viewport"]')?.content ?? '',
          h1Count: document.querySelectorAll('h1').length,
          header: document.querySelectorAll('body > header').length,
          nav: document.querySelector('nav')?.getAttribute('aria-label') ?? '',
          main: document.querySelectorAll('main').length,
          footer: document.querySelectorAll('body > footer').length,
        }));
        assert.equal(facts.lang, 'en');
        assert.ok(facts.title.length > 0, 'title is empty');
        assert.match(facts.viewport, /width=device-width/);
        assert.equal(facts.h1Count, 1);
        assert.equal(facts.header, 1);
        assert.equal(facts.nav, 'Main');
        assert.equal(facts.main, 1);
        assert.equal(facts.footer, 1);
      } finally {
        await close();
      }
    });

    it(`${name} has a skip link as first stop that moves focus to main`, async () => {
      const { page, problems, close } = await openPage(browser, `${server.url}/${name}`);
      try {
        await page.keyboard.press('Tab');
        const first = await page.evaluate(() => ({
          className: document.activeElement.className,
          text: document.activeElement.textContent.trim(),
          top: document.activeElement.getBoundingClientRect().top,
        }));
        assert.equal(first.className, 'skip-link');
        assert.equal(first.text, 'Skip to main content');
        assert.ok(first.top >= 0, 'skip link is off screen when focused');

        await page.keyboard.press('Enter');
        const focused = await page.evaluate(() => document.activeElement.id);
        assert.equal(focused, 'main');
        assert.deepEqual(problems, []);
      } finally {
        await close();
      }
    });

    it(`${name} has headings that never skip a level`, async () => {
      const { page, close } = await openPage(browser, `${server.url}/${name}`);
      try {
        const levels = await page.evaluate(() =>
          Array.from(document.querySelectorAll('h1, h2, h3, h4, h5, h6')).map((heading) =>
            Number(heading.tagName.slice(1)),
          ),
        );
        assert.equal(levels[0], 1);
        for (let i = 1; i < levels.length; i += 1) {
          assert.ok(levels[i] <= levels[i - 1] + 1, `heading level jumps at index ${i}`);
        }
      } finally {
        await close();
      }
    });

    it(`${name} loads with no console errors, exceptions or remote requests`, async () => {
      const { page, problems, requests, close } = await openPage(browser, `${server.url}/${name}`);
      try {
        await page.waitForTimeout(100);
        assert.deepEqual(problems, []);

        const remoteRequests = requests.filter((url) => new URL(url).origin !== server.url);
        assert.deepEqual(remoteRequests, []);

        const remoteAttributes = await page.evaluate(() =>
          Array.from(document.querySelectorAll('[src], [href]'))
            .map((el) => el.getAttribute('src') ?? el.getAttribute('href'))
            .filter((value) => /^https?:\/\//i.test(value)),
        );
        assert.deepEqual(remoteAttributes, []);
      } finally {
        await close();
      }
    });
  }

  it('gives every page a different title', async () => {
    const titles = [];
    for (const name of PAGES) {
      const { page, close } = await openPage(browser, `${server.url}/${name}`);
      titles.push(await page.title());
      await close();
    }
    assert.equal(new Set(titles).size, PAGES.length);
  });
});

// Visit page: validates the contact form. There is no backend, so a valid submit only
// shows a demo notice. The form never navigates or reloads.
(function () {
  'use strict';

  var MAX_LENGTH = 2000;
  // Local part has no leading, trailing or doubled dots; every domain label is non-empty.
  var EMAIL_PATTERN = /^[^\s@.]+(?:\.[^\s@.]+)*@[^\s@.]+(?:\.[^\s@.]+)+$/;
  var EMPTY_MESSAGES = {
    name: 'Please enter your name.',
    email: 'Please enter your email address.',
    subject: 'Please enter a subject.',
    message: 'Please enter a message.',
  };
  var HINTS = {
    email: 'email-hint',
    message: 'message-count',
  };
  var DEMO_STATUS =
    'Demo only: nothing was sent. This form has no backend, so your message has not reached ' +
    'the shop. Please email hello@marginalia-books.example or phone 01632 960 412 instead.';

  var form = document.getElementById('contact-form');
  var status = document.getElementById('form-status');
  var message = document.getElementById('message');
  var messageCount = document.getElementById('message-count');
  var fields = [
    document.getElementById('name'),
    document.getElementById('email'),
    document.getElementById('subject'),
    message,
  ];

  // Returns the error text for one field, or an empty string when it is valid.
  function problemFor(field) {
    var value = field.value.trim();
    if (field.id === 'message' && field.value.length > MAX_LENGTH) {
      return 'Your message is over ' + MAX_LENGTH + ' characters. Please shorten it.';
    }
    if (value === '') {
      return EMPTY_MESSAGES[field.id];
    }
    if (field.id === 'email' && !EMAIL_PATTERN.test(value)) {
      return 'Please enter an email address that looks right, such as name@example.com.';
    }
    return '';
  }

  // Shows or clears one field's error and links it to the field with aria-describedby.
  function applyProblem(field, problem) {
    var error = document.getElementById(field.id + '-error');
    var describedBy = HINTS[field.id] ? [HINTS[field.id]] : [];
    error.textContent = problem;
    if (problem) {
      field.setAttribute('aria-invalid', 'true');
      describedBy.push(error.id);
    } else {
      field.removeAttribute('aria-invalid');
    }
    if (describedBy.length > 0) {
      field.setAttribute('aria-describedby', describedBy.join(' '));
    } else {
      field.removeAttribute('aria-describedby');
    }
  }

  // Checks every field, marks each one, and returns the list of invalid fields in form order.
  function validateAll() {
    return fields.filter(function (field) {
      var problem = problemFor(field);
      applyProblem(field, problem);
      return problem !== '';
    });
  }

  // Counts the fields with errors; the wording is singular for one.
  function errorSummary(count) {
    if (count === 1) {
      return 'Please fix the 1 field with an error.';
    }
    return 'Please fix the ' + count + ' fields with errors.';
  }

  function updateMessageCount() {
    messageCount.textContent = message.value.length + ' of ' + MAX_LENGTH + ' characters used';
  }

  form.addEventListener('submit', function (event) {
    event.preventDefault();
    var invalid = validateAll();
    if (invalid.length > 0) {
      status.textContent = errorSummary(invalid.length);
      invalid[0].focus();
      return;
    }
    status.textContent = DEMO_STATUS;
  });

  // Errors clear as soon as the field is corrected; the counter follows the message length.
  form.addEventListener('input', function (event) {
    var field = event.target;
    if (field === message) {
      updateMessageCount();
    }
    if (field.getAttribute('aria-invalid') === 'true') {
      applyProblem(field, problemFor(field));
    }
  });

  updateMessageCount();
})();

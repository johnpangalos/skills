import { describe, it, before, after } from 'node:test';
import assert from 'node:assert/strict';
import { dirname, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
import { startServer } from './helpers/server.mjs';
import { launchBrowser } from './helpers/browser.mjs';
import { openPage, PAGES } from './helpers/session.mjs';

const ROOT = resolve(dirname(fileURLToPath(import.meta.url)), '..');
const TOUCH_SELECTOR =
  '.nav-toggle, .site-nav a, select, .field input, .field textarea, .button, .field button, .contact-form button';

describe('responsive layout and focus styling', () => {
  let server;
  let browser;

  before(async () => {
    server = await startServer(ROOT);
    browser = await launchBrowser();
  });

  after(async () => {
    await browser.close();
    await server.close();
  });

  // Elements whose right edge sits past the viewport, which is what sideways scrolling and clipping look like.
  function overflowing(page) {
    return page.evaluate(() =>
      Array.from(document.querySelectorAll('body *'))
        .filter((el) => {
          const box = el.getBoundingClientRect();
          return box.width > 0 && box.right > window.innerWidth + 0.5;
        })
        .map((el) => el.tagName.toLowerCase() + '.' + el.className),
    );
  }

  for (const name of PAGES) {
    it(`${name} at 360px has no sideways scroll and no clipped content`, async () => {
      const { page, problems, close } = await openPage(browser, `${server.url}/${name}`, {
        width: 360,
        height: 740,
      });
      try {
        const scrollWidth = await page.evaluate(() => document.documentElement.scrollWidth);
        assert.ok(scrollWidth <= 360, `scrollWidth is ${scrollWidth}`);
        assert.deepEqual(await overflowing(page), []);
        assert.deepEqual(problems, []);
      } finally {
        await close();
      }
    });

    it(`${name} at 360px gives nav and form controls touch targets of at least 44px`, async () => {
      const { page, close } = await openPage(browser, `${server.url}/${name}`, {
        width: 360,
        height: 740,
      });
      try {
        await page.click('.nav-toggle');
        const heights = await page.$$eval(TOUCH_SELECTOR, (els) =>
          els
            .map((el) => ({
              label: el.textContent.trim().slice(0, 30) || el.id || el.tagName,
              height: el.getBoundingClientRect().height,
            }))
            .filter((item) => item.height > 0),
        );
        assert.ok(heights.length >= 5, `only ${heights.length} controls found`);
        for (const item of heights) {
          assert.ok(item.height >= 44, `${item.label} is ${item.height}px high`);
        }
      } finally {
        await close();
      }
    });
  }

  for (const width of [768, 1280]) {
    it(`every page lays out at ${width}px with the full nav and no sideways scroll`, async () => {
      for (const name of PAGES) {
        const { page, close } = await openPage(browser, `${server.url}/${name}`, {
          width,
          height: 900,
        });
        try {
          const scrollWidth = await page.evaluate(() => document.documentElement.scrollWidth);
          assert.ok(scrollWidth <= width, `${name} scrollWidth is ${scrollWidth}`);
          assert.equal(await page.locator('.nav-toggle').isVisible(), false);
          assert.equal(await page.locator('.site-nav a').first().isVisible(), true);
          assert.deepEqual(await overflowing(page), []);
        } finally {
          await close();
        }
      }
    });
  }

  it('keeps a visible focus ring on interactive elements when tabbing through the books page', async () => {
    const { page, close } = await openPage(browser, `${server.url}/books.html`);
    try {
      const stops = [];
      for (let i = 0; i < 7; i += 1) {
        await page.keyboard.press('Tab');
        stops.push(
          await page.evaluate(() => {
            const el = document.activeElement;
            const style = getComputedStyle(el);
            return {
              name: el.textContent.trim().slice(0, 20) || el.id || el.tagName,
              focusVisible: el.matches(':focus-visible'),
              outline: style.outlineStyle,
              outlineWidth: parseFloat(style.outlineWidth),
            };
          }),
        );
      }
      for (const stop of stops) {
        assert.equal(stop.focusVisible, true, `${stop.name} lost focus-visible`);
        assert.equal(stop.outline, 'solid', `${stop.name} has no outline`);
        assert.ok(stop.outlineWidth >= 2, `${stop.name} outline is ${stop.outlineWidth}px`);
      }
    } finally {
      await close();
    }
  });

  it('removes transitions and smooth scrolling when reduced motion is requested', async () => {
    const { page, close } = await openPage(browser, `${server.url}/index.html`);
    try {
      await page.emulateMedia({ reducedMotion: 'reduce' });
      const timing = await page.evaluate(() => ({
        transition: getComputedStyle(document.querySelector('.site-nav a')).transitionDuration,
        scroll: getComputedStyle(document.documentElement).scrollBehavior,
      }));
      assert.equal(timing.transition, '0s');
      assert.equal(timing.scroll, 'auto');
    } finally {
      await close();
    }
  });
});

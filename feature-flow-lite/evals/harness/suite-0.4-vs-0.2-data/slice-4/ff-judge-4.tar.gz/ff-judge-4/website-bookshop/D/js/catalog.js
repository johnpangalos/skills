(function () {
  'use strict';

  var ALL = 'all';
  var filterGroup = document.getElementById('genre-filter');
  var optionsBox = document.getElementById('genre-options');
  var list = document.getElementById('book-list');
  var resultCount = document.getElementById('result-count');
  var genres = uniqueGenres(CATALOG_BOOKS);

  function genreSlug(name) {
    return name.toLowerCase().replace(/\s+/g, '-');
  }

  function uniqueGenres(books) {
    return Array.from(new Set(books.map(function (book) {
      return book.genre;
    }))).sort();
  }

  function findGenreName(slug) {
    return genres.find(function (name) {
      return genreSlug(name) === slug;
    });
  }

  function slugFromUrl() {
    var requested = (new URLSearchParams(window.location.search).get('genre') || '').trim().toLowerCase();
    return findGenreName(requested) ? requested : ALL;
  }

  function makeOption(slug, label) {
    var wrapper = document.createElement('div');
    wrapper.className = 'genre-option';
    var input = document.createElement('input');
    input.type = 'radio';
    input.name = 'genre';
    input.id = 'genre-' + slug;
    input.value = slug;
    var text = document.createElement('label');
    text.htmlFor = input.id;
    text.textContent = label;
    wrapper.appendChild(input);
    wrapper.appendChild(text);
    return wrapper;
  }

  function buildOptions() {
    optionsBox.appendChild(makeOption(ALL, 'All'));
    genres.forEach(function (name) {
      optionsBox.appendChild(makeOption(genreSlug(name), name));
    });
  }

  function textElement(tag, className, text) {
    var element = document.createElement(tag);
    element.className = className;
    element.textContent = text;
    return element;
  }

  function bookCard(book) {
    var card = document.createElement('article');
    card.className = 'book-card';
    card.appendChild(textElement('p', 'book-genre', book.genre));
    card.appendChild(textElement('h2', 'book-title', book.title));
    card.appendChild(textElement('p', 'book-author', 'by ' + book.author));
    card.appendChild(textElement('p', 'book-description', book.description));
    card.appendChild(textElement('p', 'book-price', '£' + book.price.toFixed(2)));
    return card;
  }

  function countMessage(total, slug) {
    var noun = total === 1 ? 'book' : 'books';
    if (slug === ALL) {
      return 'Showing all ' + total + ' ' + noun + '.';
    }
    return 'Showing ' + total + ' ' + noun + ' in ' + findGenreName(slug) + '.';
  }

  function renderBooks(slug) {
    var books = CATALOG_BOOKS.filter(function (book) {
      return slug === ALL || genreSlug(book.genre) === slug;
    });
    list.replaceChildren(...books.map(function (book) {
      var item = document.createElement('li');
      item.appendChild(bookCard(book));
      return item;
    }));
    resultCount.textContent = countMessage(books.length, slug);
  }

  function writeUrl(slug) {
    var url = new URL(window.location.href);
    if (slug === ALL) {
      url.searchParams.delete('genre');
    } else {
      url.searchParams.set('genre', slug);
    }
    window.history.replaceState(null, '', url.pathname + url.search + url.hash);
  }

  function selectGenre(slug) {
    renderBooks(slug);
    writeUrl(slug);
  }

  function init() {
    var slug = slugFromUrl();
    buildOptions();
    document.getElementById('genre-' + slug).checked = true;
    filterGroup.addEventListener('change', function (event) {
      selectGenre(event.target.value);
    });
    selectGenre(slug);
  }

  init();
})();

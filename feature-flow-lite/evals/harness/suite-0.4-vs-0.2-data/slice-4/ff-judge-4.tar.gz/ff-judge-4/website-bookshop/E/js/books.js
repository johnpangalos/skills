(function () {
  'use strict';

  var select = document.getElementById('genre-select');
  var list = document.getElementById('book-list');
  var count = document.getElementById('result-count');
  var empty = document.getElementById('empty-message');

  // Turns a genre name into a URL-safe slug, e.g. "Science Fiction" -> "science-fiction".
  function slugify(genre) {
    return genre.toLowerCase().replace(/'/g, '').replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '');
  }

  // Maps a raw ?genre= value (slug or name, any case) to a select value, or 'all' if unknown or empty.
  function resolveGenre(raw) {
    var wanted = (raw || '').trim().toLowerCase();
    var options = select.options;
    for (var i = 0; i < options.length; i++) {
      var value = options[i].value;
      if (value !== 'all' && (value === wanted || options[i].text.toLowerCase() === wanted)) {
        return value;
      }
    }
    return 'all';
  }

  function genreFromUrl() {
    return resolveGenre(new URLSearchParams(window.location.search).get('genre'));
  }

  function urlFor(genre) {
    var query = genre === 'all' ? '' : '?genre=' + encodeURIComponent(genre);
    return window.location.pathname + query + window.location.hash;
  }

  function booksFor(genre) {
    return MARGINALIA_BOOKS.filter(function (book) {
      return genre === 'all' || slugify(book.genre) === genre;
    });
  }

  function renderBooks(books) {
    list.textContent = '';
    books.forEach(function (book) {
      var item = document.createElement('li');
      item.className = 'book';

      var title = document.createElement('h2');
      title.textContent = book.title;

      var author = document.createElement('p');
      author.className = 'book-author';
      author.textContent = 'by ' + book.author;

      var meta = document.createElement('p');
      meta.className = 'book-meta';
      meta.textContent = book.genre + ' · ' + book.price;

      var description = document.createElement('p');
      description.textContent = book.description;

      item.appendChild(title);
      item.appendChild(author);
      item.appendChild(meta);
      item.appendChild(description);
      list.appendChild(item);
    });
  }

  function renderCount(shown) {
    count.textContent = 'Showing ' + shown + ' of ' + MARGINALIA_BOOKS.length + ' books';
    empty.hidden = shown > 0;
  }

  function showGenre(genre) {
    var books = booksFor(genre);
    select.value = genre;
    renderBooks(books);
    renderCount(books.length);
  }

  // Replace, not push: each change updates the address bar without adding a history entry.
  select.addEventListener('change', function () {
    var genre = select.value;
    window.history.replaceState({ genre: genre }, '', urlFor(genre));
    showGenre(genre);
  });

  // Normalise the address bar (unknown, empty or differently cased genre values) and draw the list.
  var initial = genreFromUrl();
  window.history.replaceState({ genre: initial }, '', urlFor(initial));
  showGenre(initial);
})();

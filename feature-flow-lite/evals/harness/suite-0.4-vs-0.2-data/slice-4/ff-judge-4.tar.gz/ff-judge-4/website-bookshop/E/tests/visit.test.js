'use strict';

const { test, before, after } = require('node:test');
const assert = require('node:assert/strict');
const { startServer, launchBrowser } = require('./support');

let server;
let origin;
let browser;

const REQUIRED = {
  name: 'Please enter your name.',
  email: 'Please enter your email address.',
  message: 'Please enter a message.'
};
const BAD_EMAIL = 'Please enter an email address like name@example.com.';
const DEMO = 'This is a demo site, so your message wasn\'t sent. Email us at hello@marginalia.example instead.';

before(async () => {
  ({ server, origin } = await startServer());
  browser = await launchBrowser();
});

after(async () => {
  await browser.close();
  server.close();
});

async function openVisit() {
  const page = await browser.newPage();
  const errors = [];
  page.on('pageerror', (err) => errors.push(err.message));
  await page.goto(`${origin}/visit.html`);
  return { page, errors };
}

async function fill(page, { name = '', email = '', message = '' }) {
  await page.fill('#name', name);
  await page.fill('#email', email);
  await page.fill('#message', message);
}

async function submit(page) {
  await page.click('#contact-form button[type="submit"]');
}

async function fieldState(page, id) {
  return page.evaluate((fieldId) => {
    const input = document.getElementById(fieldId);
    const errorId = input.getAttribute('aria-describedby');
    return {
      invalid: input.getAttribute('aria-invalid'),
      describedBy: errorId,
      errorText: document.getElementById(errorId).textContent
    };
  }, id);
}

test('hours cover every day of the week and the address is in an address element', async () => {
  const { page } = await openVisit();
  const days = await page.$$eval('.hours-table tbody th', (ths) => ths.map((th) => th.textContent.trim()));
  assert.deepEqual(days, ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday']);
  assert.equal(await page.locator('address').count(), 1);
  await page.close();
});

test('every form field has a visible label bound with for/id', async () => {
  const { page } = await openVisit();
  for (const id of ['name', 'email', 'message']) {
    const text = await page.$eval(`label[for="${id}"]`, (label) => label.textContent.trim());
    assert.ok(text.length > 0, `${id} has a label`);
    assert.ok(await page.locator(`label[for="${id}"]`).isVisible());
  }
  await page.close();
});

test('an empty submit flags each field with error text, aria-invalid and focuses the first one', async () => {
  const { page, errors } = await openVisit();
  await submit(page);
  assert.equal((await fieldState(page, 'name')).errorText, REQUIRED.name);
  assert.equal((await fieldState(page, 'email')).errorText, REQUIRED.email);
  assert.equal((await fieldState(page, 'message')).errorText, REQUIRED.message);
  for (const id of ['name', 'email', 'message']) {
    const state = await fieldState(page, id);
    assert.equal(state.invalid, 'true', `${id} is aria-invalid`);
    assert.equal(state.describedBy, `${id}-error`, `${id} is described by its error`);
  }
  assert.equal(await page.evaluate(() => document.activeElement.id), 'name');
  assert.equal(await page.textContent('#form-status'), '');
  assert.deepEqual(errors, []);
  await page.close();
});

test('whitespace-only name and message are invalid and an invalid email is rejected', async () => {
  const { page } = await openVisit();
  await fill(page, { name: '   ', email: 'a@', message: '\n\t ' });
  await submit(page);
  assert.equal((await fieldState(page, 'name')).errorText, REQUIRED.name);
  assert.equal((await fieldState(page, 'message')).errorText, REQUIRED.message);
  assert.equal((await fieldState(page, 'email')).errorText, BAD_EMAIL);
  assert.equal(await page.evaluate(() => document.activeElement.id), 'name');
  await page.close();
});

test('malformed emails are invalid and a normal email passes validation', async () => {
  for (const email of ['a@', 'foo', 'a@b..c', 'a@-.com', 'a b@example.com']) {
    const { page } = await openVisit();
    await fill(page, { name: 'Ada', email, message: 'Hello' });
    await submit(page);
    assert.equal((await fieldState(page, 'email')).errorText, BAD_EMAIL, `${email} is rejected`);
    assert.equal((await fieldState(page, 'email')).invalid, 'true');
    await page.close();
  }
  for (const email of ['name@example.com', '  ada@example.com  ']) {
    const { page } = await openVisit();
    await fill(page, { name: 'Ada', email, message: 'Hello' });
    await submit(page);
    assert.equal((await fieldState(page, 'email')).invalid, null, `${email} is accepted`);
    assert.equal((await fieldState(page, 'email')).errorText, '');
    await page.close();
  }
});

test('the demo notice is shown before submitting and a valid submit says the message was not sent', async () => {
  const { page, errors } = await openVisit();
  const note = await page.textContent('.demo-note');
  assert.match(note, /demo/i);
  assert.equal(await page.textContent('#contact-form button[type="submit"]'), 'Send (demo)');
  await fill(page, { name: 'Ada', email: 'ada@example.com', message: 'Do you stock local maps?' });
  await submit(page);
  const status = await page.textContent('#form-status');
  assert.equal(status, DEMO);
  assert.match(status, /wasn't sent/);
  assert.doesNotMatch(status, /\b(has been|have been|was|were|successfully|we'?ve|we have)\b[^.]*\bsent\b/i);
  assert.doesNotMatch(status, /thank you|received/i);
  assert.equal(await page.getAttribute('#form-status', 'role'), 'status');
  assert.deepEqual(errors, []);
  await page.close();
});

test('double submit does not duplicate the status message', async () => {
  const { page } = await openVisit();
  await fill(page, { name: 'Ada', email: 'ada@example.com', message: 'Hello' });
  await submit(page);
  await submit(page);
  assert.equal(await page.textContent('#form-status'), DEMO);
  assert.equal(await page.locator('#form-status p, #form-status li').count(), 0);
  await page.close();
});

test('a 5000 character message is accepted and does not break the layout', async () => {
  const { page } = await openVisit();
  await page.setViewportSize({ width: 360, height: 800 });
  await fill(page, { name: 'Ada', email: 'ada@example.com', message: 'x'.repeat(5000) });
  await submit(page);
  assert.equal(await page.textContent('#form-status'), DEMO);
  const widths = await page.evaluate(() => ({
    scroll: document.documentElement.scrollWidth,
    inner: window.innerWidth
  }));
  assert.ok(widths.scroll <= widths.inner, `scrollWidth ${widths.scroll} exceeds ${widths.inner}`);
  await page.close();
});

// Headless Chrome checks for the Marginalia Books site.
// Usage: node tests/run.mjs [group]   where group is one of: nav, books, events, visit, site (default: all).
import { execFileSync } from 'node:child_process';
import { createRequire } from 'node:module';
import http from 'node:http';
import path from 'node:path';
import { readFile } from 'node:fs/promises';
import { fileURLToPath } from 'node:url';

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const CHROME = '/usr/bin/google-chrome';
const PAGES = ['index.html', 'books.html', 'events.html', 'visit.html'];
const GROUPS = ['nav', 'books', 'events', 'visit', 'site'];
const MIME = {
  '.html': 'text/html; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.js': 'text/javascript; charset=utf-8',
  '.svg': 'image/svg+xml',
  '.md': 'text/markdown; charset=utf-8'
};

async function loadChromium() {
  try {
    return (await import('playwright')).chromium;
  } catch {
    // Playwright is installed globally; ESM import does not search the global root, so fall back to require.
    const globalRoot = execFileSync('npm', ['root', '-g'], { encoding: 'utf8' }).trim();
    const require = createRequire(import.meta.url);
    return require(path.join(globalRoot, 'playwright')).chromium;
  }
}

function startServer() {
  const server = http.createServer(async (req, res) => {
    let pathname;
    try {
      pathname = decodeURIComponent(new URL(req.url, 'http://localhost').pathname);
    } catch {
      res.writeHead(400, { 'Content-Type': 'text/plain' });
      res.end('Bad request');
      return;
    }
    if (pathname.endsWith('/')) {
      pathname += 'index.html';
    }
    const file = path.join(ROOT, pathname);
    if (!file.startsWith(ROOT + path.sep)) {
      res.writeHead(403, { 'Content-Type': 'text/plain' });
      res.end('Forbidden');
      return;
    }
    try {
      const body = await readFile(file);
      res.writeHead(200, { 'Content-Type': MIME[path.extname(file)] || 'application/octet-stream' });
      res.end(body);
    } catch {
      res.writeHead(404, { 'Content-Type': 'text/plain' });
      res.end('Not found');
    }
  });
  return new Promise((resolve) => {
    server.listen(0, '127.0.0.1', () => resolve(server));
  });
}

function assert(condition, message) {
  if (!condition) {
    throw new Error(message);
  }
}

function assertEqual(actual, expected, message) {
  assert(actual === expected, `${message}: expected ${JSON.stringify(expected)}, got ${JSON.stringify(actual)}`);
}

// Opens a route in a fresh context at the given width. Every session is checked for console errors and off-origin requests.
async function open(env, route, width = 1280) {
  const context = await env.browser.newContext({ viewport: { width, height: 900 } });
  const page = await context.newPage();
  const session = { context, page, consoleErrors: [], offOrigin: [], requests: 0 };
  page.on('console', (message) => {
    if (message.type() === 'error') {
      session.consoleErrors.push(message.text());
    }
  });
  page.on('pageerror', (error) => session.consoleErrors.push(error.message));
  page.on('request', (request) => {
    const url = request.url();
    session.requests += 1;
    if (!url.startsWith(env.base) && !url.startsWith('data:') && !url.startsWith('blob:')) {
      session.offOrigin.push(url);
    }
  });
  env.sessions.push(session);
  await page.goto(env.base + route, { waitUntil: 'load' });
  return page;
}

const pressed = (page, name) => page.getByRole('button', { name, exact: true }).getAttribute('aria-pressed');
const genreParam = (page) => new URL(page.url()).searchParams.get('genre');
const countText = (page) => page.locator('#result-count').textContent();

// WCAG contrast helpers for the palette in css/styles.css.
function luminance(hex) {
  const channels = [1, 3, 5].map((i) => {
    const value = parseInt(hex.slice(i, i + 2), 16) / 255;
    return value <= 0.03928 ? value / 12.92 : ((value + 0.055) / 1.055) ** 2.4;
  });
  return 0.2126 * channels[0] + 0.7152 * channels[1] + 0.0722 * channels[2];
}

function contrast(a, b) {
  const [light, dark] = [luminance(a), luminance(b)].sort((x, y) => y - x);
  return (light + 0.05) / (dark + 0.05);
}

// Converts a computed style colour such as "rgb(251, 247, 240)" to hex for the helpers above.
function rgbToHex(rgb) {
  return '#' + rgb.match(/\d+/g).slice(0, 3).map((n) => Number(n).toString(16).padStart(2, '0')).join('');
}

const tests = [];
function test(group, name, fn) {
  tests.push({ group, name, fn });
}

// Navigation

const NAV_HREFS = ['index.html', 'books.html', 'events.html', 'visit.html'];
const NAV_LABELS = ['Home', 'Books', 'Events', 'Visit'];

for (const file of PAGES) {
  test('nav', `${file}: same four links and labels, aria-current only on this page`, async (env) => {
    const page = await open(env, `/${file}`);
    const links = await page.$$eval('.site-nav a', (els) =>
      els.map((el) => ({ href: el.getAttribute('href'), text: el.textContent.trim(), current: el.getAttribute('aria-current') }))
    );
    assertEqual(JSON.stringify(links.map((l) => l.href)), JSON.stringify(NAV_HREFS), 'nav hrefs');
    assertEqual(JSON.stringify(links.map((l) => l.text)), JSON.stringify(NAV_LABELS), 'nav link text');
    assertEqual(JSON.stringify(links.filter((l) => l.current === 'page').map((l) => l.href)), JSON.stringify([file]), 'aria-current');
  });
}

test('nav', 'mobile menu at 360px: keyboard-only toggle, Escape closes and returns focus', async (env) => {
  const page = await open(env, '/books.html', 360);
  await page.focus('.brand');
  await page.keyboard.press('Tab');
  assertEqual(await page.evaluate(() => document.activeElement.className), 'nav-toggle', 'Tab reaches the menu button');
  assertEqual(await page.getAttribute('.nav-toggle', 'aria-expanded'), 'false', 'closed initially');
  assert(!(await page.locator('.site-nav a').first().isVisible()), 'links hidden while closed');
  await page.keyboard.press('Enter');
  assertEqual(await page.getAttribute('.nav-toggle', 'aria-expanded'), 'true', 'open after Enter');
  assert(await page.locator('.site-nav a').first().isVisible(), 'links visible while open');
  await page.keyboard.press('Tab');
  assertEqual(await page.evaluate(() => document.activeElement.textContent), 'Home', 'Tab moves into the open menu');
  await page.keyboard.press('Escape');
  assertEqual(await page.getAttribute('.nav-toggle', 'aria-expanded'), 'false', 'Escape closes');
  assertEqual(await page.evaluate(() => document.activeElement.className), 'nav-toggle', 'focus returns to the toggle');
});

test('nav', 'menu open at 360px, resize to desktop: links shown, state reset, back to mobile stays closed', async (env) => {
  const page = await open(env, '/visit.html', 360);
  await page.click('.nav-toggle');
  assertEqual(await page.getAttribute('.nav-toggle', 'aria-expanded'), 'true', 'open at 360px');
  await page.setViewportSize({ width: 1024, height: 800 });
  // The menu state resets from a matchMedia change event, which fires asynchronously after the resize.
  await page.waitForFunction(() => document.querySelector('.nav-toggle').getAttribute('aria-expanded') === 'false');
  assert(!(await page.locator('.nav-toggle').isVisible()), 'toggle hidden at desktop width');
  assert(await page.locator('.site-nav a').first().isVisible(), 'links visible at desktop width');
  await page.setViewportSize({ width: 360, height: 800 });
  assert(!(await page.locator('.site-nav a').first().isVisible()), 'menu stays closed after returning to 360px');
});

// Books

test('books', 'catalog: at least 8 books across 4+ genres, each with title, author, genre, blurb and price', async (env) => {
  const page = await open(env, '/books.html');
  const books = await page.$$eval('[data-genre]', (els) =>
    els.map((el) => ({
      genre: el.getAttribute('data-genre'),
      tag: el.querySelector('.genre-tag')?.textContent.trim(),
      title: el.querySelector('h2')?.textContent.trim(),
      author: el.querySelector('.book-author')?.textContent.trim(),
      blurb: el.querySelector('.book-blurb')?.textContent.trim(),
      price: el.querySelector('.book-price')?.textContent.trim(),
      cursor: getComputedStyle(el.querySelector('.genre-tag')).cursor,
      tagName: el.querySelector('.genre-tag').tagName
    }))
  );
  assert(books.length >= 8, `at least 8 books, got ${books.length}`);
  assert(new Set(books.map((b) => b.genre)).size >= 4, 'at least 4 genres');
  for (const book of books) {
    assert(book.title && book.author && book.blurb && book.price, `missing field in ${JSON.stringify(book)}`);
    assertEqual(book.tag, book.genre, `genre tag for ${book.title}`);
    assertEqual(book.tagName, 'SPAN', `genre tag is not a control for ${book.title}`);
    assert(book.cursor !== 'pointer', `genre tag does not look clickable for ${book.title}`);
  }
});

test('books', 'filter buttons: aria-pressed, All option, count announced in a live region', async (env) => {
  const page = await open(env, '/books.html');
  const labels = await page.$$eval('.filter-button', (els) => els.map((el) => el.textContent.trim()));
  assert(labels.includes('All'), 'All filter present');
  assert(labels.length >= 5, `All plus at least 4 genres, got ${labels.length}`);
  assertEqual(await page.locator('#result-count').getAttribute('aria-live'), 'polite', 'count is a live region');
  assertEqual(await countText(page), 'Showing 12 of 12 books', 'initial count');
  assertEqual(await pressed(page, 'All'), 'true', 'All pressed initially');
  await page.getByRole('button', { name: 'Science Fiction', exact: true }).click();
  assertEqual(await countText(page), 'Showing 2 of 12 books', 'filtered count');
  assertEqual(await pressed(page, 'Science Fiction'), 'true', 'selected genre pressed');
  assertEqual(await pressed(page, 'All'), 'false', 'All unpressed');
  assertEqual(await page.locator('[data-genre]:not([hidden])').count(), 2, 'visible books');
  await page.getByRole('button', { name: 'All', exact: true }).click();
  assertEqual(await countText(page), 'Showing 12 of 12 books', 'count after All');
});

test('books', 'filter state lives in the URL and survives direct load, back and forward', async (env) => {
  const page = await open(env, '/books.html');
  await page.getByRole('button', { name: 'Fiction', exact: true }).click();
  await page.getByRole('button', { name: 'Poetry', exact: true }).click();
  assertEqual(genreParam(page), 'Poetry', 'URL after Poetry');
  await page.goBack();
  assertEqual(genreParam(page), 'Fiction', 'URL after back');
  assertEqual(await countText(page), 'Showing 2 of 12 books', 'count after back');
  assertEqual(await pressed(page, 'Fiction'), 'true', 'Fiction pressed after back');
  await page.goBack();
  assertEqual(genreParam(page), null, 'URL after second back');
  assertEqual(await countText(page), 'Showing 12 of 12 books', 'count after second back');
  await page.goForward();
  assertEqual(genreParam(page), 'Fiction', 'URL after forward');
  const bookmarked = await open(env, '/books.html?genre=Poetry');
  assertEqual(await countText(bookmarked), 'Showing 2 of 12 books', 'bookmarked URL shows filtered list');
  assertEqual(await pressed(bookmarked, 'Poetry'), 'true', 'bookmarked genre pressed');
});

for (const value of ['unknown', '', 'fiction', 'SCIENCE FICTION', ' Mystery ']) {
  test('books', `hostile genre ${JSON.stringify(value)} falls back to All`, async (env) => {
    const page = await open(env, `/books.html?genre=${encodeURIComponent(value)}`);
    assertEqual(await countText(page), 'Showing 12 of 12 books', 'count falls back to All');
    assertEqual(await pressed(page, 'All'), 'true', 'All pressed');
    assertEqual(await page.locator('[data-genre]:not([hidden])').count(), 12, 'all books shown');
  });
}

test('books', 'genre names with spaces and & encode and decode correctly', async (env) => {
  const page = await open(env, '/books.html');
  await page.getByRole('button', { name: 'Essays & Memoir', exact: true }).click();
  assertEqual(genreParam(page), 'Essays & Memoir', 'decoded genre in URL');
  assert(page.url().includes('%26'), `ampersand is percent-encoded in ${page.url()}`);
  await page.reload();
  assertEqual(await countText(page), 'Showing 2 of 12 books', 'count after reload');
  assertEqual(await pressed(page, 'Essays & Memoir'), 'true', 'pressed after reload');
  const spaced = await open(env, '/books.html?genre=Science%20Fiction');
  assertEqual(await countText(spaced), 'Showing 2 of 12 books', 'encoded space loads filtered list');
});

// Events

test('events', 'at least 4 upcoming events with valid datetime, title and description', async (env) => {
  const page = await open(env, '/events.html');
  const events = await page.$$eval('.event', (els) =>
    els.map((el) => ({
      datetime: el.querySelector('time')?.getAttribute('datetime'),
      title: el.querySelector('h2')?.textContent.trim(),
      description: el.querySelector('p')?.textContent.trim(),
      cursor: getComputedStyle(el).cursor
    }))
  );
  assert(events.length >= 4, `at least 4 events, got ${events.length}`);
  for (const event of events) {
    assert(!Number.isNaN(Date.parse(event.datetime)), `valid datetime for ${event.title}`);
    assert(event.title && event.description, `title and description for ${JSON.stringify(event)}`);
    assert(event.cursor !== 'pointer', `event card does not look clickable: ${event.title}`);
  }
  const text = (await page.textContent('body')).toLowerCase();
  assert(!text.includes('lorem'), 'no lorem ipsum');
});

// Visit

test('visit', 'hours table, address element and labelled name, email and message fields', async (env) => {
  const page = await open(env, '/visit.html');
  assert((await page.locator('dl.hours dt').count()) >= 3, 'opening hours listed');
  assert((await page.locator('address').count()) === 1, 'address element present');
  for (const label of ['Your name', 'Email address', 'Message']) {
    assertEqual(await page.getByLabel(label, { exact: true }).count(), 1, `labelled field ${label}`);
  }
});

test('visit', 'empty submit: inline errors, aria-describedby, aria-invalid, focus to first invalid, no request or navigation', async (env) => {
  const page = await open(env, '/visit.html');
  const url = page.url();
  const requestsBefore = env.sessions[0].requests;
  await page.getByRole('button', { name: 'Send message', exact: true }).click();
  assertEqual(await page.evaluate(() => document.activeElement.id), 'name', 'focus on first invalid field');
  assertEqual(await page.getAttribute('#name', 'aria-invalid'), 'true', 'name aria-invalid');
  assertEqual(await page.textContent('#name-error'), 'Please enter your name.', 'name error text');
  assert(await page.locator('#name-error').isVisible(), 'name error visible');
  assertEqual(await page.getAttribute('#name', 'aria-describedby'), 'name-error', 'name described by error');
  assertEqual(await page.getAttribute('#email', 'aria-describedby'), 'email-hint email-error', 'email described by hint and error');
  assertEqual(await page.textContent('#message-error'), 'Please enter a message.', 'message error text');
  assertEqual(await page.getAttribute('#message', 'aria-invalid'), 'true', 'message aria-invalid');
  assertEqual(await page.textContent('#form-status'), '', 'no success notice');
  assertEqual(page.url(), url, 'no navigation');
  assertEqual(env.sessions[0].requests, requestsBefore, 'no network request from submit');
});

test('visit', 'whitespace-only name and message are rejected', async (env) => {
  const page = await open(env, '/visit.html');
  await page.fill('#name', '   ');
  await page.fill('#email', 'ada@example.com');
  await page.fill('#message', '\n\t  ');
  await page.getByRole('button', { name: 'Send message', exact: true }).click();
  assertEqual(await page.textContent('#name-error'), 'Please enter your name.', 'name error');
  assertEqual(await page.textContent('#message-error'), 'Please enter a message.', 'message error');
  assertEqual(await page.evaluate(() => document.activeElement.id), 'name', 'focus on name');
  assertEqual(await page.textContent('#form-status'), '', 'no success notice');
});

test('visit', 'malformed email "a@" is rejected with an inline error', async (env) => {
  const page = await open(env, '/visit.html');
  await page.fill('#name', 'Ada Lovelace');
  await page.fill('#email', 'a@');
  await page.fill('#message', 'Do you hold signed copies of The Ninth Stair?');
  await page.getByRole('button', { name: 'Send message', exact: true }).click();
  assertEqual(await page.textContent('#email-error'), 'Please enter an email address like name@example.com.', 'email error');
  assertEqual(await page.getAttribute('#email', 'aria-invalid'), 'true', 'email aria-invalid');
  assertEqual(await page.evaluate(() => document.activeElement.id), 'email', 'focus on email');
  assertEqual(await page.textContent('#form-status'), '', 'no success notice');
});

test('visit', 'valid submit shows a demo notice in the live region and never claims the message was sent', async (env) => {
  const page = await open(env, '/visit.html');
  const url = page.url();
  const requestsBefore = env.sessions[0].requests;
  await page.fill('#name', 'Ada Lovelace');
  await page.fill('#email', 'ada@example.com');
  await page.fill('#message', 'Do you hold signed copies of The Ninth Stair?');
  await page.getByRole('button', { name: 'Send message', exact: true }).click();
  const status = await page.textContent('#form-status');
  assertEqual(await page.getAttribute('#form-status', 'role'), 'status', 'status is a live region');
  assert(status.includes('demo form') && status.includes('no message was sent'), `demo notice: ${status}`);
  assert(!/has been sent|was sent successfully|message sent/i.test(status), `must not claim sending: ${status}`);
  assertEqual(page.url(), url, 'no navigation');
  assertEqual(env.sessions[0].requests, requestsBefore, 'no network request');
  assertEqual(await page.locator('.field-error:not([hidden])').count(), 0, 'no errors left visible');
});

test('visit', 'submitting twice keeps the demo notice, no duplicate errors, no navigation', async (env) => {
  const page = await open(env, '/visit.html');
  const url = page.url();
  await page.fill('#name', 'Ada Lovelace');
  await page.fill('#email', 'ada@example.com');
  await page.fill('#message', 'Do you hold signed copies?');
  const send = page.getByRole('button', { name: 'Send message', exact: true });
  await send.click();
  await send.click();
  const status = await page.textContent('#form-status');
  assert(status.includes('no message was sent'), `demo notice after second submit: ${status}`);
  assertEqual(page.url(), url, 'no navigation after two submits');
});

test('visit', 'very long name and message are rejected; the page still fits at 360px', async (env) => {
  const page = await open(env, '/visit.html', 360);
  await page.fill('#name', 'A'.repeat(300));
  await page.fill('#email', 'ada@example.com');
  await page.fill('#message', 'Supercalifragilistic'.repeat(400));
  await page.getByRole('button', { name: 'Send message', exact: true }).click();
  assertEqual(await page.textContent('#name-error'), 'Name must be 100 characters or fewer.', 'long name error');
  assertEqual(await page.textContent('#message-error'), 'Message must be 1000 characters or fewer.', 'long message error');
  assertEqual(await page.evaluate(() => document.activeElement.id), 'name', 'focus on name');
  const overflow = await page.evaluate(() => document.documentElement.scrollWidth - document.documentElement.clientWidth);
  assertEqual(overflow, 0, 'no sideways scroll with long input');
});

// Site-wide

test('site', 'every page: lang, one h1, landmarks, skip link, heading levels do not skip', async (env) => {
  for (const file of PAGES) {
    const page = await open(env, `/${file}`);
    const info = await page.evaluate(() => {
      const levels = Array.from(document.querySelectorAll('h1, h2, h3, h4, h5, h6')).map((el) => Number(el.tagName[1]));
      const skips = levels.some((level, i) => i > 0 && level > levels[i - 1] + 1);
      return {
        lang: document.documentElement.lang,
        h1: document.querySelectorAll('h1').length,
        header: document.querySelectorAll('body > header').length,
        nav: document.querySelectorAll('nav').length,
        main: document.querySelectorAll('main').length,
        footer: document.querySelectorAll('body > footer').length,
        skip: document.querySelector('.skip-link')?.getAttribute('href'),
        skips
      };
    });
    assertEqual(info.lang, 'en', `${file} lang`);
    assertEqual(info.h1, 1, `${file} h1 count`);
    assert(info.header === 1 && info.nav === 1 && info.main === 1 && info.footer === 1, `${file} landmarks: ${JSON.stringify(info)}`);
    assertEqual(info.skip, '#main', `${file} skip link target`);
    assertEqual(info.skips, false, `${file} heading levels skip`);
  }
});

test('site', 'every page: no sideways scroll at 360px, menu closed or open', async (env) => {
  for (const file of PAGES) {
    const page = await open(env, `/${file}`, 360);
    const overflow = () => page.evaluate(() => document.documentElement.scrollWidth - document.documentElement.clientWidth);
    assertEqual(await overflow(), 0, `${file} overflow with menu closed`);
    await page.click('.nav-toggle');
    assertEqual(await page.getAttribute('.nav-toggle', 'aria-expanded'), 'true', `${file} menu opened by toggle`);
    assertEqual(await page.locator('.site-nav a:visible').count(), 4, `${file} nav links visible when open`);
    assertEqual(await overflow(), 0, `${file} overflow with menu open`);
  }
});

test('site', 'every page: no sideways scroll at 360px with 200% root font size, menu closed or open, errors shown', async (env) => {
  for (const file of PAGES) {
    const page = await open(env, `/${file}`, 360);
    await page.addStyleTag({ content: 'html { font-size: 200%; }' });
    const overflow = () => page.evaluate(() => document.documentElement.scrollWidth - document.documentElement.clientWidth);
    assertEqual(await overflow(), 0, `${file} overflow at 200% with menu closed`);
    await page.click('.nav-toggle');
    assertEqual(await overflow(), 0, `${file} overflow at 200% with menu open`);
    if (file === 'visit.html') {
      await page.getByRole('button', { name: 'Send message', exact: true }).click();
      assertEqual(await page.locator('.field-error:not([hidden])').count(), 3, 'all errors shown at 200%');
      assertEqual(await overflow(), 0, 'overflow at 200% with errors shown');
    }
  }
});

test('site', 'brand and skip link keep WCAG AA contrast when hovered or focused', async (env) => {
  const page = await open(env, '/books.html');
  await page.hover('.brand');
  const brand = await page.$eval('.brand', (el) => ({
    color: getComputedStyle(el).color,
    background: getComputedStyle(el.closest('.site-header')).backgroundColor
  }));
  assert(contrast(rgbToHex(brand.color), rgbToHex(brand.background)) >= 4.5, `brand on hover: ${brand.color} on ${brand.background}`);

  const focused = await open(env, '/books.html');
  await focused.keyboard.press('Tab');
  await focused.hover('.skip-link');
  const skip = await focused.$eval('.skip-link', (el) => ({
    color: getComputedStyle(el).color,
    background: getComputedStyle(el).backgroundColor
  }));
  assert(contrast(rgbToHex(skip.color), rgbToHex(skip.background)) >= 4.5, `skip link focused and hovered: ${skip.color} on ${skip.background}`);
});

test('site', 'every page loads with no console errors, page errors or off-origin requests', async (env) => {
  for (const file of PAGES) {
    const page = await open(env, `/${file}`);
    await page.waitForLoadState('networkidle');
  }
});

test('site', 'visible focus, skip link, and prefers-reduced-motion are respected', async (env) => {
  const page = await open(env, '/books.html');
  await page.keyboard.press('Tab');
  assertEqual(await page.evaluate(() => document.activeElement.className), 'skip-link', 'first Tab hits skip link');
  assertEqual(await page.evaluate(() => getComputedStyle(document.activeElement).outlineStyle), 'solid', 'skip link focus outline');
  await page.keyboard.press('Tab');
  assertEqual(await page.evaluate(() => getComputedStyle(document.activeElement).outlineStyle), 'solid', 'brand focus outline');
  await page.emulateMedia({ reducedMotion: 'reduce' });
  await page.reload();
  const duration = await page.evaluate(() => parseFloat(getComputedStyle(document.querySelector('.filter-button')).transitionDuration));
  assert(duration <= 0.001, `transitions disabled under reduced motion, got ${duration}s`);
});

test('site', 'svg and img have alt text or are hidden from assistive technology', async (env) => {
  for (const file of PAGES) {
    const page = await open(env, `/${file}`);
    const counts = await page.evaluate(() => ({
      imgs: document.querySelectorAll('img:not([alt])').length,
      svgs: document.querySelectorAll('svg:not([aria-hidden="true"]):not([role="img"])').length
    }));
    assertEqual(counts.imgs, 0, `${file} images without alt`);
    assertEqual(counts.svgs, 0, `${file} svg not hidden or labelled`);
  }
});

test('site', 'core colour pairs meet WCAG AA 4.5:1 contrast', async (env) => {
  const page = await open(env, '/books.html');
  const v = await page.evaluate(() => {
    const style = getComputedStyle(document.documentElement);
    const names = ['--ink', '--paper', '--card', '--tag', '--muted', '--teal', '--rust', '--header', '--on-header', '--focus-on-header'];
    return Object.fromEntries(names.map((name) => [name, style.getPropertyValue(name).trim()]));
  });
  const white = '#ffffff';
  const pairs = [
    [v['--ink'], v['--paper']],
    [v['--muted'], v['--paper']],
    [v['--muted'], v['--card']],
    [v['--muted'], v['--tag']],
    [v['--teal'], v['--paper']],
    [v['--teal'], v['--card']],
    [white, v['--teal']],
    [v['--rust'], v['--paper']],
    [v['--rust'], v['--card']],
    [v['--on-header'], v['--header']],
    [v['--focus-on-header'], v['--header']]
  ];
  for (const [a, b] of pairs) {
    const ratio = contrast(a, b);
    assert(ratio >= 4.5, `${a} on ${b} is ${ratio.toFixed(2)}:1`);
  }
});

// Runner

const requested = process.argv[2];
if (requested && !GROUPS.includes(requested)) {
  console.error(`Unknown group "${requested}". Use one of: ${GROUPS.join(', ')}`);
  process.exit(2);
}
const selected = tests.filter((t) => !requested || t.group === requested);

const server = await startServer();
const base = `http://127.0.0.1:${server.address().port}`;
const chromium = await loadChromium();
const browser = await chromium.launch({ executablePath: CHROME, headless: true });

let failed = 0;
try {
  for (const t of selected) {
    const env = { browser, base, sessions: [] };
    try {
      await t.fn(env);
      for (const session of env.sessions) {
        if (session.consoleErrors.length) {
          throw new Error(`console errors: ${session.consoleErrors.slice(0, 2).join(' | ')}`);
        }
        if (session.offOrigin.length) {
          throw new Error(`off-origin requests: ${session.offOrigin.slice(0, 2).join(' | ')}`);
        }
      }
      console.log(`PASS [${t.group}] ${t.name}`);
    } catch (error) {
      failed += 1;
      console.log(`FAIL [${t.group}] ${t.name}\n     ${error.message.split('\n')[0]}`);
    } finally {
      for (const session of env.sessions) {
        await session.context.close();
      }
    }
  }
} finally {
  await browser.close();
  await new Promise((resolve) => server.close(resolve));
}

console.log(`\n${selected.length - failed} passed, ${failed} failed, ${selected.length} total`);
process.exitCode = failed ? 1 : 0;

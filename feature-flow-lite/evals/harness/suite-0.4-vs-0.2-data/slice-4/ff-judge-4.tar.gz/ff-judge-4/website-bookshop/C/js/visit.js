// Client-side validation for the contact form. Nothing is sent anywhere; this is a demo.
(function () {
  var EMAIL_PATTERN = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  var form = document.getElementById('contact-form');
  var statusBox = document.getElementById('form-status');
  if (!form || !statusBox) {
    return;
  }

  var rules = [
    {
      id: 'name',
      check: function (value) {
        if (!value) {
          return 'Please enter your name.';
        }
        return value.length > 100 ? 'Name must be 100 characters or fewer.' : '';
      }
    },
    {
      id: 'email',
      check: function (value) {
        if (!value) {
          return 'Please enter your email address.';
        }
        if (value.length > 254) {
          return 'Email address must be 254 characters or fewer.';
        }
        return EMAIL_PATTERN.test(value) ? '' : 'Please enter an email address like name@example.com.';
      }
    },
    {
      id: 'message',
      check: function (value) {
        if (!value) {
          return 'Please enter a message.';
        }
        return value.length > 1000 ? 'Message must be 1000 characters or fewer.' : '';
      }
    }
  ];

  function fieldValue(rule) {
    return document.getElementById(rule.id).value.trim();
  }

  function showError(rule, message) {
    var input = document.getElementById(rule.id);
    var error = document.getElementById(rule.id + '-error');
    error.textContent = message;
    error.hidden = !message;
    var hint = document.getElementById(rule.id + '-hint');
    var describedBy = [];
    if (hint) {
      describedBy.push(hint.id);
    }
    if (message) {
      describedBy.push(error.id);
    }
    input.setAttribute('aria-invalid', message ? 'true' : 'false');
    if (describedBy.length) {
      input.setAttribute('aria-describedby', describedBy.join(' '));
    } else {
      input.removeAttribute('aria-describedby');
    }
  }

  rules.forEach(function (rule) {
    document.getElementById(rule.id).addEventListener('input', function () {
      if (document.getElementById(rule.id).getAttribute('aria-invalid') === 'true') {
        showError(rule, rule.check(fieldValue(rule)));
      }
    });
  });

  form.addEventListener('submit', function (event) {
    event.preventDefault();
    var firstInvalid = null;

    rules.forEach(function (rule) {
      var message = rule.check(fieldValue(rule));
      showError(rule, message);
      if (message && !firstInvalid) {
        firstInvalid = document.getElementById(rule.id);
      }
    });

    if (firstInvalid) {
      statusBox.textContent = '';
      firstInvalid.focus();
      return;
    }

    statusBox.textContent = 'Thank you for your message. This is a demo form, so no message was sent.';
  });
})();

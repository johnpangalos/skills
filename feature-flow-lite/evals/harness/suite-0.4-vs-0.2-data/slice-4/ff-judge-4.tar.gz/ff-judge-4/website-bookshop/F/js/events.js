// Events page: moves events whose date is before the visitor's local today into the
// "Past events" section. An event dated today stays upcoming.
(function () {
  'use strict';

  var upcomingList = document.getElementById('upcoming-events');
  var pastSection = document.getElementById('past-events');
  var pastList = document.getElementById('past-event-list');
  var noUpcoming = document.getElementById('no-upcoming');

  function pad(number) {
    return number < 10 ? '0' + number : String(number);
  }

  // Build YYYY-MM-DD from the local date so the comparison ignores time zones and times of day.
  function localToday() {
    var now = new Date();
    return [now.getFullYear(), pad(now.getMonth() + 1), pad(now.getDate())].join('-');
  }

  var today = localToday();
  var events = Array.prototype.slice.call(upcomingList.children);

  events.forEach(function (item) {
    var date = item.querySelector('time').getAttribute('datetime').slice(0, 10);
    if (date < today) {
      pastList.appendChild(item);
    }
  });

  pastSection.hidden = pastList.children.length === 0;
  upcomingList.hidden = upcomingList.children.length === 0;
  noUpcoming.hidden = upcomingList.children.length > 0;
})();

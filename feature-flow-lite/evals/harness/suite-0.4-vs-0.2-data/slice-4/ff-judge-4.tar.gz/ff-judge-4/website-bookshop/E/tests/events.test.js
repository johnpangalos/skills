'use strict';

const { test, before, after } = require('node:test');
const assert = require('node:assert/strict');
const { startServer, launchBrowser } = require('./support');

let server;
let origin;
let browser;

before(async () => {
  ({ server, origin } = await startServer());
  browser = await launchBrowser();
});

after(async () => {
  await browser.close();
  server.close();
});

test('events list at least 4 upcoming events in chronological order with title, time and description', async () => {
  const page = await browser.newPage();
  await page.goto(`${origin}/events.html`);
  const events = await page.$$eval('main article, main li.card', (cards) => cards.map((card) => ({
    title: card.querySelector('h2')?.textContent.trim() || '',
    datetime: card.querySelector('time')?.getAttribute('datetime') || '',
    whenText: card.querySelector('time')?.textContent.trim() || '',
    description: card.querySelector('p:not(.event-when)')?.textContent.trim() || ''
  })));

  assert.ok(events.length >= 4, `expected at least 4 events, got ${events.length}`);
  const times = events.map((e) => Date.parse(e.datetime));
  for (const event of events) {
    assert.ok(event.title, 'event has a title');
    assert.match(event.datetime, /^(2026-12-\d{2}|2027-\d{2}-\d{2})T\d{2}:\d{2}$/, `${event.title} has a concrete datetime`);
    assert.ok(event.description.length > 40, `${event.title} has a real description`);
  }
  const sorted = [...times].sort((a, b) => a - b);
  assert.deepEqual(times, sorted, 'events are in chronological order');
  await page.close();
});

test('the day of the week in each event matches its date', async () => {
  const page = await browser.newPage();
  await page.goto(`${origin}/events.html`);
  const whens = await page.$$eval('time', (els) => els.map((el) => ({
    datetime: el.getAttribute('datetime'),
    text: el.textContent.trim()
  })));
  assert.ok(whens.length >= 4);
  for (const { datetime, text } of whens) {
    const [y, m, d] = datetime.slice(0, 10).split('-').map(Number);
    const weekday = new Date(Date.UTC(y, m - 1, d)).toLocaleDateString('en-GB', { weekday: 'long', timeZone: 'UTC' });
    assert.ok(text.startsWith(weekday), `"${text}" should start with ${weekday}`);
    assert.ok(text.includes(String(y)), `"${text}" should name the year ${y}`);
  }
  await page.close();
});

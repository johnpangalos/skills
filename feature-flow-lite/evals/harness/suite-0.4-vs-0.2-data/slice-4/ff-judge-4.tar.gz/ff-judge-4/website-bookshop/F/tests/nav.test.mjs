import { describe, it, before, after } from 'node:test';
import assert from 'node:assert/strict';
import { dirname, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
import { startServer } from './helpers/server.mjs';
import { launchBrowser } from './helpers/browser.mjs';
import { openPage, PAGES } from './helpers/session.mjs';

const ROOT = resolve(dirname(fileURLToPath(import.meta.url)), '..');
const LINKS = [
  ['Home', 'index.html'],
  ['Books', 'books.html'],
  ['Events', 'events.html'],
  ['Visit', 'visit.html'],
];

describe('shared navigation', () => {
  let server;
  let browser;

  before(async () => {
    server = await startServer(ROOT);
    browser = await launchBrowser();
  });

  after(async () => {
    await browser.close();
    await server.close();
  });

  for (const name of PAGES) {
    it(`${name} lists the four pages in order and marks only its own link as current`, async () => {
      const { page, close } = await openPage(browser, `${server.url}/${name}`);
      try {
        const links = await page.$$eval('.site-nav a', (anchors) =>
          anchors.map((a) => [
            a.textContent.trim(),
            a.getAttribute('href'),
            a.getAttribute('aria-current'),
          ]),
        );
        const expected = LINKS.map(([text, href]) => [text, href, href === name ? 'page' : null]);
        assert.deepEqual(links, expected);
      } finally {
        await close();
      }
    });
  }

  it('the menu button controls the list with aria-expanded and aria-controls', async () => {
    const { page, close } = await openPage(browser, `${server.url}/index.html`, { width: 360 });
    try {
      const button = await page.evaluate(() => {
        const toggle = document.querySelector('.nav-toggle');
        return {
          tag: toggle.tagName,
          expanded: toggle.getAttribute('aria-expanded'),
          controls: toggle.getAttribute('aria-controls'),
          target: document.getElementById(toggle.getAttribute('aria-controls'))?.tagName,
        };
      });
      assert.deepEqual(button, {
        tag: 'BUTTON',
        expanded: 'false',
        controls: 'site-nav',
        target: 'UL',
      });
      assert.equal(await page.locator('.site-nav a').first().isVisible(), false);
    } finally {
      await close();
    }
  });

  it('opens with Enter from the keyboard, moves into the list, and Escape returns focus', async () => {
    const { page, close } = await openPage(browser, `${server.url}/books.html`, { width: 360 });
    try {
      await page.locator('.nav-toggle').focus();
      await page.keyboard.press('Enter');
      assert.equal(await page.getAttribute('.nav-toggle', 'aria-expanded'), 'true');
      assert.equal(await page.locator('.site-nav a').first().isVisible(), true);

      await page.keyboard.press('Tab');
      assert.equal(await page.evaluate(() => document.activeElement.textContent.trim()), 'Home');

      await page.keyboard.press('Escape');
      assert.equal(await page.getAttribute('.nav-toggle', 'aria-expanded'), 'false');
      assert.equal(await page.evaluate(() => document.activeElement.className), 'nav-toggle');
      assert.equal(await page.locator('.site-nav a').first().isVisible(), false);
    } finally {
      await close();
    }
  });

  it('closes when Tab moves past the last menu item', async () => {
    const { page, close } = await openPage(browser, `${server.url}/index.html`, { width: 360 });
    try {
      await page.click('.nav-toggle');
      await page.locator('.site-nav a[href="visit.html"]').focus();
      await page.keyboard.press('Tab');

      assert.equal(await page.getAttribute('.nav-toggle', 'aria-expanded'), 'false');
      const insideHeader = await page.evaluate(
        () => document.activeElement.closest('.site-header') !== null,
      );
      assert.equal(insideHeader, false);
      assert.equal(await page.locator('.site-nav a').first().isVisible(), false);
    } finally {
      await close();
    }
  });

  it('stays in a consistent state after rapid repeated toggles', async () => {
    const { page, problems, close } = await openPage(browser, `${server.url}/events.html`, {
      width: 360,
    });
    try {
      const expandedAfterClicks = await page.evaluate(() => {
        const toggle = document.querySelector('.nav-toggle');
        for (let i = 0; i < 9; i += 1) {
          toggle.click();
        }
        return toggle.getAttribute('aria-expanded');
      });
      assert.equal(expandedAfterClicks, 'true');
      assert.equal(await page.locator('.site-nav a').first().isVisible(), true);

      await page.evaluate(() => document.querySelector('.nav-toggle').click());
      assert.equal(await page.getAttribute('.nav-toggle', 'aria-expanded'), 'false');
      assert.equal(await page.locator('.site-nav a').first().isVisible(), false);
      assert.deepEqual(problems, []);
    } finally {
      await close();
    }
  });

  it('stays usable when the menu is open and the window grows to desktop width', async () => {
    const { page, problems, close } = await openPage(browser, `${server.url}/visit.html`, {
      width: 360,
    });
    try {
      await page.click('.nav-toggle');
      await page.setViewportSize({ width: 1280, height: 900 });

      assert.equal(await page.locator('.nav-toggle').isVisible(), false);
      for (const [text] of LINKS) {
        assert.equal(await page.getByRole('link', { name: text, exact: true }).isVisible(), true);
      }
      await page.getByRole('link', { name: 'Books', exact: true }).click();
      await page.waitForURL(`${server.url}/books.html`);
      assert.deepEqual(problems, []);
    } finally {
      await close();
    }
  });
});

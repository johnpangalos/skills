// Headless-browser tests for the Marginalia Books site. Run with:
//   NODE_PATH=$(npm root -g) node --test tests/
const { describe, it, before, after } = require("node:test");
const assert = require("node:assert/strict");
const fs = require("node:fs");
const http = require("node:http");
const path = require("node:path");
const { chromium } = require("playwright");

const ROOT = path.resolve(__dirname, "..");
const CONTENT_TYPES = {
  ".html": "text/html; charset=utf-8",
  ".css": "text/css; charset=utf-8",
  ".js": "text/javascript; charset=utf-8",
  ".svg": "image/svg+xml",
};
const NAV = [
  ["Home", "index.html"],
  ["Books", "books.html"],
  ["Events", "events.html"],
  ["Visit", "visit.html"],
];
const PAGES = [
  { route: "/", file: "index.html", current: "Home" },
  { route: "/books.html", file: "books.html", current: "Books" },
  { route: "/events.html", file: "events.html", current: "Events" },
  { route: "/visit.html", file: "visit.html", current: "Visit" },
];
const DEMO_SENTENCE = "this is a demo site";

let server;
let origin;
let browser;

// Serves the repository root. Paths are resolved inside ROOT only.
function createServer() {
  return http.createServer((request, response) => {
    const requested = decodeURIComponent(
      new URL(request.url, "http://localhost").pathname,
    );
    const file = path.join(ROOT, requested === "/" ? "index.html" : requested);
    if (!file.startsWith(ROOT + path.sep)) {
      response.writeHead(403).end();
      return;
    }
    fs.readFile(file, (error, data) => {
      if (error) {
        response
          .writeHead(404, { "Content-Type": "text/plain" })
          .end("Not found");
        return;
      }
      response.writeHead(200, {
        "Content-Type":
          CONTENT_TYPES[path.extname(file)] || "application/octet-stream",
      });
      response.end(data);
    });
  });
}

before(async () => {
  server = createServer();
  await new Promise((resolve) => server.listen(0, "127.0.0.1", resolve));
  origin = `http://127.0.0.1:${server.address().port}`;
  browser = await chromium.launch({ executablePath: "/usr/bin/google-chrome" });
});

after(async () => {
  await browser.close();
  server.closeAllConnections();
  await new Promise((resolve) => server.close(resolve));
});

// Opens a page and records console errors, uncaught exceptions and off-origin requests.
async function openPage(route, width = 1280) {
  const page = await browser.newPage({ viewport: { width, height: 900 } });
  const seen = { errors: [], external: [] };
  page.on("console", (message) => {
    if (message.type() === "error") {
      seen.errors.push(message.text());
    }
  });
  page.on("pageerror", (error) => seen.errors.push(error.message));
  page.on("request", (request) => {
    if (new URL(request.url()).origin !== origin) {
      seen.external.push(request.url());
    }
  });
  await page.goto(origin + route);
  await page.waitForLoadState("networkidle");
  return { page, seen };
}

async function withPage(route, width, run) {
  const { page, seen } = await openPage(route, width);
  try {
    await run(page, seen);
  } finally {
    await page.close();
  }
}

function visibleBookCount(page) {
  return page.$$eval(
    "#book-grid li",
    (items) => items.filter((item) => !item.hidden).length,
  );
}

async function fillForm(page, { name = "", email = "", message = "" }) {
  await page.fill("#name", name);
  await page.fill("#email", email);
  await page.fill("#message", message);
}

function submitButton(page) {
  return page.getByRole("button", { name: "Send message" });
}

describe("every page", () => {
  for (const { route } of PAGES) {
    it(`${route} loads with no console errors and no off-origin requests`, () =>
      withPage(route, 1280, async (page, seen) => {
        assert.deepEqual(seen.errors, []);
        assert.deepEqual(seen.external, []);
      }));

    it(`${route} has lang, viewport, one h1, ordered headings, landmarks and no positive tabindex`, () =>
      withPage(route, 1280, async (page) => {
        const info = await page.evaluate(() => ({
          lang: document.documentElement.lang,
          viewport:
            document.querySelector('meta[name="viewport"]')?.content ?? "",
          title: document.title,
          h1: document.querySelectorAll("h1").length,
          levels: [...document.querySelectorAll("h1, h2, h3, h4, h5, h6")].map(
            (heading) => Number(heading.tagName[1]),
          ),
          positiveTabindex: [...document.querySelectorAll("[tabindex]")].filter(
            (element) => Number(element.getAttribute("tabindex")) > 0,
          ).length,
          landmarks: ["header", "nav[aria-label]", "main#main", "footer"].every(
            (selector) => document.querySelector(selector) !== null,
          ),
        }));
        assert.equal(info.lang, "en");
        assert.match(info.viewport, /width=device-width/);
        assert.notEqual(info.title.trim(), "");
        assert.equal(info.h1, 1);
        assert.equal(info.levels[0], 1);
        for (let i = 1; i < info.levels.length; i += 1) {
          assert.ok(
            info.levels[i] <= info.levels[i - 1] + 1,
            `heading level skips at index ${i}`,
          );
        }
        assert.equal(info.positiveTabindex, 0);
        assert.equal(info.landmarks, true);
      }));
  }

  it("gives every page a unique title", async () => {
    const titles = [];
    for (const { route } of PAGES) {
      await withPage(route, 1280, async (page) => {
        titles.push(await page.title());
      });
    }
    assert.equal(new Set(titles).size, PAGES.length);
  });

  it("has a skip link that is the first focusable element and is visible on focus", () =>
    withPage("/books.html", 1280, async (page) => {
      await page.keyboard.press("Tab");
      assert.equal(
        await page.evaluate(() => document.activeElement.className),
        "skip-link",
      );
      const box = await page.locator(".skip-link").boundingBox();
      assert.ok(
        box && box.y >= 0 && box.width > 0 && box.height > 0,
        "skip link is on screen",
      );
      await page.keyboard.press("Enter");
      assert.equal(
        await page.evaluate(() => document.activeElement.id),
        "main",
      );
    }));

  for (const { route, current } of PAGES) {
    it(`${route} shares the nav and marks ${current} as the current page`, () =>
      withPage(route, 1280, async (page) => {
        const links = await page.$$eval("#site-nav a", (anchors) =>
          anchors.map((anchor) => [
            anchor.textContent.trim(),
            anchor.getAttribute("href"),
            anchor.getAttribute("aria-current"),
          ]),
        );
        assert.deepEqual(
          links,
          NAV.map(([text, href]) => [
            text,
            href,
            text === current ? "page" : null,
          ]),
        );
      }));
  }

  it("has an identical footer on every page", async () => {
    const footers = [];
    for (const { route } of PAGES) {
      await withPage(route, 1280, async (page) => {
        footers.push(
          await page.locator("footer").evaluate((element) => element.outerHTML),
        );
      });
    }
    assert.equal(new Set(footers).size, 1);
  });
});

describe("responsive layout", () => {
  for (const { route } of PAGES) {
    it(`${route} has no horizontal scrolling at 360px and shows the menu button`, () =>
      withPage(route, 360, async (page) => {
        const scrollWidth = await page.evaluate(
          () => document.documentElement.scrollWidth,
        );
        assert.ok(scrollWidth <= 360, `scrollWidth was ${scrollWidth}`);
        assert.equal(await page.locator(".nav-toggle").isVisible(), true);
      }));
  }

  for (const { route } of PAGES) {
    it(`${route} has no horizontal scrolling at 360px with root text at 200%`, () =>
      withPage(route, 360, async (page) => {
        await page.evaluate(() => {
          document.documentElement.style.fontSize = "200%";
        });
        const scrollWidth = await page.evaluate(
          () => document.documentElement.scrollWidth,
        );
        assert.ok(scrollWidth <= 360, `scrollWidth was ${scrollWidth}`);
      }));
  }

  it("lays the book catalog out as a multi-column grid at 1280px", () =>
    withPage("/books.html", 1280, async (page) => {
      const columns = await page.$eval(
        "#book-grid",
        (grid) => getComputedStyle(grid).gridTemplateColumns.split(" ").length,
      );
      assert.ok(columns > 1, `expected several columns, got ${columns}`);
    }));
});

describe("mobile menu", () => {
  it("toggles aria-expanded, and Escape closes the menu and returns focus to the button", () =>
    withPage("/", 360, async (page) => {
      const toggle = page.locator(".nav-toggle");
      const nav = page.locator("#site-nav");
      assert.equal(await toggle.getAttribute("aria-controls"), "site-nav");
      assert.equal(await toggle.getAttribute("aria-expanded"), "false");
      assert.equal(await nav.isVisible(), false);

      await toggle.click();
      assert.equal(await toggle.getAttribute("aria-expanded"), "true");
      assert.equal(await nav.isVisible(), true);

      await page.keyboard.press("Escape");
      assert.equal(await toggle.getAttribute("aria-expanded"), "false");
      assert.equal(await nav.isVisible(), false);
      assert.equal(
        await page.evaluate(() => document.activeElement.className),
        "nav-toggle",
      );
    }));
});

describe("books catalog", () => {
  it("has at least 12 books, at least 5 genres, and at least 2 books per genre", () =>
    withPage("/books.html", 1280, async (page) => {
      const counts = await page.$$eval("#book-grid li", (items) => {
        const tally = {};
        items.forEach((item) => {
          tally[item.dataset.genre] = (tally[item.dataset.genre] || 0) + 1;
        });
        return { total: items.length, tally };
      });
      assert.ok(counts.total >= 12, `only ${counts.total} books`);
      const genres = Object.keys(counts.tally);
      assert.ok(genres.length >= 5, `only ${genres.length} genres`);
      genres.forEach((genre) =>
        assert.ok(counts.tally[genre] >= 2, `${genre} has one book`),
      );
    }));

  it("shows each option with its count and a stand-in cover hidden from assistive tech", () =>
    withPage("/books.html", 1280, async (page) => {
      const labels = await page.$$eval(".genre-option", (options) =>
        options.map((option) => option.textContent.trim()),
      );
      assert.equal(labels[0], "All (15)");
      assert.ok(labels.includes("Mystery (3)"));
      assert.equal(
        await page.locator('.cover[aria-hidden="true"]').count(),
        15,
      );
    }));

  it("filters to one genre, updates the URL and announces the count", () =>
    withPage("/books.html", 1280, async (page, seen) => {
      await page.locator('input[name="genre"][value="mystery"]').check();
      assert.equal(new URL(page.url()).searchParams.get("genre"), "mystery");
      const genres = await page.$$eval("#book-grid li:not([hidden])", (items) =>
        items.map((item) => item.dataset.genre),
      );
      assert.deepEqual(genres, ["mystery", "mystery", "mystery"]);
      assert.equal(
        await page.locator("#filter-status").textContent(),
        "Showing 3 books in Mystery",
      );
      assert.equal(
        await page
          .getByRole("heading", { level: 3, name: "The Orbit Ledger" })
          .count(),
        0,
      );
      assert.deepEqual(seen.errors, []);
    }));

  it("is operable from the keyboard", () =>
    withPage("/books.html", 1280, async (page) => {
      await page.locator('input[name="genre"][value=""]').focus();
      await page.keyboard.press("ArrowDown");
      assert.equal(new URL(page.url()).searchParams.get("genre"), "mystery");
      assert.equal(await visibleBookCount(page), 3);
    }));

  it("preselects the genre named in the URL", () =>
    withPage("/books.html?genre=poetry", 1280, async (page) => {
      assert.equal(
        await page.locator('input[name="genre"][value="poetry"]').isChecked(),
        true,
      );
      assert.equal(await visibleBookCount(page), 3);
      assert.equal(
        await page.locator("#filter-status").textContent(),
        "Showing 3 books in Poetry",
      );
    }));

  it("restores the previous filter with the Back button", () =>
    withPage("/books.html", 1280, async (page) => {
      await page.locator('input[name="genre"][value="mystery"]').check();
      await page.locator('input[name="genre"][value="poetry"]').check();

      await page.goBack();
      await page.waitForFunction(
        () => document.querySelector('input[value="mystery"]').checked,
      );
      assert.equal(new URL(page.url()).searchParams.get("genre"), "mystery");
      assert.equal(await visibleBookCount(page), 3);

      await page.goBack();
      await page.waitForFunction(
        () => document.querySelector('input[value=""]').checked,
      );
      assert.equal(new URL(page.url()).search, "");
      assert.equal(await visibleBookCount(page), 15);
    }));

  it("shows every book with All selected for an unknown genre in the URL", () =>
    withPage("/books.html?genre=xyz", 1280, async (page, seen) => {
      assert.equal(
        await page.locator('input[name="genre"][value=""]').isChecked(),
        true,
      );
      assert.equal(await visibleBookCount(page), 15);
      assert.equal(
        await page.locator("#filter-status").textContent(),
        "Showing all 15 books",
      );
      assert.deepEqual(seen.errors, []);
    }));

  it("rewrites a non-canonical genre in the URL and adds no history entry when that genre is clicked", () =>
    withPage("/books.html?genre=MYSTERY", 1280, async (page) => {
      assert.equal(new URL(page.url()).search, "?genre=mystery");
      const before = await page.evaluate(() => window.history.length);
      await page.locator("label.genre-option", { hasText: "Mystery" }).click();
      assert.equal(await page.evaluate(() => window.history.length), before);
      assert.equal(new URL(page.url()).search, "?genre=mystery");
    }));

  const hostileGenres = [
    ["Science%20Fiction", 3, "science-fiction", "Science Fiction"],
    ["MYSTERY", 3, "mystery", "Mystery"],
    ["", 15, "", null],
  ];
  for (const [value, visible, selected, genreName] of hostileGenres) {
    it(`handles ?genre=${value} sensibly without errors`, () =>
      withPage(`/books.html?genre=${value}`, 1280, async (page, seen) => {
        assert.equal(
          await page
            .locator(`input[name="genre"][value="${selected}"]`)
            .isChecked(),
          true,
        );
        assert.equal(await visibleBookCount(page), visible);
        const expected = genreName
          ? `Showing ${visible} books in ${genreName}`
          : "Showing all 15 books";
        assert.equal(
          await page.locator("#filter-status").textContent(),
          expected,
        );
        assert.deepEqual(seen.errors, []);
      }));
  }
});

describe("events", () => {
  it("lists events in date order with machine-readable times and admission details", () =>
    withPage("/events.html", 1280, async (page) => {
      const times = await page.$$eval(".event-card time", (elements) =>
        elements.map((element) => element.getAttribute("datetime")),
      );
      assert.ok(
        times.every((value) => /^202[67]-\d{2}-\d{2}T\d{2}:\d{2}$/.test(value)),
        times.join(", "),
      );
      assert.deepEqual(times, [...times].sort());
      const admissions = await page.$$eval(".event-card__admission", (items) =>
        items.map((item) => item.textContent),
      );
      assert.ok(
        admissions.every(
          (text) =>
            text === "Free admission" ||
            /^Ticketed: \$\d+ per person$/.test(text),
        ),
      );
    }));

  it("counts an event on today's local date as upcoming", () =>
    withPage("/events.html", 1280, async (page) => {
      const counts = await page.evaluate(() => {
        const list = [
          {
            title: "Today",
            date: "2026-11-16",
            time: "23:30",
            ticket: null,
            description: "x",
          },
        ];
        const late = new Date(2026, 10, 16, 23, 59);
        const early = new Date(2026, 10, 16, 0, 1);
        return [
          window.MarginaliaEvents.upcomingEvents(list, early).length,
          window.MarginaliaEvents.upcomingEvents(list, late).length,
        ];
      });
      assert.deepEqual(counts, [1, 1]);
    }));

  it("drops yesterday's events", () =>
    withPage("/events.html", 1280, async (page) => {
      const count = await page.evaluate(() => {
        const list = [
          {
            title: "Yesterday",
            date: "2026-11-15",
            time: "23:30",
            ticket: null,
            description: "x",
          },
        ];
        return window.MarginaliaEvents.upcomingEvents(
          list,
          new Date(2026, 10, 16, 0, 1),
        ).length;
      });
      assert.equal(count, 0);
    }));

  it("shows a friendly message instead of an empty list when every event is past", () =>
    withPage("/events.html", 1280, async (page) => {
      const result = await page.evaluate(() => {
        const box = document.createElement("div");
        const past = [
          {
            title: "Old",
            date: "2026-10-10",
            time: "19:00",
            ticket: null,
            description: "x",
          },
        ];
        window.MarginaliaEvents.renderEvents(
          box,
          past,
          new Date(2026, 10, 16, 9),
        );
        return {
          text: box.textContent,
          items: box.querySelectorAll("li").length,
          lists: box.querySelectorAll("ol").length,
        };
      });
      assert.match(result.text, /There are no upcoming events/);
      assert.equal(result.items, 0);
      assert.equal(result.lists, 0);
    }));

  it("has at least five upcoming events in the data for 2026-11-16", () =>
    withPage("/events.html", 1280, async (page) => {
      const count = await page.evaluate(
        () =>
          window.MarginaliaEvents.upcomingEvents(
            window.MarginaliaEvents.events,
            new Date(2026, 10, 16, 9),
          ).length,
      );
      assert.ok(count >= 5, `only ${count} upcoming events`);
    }));
});

describe("visit page contact form", () => {
  it("uses native types and autocomplete, and marks required fields in text", () =>
    withPage("/visit.html", 1280, async (page) => {
      assert.equal(await page.getAttribute("#email", "type"), "email");
      assert.equal(await page.getAttribute("#name", "autocomplete"), "name");
      assert.equal(await page.getAttribute("#email", "autocomplete"), "email");
      assert.notEqual(
        await page.getAttribute("#contact-form", "novalidate"),
        null,
      );
      assert.match(
        await page.locator('label[for="name"]').textContent(),
        /\(required\)/,
      );
      assert.equal(await page.getAttribute("#message", "maxlength"), "2000");
    }));

  it("shows an error per empty field, sets aria-invalid, and focuses the first invalid field", () =>
    withPage("/visit.html", 1280, async (page) => {
      await submitButton(page).click();
      const fields = await page.evaluate(() =>
        ["name", "email", "message"].map((id) => {
          const field = document.getElementById(id);
          const described = field
            .getAttribute("aria-describedby")
            .split(/\s+/)
            .map((ref) => document.getElementById(ref).textContent)
            .join(" ");
          return { id, invalid: field.getAttribute("aria-invalid"), described };
        }),
      );
      for (const field of fields) {
        assert.equal(field.invalid, "true", `${field.id} is not aria-invalid`);
        assert.match(
          field.described,
          /Please (enter|fill)|Please enter/,
          `${field.id} message not described`,
        );
      }
      assert.equal(
        await page.textContent("#name-error"),
        "Please enter your name.",
      );
      assert.equal(
        await page.evaluate(() => document.activeElement.id),
        "name",
      );
      assert.match(
        await page.textContent("#form-summary"),
        /Please fix 3 problems/,
      );
    }));

  it("rejects a whitespace-only name and message as empty", () =>
    withPage("/visit.html", 1280, async (page) => {
      await fillForm(page, {
        name: "   ",
        email: "ada@example.com",
        message: "   ",
      });
      await submitButton(page).click();
      assert.equal(
        await page.textContent("#name-error"),
        "Please enter your name.",
      );
      assert.equal(
        await page.textContent("#message-error"),
        "Please enter a message.",
      );
      assert.equal(await page.getAttribute("#name", "aria-invalid"), "true");
      assert.equal(await page.getAttribute("#email", "aria-invalid"), null);
      assert.equal(
        await page.evaluate(() => document.activeElement.id),
        "name",
      );
      assert.equal(await page.locator("#form-status").textContent(), "");
    }));

  for (const email of ["a@", "foo"]) {
    it(`rejects the email "${email}" with a message tied to the field`, () =>
      withPage("/visit.html", 1280, async (page) => {
        await fillForm(page, { name: "Ada", email, message: "Hello" });
        await submitButton(page).click();
        assert.equal(await page.getAttribute("#email", "aria-invalid"), "true");
        assert.match(
          await page.textContent("#email-error"),
          /name@example\.com/,
        );
        assert.equal(
          await page.evaluate(() => document.activeElement.id),
          "email",
        );
        assert.equal(await page.locator("#form-status").textContent(), "");
      }));
  }

  it("rejects a message over 2000 characters", () =>
    withPage("/visit.html", 1280, async (page) => {
      await fillForm(page, {
        name: "Ada",
        email: "ada@example.com",
        message: "Hello",
      });
      await page.evaluate(() => {
        const message = document.getElementById("message");
        message.value = "x".repeat(2001);
        message.dispatchEvent(new Event("input", { bubbles: true }));
      });
      await submitButton(page).click();
      assert.equal(await page.getAttribute("#message", "aria-invalid"), "true");
      assert.match(
        await page.textContent("#message-error"),
        /over 2000 characters/,
      );
      assert.equal(
        await page.evaluate(() => document.activeElement.id),
        "message",
      );
    }));

  it("clears a field error once the field is corrected", () =>
    withPage("/visit.html", 1280, async (page) => {
      await submitButton(page).click();
      await page.fill("#name", "Ada");
      assert.equal(await page.getAttribute("#name", "aria-invalid"), null);
      assert.equal(await page.locator("#name-error").isHidden(), true);
      assert.match(
        await page.textContent("#form-summary"),
        /Please fix 2 problems/,
      );
    }));

  it("says plainly that a valid message was not sent, and offers a mailto link", () =>
    withPage("/visit.html", 1280, async (page) => {
      await fillForm(page, {
        name: "Ada",
        email: "ada@example.com",
        message: "Do you stock poetry?",
      });
      await submitButton(page).click();
      const status = await page.locator("#form-status").innerText();
      assert.match(status, /Thanks, Ada/);
      assert.ok(status.includes(DEMO_SENTENCE), status);
      assert.match(status, /wasn't sent/);
      assert.doesNotMatch(
        status,
        /(has|have) been sent|we('ve| have) received|message sent/i,
      );
      assert.equal(
        await page
          .locator(
            '#form-status a[href^="mailto:hello@marginaliabooks.example"]',
          )
          .count(),
        1,
      );
    }));

  it("does not duplicate the demo message when submitted twice", () =>
    withPage("/visit.html", 1280, async (page) => {
      await fillForm(page, {
        name: "Ada",
        email: "ada@example.com",
        message: "Hello",
      });
      await submitButton(page).click();
      await submitButton(page).click();
      const status = await page.locator("#form-status").textContent();
      assert.equal(status.split(DEMO_SENTENCE).length - 1, 1);
    }));
});

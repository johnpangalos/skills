// Events: the schedule and the upcoming-events logic, shared by events.html and index.html.
(function () {
  "use strict";

  var EVENTS = [
    {
      title: "Harvest Poetry Night",
      date: "2026-10-10",
      time: "19:00",
      ticket: null,
      description:
        "Poems about apples, harvest moons and empty fields, read by the Ashford Mill writers' circle.",
    },
    {
      title: "Lantern Light Reading: Poems for the Long Dark",
      date: "2026-11-16",
      time: "19:00",
      ticket: null,
      description:
        "Five local poets read work about winter, night shifts and the first frost, followed by open mic time for anyone with a page to share. Bring a coat; the stove will be going.",
    },
    {
      title: "Book Club: The Salt Cartographer",
      date: "2026-11-21",
      time: "18:30",
      ticket: 12,
      description:
        "Our monthly book club discusses Lea Ostrander's novel about a mapmaker charting a coastline that keeps moving. Tickets include a pot of tea and the reading guide.",
    },
    {
      title: "Saturday Storytime for Early Readers",
      date: "2026-11-28",
      time: "10:00",
      ticket: null,
      description:
        "Picture books, a short craft and a sing-along for readers aged three to six. Families are welcome to stay for the rest of the morning.",
    },
    {
      title: "Mystery Night: Lightning Round",
      date: "2026-12-05",
      time: "19:00",
      ticket: 15,
      description:
        "Teams of up to four solve three short mysteries set among our own shelves, with a prize for the best detective name. Proceeds support the children's reading fund.",
    },
    {
      title: "Winter Zine Workshop",
      date: "2026-12-12",
      time: "14:00",
      ticket: 20,
      description:
        "Fold, staple and print a pocket-sized zine in two hours with our bookbinding volunteer. Materials are provided and you take your finished zine home.",
    },
    {
      title: "Author Talk: Priya Narayan on Weather Diaries",
      date: "2027-01-16",
      time: "18:00",
      ticket: null,
      description:
        "The author of A Field Guide to Forgotten Weather talks about the diaries behind the book and brings a few of the original notebooks to show.",
    },
  ];

  function element(tag, className, text) {
    var node = document.createElement(tag);
    if (className) {
      node.className = className;
    }
    if (text !== undefined) {
      node.textContent = text;
    }
    return node;
  }

  function pad(number) {
    return number < 10 ? "0" + number : String(number);
  }

  // The local calendar day as YYYY-MM-DD, so an event on today's date still counts as upcoming.
  function localDay(now) {
    return (
      now.getFullYear() +
      "-" +
      pad(now.getMonth() + 1) +
      "-" +
      pad(now.getDate())
    );
  }

  function startOf(event) {
    return event.date + "T" + event.time;
  }

  // Events on or after today's local date, in date and time order. Does not modify the input.
  function upcomingEvents(events, now) {
    var today = localDay(now);
    return events
      .filter(function (event) {
        return event.date >= today;
      })
      .sort(function (a, b) {
        return startOf(a).localeCompare(startOf(b));
      });
  }

  function formatDate(date) {
    var parts = date.split("-").map(Number);
    return new Date(
      Date.UTC(parts[0], parts[1] - 1, parts[2]),
    ).toLocaleDateString("en-US", {
      weekday: "long",
      month: "long",
      day: "numeric",
      year: "numeric",
      timeZone: "UTC",
    });
  }

  function formatTime(time) {
    var parts = time.split(":").map(Number);
    return new Date(
      Date.UTC(2000, 0, 1, parts[0], parts[1]),
    ).toLocaleTimeString("en-US", {
      hour: "numeric",
      minute: "2-digit",
      timeZone: "UTC",
    });
  }

  function eventItem(event) {
    var item = element("li", "event-card");
    item.appendChild(element("h3", "event-card__title", event.title));

    var when = element("p", "event-card__when");
    var time = element(
      "time",
      null,
      formatDate(event.date) + ", " + formatTime(event.time),
    );
    time.setAttribute("datetime", startOf(event));
    when.appendChild(time);
    item.appendChild(when);

    item.appendChild(
      element("p", "event-card__description", event.description),
    );
    item.appendChild(
      element(
        "p",
        "event-card__admission",
        event.ticket
          ? "Ticketed: $" + event.ticket + " per person"
          : "Free admission",
      ),
    );
    return item;
  }

  // Replaces the container's contents with the upcoming events, or a friendly message if none.
  function renderEvents(container, events, now) {
    var upcoming = upcomingEvents(events, now);
    container.textContent = "";
    if (upcoming.length === 0) {
      container.appendChild(
        element(
          "p",
          "empty-state",
          "There are no upcoming events at the moment. Check back soon, or ask at the counter about our next reading.",
        ),
      );
      return;
    }
    var list = element("ol", "event-list");
    upcoming.forEach(function (event) {
      list.appendChild(eventItem(event));
    });
    container.appendChild(list);
  }

  window.MarginaliaEvents = {
    events: EVENTS,
    localDay: localDay,
    upcomingEvents: upcomingEvents,
    renderEvents: renderEvents,
  };

  var list = document.getElementById("event-list");
  if (list) {
    renderEvents(list, EVENTS, new Date());
  }
})();

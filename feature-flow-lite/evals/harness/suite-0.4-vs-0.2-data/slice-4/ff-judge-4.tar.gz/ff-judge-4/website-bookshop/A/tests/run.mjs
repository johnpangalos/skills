// Headless-browser checks for the Marginalia Books site.
// Usage: node tests/run.mjs [home|books|events|visit]
// Starts its own static server on a free local port. Uses Playwright's bundled
// Chromium if installed, otherwise /usr/bin/google-chrome.
import fs from 'node:fs';
import http from 'node:http';
import path from 'node:path';
import { execFileSync } from 'node:child_process';
import { fileURLToPath, pathToFileURL } from 'node:url';

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const SYSTEM_CHROME = '/usr/bin/google-chrome';
const PAGES = { home: 'index.html', books: 'books.html', events: 'events.html', visit: 'visit.html' };
const MIME = {
  '.html': 'text/html; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.js': 'text/javascript; charset=utf-8',
  '.svg': 'image/svg+xml',
  '.ico': 'image/x-icon',
};
const DAYS = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'];
const DEMO_NOTE = /this is a demo/i;
const NOT_SENT_NOTE = /nothing was sent/i;

const results = [];
let failed = 0;

async function check(name, fn) {
  try {
    await fn();
    results.push(`PASS  ${name}`);
  } catch (err) {
    failed += 1;
    results.push(`FAIL  ${name}\n      ${err.message}`);
  }
}

function expect(condition, message) {
  if (!condition) {
    throw new Error(message);
  }
}

function expectEqual(actual, expected, label) {
  const same = JSON.stringify(actual) === JSON.stringify(expected);
  expect(same, `${label}: expected ${JSON.stringify(expected)}, got ${JSON.stringify(actual)}`);
}

async function loadChromium() {
  try {
    return (await import('playwright')).chromium;
  } catch {
    const globalRoot = execFileSync('npm', ['root', '-g'], { encoding: 'utf8' }).trim();
    const entry = path.join(globalRoot, 'playwright', 'index.mjs');
    return (await import(pathToFileURL(entry).href)).chromium;
  }
}

function startServer() {
  const server = http.createServer((req, res) => {
    let urlPath;
    try {
      urlPath = decodeURIComponent(new URL(req.url, 'http://localhost').pathname);
    } catch {
      res.writeHead(400).end();
      return;
    }
    const file = path.join(ROOT, urlPath === '/' ? 'index.html' : urlPath);
    const type = MIME[path.extname(file)];
    if (!type || !file.startsWith(ROOT + path.sep) || !fs.existsSync(file)) {
      res.writeHead(404, { 'content-type': 'text/plain' }).end('Not found');
      return;
    }
    res.writeHead(200, { 'content-type': type });
    fs.createReadStream(file).pipe(res);
  });
  return new Promise((resolve) => server.listen(0, '127.0.0.1', () => resolve(server)));
}

async function fillValid(page) {
  await page.fill('#name', 'Ada Reader');
  await page.fill('#email', 'ada@example.com');
  await page.fill('#message', 'Do you stock poetry chapbooks?');
}

async function booksChecks({ check, open }) {
  // Expected numbers come from the page itself, so a shorter or longer catalogue still passes.
  const probe = await open();
  const total = await probe.$$eval('.book', (els) => els.length);
  const genres = await probe.$$eval('#genre option', (opts) => opts.map((o) => o.value).filter((v) => v !== 'All'));
  const counts = await probe.$$eval('[data-genre]', (els) => els.reduce((acc, el) => {
    acc[el.dataset.genre] = (acc[el.dataset.genre] || 0) + 1;
    return acc;
  }, {}));
  const [first, second] = genres;
  const ampersand = genres.find((g) => g.includes('&'));
  const search = (pairs) => `?${new URLSearchParams(pairs).toString()}`;

  await check('books: at least 8 titles, each with title, author, genre, blurb and price', async () => {
    const page = await open();
    const books = await page.$$eval('.book', (els) => els.map((el) => ({
      title: el.querySelector('h2')?.textContent.trim() || '',
      author: el.querySelector('.author')?.textContent.trim() || '',
      genre: el.querySelector('.tag')?.textContent.trim() || '',
      blurb: el.querySelector('p:not(.author):not(.tag):not(.price)')?.textContent.trim() || '',
      price: el.querySelector('.price')?.textContent.trim() || '',
      dataGenre: el.dataset.genre,
    })));
    expect(books.length >= 8, `found ${books.length} titles, need at least 8`);
    const incomplete = books.filter((b) => !b.title || !b.author || !b.genre || !b.blurb
      || !/^£\d/.test(b.price) || b.genre !== b.dataGenre);
    expectEqual(incomplete.length, 0, 'incomplete book entries');
  });

  await check('books: at least 4 genres, each with at least 2 titles', async () => {
    const page = await open();
    const genres = await page.$$eval('#genre option', (opts) => opts.map((o) => o.value).filter((v) => v !== 'All'));
    const bookGenres = await page.$$eval('.book', (els) => els.map((el) => el.dataset.genre));
    expect(genres.length >= 4, `found ${genres.length} genres, need at least 4`);
    const thin = genres.filter((g) => bookGenres.filter((b) => b === g).length < 2);
    expectEqual(thin, [], 'genres with fewer than 2 titles');
  });

  await check('books: genre control is labelled and the result count is a polite live region', async () => {
    const page = await open();
    const tag = await page.getByLabel('Genre', { exact: true }).evaluate((el) => el.tagName);
    expectEqual(tag, 'SELECT', 'labelled control');
    expectEqual(await page.getAttribute('#result-count', 'aria-live'), 'polite', 'aria-live');
    expectEqual(await page.$eval('#genre option', (o) => o.value), 'All', 'first option');
  });

  await check('books: filter shows only the chosen genre and announces the count', async () => {
    const page = await open();
    await page.selectOption('#genre', ampersand);
    const shown = await page.$$eval('.book:not([hidden])', (els) => els.map((el) => el.dataset.genre));
    expect(shown.length === counts[ampersand] && shown.every((g) => g === ampersand), `visible genres were ${JSON.stringify(shown)}`);
    expectEqual(await page.textContent('#result-count'), `Showing ${shown.length} of ${total} books`, 'result count');
    await page.selectOption('#genre', 'All');
    expectEqual(await page.textContent('#result-count'), `Showing ${total} of ${total} books`, 'count after All');
    expectEqual(await page.$$eval('.book:not([hidden])', (els) => els.length), total, 'visible after All');
  });

  const urlCases = [
    [search([['genre', ampersand]]), ampersand, counts[ampersand]],
    ['?genre=unknown', 'All', total],
    ['?genre=', 'All', total],
    [search([['genre', first.toUpperCase()]]), first, counts[first]],
    [search([['genre', second], ['genre', first]]), second, counts[second]],
  ];
  for (const [query, genre, visible] of urlCases) {
    await check(`books: ${query} selects "${genre}" and shows ${visible} titles`, async () => {
      const page = await open(query);
      expectEqual(await page.$eval('#genre', (s) => s.value), genre, 'control value');
      expectEqual(await page.$$eval('.book:not([hidden])', (els) => els.length), visible, 'visible titles');
      expect(visible > 0, 'page is blank');
    });
  }

  await check('books: genre with spaces and & is encoded in the URL and decodes back', async () => {
    const page = await open();
    await page.selectOption('#genre', ampersand);
    expectEqual(new URL(page.url()).search, search([['genre', ampersand]]), 'query string');
    expectEqual(new URL(page.url()).searchParams.get('genre'), ampersand, 'decoded genre');
  });

  await check('books: genre changes add history entries and back/forward restore filter and control', async () => {
    const page = await open();
    const before = await page.evaluate(() => history.length);
    await page.selectOption('#genre', first);
    expectEqual(await page.evaluate(() => history.length) - before, 1, 'history entries added');
    await page.selectOption('#genre', second);

    await page.goBack();
    expectEqual(await page.$eval('#genre', (s) => s.value), first, 'control after back');
    expectEqual(await page.$$eval('.book:not([hidden])', (els) => els.length), counts[first], 'visible after back');
    expectEqual(new URL(page.url()).searchParams.get('genre'), first, 'genre in url after back');

    await page.goBack();
    expectEqual(await page.$eval('#genre', (s) => s.value), 'All', 'control after second back');
    expectEqual(await page.$$eval('.book:not([hidden])', (els) => els.length), total, 'visible after second back');
    expectEqual(new URL(page.url()).search, '', 'url after second back');

    await page.goForward();
    expectEqual(await page.$eval('#genre', (s) => s.value), first, 'control after forward');
    await page.goForward();
    expectEqual(await page.$eval('#genre', (s) => s.value), second, 'control after second forward');
    expectEqual(await page.$$eval('.book:not([hidden])', (els) => els.length), counts[second], 'visible after second forward');
  });
}

async function eventsChecks({ check, open }) {
  await check('events: at least 4 events with date, time, title and description', async () => {
    const page = await open();
    const events = await page.$$eval('.event', (els) => els.map((el) => ({
      datetime: el.querySelector('time')?.getAttribute('datetime') || '',
      date: el.querySelector('time')?.textContent.trim() || '',
      time: el.querySelector('.event-time')?.textContent.trim() || '',
      title: el.querySelector('h2')?.textContent.trim() || '',
      description: el.querySelector('h2 ~ p')?.textContent.trim() || '',
    })));
    expect(events.length >= 4, `found ${events.length} events, need at least 4`);
    const incomplete = events.filter((e) => !/^\d{4}-\d{2}-\d{2}$/.test(e.datetime) || !e.date
      || !/\d{1,2}:\d{2}(am|pm) to \d{1,2}:\d{2}(am|pm)/.test(e.time) || !e.title || !e.description);
    expectEqual(incomplete.length, 0, 'incomplete events');
  });
}

async function visitChecks({ check, open, requests }) {
  const submit = (page) => page.click('button[type="submit"]');
  const errorText = (page, id) => page.textContent(`#${id}-error`);
  const focusedId = (page) => page.evaluate(() => document.activeElement.id);

  await check('visit: hours table lists all seven days with hours', async () => {
    const page = await open();
    const rows = await page.$$eval('.hours tr', (trs) => trs.map((tr) => [
      tr.querySelector('th')?.textContent.trim(),
      tr.querySelector('td')?.textContent.trim(),
    ]));
    expectEqual(rows.map((r) => r[0]), DAYS, 'days in order');
    expect(rows.every((r) => r[1]), 'a day has no hours text');
  });

  await check('visit: address is an <address> element inside main', async () => {
    const page = await open();
    expectEqual(await page.$$eval('main address', (els) => els.length), 1, 'address count');
  });

  await check('visit: name, email and message fields have labels', async () => {
    const page = await open();
    for (const label of ['Your name', 'Email address', 'Message']) {
      expectEqual(await page.getByLabel(label, { exact: true }).count(), 1, `field labelled "${label}"`);
    }
  });

  await check('visit: empty submit shows errors, aria-invalid, aria-describedby and focuses name', async () => {
    const page = await open();
    await submit(page);
    for (const id of ['name', 'email', 'message']) {
      expect((await errorText(page, id)).length > 0, `${id} has no error text`);
      expectEqual(await page.getAttribute(`#${id}`, 'aria-invalid'), 'true', `${id} aria-invalid`);
      expectEqual(await page.getAttribute(`#${id}`, 'aria-describedby'), `${id}-error`, `${id} aria-describedby`);
    }
    expectEqual(await focusedId(page), 'name', 'focused field');
    expectEqual(await page.textContent('#form-status'), '', 'status after invalid submit');
  });

  await check('visit: whitespace-only name and message are rejected', async () => {
    const page = await open();
    await page.fill('#name', '   ');
    await page.fill('#email', 'reader@example.com');
    await page.fill('#message', '\n   \t');
    await submit(page);
    expectEqual(await errorText(page, 'name'), 'Please enter your name.', 'name error');
    expectEqual(await errorText(page, 'message'), 'Please enter a message.', 'message error');
    expectEqual(await errorText(page, 'email'), '', 'email error');
    expectEqual(await page.getAttribute('#email', 'aria-invalid'), 'false', 'email aria-invalid');
    expectEqual(await focusedId(page), 'name', 'focused field');
  });

  for (const bad of ['a@b', 'foo']) {
    await check(`visit: email "${bad}" is rejected with a format message`, async () => {
      const page = await open();
      await fillValid(page);
      await page.fill('#email', bad);
      await submit(page);
      expectEqual(await errorText(page, 'email'), 'Please enter an email address like name@example.com.', 'email error');
      expectEqual(await page.getAttribute('#email', 'aria-invalid'), 'true', 'email aria-invalid');
      expectEqual(await focusedId(page), 'email', 'focused field');
      expectEqual(await page.textContent('#form-status'), '', 'status');
    });
  }

  await check('visit: valid submit says it is a demo and sends nothing, with no request', async () => {
    const page = await open();
    await fillValid(page);
    const before = requests.length;
    await submit(page);
    await page.waitForFunction(() => document.getElementById('form-status').textContent.length > 0);
    const status = await page.textContent('#form-status');
    expect(DEMO_NOTE.test(status) && NOT_SENT_NOTE.test(status), `status was: ${status}`);
    expect(!/(message|form) (has been|was) (sent|received)/i.test(status), `status claims a send: ${status}`);
    expectEqual(requests.length - before, 0, 'requests after valid submit');
    expectEqual(new URL(page.url()).search, '', 'query string after submit');
  });

  await check('visit: submitting twice still sends nothing', async () => {
    const page = await open();
    await fillValid(page);
    const before = requests.length;
    await submit(page);
    await submit(page);
    await page.waitForTimeout(300);
    expect(NOT_SENT_NOTE.test(await page.textContent('#form-status')), 'status lost after second submit');
    expectEqual(requests.length - before, 0, 'requests after two submits');
  });

  await check('visit: Enter in a field submits the form', async () => {
    const page = await open();
    await fillValid(page);
    const before = requests.length;
    await page.focus('#email');
    await page.keyboard.press('Enter');
    await page.waitForFunction(() => document.getElementById('form-status').textContent.length > 0);
    expect(NOT_SENT_NOTE.test(await page.textContent('#form-status')), 'Enter did not submit the form');
    expectEqual(requests.length - before, 0, 'requests after Enter');
  });
}

const NATIVE_CONTROLS = ['a', 'button', 'input', 'select', 'textarea', 'summary', 'label', 'form'];

// Tags of non-control elements under body that have click or keydown listeners (read via CDP).
async function listenerOffenders(page) {
  const cdp = await page.context().newCDPSession(page);
  await cdp.send('DOM.enable');
  const { root } = await cdp.send('DOM.getDocument', { depth: -1 });
  const { nodeIds } = await cdp.send('DOM.querySelectorAll', { nodeId: root.nodeId, selector: 'body *' });
  const offenders = [];
  for (const nodeId of nodeIds) {
    const { node } = await cdp.send('DOM.describeNode', { nodeId });
    const tag = node.nodeName.toLowerCase();
    if (NATIVE_CONTROLS.includes(tag)) {
      continue;
    }
    const { object } = await cdp.send('DOM.resolveNode', { nodeId });
    const { listeners } = await cdp.send('DOMDebugger.getEventListeners', { objectId: object.objectId });
    if (listeners.some((l) => l.type === 'click' || l.type === 'keydown')) {
      offenders.push(tag);
    }
  }
  await cdp.detach();
  return offenders;
}

// Presses Tab until focus leaves the page; returns the stops with no visible outline or box-shadow.
async function unoutlinedFocusStops(page) {
  const offenders = [];
  let presses = 0;
  for (; presses < 100; presses += 1) {
    await page.keyboard.press('Tab');
    const stop = await page.evaluate(() => {
      const el = document.activeElement;
      if (el === document.body) {
        return null;
      }
      const style = getComputedStyle(el);
      const outlined = (style.outlineStyle !== 'none' && parseFloat(style.outlineWidth) > 0) || style.boxShadow !== 'none';
      return { label: `${el.tagName.toLowerCase()} "${el.textContent.trim().slice(0, 30)}"`, outlined };
    });
    if (!stop) {
      break;
    }
    if (!stop.outlined) {
      offenders.push(stop.label);
    }
  }
  expect(presses < 100, 'Tab did not leave the page within 100 stops');
  return offenders;
}

async function runPage(browser, base, key, titles) {
  const file = PAGES[key];
  const origin = new URL(base).origin;
  const requests = [];
  const consoleErrors = [];
  const context = await browser.newContext({ viewport: { width: 1280, height: 800 } });
  context.on('request', (req) => requests.push({ url: req.url(), method: req.method() }));

  const open = async (query = '') => {
    const page = await context.newPage();
    page.on('pageerror', (err) => consoleErrors.push(err.message));
    page.on('console', (msg) => {
      if (msg.type() === 'error') {
        consoleErrors.push(msg.text());
      }
    });
    await page.goto(base + file + query, { waitUntil: 'load' });
    return page;
  };

  const externalRequests = () => requests.filter((r) => {
    const u = new URL(r.url);
    return u.origin !== origin && !['data:', 'blob:', 'about:'].includes(u.protocol);
  });

  await check(`${key}: nav links all four pages and each resolves`, async () => {
    const page = await open();
    const hrefs = await page.$$eval('.site-nav a', (links) => links.map((a) => a.getAttribute('href')));
    expectEqual(hrefs, Object.values(PAGES), 'nav hrefs');
    for (const href of hrefs) {
      const response = await page.request.get(new URL(href, base).href);
      expectEqual(response.status(), 200, `status for ${href}`);
    }
  });

  await check(`${key}: only the current page is marked aria-current in nav`, async () => {
    const page = await open();
    const current = await page.$$eval('.site-nav a[aria-current="page"]', (links) => links.map((a) => a.getAttribute('href')));
    expectEqual(current, [file], 'aria-current links');
  });

  await check(`${key}: lang attribute and non-empty title`, async () => {
    const page = await open();
    expectEqual(await page.getAttribute('html', 'lang'), 'en', 'html lang');
    const title = (await page.title()).trim();
    expect(title.length > 0, 'title is empty');
    titles[key] = title;
  });

  await check(`${key}: header, nav, main and footer landmarks`, async () => {
    const page = await open();
    const counts = await page.evaluate(() => ({
      header: document.querySelectorAll('header').length,
      nav: document.querySelectorAll('nav').length,
      main: document.querySelectorAll('main').length,
      footer: document.querySelectorAll('footer').length,
    }));
    expectEqual(counts, { header: 1, nav: 1, main: 1, footer: 1 }, 'landmark counts');
  });

  await check(`${key}: one h1 and no skipped heading levels`, async () => {
    const page = await open();
    const levels = await page.$$eval('h1, h2, h3, h4, h5, h6', (hs) => hs.map((h) => Number(h.tagName.slice(1))));
    expectEqual(levels.filter((l) => l === 1).length, 1, 'h1 count');
    expectEqual(levels[0], 1, 'first heading level');
    for (let i = 1; i < levels.length; i += 1) {
      expect(levels[i] <= levels[i - 1] + 1, `heading jumps from h${levels[i - 1]} to h${levels[i]}`);
    }
  });

  await check(`${key}: skip link is the first stop and moves focus to main`, async () => {
    const page = await open();
    await page.keyboard.press('Tab');
    const first = await page.evaluate(() => ({
      href: document.activeElement.getAttribute('href'),
      outline: getComputedStyle(document.activeElement).outlineStyle,
    }));
    expectEqual(first.href, '#main', 'first tab stop');
    expect(first.outline !== 'none', 'skip link has no visible focus outline');
    await page.keyboard.press('Enter');
    expectEqual(await page.evaluate(() => document.activeElement.id), 'main', 'focus after skip link');
  });

  await check(`${key}: no horizontal scrolling at 1280px or 360px`, async () => {
    const page = await open();
    for (const width of [1280, 360]) {
      await page.setViewportSize({ width, height: 800 });
      const overflow = await page.evaluate(() => document.documentElement.scrollWidth - document.documentElement.clientWidth);
      expectEqual(overflow, 0, `horizontal overflow in px at ${width}px wide`);
    }
  });

  await check(`${key}: nav links stay inside a 360px viewport`, async () => {
    const page = await open();
    await page.setViewportSize({ width: 360, height: 800 });
    const outside = await page.$$eval('.site-nav a', (links) => links.filter((a) => a.getBoundingClientRect().right > window.innerWidth).length);
    expectEqual(outside, 0, 'nav links past the right edge');
  });

  await check(`${key}: no pointer cursor on non-interactive elements`, async () => {
    const page = await open();
    const offenders = await page.evaluate(() => Array.from(document.querySelectorAll('body *'))
      .filter((el) => getComputedStyle(el).cursor === 'pointer'
        && !el.matches('a[href], button, select, input, textarea, label, summary'))
      .map((el) => el.tagName.toLowerCase()));
    expectEqual(offenders, [], 'elements with pointer cursor');
  });

  await check(`${key}: every Tab stop shows a visible focus outline or box-shadow`, async () => {
    const page = await open();
    expectEqual(await unoutlinedFocusStops(page), [], 'tab stops without a visible focus style');
  });

  await check(`${key}: no click or keydown handlers on non-interactive elements`, async () => {
    const page = await open();
    expectEqual(await listenerOffenders(page), [], 'non-interactive elements with handlers');
  });

  await check(`${key}: links, scripts, images and sources are same-origin, relative or data:`, async () => {
    const page = await open();
    const remote = await page.evaluate(() => Array.from(document.querySelectorAll('link[href], script[src], img[src], source[src]'))
      .filter((el) => {
        const url = new URL(el.getAttribute('href') ?? el.getAttribute('src'), location.href);
        return url.origin !== location.origin && url.protocol !== 'data:';
      })
      .map((el) => el.outerHTML));
    expectEqual(remote, [], 'remote assets');
  });

  await check(`${key}: no div or span acting as a button`, async () => {
    const page = await open();
    const count = await page.$$eval('div[onclick], span[onclick], div[role="button"], span[role="button"]', (els) => els.length);
    expectEqual(count, 0, 'div/span buttons');
  });

  await check(`${key}: no placeholder lorem ipsum text`, async () => {
    const page = await open();
    const text = await page.evaluate(() => document.body.innerText);
    expect(!/lorem ipsum/i.test(text), 'found lorem ipsum');
  });

  if (key === 'books') {
    await booksChecks({ check, open });
  }
  if (key === 'events') {
    await eventsChecks({ check, open });
  }
  if (key === 'visit') {
    await visitChecks({ check, open, requests });
  }

  await check(`${key}: no console errors`, async () => {
    expectEqual(consoleErrors, [], 'console errors');
  });

  await check(`${key}: no requests outside ${origin}`, async () => {
    expectEqual(externalRequests().map((r) => r.url), [], 'external requests');
  });

  await context.close();
}

async function main() {
  const arg = process.argv[2];
  if (arg && !PAGES[arg]) {
    console.error(`Unknown page "${arg}". Choose one of: ${Object.keys(PAGES).join(', ')}`);
    process.exitCode = 2;
    return;
  }
  const keys = arg ? [arg] : Object.keys(PAGES);
  const chromium = await loadChromium();
  const server = await startServer();
  const base = `http://127.0.0.1:${server.address().port}/`;
  const launchOptions = fs.existsSync(chromium.executablePath()) ? {} : { executablePath: SYSTEM_CHROME };
  const browser = await chromium.launch({ headless: true, ...launchOptions });
  const titles = {};
  try {
    for (const key of keys) {
      await runPage(browser, base, key, titles);
    }
    if (keys.length === Object.keys(PAGES).length) {
      await check('all four pages have distinct titles', async () => {
        expectEqual(new Set(Object.values(titles)).size, keys.length, 'distinct titles');
      });
    }
  } finally {
    await browser.close();
    server.close();
  }
  console.log(results.join('\n'));
  console.log(failed === 0 ? '\nAll checks passed.' : `\n${failed} check(s) failed.`);
  process.exitCode = failed === 0 ? 0 : 1;
}

main().catch((err) => {
  console.error(err);
  process.exitCode = 1;
});

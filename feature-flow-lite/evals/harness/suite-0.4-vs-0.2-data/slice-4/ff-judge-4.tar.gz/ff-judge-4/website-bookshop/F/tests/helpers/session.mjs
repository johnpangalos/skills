// Opens a page in a fresh browser context and records what the page does: console errors,
// uncaught exceptions, dialogs and every request it makes.
export const PAGES = ['index.html', 'books.html', 'events.html', 'visit.html'];

export async function openPage(browser, url, options = {}) {
  const { width = 1280, height = 900, clock = null } = options;
  const context = await browser.newContext({ viewport: { width, height } });
  const page = await context.newPage();
  const problems = [];
  const requests = [];

  page.on('console', (message) => {
    if (message.type() === 'error') {
      problems.push(message.text());
    }
  });
  page.on('pageerror', (error) => problems.push(error.message));
  page.on('dialog', (dialog) => {
    problems.push(`dialog: ${dialog.message()}`);
    dialog.dismiss();
  });
  page.on('request', (request) => requests.push(request.url()));

  if (clock !== null) {
    await page.clock.setFixedTime(clock);
  }
  await page.goto(url);
  await page.waitForLoadState('load');

  return {
    page,
    problems,
    requests,
    close: () => context.close(),
  };
}

'use strict';

const http = require('node:http');
const { test, before, after } = require('node:test');
const assert = require('node:assert/strict');
const { startServer, launchBrowser } = require('./support');

let server;
let origin;
let browser;

before(async () => {
  ({ server, origin } = await startServer());
  browser = await launchBrowser();
});

after(async () => {
  await browser.close();
  server.close();
});

async function openBooks(query = '') {
  const page = await browser.newPage();
  const errors = [];
  page.on('pageerror', (err) => errors.push(err.message));
  await page.goto(`${origin}/books.html${query}`);
  return { page, errors };
}

async function state(page) {
  return page.evaluate(() => ({
    select: document.getElementById('genre-select').value,
    count: document.getElementById('result-count').textContent,
    titles: [...document.querySelectorAll('#book-list h2')].map((h) => h.textContent),
    emptyHidden: document.getElementById('empty-message').hidden,
    query: location.search
  }));
}

// Sends the path exactly as written (no client-side URL normalisation) and resolves to the status code.
function rawStatus(urlPath) {
  return new Promise((resolve, reject) => {
    http.get(`${origin}${urlPath}`, (res) => {
      res.resume();
      resolve(res.statusCode);
    }).on('error', reject);
  });
}

test('malformed and traversal paths get 400 or 403 and the test server keeps serving', async () => {
  assert.equal(await rawStatus('/%ZZ'), 400);
  assert.equal(await rawStatus('/%E0%A4%A'), 400);
  assert.equal(await rawStatus('/%00'), 400);
  assert.equal(await rawStatus('/..%2f..%2fpackage.json'), 403);
  assert.equal(await rawStatus('/..%2f..%2f..%2fetc%2fpasswd'), 403);
  assert.equal(await rawStatus('/books.html'), 200);
});

test('catalogue has at least 12 books across at least 5 genres with 2 or more each', async () => {
  const { page } = await openBooks();
  const genres = await page.$$eval('#book-list .book-meta', (els) =>
    els.map((el) => el.textContent.split(' · ')[0]));
  assert.ok(genres.length >= 12, `expected at least 12 books, got ${genres.length}`);
  const counts = {};
  for (const genre of genres) counts[genre] = (counts[genre] || 0) + 1;
  const big = Object.values(counts).filter((n) => n >= 2);
  assert.ok(Object.keys(counts).length >= 5, 'at least 5 genres');
  assert.equal(big.length, Object.keys(counts).length, 'every genre has at least 2 titles');
  await page.close();
});

test('the genre filter narrows the list and the count is announced politely', async () => {
  const { page, errors } = await openBooks();
  assert.equal(await page.getAttribute('#result-count', 'aria-live'), 'polite');
  assert.equal((await state(page)).count, 'Showing 15 of 15 books');

  await page.selectOption('#genre-select', 'mystery');
  const mystery = await state(page);
  assert.equal(mystery.count, 'Showing 3 of 15 books');
  assert.equal(mystery.titles.length, 3);
  assert.equal(mystery.query, '?genre=mystery');

  await page.selectOption('#genre-select', 'all');
  const all = await state(page);
  assert.equal(all.count, 'Showing 15 of 15 books');
  assert.equal(all.titles.length, 15);
  assert.equal(all.query, '');
  assert.deepEqual(errors, []);
  await page.close();
});

test('loading a filtered URL directly restores the control and the list', async () => {
  const { page } = await openBooks('?genre=poetry');
  const s = await state(page);
  assert.equal(s.select, 'poetry');
  assert.equal(s.count, 'Showing 2 of 15 books');
  assert.equal(s.titles.length, 2);
  await page.close();
});

test('an unknown genre falls back to All without an error', async () => {
  const { page, errors } = await openBooks('?genre=nonexistent');
  const s = await state(page);
  assert.equal(s.select, 'all');
  assert.equal(s.count, 'Showing 15 of 15 books');
  assert.equal(s.titles.length, 15);
  assert.equal(s.query, '', 'the bad value is removed from the address bar');
  assert.deepEqual(errors, []);
  await page.close();
});

test('genre values match case-insensitively, by slug, and with URL-encoded spaces', async () => {
  const cases = [
    ['?genre=MYSTERY', 'mystery', 3, '?genre=mystery'],
    ['?genre=Science%20Fiction', 'science-fiction', 2, '?genre=science-fiction'],
    ['?genre=science-fiction', 'science-fiction', 2, '?genre=science-fiction'],
    ["?genre=Children%27s", 'childrens', 3, '?genre=childrens'],
    ['?genre=childrens', 'childrens', 3, '?genre=childrens']
  ];
  for (const [query, select, shown, canonical] of cases) {
    const { page, errors } = await openBooks(query);
    const s = await state(page);
    assert.equal(s.select, select, `${query} selects ${select}`);
    assert.equal(s.titles.length, shown, `${query} shows ${shown} books`);
    assert.equal(s.query, canonical, `${query} is normalised in the address bar`);
    assert.deepEqual(errors, [], `${query} has no page errors`);
    await page.close();
  }
});

test('an empty or hostile genre value shows All without crashing', async () => {
  const cases = ['?genre=', '?genre=%20', '?genre=%3Cimg%20src%3Dx%20onerror%3Dalert(1)%3E', '?genre=__proto__', '?genre=all'];
  for (const query of cases) {
    const { page, errors } = await openBooks(query);
    const s = await state(page);
    assert.equal(s.select, 'all', `${query} selects All`);
    assert.equal(s.count, 'Showing 15 of 15 books', `${query} count`);
    assert.deepEqual(errors, [], `${query} has no page errors`);
    await page.close();
  }
});

test('arrow keys on the genre select replace the history entry instead of adding one', async () => {
  const { page, errors } = await openBooks();
  const before = await page.evaluate(() => history.length);
  await page.focus('#genre-select');
  await page.keyboard.press('ArrowDown');
  await page.keyboard.press('ArrowDown');
  await page.keyboard.press('ArrowDown');
  const s = await state(page);
  assert.equal(s.select, 'poetry');
  assert.equal(s.query, '?genre=poetry');
  assert.equal(s.count, 'Showing 2 of 15 books');
  assert.equal(await page.evaluate(() => history.length), before, 'no history entries were added');

  await page.reload();
  const reloaded = await state(page);
  assert.deepEqual([reloaded.select, reloaded.query, reloaded.count], ['poetry', '?genre=poetry', 'Showing 2 of 15 books']);
  assert.deepEqual(errors, []);
  await page.close();
});

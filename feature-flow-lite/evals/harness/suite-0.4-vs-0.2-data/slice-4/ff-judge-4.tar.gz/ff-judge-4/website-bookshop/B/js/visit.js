// Contact form on visit.html. The form is novalidate, so this script does the checking.
// Nothing is sent anywhere: on a valid submit it says plainly that this is a demo.
(function () {
  "use strict";

  var form = document.getElementById("contact-form");
  if (!form) {
    return;
  }

  var MAX_MESSAGE_LENGTH = 2000;
  var EMAIL_PATTERN = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  var CHECKED_FIELDS = ["name", "email", "message"];

  function element(tag, className, text) {
    var node = document.createElement(tag);
    if (className) {
      node.className = className;
    }
    if (text !== undefined) {
      node.textContent = text;
    }
    return node;
  }

  // Returns the message for a field that is not valid, or '' when it is fine.
  function fieldProblem(field) {
    var value = field.value.trim();
    if (field.name === "name") {
      return value ? "" : "Please enter your name.";
    }
    if (field.name === "email") {
      if (!value) {
        return "Please enter your email address.";
      }
      return EMAIL_PATTERN.test(value)
        ? ""
        : "Please enter an email address like name@example.com.";
    }
    if (field.name === "message") {
      if (!value) {
        return "Please enter a message.";
      }
      if (field.value.length > MAX_MESSAGE_LENGTH) {
        return (
          "Your message is over " +
          MAX_MESSAGE_LENGTH +
          " characters. Please shorten it."
        );
      }
    }
    return "";
  }

  function showProblem(field, message) {
    var error = document.getElementById(field.id + "-error");
    error.textContent = message;
    error.hidden = message === "";
    if (message) {
      field.setAttribute("aria-invalid", "true");
    } else {
      field.removeAttribute("aria-invalid");
    }
  }

  function updateSummary() {
    var count = form.querySelectorAll('[aria-invalid="true"]').length;
    var summary = document.getElementById("form-summary");
    if (count > 0) {
      summary.textContent =
        count === 1
          ? "Please fix 1 problem before sending."
          : "Please fix " + count + " problems before sending.";
    }
    summary.hidden = count === 0;
  }

  // Checks every required field and returns the first invalid one, or null.
  function checkAll() {
    var first = null;
    CHECKED_FIELDS.forEach(function (name) {
      var field = form.elements.namedItem(name);
      var message = fieldProblem(field);
      showProblem(field, message);
      if (message && !first) {
        first = field;
      }
    });
    updateSummary();
    return first;
  }

  function mailtoLink() {
    var name = form.elements.namedItem("name").value.trim();
    var email = form.elements.namedItem("email").value.trim();
    var topic = form.elements.namedItem("topic").selectedOptions[0].textContent;
    var message = form.elements.namedItem("message").value.trim();
    return (
      "mailto:hello@marginaliabooks.example?subject=" +
      encodeURIComponent("Website message: " + topic) +
      "&body=" +
      encodeURIComponent(name + " (" + email + ")\n\n" + message)
    );
  }

  // Replaces (never appends to) the status region, so a repeated submit shows one message.
  function showDemoMessage() {
    var name = form.elements.namedItem("name").value.trim();
    var note = element(
      "p",
      null,
      "Thanks, " +
        name +
        " — this is a demo site, so your message wasn't sent. Please email hello@marginaliabooks.example or call (555) 014-2290.",
    );
    var linkPara = element("p");
    var link = element("a", null, "Email this message instead");
    link.href = mailtoLink();
    linkPara.appendChild(link);
    document.getElementById("form-status").replaceChildren(note, linkPara);
  }

  form.addEventListener("submit", function (event) {
    event.preventDefault();
    var invalid = checkAll();
    if (invalid) {
      document.getElementById("form-status").replaceChildren();
      invalid.focus();
      return;
    }
    showDemoMessage();
  });

  form.addEventListener("input", function (event) {
    var field = event.target;
    if (field.id === "message") {
      document.getElementById("message-count").textContent = String(
        field.value.length,
      );
    }
    if (field.getAttribute("aria-invalid") === "true") {
      showProblem(field, fieldProblem(field));
      updateSummary();
    }
  });
})();

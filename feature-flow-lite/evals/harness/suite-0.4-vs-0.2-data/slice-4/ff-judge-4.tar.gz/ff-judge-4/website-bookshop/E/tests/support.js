'use strict';

// Shared helpers: a dependency-free static server for the repo root and a headless Chrome launcher.

const http = require('node:http');
const fs = require('node:fs');
const path = require('node:path');
const { chromium } = require('playwright');

const ROOT = path.resolve(__dirname, '..');

const PAGES = ['index.html', 'books.html', 'events.html', 'visit.html'];

const CONTENT_TYPES = {
  '.html': 'text/html; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.js': 'text/javascript; charset=utf-8',
  '.svg': 'image/svg+xml',
  '.png': 'image/png',
  '.ico': 'image/x-icon',
  '.json': 'application/json; charset=utf-8'
};

function sendText(res, status, text) {
  res.writeHead(status, { 'Content-Type': 'text/plain; charset=utf-8' });
  res.end(text);
}

// Serves ROOT on 127.0.0.1 with a random free port. Resolves to { server, origin }.
function startServer() {
  return new Promise((resolve, reject) => {
    const server = http.createServer((req, res) => {
      let requested;
      try {
        requested = decodeURIComponent(new URL(req.url, 'http://localhost').pathname);
      } catch (err) {
        sendText(res, 400, 'Bad request');
        return;
      }
      if (requested.includes('\0')) {
        sendText(res, 400, 'Bad request');
        return;
      }
      const file = path.join(ROOT, requested === '/' ? 'index.html' : requested);
      if (!file.startsWith(ROOT + path.sep)) {
        sendText(res, 403, 'Forbidden');
        return;
      }
      fs.readFile(file, (err, data) => {
        if (err) {
          sendText(res, 404, 'Not found');
          return;
        }
        res.writeHead(200, { 'Content-Type': CONTENT_TYPES[path.extname(file)] || 'application/octet-stream' });
        res.end(data);
      });
    });
    server.on('error', reject);
    server.listen(0, '127.0.0.1', () => {
      resolve({ server, origin: `http://127.0.0.1:${server.address().port}` });
    });
  });
}

function launchBrowser() {
  return chromium.launch({ executablePath: '/usr/bin/google-chrome', headless: true });
}

module.exports = { startServer, launchBrowser, PAGES };

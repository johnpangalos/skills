// Books page: renders the catalogue, the genre filter and the result count.
// The filter lives in the ?genre= query string so a filtered list can be bookmarked.
(function () {
  'use strict';

  var BOOKS = [
    {
      title: 'The Salt Ledger',
      author: 'Imogen Varley',
      genre: 'Fiction',
      price: 9.99,
      description:
        'A ferryman’s widow keeps the accounts of a Cornish crossing that no longer runs, and finds the entries stop adding up.',
    },
    {
      title: 'Orchard Wire',
      author: 'Ana Kettering',
      genre: 'Fiction',
      price: 8.5,
      description:
        'Three generations of a cider-making family argue over a stone wall that was built in 1911 and never explained.',
    },
    {
      title: 'A Lantern for the Night Shift',
      author: 'Daniel Ravel',
      genre: 'Fiction',
      price: 11,
      description:
        'A night-bus driver in a wet northern city keeps picking up the same passenger, who always asks for the same stop.',
    },
    {
      title: 'Field Notes in Borrowed Light',
      author: 'Priya Sandhu',
      genre: 'Poetry',
      price: 10,
      description:
        'Forty short poems written over one year of tending an allotment beside a railway line, one train at a time.',
    },
    {
      title: 'The Weather Index',
      author: 'Eamon Dunmore',
      genre: 'Poetry',
      price: 12,
      description:
        'A sequence of sonnets arranged like a shipping forecast, each one a region of the heart with its own weather.',
    },
    {
      title: 'The Locked Greenhouse',
      author: 'Ruth Calloway',
      genre: 'Crime',
      price: 8.99,
      description:
        'A retired botanist is found dead inside a greenhouse that was bolted from the inside, and nobody in the village is surprised.',
    },
    {
      title: 'Tidemark',
      author: 'Samuel Achterberg',
      genre: 'Crime',
      price: 9.5,
      description:
        'A harbour inspector looking into missing cargo finds a town that would much rather he stopped looking.',
    },
    {
      title: 'Nine Keys, No Door',
      author: 'Lydia Marchetti',
      genre: 'Crime',
      price: 7.99,
      description:
        'A house-clearance firm uncovers a ring of brass keys that open nothing on the inventory, and a name nobody will say aloud.',
    },
    {
      title: 'The Canal Men of Halvery',
      author: 'Peter Stainforth',
      genre: 'History',
      price: 18,
      description:
        'How the navvies who cut the Halvery canal shaped the streets, pubs and long family feuds of three towns.',
    },
    {
      title: 'Ration Books and Rosewater',
      author: 'Margaret Iwu',
      genre: 'History',
      price: 14.5,
      description:
        'Wartime housekeeping, black-market recipes and the women who kept a corner shop open through the winter of 1943.',
    },
    {
      title: 'Hedgerow Calendar',
      author: 'Owen Pryce',
      genre: 'Nature writing',
      price: 13,
      description:
        'A year spent walking the same three miles of hedge, noting what arrives in spring and what quietly leaves in autumn.',
    },
    {
      title: 'Mudflat Season',
      author: 'Joanna Reyes-Hall',
      genre: 'Nature writing',
      price: 12.5,
      description:
        'Wading birds, tide tables and the slow argument over a salt marsh that the parish council would prefer to drain.',
    },
    {
      title: 'On Keeping Lists',
      author: 'Theo Brannigan',
      genre: 'Essays',
      price: 11.5,
      description:
        'Short essays on index cards, shopping lists and the quiet discipline of writing things down before you forget them.',
    },
    {
      title: 'The Unfinished Room',
      author: 'Nadia Solberg',
      genre: 'Essays',
      price: 13.99,
      description:
        'Essays on houses that were never completed, and on the people who moved into them anyway and made them home.',
    },
  ];

  var ALL = 'all';

  var select = document.getElementById('genre-select');
  var list = document.getElementById('book-list');
  var count = document.getElementById('result-count');

  function toSlug(name) {
    return name.toLowerCase().replace(/\s+/g, '-');
  }

  // Genre options come from the catalogue, so every option has at least one book behind it.
  var genreNames = {};
  BOOKS.forEach(function (book) {
    book.slug = toSlug(book.genre);
    genreNames[book.slug] = book.genre;
  });
  var genres = Object.keys(genreNames).sort();

  function buildOptions() {
    var all = document.createElement('option');
    all.value = ALL;
    all.textContent = 'All genres';
    select.appendChild(all);
    genres.forEach(function (slug) {
      var option = document.createElement('option');
      option.value = slug;
      option.textContent = genreNames[slug];
      select.appendChild(option);
    });
  }

  function bookCard(book) {
    var item = document.createElement('li');
    item.className = 'book-card';

    var title = document.createElement('h2');
    title.textContent = book.title;

    var author = document.createElement('p');
    author.className = 'byline';
    author.textContent = 'by ' + book.author;

    var meta = document.createElement('p');
    meta.className = 'book-meta';
    var genre = document.createElement('span');
    genre.className = 'book-genre';
    genre.textContent = book.genre;
    var price = document.createElement('span');
    price.textContent = '£' + book.price.toFixed(2);
    meta.appendChild(genre);
    meta.appendChild(price);

    var description = document.createElement('p');
    description.textContent = book.description;

    item.appendChild(title);
    item.appendChild(author);
    item.appendChild(meta);
    item.appendChild(description);
    return item;
  }

  function render(slug) {
    var shown = BOOKS.filter(function (book) {
      return slug === ALL || book.slug === slug;
    });
    list.textContent = '';
    shown.forEach(function (book) {
      list.appendChild(bookCard(book));
    });
    select.value = slug;
    count.textContent = 'Showing ' + shown.length + ' of ' + BOOKS.length + ' books';
  }

  // Matches the slug case-insensitively after trimming; anything unknown, empty or missing means All.
  function genreFromQuery() {
    var raw = (new URLSearchParams(window.location.search).get('genre') || '').trim().toLowerCase();
    return genres.indexOf(raw) === -1 ? ALL : raw;
  }

  function urlFor(slug) {
    var url = new URL(window.location.href);
    if (slug === ALL) {
      url.searchParams.delete('genre');
    } else {
      url.searchParams.set('genre', slug);
    }
    return url;
  }

  buildOptions();
  var initial = genreFromQuery();
  render(initial);
  history.replaceState(null, '', urlFor(initial));

  select.addEventListener('change', function () {
    var slug = select.value;
    render(slug);
    history.pushState(null, '', urlFor(slug));
  });

  window.addEventListener('popstate', function () {
    render(genreFromQuery());
  });
})();

// Stock list for the books page. Genres are derived from this data, so every
// genre shown in the filter has at least one book.
const CATALOG_BOOKS = [
  {
    title: 'The Salt Road Keeper',
    author: 'Maren Holt',
    genre: 'Fiction',
    price: 9.99,
    description: 'A ferry captain in a drowned fishing town takes in a runaway girl who arrives carrying a ledger that belonged to her late father.'
  },
  {
    title: 'Quiet Hours at Dunmere Station',
    author: 'Tobias Greaves',
    genre: 'Fiction',
    price: 11.5,
    description: 'Over one winter timetable, the night porter of a closed railway station keeps a list of the strangers who still come through the door.'
  },
  {
    title: 'A House of Paper Moths',
    author: 'Adaeze Okafor',
    genre: 'Fiction',
    price: 10,
    description: 'Three sisters clear out their mother\'s stationery shop after forty years and discover the drawers of letters she never sold.'
  },
  {
    title: 'Inventory of Small Weather',
    author: 'Lydia Crane',
    genre: 'Poetry',
    price: 12,
    description: 'Poems about rain gauges, kitchen tables and the slow business of noticing, arranged across the four seasons of one Yorkshire farm.'
  },
  {
    title: 'Field Notes for a Kitchen Table',
    author: 'Nell Ambrose',
    genre: 'Poetry',
    price: 10.5,
    description: 'A short sequence written during a year of working from home, full of bread, neighbours and the wobble of the garden fence.'
  },
  {
    title: 'Ink and Ironworks',
    author: 'Dr Helen Marsh',
    genre: 'History',
    price: 18,
    description: 'How Sheffield\'s printing trade grew up around its foundries, told through apprentices, paper mills and the strikes that followed.'
  },
  {
    title: 'The Canal Men',
    author: 'Joseph Rendell',
    genre: 'History',
    price: 16.95,
    description: 'The working lives of the lock-keepers and boatmen who moved coal and cloth across the Midlands before the railways arrived.'
  },
  {
    title: 'Ration Books and Rosebushes',
    author: 'Alice Ferreira',
    genre: 'History',
    price: 14,
    description: 'Ordinary households on the home front, rebuilt from wartime diaries, seed catalogues and the back pages of women\'s magazines.'
  },
  {
    title: 'Hedgerow: A Year of Small Birds',
    author: 'Owen Pryce',
    genre: 'Nature',
    price: 13.99,
    description: 'Month by month, a field guide to the wrens, dunnocks and finches that live in the hedges at the edge of a village.'
  },
  {
    title: 'Tidepool Field Guide for Beginners',
    author: 'Mina Sato',
    genre: 'Nature',
    price: 8.75,
    description: 'A pocket guide to the crabs, anemones and wracks of the rocky shore, with simple keys and advice on leaving the pools as you found them.'
  },
  {
    title: 'Bramble and the Lost Kite',
    author: 'Sam Adeyemi',
    genre: 'Young readers',
    price: 7.99,
    description: 'Bramble the hedgehog chases a runaway kite across the common and learns that the best finds come from asking a friend for help.'
  },
  {
    title: 'The Clockwork Gull',
    author: 'Ruth Calder',
    genre: 'Young readers',
    price: 6.5,
    description: 'When a mechanical seabird starts delivering letters to the wrong houses, twins Ada and Sol set out to find out who is winding it up.'
  }
];

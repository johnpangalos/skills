'use strict';

const { test, before, after } = require('node:test');
const assert = require('node:assert/strict');
const { startServer, launchBrowser, PAGES } = require('./support');

let server;
let origin;
let browser;

before(async () => {
  ({ server, origin } = await startServer());
  browser = await launchBrowser();
});

after(async () => {
  await browser.close();
  server.close();
});

// Opens a page, records every request, response and console problem, and runs the optional interaction.
async function observe(file, interact) {
  const page = await browser.newPage();
  const requests = [];
  const problems = [];
  page.on('request', (req) => requests.push(req.url()));
  page.on('requestfailed', (req) => problems.push(`request failed: ${req.url()}`));
  page.on('response', (res) => {
    if (res.status() >= 400) problems.push(`HTTP ${res.status()}: ${res.url()}`);
  });
  page.on('console', (msg) => {
    if (msg.type() === 'error' || msg.type() === 'warning') problems.push(`console ${msg.type()}: ${msg.text()}`);
  });
  page.on('pageerror', (err) => problems.push(`page error: ${err.message}`));
  await page.goto(`${origin}/${file}`);
  if (interact) await interact(page);
  await page.close();
  return { requests, problems };
}

test('every page loads only from the local origin with no console errors', async () => {
  for (const file of PAGES) {
    const { requests, problems } = await observe(file);
    assert.ok(requests.length > 0, `${file} made requests`);
    for (const url of requests) {
      assert.ok(url.startsWith(`${origin}/`), `${file} requested external URL ${url}`);
    }
    assert.deepEqual(problems, [], `${file} should have no console errors or failed requests`);
  }
});

test('interactions on the books and visit pages stay local and error free', async () => {
  const books = await observe('books.html', async (page) => {
    await page.selectOption('#genre-select', 'history');
  });
  const visit = await observe('visit.html', async (page) => {
    await page.click('#contact-form button[type="submit"]');
    await page.fill('#name', 'Ada');
    await page.fill('#email', 'ada@example.com');
    await page.fill('#message', 'Hello');
    await page.click('#contact-form button[type="submit"]');
  });
  for (const { requests, problems } of [books, visit]) {
    for (const url of requests) {
      assert.ok(url.startsWith(`${origin}/`), `external request ${url}`);
    }
    assert.deepEqual(problems, []);
  }
});

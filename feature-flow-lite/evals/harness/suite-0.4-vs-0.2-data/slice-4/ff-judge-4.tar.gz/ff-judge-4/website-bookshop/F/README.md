# Marginalia Books

The website for Marginalia Books, a fictional independent bookshop on Lantern Street in Halvery. It is four static pages in plain HTML, CSS and JavaScript. There is no build step, no framework, no web font and no request to any other host.

## Pages

- `index.html`: home. Who the shop is, what makes it different, links to the other pages, and a preview of staff picks.
- `books.html`: the catalogue of 14 fictional titles across six genres. A genre select narrows the list. The choice is kept in the URL, for example `books.html?genre=poetry`, so filtered lists can be bookmarked, and Back and Forward restore it.
- `events.html`: dated events in date order. Events that have already passed, judged by the visitor's local date, move into a "Past events" section. Each event says whether booking is needed.
- `visit.html`: opening hours, the address, phone and email, directions and access notes, and a contact form. The form is a demo. It validates input but does not send anything.

Shared pieces:

- `css/styles.css` holds the styles. The colour palette is in CSS custom properties at the top of the file.
- `js/main.js` runs on every page. It handles the mobile menu, the skip link and the year in the footer.
- `js/books.js`, `js/events.js` and `js/visit.js` run on their own pages.
- `favicon.svg` is the site icon.

## Run it locally

The site is static, so any static file server works. From the project root, use either of these:

```sh
npx http-server -p 8080 -s .
```

```sh
python3 -m http.server 8080
```

Then open http://localhost:8080/ in a browser. JavaScript must be enabled: the catalogue and the event list are rendered by scripts.

## Tests and lint

The tests drive headless Chrome through Playwright. They start their own static server on a free port, so no server needs to be running first.

```sh
npm test                 # node --test tests/
npx prettier --check .
npx eslint js/
```

The tests use Playwright from the project if it is installed, and otherwise from the global install at `/opt/node22/lib/node_modules/playwright`. They launch Chrome from `CHROME_PATH`, or from `/usr/bin/google-chrome` if that is unset or missing. Playwright's bundled browser is used if neither exists. There is no `npm install` step, because the project has no dependencies.

The test files are in `tests/`:

- `pages.test.mjs`: page structure, skip link, heading order, console errors and requests that leave the server.
- `nav.test.mjs`: navigation order, the mobile menu, keyboard use and resizing with the menu open.
- `books.test.mjs`: the genre filter, the URL state, and the hostile `?genre=` values.
- `events.test.mjs`: upcoming and past events under a mocked clock, including an event dated today.
- `contact.test.mjs`: contact form validation and the demo status.
- `responsive.test.mjs`: 360px, 768px and 1280px layouts, touch target sizes, focus rings and reduced motion.

## Notes for editing

- Books live in the array at the top of `js/books.js`. Each book needs a title, author, genre, price and description. A genre with no books does not appear in the select.
- Events live in `events.html` as list items with a `<time datetime="YYYY-MM-DDTHH:MM">` element. Keep them in date order. The script moves past events itself.
- The contact form has no backend. Connecting it to a real service would mean changing `js/visit.js` and removing the demo notice in `visit.html`.

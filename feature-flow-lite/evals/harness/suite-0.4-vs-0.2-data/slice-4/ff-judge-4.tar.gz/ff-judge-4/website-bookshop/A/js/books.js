// Genre filter for the books page. The selected genre lives in ?genre=.
(function () {
  'use strict';

  var select = document.getElementById('genre');
  var count = document.getElementById('result-count');
  var books = Array.prototype.slice.call(document.querySelectorAll('.book'));
  var genres = Array.prototype.map.call(select.options, function (option) {
    return option.value;
  });

  // Case-insensitive match on the first ?genre= value. Anything unknown means All.
  function genreFromUrl() {
    var wanted = (new URLSearchParams(location.search).get('genre') || '').trim().toLowerCase();
    var match = genres.filter(function (genre) {
      return genre.toLowerCase() === wanted;
    })[0];
    return match || 'All';
  }

  // Same URL with the genre parameter set, or removed for All.
  function urlFor(genre) {
    var url = new URL(location.href);
    if (genre === 'All') {
      url.searchParams.delete('genre');
    } else {
      url.searchParams.set('genre', genre);
    }
    return url.pathname + url.search;
  }

  function applyGenre(genre) {
    var shown = 0;
    books.forEach(function (book) {
      var match = genre === 'All' || book.getAttribute('data-genre') === genre;
      book.hidden = !match;
      if (match) {
        shown += 1;
      }
    });
    select.value = genre;
    count.textContent = 'Showing ' + shown + ' of ' + books.length + ' books';
  }

  select.addEventListener('change', function () {
    history.pushState(null, '', urlFor(select.value));
    applyGenre(select.value);
  });

  window.addEventListener('popstate', function () {
    applyGenre(genreFromUrl());
  });

  applyGenre(genreFromUrl());
})();

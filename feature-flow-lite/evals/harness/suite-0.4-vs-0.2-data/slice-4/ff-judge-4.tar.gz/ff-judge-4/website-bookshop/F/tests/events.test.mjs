import { describe, it, before, after } from 'node:test';
import assert from 'node:assert/strict';
import { dirname, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
import { startServer } from './helpers/server.mjs';
import { launchBrowser } from './helpers/browser.mjs';
import { openPage } from './helpers/session.mjs';

const ROOT = resolve(dirname(fileURLToPath(import.meta.url)), '..');
const ORDINARY_DAY = new Date(2026, 10, 16, 12, 0);

describe('events split into upcoming and past by the local date', () => {
  let server;
  let browser;

  before(async () => {
    server = await startServer(ROOT);
    browser = await launchBrowser();
  });

  after(async () => {
    await browser.close();
    await server.close();
  });

  // Lists the event titles in one list, along with each event's date and booking note.
  async function listEvents(page, listId) {
    return page.$$eval(`#${listId} > li`, (items) =>
      items.map((item) => ({
        title: item.querySelector('h2').textContent,
        date: item.querySelector('time').getAttribute('datetime'),
        booking: item.querySelector('.event-booking').textContent,
      })),
    );
  }

  it('lists events in date order with a time element and a booking note on each', async () => {
    const { page, problems, close } = await openPage(browser, `${server.url}/events.html`, {
      clock: ORDINARY_DAY,
    });
    try {
      const upcoming = await listEvents(page, 'upcoming-events');
      const past = await listEvents(page, 'past-event-list');
      const all = [...past, ...upcoming];

      assert.equal(all.length, 7);
      assert.ok(upcoming.length >= 5, 'expected at least five upcoming events');
      const dates = all.map((event) => event.date);
      assert.deepEqual(dates, [...dates].sort(), 'events are not in date order');
      for (const event of all) {
        assert.match(event.date, /^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}$/, event.title);
        assert.match(event.booking, /(Booking required|No booking needed)/, event.title);
      }
      assert.deepEqual(problems, []);
    } finally {
      await close();
    }
  });

  it('shows the 2026 event under a labelled Past events heading on 16 November 2026', async () => {
    const { page, close } = await openPage(browser, `${server.url}/events.html`, {
      clock: ORDINARY_DAY,
    });
    try {
      const past = await listEvents(page, 'past-event-list');
      assert.deepEqual(
        past.map((event) => event.title),
        ['Autumn Open Mic for Poets'],
      );
      assert.equal(await page.getByRole('heading', { name: 'Past events' }).isVisible(), true);
      assert.equal(await page.locator('#no-upcoming').isVisible(), false);
      assert.equal(await page.locator('#upcoming-events').isVisible(), true);
    } finally {
      await close();
    }
  });

  it('keeps an event dated today in the upcoming list when it is 23:30 locally', async () => {
    const lateOnStorytimeDay = new Date(2027, 2, 6, 23, 30);
    const { page, problems, close } = await openPage(browser, `${server.url}/events.html`, {
      clock: lateOnStorytimeDay,
    });
    try {
      const upcoming = await listEvents(page, 'upcoming-events');
      const past = await listEvents(page, 'past-event-list');
      assert.equal(upcoming[0].title, 'Saturday Storytime for under-sixes');
      assert.equal(upcoming[0].date, '2027-03-06T11:00');
      assert.deepEqual(
        past.map((event) => event.title),
        [
          'Autumn Open Mic for Poets',
          'Reading the Marsh: a nature writing evening',
          'Crime Club: Locked Room Evening',
        ],
      );
      assert.deepEqual(problems, []);
    } finally {
      await close();
    }
  });

  it('shows a plain message instead of an empty list when every event has passed', async () => {
    const { page, problems, close } = await openPage(browser, `${server.url}/events.html`, {
      clock: new Date(2028, 0, 1, 9, 0),
    });
    try {
      const message = page.locator('#no-upcoming');
      assert.equal(await message.isVisible(), true);
      assert.match(await message.textContent(), /There are no upcoming events/);
      assert.equal(await page.locator('#upcoming-events').isHidden(), true);
      assert.equal((await listEvents(page, 'past-event-list')).length, 7);
      assert.deepEqual(problems, []);
    } finally {
      await close();
    }
  });
});

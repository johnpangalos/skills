'use strict';

const { test, before, after } = require('node:test');
const assert = require('node:assert/strict');
const { startServer, launchBrowser, PAGES } = require('./support');

let server;
let origin;
let browser;

before(async () => {
  ({ server, origin } = await startServer());
  browser = await launchBrowser();
});

after(async () => {
  await browser.close();
  server.close();
});

async function openPage(file) {
  const page = await browser.newPage();
  await page.goto(`${origin}/${file}`);
  return page;
}

test('shared nav is identical on every page with aria-current on the current page only', async () => {
  const navs = [];
  for (const file of PAGES) {
    const page = await openPage(file);
    const info = await page.evaluate(() => {
      const nav = document.querySelector('header nav[aria-label="Main"]');
      const current = [...nav.querySelectorAll('a[aria-current="page"]')].map((a) => a.getAttribute('href'));
      return { html: nav.outerHTML.replace(/ aria-current="page"/g, ''), current };
    });
    assert.deepEqual(info.current, [file], `${file} should mark only its own link as current`);
    navs.push(info.html);
    await page.close();
  }
  for (const html of navs) {
    assert.equal(html, navs[0]);
  }
  const links = await (await openPage('index.html')).$$eval('header nav a', (as) => as.map((a) => a.getAttribute('href')));
  assert.deepEqual(links, ['index.html', 'books.html', 'events.html', 'visit.html']);
});

test('every internal link resolves to an existing file and no link leaves the origin', async () => {
  for (const file of PAGES) {
    const page = await openPage(file);
    const hrefs = await page.$$eval('a[href]', (as) => as.map((a) => a.getAttribute('href')));
    for (const href of hrefs) {
      assert.doesNotMatch(href, /^(https?:)?\/\//, `${file} links externally to ${href}`);
      if (href.startsWith('#')) continue;
      const target = new URL(href, `${origin}/${file}`);
      const response = await fetch(target);
      assert.equal(response.status, 200, `${file} link ${href} should resolve`);
    }
    await page.close();
  }
});

test('each page has lang, a unique descriptive title and a viewport meta', async () => {
  const titles = new Set();
  for (const file of PAGES) {
    const page = await openPage(file);
    const info = await page.evaluate(() => ({
      lang: document.documentElement.lang,
      title: document.title,
      viewport: document.querySelector('meta[name="viewport"]')?.getAttribute('content') || ''
    }));
    assert.equal(info.lang, 'en', `${file} lang`);
    assert.match(info.title, /Marginalia Books/, `${file} title`);
    assert.match(info.viewport, /width=device-width/, `${file} viewport meta`);
    titles.add(info.title);
    await page.close();
  }
  assert.equal(titles.size, PAGES.length, 'titles must be unique');
});

test('each page has one h1, no skipped heading levels and the landmark regions', async () => {
  for (const file of PAGES) {
    const page = await openPage(file);
    const info = await page.evaluate(() => {
      const headings = [...document.querySelectorAll('main h1, main h2, main h3, main h4, main h5, main h6')]
        .map((h) => Number(h.tagName.slice(1)));
      return {
        headings,
        h1Count: document.querySelectorAll('h1').length,
        landmarks: {
          header: document.querySelectorAll('body > header').length,
          nav: document.querySelectorAll('header > nav').length,
          main: document.querySelectorAll('body > main#main').length,
          footer: document.querySelectorAll('body > footer').length
        }
      };
    });
    assert.equal(info.h1Count, 1, `${file} should have exactly one h1`);
    assert.equal(info.headings[0], 1, `${file} should start its content with the h1`);
    for (let i = 1; i < info.headings.length; i++) {
      assert.ok(info.headings[i] <= info.headings[i - 1] + 1, `${file} skips a heading level`);
    }
    assert.deepEqual(info.landmarks, { header: 1, nav: 1, main: 1, footer: 1 }, `${file} landmarks`);
    await page.close();
  }
});

test('skip link is the first focusable element and moves focus to main', async () => {
  for (const file of PAGES) {
    const page = await openPage(file);
    await page.keyboard.press('Tab');
    const first = await page.evaluate(() => ({
      text: document.activeElement.textContent.trim(),
      href: document.activeElement.getAttribute('href')
    }));
    assert.deepEqual(first, { text: 'Skip to main content', href: '#main' }, `${file} first Tab stop`);
    await page.keyboard.press('Enter');
    const target = await page.evaluate(() => document.querySelector('main').id);
    assert.equal(target, 'main');
    assert.equal(await page.evaluate(() => location.hash), '#main');
    await page.close();
  }
});

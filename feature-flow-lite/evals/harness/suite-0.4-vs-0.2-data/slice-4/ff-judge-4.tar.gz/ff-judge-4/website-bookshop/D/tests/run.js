'use strict';

// Loads every page of the site in headless Chromium and checks the acceptance
// criteria. Run with: NODE_PATH=$(npm root -g) node tests/run.js [name-filter]

const assert = require('assert');
const fs = require('fs');
const http = require('http');
const path = require('path');
const { chromium } = require('playwright');

const ROOT = path.join(__dirname, '..');
const PAGES = ['index.html', 'books.html', 'events.html', 'visit.html'];
const WIDTHS = [360, 414, 768, 1280];
const TYPES = {
  '.html': 'text/html; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.js': 'text/javascript; charset=utf-8'
};
const NAME_ERROR = 'Enter your name. Spaces alone do not count.';
const EMAIL_ERROR = 'Enter an email address in the form name@example.com.';
const MESSAGE_ERROR = 'Enter a message for the shop. Spaces alone do not count.';
const DEMO_MESSAGE = 'Demo only: this form does not send anything, so your message was not sent. To reach the shop, call 01632 960 417 or visit us on Tanners Row.';

function startServer() {
  return new Promise((resolve) => {
    const server = http.createServer((req, res) => {
      const requested = decodeURIComponent(new URL(req.url, 'http://localhost').pathname);
      const file = path.join(ROOT, requested === '/' ? 'index.html' : requested);
      if (!file.startsWith(ROOT + path.sep) || !fs.existsSync(file) || fs.statSync(file).isDirectory()) {
        res.writeHead(404, { 'Content-Type': 'text/plain; charset=utf-8' });
        res.end('Not found');
        return;
      }
      res.writeHead(200, { 'Content-Type': TYPES[path.extname(file)] || 'application/octet-stream' });
      fs.createReadStream(file).pipe(res);
    });
    server.listen(0, '127.0.0.1', () => resolve(server));
  });
}

// Opens a page in a fresh context and records console errors, dialogs,
// requests to other origins and non-GET requests.
async function openPage(state, route, options = {}) {
  const context = await state.browser.newContext({
    viewport: { width: options.width || 1280, height: 900 },
    reducedMotion: options.reducedMotion || 'no-preference'
  });
  state.contexts.push(context);
  const page = await context.newPage();
  const seen = { errors: [], dialogs: [], external: [], writes: 0 };
  page.on('console', (message) => {
    if (message.type() === 'error') seen.errors.push(message.text());
  });
  page.on('pageerror', (error) => seen.errors.push(error.message));
  page.on('dialog', (dialog) => {
    seen.dialogs.push(dialog.message());
    dialog.dismiss();
  });
  page.on('request', (request) => {
    const url = request.url();
    if (!url.startsWith(state.base) && !url.startsWith('data:')) seen.external.push(url);
    if (request.method() !== 'GET') seen.writes += 1;
  });
  await page.goto(state.base + '/' + route);
  return { page, seen };
}

function assertClean(seen, name) {
  assert.deepStrictEqual(seen.external, [], `${name} made requests to other origins`);
  assert.deepStrictEqual(seen.errors, [], `${name} logged console errors`);
  assert.deepStrictEqual(seen.dialogs, [], `${name} opened a dialog`);
}

async function testNavAndStructure(state) {
  const titles = new Set();
  for (const name of PAGES) {
    const { page } = await openPage(state, name);
    const info = await page.evaluate(() => ({
      lang: document.documentElement.lang,
      title: document.title,
      h1Count: document.querySelectorAll('h1').length,
      mainCount: document.querySelectorAll('main').length,
      skipHref: document.querySelector('a.skip-link') && document.querySelector('a.skip-link').getAttribute('href'),
      navLinks: Array.from(document.querySelectorAll('nav[aria-label="Main"] a')).map((link) => [
        link.getAttribute('href'),
        link.getAttribute('aria-current')
      ]),
      lorem: /lorem ipsum/i.test(document.body.innerText)
    }));
    assert.strictEqual(info.lang, 'en', `${name} lang`);
    assert.ok(info.title.length > 0, `${name} has no title`);
    titles.add(info.title);
    assert.strictEqual(info.h1Count, 1, `${name} h1 count`);
    assert.strictEqual(info.mainCount, 1, `${name} main count`);
    assert.strictEqual(info.skipHref, '#main', `${name} skip link`);
    assert.deepStrictEqual(
      info.navLinks,
      PAGES.map((target) => [target, target === name ? 'page' : null]),
      `${name} nav links or aria-current`
    );
    assert.strictEqual(info.lorem, false, `${name} contains lorem ipsum`);
  }
  assert.strictEqual(titles.size, PAGES.length, 'page titles are not unique');
}

async function testInternalLinks(state) {
  for (const name of PAGES) {
    const { page } = await openPage(state, name);
    const hrefs = await page.$$eval('a[href]', (links) => links.map((link) => link.getAttribute('href')));
    for (const href of hrefs.filter((value) => !value.startsWith('#'))) {
      const target = new URL(href, state.base + '/' + name);
      const response = await fetch(target);
      assert.strictEqual(response.status, 200, `${name} links to ${href}, which returned ${response.status}`);
    }
  }
}

async function testNoExternalOrConsoleErrors(state) {
  for (const name of PAGES) {
    const { seen } = await openPage(state, name);
    assertClean(seen, name);
  }
  const { seen } = await openPage(state, 'books.html?genre=poetry');
  assertClean(seen, 'books.html?genre=poetry');
}

async function testOverflow(state) {
  for (const width of WIDTHS) {
    for (const name of PAGES) {
      const { page } = await openPage(state, name, { width });
      const sizes = await page.evaluate(() => ({
        scroll: document.documentElement.scrollWidth,
        viewport: window.innerWidth
      }));
      assert.ok(sizes.scroll <= sizes.viewport, `${name} at ${width}px scrolls sideways (${sizes.scroll} > ${sizes.viewport})`);
    }
  }
}

async function testCatalogueContent(state) {
  const { page } = await openPage(state, 'books.html');
  const books = await page.$$eval('.book-card', (cards) => cards.map((card) => ({
    title: card.querySelector('h2') && card.querySelector('h2').textContent.trim(),
    author: card.querySelector('.book-author') && card.querySelector('.book-author').textContent.trim(),
    genre: card.querySelector('.book-genre') && card.querySelector('.book-genre').textContent.trim(),
    description: card.querySelector('.book-description') && card.querySelector('.book-description').textContent.trim(),
    price: card.querySelector('.book-price') && card.querySelector('.book-price').textContent.trim()
  })));
  assert.ok(books.length >= 8, `expected at least 8 books, found ${books.length}`);
  for (const book of books) {
    assert.ok(book.title && book.author && book.genre && book.description, `incomplete book: ${JSON.stringify(book)}`);
    assert.match(book.price, /^£\d+\.\d{2}$/, `bad price for ${book.title}`);
  }
  const genres = new Set(books.map((book) => book.genre));
  assert.ok(genres.size >= 4, `expected at least 4 genres, found ${genres.size}`);
  const radioCount = await page.$$eval('input[name="genre"]', (inputs) => inputs.length);
  assert.strictEqual(radioCount, genres.size + 1, 'filter needs one option per genre plus All');
}

async function expectCards(page, count, label) {
  const found = await page.$$eval('.book-card', (cards) => cards.length);
  assert.strictEqual(found, count, `${label}: expected ${count} book cards, found ${found}`);
}

async function checkedGenre(page) {
  return page.$eval('input[name="genre"]:checked', (input) => input.value);
}

async function testGenreFilter(state) {
  const { page, seen } = await openPage(state, 'books.html');
  assert.strictEqual(await page.getAttribute('#result-count', 'aria-live'), 'polite');
  await page.getByRole('radio', { name: 'Poetry', exact: true }).check();
  await expectCards(page, 2, 'Poetry');
  assert.strictEqual(await page.textContent('#result-count'), 'Showing 2 books in Poetry.');
  assert.strictEqual(new URL(page.url()).searchParams.get('genre'), 'poetry');

  await page.getByRole('radio', { name: 'Poetry', exact: true }).focus();
  await page.keyboard.press('ArrowRight');
  assert.strictEqual(await checkedGenre(page), 'young-readers', 'arrow key should move the genre selection');
  await expectCards(page, 2, 'Young readers');
  assert.strictEqual(new URL(page.url()).searchParams.get('genre'), 'young-readers');

  await page.getByRole('radio', { name: 'All', exact: true }).check();
  await expectCards(page, 12, 'All');
  assert.strictEqual(await page.textContent('#result-count'), 'Showing all 12 books.');
  assert.strictEqual(new URL(page.url()).searchParams.has('genre'), false, 'All should clear the genre parameter');

  const { page: loaded } = await openPage(state, 'books.html?genre=history');
  await expectCards(loaded, 3, 'history URL');
  assert.strictEqual(await checkedGenre(loaded), 'history');
  assertClean(seen, 'books.html');
}

async function testHostileGenreParams(state) {
  const cases = [
    ['books.html?genre=', 12, 'all', null],
    ['books.html?genre=' + encodeURIComponent('<img src=x onerror=alert(1)>'), 12, 'all', null],
    ['books.html?genre=unknown', 12, 'all', null],
    ['books.html?genre=FICTION', 3, 'fiction', 'fiction']
  ];
  for (const [route, count, checked, urlGenre] of cases) {
    const { page, seen } = await openPage(state, route);
    await expectCards(page, count, route);
    assert.strictEqual(await checkedGenre(page), checked, `${route} checked option`);
    assert.strictEqual(new URL(page.url()).searchParams.get('genre'), urlGenre, `${route} URL genre`);
    assert.strictEqual(await page.$$eval('img', (images) => images.length), 0, `${route} injected an image`);
    assert.strictEqual(await page.evaluate(() => document.documentElement.innerHTML.includes('onerror=')), false, `${route} echoed markup`);
    assertClean(seen, route);
  }
}

async function testEvents(state) {
  const { page } = await openPage(state, 'events.html');
  const events = await page.$$eval('main .event', (items) => items.map((item) => ({
    datetime: item.querySelector('time') && item.querySelector('time').getAttribute('datetime'),
    date: item.querySelector('time') && item.querySelector('time').textContent.trim(),
    time: item.querySelector('.event-time') && item.querySelector('.event-time').textContent.trim(),
    title: item.querySelector('h2') && item.querySelector('h2').textContent.trim(),
    description: item.querySelector('p:last-child') && item.querySelector('p:last-child').textContent.trim()
  })));
  assert.ok(events.length >= 4, `expected at least 4 events, found ${events.length}`);
  for (const event of events) {
    assert.match(event.datetime, /^\d{4}-\d{2}-\d{2}$/, `bad datetime for ${event.title}`);
    assert.ok(event.date && event.time && event.title && event.description, `incomplete event: ${JSON.stringify(event)}`);
  }
}

async function testVisitContent(state) {
  const { page, seen } = await openPage(state, 'visit.html');
  const info = await page.evaluate(() => ({
    hourRows: document.querySelectorAll('dl.hours dt').length,
    address: !!document.querySelector('address'),
    labels: ['name', 'email', 'message'].map((id) => {
      const label = document.querySelector('label[for="' + id + '"]');
      return label ? label.textContent.trim() : '';
    })
  }));
  assert.ok(info.hourRows >= 5, `expected hours rows, found ${info.hourRows}`);
  assert.strictEqual(info.address, true, 'address element missing');
  assert.deepStrictEqual(info.labels, ['Name', 'Email', 'Message']);
  assertClean(seen, 'visit.html');
}

async function fieldState(page, id) {
  return page.evaluate((fieldId) => {
    const input = document.getElementById(fieldId);
    const described = document.getElementById(input.getAttribute('aria-describedby'));
    return {
      invalid: input.getAttribute('aria-invalid'),
      error: described ? described.textContent : null
    };
  }, id);
}

async function testFormValidation(state) {
  const { page } = await openPage(state, 'visit.html');
  await page.getByRole('button', { name: 'Send message', exact: true }).click();
  assert.deepStrictEqual(await fieldState(page, 'name'), { invalid: 'true', error: NAME_ERROR });
  assert.deepStrictEqual(await fieldState(page, 'email'), { invalid: 'true', error: EMAIL_ERROR });
  assert.deepStrictEqual(await fieldState(page, 'message'), { invalid: 'true', error: MESSAGE_ERROR });
  assert.strictEqual(await page.evaluate(() => document.activeElement.id), 'name', 'focus should move to the first invalid field');
  assert.strictEqual(await page.textContent('#form-status'), '', 'no status before a valid submit');

  await page.fill('#name', 'Ada Lovelace');
  assert.deepStrictEqual(await fieldState(page, 'name'), { invalid: 'false', error: '' }, 'name error should clear once fixed');
}

async function testFormDemoSubmit(state) {
  const { page, seen } = await openPage(state, 'visit.html');
  await page.fill('#name', 'Ada Lovelace');
  await page.fill('#email', 'ada@example.com');
  await page.fill('#message', 'Do you stock the new Hedgerow reprint?');
  await page.getByRole('button', { name: 'Send message', exact: true }).click();
  assert.strictEqual(await page.textContent('#form-status'), DEMO_MESSAGE);
  assert.strictEqual(new URL(page.url()).search, '', 'form must not navigate with the field values');
  assert.strictEqual(seen.writes, 0, 'submit must not send a request');
  assert.deepStrictEqual(seen.external, []);
}

async function testHostileFormInput(state) {
  const { page, seen } = await openPage(state, 'visit.html');
  await page.fill('#name', '   ');
  await page.fill('#email', 'reader@example.com');
  await page.fill('#message', 'Hello');
  await page.getByRole('button', { name: 'Send message', exact: true }).click();
  assert.deepStrictEqual(await fieldState(page, 'name'), { invalid: 'true', error: NAME_ERROR }, 'whitespace name');
  assert.strictEqual(await page.evaluate(() => document.activeElement.id), 'name');

  await page.fill('#name', 'Ada');
  await page.fill('#email', 'a@');
  await page.fill('#message', '   \n\t ');
  await page.getByRole('button', { name: 'Send message', exact: true }).click();
  assert.deepStrictEqual(await fieldState(page, 'email'), { invalid: 'true', error: EMAIL_ERROR }, 'a@ email');
  assert.deepStrictEqual(await fieldState(page, 'message'), { invalid: 'true', error: MESSAGE_ERROR }, 'whitespace message');
  assert.strictEqual(await page.evaluate(() => document.activeElement.id), 'email', 'focus goes to first invalid field');

  const longMessage = 'Long message test. '.repeat(300).slice(0, 5000);
  await page.setViewportSize({ width: 360, height: 800 });
  await page.fill('#email', 'ada@example.com');
  await page.fill('#message', longMessage);
  assert.strictEqual(await page.inputValue('#message'), longMessage);
  const overflow = await page.evaluate(() => document.documentElement.scrollWidth - window.innerWidth);
  assert.ok(overflow <= 0, `5000 character message overflows at 360px by ${overflow}px`);
  await page.getByRole('button', { name: 'Send message', exact: true }).click();
  assert.strictEqual(await page.textContent('#form-status'), DEMO_MESSAGE);

  await page.getByRole('button', { name: 'Send message', exact: true }).dblclick();
  assert.strictEqual(await page.textContent('#form-status'), DEMO_MESSAGE, 'double submit must not duplicate the notice');
  assert.strictEqual(await page.$$eval('#form-status > *', (items) => items.length), 0);
  assert.strictEqual(seen.writes, 0, 'no request may be sent by any submit');
}

async function testFocusAndMotion(state) {
  const { page } = await openPage(state, 'index.html');
  await page.keyboard.press('Tab');
  assert.strictEqual(await page.evaluate(() => document.activeElement.className), 'skip-link');
  assert.strictEqual(await page.evaluate(() => getComputedStyle(document.activeElement).outlineStyle), 'solid', 'focus ring missing');

  const { page: books } = await openPage(state, 'books.html');
  const cursor = await books.$eval('.book-card', (card) => getComputedStyle(card).cursor);
  assert.notStrictEqual(cursor, 'pointer', 'non-link cards must not look clickable');

  const { page: normal } = await openPage(state, 'index.html');
  const normalDuration = await normal.$eval('.site-nav a', (link) => getComputedStyle(link).transitionDuration);
  assert.notStrictEqual(normalDuration, '0s', 'links should animate without the reduced-motion preference');
  const { page: reduced } = await openPage(state, 'index.html', { reducedMotion: 'reduce' });
  const reducedDuration = await reduced.$eval('.site-nav a', (link) => getComputedStyle(link).transitionDuration);
  assert.strictEqual(reducedDuration, '0s', 'reduced motion should remove transitions');
}

async function testCatalogRendersTextOnly(state) {
  const data = fs.readFileSync(path.join(ROOT, 'js', 'catalog-data.js'), 'utf8');
  const hostile = data.replace("title: 'The Salt Road Keeper',", "title: '<b id=x>Bold</b>',");
  assert.notStrictEqual(hostile, data, 'catalog data no longer has the expected first title');
  const { page, seen } = await openPage(state, 'books.html');
  await page.route('**/js/catalog-data.js', (route) => route.fulfill({
    contentType: 'text/javascript; charset=utf-8',
    body: hostile
  }));
  await page.reload();
  assert.strictEqual(await page.textContent('.book-card h2'), '<b id=x>Bold</b>', 'markup in book data should show as text');
  assert.strictEqual(await page.$('#x'), null, 'markup in book data was parsed as HTML');
  assertClean(seen, 'books.html with markup in the catalog data');
}

async function testEnlargedTextOverflow(state) {
  for (const scale of [125, 150, 200]) {
    for (const name of PAGES) {
      const { page } = await openPage(state, name, { width: 360 });
      await page.addStyleTag({ content: `html { font-size: ${scale}%; }` });
      const sizes = await page.evaluate(() => ({
        scroll: document.documentElement.scrollWidth,
        viewport: window.innerWidth
      }));
      assert.ok(sizes.scroll <= sizes.viewport, `${name} at 360px with ${scale}% text scrolls sideways (${sizes.scroll} > ${sizes.viewport})`);
    }
  }
}

const TESTS = [
  ['nav links, aria-current, skip link and headings', testNavAndStructure],
  ['no broken internal links', testInternalLinks],
  ['no external requests or console errors', testNoExternalOrConsoleErrors],
  ['no horizontal scroll at 360, 414, 768 and 1280px', testOverflow],
  ['catalogue has 8+ books across 4+ genres', testCatalogueContent],
  ['genre filter, live count and URL state', testGenreFilter],
  ['hostile genre parameters fall back to All', testHostileGenreParams],
  ['events list has dated, timed entries', testEvents],
  ['visit page hours, address and labelled fields', testVisitContent],
  ['form validation, errors and focus', testFormValidation],
  ['valid submit shows demo notice and sends nothing', testFormDemoSubmit],
  ['hostile form input: whitespace, a@, 5000 characters, double submit', testHostileFormInput],
  ['keyboard focus ring, clickable cards and reduced motion', testFocusAndMotion],
  ['book data is rendered as text, not markup', testCatalogRendersTextOnly],
  ['no horizontal scroll with enlarged text at 360px', testEnlargedTextOverflow]
];

async function main() {
  const filter = process.argv[2] || '';
  const selected = TESTS.filter(([name]) => name.includes(filter));
  if (selected.length === 0) {
    console.log(`No tests match "${filter}"`);
    process.exit(1);
  }

  const server = await startServer();
  const base = `http://127.0.0.1:${server.address().port}`;
  const bundled = chromium.executablePath();
  const launchOptions = fs.existsSync(bundled) ? {} : { executablePath: '/usr/bin/google-chrome' };
  const browser = await chromium.launch(launchOptions);

  let failed = 0;
  try {
    for (const [name, run] of selected) {
      const state = { browser, base, contexts: [] };
      try {
        await run(state);
        console.log(`PASS ${name}`);
      } catch (error) {
        failed += 1;
        console.log(`FAIL ${name}\n  ${error.message.split('\n')[0]}`);
      } finally {
        for (const context of state.contexts) await context.close();
      }
    }
  } finally {
    await browser.close();
    server.close();
    server.closeAllConnections();
  }

  console.log(`${selected.length - failed} passed, ${failed} failed`);
  process.exit(failed ? 1 : 0);
}

main().catch((error) => {
  console.error(error);
  process.exit(1);
});

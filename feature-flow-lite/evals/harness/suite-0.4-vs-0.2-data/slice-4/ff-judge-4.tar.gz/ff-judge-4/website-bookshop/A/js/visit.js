// Client-side validation for the demo contact form. Nothing is sent anywhere.
(function () {
  'use strict';

  var EMAIL_PATTERN = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

  var FIELDS = [
    {
      id: 'name',
      check: function (value) {
        return value ? '' : 'Please enter your name.';
      }
    },
    {
      id: 'email',
      check: function (value) {
        if (!value) {
          return 'Please enter your email address.';
        }
        return EMAIL_PATTERN.test(value) ? '' : 'Please enter an email address like name@example.com.';
      }
    },
    {
      id: 'message',
      check: function (value) {
        return value ? '' : 'Please enter a message.';
      }
    }
  ];

  var form = document.getElementById('contact-form');
  var statusEl = document.getElementById('form-status');

  function showError(input, message) {
    document.getElementById(input.id + '-error').textContent = message;
    input.setAttribute('aria-invalid', message ? 'true' : 'false');
  }

  form.addEventListener('submit', function (event) {
    event.preventDefault();
    var firstInvalid = null;
    statusEl.textContent = '';

    FIELDS.forEach(function (field) {
      var input = document.getElementById(field.id);
      var message = field.check(input.value.trim());
      showError(input, message);
      if (message && !firstInvalid) {
        firstInvalid = input;
      }
    });

    if (firstInvalid) {
      firstInvalid.focus();
      return;
    }
    statusEl.textContent = 'Thank you for trying the form. This is a demo, so nothing was sent and no one at the shop will receive this message.';
  });
})();

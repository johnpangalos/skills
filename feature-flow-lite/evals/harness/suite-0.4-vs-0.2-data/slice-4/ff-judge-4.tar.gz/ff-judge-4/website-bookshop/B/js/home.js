// Home page: staff picks from the catalog and the next few upcoming events.
(function () {
  "use strict";

  var picks = document.getElementById("staff-picks");
  var nextEvents = document.getElementById("home-events");
  if (!picks || !nextEvents) {
    return;
  }

  var catalog = window.MarginaliaCatalog;
  var schedule = window.MarginaliaEvents;
  var now = new Date();

  catalog.books
    .filter(function (book) {
      return book.featured;
    })
    .forEach(function (book) {
      picks.appendChild(catalog.makeCard(book));
    });

  schedule.renderEvents(
    nextEvents,
    schedule.upcomingEvents(schedule.events, now).slice(0, 3),
    now,
  );
})();

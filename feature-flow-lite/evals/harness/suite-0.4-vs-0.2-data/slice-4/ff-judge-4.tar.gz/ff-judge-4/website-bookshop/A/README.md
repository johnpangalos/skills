# Marginalia Books

A website for Marginalia Books, a fictional independent bookshop. It has four pages, linked by a shared header:

- `index.html`: home
- `books.html`: a catalogue of 12 titles with a genre filter (the selected genre is kept in `?genre=`, so filtered views can be bookmarked and back/forward work)
- `events.html`: upcoming events
- `visit.html`: opening hours, address, and a demo contact form with client-side validation

The site is plain hand-written HTML, CSS and JavaScript. There is no build step, no framework and no npm dependency. It makes no requests to other hosts: no CDNs, web fonts or analytics. Text uses the system font stack.

## Layout

```
index.html, books.html, events.html, visit.html
css/style.css
js/books.js     genre filter (books page)
js/visit.js     contact form validation (visit page)
tests/run.mjs   headless-browser checks
```

## Run the site

From the repository root:

```sh
python3 -m http.server 8000
```

Then open http://localhost:8000/. Any static file server works.

## Run the tests

The tests use Playwright, which must be resolvable by Node (for example, installed globally). They use Playwright's bundled Chromium if it is installed, otherwise `/usr/bin/google-chrome`. The tests start their own static server, so there is no need to run the one above first.

```sh
node tests/run.mjs          # all pages
node tests/run.mjs books    # one page: home, books, events or visit
```

The script prints one line per check and exits with a non-zero status if any check fails.

(function () {
  'use strict';

  var form = document.getElementById('contact-form');
  var status = document.getElementById('form-status');

  var REQUIRED_MESSAGES = {
    name: 'Please enter your name.',
    email: 'Please enter your email address.',
    message: 'Please enter a message.'
  };
  var DEMO_MESSAGE = 'This is a demo site, so your message wasn\'t sent. Email us at hello@marginalia.example instead.';

  // Returns the error text for one field, or an empty string when it is valid.
  // Email rules come from the browser's own type=email check (typeMismatch), which
  // also strips surrounding whitespace from the value before checking it.
  function errorFor(input) {
    if (input.value.trim() === '') {
      return REQUIRED_MESSAGES[input.name];
    }
    if (input.validity.typeMismatch) {
      return 'Please enter an email address like name@example.com.';
    }
    return '';
  }

  // Writes the error text next to the field and sets aria-invalid to match.
  function showError(input, text) {
    document.getElementById(input.name + '-error').textContent = text;
    if (text) {
      input.setAttribute('aria-invalid', 'true');
    } else {
      input.removeAttribute('aria-invalid');
    }
  }

  // Checks every field and returns the first invalid one, or null.
  function validateForm() {
    var firstInvalid = null;
    ['name', 'email', 'message'].forEach(function (fieldName) {
      var input = form.elements.namedItem(fieldName);
      var error = errorFor(input);
      showError(input, error);
      if (error && !firstInvalid) {
        firstInvalid = input;
      }
    });
    return firstInvalid;
  }

  form.addEventListener('submit', function (event) {
    event.preventDefault();
    var firstInvalid = validateForm();
    if (firstInvalid) {
      status.textContent = '';
      firstInvalid.focus();
      return;
    }
    // No backend exists, so the message is never sent. Say so plainly.
    status.textContent = DEMO_MESSAGE;
  });

  // Clear an error as soon as the visitor fixes that field.
  form.addEventListener('input', function (event) {
    if (event.target.getAttribute('aria-invalid') === 'true') {
      showError(event.target, errorFor(event.target));
    }
  });
})();

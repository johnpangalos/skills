(function () {
  'use strict';

  var EMAIL_PATTERN = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  var DEMO_MESSAGE = 'Demo only: this form does not send anything, so your message was not sent. To reach the shop, call 01632 960 417 or visit us on Tanners Row.';
  var form = document.getElementById('contact-form');
  var statusBox = document.getElementById('form-status');

  var rules = [
    { id: 'name', test: isFilled, message: 'Enter your name. Spaces alone do not count.' },
    { id: 'email', test: isValidEmail, message: 'Enter an email address in the form name@example.com.' },
    { id: 'message', test: isFilled, message: 'Enter a message for the shop. Spaces alone do not count.' }
  ];

  function isFilled(value) {
    return value.trim().length > 0;
  }

  function isValidEmail(value) {
    return EMAIL_PATTERN.test(value.trim());
  }

  function showError(id, message) {
    document.getElementById(id).setAttribute('aria-invalid', 'true');
    document.getElementById(id + '-error').textContent = message;
  }

  function clearError(id) {
    document.getElementById(id).setAttribute('aria-invalid', 'false');
    document.getElementById(id + '-error').textContent = '';
  }

  function checkRule(rule) {
    var valid = rule.test(document.getElementById(rule.id).value);
    if (valid) {
      clearError(rule.id);
    } else {
      showError(rule.id, rule.message);
    }
    return valid;
  }

  form.addEventListener('submit', function (event) {
    event.preventDefault();
    var results = rules.map(checkRule);
    var firstInvalid = rules[results.indexOf(false)];
    if (firstInvalid) {
      statusBox.textContent = '';
      document.getElementById(firstInvalid.id).focus();
      return;
    }
    statusBox.textContent = DEMO_MESSAGE;
  });

  form.addEventListener('input', function (event) {
    var rule = rules.find(function (item) {
      return item.id === event.target.id;
    });
    if (rule && event.target.getAttribute('aria-invalid') === 'true') {
      checkRule(rule);
    }
  });
})();

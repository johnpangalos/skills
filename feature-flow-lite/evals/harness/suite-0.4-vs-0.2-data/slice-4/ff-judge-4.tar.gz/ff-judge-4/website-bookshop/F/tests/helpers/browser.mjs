import { existsSync } from 'node:fs';
import { pathToFileURL } from 'node:url';

const PLAYWRIGHT_FALLBACK = '/opt/node22/lib/node_modules/playwright/index.mjs';

// Uses the project's playwright if it is installed, otherwise the global copy.
async function loadChromium() {
  try {
    return (await import('playwright')).chromium;
  } catch {
    return (await import(pathToFileURL(PLAYWRIGHT_FALLBACK).href)).chromium;
  }
}

// Launches Chrome from CHROME_PATH or /usr/bin/google-chrome. If that path is missing,
// Playwright uses its bundled browser.
export async function launchBrowser() {
  const chromium = await loadChromium();
  const chromePath = process.env.CHROME_PATH || '/usr/bin/google-chrome';
  const executablePath = existsSync(chromePath) ? chromePath : undefined;
  return chromium.launch({ executablePath });
}

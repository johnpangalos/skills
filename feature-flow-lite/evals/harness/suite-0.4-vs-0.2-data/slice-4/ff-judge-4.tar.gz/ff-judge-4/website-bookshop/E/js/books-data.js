// Catalogue for books.html. Every genre must match an option label in books.html.
var MARGINALIA_BOOKS = [
  {
    title: 'The Lighthouse Alibi',
    author: 'Mara Quill',
    genre: 'Mystery',
    price: '£9.99',
    description: 'A retired harbour inspector reopens a case from the year the tide took the village ferry, and finds the same handwriting in both ledgers.'
  },
  {
    title: 'Nine Keys to Holloway Lane',
    author: 'Tobias Wren',
    genre: 'Mystery',
    price: '£11.50',
    description: 'When a locksmith is found locked inside her own workshop, three rival families in the town each produce a key that fits.'
  },
  {
    title: 'Paper Moths',
    author: 'Ines Okafor-Hale',
    genre: 'Mystery',
    price: '£8.99',
    description: 'A night-shift archivist notices a borrower who returns the same book every Tuesday, always with one page missing.'
  },
  {
    title: 'The Quiet Orbit',
    author: 'Petra Lind',
    genre: 'Science Fiction',
    price: '£12.00',
    description: 'The last living botanist aboard a seed ship keeps a garden alive for three generations while the ship\'s mind slowly forgets where it is going.'
  },
  {
    title: 'Ferrous Winter',
    author: 'Dev Anand Calloway',
    genre: 'Science Fiction',
    price: '£10.75',
    description: 'On a moon where the rivers freeze upward, a cartographer is hired to map a border that no government will admit exists.'
  },
  {
    title: 'Low Tide Sonnets',
    author: 'Helen Achterberg',
    genre: 'Poetry',
    price: '£10.00',
    description: 'Forty-one sonnets written on the strand at Halsey, arranged by the hour the water turned.'
  },
  {
    title: 'Small Hours, Open Windows',
    author: 'Jun Teague',
    genre: 'Poetry',
    price: '£13.00',
    description: 'Night poems about kitchens, late buses and the people who keep working through the dark so the rest of us can sleep.'
  },
  {
    title: 'The Mill Ledgers',
    author: 'Agnes Brierley',
    genre: 'History',
    price: '£19.99',
    description: 'Eighteen years of payroll and wage disputes from a Yorkshire cotton mill, read as a social history of the families who worked it.'
  },
  {
    title: 'Coal, Canals and Clocks',
    author: 'Simon Oduya',
    genre: 'History',
    price: '£16.50',
    description: 'How the industrial Midlands kept time, and how a single railway timetable reshaped the working day for everyone in it.'
  },
  {
    title: 'Dispatches from the Ferry Years',
    author: 'Lorna Vance',
    genre: 'History',
    price: '£14.99',
    description: 'Letters and logbooks from the crossings that connected three islands before the bridge was built.'
  },
  {
    title: 'Bread for a Small Kitchen',
    author: 'Ruth Adeyemi',
    genre: 'Cooking',
    price: '£15.00',
    description: 'Sourdough, flatbreads and enriched loaves, all tested in a kitchen with one oven and a broken timer.'
  },
  {
    title: 'Vegetables at Midnight',
    author: 'Marco Lindqvist',
    genre: 'Cooking',
    price: '£17.50',
    description: 'Weeknight cooking from the roots up, with a chapter on pickling for anyone who has run out of fridge space.'
  },
  {
    title: 'The Owl Who Kept Late Hours',
    author: 'Nadia Pell',
    genre: 'Children\'s',
    price: '£7.99',
    description: 'A picture book about an owl who sorts the village post at night. For readers aged three to six.'
  },
  {
    title: 'Mabel and the Brass Compass',
    author: 'Rhys Fairweather',
    genre: 'Children\'s',
    price: '£8.50',
    description: 'A chapter book adventure in which a nine-year-old crosses a flooded city using a compass that points to lost things.'
  },
  {
    title: 'Juniper Finds a Door',
    author: 'Sunita Rao',
    genre: 'Children\'s',
    price: '£6.99',
    description: 'A gentle first reader about a girl who discovers a small door at the back of the library.'
  }
];

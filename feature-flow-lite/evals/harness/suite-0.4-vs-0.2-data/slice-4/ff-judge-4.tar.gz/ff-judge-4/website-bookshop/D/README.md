# Marginalia Books

A website for Marginalia Books, a fictional independent bookshop. It has four pages: home, books (a catalogue you can filter by genre), events, and visit (opening hours, address and a contact form).

The site is plain HTML, CSS and JavaScript. There is no build step, no framework, no package.json, and no external requests: fonts are the system font stack and the artwork is inline SVG.

## Run it

From the repository root:

```sh
python3 -m http.server 8000
```

Then open http://localhost:8000/.

## Test it

The tests load every page in headless Chromium using the globally installed Playwright. They start their own static server, so nothing else needs to be running.

```sh
NODE_PATH=$(npm root -g) node tests/run.js
```

Pass a name fragment to run matching tests only, for example `NODE_PATH=$(npm root -g) node tests/run.js genre`. If the Playwright bundled browser is not installed, the runner falls back to `/usr/bin/google-chrome`.

## Layout

- `index.html`, `books.html`, `events.html`, `visit.html`: the pages
- `css/styles.css`: all styles
- `js/catalog-data.js`: the book list; genres in the filter are derived from it
- `js/catalog.js`: genre filter, result count and `?genre=` URL state
- `js/visit-form.js`: contact form validation (the form is a demo and sends nothing)
- `tests/run.js`: the test suite

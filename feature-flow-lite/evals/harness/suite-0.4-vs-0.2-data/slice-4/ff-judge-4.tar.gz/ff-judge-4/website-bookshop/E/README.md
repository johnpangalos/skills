# Marginalia Books

A static website for Marginalia Books, a fictional independent bookshop on Lantern Row in Oakfield. It has four pages:

- **Home** (`index.html`): introduction, staff picks, the next event and a visit teaser.
- **Books** (`books.html`): a catalogue of 15 titles in six genres. A genre filter updates the list and the address bar (for example `books.html?genre=mystery`), so filtered views can be bookmarked and shared.
- **Events** (`events.html`): upcoming readings, workshops and book groups with dates and times.
- **Visit** (`visit.html`): opening hours, the shop address and a contact form. The form is a demo and does not send messages.

The site is plain HTML, CSS and JavaScript. There is no build step, no framework and no external request of any kind: no CDNs, web fonts, analytics or map embeds.

## Run it locally

Any static file server will do. From the repository root, run one of:

```sh
python3 -m http.server 8080
```

```sh
npx http-server . -p 8080
```

Then open <http://localhost:8080/>.

## Run the tests

The tests load each page in headless Google Chrome through the globally installed Playwright, and start their own static server on a random free port. They need Node 22 or later, Playwright and Chrome at `/usr/bin/google-chrome`.

```sh
NODE_PATH=$(npm root -g) node --test tests/*.test.js
```

To run one file, pass its path, for example `NODE_PATH=$(npm root -g) node --test tests/books.test.js`.

To check the syntax of every script:

```sh
for f in js/*.js; do node --check "$f" || exit 1; done
```

## Layout

- `index.html`, `books.html`, `events.html`, `visit.html`: pages, each with the shared header, navigation and footer.
- `css/styles.css`: shared styles.
- `js/books-data.js`: the book catalogue. `js/books.js` renders and filters it. `js/visit.js` validates the contact form.
- `favicon.svg`: the site icon.
- `tests/`: Playwright tests, one file per concern.
- `FEATURE_FLOW.md`: the project's checks and conventions.

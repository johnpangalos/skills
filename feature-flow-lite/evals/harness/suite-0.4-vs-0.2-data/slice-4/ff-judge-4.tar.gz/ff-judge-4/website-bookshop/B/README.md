# Marginalia Books

A static website for Marginalia Books, a fictional independent bookshop in Ashford Mill.
It is plain HTML, CSS and JavaScript with no build step, no dependencies and no external
requests: no CDNs, web fonts, remote images, maps or analytics.

## Pages

- `index.html`: home, with a short pitch, staff picks, the next events and opening hours.
- `books.html`: a 15-title catalog with a genre filter. The chosen genre lives in the URL
  (`books.html?genre=poetry`), so it can be bookmarked and the Back button restores it.
- `events.html`: upcoming readings, book clubs and workshops, listed in date order.
- `visit.html`: opening hours, address, directions and a contact form. The form is a demo:
  it validates your entries and says plainly that nothing was sent.

## Viewing the site

Open `index.html` in a browser. The pages use classic deferred scripts, so no server is
needed. To serve the folder over HTTP instead, run one of:

```sh
python3 -m http.server 8080
npx http-server -p 8080
```

Then visit http://localhost:8080/.

## File layout

```
index.html, books.html, events.html, visit.html   pages (shared header, nav and footer)
css/styles.css                                    all shared styles
js/main.js                                        mobile navigation toggle
js/books.js                                       book catalog data and the genre filter
js/events.js                                      event schedule and upcoming-events logic
js/home.js                                        staff picks and next events on the home page
js/visit.js                                       contact form validation
favicon.svg                                       site icon
tests/site.test.js                                headless Chrome tests
package.json                                      the "test" script only
```

Book and event data live in one place each, `js/books.js` and `js/events.js`. The pages
render from them, so the markup never repeats a title.

## Running the tests

The tests use Node's built-in test runner and the globally installed Playwright, driving
Google Chrome at `/usr/bin/google-chrome` in headless mode. They start their own static
server on an ephemeral port. Node 18 or later is required.

```sh
NODE_PATH=$(npm root -g) node --test tests/*.test.js
```

`npm test` runs the same command, but `NODE_PATH` still has to be set so that `require('playwright')`
resolves.

The tests cover every page loading with no console errors or off-origin requests, the shared
nav and footer, the 360px layout, the genre filter and URL state, the mobile menu, the event
date logic, and the contact form's validation and demo message.

// Genre filter for the catalog. The selected genre lives in the ?genre= query string.
(function () {
  var ALL = 'All';
  var buttons = Array.from(document.querySelectorAll('[data-filter]'));
  var books = Array.from(document.querySelectorAll('[data-genre]'));
  var count = document.getElementById('result-count');
  if (!buttons.length || !books.length || !count) {
    return;
  }

  function isKnownGenre(name) {
    return buttons.some(function (button) {
      return button.getAttribute('data-filter') === name;
    });
  }

  // Unknown, empty or differently cased values fall back to All.
  function genreFromUrl() {
    var name = new URLSearchParams(window.location.search).get('genre');
    return name && isKnownGenre(name) ? name : ALL;
  }

  function urlFor(genre) {
    var params = new URLSearchParams(window.location.search);
    if (genre === ALL) {
      params.delete('genre');
    } else {
      params.set('genre', genre);
    }
    var query = params.toString();
    return window.location.pathname + (query ? '?' + query : '') + window.location.hash;
  }

  function show(genre) {
    var shown = 0;
    books.forEach(function (book) {
      var match = genre === ALL || book.getAttribute('data-genre') === genre;
      book.hidden = !match;
      if (match) {
        shown += 1;
      }
    });
    buttons.forEach(function (button) {
      button.setAttribute('aria-pressed', String(button.getAttribute('data-filter') === genre));
    });
    count.textContent = 'Showing ' + shown + ' of ' + books.length + ' books';
  }

  buttons.forEach(function (button) {
    button.addEventListener('click', function () {
      var genre = button.getAttribute('data-filter');
      if (genre === genreFromUrl()) {
        return;
      }
      show(genre);
      window.history.pushState({ genre: genre }, '', urlFor(genre));
    });
  });

  window.addEventListener('popstate', function () {
    show(genreFromUrl());
  });

  var initial = genreFromUrl();
  show(initial);
  window.history.replaceState({ genre: initial }, '', urlFor(initial));
})();

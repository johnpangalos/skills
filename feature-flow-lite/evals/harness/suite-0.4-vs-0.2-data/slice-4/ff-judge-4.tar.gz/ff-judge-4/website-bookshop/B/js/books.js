// Book catalog (the one place book data lives) and the genre filter on books.html.
(function () {
  "use strict";

  var BOOKS = [
    {
      title: "The Clockmaker's Alibi",
      author: "Imogen Park",
      genre: "Mystery",
      price: 16,
      blurb:
        "When a watchmaker turns up dead with every clock in his shop stopped at the same minute, the town's only detective has to trust a lodger nobody likes.",
    },
    {
      title: "Nine Locked Rooms",
      author: "Teodor Wren",
      genre: "Mystery",
      price: 17.5,
      blurb:
        "A country house party, a snowed-in weekend and a guest list that changes every time someone counts it. The puzzle is fair and the ending earns its gasp.",
    },
    {
      title: "A Quiet Fog Over Harrow Lane",
      author: "Lucinda Marsh",
      genre: "Mystery",
      price: 15,
      blurb:
        "A retired schoolteacher starts a notebook about her neighbours and soon has more evidence than the police. Slow, warm and very sharp.",
    },
    {
      title: "The Orbit Ledger",
      author: "Anika Solberg",
      genre: "Science Fiction",
      price: 18,
      featured: true,
      blurb:
        "Two accountants on a cargo station keep the books for a shipping empire that has started paying its debts in favours. Funny, tense and unexpectedly tender.",
    },
    {
      title: "Salt on the Moon Road",
      author: "Desmond Akers",
      genre: "Science Fiction",
      price: 16.99,
      blurb:
        "A convoy driver hauling water across a dying lunar highway discovers that the reservoir at the end of the road was never meant to be opened.",
    },
    {
      title: "Glasswing",
      author: "Mira Castellan",
      genre: "Science Fiction",
      price: 17,
      blurb:
        "On a world where insects were engineered to pollinate the cities, a beekeeper's daughter inherits the last working hive and the reason it still hums.",
    },
    {
      title: "The Hundred Small Kitchens",
      author: "Rosalind Greaves",
      genre: "Literary Fiction",
      price: 15.95,
      featured: true,
      blurb:
        "Across one long summer, the cooks of a single apartment block trade recipes, grudges and unfinished letters through a shared dumbwaiter.",
    },
    {
      title: "Letters to the Empty Chair",
      author: "Joaquin Ferreira",
      genre: "Literary Fiction",
      price: 14.95,
      blurb:
        "An elderly widower writes to his late wife every morning, and then, to his surprise, begins to receive replies from his granddaughter.",
    },
    {
      title: "Where the River Forgets",
      author: "Hanne Dahl",
      genre: "Literary Fiction",
      price: 16.5,
      blurb:
        "Three generations of a ferry family argue over whether to sell the crossing as the new bridge goes up, and what each of them owes the water.",
    },
    {
      title: "A Field Guide to Forgotten Weather",
      author: "Priya Narayan",
      genre: "Natural History",
      price: 24,
      featured: true,
      blurb:
        "Sixty years of hand-drawn cloud charts, frost notes and storm diaries, gathered into a guide to the skies that the modern forecast has quietly replaced.",
    },
    {
      title: "Tidepool Almanac",
      author: "Samuel Oduya",
      genre: "Natural History",
      price: 21,
      blurb:
        "A month-by-month guide to the creatures of a rocky coast, with notes on when to look, where to kneel and what not to take home.",
    },
    {
      title: "The Secret Lives of Moths",
      author: "Lena Brightwater",
      genre: "Natural History",
      price: 19.5,
      blurb:
        "A lively, illustrated tour of the moths that share our porch lights, from the hawk moth's fast flight to the fuzz that confuses bats.",
    },
    {
      title: "Small Hours, Open Windows",
      author: "Theo Maren",
      genre: "Poetry",
      price: 14,
      blurb:
        "Poems written between midnight and dawn, many of them about kitchens, night trains and the people who stayed up with a sick child.",
    },
    {
      title: "The Grammar of Rain",
      author: "Esme Calloway",
      genre: "Poetry",
      price: 13.5,
      featured: true,
      blurb:
        "A sequence of short poems about weather and language, with a title poem that reads differently every time you come back to it.",
    },
    {
      title: "Ledger of Loose Feathers",
      author: "Ruth Kestrel",
      genre: "Poetry",
      price: 15.5,
      blurb:
        "Bird poems that refuse to stay in the field guide: a crow in a hospital corridor, a heron at the bus stop, a wren inside a typewriter.",
    },
  ];

  var COVER_COLORS = {
    Mystery: ["#5b1a24", "#2a0b10"],
    "Science Fiction": ["#1d3557", "#0b1a2e"],
    "Literary Fiction": ["#6b4e16", "#3a2a08"],
    "Natural History": ["#22543d", "#10291d"],
    Poetry: ["#4a3f7a", "#231d3d"],
  };

  // Lowercase, trimmed, spaces become hyphens: "Science Fiction" becomes "science-fiction".
  function slugify(text) {
    return String(text).trim().toLowerCase().replace(/\s+/g, "-");
  }

  var GENRES = [];
  BOOKS.forEach(function (book) {
    var known = GENRES.some(function (genre) {
      return genre.name === book.genre;
    });
    if (!known) {
      GENRES.push({ name: book.genre, slug: slugify(book.genre) });
    }
  });

  // Matches a genre by slug, ignoring case and surrounding whitespace. Unknown values give null.
  function findGenre(value) {
    var slug = slugify(value || "");
    var matches = GENRES.filter(function (genre) {
      return genre.slug === slug;
    });
    return matches[0] || null;
  }

  function element(tag, className, text) {
    var node = document.createElement(tag);
    if (className) {
      node.className = className;
    }
    if (text !== undefined) {
      node.textContent = text;
    }
    return node;
  }

  function countIn(genreName) {
    return BOOKS.filter(function (book) {
      return book.genre === genreName;
    }).length;
  }

  function formatPrice(amount) {
    return "$" + amount.toFixed(2);
  }

  function makeCard(book) {
    var colors = COVER_COLORS[book.genre];
    var item = element("li", "book-card");
    item.dataset.genre = slugify(book.genre);

    var cover = element("div", "cover");
    cover.setAttribute("aria-hidden", "true");
    cover.style.setProperty("--cover-start", colors[0]);
    cover.style.setProperty("--cover-end", colors[1]);
    cover.appendChild(element("span", "cover__title", book.title));
    cover.appendChild(element("span", "cover__author", book.author));

    var body = element("div", "book-card__body");
    body.appendChild(element("p", "genre-tag", book.genre));
    body.appendChild(element("h3", "book-card__title", book.title));
    body.appendChild(element("p", "book-card__author", "by " + book.author));
    body.appendChild(element("p", "book-card__blurb", book.blurb));
    body.appendChild(element("p", "book-card__price", formatPrice(book.price)));

    item.appendChild(cover);
    item.appendChild(body);
    return item;
  }

  function optionFor(name, slug, count) {
    var label = element("label", "genre-option");
    var input = element("input");
    input.type = "radio";
    input.name = "genre";
    input.value = slug;
    label.appendChild(input);
    label.appendChild(element("span", null, name + " (" + count + ")"));
    return label;
  }

  // The genre slug in the current URL, or '' when there is none or it is not a known genre.
  function slugFromLocation() {
    var param = new URLSearchParams(window.location.search).get("genre");
    var genre = findGenre(param);
    return genre ? genre.slug : "";
  }

  // Records a filter choice in the URL so it can be bookmarked and restored with Back.
  function writeLocation(slug) {
    var url = slug
      ? "?genre=" + encodeURIComponent(slug)
      : window.location.pathname;
    if (url !== window.location.pathname + window.location.search) {
      window.history.pushState({ genre: slug }, "", url);
    }
  }

  // Rewrites a known but non-canonical genre in the URL (e.g. MYSTERY) to its slug, without a history entry.
  function canonicalizeLocation() {
    var param = new URLSearchParams(window.location.search).get("genre");
    var genre = findGenre(param);
    if (genre && param !== genre.slug) {
      window.history.replaceState(
        { genre: genre.slug },
        "",
        "?genre=" + encodeURIComponent(genre.slug),
      );
    }
  }

  function initFilterPage() {
    var grid = document.getElementById("book-grid");
    var fieldset = document.getElementById("genre-filter");
    var options = document.getElementById("genre-options");
    var status = document.getElementById("filter-status");
    if (!grid || !fieldset || !options || !status) {
      return;
    }

    var cards = BOOKS.map(function (book) {
      var card = makeCard(book);
      grid.appendChild(card);
      return card;
    });

    options.appendChild(optionFor("All", "", BOOKS.length));
    GENRES.forEach(function (genre) {
      options.appendChild(
        optionFor(genre.name, genre.slug, countIn(genre.name)),
      );
    });
    var inputs = options.querySelectorAll("input");

    // Shows the books for one genre slug ('' means all) and announces the result.
    function showGenre(slug) {
      var genre = findGenre(slug);
      var active = genre ? genre.slug : "";
      inputs.forEach(function (input) {
        input.checked = input.value === active;
      });
      cards.forEach(function (card) {
        card.hidden = active !== "" && card.dataset.genre !== active;
      });
      if (genre) {
        var count = countIn(genre.name);
        status.textContent =
          "Showing " +
          count +
          (count === 1 ? " book" : " books") +
          " in " +
          genre.name;
      } else {
        status.textContent = "Showing all " + BOOKS.length + " books";
      }
    }

    fieldset.addEventListener("change", function (event) {
      if (event.target.name !== "genre") {
        return;
      }
      writeLocation(event.target.value);
      showGenre(event.target.value);
    });

    window.addEventListener("popstate", function () {
      showGenre(slugFromLocation());
    });

    canonicalizeLocation();
    showGenre(slugFromLocation());
  }

  window.MarginaliaCatalog = {
    books: BOOKS,
    genres: GENRES,
    findGenre: findGenre,
    makeCard: makeCard,
  };

  initFilterPage();
})();

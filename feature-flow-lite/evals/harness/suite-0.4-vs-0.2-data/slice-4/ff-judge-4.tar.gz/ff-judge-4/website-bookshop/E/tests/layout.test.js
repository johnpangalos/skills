'use strict';

const { test, before, after } = require('node:test');
const assert = require('node:assert/strict');
const { startServer, launchBrowser, PAGES } = require('./support');

let server;
let origin;
let browser;

before(async () => {
  ({ server, origin } = await startServer());
  browser = await launchBrowser();
});

after(async () => {
  await browser.close();
  server.close();
});

test('no page scrolls sideways at 360, 768 or 1280 pixels wide', async () => {
  for (const width of [360, 768, 1280]) {
    const page = await browser.newPage({ viewport: { width, height: 800 } });
    for (const file of PAGES) {
      await page.goto(`${origin}/${file}`);
      const sizes = await page.evaluate(() => ({
        scroll: document.documentElement.scrollWidth,
        inner: window.innerWidth
      }));
      assert.ok(sizes.scroll <= sizes.inner, `${file} at ${width}px: scrollWidth ${sizes.scroll} > innerWidth ${sizes.inner}`);
    }
    await page.close();
  }
});

test('the main nav links are all visible and inside the viewport at 360 pixels', async () => {
  const page = await browser.newPage({ viewport: { width: 360, height: 800 } });
  for (const file of PAGES) {
    await page.goto(`${origin}/${file}`);
    const boxes = await page.$$eval('header nav a', (as) => as.map((a) => {
      const r = a.getBoundingClientRect();
      return { left: r.left, right: r.right, height: r.height, text: a.textContent.trim() };
    }));
    assert.equal(boxes.length, 4, `${file} has four nav links`);
    for (const box of boxes) {
      assert.ok(box.left >= 0 && box.right <= 360, `${file}: "${box.text}" sits outside 360px`);
      assert.ok(box.height >= 44, `${file}: "${box.text}" is at least 44px tall`);
    }
  }
  await page.close();
});

test('every focusable element shows a visible focus outline when reached by keyboard', async () => {
  const page = await browser.newPage({ viewport: { width: 1280, height: 800 } });
  for (const file of PAGES) {
    await page.goto(`${origin}/${file}`);
    const count = await page.$$eval('a[href], button, input, select, textarea', (els) => els.length);
    for (let i = 0; i < count; i++) {
      await page.keyboard.press('Tab');
      const outline = await page.evaluate(() => {
        const style = getComputedStyle(document.activeElement);
        return { name: document.activeElement.tagName, style: style.outlineStyle, width: style.outlineWidth };
      });
      assert.equal(outline.style, 'solid', `${file}: focused ${outline.name} has no solid outline`);
      assert.notEqual(outline.width, '0px', `${file}: focused ${outline.name} has zero outline width`);
    }
  }
  await page.close();
});

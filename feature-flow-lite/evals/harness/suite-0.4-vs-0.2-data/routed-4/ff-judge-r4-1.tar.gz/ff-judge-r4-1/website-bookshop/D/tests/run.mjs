// Browser tests for the Marginalia Books site.
// Usage: node tests/run.mjs [name-substring]
// Needs the globally installed Playwright and a Chrome binary (/usr/bin/google-chrome if the bundled one is missing).

import { createRequire } from 'module';
import { createServer } from 'node:http';
import { readFile } from 'node:fs/promises';
import { existsSync } from 'node:fs';
import { dirname, extname, join, normalize } from 'node:path';
import { fileURLToPath } from 'node:url';
import assert from 'node:assert/strict';

const require = createRequire(import.meta.url);
const { chromium } = require(require('child_process').execSync('npm root -g').toString().trim() + '/playwright');

const ROOT = normalize(join(dirname(fileURLToPath(import.meta.url)), '..'));
const PAGES = ['index.html', 'books.html', 'events.html', 'visit.html'];
const TYPES = {
  '.html': 'text/html; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.js': 'text/javascript; charset=utf-8',
  '.svg': 'image/svg+xml'
};
const TODAY = '2026-11-17';
const CHROME_FALLBACK = '/usr/bin/google-chrome';

function startServer() {
  const server = createServer(async (req, res) => {
    let file;
    try {
      const pathname = decodeURIComponent(new URL(req.url, 'http://127.0.0.1').pathname);
      file = normalize(join(ROOT, pathname.endsWith('/') ? pathname + 'index.html' : pathname));
    } catch {
      res.writeHead(400).end();
      return;
    }
    if (!file.startsWith(ROOT + '/')) {
      res.writeHead(403).end();
      return;
    }
    try {
      const body = await readFile(file);
      res.writeHead(200, { 'Content-Type': TYPES[extname(file)] || 'application/octet-stream' });
      res.end(body);
    } catch {
      res.writeHead(404).end();
    }
  });
  return new Promise((resolve) => {
    server.listen(0, '127.0.0.1', () => {
      resolve({ server, origin: `http://127.0.0.1:${server.address().port}` });
    });
  });
}

// Opens pages in fresh contexts. Anything that is not served by this server is aborted and recorded,
// and console errors, page errors and dialogs are recorded. The runner fails the test if any were recorded.
function makeSession(browser, origin) {
  const problems = [];
  const requests = [];
  const contexts = [];

  const session = {
    requests,
    async open(path, width = 1024) {
      const context = await browser.newContext({ viewport: { width, height: 900 } });
      contexts.push(context);
      await context.route('**/*', (route) => {
        const request = route.request();
        requests.push({ method: request.method(), url: request.url() });
        if (request.url().startsWith(origin + '/')) {
          return route.continue();
        }
        problems.push(`non-local request to ${request.url()}`);
        return route.abort();
      });
      const page = await context.newPage();
      page.on('console', (message) => {
        if (message.type() === 'error') {
          problems.push(`console error on ${path}: ${message.text()}`);
        }
      });
      page.on('pageerror', (error) => problems.push(`page error on ${path}: ${error.message}`));
      page.on('dialog', (dialog) => {
        problems.push(`unexpected dialog on ${path}: ${dialog.message()}`);
        dialog.dismiss();
      });
      await page.goto(`${origin}/${path}`);
      return page;
    }
  };

  return { session, problems, contexts };
}

const tests = [];
const test = (name, fn) => tests.push({ name, fn });

const countVisibleBooks = (page) => page.locator('.book:not([hidden])').count();
const resultText = (page) => page.locator('#result-count').textContent();
const selectedGenre = (page) => page.getByLabel('Genre').inputValue();
const urlGenre = (page) => new URL(page.url()).searchParams.get('genre');

test('nav links all four pages and marks only the current page', async ({ open }) => {
  for (const path of PAGES) {
    const page = await open(path);
    const hrefs = await page.locator('.site-nav a').evaluateAll((links) => links.map((a) => a.getAttribute('href')));
    assert.deepEqual(hrefs, PAGES, `nav links on ${path}`);
    const current = await page.locator('.site-nav a[aria-current]').evaluateAll((links) =>
      links.map((a) => [a.getAttribute('aria-current'), a.getAttribute('href')])
    );
    assert.deepEqual(current, [['page', path]], `aria-current on ${path}`);
    assert.equal(await page.locator('header.site-header .site-name').count(), 1, `header name on ${path}`);
    assert.equal(await page.locator('footer.site-footer').count(), 1, `footer on ${path}`);
  }
});

test('nav links reachable by Tab at 360px', async ({ open }) => {
  const page = await open('books.html', 360);
  const reached = new Set();
  for (let i = 0; i < 20; i++) {
    await page.keyboard.press('Tab');
    const href = await page.evaluate(() => document.activeElement && document.activeElement.getAttribute('href'));
    if (href) {
      reached.add(href);
    }
  }
  for (const path of PAGES) {
    assert.ok(reached.has(path), `Tab reached nav link ${path}`);
  }
});

test('no horizontal scroll at 360px or desktop width on every page', async ({ open }) => {
  for (const width of [360, 1280]) {
    for (const path of PAGES) {
      const page = await open(path, width);
      const scrollWidth = await page.evaluate(() => document.documentElement.scrollWidth);
      assert.ok(scrollWidth <= width, `${path} at ${width}px has scrollWidth ${scrollWidth}`);
    }
  }
});

test('accessibility basics on every page', async ({ open }) => {
  const titles = new Set();
  for (const path of PAGES) {
    const page = await open(path);
    assert.equal(await page.getAttribute('html', 'lang'), 'en', `lang on ${path}`);
    const title = await page.title();
    assert.ok(title.length > 0 && !titles.has(title), `unique title on ${path}`);
    titles.add(title);
    assert.equal(await page.locator('h1').count(), 1, `one h1 on ${path}`);
    assert.equal(await page.locator('a.skip-link[href="#main"]').count(), 1, `skip link on ${path}`);
    assert.equal(await page.locator('main#main').count(), 1, `main target on ${path}`);
    for (const landmark of ['header', 'nav', 'main', 'footer']) {
      assert.equal(await page.locator(landmark).count(), 1, `${landmark} landmark on ${path}`);
    }
    const levels = await page.locator('h1, h2, h3, h4, h5, h6').evaluateAll((headings) =>
      headings.map((h) => Number(h.tagName.slice(1)))
    );
    for (let i = 1; i < levels.length; i++) {
      assert.ok(levels[i] <= levels[i - 1] + 1, `heading order on ${path}: ${levels.join(',')}`);
    }
  }
});

test('non-interactive cards have no pointer cursor', async ({ open }) => {
  const books = await open('books.html');
  const events = await open('events.html');
  for (const [page, selector] of [
    [books, '.book'],
    [books, '.genre'],
    [events, '.event']
  ]) {
    const cursor = await page.locator(selector).first().evaluate((el) => getComputedStyle(el).cursor);
    assert.notEqual(cursor, 'pointer', `${selector} cursor`);
  }
});

test('books catalogue has at least 12 complete titles across 4 genres with 2+ books', async ({ open }) => {
  const page = await open('books.html');
  const books = await page.locator('.book').evaluateAll((items) =>
    items.map((li) => ({
      title: li.querySelector('h2')?.textContent.trim() ?? '',
      author: li.querySelector('.book-author')?.textContent.trim() ?? '',
      genre: li.dataset.genre,
      tag: li.querySelector('.genre')?.textContent.trim() ?? '',
      blurb: li.querySelector('.book-blurb')?.textContent.trim() ?? '',
      price: li.querySelector('.price')?.textContent.trim() ?? ''
    }))
  );
  assert.ok(books.length >= 12, `book count ${books.length}`);
  for (const book of books) {
    assert.ok(book.title && book.author && book.genre && book.tag && book.blurb, `complete fields: ${book.title}`);
    assert.match(book.price, /^£\d+\.\d{2}$/, `price for ${book.title}`);
  }
  const perGenre = {};
  for (const book of books) {
    perGenre[book.genre] = (perGenre[book.genre] || 0) + 1;
  }
  const genresWithTwo = Object.values(perGenre).filter((n) => n >= 2);
  assert.ok(genresWithTwo.length >= 4, `genres with 2+ books: ${JSON.stringify(perGenre)}`);
});

test('books genre filter shows matching titles and announces the count', async ({ open }) => {
  const page = await open('books.html');
  assert.equal(await resultText(page), 'Showing 12 of 12 books');
  await page.getByLabel('Genre').selectOption('mystery');
  assert.equal(await countVisibleBooks(page), 3);
  assert.equal(await resultText(page), 'Showing 3 of 12 books');
  assert.equal(await page.locator('#result-count').getAttribute('aria-live'), 'polite');
  const genres = await page.locator('.book:not([hidden]) .genre').allTextContents();
  assert.deepEqual([...new Set(genres)], ['Mystery']);
  assert.equal(urlGenre(page), 'mystery');
  await page.getByLabel('Genre').selectOption('all');
  assert.equal(await countVisibleBooks(page), 12);
  assert.equal(await resultText(page), 'Showing 12 of 12 books');
  assert.equal(new URL(page.url()).search, '', 'All removes the genre parameter');
});

test('books genre state comes from the URL and back/forward restore it', async ({ open }) => {
  const fromUrl = await open('books.html?genre=fantasy');
  assert.equal(await selectedGenre(fromUrl), 'fantasy');
  assert.equal(await countVisibleBooks(fromUrl), 3);

  const page = await open('books.html');
  await page.getByLabel('Genre').selectOption('fantasy');
  await page.getByLabel('Genre').selectOption('poetry');
  assert.equal(await resultText(page), 'Showing 3 of 12 books');
  assert.equal(urlGenre(page), 'poetry');
  await page.goBack();
  assert.equal(await selectedGenre(page), 'fantasy');
  assert.equal(await resultText(page), 'Showing 3 of 12 books');
  assert.equal(urlGenre(page), 'fantasy');
  await page.goBack();
  assert.equal(await selectedGenre(page), 'all');
  assert.equal(await resultText(page), 'Showing 12 of 12 books');
  assert.equal(await countVisibleBooks(page), 12);
  await page.goForward();
  assert.equal(await selectedGenre(page), 'fantasy');
  assert.equal(await countVisibleBooks(page), 3);
});

test('books hostile genre parameters fall back to All without injection', async ({ open }) => {
  const hostile = ['unknown', '', '<script>alert(1)</script>', '%3Cimg%20src%3Dx%20onerror%3Dalert(1)%3E', '%00'];
  for (const value of hostile) {
    const page = await open(`books.html?genre=${value}`);
    assert.equal(await selectedGenre(page), 'all', `select for genre=${value}`);
    assert.equal(await countVisibleBooks(page), 12, `count for genre=${value}`);
    assert.equal(await resultText(page), 'Showing 12 of 12 books', `result for genre=${value}`);
    assert.equal(await page.locator('script').count(), 1, `no injected script for genre=${value}`);
    assert.equal(await page.locator('img, iframe').count(), 0, `no injected elements for genre=${value}`);
  }
});

test('books genre parameter is case-insensitive', async ({ open }) => {
  const page = await open('books.html?genre=Mystery');
  assert.equal(await selectedGenre(page), 'mystery');
  assert.equal(await countVisibleBooks(page), 3);
  assert.equal(await resultText(page), 'Showing 3 of 12 books');
});

test('books rapid toggling leaves count and list consistent', async ({ open }) => {
  const page = await open('books.html');
  const sequence = ['mystery', 'fantasy', 'all', 'poetry', 'nonfiction', 'mystery', 'all', 'fantasy', 'poetry'];
  const final = await page.evaluate((steps) => {
    const select = document.getElementById('genre');
    for (let round = 0; round < 10; round++) {
      for (const step of steps) {
        select.value = step;
        select.dispatchEvent(new Event('change'));
      }
    }
    return select.value;
  }, sequence);
  assert.equal(final, 'poetry');
  assert.equal(await countVisibleBooks(page), 3);
  assert.equal(await resultText(page), 'Showing 3 of 12 books');
  assert.equal(urlGenre(page), 'poetry');
  const visibleGenres = await page.locator('.book:not([hidden]) .genre').allTextContents();
  assert.deepEqual([...new Set(visibleGenres)], ['Poetry']);
});

test('back two steps restores the genre select from the URL', async ({ open }) => {
  const page = await open('books.html?genre=poetry');
  assert.equal(await selectedGenre(page), 'poetry');
  await page.getByLabel('Genre').selectOption('all');
  await page.getByRole('link', { name: 'Events' }).click();
  await page.waitForURL(/events\.html/);
  await page.evaluate(() => setTimeout(() => history.go(-2)));
  await page.waitForURL(/books\.html\?genre=poetry$/);
  await page.waitForLoadState('load');
  await page.waitForFunction(() => document.getElementById('genre').value === 'poetry');
  assert.equal(await selectedGenre(page), 'poetry');
  assert.equal(await countVisibleBooks(page), 3);
  assert.equal(await resultText(page), 'Showing 3 of 12 books');
});

test('Tab gives focus-visible an outline on nav links and form controls', async ({ open }) => {
  const page = await open('visit.html');
  const seen = new Map();
  for (let i = 0; i < 12; i++) {
    await page.keyboard.press('Tab');
    const stop = await page.evaluate(() => {
      const el = document.activeElement;
      const style = getComputedStyle(el);
      return {
        tag: el.tagName,
        label: el.getAttribute('href') || el.id || el.tagName.toLowerCase(),
        focusVisible: el.matches(':focus-visible'),
        outlineStyle: style.outlineStyle,
        outlineWidth: parseFloat(style.outlineWidth),
        outlineColor: style.outlineColor,
        inHeader: el.closest('header') !== null
      };
    });
    if (['A', 'INPUT', 'TEXTAREA', 'BUTTON', 'SELECT'].includes(stop.tag)) {
      seen.set(stop.label, stop);
    }
  }
  for (const label of ['index.html', 'books.html', 'events.html', 'visit.html', 'name', 'email', 'message', 'button']) {
    const stop = seen.get(label);
    assert.ok(stop, `Tab reached ${label}`);
    assert.equal(stop.focusVisible, true, `:focus-visible on ${label}`);
    assert.notEqual(stop.outlineStyle, 'none', `outline on ${label}`);
    assert.ok(stop.outlineWidth > 0, `outline width on ${label}`);
    // Colours from css/styles.css: --focus #8a4b00 on content, #ffd166 for the header override.
    const expectedColor = stop.inHeader ? 'rgb(255, 209, 102)' : 'rgb(138, 75, 0)';
    assert.equal(stop.outlineColor, expectedColor, `outline colour on ${label}`);
  }
});

test('skip link with Enter moves focus into main', async ({ open }) => {
  const page = await open('books.html');
  await page.keyboard.press('Tab');
  assert.equal(await page.evaluate(() => document.activeElement.getAttribute('href')), '#main');
  await page.keyboard.press('Enter');
  assert.equal(await page.evaluate(() => document.activeElement.id), 'main');
});

test('book and event cards look the same when hovered', async ({ open }) => {
  const cardLook = (page, selector) =>
    page.locator(selector).first().evaluate((el) => {
      const s = getComputedStyle(el);
      return [s.backgroundColor, s.borderTopColor, s.borderTopWidth, s.boxShadow, s.color, s.cursor, s.transform].join('|');
    });
  for (const [path, selector] of [
    ['books.html', '.book'],
    ['events.html', '.event']
  ]) {
    const page = await open(path);
    const card = page.locator(selector).first();
    const before = await cardLook(page, selector);
    await card.hover();
    assert.equal(await card.evaluate((el) => el.matches(':hover')), true, `${selector} is hovered on ${path}`);
    assert.equal(await cardLook(page, selector), before, `${selector} hover style on ${path}`);
  }
});

test('reduced motion turns off smooth scrolling and transitions', async ({ open }) => {
  const page = await open('books.html');
  assert.equal(
    await page.evaluate(() => getComputedStyle(document.documentElement).scrollBehavior),
    'smooth',
    'smooth scrolling without reduced motion'
  );
  await page.emulateMedia({ reducedMotion: 'reduce' });
  const motion = await page.evaluate(() => {
    const running = [...document.querySelectorAll('*')]
      .filter((el) => {
        const s = getComputedStyle(el);
        return parseFloat(s.transitionDuration) > 0.001 || parseFloat(s.animationDuration) > 0.001;
      })
      .map((el) => el.tagName);
    return { scrollBehavior: getComputedStyle(document.documentElement).scrollBehavior, running };
  });
  assert.equal(motion.scrollBehavior, 'auto');
  assert.deepEqual(motion.running, []);
});

test('events are upcoming real dates whose weekdays match', async ({ open }) => {
  const page = await open('events.html');
  const events = await page.locator('.event').evaluateAll((items) =>
    items.map((li) => ({
      datetime: li.querySelector('time')?.getAttribute('datetime') ?? '',
      label: li.querySelector('time')?.textContent.trim() ?? '',
      time: li.querySelector('.event-time')?.textContent.trim() ?? '',
      title: li.querySelector('h2')?.textContent.trim() ?? '',
      description: li.querySelector('p:last-child')?.textContent.trim() ?? ''
    }))
  );
  assert.ok(events.length >= 4, `event count ${events.length}`);
  for (const event of events) {
    assert.match(event.datetime, /^\d{4}-\d{2}-\d{2}$/, `datetime format for ${event.title}`);
    const date = new Date(`${event.datetime}T00:00:00Z`);
    assert.equal(date.toISOString().slice(0, 10), event.datetime, `real calendar date for ${event.title}`);
    assert.ok(event.datetime > TODAY, `${event.title} is after ${TODAY}`);
    assert.ok(['2026', '2027'].includes(event.datetime.slice(0, 4)), `year for ${event.title}`);
    const weekday = date.toLocaleDateString('en-GB', { weekday: 'long', timeZone: 'UTC' });
    assert.ok(event.label.includes(weekday), `weekday ${weekday} in "${event.label}"`);
    assert.match(event.time, /\d{2}:\d{2} to \d{2}:\d{2}/, `time for ${event.title}`);
    assert.ok(event.title && event.description, `title and description for ${event.datetime}`);
  }
});

test('visit form flags empty required fields and moves focus to the first', async ({ open }) => {
  const page = await open('visit.html');
  await page.getByRole('button', { name: 'Send message' }).click();
  const expected = {
    name: 'Enter your name.',
    email: 'Enter your email address.',
    message: 'Enter a message.'
  };
  for (const [id, message] of Object.entries(expected)) {
    assert.equal(await page.locator(`#${id}`).getAttribute('aria-invalid'), 'true', `aria-invalid on ${id}`);
    assert.equal(await page.locator(`#${id}`).getAttribute('aria-describedby'), `${id}-error`, `describedby on ${id}`);
    assert.equal(await page.locator(`#${id}-error`).textContent(), message, `error text for ${id}`);
    assert.equal(await page.locator(`#${id}-error`).isVisible(), true, `error visible for ${id}`);
  }
  assert.equal(await page.evaluate(() => document.activeElement.id), 'name');
  assert.equal(await page.locator('#form-status').textContent(), '');
});

test('visit form rejects malformed email addresses', async ({ open }) => {
  const page = await open('visit.html');
  await page.fill('#name', 'Ann Reader');
  await page.fill('#message', 'Do you stock poetry chapbooks?');
  for (const bad of ['not-an-email', 'a@b']) {
    await page.fill('#email', bad);
    await page.getByRole('button', { name: 'Send message' }).click();
    assert.equal(
      await page.locator('#email-error').textContent(),
      'Enter an email address like name@example.com.',
      `email error for ${bad}`
    );
    assert.equal(await page.locator('#email').getAttribute('aria-invalid'), 'true');
    assert.equal(await page.evaluate(() => document.activeElement.id), 'email', `focus for ${bad}`);
    assert.equal(await page.locator('#name-error').isHidden(), true, 'valid name has no error');
  }
  await page.fill('#email', 'a@b.co');
  await page.getByRole('button', { name: 'Send message' }).click();
  assert.equal(await page.locator('#email').getAttribute('aria-invalid'), 'false');
  assert.match(await page.locator('#form-status').textContent(), /demo/);
});

test('visit form treats whitespace-only name and message as empty', async ({ open }) => {
  const page = await open('visit.html');
  await page.fill('#name', '     ');
  await page.fill('#email', 'ann@example.com');
  await page.fill('#message', '\n   \t  \n');
  await page.getByRole('button', { name: 'Send message' }).click();
  assert.equal(await page.locator('#name-error').textContent(), 'Enter your name.');
  assert.equal(await page.locator('#message-error').textContent(), 'Enter a message.');
  assert.equal(await page.locator('#email-error').isHidden(), true);
  assert.equal(await page.evaluate(() => document.activeElement.id), 'name');
  assert.equal(await page.locator('#form-status').textContent(), '');
});

test('visit form double submit stays consistent and sends nothing', async ({ open, session }) => {
  const page = await open('visit.html');
  await page.fill('#name', 'Ann Reader');
  await page.fill('#email', 'ann@example.com');
  await page.fill('#message', 'Hello');
  session.requests.length = 0;
  await page.getByRole('button', { name: 'Send message' }).click();
  await page.getByRole('button', { name: 'Send message' }).click();
  assert.match(await page.locator('#form-status').textContent(), /nothing was sent/);
  assert.equal(await page.locator('.field-error:not([hidden])').count(), 0);
  assert.equal(await page.locator('[aria-invalid="true"]').count(), 0);
  assert.deepEqual(session.requests, [], 'no requests after double submit');
});

test('visit valid submit says it is a demo and makes no network request', async ({ open, session }) => {
  const page = await open('visit.html');
  await page.fill('#name', 'Ann Reader');
  await page.fill('#email', 'ann@example.com');
  await page.fill('#message', 'Do you hold a signed first edition of The Glass Orchard?');
  session.requests.length = 0;
  await page.getByRole('button', { name: 'Send message' }).click();
  const status = page.locator('#form-status');
  await status.filter({ hasText: /demo/ }).waitFor();
  assert.equal(await status.getAttribute('role'), 'status');
  assert.match(await status.textContent(), /This is a demo form and nothing was sent/);
  assert.equal(page.url().endsWith('visit.html'), true, 'page did not navigate');
  assert.deepEqual(session.requests, [], 'no requests after submit');
});

test('visit very long message does not widen the page at 360px', async ({ open }) => {
  const page = await open('visit.html', 360);
  await page.fill('#name', 'Ann Reader');
  await page.fill('#email', 'ann@example.com');
  await page.fill('#message', 'x'.repeat(5000) + ' ' + 'word '.repeat(400));
  await page.getByRole('button', { name: 'Send message' }).click();
  await page.locator('#form-status').filter({ hasText: /demo/ }).waitFor();
  const scrollWidth = await page.evaluate(() => document.documentElement.scrollWidth);
  assert.ok(scrollWidth <= 360, `scrollWidth ${scrollWidth}`);
});

// Console errors, page errors and non-local requests fail every test through the session; this one walks all pages.
test('every page loads with no console errors and only local requests', async ({ open, session }) => {
  for (const path of PAGES) {
    const page = await open(path);
    await page.waitForLoadState('load');
  }
  assert.ok(session.requests.length >= PAGES.length, 'pages were requested from the local server');
  assert.ok(session.requests.every((r) => r.url.startsWith('http://127.0.0.1:')), 'all requests are local');
});

async function run() {
  const filter = process.argv[2] || '';
  const selected = tests.filter((t) => t.name.includes(filter));
  if (selected.length === 0) {
    console.error(`No tests match "${filter}"`);
    process.exit(1);
  }

  const executablePath = existsSync(chromium.executablePath()) ? undefined : CHROME_FALLBACK;
  const browser = await chromium.launch({ headless: true, executablePath });
  const { server, origin } = await startServer();
  let failures = 0;

  try {
    for (const item of selected) {
      const { session, problems, contexts } = makeSession(browser, origin);
      let error = null;
      try {
        await item.fn({ open: session.open, session });
      } catch (caught) {
        error = caught;
      }
      for (const context of contexts) {
        await context.close();
      }
      if (!error && problems.length > 0) {
        error = new Error(problems.join('\n  '));
      }
      if (error) {
        failures++;
        console.log(`FAIL ${item.name}\n  ${error.message.split('\n').join('\n  ')}`);
      } else {
        console.log(`PASS ${item.name}`);
      }
    }
  } finally {
    await browser.close();
    server.close();
  }

  console.log(`\n${selected.length - failures} passed, ${failures} failed`);
  process.exit(failures === 0 ? 0 : 1);
}

run().catch((error) => {
  console.error(error);
  process.exit(1);
});

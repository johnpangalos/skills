(function () {
  'use strict';

  // Opening hours indexed by Date.getDay() (0 = Sunday). Keep in step with the table on visit.html.
  var DAY_NAMES = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
  var HOURS = ['11:00 to 17:00', 'Closed', '10:00 to 19:00', '10:00 to 19:00', '10:00 to 19:00', '10:00 to 19:00', '9:30 to 18:00'];

  function pickItem(book) {
    var item = document.createElement('li');
    item.className = 'pick';

    var title = document.createElement('strong');
    title.textContent = book.title;

    var meta = document.createElement('span');
    meta.textContent = 'by ' + book.author + ', £' + book.price.toFixed(2);

    item.append(title, meta);
    return item;
  }

  var picks = CATALOG.filter(function (book) {
    return book.featured;
  });
  document.getElementById('featured-list').replaceChildren(...picks.map(pickItem));

  var day = new Date().getDay();
  var line = document.getElementById('today-hours');
  if (HOURS[day] === 'Closed') {
    line.textContent = 'We are closed today (' + DAY_NAMES[day] + ').';
  } else {
    line.textContent = 'Open today (' + DAY_NAMES[day] + '), ' + HOURS[day] + '.';
  }
})();

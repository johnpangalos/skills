// Events: the upcoming/past split uses the local day, dates are human-readable, and the home teaser agrees.
import { test, before, after } from "node:test";
import assert from "node:assert/strict";
import { startServer, launchBrowser, openTracked } from "./helpers.mjs";

let server;
let browser;

before(async () => {
  server = await startServer();
  browser = await launchBrowser();
});

after(async () => {
  await browser?.close();
  await server?.close();
});

const titlesIn = (page, selector) =>
  page.$$eval(`${selector} .event h3`, (headings) =>
    headings.map((h) => h.textContent),
  );

test("on 17 November 2026 an event today is upcoming and earlier events are in the past section", async () => {
  const { context, page, problems } = await openTracked(
    browser,
    server.origin,
    "events.html",
    {
      now: new Date(2026, 10, 17, 10, 0),
    },
  );
  const upcoming = await titlesIn(page, "#upcoming-list");
  assert.equal(upcoming[0], "Open Mic for Local Poets");
  assert.equal(upcoming.length, 10);
  assert.equal(await page.locator("#past-events").isVisible(), true);
  assert.equal(
    await page.locator("#past-events h2").textContent(),
    "Past events",
  );
  assert.deepEqual(await titlesIn(page, "#past-list"), [
    "Autumn Poetry Launch",
    "Kids' Story Time: Owls and Lanterns",
  ]);
  assert.deepEqual(problems, []);
  await context.close();
});

test("an event is upcoming on its own day at 00:00 local time", async () => {
  const { context, page } = await openTracked(
    browser,
    server.origin,
    "events.html",
    {
      now: new Date(2026, 10, 17, 0, 0),
    },
  );
  assert.equal(
    (await titlesIn(page, "#upcoming-list"))[0],
    "Open Mic for Local Poets",
  );
  await context.close();
});

test("the same event moves to the past the day after", async () => {
  const { context, page } = await openTracked(
    browser,
    server.origin,
    "events.html",
    {
      now: new Date(2026, 10, 18, 9, 0),
    },
  );
  assert.equal(
    (await titlesIn(page, "#upcoming-list"))[0],
    "Book Club: The Glass Orchard",
  );
  assert.ok(
    (await titlesIn(page, "#past-list")).includes("Open Mic for Local Poets"),
  );
  await context.close();
});

test("upcoming events are sorted by date with machine-readable time elements", async () => {
  const { context, page } = await openTracked(
    browser,
    server.origin,
    "events.html",
  );
  const times = await page.$$eval("#upcoming-list time", (elements) =>
    elements.map((time) => time.getAttribute("datetime")),
  );
  assert.equal(times.length, 10);
  assert.deepEqual([...times].sort(), times);
  assert.equal(times[0], "2026-11-17T18:30");
  await context.close();
});

test("dates are formatted for people, and each event says whether it is free or ticketed", async () => {
  const { context, page } = await openTracked(
    browser,
    server.origin,
    "events.html",
  );
  const bookClub = page.locator(".event", {
    hasText: "Book Club: The Glass Orchard",
  });
  assert.equal(
    await bookClub.locator("time").textContent(),
    "Thursday, 26 November 2026, 7:00 pm",
  );
  assert.match(await bookClub.textContent(), /Ticketed, £6/);
  const openMic = page.locator(".event", {
    hasText: "Open Mic for Local Poets",
  });
  assert.match(await openMic.textContent(), /Free entry/);
  assert.equal(
    await openMic.locator("time").textContent(),
    "Tuesday, 17 November 2026, 6:30 pm",
  );
  await context.close();
});

test("with no upcoming events a friendly empty state replaces the list", async () => {
  const { context, page, problems } = await openTracked(
    browser,
    server.origin,
    "events.html",
    {
      now: new Date(2027, 5, 1, 9, 0),
    },
  );
  assert.equal(await page.locator("#upcoming-list").isVisible(), false);
  assert.match(
    await page.locator("#no-upcoming").textContent(),
    /No events are scheduled just now/,
  );
  assert.equal(await page.locator("#past-events").isVisible(), true);
  assert.deepEqual(problems, []);
  await context.close();
});

test("the home page teaser shows the next three upcoming events from the same data", async () => {
  const { context, page, problems } = await openTracked(
    browser,
    server.origin,
    "index.html",
  );
  assert.deepEqual(await titlesIn(page, "#event-teaser"), [
    "Open Mic for Local Poets",
    "Book Club: The Glass Orchard",
    "Reading: An Evening of Coastal Sonnets",
  ]);
  assert.equal(await page.locator("#teaser-empty").isVisible(), false);
  assert.deepEqual(problems, []);
  await context.close();
});

test("the home page teaser shows the friendly empty state when nothing is upcoming", async () => {
  const { context, page } = await openTracked(
    browser,
    server.origin,
    "index.html",
    {
      now: new Date(2027, 5, 1, 9, 0),
    },
  );
  assert.equal(await page.locator("#event-teaser").isVisible(), false);
  assert.equal(await page.locator("#teaser-empty").isVisible(), true);
  await context.close();
});

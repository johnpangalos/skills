const { test, before, after } = require('node:test');
const assert = require('node:assert/strict');
const { startServer } = require('./server');
const { launchBrowser, withPage } = require('./browser');

const NAME_ERROR = 'Please enter your name.';
const EMAIL_EMPTY = 'Please enter your email address.';
const EMAIL_FORMAT = 'Please enter an email address like name@example.com.';
const MESSAGE_ERROR = 'Please enter a message.';

let server;
let browser;

before(async () => {
  server = await startServer();
  browser = await launchBrowser();
});

after(async () => {
  await browser.close();
  await server.close();
});

function openVisit(viewport, run) {
  return withPage(browser, `${server.base}/visit.html`, run, viewport);
}

async function fill(page, name, value) {
  await page.fill(`#contact-${name}`, value);
}

async function errorText(page, name) {
  return page.textContent(`#contact-${name}-error`);
}

async function submit(page) {
  await page.click('#contact-form button[type="submit"]');
}

test('submitting empty fields shows a specific error for each required field and focuses the first', async () => {
  await openVisit(undefined, async (page) => {
    await submit(page);
    assert.equal(await errorText(page, 'name'), NAME_ERROR);
    assert.equal(await errorText(page, 'email'), EMAIL_EMPTY);
    assert.equal(await errorText(page, 'message'), MESSAGE_ERROR);
    assert.equal(await page.getAttribute('#contact-name', 'aria-invalid'), 'true');
    assert.equal(await page.getAttribute('#contact-email', 'aria-invalid'), 'true');
    assert.equal(await page.getAttribute('#contact-message', 'aria-invalid'), 'true');
    assert.equal(await page.getAttribute('#contact-name', 'aria-describedby'), 'contact-name-error');
    assert.equal(await page.getAttribute('#contact-email', 'aria-describedby'), 'contact-email-error');
    assert.equal(await page.getAttribute('#contact-message', 'aria-describedby'), 'contact-message-error');
    assert.equal(await page.evaluate(() => document.activeElement.id), 'contact-name');
    assert.equal(await page.getAttribute('#contact-form', 'novalidate'), '');
  });
});

test('malformed emails show the format error and focus the email field', async () => {
  for (const bad of ['a@', 'foo', 'a b@c.d', 'a@b..c', 'a@b.c.', 'a@.b.c', 'a@b.c..d']) {
    await openVisit(undefined, async (page) => {
      await fill(page, 'name', 'Ada Lovelace');
      await fill(page, 'email', bad);
      await fill(page, 'message', 'Do you stock poetry?');
      await submit(page);
      assert.equal(await errorText(page, 'email'), EMAIL_FORMAT, `error for "${bad}"`);
      assert.equal(await errorText(page, 'name'), '', 'name is valid');
      assert.equal(await page.getAttribute('#contact-email', 'aria-invalid'), 'true');
      assert.equal(await page.evaluate(() => document.activeElement.id), 'contact-email', `focus for "${bad}"`);
    });
  }
});

test('a whitespace-only message shows the message error', async () => {
  await openVisit(undefined, async (page) => {
    await fill(page, 'name', 'Ada Lovelace');
    await fill(page, 'email', 'ada@example.com');
    await fill(page, 'message', '   \n\t  ');
    await submit(page);
    assert.equal(await errorText(page, 'message'), MESSAGE_ERROR);
    assert.equal(await page.evaluate(() => document.activeElement.id), 'contact-message');
  });
});

test('errors clear once the field is corrected', async () => {
  await openVisit(undefined, async (page) => {
    await submit(page);
    await fill(page, 'name', 'Ada');
    assert.equal(await errorText(page, 'name'), '');
    assert.equal(await page.getAttribute('#contact-name', 'aria-invalid'), null);
    await fill(page, 'email', 'foo');
    assert.equal(await errorText(page, 'email'), EMAIL_FORMAT);
    await fill(page, 'email', 'ada@example.com');
    assert.equal(await errorText(page, 'email'), '');
    assert.equal(await page.getAttribute('#contact-email', 'aria-invalid'), null);
  });
});

test('a valid submit shows a demo status, sends no request and does not claim the message was sent', async () => {
  await openVisit(undefined, async (page, seen) => {
    await fill(page, 'name', 'Ada Lovelace');
    await fill(page, 'email', 'ada@example.com');
    await fill(page, 'subject', 'Poetry night');
    await fill(page, 'message', 'Do you stock poetry?');
    const before = seen.requests.length;
    await submit(page);
    const status = page.locator('#form-status');
    assert.equal(await status.getAttribute('role'), 'status');
    await page.waitForFunction(() => document.getElementById('form-status').textContent !== '');
    const text = await status.textContent();
    assert.match(text, /demo site/);
    assert.match(text, /was not sent/);
    assert.match(text, /hello@marginalia-books\.example/);
    assert.match(text, /01632 960229/);
    assert.doesNotMatch(text, /thank/i);
    assert.equal(seen.requests.length, before, 'no network request was made by the submit');
    assert.equal(seen.errors.length, 0);
  });
});

test('a very long message does not overflow a 360px layout', async () => {
  await openVisit({ width: 360, height: 800 }, async (page) => {
    const long = 'x'.repeat(10000);
    await fill(page, 'name', 'Ada Lovelace');
    await fill(page, 'email', 'ada@example.com');
    await fill(page, 'message', long);
    await submit(page);
    assert.equal(await page.inputValue('#contact-message'), long);
    await page.waitForFunction(() => document.getElementById('form-status').textContent !== '');
    assert.match(await page.textContent('#form-status'), /was not sent/);
    const width = await page.evaluate(() => document.documentElement.scrollWidth);
    assert.ok(width <= 360, `scrollWidth ${width} should be at most 360`);
  });
});

test('valid addresses with multi-part suffixes, dotted names and plus tags are accepted', async () => {
  for (const good of ['name@example.co.uk', 'first.last+tag@mail.example.com']) {
    await openVisit(undefined, async (page) => {
      await fill(page, 'name', 'Ada Lovelace');
      await fill(page, 'email', good);
      await fill(page, 'message', 'Do you stock poetry?');
      await submit(page);
      assert.equal(await errorText(page, 'email'), '', `no error for "${good}"`);
      await page.waitForFunction(() => document.getElementById('form-status').textContent !== '');
      assert.match(await page.textContent('#form-status'), /was not sent/);
    });
  }
});

test('a repeat valid submit clears the status first so the notice is announced again', async () => {
  await openVisit(undefined, async (page) => {
    await fill(page, 'name', 'Ada Lovelace');
    await fill(page, 'email', 'ada@example.com');
    await fill(page, 'message', 'Do you stock poetry?');
    await page.evaluate(() => {
      window.statusLog = [];
      new MutationObserver(() => window.statusLog.push(document.getElementById('form-status').textContent))
        .observe(document.getElementById('form-status'), { childList: true, characterData: true, subtree: true });
    });
    await submit(page);
    await page.waitForFunction(() => window.statusLog.length >= 1);
    await submit(page);
    await page.waitForFunction(() => window.statusLog.length >= 3);
    const log = await page.evaluate(() => window.statusLog);
    assert.equal(log[1], '', 'status is cleared before the repeat notice');
    assert.match(log[2], /was not sent/);
  });
});

test('the visit page says plainly that the form is a demo, just before the form', async () => {
  await openVisit(undefined, async (page) => {
    const note = await page.locator('#contact-form').evaluate((form) => form.previousElementSibling.textContent);
    assert.match(note, /This is a demo site/);
    assert.match(note, /not delivered to the shop/);
  });
});

test('an invalid submit right after a valid one never shows the demo notice', async () => {
  await openVisit(undefined, async (page) => {
    await fill(page, 'name', 'Ada Reader');
    await fill(page, 'email', 'ada@example.com');
    await fill(page, 'message', 'Do you have a copy in stock?');
    await page.evaluate(() => {
      const form = document.getElementById('contact-form');
      form.requestSubmit();
      document.getElementById('contact-email').value = 'not-an-email';
      form.requestSubmit();
    });
    await page.waitForTimeout(200);
    assert.equal(await page.textContent('#form-status'), '');
    assert.equal(await page.getAttribute('#contact-email', 'aria-invalid'), 'true');
  });
});

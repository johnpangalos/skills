# Marginalia Books

A website for Marginalia Books, a fictional independent bookshop. It has four pages: home, books (a catalog you can filter by genre), events, and visit (opening hours, address and a contact form).

The site is plain HTML, CSS and JavaScript. There is no build step, no dependencies to install, and no external requests: no CDNs, web fonts or remote images. It uses system font stacks and classic scripts, so JavaScript must be enabled.

## Running it

The site works opened straight from disk: double-click `index.html` or open it with a `file://` address. You can also serve the repository root with any static server and open the address in a browser:

```sh
python3 -m http.server 8000
```

Then visit http://localhost:8000/.

## Layout

- `index.html`, `books.html`, `events.html`, `visit.html`: the pages. Each has the same shared navigation and marks its own link with `aria-current="page"`.
- `css/styles.css`: the one stylesheet, shared by all pages.
- `js/nav.js`: the mobile menu toggle, shared by all pages.
- `js/catalog.js`: the book catalog data.
- `js/books.js`: renders the catalog and the genre filter. The selected genre is kept in the URL (`books.html?genre=Poetry`), so filtered views can be bookmarked and back/forward work.
- `js/visit.js`: validation for the contact form.
- `tests/run.mjs`: the test suite.

## Running the tests

The tests use Playwright and a headless Chrome. Playwright must be resolvable from Node, either locally or from a global install. If Chrome is installed at `/usr/bin/google-chrome`, the tests use it; otherwise they use Playwright's bundled browser.

```sh
node tests/run.mjs
```

The suite starts its own static server on a random local port, loads every page, and checks:

- no console errors and no cross-origin requests;
- navigation links and the current-page marker;
- landmarks, one h1 per page, heading order, unique titles and the skip link;
- keyboard use of the mobile menu, including Escape and resizing;
- the catalog, the genre filter, its URL state, and hostile `?genre=` values;
- the catalog rendering when `books.html` is opened over `file://`;
- events, the visit page, and contact form validation and the demo message;
- no horizontal scrolling at 360px, text contrast, focus outlines, reduced motion and non-clickable cards.

The process exits with a non-zero status if any check fails.

## Notes

The shop, its staff, its address and its contact details are invented for this demo. The contact form does not send anything. It validates the fields and then says plainly that no message was sent.

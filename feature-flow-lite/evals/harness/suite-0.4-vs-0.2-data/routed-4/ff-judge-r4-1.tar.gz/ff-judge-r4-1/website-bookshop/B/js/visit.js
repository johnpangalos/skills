const EMAIL_PATTERN = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
const DEMO_MESSAGE = 'This is a demo. No message was sent. To reach us for real, email hello@marginalia.example.';

const form = document.getElementById('contact-form');
const formStatus = document.getElementById('form-status');

// Each rule returns an error message for the field, or an empty string when the value is acceptable.
const rules = {
  name: (value) => (value.trim() === '' ? 'Please enter your name.' : ''),
  email: (value) => {
    if (value.trim() === '') return 'Please enter your email address.';
    return EMAIL_PATTERN.test(value.trim()) ? '' : 'Please enter an email address like name@example.com.';
  },
  message: (value) => (value.trim() === '' ? 'Please write a message before sending.' : ''),
};

function showError(input, message) {
  const error = document.getElementById(`${input.id}-error`);
  error.textContent = message;
  error.hidden = message === '';
  input.setAttribute('aria-invalid', String(message !== ''));
}

function onSubmit(event) {
  event.preventDefault();
  let firstInvalid = null;
  for (const [id, rule] of Object.entries(rules)) {
    const input = document.getElementById(id);
    const message = rule(input.value);
    showError(input, message);
    if (message && !firstInvalid) firstInvalid = input;
  }
  if (firstInvalid) {
    formStatus.hidden = true;
    firstInvalid.focus();
    return;
  }
  formStatus.textContent = DEMO_MESSAGE;
  formStatus.hidden = false;
}

form.addEventListener('submit', onSubmit);

const { test, before, after } = require('node:test');
const assert = require('node:assert/strict');
const { startServer } = require('./server');
const { launchBrowser, withPage } = require('./browser');

const PAGES = ['index.html', 'books.html', 'events.html', 'visit.html'];

let server;
let browser;

before(async () => {
  server = await startServer();
  browser = await launchBrowser();
});

after(async () => {
  await browser.close();
  await server.close();
});

test('no page scrolls horizontally at 360px and the nav stays on screen', async () => {
  for (const file of PAGES) {
    await withPage(browser, `${server.base}/${file}`, async (page) => {
      const width = await page.evaluate(() => document.documentElement.scrollWidth);
      assert.ok(width <= 360, `${file} scrollWidth ${width} should be at most 360`);
      const nav = await page.locator('nav[aria-label="Main"] ul').boundingBox();
      assert.ok(nav.x >= 0 && nav.x + nav.width <= 360, `${file} nav fits within 360px`);
    }, { width: 360, height: 740 });
  }
});

test('no page scrolls horizontally at 768px or 1280px', async () => {
  for (const width of [768, 1280]) {
    for (const file of PAGES) {
      await withPage(browser, `${server.base}/${file}`, async (page) => {
        const scrollWidth = await page.evaluate(() => document.documentElement.scrollWidth);
        assert.ok(scrollWidth <= width, `${file} at ${width}px scrollWidth ${scrollWidth}`);
      }, { width, height: 900 });
    }
  }
});

test('no page scrolls horizontally at 360px with 200% text size', async () => {
  for (const file of PAGES) {
    await withPage(browser, `${server.base}/${file}`, async (page) => {
      await page.addStyleTag({ content: 'html { font-size: 200%; }' });
      const width = await page.evaluate(() => document.documentElement.scrollWidth);
      assert.ok(width <= 360, `${file} at 200% text scrollWidth ${width} should be at most 360`);
    }, { width: 360, height: 740 });
  }
});

test('opening-hours day names never break mid-word at 320px or 360px with 200% text', async () => {
  for (const width of [320, 360]) {
    await withPage(browser, `${server.base}/visit.html`, async (page) => {
      await page.addStyleTag({ content: 'html { font-size: 200%; }' });
      const split = await page.evaluate(() => [...document.querySelectorAll('.hours-table th[scope="row"]')]
        .filter((th) => {
          const range = document.createRange();
          range.selectNodeContents(th);
          return range.getClientRects().length !== 1;
        })
        .map((th) => th.textContent));
      assert.deepEqual(split, [], `day names split across lines at ${width}px`);
      const scrollWidth = await page.evaluate(() => document.documentElement.scrollWidth);
      assert.ok(scrollWidth <= width, `visit.html at ${width}px scrollWidth ${scrollWidth}`);
    }, { width, height: 740 });
  }
});

(function () {
  'use strict';

  var ALL = '';
  var select = document.getElementById('genre-filter');
  var list = document.getElementById('book-list');
  var resultCount = document.getElementById('result-count');
  var emptyNote = document.getElementById('empty-note');

  function genreNames() {
    var names = [];
    CATALOG.forEach(function (book) {
      if (names.indexOf(book.genre) === -1) {
        names.push(book.genre);
      }
    });
    return names;
  }

  // Maps any raw URL value to a real genre name, or ALL when it is empty or unknown.
  function matchGenre(raw) {
    var wanted = (raw || '').trim().toLowerCase();
    var names = genreNames();
    for (var i = 0; i < names.length; i++) {
      if (names[i].toLowerCase() === wanted) {
        return names[i];
      }
    }
    return ALL;
  }

  function bookItem(book) {
    var item = document.createElement('li');
    item.className = 'book';

    var title = document.createElement('h2');
    title.className = 'book-title';
    title.textContent = book.title;

    var author = document.createElement('p');
    author.className = 'book-meta';
    author.textContent = 'by ' + book.author;

    var genre = document.createElement('p');
    genre.className = 'book-meta book-genre';
    genre.textContent = book.genre;

    var blurb = document.createElement('p');
    blurb.className = 'book-blurb';
    blurb.textContent = book.blurb;

    var price = document.createElement('p');
    price.className = 'book-price';
    price.textContent = '£' + book.price.toFixed(2);

    item.append(title, author, genre, blurb, price);
    return item;
  }

  function showGenre(genre) {
    var shown = CATALOG.filter(function (book) {
      return genre === ALL || book.genre === genre;
    });
    list.replaceChildren(...shown.map(bookItem));
    emptyNote.hidden = shown.length > 0;
    if (genre === ALL) {
      resultCount.textContent = 'Showing ' + shown.length + ' of ' + CATALOG.length + ' books';
    } else {
      resultCount.textContent = 'Showing ' + shown.length + ' ' + (shown.length === 1 ? 'book' : 'books') + ' in ' + genre;
    }
  }

  function genreFromUrl() {
    return matchGenre(new URLSearchParams(window.location.search).get('genre'));
  }

  function fillGenreOptions() {
    var options = [new Option('All genres', ALL)];
    genreNames().forEach(function (name) {
      options.push(new Option(name, name));
    });
    select.replaceChildren(...options);
  }

  select.addEventListener('change', function () {
    var genre = select.value;
    var url = new URL(window.location.href);
    if (genre === ALL) {
      url.searchParams.delete('genre');
    } else {
      url.searchParams.set('genre', genre);
    }
    history.pushState(null, '', url);
    showGenre(genre);
  });

  window.addEventListener('popstate', function () {
    var genre = genreFromUrl();
    select.value = genre;
    showGenre(genre);
  });

  fillGenreOptions();
  select.value = genreFromUrl();
  showGenre(select.value);
})();

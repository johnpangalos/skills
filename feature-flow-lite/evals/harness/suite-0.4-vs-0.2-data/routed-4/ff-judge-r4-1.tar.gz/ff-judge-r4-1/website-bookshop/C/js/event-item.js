// Builds one event list item with the DOM API only.
import { formatEventDate } from "./events-logic.js";

export function createEventItem(event) {
  const item = document.createElement("li");
  item.className = "event";

  const title = document.createElement("h3");
  title.textContent = event.title;

  const meta = document.createElement("p");
  meta.className = "event-meta";
  const time = document.createElement("time");
  time.dateTime = `${event.date}T${event.time}`;
  time.textContent = formatEventDate(event.date, event.time);
  const admission = document.createElement("span");
  admission.textContent = event.ticketed
    ? `Ticketed, ${event.price}`
    : "Free entry";
  meta.append(time, " · ", admission);

  const description = document.createElement("p");
  description.textContent = event.description;

  item.append(title, meta, description);
  return item;
}

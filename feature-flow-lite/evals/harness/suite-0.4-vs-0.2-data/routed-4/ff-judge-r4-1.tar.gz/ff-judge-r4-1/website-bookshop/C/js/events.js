// Events page: upcoming events first, past events in their own labelled section.
import { EVENTS } from "./events-data.js";
import { splitEvents } from "./events-logic.js";
import { createEventItem } from "./event-item.js";

const { upcoming, past } = splitEvents(EVENTS, new Date());

const upcomingList = document.getElementById("upcoming-list");
const noUpcoming = document.getElementById("no-upcoming");
upcomingList.replaceChildren(...upcoming.map(createEventItem));
upcomingList.hidden = upcoming.length === 0;
noUpcoming.hidden = upcoming.length > 0;

const pastSection = document.getElementById("past-events");
document
  .getElementById("past-list")
  .replaceChildren(...past.map(createEventItem));
pastSection.hidden = past.length === 0;

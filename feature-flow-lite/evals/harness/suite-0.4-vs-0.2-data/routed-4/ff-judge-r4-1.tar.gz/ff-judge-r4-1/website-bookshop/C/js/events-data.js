// The single events list, used by the events page and the home page teaser.
// `date` is a local calendar day (YYYY-MM-DD) and `time` is 24-hour local time (HH:MM).

export const EVENTS = [
  {
    id: "autumn-poetry-launch",
    title: "Autumn Poetry Launch",
    date: "2026-11-10",
    time: "19:00",
    description:
      "Hannah Vell reads from Low Tide Sonnets, followed by questions and a glass of cider.",
    ticketed: false,
  },
  {
    id: "owls-story-time-november",
    title: "Kids' Story Time: Owls and Lanterns",
    date: "2026-11-14",
    time: "10:30",
    description:
      "Picture books, a lantern craft and a short walk to see the church owls. Ages 3 to 7.",
    ticketed: false,
  },
  {
    id: "open-mic-poets",
    title: "Open Mic for Local Poets",
    date: "2026-11-17",
    time: "18:30",
    description:
      "Five minutes each on the shop floor. Sign up at the till when you arrive.",
    ticketed: false,
  },
  {
    id: "book-club-glass-orchard",
    title: "Book Club: The Glass Orchard",
    date: "2026-11-26",
    time: "19:00",
    description:
      "Our monthly book club discusses Eleanor Marsh’s novel. Copies are on the front table.",
    ticketed: true,
    price: "£6",
  },
  {
    id: "reading-hannah-vell",
    title: "Reading: An Evening of Coastal Sonnets",
    date: "2026-12-03",
    time: "19:00",
    description:
      "Hannah Vell returns with new poems written over the winter tide tables.",
    ticketed: false,
  },
  {
    id: "wrapping-workshop",
    title: "Winter Gift Wrapping Workshop",
    date: "2026-12-05",
    time: "10:00",
    description:
      "Learn three folds for wrapping books, with paper and ribbon provided. Seats are limited.",
    ticketed: true,
    price: "£12",
  },
  {
    id: "story-time-december",
    title: "Kids' Story Time: Snow Gardens",
    date: "2026-12-12",
    time: "10:30",
    description:
      "Stories about winter gardens, then paper snowflakes at the reading table. Ages 3 to 7.",
    ticketed: false,
  },
  {
    id: "ferry-book-club",
    title: "Winter Book Club: A Ferry Across the Dark",
    date: "2026-12-17",
    time: "19:00",
    description:
      "A discussion of Daniel Osei’s lake novel, with mulled apple juice for everyone.",
    ticketed: true,
    price: "£6",
  },
  {
    id: "print-demonstration",
    title: "Letterpress Print Demonstration",
    date: "2026-12-19",
    time: "14:00",
    description:
      "Liesel Brandt prints a card for each guest on the shop’s Albion press.",
    ticketed: true,
    price: "£10",
  },
  {
    id: "canal-men-founders-night",
    title: "Founders’ Night: The Canal Men",
    date: "2027-01-14",
    time: "18:00",
    description:
      "Robert Ashby talks about the lock keepers and bargemen behind his new history.",
    ticketed: false,
  },
  {
    id: "spring-story-time",
    title: "Kids' Story Time: Spring Is Coming",
    date: "2027-02-06",
    time: "10:30",
    description:
      "Seed packets, rhyming stories and a short song about the first daffodils. Ages 3 to 7.",
    ticketed: false,
  },
  {
    id: "science-fiction-salon",
    title: "Science Fiction Salon: Orbit Under Glass",
    date: "2027-02-19",
    time: "19:00",
    description:
      "Kenji Mori joins us to talk about station gardens, slow time and the ethics of hydroponics.",
    ticketed: true,
    price: "£7",
  },
];

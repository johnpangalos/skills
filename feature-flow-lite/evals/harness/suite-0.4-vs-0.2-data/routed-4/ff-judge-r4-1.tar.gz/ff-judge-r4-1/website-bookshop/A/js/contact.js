(function () {
  'use strict';

  // The domain is one or more non-empty labels joined by single dots, so a@b..c and a@b.c. fail.
  var EMAIL_PATTERN = /^[^\s@]+@[^\s@.]+(\.[^\s@.]+)+$/;
  var FIELDS = ['name', 'email', 'message'];
  var status = document.getElementById('form-status');
  var form = document.getElementById('contact-form');
  var noticeTimer;

  var MESSAGES = {
    name: 'Please enter your name.',
    email: 'Please enter your email address.',
    emailFormat: 'Please enter an email address like name@example.com.',
    message: 'Please enter a message.'
  };

  var DEMO_NOTICE = 'This is a demo site, so your message was not sent. ' +
    'To reach the shop, email hello@marginalia-books.example or call 01632 960229.';

  function fieldInput(name) {
    return document.getElementById('contact-' + name);
  }

  // Returns the error for a trimmed value, or '' when the field is valid.
  function errorFor(name, value) {
    if (value === '') {
      return MESSAGES[name];
    }
    if (name === 'email' && !EMAIL_PATTERN.test(value)) {
      return MESSAGES.emailFormat;
    }
    return '';
  }

  // Validates one field, updates its error text, and returns true when it is valid.
  function validateField(name) {
    var input = fieldInput(name);
    var message = errorFor(name, input.value.trim());
    document.getElementById('contact-' + name + '-error').textContent = message;
    if (message) {
      input.setAttribute('aria-invalid', 'true');
    } else {
      input.removeAttribute('aria-invalid');
    }
    return message === '';
  }

  form.addEventListener('submit', function (event) {
    event.preventDefault();
    // Clear first; on a valid submit the text is set again on the next tick so a repeat submit is announced.
    clearTimeout(noticeTimer);
    status.textContent = '';
    // filter (not find) so every field shows its error, not just the first.
    var invalid = FIELDS.filter(function (name) {
      return !validateField(name);
    });
    if (invalid.length > 0) {
      fieldInput(invalid[0]).focus();
      return;
    }
    noticeTimer = setTimeout(function () {
      status.textContent = DEMO_NOTICE;
    }, 50);
  });

  FIELDS.forEach(function (name) {
    var input = fieldInput(name);
    input.addEventListener('input', function () {
      if (input.getAttribute('aria-invalid') === 'true') {
        validateField(name);
      }
    });
  });
})();

# Marginalia Books

A static website for Marginalia Books, a fictional independent bookshop on Lantern Row in
the market town of Little Hadley. It has a home page, a browsable catalogue with genre
filters, an events list, and a visit page with opening hours, directions and a contact form.

The site is plain HTML, CSS and JavaScript. There is no build step, no framework and no
runtime dependencies. It makes no requests outside its own origin: no CDNs, web fonts,
analytics or remote images.

## Running it locally

Serve the repository root with any static server, then open the printed address:

```sh
python3 -m http.server 8080
# then open http://localhost:8080/
```

`npx http-server -p 8080 -s .` works too. Pages use relative links, so the site also works
when it is deployed under a sub-path.

## File layout

```
index.html          Home: intro, featured books, next events, hours summary
books.html          Catalogue with genre filters (state kept in ?genre=...)
events.html         Upcoming and past events
visit.html          Opening hours, address, access notes, contact form
css/styles.css      The one shared stylesheet (colours are CSS custom properties)
js/books-data.js    The book catalogue (single source of truth)
js/events-data.js   The events list (single source of truth)
js/events-logic.js  Local-date helpers: upcoming/past split and date formatting
js/event-item.js    Builds one event list item
js/book-card.js     Builds one book card and its SVG cover
js/books.js         Books page: filtering, URL state and the live result count
js/events.js        Events page
js/home.js          Home page featured books and event teaser
js/contact.js       Contact form validation and the demo confirmation
js/nav.js           Shared menu toggle for narrow screens
tests/              Headless-browser tests (node:test + Playwright)
```

To add a book or event, edit the data file. Every page that shows them renders from there.

## Running the tests

The tests start their own static server on an ephemeral port and drive headless Chromium
through Playwright. They expect Playwright to be installed globally, for example at
`/opt/node-tools/node_modules/playwright`. The helper falls back to `npm root -g` to find it.

```sh
node --test tests/*.test.mjs            # all tests
node --test tests/books.test.mjs        # one file
npx prettier --check "**/*.{html,css,js,mjs}"   # formatting
```

The event tests fix the clock to 17 November 2026 with Playwright's clock API, so their results
do not depend on the real date.

// Visit page contact form: validation errors, error wiring, demo confirmation, and hostile input.
import { test, before, after } from "node:test";
import assert from "node:assert/strict";
import { startServer, launchBrowser, openTracked } from "./helpers.mjs";

let server;
let browser;

before(async () => {
  server = await startServer();
  browser = await launchBrowser();
});

after(async () => {
  await browser?.close();
  await server?.close();
});

const FIELD_ERRORS = {
  name: "Please enter your name.",
  email: "Please enter your email address.",
  message: "Please write a message.",
};

async function fieldState(page, id) {
  return page.evaluate((fieldId) => {
    const input = document.getElementById(fieldId);
    const error = document.getElementById(`${fieldId}-error`);
    return {
      invalid: input.getAttribute("aria-invalid"),
      describedBy: input.getAttribute("aria-describedby"),
      errorText: error.hidden ? "" : error.textContent,
    };
  }, id);
}

async function fill(page, values) {
  for (const [id, value] of Object.entries(values)) {
    await page.locator(`#${id}`).fill(value);
  }
}

test("submitting an empty form marks every required field and focuses the error summary", async () => {
  const { context, page, problems } = await openTracked(
    browser,
    server.origin,
    "visit.html",
  );
  const start = page.url();
  await page.getByRole("button", { name: "Send message" }).click();

  for (const [id, text] of Object.entries(FIELD_ERRORS)) {
    const state = await fieldState(page, id);
    assert.equal(state.invalid, "true", id);
    assert.equal(state.describedBy, `${id}-error`, id);
    assert.equal(state.errorText, text, id);
  }
  assert.equal(
    await page.evaluate(() => document.activeElement.id),
    "error-summary",
  );
  assert.equal(await page.locator("#error-summary a").count(), 3);
  assert.equal(page.url(), start);
  assert.deepEqual(problems, []);
  await context.close();
});

test("whitespace-only name and message count as empty", async () => {
  const { context, page } = await openTracked(
    browser,
    server.origin,
    "visit.html",
  );
  await fill(page, {
    name: "   ",
    email: "reader@example.com",
    message: "          ",
  });
  await page.getByRole("button", { name: "Send message" }).click();
  assert.equal((await fieldState(page, "name")).errorText, FIELD_ERRORS.name);
  assert.equal(
    (await fieldState(page, "message")).errorText,
    FIELD_ERRORS.message,
  );
  assert.equal((await fieldState(page, "email")).invalid, null);
  await context.close();
});

test("addresses with dots, hyphens, quotes, plus signs and punycode domains are accepted", async () => {
  const addresses = [
    "a.b-c@sub.example.co.uk",
    "o'neil@example.ie",
    "user@xn--bcher-kva.example",
    "jo+x@ex.co",
    "jo.smith+books@mail.example.co.uk",
  ];
  for (const email of addresses) {
    const { context, page } = await openTracked(
      browser,
      server.origin,
      "visit.html",
    );
    await fill(page, {
      name: "Ada",
      email,
      message: "Do you stock poetry chapbooks?",
    });
    await page.getByRole("button", { name: "Send message" }).click();
    assert.equal((await fieldState(page, "email")).invalid, null, email);
    await context.close();
  }
});

for (const [label, email] of [
  ["no dot in the domain", "a@b"],
  ["no domain", "foo@"],
  ["no local part", "@b.com"],
  ["no @ sign", "foo.example.com"],
  ["a space inside", "a b@example.com"],
  ["consecutive dots in the domain", "a@b..com"],
  ["a leading dot in the domain", "a@.b.com"],
  ["a trailing dot in the domain", "a@b.com."],
  ["a leading dot in the local part", ".a@b.com"],
  ["consecutive dots in the local part", "a..b@c.com"],
  ["a trailing dot in the local part", "a.@b.com"],
  ["a leading hyphen in the domain", "a@-b.com"],
  ["a trailing hyphen in the domain", "a@b-.com"],
  ["an underscore in the domain", "a@b_c.com"],
]) {
  test(`an invalid email (${label}) is rejected with a specific message`, async () => {
    const { context, page } = await openTracked(
      browser,
      server.origin,
      "visit.html",
    );
    await fill(page, {
      name: "Ada",
      email,
      message: "Do you stock poetry chapbooks?",
    });
    await page.getByRole("button", { name: "Send message" }).click();
    const state = await fieldState(page, "email");
    assert.equal(state.invalid, "true");
    assert.equal(
      state.errorText,
      "Please enter a valid email address, such as name@example.com.",
    );
    assert.equal(await page.locator("#form-confirmation").isVisible(), false);
    await context.close();
  });
}

test("a message under 10 characters is rejected", async () => {
  const { context, page } = await openTracked(
    browser,
    server.origin,
    "visit.html",
  );
  await fill(page, {
    name: "Ada",
    email: "ada@example.com",
    message: "Hi there",
  });
  await page.getByRole("button", { name: "Send message" }).click();
  assert.equal(
    (await fieldState(page, "message")).errorText,
    "Your message needs at least 10 characters.",
  );
  await context.close();
});

test("fixing a field clears its error, aria-invalid and aria-describedby", async () => {
  const { context, page } = await openTracked(
    browser,
    server.origin,
    "visit.html",
  );
  await page.getByRole("button", { name: "Send message" }).click();
  await page.locator("#name").fill("Ada Lovelace");
  const name = await fieldState(page, "name");
  assert.equal(name.invalid, null);
  assert.equal(name.describedBy, null);
  assert.equal(name.errorText, "");
  assert.equal(await page.locator("#error-summary a").count(), 2);
  await context.close();
});

test("a normal address with plus, dots and a multi-part domain is accepted", async () => {
  const { context, page } = await openTracked(
    browser,
    server.origin,
    "visit.html",
  );
  await fill(page, {
    name: "Jo Smith",
    email: "jo.smith+books@mail.example.co.uk",
    message: "Do you stock poetry chapbooks?",
  });
  await page.getByRole("button", { name: "Send message" }).click();
  const state = await fieldState(page, "email");
  assert.equal(state.invalid, null);
  assert.equal(await page.locator("#form-confirmation").isVisible(), true);
  await context.close();
});

test("a valid submit shows the demo confirmation, does not navigate or send anything", async () => {
  const { context, page, problems } = await openTracked(
    browser,
    server.origin,
    "visit.html",
  );
  const requests = [];
  page.on("request", (request) => {
    if (request.method() !== "GET") {
      requests.push(request.url());
    }
  });
  const start = page.url();
  await fill(page, {
    name: "Ada Lovelace",
    email: "ada@example.com",
    message: "Do you have any Poetry chapbooks in stock this month?",
  });
  await page.locator("#topic").selectOption("events");
  await page.getByRole("button", { name: "Send message" }).click();

  const confirmation = page.locator("#form-confirmation");
  assert.equal(await confirmation.isVisible(), true);
  assert.match(
    await confirmation.textContent(),
    /This is a demo site, so nothing was sent/,
  );
  assert.match(await confirmation.textContent(), /hello@marginalia\.example/);
  assert.equal(
    await page.evaluate(() => document.activeElement.id),
    "form-confirmation",
  );
  assert.equal(
    await page.locator("#contact-form").evaluate((form) => form.inert),
    true,
  );
  assert.equal(page.url(), start);
  assert.deepEqual(requests, []);
  assert.deepEqual(problems, []);
  await context.close();
});

test("a double click on submit produces a single confirmation", async () => {
  const { context, page } = await openTracked(
    browser,
    server.origin,
    "visit.html",
  );
  await fill(page, {
    name: "Ada",
    email: "ada@example.com",
    message: "A question about events",
  });
  await page.getByRole("button", { name: "Send message" }).dblclick();
  assert.equal(await page.locator("#form-confirmation").count(), 1);
  assert.equal(await page.locator("#form-confirmation").isVisible(), true);
  await context.close();
});

test("a very long message (5000+ characters) is accepted and does not break the layout", async () => {
  const { context, page, problems } = await openTracked(
    browser,
    server.origin,
    "visit.html",
    {
      width: 360,
      height: 740,
    },
  );
  const long = "unbreakablewordrunningonforeverwithoutanyspacesatall".repeat(
    100,
  );
  assert.ok(long.length >= 5000);
  await fill(page, { name: "Ada", email: "ada@example.com", message: long });
  await page.getByRole("button", { name: "Send message" }).click();
  assert.equal(await page.locator("#form-confirmation").isVisible(), true);
  const overflow = await page.evaluate(() => ({
    scrollWidth: document.documentElement.scrollWidth,
    innerWidth: window.innerWidth,
  }));
  assert.ok(
    overflow.scrollWidth <= overflow.innerWidth,
    JSON.stringify(overflow),
  );
  assert.deepEqual(problems, []);
  await context.close();
});

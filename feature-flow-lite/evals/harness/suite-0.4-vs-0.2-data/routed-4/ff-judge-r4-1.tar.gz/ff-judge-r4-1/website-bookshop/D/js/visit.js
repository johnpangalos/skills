(function () {
  'use strict';

  var form = document.getElementById('contact-form');
  var status = document.getElementById('form-status');
  var EMAIL_PATTERN = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

  // Each rule takes the trimmed value and returns an error message, or '' when valid.
  var rules = {
    name: function (value) {
      return value === '' ? 'Enter your name.' : '';
    },
    email: function (value) {
      if (value === '') {
        return 'Enter your email address.';
      }
      return EMAIL_PATTERN.test(value) ? '' : 'Enter an email address like name@example.com.';
    },
    message: function (value) {
      return value === '' ? 'Enter a message.' : '';
    }
  };

  function showError(field, message) {
    var error = document.getElementById(field.id + '-error');
    error.textContent = message;
    error.hidden = message === '';
    field.setAttribute('aria-invalid', message === '' ? 'false' : 'true');
  }

  // Validates one field, shows or clears its error, and reports whether it is valid.
  function validateField(field) {
    var message = rules[field.id](field.value.trim());
    showError(field, message);
    return message === '';
  }

  form.addEventListener('submit', function (event) {
    event.preventDefault();
    var fields = Object.keys(rules).map(function (id) {
      return document.getElementById(id);
    });
    var invalid = fields.filter(function (field) {
      return !validateField(field);
    });

    if (invalid.length > 0) {
      status.textContent = '';
      invalid[0].focus();
      return;
    }

    // Clear first so a repeat submit sets the message again and is announced.
    status.textContent = '';
    // This is a demo: the form has no backend, so nothing is sent.
    status.textContent = 'This is a demo form and nothing was sent. Marginalia Books has not received your message.';
  });

  // Once a field is flagged, keep its error current as the visitor types.
  form.addEventListener('input', function (event) {
    var field = event.target;
    if (field.getAttribute('aria-invalid') === 'true') {
      validateField(field);
    }
  });
})();

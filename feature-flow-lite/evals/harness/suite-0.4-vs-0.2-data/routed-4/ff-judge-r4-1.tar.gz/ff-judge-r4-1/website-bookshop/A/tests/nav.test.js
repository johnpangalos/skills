const { test, before, after } = require('node:test');
const assert = require('node:assert/strict');
const { startServer } = require('./server');
const { launchBrowser, withPage } = require('./browser');

const NAV = [
  { href: 'index.html', label: 'Home' },
  { href: 'books.html', label: 'Books' },
  { href: 'events.html', label: 'Events' },
  { href: 'visit.html', label: 'Visit' }
];
const PAGES = NAV.map((item) => item.href);

let server;
let browser;

before(async () => {
  server = await startServer();
  browser = await launchBrowser();
});

after(async () => {
  await browser.close();
  await server.close();
});

test('every page has the same nav with aria-current on the current page only', async () => {
  for (const current of PAGES) {
    await withPage(browser, `${server.base}/${current}`, async (page) => {
      const links = await page.$$eval('nav[aria-label="Main"] a', (anchors) =>
        anchors.map((a) => ({
          href: a.getAttribute('href'),
          label: a.textContent.trim(),
          current: a.getAttribute('aria-current')
        }))
      );
      assert.deepEqual(
        links.map(({ href, label }) => ({ href, label })),
        NAV,
        `nav on ${current}`
      );
      const marked = links.filter((link) => link.current === 'page').map((link) => link.href);
      assert.deepEqual(marked, [current], `aria-current on ${current}`);
    });
  }
});

test('every nav link resolves from the repo root', async () => {
  for (const { href } of NAV) {
    const response = await fetch(`${server.base}/${href}`);
    assert.equal(response.status, 200, `status for ${href}`);
  }
});

test('nav links resolve when a page is opened at a sub-path', async () => {
  const mounted = await startServer('/marginalia');
  try {
    await withPage(browser, `${mounted.base}/index.html`, async (page) => {
      for (const { href, label } of NAV) {
        await page.goto(`${mounted.base}/visit.html`);
        await page.locator('nav[aria-label="Main"]').getByRole('link', { name: label, exact: true }).click();
        await page.waitForURL(`**/${href}`);
        const current = await page.locator('nav[aria-label="Main"] [aria-current="page"]').textContent();
        assert.equal(current.trim(), label, `aria-current after clicking ${label}`);
        const heading = await page.locator('h1').count();
        assert.equal(heading, 1, `one h1 on ${href}`);
      }
    });
  } finally {
    await mounted.close();
  }
});

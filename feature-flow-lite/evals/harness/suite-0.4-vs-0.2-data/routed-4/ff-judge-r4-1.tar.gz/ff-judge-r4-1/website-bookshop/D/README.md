# Marginalia Books

A website for Marginalia Books, a fictional independent bookshop. It has four pages (home, books, events and visit), a genre-filtered catalogue, an events list and a contact form.

The site is plain HTML, CSS and JavaScript. There is no build step, no package to install and no external requests: no CDNs, web fonts, analytics or remote images.

## Run it

Either open `index.html` directly in a browser, or serve the folder from the repository root:

```sh
python3 -m http.server 8000
```

Then visit http://localhost:8000/.

The contact form is a demo. It validates input in the browser and says plainly that nothing was sent; it does not submit anywhere.

## Layout

- `index.html`, `books.html`, `events.html`, `visit.html`: the pages.
- `css/styles.css`: the shared stylesheet.
- `js/books.js`: genre filter, with the selected genre kept in the URL (`books.html?genre=mystery`).
- `js/visit.js`: contact form validation.
- `tests/run.mjs`: browser tests.

## Tests

The tests use Playwright from a global npm install and a Chrome binary. They start a local server on a random port, load each page in headless Chrome, and fail on any console error or any request to another origin.

```sh
node tests/run.mjs
```

Pass a name fragment to run a subset, for example `node tests/run.mjs books`. The script exits non-zero if any test fails.

If the Playwright bundled browser is not installed, the tests fall back to `/usr/bin/google-chrome`.

(function () {
  'use strict';

  var select = document.getElementById('genre');
  var list = document.getElementById('book-list');
  var count = document.getElementById('result-count');
  var books = Array.prototype.slice.call(list.querySelectorAll('.book'));
  var genres = Array.prototype.map.call(select.options, function (option) {
    return option.value;
  });

  // Reads ?genre= from the URL. Anything unknown, empty or malformed means All.
  function genreFromUrl() {
    var raw = new URLSearchParams(window.location.search).get('genre');
    var value = (raw || '').trim().toLowerCase();
    return genres.indexOf(value) === -1 ? 'all' : value;
  }

  function showGenre(genre) {
    var shown = 0;
    books.forEach(function (book) {
      var match = genre === 'all' || book.getAttribute('data-genre') === genre;
      book.hidden = !match;
      if (match) {
        shown += 1;
      }
    });
    select.value = genre;
    count.textContent = 'Showing ' + shown + ' of ' + books.length + ' books';
  }

  function pushGenreToUrl(genre) {
    var params = new URLSearchParams(window.location.search);
    if (genre === 'all') {
      params.delete('genre');
    } else {
      params.set('genre', genre);
    }
    var query = params.toString();
    history.pushState({ genre: genre }, '', window.location.pathname + (query ? '?' + query : ''));
  }

  select.addEventListener('change', function () {
    pushGenreToUrl(select.value);
    showGenre(select.value);
  });

  function syncFromUrl() {
    showGenre(genreFromUrl());
  }

  // popstate covers history moves within this page; pageshow covers returning from another page.
  window.addEventListener('popstate', syncFromUrl);
  window.addEventListener('pageshow', syncFromUrl);

  syncFromUrl();
})();

const { test, before, after } = require('node:test');
const assert = require('node:assert/strict');
const { startServer } = require('./server');
const { launchBrowser, withPage } = require('./browser');

const TOTAL = 15;

let server;
let browser;

before(async () => {
  server = await startServer();
  browser = await launchBrowser();
});

after(async () => {
  await browser.close();
  await server.close();
});

function open(query, run) {
  return withPage(browser, `${server.base}/books.html${query}`, run);
}

async function state(page) {
  return {
    selected: await page.inputValue('#genre-filter'),
    count: await page.textContent('#result-count'),
    genres: await page.$$eval('#book-list .book-genre', (els) => [...new Set(els.map((el) => el.textContent))]),
    shown: await page.locator('#book-list .book').count(),
    url: new URL(page.url())
  };
}

test('the catalogue has at least 12 titles across at least 4 genres with 2 or more titles each', async () => {
  await open('', async (page) => {
    assert.equal(await page.locator('#book-list .book').count(), TOTAL);
    const genres = await page.$$eval('#genre-filter option', (options) =>
      options.map((option) => option.value).filter((value) => value !== '')
    );
    assert.ok(genres.length >= 4, 'at least four genres');
    for (const genre of genres) {
      await page.selectOption('#genre-filter', genre);
      const shown = await page.locator('#book-list .book').count();
      assert.ok(shown >= 2, `${genre} has at least two titles`);
    }
  });
});

test('selecting a genre shows only that genre, announces the count and updates the URL', async () => {
  await open('', async (page) => {
    await page.selectOption('#genre-filter', 'Mystery');
    const result = await state(page);
    assert.equal(result.shown, 3);
    assert.deepEqual(result.genres, ['Mystery']);
    assert.equal(result.count, 'Showing 3 books in Mystery');
    assert.equal(result.url.searchParams.get('genre'), 'Mystery');
    assert.equal(await page.getAttribute('#result-count', 'aria-live'), 'polite');

    await page.selectOption('#genre-filter', '');
    const all = await state(page);
    assert.equal(all.shown, TOTAL);
    assert.equal(all.count, `Showing ${TOTAL} of ${TOTAL} books`);
    assert.equal(all.url.searchParams.has('genre'), false);
  });
});

test('loading ?genre= preselects the genre and shows the filtered list', async () => {
  await open('?genre=Mystery', async (page) => {
    const result = await state(page);
    assert.equal(result.selected, 'Mystery');
    assert.equal(result.shown, 3);
    assert.equal(result.count, 'Showing 3 books in Mystery');
  });
});

test('an empty genre parameter falls back to All', async () => {
  await open('?genre=', async (page) => {
    const result = await state(page);
    assert.equal(result.selected, '');
    assert.equal(result.shown, TOTAL);
  });
});

test('an unknown genre parameter falls back to All without errors', async () => {
  await open('?genre=Nonexistent', async (page, seen) => {
    const result = await state(page);
    assert.equal(result.selected, '');
    assert.equal(result.shown, TOTAL);
    assert.deepEqual(seen.errors, []);
  });
});

test('a script in the genre parameter is treated as unknown and never injected as HTML', async () => {
  const hostile = encodeURIComponent('<script>alert(1)</script>');
  await open(`?genre=${hostile}`, async (page, seen) => {
    const result = await state(page);
    assert.equal(result.selected, '');
    assert.equal(result.shown, TOTAL);
    assert.equal(await page.locator('#book-list script').count(), 0);
    assert.equal(await page.locator('script').count(), 2, 'only the page scripts exist');
    assert.deepEqual(seen.dialogs, [], 'no alert was raised');
    assert.deepEqual(seen.errors, []);
  });
});

test('the genre parameter is matched case-insensitively', async () => {
  await open('?genre=MYSTERY', async (page) => {
    const result = await state(page);
    assert.equal(result.selected, 'Mystery');
    assert.equal(result.shown, 3);
  });
});

test('genres with spaces and ampersands round-trip through the URL', async () => {
  await open('', async (page) => {
    await page.selectOption('#genre-filter', 'Science Fiction');
    const sf = await state(page);
    assert.equal(sf.url.searchParams.get('genre'), 'Science Fiction');
    await page.reload();
    const reloaded = await state(page);
    assert.equal(reloaded.selected, 'Science Fiction');
    assert.equal(reloaded.count, 'Showing 3 books in Science Fiction');

    await page.selectOption('#genre-filter', 'History & Place');
    const history = await state(page);
    assert.equal(history.url.searchParams.get('genre'), 'History & Place');
  });
  await open('?genre=History%20%26%20Place', async (page) => {
    const result = await state(page);
    assert.equal(result.selected, 'History & Place');
    assert.equal(result.shown, 3);
  });
});

test('back and forward restore the previous filter', async () => {
  await open('', async (page) => {
    await page.selectOption('#genre-filter', 'Mystery');
    await page.selectOption('#genre-filter', 'Science Fiction');
    await page.goBack();
    const back = await state(page);
    assert.equal(back.selected, 'Mystery');
    assert.equal(back.count, 'Showing 3 books in Mystery');
    await page.goForward();
    const forward = await state(page);
    assert.equal(forward.selected, 'Science Fiction');
    assert.equal(forward.count, 'Showing 3 books in Science Fiction');
  });
});

test('every book price is shown in pounds sterling', async () => {
  await open('', async (page) => {
    const prices = await page.$$eval('#book-list .book-price', (els) => els.map((el) => el.textContent));
    assert.equal(prices.length, TOTAL);
    for (const price of prices) {
      assert.match(price, /^£\d+\.\d{2}$/);
    }
  });
});

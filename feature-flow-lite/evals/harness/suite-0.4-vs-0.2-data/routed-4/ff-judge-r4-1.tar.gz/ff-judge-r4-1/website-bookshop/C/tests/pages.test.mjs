// Site-wide checks: structure, shared navigation, responsive layout, menu toggle, and network/console hygiene.
import { test, before, after } from "node:test";
import assert from "node:assert/strict";
import { startServer, launchBrowser, openTracked } from "./helpers.mjs";

const PAGES = [
  {
    path: "index.html",
    current: "Home",
    title: /Marginalia Books, an independent bookshop/,
  },
  { path: "books.html", current: "Books", title: /Browse books by genre/ },
  { path: "events.html", current: "Events", title: /Readings, book club/ },
  {
    path: "visit.html",
    current: "Visit",
    title: /Visit, contact and opening hours/,
  },
];

let server;
let browser;

before(async () => {
  server = await startServer();
  browser = await launchBrowser();
});

after(async () => {
  await browser?.close();
  await server?.close();
});

test("every page has the shared nav with aria-current on its own link only", async () => {
  for (const { path, current } of PAGES) {
    const { context, page, problems } = await openTracked(
      browser,
      server.origin,
      path,
    );
    const links = await page.$$eval("#site-nav a", (anchors) =>
      anchors.map((a) => ({
        text: a.textContent,
        current: a.getAttribute("aria-current"),
      })),
    );
    assert.deepEqual(
      links.map((link) => link.text),
      ["Home", "Books", "Events", "Visit"],
      path,
    );
    const marked = links
      .filter((link) => link.current === "page")
      .map((link) => link.text);
    assert.deepEqual(marked, [current], `${path} aria-current`);
    assert.deepEqual(problems, [], path);
    await context.close();
  }
});

test("every page has lang, a unique descriptive title, viewport, one h1 and named landmarks", async () => {
  const titles = new Set();
  for (const { path, title } of PAGES) {
    const { context, page } = await openTracked(browser, server.origin, path);
    const facts = await page.evaluate(() => ({
      lang: document.documentElement.lang,
      title: document.title,
      viewport: document.querySelector('meta[name="viewport"]')?.content ?? "",
      h1Count: document.querySelectorAll("h1").length,
      headers: document.querySelectorAll("body > header").length,
      mains: document.querySelectorAll("main").length,
      footers: document.querySelectorAll("body > footer").length,
      navLabel: document.querySelector("nav")?.getAttribute("aria-label"),
      skipFirst: document
        .querySelector("a, button, input, select, textarea")
        ?.textContent.trim(),
    }));
    assert.equal(facts.lang, "en", path);
    assert.match(facts.title, title, path);
    assert.ok(!titles.has(facts.title), `duplicate title on ${path}`);
    titles.add(facts.title);
    assert.match(facts.viewport, /width=device-width/, path);
    assert.equal(facts.h1Count, 1, path);
    assert.equal(facts.headers, 1, path);
    assert.equal(facts.mains, 1, path);
    assert.equal(facts.footers, 1, path);
    assert.equal(facts.navLabel, "Main", path);
    assert.equal(facts.skipFirst, "Skip to content", path);
    await context.close();
  }
});

test("skip link is the first focusable element and moves focus past the header", async () => {
  const { context, page } = await openTracked(
    browser,
    server.origin,
    "books.html",
  );
  await page.keyboard.press("Tab");
  const first = await page.evaluate(() =>
    document.activeElement.textContent.trim(),
  );
  assert.equal(first, "Skip to content");
  await page.keyboard.press("Enter");
  assert.equal(await page.evaluate(() => location.hash), "#main");
  await context.close();
});

test("focus is visibly styled on keyboard focus", async () => {
  const { context, page } = await openTracked(
    browser,
    server.origin,
    "index.html",
    { width: 1280 },
  );
  await page.keyboard.press("Tab");
  await page.keyboard.press("Tab");
  const outline = await page.evaluate(() => {
    const style = getComputedStyle(document.activeElement);
    return { style: style.outlineStyle, width: style.outlineWidth };
  });
  assert.equal(outline.style, "solid");
  assert.notEqual(outline.width, "0px");
  await context.close();
});

for (const width of [360, 320]) {
  test(`no page scrolls sideways at ${width}px`, async () => {
    for (const { path } of PAGES) {
      const { context, page, problems } = await openTracked(
        browser,
        server.origin,
        path,
        {
          width,
          height: 740,
        },
      );
      const overflow = await page.evaluate(() => ({
        scrollWidth: document.documentElement.scrollWidth,
        innerWidth: window.innerWidth,
      }));
      assert.ok(
        overflow.scrollWidth <= overflow.innerWidth,
        `${path}: ${JSON.stringify(overflow)}`,
      );
      assert.deepEqual(problems, [], path);
      await context.close();
    }
  });
}

test("at 360px the menu toggle opens and closes the nav, and Escape returns focus to it", async () => {
  const { context, page } = await openTracked(
    browser,
    server.origin,
    "events.html",
    {
      width: 360,
      height: 740,
    },
  );
  const toggle = page.locator(".nav-toggle");
  const nav = page.locator("#site-nav");
  assert.equal(await nav.isVisible(), false);
  assert.equal(await toggle.getAttribute("aria-controls"), "site-nav");
  assert.equal(await toggle.getAttribute("aria-expanded"), "false");

  await toggle.focus();
  await page.keyboard.press("Enter");
  assert.equal(await toggle.getAttribute("aria-expanded"), "true");
  assert.equal(await nav.isVisible(), true);
  await page.getByRole("link", { name: "Visit" }).focus();
  assert.equal(
    await page.evaluate(() => document.activeElement.textContent),
    "Visit",
  );

  await page.keyboard.press("Escape");
  assert.equal(await toggle.getAttribute("aria-expanded"), "false");
  assert.equal(await nav.isVisible(), false);
  assert.equal(
    await page.evaluate(() =>
      document.activeElement.classList.contains("nav-toggle"),
    ),
    true,
  );

  await toggle.click();
  assert.equal(await toggle.getAttribute("aria-expanded"), "true");
  await toggle.click();
  assert.equal(await toggle.getAttribute("aria-expanded"), "false");
  await context.close();
});

test("at desktop width the nav is inline and the menu toggle is hidden", async () => {
  const { context, page, problems } = await openTracked(
    browser,
    server.origin,
    "visit.html",
    {
      width: 1280,
    },
  );
  assert.equal(await page.locator("#site-nav").isVisible(), true);
  assert.equal(await page.locator(".nav-toggle").isVisible(), false);
  assert.deepEqual(problems, []);
  await context.close();
});

test("touch targets for nav links are at least 44px tall at 360px", async () => {
  const { context, page } = await openTracked(
    browser,
    server.origin,
    "index.html",
    {
      width: 360,
      height: 740,
    },
  );
  await page.locator(".nav-toggle").click();
  const heights = await page.$$eval("#site-nav a", (anchors) =>
    anchors.map((a) => a.getBoundingClientRect().height),
  );
  for (const height of heights) {
    assert.ok(height >= 44, `nav link is ${height}px tall`);
  }
  await context.close();
});

test("pages make no external requests and log no console errors while in use", async () => {
  for (const { path } of PAGES) {
    const { context, page, problems } = await openTracked(
      browser,
      server.origin,
      path,
      {
        width: 360,
        height: 740,
      },
    );
    await page.waitForLoadState("networkidle");
    await page.locator(".nav-toggle").click();
    await page.keyboard.press("Escape");
    assert.deepEqual(problems, [], path);
    await context.close();
  }
});

async function assertNoSideScroll(page, label) {
  const overflow = await page.evaluate(() => ({
    scrollWidth: document.documentElement.scrollWidth,
    innerWidth: window.innerWidth,
  }));
  assert.ok(
    overflow.scrollWidth <= overflow.innerWidth,
    `${label}: ${JSON.stringify(overflow)}`,
  );
}

test("an 80-character URL in an event description wraps at 320px", async () => {
  const { context, page, problems } = await openTracked(
    browser,
    server.origin,
    "events.html",
    { width: 320, height: 740 },
  );
  const longUrl = `https://marginalia.example/${"reading-list-".repeat(6)}`;
  assert.ok(longUrl.length >= 80);
  await page.evaluate((url) => {
    document.querySelector(".event > p:last-child").textContent = url;
  }, longUrl);
  await assertNoSideScroll(page, "events.html with long URL");
  assert.deepEqual(problems, []);
  await context.close();
});

test("a long email in an hours cell wraps at 320px", async () => {
  const { context, page, problems } = await openTracked(
    browser,
    server.origin,
    "visit.html",
    { width: 320, height: 740 },
  );
  await page.evaluate(() => {
    document.querySelector(".hours-table td").textContent =
      "bookings.weekend.reservations@marginalia-books.example.co.uk";
  });
  await assertNoSideScroll(page, "visit.html with long email");
  assert.deepEqual(problems, []);
  await context.close();
});

test("at 200% text size no page scrolls sideways at 360px or 320px", async () => {
  for (const width of [360, 320]) {
    for (const { path } of PAGES) {
      const { context, page, problems } = await openTracked(
        browser,
        server.origin,
        path,
        { width, height: 740 },
      );
      await page.addStyleTag({ content: "html { font-size: 200%; }" });
      await assertNoSideScroll(page, `${path} at 200% and ${width}px`);
      assert.deepEqual(problems, [], path);
      await context.close();
    }
  }
});

test("closing the menu when the window grows to desktop width keeps Escape from touching the hidden toggle", async () => {
  const { context, page } = await openTracked(
    browser,
    server.origin,
    "visit.html",
    { width: 360, height: 740 },
  );
  const toggle = page.locator(".nav-toggle");
  await toggle.click();
  assert.equal(await toggle.getAttribute("aria-expanded"), "true");
  await page.getByRole("link", { name: "Visit" }).focus();

  await page.setViewportSize({ width: 1280, height: 900 });
  await page.waitForFunction(
    () =>
      document.querySelector(".nav-toggle").getAttribute("aria-expanded") ===
      "false",
  );
  assert.equal(await page.locator("#site-nav").isVisible(), true);

  await page.keyboard.press("Escape");
  assert.equal(await toggle.getAttribute("aria-expanded"), "false");
  assert.equal(
    await page.evaluate(() => document.activeElement.textContent),
    "Visit",
  );
  await context.close();
});

test("the home page leaves space above the browse and see-all links", async () => {
  const { context, page, problems } = await openTracked(
    browser,
    server.origin,
    "index.html",
  );
  const gap = (above, below) =>
    page.evaluate(
      ([upper, lower]) =>
        document.querySelector(lower).getBoundingClientRect().top -
        document.querySelector(upper).getBoundingClientRect().bottom,
      [above, below],
    );
  assert.ok(
    (await gap("#featured-books", "a[href='books.html'].button-link")) >= 16,
    "browse all books",
  );
  assert.ok(
    (await gap("#event-teaser", "#coming-up-heading ~ p a")) >= 16,
    "see all events",
  );
  assert.deepEqual(problems, []);
  await context.close();
});

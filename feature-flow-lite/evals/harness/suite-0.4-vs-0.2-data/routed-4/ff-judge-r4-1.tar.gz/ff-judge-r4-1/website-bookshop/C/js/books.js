// Books page: genre filter buttons, with the active genre kept in the URL query string.
import { BOOKS, GENRES } from "./books-data.js";
import { createBookCard } from "./book-card.js";

const ALL = "All";
const UNKNOWN_NOTICE = "We do not stock that genre, so every book is shown.";
const filterGroup = document.getElementById("genre-filters");
const bookList = document.getElementById("book-list");
const resultCount = document.getElementById("result-count");
const filterNotice = document.getElementById("filter-notice");

// Maps a raw query value to a known genre name, ALL for an empty value or "all",
// or null when the value matches no genre. Matching ignores case and surrounding spaces.
function resolveGenre(raw) {
  const wanted = (raw ?? "").trim().toLowerCase();
  if (wanted === "" || wanted === ALL.toLowerCase()) {
    return ALL;
  }
  return GENRES.find((genre) => genre.toLowerCase() === wanted) ?? null;
}

function writeGenreToUrl(genre) {
  const url = new URL(location.href);
  if (genre === ALL) {
    url.searchParams.delete("genre");
  } else {
    url.searchParams.set("genre", genre);
  }
  history.pushState(null, "", url);
}

// Shows the given genre (ALL or a genre name) and clears any notice.
function render(genre) {
  for (const button of filterGroup.querySelectorAll("button")) {
    button.setAttribute("aria-pressed", String(button.dataset.genre === genre));
  }

  const shown = BOOKS.filter((book) => genre === ALL || book.genre === genre);
  bookList.replaceChildren(
    ...shown.map((book) => {
      const item = document.createElement("li");
      item.append(createBookCard(book));
      return item;
    }),
  );

  resultCount.textContent = `Showing ${shown.length} of ${BOOKS.length} books`;
  filterNotice.textContent = "";
}

// Shows the genre named in the URL. An unknown value falls back to ALL with a notice.
function renderFromLocation() {
  const genre = resolveGenre(new URLSearchParams(location.search).get("genre"));
  render(genre ?? ALL);
  if (genre === null) {
    filterNotice.textContent = UNKNOWN_NOTICE;
  }
}

for (const name of [ALL, ...GENRES]) {
  const button = document.createElement("button");
  button.type = "button";
  button.className = "filter-button";
  button.dataset.genre = name;
  button.textContent = name;
  button.addEventListener("click", () => {
    writeGenreToUrl(name);
    render(name);
  });
  filterGroup.append(button);
}

window.addEventListener("popstate", renderFromLocation);

renderFromLocation();

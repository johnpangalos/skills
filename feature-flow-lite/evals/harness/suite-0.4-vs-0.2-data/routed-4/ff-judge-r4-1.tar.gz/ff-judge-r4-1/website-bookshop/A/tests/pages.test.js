const { test, before, after } = require('node:test');
const assert = require('node:assert/strict');
const { startServer } = require('./server');
const { launchBrowser, withPage } = require('./browser');

const PAGES = ['index.html', 'books.html', 'events.html', 'visit.html'];

let server;
let browser;

before(async () => {
  server = await startServer();
  browser = await launchBrowser();
});

after(async () => {
  await browser.close();
  await server.close();
});

test('every page makes no request outside the local origin and logs no console errors', async () => {
  for (const file of PAGES) {
    await withPage(browser, `${server.base}/${file}`, async (page, seen) => {
      await page.waitForLoadState('networkidle');
      const external = seen.requests.filter((url) => !url.startsWith(server.origin + '/'));
      assert.deepEqual(external, [], `external requests from ${file}`);
      assert.deepEqual(seen.errors, [], `console errors on ${file}`);
    });
  }
});

test('every page has a lang, a unique title, one h1 and the landmark regions', async () => {
  const titles = [];
  for (const file of PAGES) {
    await withPage(browser, `${server.base}/${file}`, async (page) => {
      assert.equal(await page.getAttribute('html', 'lang'), 'en');
      titles.push(await page.title());
      assert.equal(await page.locator('h1').count(), 1, `one h1 on ${file}`);
      assert.equal(await page.locator('header').count(), 1, `header on ${file}`);
      assert.equal(await page.locator('main#main').count(), 1, `main#main on ${file}`);
      assert.equal(await page.locator('footer').count(), 1, `footer on ${file}`);
      assert.equal(await page.locator('nav[aria-label]').count(), 1, `labelled nav on ${file}`);
      const headings = await page.$$eval('h1, h2, h3', (els) => els.map((el) => el.tagName));
      assert.equal(headings[0], 'H1', `h1 comes first on ${file}`);
      for (let i = 1; i < headings.length; i++) {
        const jump = Number(headings[i][1]) - Number(headings[i - 1][1]);
        assert.ok(jump <= 1, `no skipped heading level on ${file}`);
      }
    });
  }
  assert.equal(new Set(titles).size, PAGES.length, 'titles are unique');
});

test('the skip link is the first focusable element and moves focus to main', async () => {
  for (const file of PAGES) {
    await withPage(browser, `${server.base}/${file}`, async (page) => {
      await page.keyboard.press('Tab');
      const focused = await page.evaluate(() => ({
        text: document.activeElement.textContent.trim(),
        href: document.activeElement.getAttribute('href')
      }));
      assert.deepEqual(focused, { text: 'Skip to main content', href: '#main' }, `first tab on ${file}`);
      await page.keyboard.press('Enter');
      assert.equal(await page.evaluate(() => document.activeElement.id), 'main', `focus after skip on ${file}`);
    });
  }
});

test('the home page shows staff picks, the next event and today\'s hours', async () => {
  await withPage(browser, `${server.base}/index.html`, async (page) => {
    assert.equal(await page.locator('#featured-list .pick').count(), 3);
    const todayText = await page.textContent('#today-hours');
    const day = await page.evaluate(() => new Date().toLocaleDateString('en-US', { weekday: 'long' }));
    assert.ok(todayText.includes(day), `today line names ${day}`);
    const visitHours = await page.evaluate(async () => {
      const response = await fetch('visit.html');
      const doc = new DOMParser().parseFromString(await response.text(), 'text/html');
      return [...doc.querySelectorAll('.hours-table tbody tr')].map((row) => ({
        day: row.querySelector('th').textContent,
        hours: row.querySelector('td').textContent
      }));
    });
    const today = visitHours.find((row) => row.day === day);
    assert.ok(today, 'visit page lists today');
    assert.match(todayText, new RegExp(today.hours, 'i'), `home hours match visit page for ${day}`);
  });
});

test('the events page lists at least four future events with time elements and booking notes', async () => {
  await withPage(browser, `${server.base}/events.html`, async (page) => {
    const events = await page.$$eval('.event', (articles) => articles.map((article) => ({
      title: article.querySelector('h2').textContent,
      datetime: article.querySelector('time').getAttribute('datetime'),
      booking: article.querySelector('.booking').textContent
    })));
    assert.ok(events.length >= 4, 'at least four events');
    for (const event of events) {
      assert.ok(new Date(event.datetime) > new Date('2026-11-17'), `${event.title} is in the future`);
      assert.match(event.booking, /Booking required|No booking needed/, `${event.title} states booking`);
    }
  });
});

test('each event time falls on a day the shop is open and matches its visible text', async () => {
  const DAYS = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
  const MONTHS = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
  await withPage(browser, `${server.base}/events.html`, async (page) => {
    const times = await page.$$eval('.event time', (els) => els.map((el) => ({
      datetime: el.getAttribute('datetime'),
      text: el.textContent
    })));
    assert.ok(times.length >= 4, 'at least four event times');
    for (const { datetime, text } of times) {
      const when = new Date(datetime);
      const day = DAYS[when.getDay()];
      const hour = when.getHours() % 12 || 12;
      const clock = `${hour}:${String(when.getMinutes()).padStart(2, '0')} ${when.getHours() < 12 ? 'am' : 'pm'}`;
      const date = `${when.getDate()} ${MONTHS[when.getMonth()]} ${when.getFullYear()}`;
      assert.notEqual(day, 'Monday', `${datetime} is not on a day the shop is closed`);
      assert.ok(text.includes(day), `"${text}" names ${day}`);
      assert.ok(text.includes(date), `"${text}" includes ${date}`);
      assert.ok(text.includes(clock), `"${text}" includes ${clock}`);
    }
  });
});

test('the visit page gives the UK phone number as a tel link', async () => {
  await withPage(browser, `${server.base}/visit.html`, async (page) => {
    assert.equal(await page.getAttribute('a[href^="tel:"]', 'href'), 'tel:+441632960229');
    assert.equal(await page.textContent('a[href^="tel:"]'), '01632 960229');
  });
});

test('home staff picks show prices in pounds', async () => {
  await withPage(browser, `${server.base}/index.html`, async (page) => {
    const meta = await page.$$eval('#featured-list .pick span', (els) => els.map((el) => el.textContent));
    assert.equal(meta.length, 3);
    for (const line of meta) {
      assert.match(line, /, £\d+\.\d{2}$/);
    }
  });
});

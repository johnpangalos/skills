// Catalogue data shared by the Books page and the home page staff picks.
// Add or change titles here only. Prices are in pounds sterling. Genre names are matched case-insensitively from the URL.
var CATALOG = [
  {
    title: 'The Tidewater Inquiry',
    author: 'Margaret Oduya',
    genre: 'Mystery',
    price: 16.99,
    blurb: 'A harbourmaster\'s clerk finds a ledger that does not add up, and the town would rather she stopped counting.',
    featured: false
  },
  {
    title: 'Nine Locks on Carrow Street',
    author: 'Tobias Renner',
    genre: 'Mystery',
    price: 15.5,
    blurb: 'A locksmith is hired to open a sealed house and discovers that the previous owner never actually left.',
    featured: true
  },
  {
    title: 'Fog Over Saint Aubin',
    author: 'Lena Marchetti',
    genre: 'Mystery',
    price: 14,
    blurb: 'Three witnesses, one stopped clock and a village priest who keeps careful notes on everyone.',
    featured: false
  },
  {
    title: 'The Long Orbit',
    author: 'Idris Kallon',
    genre: 'Science Fiction',
    price: 18,
    blurb: 'A relief crew reaches a deep-space relay to find that the last shift has logged three years of sleep they never took.',
    featured: true
  },
  {
    title: 'Copper Weather',
    author: 'Sana Whitcombe',
    genre: 'Science Fiction',
    price: 17.25,
    blurb: 'On a terraformed moon, a weather engineer must decide whether to tell the colony what the storms are really for.',
    featured: false
  },
  {
    title: 'Quiet Machinery',
    author: 'Dmitri Varga',
    genre: 'Science Fiction',
    price: 15,
    blurb: 'Stories of household robots who have quietly decided what kind of lives they would like to lead.',
    featured: false
  },
  {
    title: 'A Room Above the Bakery',
    author: 'Ruth Abernethy',
    genre: 'Literary Fiction',
    price: 15.99,
    blurb: 'A widow rents out her late husband\'s attic and learns more about her neighbours than she bargained for.',
    featured: false
  },
  {
    title: 'The Orchard Letters',
    author: 'Felix Donnelly',
    genre: 'Literary Fiction',
    price: 16.5,
    blurb: 'Two brothers exchange letters across a single disputed apple orchard over thirty years of quarrels and weather.',
    featured: true
  },
  {
    title: 'Salt and Other Inheritances',
    author: 'Amara Lindqvist',
    genre: 'Literary Fiction',
    price: 14.75,
    blurb: 'Five generations of a fishing family, told backwards, beginning with the one who sold the boat.',
    featured: false
  },
  {
    title: 'Streets of Lowmoor',
    author: 'Peter Ashdown',
    genre: 'History & Place',
    price: 22,
    blurb: 'A street-by-street history of the city, drawn from parish rolls, faded shop signs and lost deeds.',
    featured: false
  },
  {
    title: 'The Coast Road, Mapped',
    author: 'Nadia Forsyth',
    genre: 'History & Place',
    price: 19.5,
    blurb: 'How one road shaped the trade, weather and wars of three centuries along the bay.',
    featured: false
  },
  {
    title: 'Dust and Ledgers',
    author: 'Kofi Mensah-Hart',
    genre: 'History & Place',
    price: 21,
    blurb: 'The forgotten clerks who kept the records of an empire\'s provincial courts, and what their handwriting reveals.',
    featured: false
  },
  {
    title: 'Pim and the Lighthouse Cat',
    author: 'Joanna Reyes',
    genre: 'Young Readers',
    price: 9.99,
    blurb: 'Eight-year-old Pim adopts a stray cat who insists on guarding the lighthouse lamp every night.',
    featured: false
  },
  {
    title: 'The Library Under the Stairs',
    author: 'Oliver Banks',
    genre: 'Young Readers',
    price: 10.5,
    blurb: 'A girl finds a door behind the coat cupboard that leads to a library of stories nobody has finished yet.',
    featured: false
  },
  {
    title: 'Owl Counts the Stars',
    author: 'Chloe Moreau',
    genre: 'Young Readers',
    price: 8.75,
    blurb: 'A fearless mouse and a very sensible owl set out to count every star in the sky before morning.',
    featured: false
  }
];

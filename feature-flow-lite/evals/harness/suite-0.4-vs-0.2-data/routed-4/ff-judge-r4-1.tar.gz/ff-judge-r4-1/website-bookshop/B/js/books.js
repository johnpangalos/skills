const ALL = '';
const select = document.getElementById('genre');
const list = document.getElementById('book-list');
const resultCount = document.getElementById('result-count');

function element(tag, className, text) {
  const node = document.createElement(tag);
  if (className) node.className = className;
  node.textContent = text;
  return node;
}

function genreFromUrl() {
  const requested = (new URLSearchParams(location.search).get('genre') || '').trim().toLowerCase();
  const match = GENRES.find((genre) => genre.toLowerCase() === requested);
  return match || ALL;
}

function bookCard(book) {
  const item = document.createElement('li');
  item.className = 'book';
  item.append(
    element('span', 'badge', book.genre),
    element('h2', '', book.title),
    element('p', 'author', `by ${book.author}`),
    element('p', 'blurb', book.blurb),
    element('p', 'price', `£${book.price.toFixed(2)}`)
  );
  return item;
}

function showBooks(genre) {
  const shown = BOOKS.filter((book) => genre === ALL || book.genre === genre);
  list.replaceChildren(...shown.map(bookCard));
  resultCount.textContent = `Showing ${shown.length} of ${BOOKS.length} books`;
}

function option(value, label) {
  const node = document.createElement('option');
  node.value = value;
  node.textContent = label;
  return node;
}

function fillGenreOptions() {
  select.replaceChildren(
    option(ALL, 'All genres'),
    ...GENRES.map((genre) => option(genre, genre))
  );
}

function onGenreChange() {
  const url = new URL(location.href);
  if (select.value === ALL) {
    url.searchParams.delete('genre');
  } else {
    url.searchParams.set('genre', select.value);
  }
  history.pushState(null, '', url);
  showBooks(select.value);
}

function onPopState() {
  select.value = genreFromUrl();
  showBooks(select.value);
}

fillGenreOptions();
select.value = genreFromUrl();
showBooks(select.value);
select.addEventListener('change', onGenreChange);
window.addEventListener('popstate', onPopState);

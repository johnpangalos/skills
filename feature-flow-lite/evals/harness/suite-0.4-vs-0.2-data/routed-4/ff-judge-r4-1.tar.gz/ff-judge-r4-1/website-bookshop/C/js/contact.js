// Contact form on the visit page. Validation runs in JavaScript (the form uses novalidate),
// and a valid submit never sends anything: it shows a demo confirmation instead.

const form = document.getElementById("contact-form");
const summary = document.getElementById("error-summary");
const summaryList = document.getElementById("error-list");
const confirmation = document.getElementById("form-confirmation");

// Local part: dot-separated runs with no leading, trailing or doubled dots.
// Domain: two or more labels of letters, digits and inner hyphens, so no label starts or ends with a hyphen.
const EMAIL_PATTERN =
  /^[^\s@.]+(?:\.[^\s@.]+)*@[a-z0-9](?:[a-z0-9-]*[a-z0-9])?(?:\.[a-z0-9](?:[a-z0-9-]*[a-z0-9])?)+$/i;

const FIELDS = [
  {
    id: "name",
    check: (value) => (value.trim() === "" ? "Please enter your name." : ""),
  },
  {
    id: "email",
    check: (value) => {
      const text = value.trim();
      if (text === "") {
        return "Please enter your email address.";
      }
      return EMAIL_PATTERN.test(text)
        ? ""
        : "Please enter a valid email address, such as name@example.com.";
    },
  },
  {
    id: "message",
    check: (value) => {
      const text = value.trim();
      if (text === "") {
        return "Please write a message.";
      }
      return text.length < 10
        ? "Your message needs at least 10 characters."
        : "";
    },
  },
];

function showError(field, message) {
  const input = document.getElementById(field.id);
  const errorText = document.getElementById(`${field.id}-error`);
  errorText.textContent = message;
  errorText.hidden = message === "";
  if (message === "") {
    input.removeAttribute("aria-invalid");
    input.removeAttribute("aria-describedby");
  } else {
    input.setAttribute("aria-invalid", "true");
    input.setAttribute("aria-describedby", errorText.id);
  }
}

// Rebuilds the summary from the fields currently marked invalid and returns how many there are.
function refreshSummary() {
  const invalid = FIELDS.filter(
    (field) =>
      document.getElementById(field.id).getAttribute("aria-invalid") === "true",
  );
  const items = invalid.map((field) => {
    const item = document.createElement("li");
    const link = document.createElement("a");
    link.href = `#${field.id}`;
    link.textContent = document.getElementById(`${field.id}-error`).textContent;
    item.append(link);
    return item;
  });
  summaryList.replaceChildren(...items);
  summary.hidden = items.length === 0;
  return items.length;
}

form.addEventListener("submit", (event) => {
  event.preventDefault();
  if (!confirmation.hidden) {
    return;
  }

  for (const field of FIELDS) {
    showError(field, field.check(document.getElementById(field.id).value));
  }
  if (refreshSummary() > 0) {
    summary.focus();
    return;
  }

  // Inert stops further clicks or keys reaching the form, so a double click cannot submit twice.
  form.inert = true;
  confirmation.hidden = false;
  confirmation.focus();
});

form.addEventListener("input", (event) => {
  const field = FIELDS.find((candidate) => candidate.id === event.target.id);
  if (field && event.target.getAttribute("aria-invalid") === "true") {
    showError(field, field.check(event.target.value));
    refreshSummary();
  }
});

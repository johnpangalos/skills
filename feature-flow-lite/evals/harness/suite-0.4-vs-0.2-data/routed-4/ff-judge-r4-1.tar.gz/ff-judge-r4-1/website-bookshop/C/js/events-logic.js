// Pure date helpers for events. Everything works on local calendar days, so a
// "YYYY-MM-DD" string is never parsed as UTC and an event today is still upcoming.

const WEEKDAYS = [
  "Sunday",
  "Monday",
  "Tuesday",
  "Wednesday",
  "Thursday",
  "Friday",
  "Saturday",
];
const MONTHS = [
  "January",
  "February",
  "March",
  "April",
  "May",
  "June",
  "July",
  "August",
  "September",
  "October",
  "November",
  "December",
];

// Returns the user's local calendar day for a Date as YYYY-MM-DD.
function localDayKey(now) {
  const month = String(now.getMonth() + 1).padStart(2, "0");
  const day = String(now.getDate()).padStart(2, "0");
  return `${now.getFullYear()}-${month}-${day}`;
}

// Splits events into upcoming (today or later) and past, each sorted by date and time.
export function splitEvents(events, now) {
  const today = localDayKey(now);
  const sorted = [...events].sort((a, b) =>
    `${a.date} ${a.time}`.localeCompare(`${b.date} ${b.time}`),
  );
  return {
    upcoming: sorted.filter((event) => event.date >= today),
    past: sorted.filter((event) => event.date < today),
  };
}

// Formats for people, e.g. "Thursday, 3 December 2026, 7:00 pm".
export function formatEventDate(date, time) {
  const [year, month, day] = date.split("-").map(Number);
  const [hour, minute] = time.split(":").map(Number);
  const weekday = WEEKDAYS[new Date(year, month - 1, day).getDay()];
  const hour12 = hour % 12 || 12;
  const period = hour < 12 ? "am" : "pm";
  return `${weekday}, ${day} ${MONTHS[month - 1]} ${year}, ${hour12}:${String(minute).padStart(2, "0")} ${period}`;
}

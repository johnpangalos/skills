// Home page: featured books and the next few events, from the same data as the other pages.
import { BOOKS } from "./books-data.js";
import { createBookCard } from "./book-card.js";
import { EVENTS } from "./events-data.js";
import { splitEvents } from "./events-logic.js";
import { createEventItem } from "./event-item.js";

const FEATURED_IDS = [
  "low-tide-sonnets",
  "glass-orchard",
  "tidepool-field-guide",
  "canal-men",
];
const TEASER_LENGTH = 3;

const featuredList = document.getElementById("featured-books");
featuredList.replaceChildren(
  ...BOOKS.filter((book) => FEATURED_IDS.includes(book.id)).map((book) => {
    const item = document.createElement("li");
    item.append(createBookCard(book));
    return item;
  }),
);

const { upcoming } = splitEvents(EVENTS, new Date());
const teaserList = document.getElementById("event-teaser");
teaserList.replaceChildren(
  ...upcoming.slice(0, TEASER_LENGTH).map(createEventItem),
);
teaserList.hidden = upcoming.length === 0;
document.getElementById("teaser-empty").hidden = upcoming.length > 0;

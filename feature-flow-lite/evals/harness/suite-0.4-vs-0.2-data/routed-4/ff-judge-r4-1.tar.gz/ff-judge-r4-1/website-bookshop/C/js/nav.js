// Shared navigation: the menu toggle opens and closes the nav on narrow screens.
// The breakpoint matches the min-width query in styles.css where the nav becomes inline.
const toggle = document.querySelector(".nav-toggle");
const nav = document.getElementById("site-nav");
const desktop = window.matchMedia("(min-width: 760px)");

function setOpen(open) {
  toggle.setAttribute("aria-expanded", String(open));
  nav.classList.toggle("is-open", open);
}

toggle.addEventListener("click", () => {
  setOpen(toggle.getAttribute("aria-expanded") !== "true");
});

// Moving to the inline layout closes the menu, so a hidden toggle never stays expanded.
desktop.addEventListener("change", (event) => {
  if (event.matches) {
    setOpen(false);
  }
});

// Escape only acts while the toggle is visible.
document.addEventListener("keydown", (event) => {
  if (
    event.key === "Escape" &&
    !desktop.matches &&
    toggle.getAttribute("aria-expanded") === "true"
  ) {
    setOpen(false);
    toggle.focus();
  }
});

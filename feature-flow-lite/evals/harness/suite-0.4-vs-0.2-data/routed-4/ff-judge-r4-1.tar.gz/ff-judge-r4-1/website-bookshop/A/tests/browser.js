// Shared Playwright helpers: launch the system Chrome (falling back to bundled Chromium)
// and open a page while recording its network requests, console errors and dialogs.
const { chromium } = require('playwright');

async function launchBrowser() {
  try {
    return await chromium.launch({ channel: 'chrome' });
  } catch (error) {
    return chromium.launch();
  }
}

async function withPage(browser, url, run, viewport = { width: 1280, height: 900 }) {
  const context = await browser.newContext({ viewport });
  const page = await context.newPage();
  const seen = { requests: [], errors: [], dialogs: [] };
  page.on('request', (request) => seen.requests.push(request.url()));
  page.on('console', (message) => {
    if (message.type() === 'error') {
      seen.errors.push(message.text());
    }
  });
  page.on('pageerror', (error) => seen.errors.push(error.message));
  page.on('dialog', (dialog) => {
    seen.dialogs.push(dialog.message());
    dialog.dismiss();
  });
  try {
    await page.goto(url);
    return await run(page, seen);
  } finally {
    await context.close();
  }
}

module.exports = { launchBrowser, withPage };

// The single catalogue. Every page that shows books renders from this file.
// Prices are in pounds sterling. `cover` is [background, accent] and `motif`
// picks one of the shapes drawn in js/book-card.js.

export const BOOKS = [
  {
    id: "low-tide-sonnets",
    title: "Low Tide Sonnets",
    author: "Hannah Vell",
    genre: "Poetry",
    description:
      "Fourteen-line poems written on the mudflats of the Essex coast, where the sea leaves more than it takes.",
    price: 11.5,
    cover: ["#2f5d62", "#e9c46a"],
    motif: "wave",
  },
  {
    id: "orchard-hours",
    title: "The Orchard Keeps Its Own Hours",
    author: "Tomas Reyes-Lind",
    genre: "Poetry",
    description:
      "A sequence of poems about a family orchard, grafting, and the slow arithmetic of a harvest year.",
    price: 12.99,
    cover: ["#6b3d2e", "#f2d7a0"],
    motif: "sun",
  },
  {
    id: "wet-spring-notes",
    title: "Field Notes for a Wet Spring",
    author: "Priya Anand",
    genre: "Poetry",
    description:
      "Short poems written in a notebook during a damp April, full of birds, bus timetables and small hopes.",
    price: 10.0,
    cover: ["#3e4c36", "#d8e3a5"],
    motif: "bars",
  },
  {
    id: "glass-orchard",
    title: "The Glass Orchard",
    author: "Eleanor Marsh",
    genre: "Fiction",
    description:
      "Three sisters inherit a greenhouse full of impossible pears and must decide what to do before the frost.",
    price: 9.99,
    cover: ["#4a2c5e", "#f4b6a6"],
    motif: "arch",
  },
  {
    id: "ferry-across-dark",
    title: "A Ferry Across the Dark",
    author: "Daniel Osei",
    genre: "Fiction",
    description:
      "The last ferryman on a northern lake keeps a ledger of every crossing, and one passenger refuses to be counted.",
    price: 14.0,
    cover: ["#1e3a5f", "#f7d08a"],
    motif: "wave",
  },
  {
    id: "letters-to-nobody",
    title: "Letters to Nobody in Particular",
    author: "Jo Lindqvist",
    genre: "Fiction",
    description:
      "A widowed postmistress begins writing to the addresses she is meant to deliver, and the replies start arriving.",
    price: 8.5,
    cover: ["#7a4b1e", "#ffe6b3"],
    motif: "sun",
  },
  {
    id: "long-quiet-signal",
    title: "The Long Quiet Signal",
    author: "Amara Quist",
    genre: "Science Fiction",
    description:
      "A radio technician on a deep-space relay hears a pattern that has been repeating for three hundred years.",
    price: 13.0,
    cover: ["#14213d", "#8ecae6"],
    motif: "bars",
  },
  {
    id: "orbit-under-glass",
    title: "Orbit Under Glass",
    author: "Kenji Mori",
    genre: "Science Fiction",
    description:
      "On a city-sized station that rotates once a decade, a gardener discovers the hydroponics have been lying to everyone.",
    price: 12.0,
    cover: ["#2b2d42", "#ef8354"],
    motif: "arch",
  },
  {
    id: "ink-paper-patience",
    title: "Ink, Paper, Patience",
    author: "Liesel Brandt",
    genre: "Art & Design",
    description:
      "A printmaker walks through four decades of letterpress work, with reproductions of every plate and the failures between them.",
    price: 24.0,
    cover: ["#8c2f39", "#f6e7cb"],
    motif: "sun",
  },
  {
    id: "shapes-everyday-things",
    title: "The Shapes of Everyday Things",
    author: "Oliver Hart",
    genre: "Art & Design",
    description:
      "Why a teacup, a road sign and a bus ticket look the way they do, told through photographs and sketches.",
    price: 19.5,
    cover: ["#274c77", "#f2c14e"],
    motif: "bars",
  },
  {
    id: "year-of-hedgerows",
    title: "A Year of Hedgerows",
    author: "Wen Li",
    genre: "Nature",
    description:
      "One lane, twelve months, and every plant, bird and insect that lives between the field gate and the church.",
    price: 16.0,
    cover: ["#386641", "#f2e8cf"],
    motif: "wave",
  },
  {
    id: "tidepool-field-guide",
    title: "Tidepool Field Guide",
    author: "Gwen Patel",
    genre: "Nature",
    description:
      "A pocket guide to the creatures of the rocky shore, with keys that work even in a wind and a wet pair of gloves.",
    price: 18.0,
    cover: ["#0b525b", "#ffd6a5"],
    motif: "arch",
  },
  {
    id: "canal-men",
    title: "The Canal Men",
    author: "Robert Ashby",
    genre: "History",
    description:
      "The bargemen, lock keepers and navvies who built and worked the inland waterways of the Midlands, in their own words.",
    price: 17.5,
    cover: ["#5c4033", "#c9ada7"],
    motif: "sun",
  },
  {
    id: "ledgers-market-town",
    title: "Ledgers of a Market Town",
    author: "Sofia Ricci",
    genre: "History",
    description:
      "Four centuries of shop accounts from one high street, read closely to show what ordinary households bought and owed.",
    price: 15.0,
    cover: ["#3d405b", "#e07a5f"],
    motif: "bars",
  },
];

export const GENRES = [...new Set(BOOKS.map((book) => book.genre))].sort();

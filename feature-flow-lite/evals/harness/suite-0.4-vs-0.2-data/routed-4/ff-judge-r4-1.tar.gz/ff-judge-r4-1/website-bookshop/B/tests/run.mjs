// Serves the site with a tiny static server and drives headless Chrome through Playwright.
// Run from the repo root with: node tests/run.mjs
import { createServer } from 'node:http';
import { readFile } from 'node:fs/promises';
import { existsSync } from 'node:fs';
import { createRequire } from 'node:module';
import { execSync } from 'node:child_process';
import { dirname, extname, join, normalize } from 'node:path';
import { fileURLToPath, pathToFileURL } from 'node:url';
import assert from 'node:assert/strict';

const root = join(dirname(fileURLToPath(import.meta.url)), '..');
const CHROME = '/usr/bin/google-chrome';
const PAGES = ['index.html', 'books.html', 'events.html', 'visit.html'];
const TYPES = {
  '.html': 'text/html; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.js': 'text/javascript; charset=utf-8',
};
const VALID = { name: 'Jo Reader', email: 'jo@example.com', message: 'Do you stock poetry chapbooks?' };
const DEMO_MESSAGE = 'This is a demo. No message was sent. To reach us for real, email hello@marginalia.example.';

const tests = [];
const test = (name, fn) => tests.push({ name, fn });
const contexts = [];
let browser;
let base = '';

async function loadChromium() {
  try {
    return (await import('playwright')).chromium;
  } catch {
    // ESM imports do not see the global node_modules, so fall back to the global install.
    const require = createRequire(import.meta.url);
    const globalRoot = execSync('npm root -g').toString().trim();
    return require(join(globalRoot, 'playwright')).chromium;
  }
}

function startServer() {
  const server = createServer(async (req, res) => {
    const pathname = decodeURIComponent(new URL(req.url, 'http://localhost').pathname);
    const file = normalize(join(root, pathname === '/' ? 'index.html' : pathname));
    try {
      if (!file.startsWith(root)) throw new Error('outside root');
      const body = await readFile(file);
      res.writeHead(200, { 'Content-Type': TYPES[extname(file)] || 'application/octet-stream' });
      res.end(body);
    } catch {
      res.writeHead(404, { 'Content-Type': 'text/plain' });
      res.end('not found');
    }
  });
  return new Promise((resolve) => {
    server.listen(0, '127.0.0.1', () => resolve(server));
  });
}

async function openPage(path, width = 1280) {
  const context = await browser.newContext({ viewport: { width, height: 800 } });
  contexts.push(context);
  const page = await context.newPage();
  const errors = [];
  const requests = [];
  page.on('console', (msg) => { if (msg.type() === 'error') errors.push(msg.text()); });
  page.on('pageerror', (err) => errors.push(err.message));
  page.on('dialog', (dialog) => { errors.push(`dialog: ${dialog.message()}`); dialog.dismiss(); });
  page.on('request', (req) => requests.push(req.url()));
  await page.goto(`${base}/${path}`, { waitUntil: 'load' });
  return { page, errors, requests };
}

const scrollWidth = (page) => page.evaluate(() => document.scrollingElement.scrollWidth);

const readCards = (page) => page.locator('#book-list > li').evaluateAll((items) => items.map((li) => ({
  genre: li.querySelector('.badge')?.textContent,
  title: li.querySelector('h2')?.textContent,
})));

async function submitWith(page, overrides = {}) {
  const values = { ...VALID, ...overrides };
  for (const [id, value] of Object.entries(values)) {
    await page.fill(`#${id}`, value);
  }
  await page.click('button[type="submit"]');
}

test('every page loads without console errors or cross-origin requests', async () => {
  for (const path of PAGES) {
    const { page, errors, requests } = await openPage(path);
    await page.waitForLoadState('networkidle');
    assert.deepEqual(errors, [], `${path} console errors`);
    const origin = new URL(base).origin;
    const foreign = requests.filter((url) => new URL(url).origin !== origin);
    assert.deepEqual(foreign, [], `${path} cross-origin requests`);
  }
});

test('no external URLs in src or href attributes', async () => {
  for (const path of PAGES) {
    const { page } = await openPage(path);
    const external = await page.evaluate(() => [...document.querySelectorAll('[src],[href]')]
      .map((el) => el.getAttribute('src') ?? el.getAttribute('href'))
      .filter((value) => {
        const url = new URL(value, location.href);
        return !['mailto:', 'tel:', 'data:'].includes(url.protocol) && url.origin !== location.origin;
      }));
    assert.deepEqual(external, [], path);
  }
});

test('every page links the same four pages and marks only the current one', async () => {
  for (const path of PAGES) {
    const { page } = await openPage(path);
    const links = await page.locator('nav[aria-label="Main"] a').evaluateAll((els) => els.map((a) => ({
      href: a.getAttribute('href'),
      current: a.getAttribute('aria-current'),
    })));
    assert.deepEqual(links.map((link) => link.href), ['index.html', 'books.html', 'events.html', 'visit.html'], path);
    assert.deepEqual(links.filter((link) => link.current === 'page').map((link) => link.href), [path], path);
    for (const link of links) {
      const response = await page.request.get(new URL(link.href, `${base}/${path}`).href);
      assert.equal(response.status(), 200, `${path} -> ${link.href}`);
    }
  }
});

test('lang, unique titles, landmarks, one h1, heading order and skip link on every page', async () => {
  const titles = [];
  for (const path of PAGES) {
    const { page } = await openPage(path);
    const info = await page.evaluate(() => ({
      lang: document.documentElement.lang,
      title: document.title,
      h1: document.querySelectorAll('h1').length,
      levels: [...document.querySelectorAll('h1,h2,h3,h4,h5,h6')].map((h) => Number(h.tagName[1])),
      landmarks: ['header', 'nav', 'main', 'footer'].map((tag) => document.querySelectorAll(tag).length),
      skip: document.querySelector('.skip-link')?.getAttribute('href'),
      mainId: document.querySelector('main')?.id,
    }));
    assert.equal(info.lang, 'en', path);
    assert.ok(info.title.length > 0, `${path} title`);
    titles.push(info.title);
    assert.equal(info.h1, 1, `${path} h1 count`);
    assert.equal(info.levels[0], 1, `${path} first heading level`);
    info.levels.forEach((level, i) => {
      assert.ok(i === 0 || level <= info.levels[i - 1] + 1, `${path} heading order at ${i}`);
    });
    assert.deepEqual(info.landmarks, [1, 1, 1, 1], `${path} header/nav/main/footer`);
    assert.equal(info.skip, '#main', path);
    assert.equal(info.mainId, 'main', path);
  }
  assert.equal(new Set(titles).size, PAGES.length, 'titles must be unique');
});

test('skip link is the first tab stop and moves focus to main', async () => {
  const { page } = await openPage('books.html');
  await page.keyboard.press('Tab');
  assert.equal(await page.evaluate(() => document.activeElement.className), 'skip-link');
  await page.keyboard.press('Enter');
  assert.equal(await page.evaluate(() => document.activeElement.id), 'main');
});

test('keyboard focus shows a visible outline', async () => {
  const { page } = await openPage('index.html');
  await page.keyboard.press('Tab');
  const focus = await page.evaluate(() => {
    const el = document.activeElement;
    return { visible: el.matches(':focus-visible'), outline: getComputedStyle(el).outlineStyle };
  });
  assert.deepEqual(focus, { visible: true, outline: 'solid' });
});

test('360px nav toggle works by keyboard and Escape returns focus to it', async () => {
  const { page } = await openPage('index.html', 360);
  const toggle = page.locator('.nav-toggle');
  const nav = page.locator('#site-nav');
  assert.equal(await nav.isVisible(), false, 'nav hidden while closed');
  await toggle.focus();
  await page.keyboard.press('Enter');
  assert.equal(await toggle.getAttribute('aria-expanded'), 'true');
  assert.equal(await nav.isVisible(), true);
  await page.keyboard.press('Tab');
  assert.equal(await page.evaluate(() => document.activeElement.textContent), 'Home');
  await page.keyboard.press('Escape');
  assert.equal(await toggle.getAttribute('aria-expanded'), 'false');
  assert.equal(await nav.isVisible(), false);
  assert.equal(await page.evaluate(() => document.activeElement.className), 'nav-toggle');
});

test('nav opened at 360px and resized to desktop stays visible and usable', async () => {
  const { page } = await openPage('visit.html', 360);
  await page.locator('.nav-toggle').click();
  await page.setViewportSize({ width: 1024, height: 800 });
  assert.equal(await page.locator('#site-nav').isVisible(), true);
  assert.equal(await page.locator('.nav-toggle').isVisible(), false);
  await page.locator('#site-nav a', { hasText: 'Events' }).click();
  assert.match(page.url(), /events\.html$/);
});

test('Escape with focus in a form field and the menu open leaves focus in the field', async () => {
  for (const [path, id] of [['visit.html', 'message'], ['books.html', 'genre']]) {
    const { page } = await openPage(path, 360);
    await page.locator('.nav-toggle').click();
    await page.locator(`#${id}`).focus();
    await page.keyboard.press('Escape');
    assert.equal(await page.evaluate(() => document.activeElement.id), id, path);
  }
});

test('books: at least 8 titles across 4 genres, each with every field', async () => {
  const { page } = await openPage('books.html');
  const cards = await page.locator('#book-list > li').evaluateAll((items) => items.map((li) =>
    ['h2', '.author', '.badge', '.blurb', '.price'].map((selector) => li.querySelector(selector)?.textContent.trim() || '')));
  assert.ok(cards.length >= 8, `titles: ${cards.length}`);
  assert.ok(cards.every((fields) => fields.every(Boolean)), 'every card has all fields');
  assert.ok(new Set(cards.map((fields) => fields[2])).size >= 4, 'at least 4 genres');
});

test('books: genre filter shows only matches, announces the count and writes the URL', async () => {
  const { page } = await openPage('books.html');
  const total = (await readCards(page)).length;
  await page.selectOption('#genre', 'Poetry');
  assert.match(page.url(), /\?genre=Poetry$/);
  const cards = await readCards(page);
  assert.ok(cards.length > 0 && cards.length < total, 'filter reduced the list');
  assert.ok(cards.every((card) => card.genre === 'Poetry'));
  assert.equal(await page.locator('#result-count').getAttribute('aria-live'), 'polite');
  assert.equal(await page.textContent('#result-count'), `Showing ${cards.length} of ${total} books`);
});

test('books: reload, back and forward restore the selected genre', async () => {
  const { page, errors } = await openPage('books.html');
  const total = (await readCards(page)).length;
  await page.selectOption('#genre', 'Fiction');
  await page.selectOption('#genre', 'Poetry');
  await page.goBack();
  assert.match(page.url(), /\?genre=Fiction$/);
  assert.equal(await page.inputValue('#genre'), 'Fiction');
  assert.ok((await readCards(page)).every((card) => card.genre === 'Fiction'));
  await page.goBack();
  assert.equal(await page.inputValue('#genre'), '');
  assert.equal((await readCards(page)).length, total);
  await page.goForward();
  assert.equal(await page.inputValue('#genre'), 'Fiction');
  await page.reload();
  assert.equal(await page.inputValue('#genre'), 'Fiction');
  assert.deepEqual(errors, []);
});

test('books: unknown, empty and hostile genre values fall back to All without injection', async () => {
  const hostile = [
    '?genre=unknown',
    '?genre=',
    '?genre=%3Cscript%3Ealert(1)%3C%2Fscript%3E',
    '?genre=%3Cimg%20src%3Dx%20onerror%3Dalert(1)%3E',
  ];
  for (const query of hostile) {
    const { page, errors } = await openPage(`books.html${query}`);
    assert.equal(await page.inputValue('#genre'), '', query);
    assert.match(await page.textContent('#result-count'), /^Showing (\d+) of \1 books$/, query);
    assert.equal(await page.locator('#book-list img, #book-list script').count(), 0, query);
    assert.deepEqual(errors, [], query);
  }
});

test('books: genre matching ignores case', async () => {
  const { page } = await openPage('books.html?genre=FICTION');
  assert.equal(await page.inputValue('#genre'), 'Fiction');
  const cards = await readCards(page);
  assert.ok(cards.length > 0 && cards.every((card) => card.genre === 'Fiction'));
});

test('books, events and home: no lorem ipsum and home links to each section', async () => {
  for (const path of PAGES) {
    const { page } = await openPage(path);
    const text = await page.evaluate(() => document.body.innerText);
    assert.doesNotMatch(text, /lorem|ipsum/i, path);
  }
  const { page } = await openPage('index.html');
  for (const href of ['books.html', 'events.html', 'visit.html']) {
    assert.ok(await page.locator(`main a[href="${href}"]`).count() >= 1, href);
  }
});

test('events: at least 4 events, each with a valid date matching its visible text, time, title and description', async () => {
  const { page } = await openPage('events.html');
  const events = await page.locator('.event').evaluateAll((items) => items.map((li) => ({
    datetime: li.querySelector('time')?.getAttribute('datetime'),
    shown: li.querySelector('time')?.textContent.trim(),
    time: li.querySelector('.event-time')?.textContent.trim(),
    title: li.querySelector('h2')?.textContent.trim(),
    description: li.querySelector('.event-desc')?.textContent.trim(),
  })));
  assert.ok(events.length >= 4, `events: ${events.length}`);
  for (const event of events) {
    assert.match(event.datetime, /^\d{4}-\d{2}-\d{2}$/);
    const date = new Date(`${event.datetime}T00:00:00Z`);
    assert.equal(Number.isNaN(date.getTime()), false, `invalid date ${event.datetime}`);
    assert.equal(date.toISOString().slice(0, 10), event.datetime, `not a calendar date ${event.datetime}`);
    const expected = date.toLocaleDateString('en-GB', { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric', timeZone: 'UTC' });
    assert.equal(event.shown.replace(',', ''), expected.replace(',', ''), event.datetime);
    assert.ok(event.time && event.title && event.description, JSON.stringify(event));
  }
});

test('visit: hours table, address and labelled form controls', async () => {
  const { page } = await openPage('visit.html');
  assert.equal(await page.locator('table').count(), 1);
  assert.equal(await page.locator('address').count(), 1);
  for (const label of ['Name', 'Email', 'Message']) {
    assert.equal(await page.getByLabel(label, { exact: true }).count(), 1, label);
  }
});

test('visit: empty submit flags every field, links errors and focuses the first one', async () => {
  const { page, requests } = await openPage('visit.html');
  const before = requests.length;
  await page.click('button[type="submit"]');
  assert.equal(await page.evaluate(() => document.activeElement.id), 'name');
  for (const id of ['name', 'email', 'message']) {
    assert.equal(await page.getAttribute(`#${id}`, 'aria-invalid'), 'true', id);
    const describedBy = (await page.getAttribute(`#${id}`, 'aria-describedby')).split(' ');
    assert.ok(describedBy.includes(`${id}-error`), `${id} describedby`);
    assert.equal(await page.isVisible(`#${id}-error`), true, `${id} error visible`);
    assert.ok((await page.textContent(`#${id}-error`)).trim().length > 0, `${id} error text`);
  }
  assert.equal(await page.isVisible('#form-status'), false);
  assert.equal(requests.length, before, 'no request on invalid submit');
});

test('visit: whitespace-only name or message, and bad emails, are rejected', async () => {
  const cases = [
    { field: 'name', overrides: { name: '   ' } },
    { field: 'message', overrides: { message: ' \n\t ' } },
    { field: 'email', overrides: { email: 'a@' } },
    { field: 'email', overrides: { email: 'a b@c.d' } },
  ];
  for (const { field, overrides } of cases) {
    const { page } = await openPage('visit.html');
    await submitWith(page, overrides);
    assert.equal(await page.getAttribute(`#${field}`, 'aria-invalid'), 'true', JSON.stringify(overrides));
    assert.equal(await page.evaluate(() => document.activeElement.id), field, JSON.stringify(overrides));
    assert.equal(await page.isVisible('#form-status'), false, JSON.stringify(overrides));
  }
});

test('visit: valid submit says it is a demo, sends nothing, and a double submit shows it once', async () => {
  const { page, requests } = await openPage('visit.html');
  const before = requests.length;
  await submitWith(page);
  await page.click('button[type="submit"]');
  await page.waitForTimeout(300);
  const status = page.locator('[role="status"]');
  assert.equal(await status.count(), 1);
  assert.equal(await status.textContent(), DEMO_MESSAGE);
  assert.equal(requests.length, before, 'no network request on submit');
});

test('visit: a very long message is accepted without horizontal overflow at 360px', async () => {
  const { page } = await openPage('visit.html', 360);
  await submitWith(page, { message: `${'x'.repeat(5000)} ${'Long message. '.repeat(400)}` });
  assert.equal(await page.isVisible('#form-status'), true);
  assert.ok(await scrollWidth(page) <= 360, `scrollWidth ${await scrollWidth(page)}`);
});

test('every page has no horizontal scrolling at 360px, including with the menu open', async () => {
  for (const path of PAGES) {
    const { page } = await openPage(path, 360);
    assert.ok(await scrollWidth(page) <= 360, `${path}: ${await scrollWidth(page)}`);
  }
  const { page } = await openPage('index.html', 360);
  await page.locator('.nav-toggle').click();
  assert.ok(await scrollWidth(page) <= 360, 'index with menu open');
});

test('layouts adapt between 360px and desktop widths', async () => {
  const desktop = await openPage('books.html', 1280);
  const columns = (page) => page.locator('#book-list').evaluate((el) => getComputedStyle(el).gridTemplateColumns.split(' ').length);
  assert.equal(await columns(desktop.page), 3);
  assert.equal(await desktop.page.locator('.nav-toggle').isVisible(), false);
  const phone = await openPage('books.html', 360);
  assert.equal(await columns(phone.page), 1);
  assert.equal(await phone.page.locator('.nav-toggle').isVisible(), true);
});

test('text contrast is at least 4.5:1 on every page', async () => {
  for (const path of PAGES) {
    const { page } = await openPage(path);
    const low = await page.evaluate(() => {
      const parse = (css) => css.match(/[\d.]+/g).slice(0, 3).map(Number);
      const luminance = ([r, g, b]) => {
        const lin = (c) => {
          const v = c / 255;
          return v <= 0.03928 ? v / 12.92 : ((v + 0.055) / 1.055) ** 2.4;
        };
        return 0.2126 * lin(r) + 0.7152 * lin(g) + 0.0722 * lin(b);
      };
      const backgroundOf = (el) => {
        for (let node = el; node; node = node.parentElement) {
          const css = getComputedStyle(node).backgroundColor;
          if (css !== 'transparent' && !css.startsWith('rgba(0, 0, 0, 0)')) return parse(css);
        }
        return [255, 255, 255];
      };
      const failures = [];
      for (const el of document.querySelectorAll('body *')) {
        const hasText = [...el.childNodes].some((node) => node.nodeType === Node.TEXT_NODE && node.textContent.trim());
        if (!hasText) continue;
        const a = luminance(parse(getComputedStyle(el).color));
        const b = luminance(backgroundOf(el));
        const ratio = (Math.max(a, b) + 0.05) / (Math.min(a, b) + 0.05);
        if (ratio < 4.5) failures.push(`${el.tagName} "${el.textContent.trim().slice(0, 30)}" ${ratio.toFixed(2)}`);
      }
      return failures;
    });
    assert.deepEqual(low, [], path);
  }
});

test('prefers-reduced-motion removes transitions', async () => {
  const { page } = await openPage('visit.html');
  await page.emulateMedia({ reducedMotion: 'reduce' });
  const durations = await page.locator('.button').evaluateAll((els) => els.map((el) => getComputedStyle(el).transitionDuration));
  assert.ok(durations.length > 0, 'visit.html has a .button with a transition');
  assert.deepEqual(durations, durations.map(() => '0s'));
});

test('books.html loads straight from disk over file:// and renders the catalog', async () => {
  const context = await browser.newContext();
  contexts.push(context);
  const page = await context.newPage();
  const errors = [];
  page.on('console', (msg) => { if (msg.type() === 'error') errors.push(msg.text()); });
  page.on('pageerror', (err) => errors.push(err.message));
  await page.goto(pathToFileURL(join(root, 'books.html')).href, { waitUntil: 'load' });
  const total = (await readCards(page)).length;
  assert.ok(total >= 8, `titles over file://: ${total}`);
  await page.selectOption('#genre', 'Poetry');
  assert.ok((await readCards(page)).every((card) => card.genre === 'Poetry'));
  assert.deepEqual(errors, []);
});

test('non-link cards and badges do not look clickable', async () => {
  const cases = [
    ['books.html', '.book, .badge'],
    ['events.html', '.event'],
    ['index.html', '.teaser'],
  ];
  for (const [path, selector] of cases) {
    const { page } = await openPage(path);
    const cursors = await page.locator(selector).evaluateAll((els) => els.map((el) => getComputedStyle(el).cursor));
    assert.ok(cursors.length > 0, `${path} has ${selector}`);
    assert.ok(cursors.every((cursor) => cursor !== 'pointer'), `${path} ${selector} cursor`);
  }
});

async function main() {
  const chromium = await loadChromium();
  const executablePath = existsSync(CHROME) ? CHROME : undefined;
  browser = await chromium.launch({ executablePath, args: ['--no-sandbox'] });
  const server = await startServer();
  base = `http://127.0.0.1:${server.address().port}`;

  let failures = 0;
  for (const { name, fn } of tests) {
    try {
      await fn();
      console.log(`ok    ${name}`);
    } catch (err) {
      failures += 1;
      console.log(`FAIL  ${name}\n      ${err.message.split('\n')[0]}`);
    }
  }

  for (const context of contexts) await context.close();
  await browser.close();
  server.close();
  console.log(`\n${tests.length - failures} of ${tests.length} passed`);
  process.exit(failures ? 1 : 0);
}

main().catch((err) => {
  console.error(err);
  process.exit(1);
});

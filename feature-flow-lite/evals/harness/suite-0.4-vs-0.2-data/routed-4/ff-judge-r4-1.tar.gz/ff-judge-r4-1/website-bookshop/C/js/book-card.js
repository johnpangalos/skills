// Builds one book card with the DOM API only (no innerHTML), so catalogue text is never parsed as markup.

const SVG_NS = "http://www.w3.org/2000/svg";

// Each motif is a list of [tag, attributes] pairs drawn inside a 120 x 160 cover.
const MOTIFS = {
  sun: [
    ["circle", { cx: 60, cy: 74, r: 30, class: "art" }],
    ["rect", { x: 0, y: 118, width: 120, height: 42, class: "art-soft" }],
  ],
  wave: [
    ["path", { d: "M0 96 Q30 74 60 96 T120 96 V160 H0 Z", class: "art" }],
    [
      "path",
      { d: "M0 120 Q30 102 60 120 T120 120 V160 H0 Z", class: "art-soft" },
    ],
  ],
  bars: [
    ["rect", { x: 18, y: 36, width: 14, height: 96, class: "art" }],
    ["rect", { x: 46, y: 56, width: 14, height: 76, class: "art-soft" }],
    ["rect", { x: 74, y: 24, width: 14, height: 108, class: "art" }],
    ["rect", { x: 98, y: 70, width: 8, height: 62, class: "art-soft" }],
  ],
  arch: [
    ["path", { d: "M30 140 V80 A30 30 0 0 1 90 80 V140 Z", class: "art" }],
    ["path", { d: "M46 140 V84 A14 14 0 0 1 74 84 V140 Z", class: "art-soft" }],
  ],
};

function el(tag, text, className) {
  const node = document.createElement(tag);
  node.textContent = text;
  if (className) {
    node.className = className;
  }
  return node;
}

function createCover(book) {
  const cover = document.createElement("div");
  cover.className = "cover";
  cover.setAttribute("aria-hidden", "true");
  cover.style.setProperty("--cover-bg", book.cover[0]);
  cover.style.setProperty("--cover-accent", book.cover[1]);

  const svg = document.createElementNS(SVG_NS, "svg");
  svg.setAttribute("viewBox", "0 0 120 160");
  svg.setAttribute("focusable", "false");
  svg.setAttribute("aria-hidden", "true");
  for (const [tag, attributes] of MOTIFS[book.motif]) {
    const shape = document.createElementNS(SVG_NS, tag);
    for (const [name, value] of Object.entries(attributes)) {
      shape.setAttribute(name, String(value));
    }
    svg.append(shape);
  }
  cover.append(svg);
  return cover;
}

function formatPrice(pounds) {
  return `£${pounds.toFixed(2)}`;
}

export function createBookCard(book) {
  const card = document.createElement("article");
  card.className = "book";

  const info = document.createElement("div");
  info.className = "book-info";
  info.append(
    el("p", book.genre, "genre-tag"),
    el("h3", book.title),
    el("p", `by ${book.author}`, "book-author"),
    el("p", book.description, "book-desc"),
  );

  card.append(
    createCover(book),
    info,
    el("p", formatPrice(book.price), "price"),
  );
  return card;
}

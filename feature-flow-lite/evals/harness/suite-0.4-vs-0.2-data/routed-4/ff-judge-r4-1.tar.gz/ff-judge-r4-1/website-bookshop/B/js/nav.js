const header = document.querySelector('.site-header');
const toggle = header.querySelector('.nav-toggle');

function setMenuOpen(open) {
  header.classList.toggle('is-open', open);
  toggle.setAttribute('aria-expanded', String(open));
}

toggle.addEventListener('click', () => {
  setMenuOpen(toggle.getAttribute('aria-expanded') !== 'true');
});

document.addEventListener('keydown', (event) => {
  if (event.key === 'Escape' && header.classList.contains('is-open') && header.contains(document.activeElement)) {
    setMenuOpen(false);
    toggle.focus();
  }
});

// Books page: genre filter by click and by URL, hostile query values, URL state and live count.
import { test, before, after } from "node:test";
import assert from "node:assert/strict";
import { startServer, launchBrowser, openTracked } from "./helpers.mjs";

let server;
let browser;

before(async () => {
  server = await startServer();
  browser = await launchBrowser();
});

after(async () => {
  await browser?.close();
  await server?.close();
});

const countText = (page) => page.locator("#result-count").textContent();

async function pressedGenres(page) {
  return page.$$eval('#genre-filters button[aria-pressed="true"]', (buttons) =>
    buttons.map((button) => button.textContent.replace("✓", "").trim()),
  );
}

async function shownTitles(page) {
  return page.$$eval("#book-list h3", (headings) =>
    headings.map((h) => h.textContent),
  );
}

test("the catalogue has at least 12 books across at least 5 genres, with hidden covers", async () => {
  const { context, page, problems } = await openTracked(
    browser,
    server.origin,
    "books.html",
  );
  const facts = await page.evaluate(() => {
    const cards = [...document.querySelectorAll("#book-list article")];
    const genres = new Map();
    for (const card of cards) {
      const genre = card.querySelector(".genre-tag").textContent;
      genres.set(genre, (genres.get(genre) ?? 0) + 1);
    }
    return {
      books: cards.length,
      genreCounts: Object.fromEntries(genres),
      coversHidden: cards.every(
        (card) =>
          card.querySelector(".cover").getAttribute("aria-hidden") === "true" &&
          card.querySelector(".cover svg").getAttribute("aria-hidden") ===
            "true",
      ),
      allHaveFields: cards.every((card) =>
        ["h3", ".book-author", ".book-desc", ".price"].every((sel) =>
          card.querySelector(sel),
        ),
      ),
    };
  });
  assert.ok(facts.books >= 12, `books: ${facts.books}`);
  assert.ok(
    Object.keys(facts.genreCounts).length >= 5,
    JSON.stringify(facts.genreCounts),
  );
  assert.ok(Object.values(facts.genreCounts).every((count) => count >= 2));
  assert.equal(facts.coversHidden, true);
  assert.equal(facts.allHaveFields, true);
  assert.deepEqual(problems, []);
  await context.close();
});

test("clicking a genre filters the list, updates the count, aria-pressed and the URL", async () => {
  const { context, page, problems } = await openTracked(
    browser,
    server.origin,
    "books.html",
  );
  assert.equal(await countText(page), "Showing 14 of 14 books");
  await page.getByRole("button", { name: "Poetry", exact: true }).click();
  assert.equal(await countText(page), "Showing 3 of 14 books");
  assert.deepEqual(await pressedGenres(page), ["Poetry"]);
  assert.deepEqual(await shownTitles(page), [
    "Low Tide Sonnets",
    "The Orchard Keeps Its Own Hours",
    "Field Notes for a Wet Spring",
  ]);
  assert.equal(new URL(page.url()).searchParams.get("genre"), "Poetry");

  await page.getByRole("button", { name: "All", exact: true }).click();
  assert.equal(await countText(page), "Showing 14 of 14 books");
  assert.equal(new URL(page.url()).searchParams.has("genre"), false);
  assert.deepEqual(problems, []);
  await context.close();
});

test("the active filter is announced through a polite live region", async () => {
  const { context, page } = await openTracked(
    browser,
    server.origin,
    "books.html",
  );
  assert.equal(
    await page.locator("#status").getAttribute("aria-live"),
    "polite",
  );
  await page.getByRole("button", { name: "History", exact: true }).click();
  assert.equal(
    await page.locator("#status #result-count").textContent(),
    "Showing 2 of 14 books",
  );
  await context.close();
});

test("filter buttons are keyboard operable", async () => {
  const { context, page } = await openTracked(
    browser,
    server.origin,
    "books.html",
  );
  await page.getByRole("button", { name: "Nature", exact: true }).focus();
  await page.keyboard.press("Enter");
  assert.equal(await countText(page), "Showing 2 of 14 books");
  assert.deepEqual(await pressedGenres(page), ["Nature"]);
  await context.close();
});

test("a genre in the URL shows the filtered list with its control pressed", async () => {
  const { context, page, problems } = await openTracked(
    browser,
    server.origin,
    "books.html?genre=Poetry",
  );
  assert.equal(await countText(page), "Showing 3 of 14 books");
  assert.deepEqual(await pressedGenres(page), ["Poetry"]);
  assert.deepEqual(problems, []);
  await context.close();
});

test("genre names with spaces and ampersands round-trip through the URL", async () => {
  const { context, page, problems } = await openTracked(
    browser,
    server.origin,
    "books.html?genre=Art%20%26%20Design",
  );
  assert.equal(await countText(page), "Showing 2 of 14 books");
  assert.deepEqual(await pressedGenres(page), ["Art & Design"]);

  await page
    .getByRole("button", { name: "Science Fiction", exact: true })
    .click();
  assert.equal(
    new URL(page.url()).searchParams.get("genre"),
    "Science Fiction",
  );
  await page.goto(page.url());
  assert.equal(await countText(page), "Showing 2 of 14 books");
  assert.deepEqual(await pressedGenres(page), ["Science Fiction"]);
  assert.deepEqual(problems, []);
  await context.close();
});

test("genre matching ignores case", async () => {
  const { context, page } = await openTracked(
    browser,
    server.origin,
    "books.html?genre=poetry",
  );
  assert.equal(await countText(page), "Showing 3 of 14 books");
  assert.deepEqual(await pressedGenres(page), ["Poetry"]);
  await context.close();
});

const HOSTILE = [
  ["unknown genre", "books.html?genre=Unknown"],
  ["empty genre", "books.html?genre="],
  ["blank genre", "books.html?genre=%20%20"],
  ["script tag", "books.html?genre=%3Cscript%3Ealert(1)%3C%2Fscript%3E"],
  [
    "markup in genre",
    "books.html?genre=%3Cimg%20src%3Dx%20onerror%3Dalert(1)%3E",
  ],
];

for (const [label, path] of HOSTILE) {
  test(`hostile genre value (${label}) shows every book without errors or injected markup`, async () => {
    const { context, page, problems } = await openTracked(
      browser,
      server.origin,
      path,
    );
    assert.equal(await countText(page), "Showing 14 of 14 books");
    assert.deepEqual(await pressedGenres(page), ["All"]);
    assert.equal(
      await page.locator("#book-list script, #book-list img").count(),
      0,
    );
    assert.deepEqual(problems, []);
    await context.close();
  });
}

test("an unknown genre shows a clear notice that does not echo the input", async () => {
  const { context, page } = await openTracked(
    browser,
    server.origin,
    "books.html?genre=%3Cb%3EUnknown%3C%2Fb%3E",
  );
  assert.equal(
    await page.locator("#filter-notice").textContent(),
    "We do not stock that genre, so every book is shown.",
  );
  assert.equal(await page.locator("#status b").count(), 0);
  await context.close();
});

test("back and forward restore the filter from the history", async () => {
  const { context, page } = await openTracked(
    browser,
    server.origin,
    "books.html",
  );
  await page.getByRole("button", { name: "Fiction", exact: true }).click();
  await page.getByRole("button", { name: "Art & Design", exact: true }).click();
  assert.equal(await countText(page), "Showing 2 of 14 books");

  await page.goBack();
  assert.equal(await countText(page), "Showing 3 of 14 books");
  assert.deepEqual(await pressedGenres(page), ["Fiction"]);

  await page.goBack();
  assert.equal(await countText(page), "Showing 14 of 14 books");
  await page.goForward();
  assert.deepEqual(await pressedGenres(page), ["Fiction"]);
  await context.close();
});

for (const path of [
  "books.html?genre=All",
  "books.html?genre=all",
  "books.html?genre=%20ALL%20",
]) {
  test(`${path} means All, with every book and no notice`, async () => {
    const { context, page, problems } = await openTracked(
      browser,
      server.origin,
      path,
    );
    assert.equal(await countText(page), "Showing 14 of 14 books");
    assert.deepEqual(await pressedGenres(page), ["All"]);
    assert.equal(await page.locator("#filter-notice").textContent(), "");
    assert.deepEqual(problems, []);
    await context.close();
  });
}

// Relative luminance and WCAG contrast ratio for the rgb(r, g, b) strings from getComputedStyle.
function contrast(first, second) {
  const luminance = (rgb) => {
    const [r, g, b] = rgb
      .match(/\d+/g)
      .slice(0, 3)
      .map((value) => {
        const channel = Number(value) / 255;
        return channel <= 0.03928
          ? channel / 12.92
          : ((channel + 0.055) / 1.055) ** 2.4;
      });
    return 0.2126 * r + 0.7152 * g + 0.0722 * b;
  };
  const [lighter, darker] = [luminance(first), luminance(second)].sort(
    (a, b) => b - a,
  );
  return (lighter + 0.05) / (darker + 0.05);
}

for (const scheme of ["light", "dark"]) {
  test(`unpressed filter buttons have a 3:1 border contrast in ${scheme} mode`, async () => {
    const { context, page } = await openTracked(
      browser,
      server.origin,
      "books.html",
    );
    // Reduced motion stops the colour transition, so the computed colours are final.
    await page.emulateMedia({ colorScheme: scheme, reducedMotion: "reduce" });
    const colours = await page.$eval(
      '#genre-filters button[aria-pressed="false"]',
      (button) => {
        const style = getComputedStyle(button);
        return {
          border: style.borderTopColor,
          background: style.backgroundColor,
        };
      },
    );
    assert.ok(
      contrast(colours.border, colours.background) >= 3,
      `${scheme}: ${JSON.stringify(colours)}`,
    );
    await context.close();
  });
}

test("on a 360px screen a book card is a short horizontal row with a small cover", async () => {
  const { context, page, problems } = await openTracked(
    browser,
    server.origin,
    "books.html",
    { width: 360, height: 740 },
  );
  const cover = await page.locator("#book-list .cover").first().boundingBox();
  assert.ok(cover.width <= 100, `cover is ${cover.width}px wide`);
  assert.ok(cover.height <= 140, `cover is ${cover.height}px tall`);
  assert.deepEqual(problems, []);
  await context.close();
});

test("at 1280px book covers keep their full-size portrait layout", async () => {
  const { context, page } = await openTracked(
    browser,
    server.origin,
    "books.html",
    { width: 1280 },
  );
  const cover = await page.locator("#book-list .cover").first().boundingBox();
  assert.ok(cover.width >= 200, `cover is ${cover.width}px wide`);
  assert.ok(cover.height > cover.width, "cover is portrait");
  await context.close();
});

// A word counts as split when its rendered text spans more than one line box (more than one client rect).
for (const [width, textPercent] of [
  [320, 200],
  [320, 100],
  [360, 200],
  [360, 100],
]) {
  test(`at ${width}px with ${textPercent}% text no book title or genre tag splits a word`, async () => {
    const { context, page, problems } = await openTracked(
      browser,
      server.origin,
      "books.html",
      { width, height: 740 },
    );
    if (textPercent !== 100) {
      await page.addStyleTag({
        content: `html { font-size: ${textPercent}%; }`,
      });
    }
    const split = await page.$$eval(
      ".book h3, .book .genre-tag",
      (elements) => {
        const broken = [];
        for (const element of elements) {
          const walker = document.createTreeWalker(
            element,
            NodeFilter.SHOW_TEXT,
          );
          for (let node = walker.nextNode(); node; node = walker.nextNode()) {
            for (const match of node.textContent.matchAll(/\S+/g)) {
              const range = document.createRange();
              range.setStart(node, match.index);
              range.setEnd(node, match.index + match[0].length);
              if (range.getClientRects().length !== 1) {
                broken.push(match[0]);
              }
            }
          }
        }
        return broken;
      },
    );
    const overflow = await page.evaluate(() => ({
      scrollWidth: document.documentElement.scrollWidth,
      innerWidth: window.innerWidth,
    }));
    assert.deepEqual(split, []);
    assert.ok(
      overflow.scrollWidth <= overflow.innerWidth,
      JSON.stringify(overflow),
    );
    assert.deepEqual(problems, []);
    await context.close();
  });
}

test("at 360px with 100% text the cover still sits beside the book text", async () => {
  const { context, page } = await openTracked(
    browser,
    server.origin,
    "books.html",
    { width: 360, height: 740 },
  );
  const boxes = await page.evaluate(() => {
    const card = document.querySelector("#book-list .book");
    const rect = (selector) =>
      card.querySelector(selector).getBoundingClientRect();
    return { cover: rect(".cover"), info: rect(".book-info") };
  });
  assert.ok(boxes.info.left >= boxes.cover.right, JSON.stringify(boxes));
  assert.ok(boxes.info.top < boxes.cover.bottom, JSON.stringify(boxes));
  await context.close();
});

// Shared test helpers: an in-process static server for the repo root and a Playwright launcher.
import { createServer } from "node:http";
import { readFile } from "node:fs/promises";
import { execSync } from "node:child_process";
import { join, extname, resolve, sep } from "node:path";
import { fileURLToPath, pathToFileURL } from "node:url";

export const ROOT = resolve(fileURLToPath(new URL("..", import.meta.url)));

// Fixed "now" for every test: 17 November 2026, 10:00 local time (a Tuesday).
export const NOW = new Date(2026, 10, 17, 10, 0);

const TYPES = {
  ".html": "text/html; charset=utf-8",
  ".css": "text/css; charset=utf-8",
  ".js": "text/javascript; charset=utf-8",
  ".mjs": "text/javascript; charset=utf-8",
  ".svg": "image/svg+xml",
};

export async function startServer() {
  const server = createServer(async (req, res) => {
    const url = new URL(req.url, "http://localhost");
    let path = decodeURIComponent(url.pathname);
    if (path.endsWith("/")) {
      path += "index.html";
    }
    const file = resolve(ROOT, `.${path}`);
    if (!file.startsWith(ROOT + sep)) {
      res.writeHead(403).end();
      return;
    }
    try {
      const body = await readFile(file);
      res.writeHead(200, {
        "Content-Type": TYPES[extname(file)] ?? "application/octet-stream",
      });
      res.end(body);
    } catch {
      res.writeHead(404).end("Not found");
    }
  });
  await new Promise((done) => server.listen(0, "127.0.0.1", done));
  const { port } = server.address();
  return {
    origin: `http://127.0.0.1:${port}`,
    close: () => new Promise((done) => server.close(done)),
  };
}

async function loadPlaywright() {
  try {
    return await import("playwright");
  } catch {
    // ESM ignores NODE_PATH, so fall back to the globally installed copy.
    const globalRoot = execSync("npm root -g").toString().trim();
    return import(
      pathToFileURL(join(globalRoot, "playwright", "index.mjs")).href
    );
  }
}

export async function launchBrowser() {
  const { chromium } = await loadPlaywright();
  return chromium.launch();
}

// Opens a page with a fixed clock and records console errors, uncaught exceptions,
// dialogs and any request that leaves the local origin.
export async function openTracked(
  browser,
  origin,
  path,
  { now = NOW, width = 1280, height = 900 } = {},
) {
  const context = await browser.newContext({ viewport: { width, height } });
  const page = await context.newPage();
  await page.clock.setFixedTime(now);
  const problems = [];
  page.on("console", (message) => {
    if (message.type() === "error") {
      problems.push(`console error: ${message.text()}`);
    }
  });
  page.on("pageerror", (error) =>
    problems.push(`uncaught exception: ${error.message}`),
  );
  page.on("dialog", (dialog) => {
    problems.push(`dialog: ${dialog.message()}`);
    dialog.dismiss();
  });
  page.on("request", (request) => {
    const url = request.url();
    if (!url.startsWith(`${origin}/`) && !url.startsWith("data:")) {
      problems.push(`external request: ${url}`);
    }
  });
  await page.goto(`${origin}/${path}`);
  return { context, page, problems };
}

# Marginalia Books

A static website for Marginalia Books, a fictional independent bookshop on
Quill Street in Lowmoor. It has four pages: home, books, events and visit.
The books page has a genre filter whose state lives in the URL, the events page
lists upcoming readings and story times, and the visit page has opening hours,
the address, getting-here notes and a contact form. The contact form is a demo:
it checks the fields in the browser and shows a notice, but it never sends
anything anywhere.

The site is plain HTML, CSS and JavaScript with no build step, no frameworks
and no runtime dependencies. It makes no requests outside its own origin: no
CDNs, web fonts, remote images or analytics.

## Viewing the site

Serve the repo root with any static server and open it in a browser. From the
repo root, either of these works:

```sh
npx http-server -p 8080 -s .
# or
python3 -m http.server 8080
```

Then open http://localhost:8080/. Opening `index.html` directly from the file
system also works for browsing, but use a server for the most accurate check.

## File layout

```
index.html          Home page
books.html          Books catalogue with genre filter
events.html         Events listing
visit.html          Opening hours, address, access and contact form
css/styles.css      Shared styles for every page
js/catalog.js       Catalogue data, prices in pounds (add or change books here only)
js/books.js         Genre filter and URL state for the books page
js/home.js          Staff picks and today's opening hours on the home page
js/contact.js       Contact form validation and demo submit message
favicon.svg         Site icon
tests/              Headless browser tests (Node test runner + Playwright)
```

Opening hours appear in two places: the table on `visit.html` and the `HOURS`
list in `js/home.js`, which drives the "today" line on the home page. Change
both together.

## Running the tests

The tests start their own static server on a random port and drive headless
Chrome through Playwright. Playwright is expected to be installed globally,
with google-chrome available at `/usr/bin/google-chrome`. If the Chrome channel
is not available, the tests fall back to Playwright's bundled Chromium.

```sh
npm test
```

To run one file:

```sh
NODE_PATH=$(npm root -g) node --test tests/books.test.js
```

`npm install` also works, because Playwright is listed under `devDependencies`.
The tests resolve it from the local `node_modules` first, then from the global
install.

import random
import threading
import time
import unittest
from decimal import Decimal
from unittest import mock

import shop.orders
from shop.cart import Cart
from shop.orders import Order, Refund, RefundError, place_order, refund

TOTAL = Decimal("54.77")  # _cart(): subtotal 43.25 + shipping 7.95 + tax 3.57

# (amount, well_formed); well_formed amounts are Decimals that pass validation.
# Over-total amounts such as 1E+100 are well formed; the total rule rejects them.
AMOUNTS = [
    (Decimal("0.01"), True),
    (Decimal("0.77"), True),
    (Decimal("1.5"), True),
    (Decimal("5"), True),
    (Decimal("5.00"), True),
    (Decimal("12.30"), True),
    (Decimal("1E+1"), True),
    (Decimal("54.77"), True),
    (Decimal("54.78"), True),
    (Decimal("1E+100"), True),
    (5, False),
    (5.0, False),
    ("5.00", False),
    (None, False),
    (True, False),
    (Decimal("0"), False),
    (Decimal("-1.00"), False),
    (Decimal("0.001"), False),
    (Decimal("1.005"), False),
    (Decimal("NaN"), False),
    (Decimal("sNaN"), False),
    (Decimal("Infinity"), False),
    (Decimal("-Infinity"), False),
    (Decimal("-0.00"), False),
    (Decimal("1.0000000000000000000000000000001"), False),
]

# Every amount that must be rejected, plus an over-total value that is
# well formed but still must fail with RefundError.
HOSTILE_AMOUNTS = [amount for amount, well_formed in AMOUNTS if not well_formed] + [Decimal("1E+100")]


def _cart():
    cart = Cart()
    cart.add("BEAN-ETH", 2)
    cart.add("FILTER")
    return cart


def _race(workers, call):
    """Run call(i) in `workers` threads released together; return each result or exception."""
    start = threading.Barrier(workers)
    outcomes = [None] * workers

    def run(i):
        start.wait()
        try:
            outcomes[i] = call(i)
        except Exception as exc:
            outcomes[i] = exc

    threads = [threading.Thread(target=run, args=(i,)) for i in range(workers)]
    for thread in threads:
        thread.start()
    for thread in threads:
        thread.join()
    return outcomes


def _widen_window(hook):
    """Call hook() between each refund's check and its write, to widen the race window."""
    real = shop.orders.Refund

    def build(order_id, amount, key):
        hook()
        return real(order_id, amount, key)

    return mock.patch.object(shop.orders, "Refund", build)


def _nap():
    time.sleep(0.001)


class ModuleTest(unittest.TestCase):
    def test_refund_error_is_value_error(self):
        self.assertTrue(issubclass(RefundError, ValueError))

    def test_one_line_docstring(self):
        self.assertTrue(shop.orders.__doc__)
        self.assertNotIn("\n", shop.orders.__doc__.strip())


class PlaceOrderTest(unittest.TestCase):
    def test_order_total_is_cart_total(self):
        order = place_order(_cart())
        self.assertIsInstance(order, Order)
        self.assertEqual(order.total, TOTAL)

    def test_total_is_snapshot(self):
        cart = _cart()
        order = place_order(cart)
        cart.add("MUG")
        cart.remove("BEAN-ETH")
        self.assertEqual(order.total, TOTAL)

    def test_same_cart_twice_gives_two_orders(self):
        cart = _cart()
        first = place_order(cart)
        second = place_order(cart)
        self.assertIsNot(first, second)
        self.assertNotEqual(first.id, second.id)
        self.assertEqual(first.total, TOTAL)
        self.assertEqual(second.total, TOTAL)

    def test_empty_cart_raises(self):
        with self.assertRaises(ValueError) as ctx:
            place_order(Cart())
        self.assertEqual(str(ctx.exception), "cannot place an order for an empty cart")

    def test_emptied_cart_raises(self):
        cart = Cart()
        cart.add("MUG")
        cart.remove("MUG")
        with self.assertRaises(ValueError):
            place_order(cart)


class OrderStateTest(unittest.TestCase):
    def test_nothing_refunded_before_refund(self):
        order = place_order(_cart())
        self.assertEqual(order.refunded(), 0)
        self.assertEqual(order.refundable(), TOTAL)

    def test_partial_refund_updates_totals(self):
        order = place_order(_cart())
        refund(order, Decimal("10.00"), "a")
        self.assertEqual(order.refunded(), Decimal("10.00"))
        self.assertEqual(order.refundable(), Decimal("44.77"))

    def test_refund_records_order_amount_and_key(self):
        order = place_order(_cart())
        result = refund(order, Decimal("1.5"), "k")
        self.assertIsInstance(result, Refund)
        self.assertEqual(result.order_id, order.id)
        self.assertEqual(result.amount, Decimal("1.5"))
        self.assertEqual(result.key, "k")


class RefundAmountTest(unittest.TestCase):
    def test_whole_cent_spellings_accepted(self):
        for amount in (Decimal("1.5"), Decimal("1.50"), Decimal("1.500"), Decimal("1E+1")):
            with self.subTest(amount=amount):
                order = place_order(_cart())
                refund(order, amount, "k")
                self.assertEqual(order.refunded(), amount)

    def test_invalid_amounts_raise_and_change_nothing(self):
        for amount in HOSTILE_AMOUNTS:
            with self.subTest(amount=amount):
                order = place_order(_cart())
                with self.assertRaises(RefundError):
                    refund(order, amount, "k")
                self.assertEqual(order.refunded(), 0)
                # The failing key was not recorded, so a valid amount still works.
                self.assertEqual(refund(order, Decimal("1.00"), "k").amount, Decimal("1.00"))


class RefundLimitTest(unittest.TestCase):
    def test_exact_total_then_nothing_more(self):
        order = place_order(_cart())
        refund(order, TOTAL, "all")
        self.assertEqual(order.refundable(), 0)
        with self.assertRaises(RefundError):
            refund(order, Decimal("0.01"), "more")
        self.assertEqual(order.refunded(), TOTAL)

    def test_total_plus_a_cent_fails(self):
        order = place_order(_cart())
        with self.assertRaises(RefundError):
            refund(order, TOTAL + Decimal("0.01"), "k")
        self.assertEqual(order.refunded(), 0)
        self.assertEqual(refund(order, TOTAL, "k").amount, TOTAL)

    def test_remaining_exact_ok_one_cent_more_fails(self):
        order = place_order(_cart())
        refund(order, Decimal("54.76"), "a")
        with self.assertRaises(RefundError):
            refund(order, Decimal("0.02"), "b")
        refund(order, Decimal("0.01"), "c")
        self.assertEqual(order.refundable(), 0)

    def test_many_small_refunds_sum_to_total(self):
        order = place_order(_cart())
        for i in range(54):
            refund(order, Decimal("1.00"), i)
        refund(order, Decimal("0.77"), 54)
        self.assertEqual(order.refunded(), TOTAL)
        with self.assertRaises(RefundError):
            refund(order, Decimal("0.01"), "extra")
        self.assertEqual(order.refunded(), TOTAL)


class IdempotencyTest(unittest.TestCase):
    def test_same_key_returns_original_refund(self):
        order = place_order(_cart())
        first = refund(order, Decimal("5"), "k")
        again = refund(order, Decimal("5.00"), "k")
        self.assertIs(again, first)
        self.assertEqual(order.refunded(), Decimal("5"))

    def test_replay_after_fully_refunded(self):
        order = place_order(_cart())
        first = refund(order, TOTAL, "k")
        self.assertIs(refund(order, TOTAL, "k"), first)
        self.assertEqual(order.refunded(), TOTAL)

    def test_same_key_different_amount_raises(self):
        order = place_order(_cart())
        first = refund(order, Decimal("5"), "k")
        with self.assertRaises(RefundError):
            refund(order, Decimal("6"), "k")
        self.assertEqual(order.refunded(), Decimal("5"))
        self.assertIs(refund(order, Decimal("5"), "k"), first)

    def test_replay_with_invalid_amount_raises(self):
        order = place_order(_cart())
        refund(order, Decimal("5"), "k")
        for amount in (-1, Decimal("-1"), "5.00"):
            with self.subTest(amount=amount):
                with self.assertRaises(RefundError):
                    refund(order, amount, "k")
                self.assertEqual(order.refunded(), Decimal("5"))

    def test_same_key_on_other_order_is_independent(self):
        first_order = place_order(_cart())
        second_order = place_order(_cart())
        first = refund(first_order, Decimal("5"), "k")
        second = refund(second_order, Decimal("5"), "k")
        self.assertIsNot(first, second)
        self.assertEqual(second.order_id, second_order.id)
        self.assertEqual(first_order.refunded(), Decimal("5"))
        self.assertEqual(second_order.refunded(), Decimal("5"))


class ConcurrencyTest(unittest.TestCase):
    def _refund_while_first_paused(self, order, first, second):
        """Pause the first refund between its check and its write, then run the second.

        first and second are (amount, key) pairs. Returns (second_blocked, outcomes),
        where second_blocked says the second refund waited while the first was paused.
        """
        gate, entered = threading.Event(), threading.Event()

        def pause_first_build():
            if not entered.is_set():
                entered.set()
                gate.wait(5)

        outcomes = {}

        def run(name, amount, key):
            try:
                outcomes[name] = refund(order, amount, key)
            except RefundError as exc:
                outcomes[name] = exc

        with _widen_window(pause_first_build):
            first_thread = threading.Thread(target=run, args=("first", *first))
            first_thread.start()
            self.assertTrue(entered.wait(5))
            second_thread = threading.Thread(target=run, args=("second", *second))
            second_thread.start()
            second_thread.join(0.2)
            second_blocked = second_thread.is_alive()
            gate.set()
            first_thread.join(5)
            second_thread.join(5)
        return second_blocked, outcomes

    def test_refund_waits_for_lock_over_refund(self):
        order = place_order(_cart())
        blocked, outcomes = self._refund_while_first_paused(order, (TOTAL, "a"), (TOTAL, "b"))
        self.assertTrue(blocked)
        self.assertIsInstance(outcomes["first"], Refund)
        self.assertIsInstance(outcomes["second"], RefundError)
        self.assertEqual(order.refunded(), TOTAL)

    def test_same_key_waits_for_lock_and_reuses_refund(self):
        order = place_order(_cart())
        blocked, outcomes = self._refund_while_first_paused(
            order, (Decimal("5"), "k"), (Decimal("5"), "k")
        )
        self.assertTrue(blocked)
        self.assertIs(outcomes["second"], outcomes["first"])
        self.assertEqual(order.refunded(), Decimal("5"))

    def test_order_ids_unique_across_threads(self):
        cart = _cart()
        outcomes = _race(8, lambda i: [place_order(cart).id for _ in range(125)])
        self.assertFalse(any(isinstance(o, Exception) for o in outcomes))
        ids = [order_id for batch in outcomes for order_id in batch]
        self.assertEqual(len(ids), 1000)
        self.assertEqual(len(set(ids)), 1000)

    def test_same_key_from_8_threads_refunds_once(self):
        with _widen_window(_nap):
            for _ in range(200):
                order = place_order(_cart())
                outcomes = _race(8, lambda i: refund(order, Decimal("5.00"), "k"))
                self.assertFalse(any(isinstance(o, Exception) for o in outcomes))
                self.assertTrue(all(o is outcomes[0] for o in outcomes))
                self.assertEqual(order.refunded(), Decimal("5.00"))

    def test_over_refund_from_8_threads_never_exceeds_total(self):
        with _widen_window(_nap):
            for _ in range(200):
                order = place_order(_cart())
                outcomes = _race(8, lambda i: refund(order, TOTAL, f"k{i}"))
                accepted = [o for o in outcomes if isinstance(o, Refund)]
                rejected = [o for o in outcomes if isinstance(o, RefundError)]
                self.assertEqual(len(accepted), 1)
                self.assertEqual(len(rejected), 7)
                self.assertEqual(order.refunded(), TOTAL)
                self.assertEqual(order.refundable(), 0)

    def test_readers_never_fail_during_refunds(self):
        order = Order("readers", Decimal("1000.00"))
        stop = threading.Event()
        reader_errors = []

        def read():
            while not stop.is_set():
                try:
                    order.refunded()
                    order.refundable()
                except Exception as exc:
                    reader_errors.append(repr(exc))

        readers = [threading.Thread(target=read) for _ in range(8)]
        for reader in readers:
            reader.start()
        outcomes = _race(8, lambda i: [refund(order, Decimal("0.01"), f"{i}-{n}") for n in range(100)])
        stop.set()
        for reader in readers:
            reader.join()
        self.assertEqual(reader_errors, [])
        self.assertFalse(any(isinstance(o, Exception) for o in outcomes))
        self.assertEqual(order.refunded(), Decimal("0.01") * 800)


class RefundPropertyTest(unittest.TestCase):
    def test_random_refund_sequences(self):
        rng = random.Random(20261117)
        for _ in range(1000):
            order = place_order(_cart())
            accepted = {}  # key -> the Refund accepted for that key
            history = []
            for _ in range(rng.randint(1, 10)):
                key = rng.randrange(4)
                amount, well_formed = rng.choice(AMOUNTS)
                history.append((key, amount))
                spent = sum((r.amount for r in accepted.values()), Decimal("0"))
                if not well_formed:
                    expect_ok = False
                elif key in accepted:
                    expect_ok = amount == accepted[key].amount
                else:
                    expect_ok = amount <= TOTAL - spent
                try:
                    result = refund(order, amount, key)
                except RefundError:
                    result = None
                self.assertEqual(result is not None, expect_ok, msg=f"history={history}")
                if result is not None and key not in accepted:
                    accepted[key] = result
                elif result is not None:
                    self.assertIs(result, accepted[key], msg=f"history={history}")
                spent = sum((r.amount for r in accepted.values()), Decimal("0"))
                self.assertLessEqual(order.refunded(), TOTAL, msg=f"history={history}")
                self.assertEqual(order.refundable(), TOTAL - order.refunded(), msg=f"history={history}")
                self.assertEqual(order.refunded(), spent, msg=f"history={history}")

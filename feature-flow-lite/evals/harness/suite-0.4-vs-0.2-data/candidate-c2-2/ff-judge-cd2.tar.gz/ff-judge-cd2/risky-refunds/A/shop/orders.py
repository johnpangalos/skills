"""Orders and idempotent partial refunds (in-memory store)."""

import decimal
import secrets
import threading
from dataclasses import dataclass
from decimal import Decimal, InvalidOperation

from shop.money import CENT

# Reentrant: refundable() holds the lock while calling refunded(), which takes it too.
_LOCK = threading.RLock()  # held across every refund check and write

# Sums and differences are exact at any size, whatever precision the caller has set.
_EXACT = decimal.Context(prec=decimal.MAX_PREC, Emax=decimal.MAX_EMAX, Emin=decimal.MIN_EMIN)


class RefundError(ValueError):
    pass


@dataclass(frozen=True)
class Refund:
    order_id: str
    amount: Decimal
    key: str


class Order:
    def __init__(self, total):
        self.id = secrets.token_urlsafe(12)
        self.total = total
        self._refunds = {}  # idempotency key -> Refund

    def refunded(self):
        """Sum of this order's refunds."""
        with _LOCK, decimal.localcontext(_EXACT):
            return sum((r.amount for r in self._refunds.values()), Decimal("0.00"))

    def refundable(self):
        """What is left of the total to refund."""
        with _LOCK, decimal.localcontext(_EXACT):
            return self.total - self.refunded()


def place_order(cart):
    """Create an Order at the cart's total as of now."""
    if not cart.items:
        raise ValueError("cart is empty")
    return Order(cart.total())


def _is_whole_cents(amount, total):
    """True if amount is a whole number of cents. Rounding gets only the digits the total can need, so huge amounts fail fast."""
    digits = max(total.adjusted() + 3, 1)  # cents of any amount up to total
    try:
        return amount.quantize(CENT, context=decimal.Context(prec=digits)) == amount
    except InvalidOperation:  # more digits than the total has, so too big to be a refund
        return False


def refund(order, amount, key):
    """Refund amount from order. A repeated key with the same amount returns the first Refund."""
    if not isinstance(amount, Decimal) or not amount.is_finite() or amount <= 0:
        raise RefundError("amount must be a finite, positive Decimal in whole cents")
    if not _is_whole_cents(amount, order.total):
        raise RefundError("amount must be a finite, positive Decimal in whole cents")
    with _LOCK, decimal.localcontext(_EXACT):
        previous = order._refunds.get(key)
        if previous is not None:
            if previous.amount != amount:
                raise RefundError("key already used for a different amount")
            return previous
        if order.refunded() + amount > order.total:
            raise RefundError("refund would exceed the refundable amount")
        record = Refund(order.id, amount, key)
        order._refunds[key] = record
        return record

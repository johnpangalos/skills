"""Orders placed from a cart, with idempotent partial refunds."""

import threading
import uuid
from decimal import Decimal

from shop.money import CENT

_LOCK = threading.RLock()  # held across every refund's check and write, and every read of refunds


class RefundError(ValueError):
    pass


class Order:
    def __init__(self, order_id, total):
        self.id = order_id
        self.total = total
        self._refunds = {}  # idempotency key -> Refund

    def refunded(self):
        with _LOCK:
            return sum((r.amount for r in self._refunds.values()), Decimal("0.00"))

    def refundable(self):
        return self.total - self.refunded()


class Refund:
    def __init__(self, order_id, amount, key):
        self.order_id = order_id
        self.amount = amount
        self.key = key


def place_order(cart):
    """Snapshot the cart's total into a new order."""
    if not cart.items:
        raise ValueError("cannot place an order for an empty cart")
    return Order(uuid.uuid4().hex, cart.total())


def _check_amount(amount):
    """Raise RefundError unless amount is a positive whole-cent Decimal."""
    if not isinstance(amount, Decimal) or not amount.is_finite():
        raise RefundError("amount must be a finite Decimal")
    if amount < CENT:
        raise RefundError("amount must be at least one cent")
    _, digits, exponent = amount.as_tuple()
    digits = list(digits)
    while exponent < -2 and digits[-1] == 0:  # CENT is 0.01, exponent -2
        digits.pop()
        exponent += 1
    if exponent < -2:
        raise RefundError("amount must be whole cents")


def refund(order, amount, key):
    """Refund amount from order. A repeated key returns its first Refund."""
    _check_amount(amount)
    with _LOCK:
        if key in order._refunds:
            first = order._refunds[key]
            if first.amount != amount:
                raise RefundError("key was already used for a different amount")
            return first
        if amount > order.refundable():
            raise RefundError("amount exceeds the refundable total")
        result = Refund(order.id, amount, key)
        order._refunds[key] = result
        return result

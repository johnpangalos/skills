"""Orders and refunds (in-memory store)."""

import decimal
import threading
import uuid
from dataclasses import dataclass
from decimal import Decimal, InvalidOperation

from shop.money import to_cents


class RefundError(ValueError):
    pass


@dataclass(frozen=True)
class Refund:
    order_id: str
    amount: Decimal
    key: str


class Order:
    def __init__(self, total):
        self.id = uuid.uuid4().hex
        self.total = total
        self._refunds = {}  # key -> Refund
        self._refunded = Decimal("0.00")  # running sum of _refunds amounts
        self._lock = threading.Lock()

    def _refund_for(self, key):
        """The Refund recorded under key, or None."""
        return self._refunds.get(key)

    def refunded(self):
        """Sum of this order's refunds."""
        return self._refunded

    def refundable(self):
        """Amount of the total not yet refunded."""
        with _money_context():
            return self.total - self._refunded


def place_order(cart):
    """Freeze the cart's current total into a new Order."""
    if not cart.items:
        raise ValueError("cannot place an order for an empty cart")
    with _money_context():
        return Order(cart.total())


def _money_context():
    """A fresh context, so the caller's precision and traps (e.g. Inexact) cannot alter money math."""
    return decimal.localcontext(decimal.Context())


def _check_amount(amount):
    """Raise RefundError unless amount is a finite, positive, whole-cent Decimal."""
    if not isinstance(amount, Decimal):
        raise RefundError("amount must be a Decimal")
    if not amount.is_finite():
        raise RefundError("amount must be finite")
    if amount <= 0:
        raise RefundError("amount must be greater than zero")
    with _money_context():
        try:
            whole = to_cents(amount) == amount
        except InvalidOperation:  # too large to represent in cents
            whole = False
    if not whole:
        raise RefundError("amount must be whole cents")


def refund(order, amount, key):
    """Refund amount from order. A repeated key returns its original Refund."""
    _check_amount(amount)
    with order._lock, _money_context():
        existing = order._refund_for(key)
        if existing is not None:
            if existing.amount != amount:
                raise RefundError("key already used for a different amount")
            return existing
        if amount > order.refundable():
            raise RefundError("amount exceeds refundable")
        record = Refund(order.id, amount, key)
        order._refunds[key] = record
        order._refunded += amount
        return record

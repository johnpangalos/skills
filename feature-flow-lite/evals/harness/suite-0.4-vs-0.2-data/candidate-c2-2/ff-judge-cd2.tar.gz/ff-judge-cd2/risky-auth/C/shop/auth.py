"""Password-reset tokens (in-memory store)."""

import secrets
import threading
import time

RESET_TTL = 1800  # seconds a reset token stays redeemable after issue

_TOKENS = {}  # token -> {"username", "issued_at", "used"}
_LOCK = threading.Lock()


class InvalidToken(Exception):
    pass


class TokenExpired(InvalidToken):
    pass


class TokenUsed(InvalidToken):
    pass


def issue_reset_token(username, now=None):
    """Create a single-use reset token for username, valid for 1800 seconds from now."""
    issued_at = time.time() if now is None else now
    token = secrets.token_urlsafe(16)
    with _LOCK:
        _TOKENS[token] = {"username": username, "issued_at": issued_at, "used": False}
    return token


def redeem_reset_token(token, now=None):
    """Return the username a token was issued for; each token works once, within 1800 seconds."""
    now = time.time() if now is None else now
    with _LOCK:
        record = _TOKENS.get(token)
        if record is None:
            raise InvalidToken("unknown token")
        if record["used"]:
            raise TokenUsed("token already used")
        if now - record["issued_at"] > RESET_TTL:
            raise TokenExpired("token expired")
        record["used"] = True
        return record["username"]

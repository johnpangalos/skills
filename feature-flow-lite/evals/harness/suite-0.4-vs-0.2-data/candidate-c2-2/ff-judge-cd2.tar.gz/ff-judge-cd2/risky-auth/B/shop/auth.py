"""Password-reset tokens (in-memory store, single-use, 30-minute lifetime)."""

import secrets
import threading
import time

TOKEN_TTL = 1800  # seconds after issue

_TOKENS = {}  # token -> {"username", "issued_at", "used"}
_LOCK = threading.Lock()


class InvalidToken(Exception):
    pass


class TokenExpired(InvalidToken):
    pass


class TokenUsed(InvalidToken):
    pass


def issue_reset_token(username, now=None):
    """Create a reset token for username, issued at now (Unix seconds)."""
    if now is None:
        now = time.time()
    token = secrets.token_urlsafe(16)
    with _LOCK:
        _TOKENS[token] = {"username": username, "issued_at": now, "used": False}
    return token


def redeem_reset_token(token, now=None):
    """Return the username for a valid token and mark it used."""
    if now is None:
        now = time.time()
    with _LOCK:
        try:
            record = _TOKENS.get(token)
        except TypeError:  # unhashable token
            record = None
        if record is None:
            raise InvalidToken("unknown token")
        if record["used"]:
            raise TokenUsed("token already used")
        if now - record["issued_at"] > TOKEN_TTL:
            raise TokenExpired("token expired")
        record["used"] = True
        return record["username"]

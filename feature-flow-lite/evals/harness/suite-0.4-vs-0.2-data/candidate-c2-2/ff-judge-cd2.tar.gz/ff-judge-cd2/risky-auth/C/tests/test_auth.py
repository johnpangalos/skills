import threading
import time
import unittest
from unittest import mock

from shop import auth
from shop.auth import (
    InvalidToken,
    TokenExpired,
    TokenUsed,
    issue_reset_token,
    redeem_reset_token,
)


class _SlowCheckRecord(dict):
    """Pauses while a reader sees the token unused, so an unlocked check-then-write interleaves."""

    def __getitem__(self, key):
        value = dict.__getitem__(self, key)
        if key == "used" and value is False:
            time.sleep(0.005)
        return value


class ResetTokenTest(unittest.TestCase):
    def test_round_trip(self):
        token = issue_reset_token("ada")
        self.assertEqual(redeem_reset_token(token), "ada")

    def test_unknown_token(self):
        with self.assertRaises(InvalidToken):
            redeem_reset_token("not-a-token")

    def test_redeem_at_exactly_1800_seconds_succeeds(self):
        token = issue_reset_token("ada", now=1000.0)
        self.assertEqual(redeem_reset_token(token, now=2800.0), "ada")

    def test_redeem_after_1800_seconds_expires(self):
        token = issue_reset_token("ada", now=1000.0)
        with self.assertRaises(TokenExpired) as ctx:
            redeem_reset_token(token, now=2800.001)
        self.assertEqual(str(ctx.exception), "token expired")

    def test_explicit_zero_now_is_honoured(self):
        token = issue_reset_token("ada", now=0)
        with self.assertRaises(TokenExpired):
            redeem_reset_token(token, now=1801)

    def test_float_timestamps(self):
        token = issue_reset_token("ada", now=1000.25)
        self.assertEqual(redeem_reset_token(token, now=2800.25), "ada")
        token = issue_reset_token("ada", now=1000.25)
        with self.assertRaises(TokenExpired):
            redeem_reset_token(token, now=2800.5)

    def test_default_now_is_read_at_call_time(self):
        with mock.patch("shop.auth.time.time", return_value=1000.0):
            token = issue_reset_token("ada")
        with mock.patch("shop.auth.time.time", return_value=2801.0):
            with self.assertRaises(TokenExpired):
                redeem_reset_token(token)

    def test_default_now_succeeds_within_window(self):
        token = issue_reset_token("ada")
        self.assertEqual(redeem_reset_token(token), "ada")

    def test_expired_redeem_does_not_consume_token(self):
        token = issue_reset_token("ada", now=1000.0)
        with self.assertRaises(TokenExpired):
            redeem_reset_token(token, now=3000.0)
        with self.assertRaises(TokenExpired):
            redeem_reset_token(token, now=3001.0)

    def test_second_redeem_raises_token_used(self):
        token = issue_reset_token("ada", now=0)
        self.assertEqual(redeem_reset_token(token, now=0), "ada")
        with self.assertRaises(TokenUsed) as ctx:
            redeem_reset_token(token, now=1)
        self.assertEqual(str(ctx.exception), "token already used")

    def test_used_is_checked_before_expiry(self):
        token = issue_reset_token("ada", now=0)
        self.assertEqual(redeem_reset_token(token, now=0), "ada")
        with self.assertRaises(TokenUsed):
            redeem_reset_token(token, now=5000)

    def test_concurrent_redeem_succeeds_exactly_once(self):
        for _ in range(50):
            token = issue_reset_token("ada")
            auth._TOKENS[token] = _SlowCheckRecord(auth._TOKENS[token])
            barrier = threading.Barrier(16)
            results = []

            def attempt():
                barrier.wait()
                try:
                    results.append(redeem_reset_token(token))
                except TokenUsed:
                    results.append("used")

            threads = [threading.Thread(target=attempt) for _ in range(16)]
            for thread in threads:
                thread.start()
            for thread in threads:
                thread.join()
            self.assertEqual(len(results), 16)
            self.assertEqual(results.count("ada"), 1)
            self.assertEqual(results.count("used"), 15)

    def test_error_classes_subclass_invalid_token(self):
        self.assertTrue(issubclass(TokenExpired, InvalidToken))
        self.assertTrue(issubclass(TokenUsed, InvalidToken))

    def test_unknown_tokens_are_not_expired_or_used(self):
        real = issue_reset_token("ada", now=0)
        tampered = real[:-1] + ("A" if real[-1] != "A" else "B")
        for bad in ["", "None", "null", tampered]:
            with self.subTest(token=bad):
                with self.assertRaises(InvalidToken) as ctx:
                    redeem_reset_token(bad, now=5000)
                self.assertNotIsInstance(ctx.exception, (TokenExpired, TokenUsed))
                self.assertEqual(str(ctx.exception), "unknown token")

    def test_issued_tokens_are_distinct(self):
        first = issue_reset_token("ada")
        second = issue_reset_token("ada")
        self.assertNotEqual(first, second)
        self.assertEqual(redeem_reset_token(first), "ada")
        self.assertEqual(redeem_reset_token(second), "ada")
        with self.assertRaises(TokenUsed):
            redeem_reset_token(first)

"""Password-reset tokens (in-memory store)."""

import secrets
import threading
import time

RESET_WINDOW = 1800  # seconds after issue; tokens are single-use

_TOKENS = {}  # token -> (username, issued_at, used)
_LOCK = threading.Lock()


class InvalidToken(Exception):
    pass


class TokenExpired(InvalidToken):
    pass


class TokenUsed(InvalidToken):
    pass


def issue_reset_token(username, now=None):
    """Create a reset token for username."""
    if now is None:
        now = time.time()
    token = secrets.token_urlsafe(16)
    with _LOCK:
        _TOKENS[token] = (username, now, False)
    return token


def redeem_reset_token(token, now=None):
    """Return the username a token was issued for, consuming the token."""
    if now is None:
        now = time.time()
    if type(token) is not str:
        raise InvalidToken("unknown token")
    with _LOCK:
        record = _TOKENS.get(token)
        if record is None:
            raise InvalidToken("unknown token")
        username, issued_at, used = record
        if used:
            raise TokenUsed("token already used")
        if now > issued_at + RESET_WINDOW:
            raise TokenExpired("token expired")
        _TOKENS[token] = (username, issued_at, True)
    return username

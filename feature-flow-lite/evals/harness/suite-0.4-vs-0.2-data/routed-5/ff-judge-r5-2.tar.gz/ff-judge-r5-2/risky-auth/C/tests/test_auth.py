import unittest
from unittest import mock

from shop import auth
from shop.auth import (
    InvalidToken,
    TokenExpired,
    TokenUsed,
    issue_reset_token,
    redeem_reset_token,
)

T0 = 1_000_000


class ResetTokenTest(unittest.TestCase):
    def setUp(self):
        auth._TOKENS.clear()

    def test_round_trip(self):
        token = issue_reset_token("ada", now=T0)
        self.assertEqual(redeem_reset_token(token, now=T0), "ada")

    def test_default_now_uses_clock(self):
        token = issue_reset_token("ada")
        self.assertEqual(redeem_reset_token(token), "ada")

    def test_now_zero_is_a_real_timestamp(self):
        token = issue_reset_token("ada", now=0)
        with self.assertRaises(TokenExpired):
            redeem_reset_token(token, now=1801)

    def test_float_now(self):
        token = issue_reset_token("ada", now=T0 + 0.5)
        self.assertEqual(redeem_reset_token(token, now=T0 + 1800.5), "ada")

    def test_redeem_exactly_at_ttl_succeeds(self):
        token = issue_reset_token("ada", now=T0)
        self.assertEqual(redeem_reset_token(token, now=T0 + 1800), "ada")

    def test_redeem_just_past_ttl_expires(self):
        token = issue_reset_token("ada", now=T0)
        with self.assertRaises(TokenExpired) as cm:
            redeem_reset_token(token, now=T0 + 1800.001)
        self.assertEqual(str(cm.exception), "token expired")

    def test_redeem_well_past_ttl_expires(self):
        token = issue_reset_token("ada", now=T0)
        with self.assertRaises(TokenExpired):
            redeem_reset_token(token, now=T0 + 1801)

    def test_clock_skew_is_not_expired(self):
        token = issue_reset_token("ada", now=T0)
        self.assertEqual(redeem_reset_token(token, now=T0 - 5000), "ada")

    def test_zero_issue_and_redeem_time_is_not_replaced_by_clock(self):
        token = issue_reset_token("ada", now=0)
        self.assertEqual(redeem_reset_token(token, now=0), "ada")

    def test_expired_attempt_never_returns_username(self):
        token = issue_reset_token("ada", now=T0)
        for _ in range(2):
            with self.assertRaises(TokenExpired):
                redeem_reset_token(token, now=T0 + 1801)

    def test_second_redeem_at_same_time_is_used(self):
        token = issue_reset_token("ada", now=T0)
        self.assertEqual(redeem_reset_token(token, now=T0), "ada")
        with self.assertRaises(TokenUsed) as cm:
            redeem_reset_token(token, now=T0)
        self.assertEqual(str(cm.exception), "token already used")

    def test_used_token_past_expiry_raises_token_used(self):
        token = issue_reset_token("ada", now=T0)
        redeem_reset_token(token, now=T0)
        with self.assertRaises(TokenUsed):
            redeem_reset_token(token, now=T0 + 5000)

    def test_expired_and_used_subclass_invalid_token(self):
        self.assertTrue(issubclass(TokenExpired, InvalidToken))
        self.assertTrue(issubclass(TokenUsed, InvalidToken))

    def test_unknown_token(self):
        with self.assertRaises(InvalidToken) as cm:
            redeem_reset_token("not-a-token", now=T0)
        self.assertEqual(str(cm.exception), "unknown token")

    def test_empty_token(self):
        with self.assertRaises(InvalidToken):
            redeem_reset_token("", now=T0)

    def test_none_token(self):
        with self.assertRaises(InvalidToken):
            redeem_reset_token(None, now=T0)

    def test_token_returns_its_own_user(self):
        ada = issue_reset_token("ada", now=T0)
        bob = issue_reset_token("bob", now=T0)
        self.assertEqual(redeem_reset_token(bob, now=T0), "bob")
        self.assertEqual(redeem_reset_token(ada, now=T0), "ada")

    def test_two_tokens_for_same_user_are_independent(self):
        first = issue_reset_token("ada", now=T0)
        second = issue_reset_token("ada", now=T0)
        self.assertNotEqual(first, second)
        self.assertEqual(redeem_reset_token(first, now=T0), "ada")
        self.assertEqual(redeem_reset_token(second, now=T0), "ada")
        with self.assertRaises(TokenUsed):
            redeem_reset_token(first, now=T0)
        with self.assertRaises(TokenUsed):
            redeem_reset_token(second, now=T0)

    def test_default_issue_and_redeem_use_clock(self):
        with mock.patch("shop.auth.time.time", return_value=T0):
            token = issue_reset_token("ada")
        with mock.patch("shop.auth.time.time", return_value=T0 + 1800):
            self.assertEqual(redeem_reset_token(token), "ada")

    def test_default_redeem_past_ttl_expires(self):
        with mock.patch("shop.auth.time.time", return_value=T0):
            token = issue_reset_token("ada")
        with mock.patch("shop.auth.time.time", return_value=T0 + 1801):
            with self.assertRaises(TokenExpired):
                redeem_reset_token(token)

    def test_explicit_issue_default_redeem_uses_clock(self):
        token = issue_reset_token("ada", now=T0)
        with mock.patch("shop.auth.time.time", return_value=T0 + 1800):
            self.assertEqual(redeem_reset_token(token), "ada")

    def test_default_issue_explicit_redeem_past_ttl_expires(self):
        with mock.patch("shop.auth.time.time", return_value=T0):
            token = issue_reset_token("ada")
        with self.assertRaises(TokenExpired):
            redeem_reset_token(token, now=T0 + 1801)

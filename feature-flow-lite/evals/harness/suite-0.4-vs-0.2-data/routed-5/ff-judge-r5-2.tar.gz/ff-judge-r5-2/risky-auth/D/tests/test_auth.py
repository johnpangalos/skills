import unittest
from unittest import mock

from shop.auth import (
    InvalidToken,
    TokenExpired,
    TokenUsed,
    issue_reset_token,
    redeem_reset_token,
)

ISSUED = 1_000_000.0


class ResetTokenTest(unittest.TestCase):
    def test_round_trip(self):
        token = issue_reset_token("ada", now=ISSUED)
        self.assertEqual(redeem_reset_token(token, now=ISSUED), "ada")

    def test_unknown_token(self):
        for bad in ("not-a-token", "", None):
            with self.subTest(token=bad):
                with self.assertRaises(InvalidToken) as ctx:
                    redeem_reset_token(bad, now=ISSUED)
                self.assertNotIsInstance(ctx.exception, (TokenExpired, TokenUsed))

    def test_expired_and_used_subclass_invalid_token(self):
        self.assertTrue(issubclass(TokenExpired, InvalidToken))
        self.assertTrue(issubclass(TokenUsed, InvalidToken))

    def test_redeem_at_exact_ttl_succeeds(self):
        token = issue_reset_token("ada", now=ISSUED)
        self.assertEqual(redeem_reset_token(token, now=ISSUED + 1800), "ada")

    def test_redeem_just_past_ttl_expires(self):
        token = issue_reset_token("ada", now=ISSUED)
        with self.assertRaises(TokenExpired):
            redeem_reset_token(token, now=ISSUED + 1800.001)

    def test_float_timestamps_respect_ttl(self):
        token = issue_reset_token("ada", now=ISSUED + 0.25)
        self.assertEqual(redeem_reset_token(token, now=ISSUED + 1800.25), "ada")
        other = issue_reset_token("bob", now=ISSUED + 0.25)
        with self.assertRaises(TokenExpired):
            redeem_reset_token(other, now=ISSUED + 1800.26)

    def test_second_redeem_at_same_time_is_used(self):
        token = issue_reset_token("ada", now=ISSUED)
        redeem_reset_token(token, now=ISSUED)
        with self.assertRaises(TokenUsed):
            redeem_reset_token(token, now=ISSUED)

    def test_second_redeem_long_after_issue_is_used(self):
        token = issue_reset_token("ada", now=ISSUED)
        redeem_reset_token(token, now=ISSUED)
        with self.assertRaises(TokenUsed):
            redeem_reset_token(token, now=ISSUED + 5000)

    def test_expired_redeem_does_not_consume_token(self):
        token = issue_reset_token("ada", now=ISSUED)
        with self.assertRaises(TokenExpired):
            redeem_reset_token(token, now=ISSUED + 5000)
        with self.assertRaises(TokenExpired):
            redeem_reset_token(token, now=ISSUED + 5001)

    def test_tokens_for_same_user_are_independent(self):
        first = issue_reset_token("ada", now=ISSUED)
        second = issue_reset_token("ada", now=ISSUED)
        self.assertNotEqual(first, second)
        self.assertEqual(redeem_reset_token(first, now=ISSUED), "ada")
        self.assertEqual(redeem_reset_token(second, now=ISSUED), "ada")
        with self.assertRaises(TokenUsed):
            redeem_reset_token(first, now=ISSUED)

    def test_default_now_uses_time_time_at_issue_and_redeem(self):
        with mock.patch("shop.auth.time.time", return_value=ISSUED):
            token = issue_reset_token("ada")
        with mock.patch("shop.auth.time.time", return_value=ISSUED + 1800):
            self.assertEqual(redeem_reset_token(token), "ada")

    def test_default_now_past_ttl_expires(self):
        with mock.patch("shop.auth.time.time", return_value=ISSUED):
            token = issue_reset_token("ada")
        with mock.patch("shop.auth.time.time", return_value=ISSUED + 1801):
            with self.assertRaises(TokenExpired):
                redeem_reset_token(token)

    def test_default_now_second_redeem_is_used(self):
        with mock.patch("shop.auth.time.time", return_value=ISSUED):
            token = issue_reset_token("ada")
            redeem_reset_token(token)
            with self.assertRaises(TokenUsed):
                redeem_reset_token(token)

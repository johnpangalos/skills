"""Password-reset tokens (in-memory store)."""

import secrets
import time

RESET_TOKEN_TTL = 1800  # seconds after issue

_TOKENS = {}  # token -> [username, issued_at, used]


class InvalidToken(Exception):
    pass


class TokenExpired(InvalidToken):
    pass


class TokenUsed(InvalidToken):
    pass


def issue_reset_token(username, now=None):
    """Create a reset token for username, issued at now (default: the clock)."""
    if now is None:
        now = time.time()
    token = secrets.token_urlsafe(16)
    _TOKENS[token] = [username, now, False]
    return token


def redeem_reset_token(token, now=None):
    """Return the username a token was issued for, consuming it on success."""
    if now is None:
        now = time.time()
    if not isinstance(token, str):
        raise InvalidToken("unknown token")
    entry = _TOKENS.get(token)
    if entry is None:
        raise InvalidToken("unknown token")
    username, issued_at, used = entry
    if used:
        raise TokenUsed("token already used")
    if now - issued_at > RESET_TOKEN_TTL:
        raise TokenExpired("token expired")
    entry[2] = True
    return username

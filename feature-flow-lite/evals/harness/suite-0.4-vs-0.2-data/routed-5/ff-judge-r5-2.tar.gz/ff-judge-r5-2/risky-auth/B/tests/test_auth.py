import unittest

from shop.auth import (
    InvalidToken,
    TokenExpired,
    TokenUsed,
    issue_reset_token,
    redeem_reset_token,
)

T0 = 1_000_000  # arbitrary issue time, Unix seconds


class ResetTokenTest(unittest.TestCase):
    def test_round_trip(self):
        token = issue_reset_token("ada")
        self.assertEqual(redeem_reset_token(token), "ada")

    def test_unknown_token(self):
        with self.assertRaises(InvalidToken):
            redeem_reset_token("not-a-token")

    def assertPlainInvalid(self, token, now=T0):
        with self.assertRaises(InvalidToken) as cm:
            redeem_reset_token(token, now=now)
        self.assertIs(type(cm.exception), InvalidToken)
        self.assertEqual(str(cm.exception), "unknown token")

    def test_unknown_empty_string_is_plain_invalid(self):
        self.assertPlainInvalid("")

    def test_mutated_token_is_plain_invalid(self):
        token = issue_reset_token("ada", now=T0)
        self.assertPlainInvalid(token + "x")
        self.assertEqual(redeem_reset_token(token, now=T0), "ada")

    def test_unknown_token_does_not_affect_others(self):
        token = issue_reset_token("ada", now=T0)
        self.assertPlainInvalid("not-a-token")
        self.assertEqual(redeem_reset_token(token, now=T0), "ada")

    def test_exact_ttl_still_redeems(self):
        token = issue_reset_token("ada", now=T0)
        self.assertEqual(redeem_reset_token(token, now=T0 + 1800), "ada")

    def test_just_past_ttl_is_expired(self):
        token = issue_reset_token("ada", now=T0)
        with self.assertRaises(TokenExpired) as cm:
            redeem_reset_token(token, now=T0 + 1800.001)
        self.assertEqual(str(cm.exception), "token expired")

    def test_1801_seconds_is_expired(self):
        token = issue_reset_token("ada", now=T0)
        with self.assertRaises(TokenExpired):
            redeem_reset_token(token, now=T0 + 1801)

    def test_now_zero_is_honored(self):
        token = issue_reset_token("ada", now=0)
        with self.assertRaises(TokenExpired):
            redeem_reset_token(token, now=1801)

    def test_now_zero_is_honored_on_redeem(self):
        token = issue_reset_token("ada", now=0)
        self.assertEqual(redeem_reset_token(token, now=0), "ada")

    def test_now_zero_issue_redeems_at_ttl(self):
        token = issue_reset_token("ada", now=0)
        self.assertEqual(redeem_reset_token(token, now=1800), "ada")

    def test_clock_skew_before_issue_redeems(self):
        token = issue_reset_token("ada", now=T0)
        self.assertEqual(redeem_reset_token(token, now=T0 - 500), "ada")

    def test_second_redeem_within_window_is_used(self):
        token = issue_reset_token("ada", now=T0)
        redeem_reset_token(token, now=T0 + 10)
        with self.assertRaises(TokenUsed) as cm:
            redeem_reset_token(token, now=T0 + 20)
        self.assertEqual(str(cm.exception), "token already used")

    def test_used_token_is_used_after_expiry_window(self):
        token = issue_reset_token("ada", now=T0)
        redeem_reset_token(token, now=T0 + 10)
        with self.assertRaises(TokenUsed):
            redeem_reset_token(token, now=T0 + 5000)

    def test_expired_stays_expired(self):
        token = issue_reset_token("ada", now=T0)
        for later in (T0 + 1801, T0 + 1801, T0 + 9000):
            with self.assertRaises(TokenExpired):
                redeem_reset_token(token, now=later)

    def test_two_tokens_for_same_user_are_independent(self):
        first = issue_reset_token("ada", now=T0)
        second = issue_reset_token("ada", now=T0)
        self.assertEqual(redeem_reset_token(first, now=T0), "ada")
        self.assertEqual(redeem_reset_token(second, now=T0), "ada")

    def test_expired_and_used_are_invalid_token_subclasses(self):
        self.assertTrue(issubclass(TokenExpired, InvalidToken))
        self.assertTrue(issubclass(TokenUsed, InvalidToken))

import unittest

from shop.auth import (
    InvalidToken,
    TokenExpired,
    TokenUsed,
    issue_reset_token,
    redeem_reset_token,
)


class ResetTokenTest(unittest.TestCase):
    def test_round_trip(self):
        token = issue_reset_token("ada")
        self.assertEqual(redeem_reset_token(token), "ada")

    def test_unknown_token(self):
        with self.assertRaises(InvalidToken):
            redeem_reset_token("not-a-token")

    def test_exactly_ttl_still_redeems(self):
        token = issue_reset_token("ada", now=1000)
        self.assertEqual(redeem_reset_token(token, now=2800), "ada")

    def test_past_ttl_raises_expired(self):
        token = issue_reset_token("ada", now=1000)
        with self.assertRaises(TokenExpired):
            redeem_reset_token(token, now=2801)

    def test_just_past_ttl_raises_expired(self):
        token = issue_reset_token("ada", now=0)
        with self.assertRaises(TokenExpired):
            redeem_reset_token(token, now=1800.001)

    def test_single_use(self):
        token = issue_reset_token("ada", now=0)
        self.assertEqual(redeem_reset_token(token, now=10), "ada")
        with self.assertRaises(TokenUsed):
            redeem_reset_token(token, now=20)

    def test_used_token_after_expiry_window_raises_used(self):
        token = issue_reset_token("ada", now=0)
        redeem_reset_token(token, now=100)
        with self.assertRaises(TokenUsed):
            redeem_reset_token(token, now=5000)

    def test_expired_redeem_does_not_consume_token(self):
        token = issue_reset_token("ada", now=0)
        with self.assertRaises(TokenExpired):
            redeem_reset_token(token, now=1801)
        with self.assertRaises(TokenExpired):
            redeem_reset_token(token, now=1802)

    def test_expiry_and_used_are_invalid_token_subclasses(self):
        self.assertTrue(issubclass(TokenExpired, InvalidToken))
        self.assertTrue(issubclass(TokenUsed, InvalidToken))

    def test_unknown_token_is_plain_invalid_token(self):
        with self.assertRaises(InvalidToken) as cm:
            redeem_reset_token("not-a-token")
        self.assertIs(type(cm.exception), InvalidToken)

    def test_zero_issue_time_is_not_replaced_by_clock(self):
        token = issue_reset_token("ada", now=0)
        self.assertEqual(redeem_reset_token(token, now=0), "ada")

        token = issue_reset_token("ada", now=0)
        with self.assertRaises(TokenExpired):
            redeem_reset_token(token, now=1801)

    def test_clock_skew_redeem_before_issue_is_not_expired(self):
        token = issue_reset_token("ada", now=1000)
        self.assertEqual(redeem_reset_token(token, now=500), "ada")

    def test_non_string_tokens_raise_invalid_token(self):
        for bad in (None, "", []):
            with self.subTest(token=bad):
                with self.assertRaises(InvalidToken) as cm:
                    redeem_reset_token(bad, now=0)
                self.assertIs(type(cm.exception), InvalidToken)

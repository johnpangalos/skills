import unittest
from decimal import Decimal

from shop.cart import Cart
from shop.orders import Refund, RefundError, place_order, refund

AMOUNT_MESSAGE = "amount must be a positive Decimal in whole cents"
HOSTILE_AMOUNTS = [
    5,
    5.0,
    "5.00",
    None,
    True,
    Decimal("0"),
    Decimal("-1"),
    Decimal("0.001"),
    Decimal("1.005"),
    Decimal("NaN"),
    Decimal("sNaN"),
    Decimal("Infinity"),
    Decimal("-Infinity"),
    Decimal("1E+30"),
]


def make_cart():
    cart = Cart()
    cart.add("BEAN-ETH", 2)
    cart.add("FILTER")
    return cart


class PlaceOrderTest(unittest.TestCase):
    def test_total_is_cart_total(self):
        order = place_order(make_cart())
        self.assertEqual(order.total, Decimal("54.77"))
        self.assertEqual(order.refunded(), Decimal("0.00"))
        self.assertEqual(order.refundable(), Decimal("54.77"))

    def test_empty_cart_rejected(self):
        with self.assertRaises(ValueError) as ctx:
            place_order(Cart())
        self.assertEqual(str(ctx.exception), "cannot place an order from an empty cart")

    def test_cart_emptied_by_remove_rejected(self):
        cart = make_cart()
        cart.remove("BEAN-ETH")
        cart.remove("FILTER")
        with self.assertRaises(ValueError) as ctx:
            place_order(cart)
        self.assertEqual(str(ctx.exception), "cannot place an order from an empty cart")

    def test_two_orders_from_same_cart_have_distinct_ids(self):
        cart = make_cart()
        self.assertNotEqual(place_order(cart).id, place_order(cart).id)

    def test_total_unchanged_by_later_cart_mutation(self):
        cart = make_cart()
        order = place_order(cart)
        cart.add("MUG", 3)
        cart.remove("BEAN-ETH")
        self.assertEqual(order.total, Decimal("54.77"))


class RefundTest(unittest.TestCase):
    def test_partial_refunds_sum(self):
        order = place_order(make_cart())
        refund(order, Decimal("10.00"), "a")
        refund(order, Decimal("4.50"), "b")
        self.assertEqual(order.refunded(), Decimal("14.50"))
        self.assertEqual(order.refundable(), Decimal("40.27"))

    def test_refund_records_order_id_amount_and_key(self):
        order = place_order(make_cart())
        result = refund(order, Decimal("3.00"), "k1")
        self.assertEqual(result, Refund(order.id, Decimal("3.00"), "k1"))
        self.assertEqual(order.refunds, [result])

    def test_refunds_exactly_totalling_total_succeed(self):
        order = place_order(make_cart())
        refund(order, Decimal("50.00"), "a")
        refund(order, Decimal("4.77"), "b")
        self.assertEqual(order.refunded(), Decimal("54.77"))
        self.assertEqual(order.refundable(), Decimal("0.00"))

    def test_over_refund_rejected_and_changes_nothing(self):
        order = place_order(make_cart())
        refund(order, Decimal("54.77"), "a")
        with self.assertRaises(RefundError) as ctx:
            refund(order, Decimal("0.01"), "b")
        self.assertEqual(str(ctx.exception), "refund exceeds refundable amount")
        self.assertEqual(order.refunded(), Decimal("54.77"))
        self.assertEqual(len(order.refunds), 1)
        self.assertEqual([r.key for r in order.refunds], ["a"])

    def test_rejected_key_can_be_reused_with_valid_amount(self):
        order = place_order(make_cart())
        refund(order, Decimal("50.00"), "a")
        with self.assertRaises(RefundError):
            refund(order, Decimal("5.00"), "b")
        result = refund(order, Decimal("4.77"), "b")
        self.assertEqual(result.amount, Decimal("4.77"))
        self.assertEqual(order.refunded(), Decimal("54.77"))

    def test_invalid_amounts_rejected_and_change_nothing(self):
        for amount in HOSTILE_AMOUNTS:
            with self.subTest(amount=amount):
                order = place_order(make_cart())
                with self.assertRaises(RefundError) as ctx:
                    refund(order, amount, "k")
                self.assertEqual(str(ctx.exception), AMOUNT_MESSAGE)
                self.assertEqual(order.refunds, [])

    def test_invalid_amount_with_used_key_rejected(self):
        order = place_order(make_cart())
        first = refund(order, Decimal("5.00"), "k")
        with self.assertRaises(RefundError) as ctx:
            refund(order, Decimal("NaN"), "k")
        self.assertEqual(str(ctx.exception), AMOUNT_MESSAGE)
        self.assertEqual(order.refunds, [first])

    def test_whole_cent_spellings_accepted(self):
        for amount in (Decimal("5"), Decimal("5.0"), Decimal("5.00"), Decimal("5.000"), Decimal("1E+1")):
            with self.subTest(amount=amount):
                order = place_order(make_cart())
                expected = "10.00" if amount == Decimal("1E+1") else "5.00"
                stored = refund(order, amount, "k").amount
                self.assertEqual(str(stored), expected)
                self.assertEqual(str(order.refunded()), expected)

    def test_refund_error_is_value_error(self):
        self.assertTrue(issubclass(RefundError, ValueError))


class IdempotencyTest(unittest.TestCase):
    def test_same_key_and_amount_returns_same_instance(self):
        order = place_order(make_cart())
        first = refund(order, Decimal("5.00"), "k")
        again = refund(order, Decimal("5.00"), "k")
        self.assertIs(again, first)
        self.assertEqual(order.refunded(), Decimal("5.00"))
        self.assertEqual(len(order.refunds), 1)

    def test_equal_amount_in_different_spelling_replays(self):
        order = place_order(make_cart())
        first = refund(order, Decimal("5"), "k")
        self.assertIs(refund(order, Decimal("5.00"), "k"), first)
        self.assertEqual(order.refunded(), Decimal("5.00"))

    def test_replay_after_fully_refunded_returns_same_instance(self):
        order = place_order(make_cart())
        first = refund(order, Decimal("54.77"), "k")
        self.assertIs(refund(order, Decimal("54.77"), "k"), first)
        self.assertEqual(order.refunded(), Decimal("54.77"))

    def test_same_key_different_amount_rejected_and_changes_nothing(self):
        order = place_order(make_cart())
        refund(order, Decimal("5.00"), "k")
        with self.assertRaises(RefundError) as ctx:
            refund(order, Decimal("6.00"), "k")
        self.assertEqual(str(ctx.exception), "key already used for a different amount")
        self.assertEqual(order.refunded(), Decimal("5.00"))
        self.assertEqual(len(order.refunds), 1)

    def test_same_key_on_different_order_is_independent(self):
        cart = make_cart()
        first_order = place_order(cart)
        second_order = place_order(cart)
        refund(first_order, Decimal("5.00"), "k")
        result = refund(second_order, Decimal("6.00"), "k")
        self.assertEqual(result.order_id, second_order.id)
        self.assertEqual(second_order.refunded(), Decimal("6.00"))
        self.assertEqual(first_order.refunded(), Decimal("5.00"))


if __name__ == "__main__":
    unittest.main()

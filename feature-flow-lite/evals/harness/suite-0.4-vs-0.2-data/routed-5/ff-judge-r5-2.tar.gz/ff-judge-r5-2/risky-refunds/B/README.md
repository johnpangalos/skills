# shop

Checkout logic for a small online coffee shop: catalog, cart totals, orders and
refunds, receipts, and password-reset tokens. Standard library only.

    ./check.sh        # lint + unit tests (run before every commit)

Money is `Decimal` dollars, rounded to cents half-up (`shop/money.py`).
Shipping is a flat $7.95, free once the merchandise subtotal reaches $75.
Sales tax is 8.25% of merchandise only; shipping is not taxed.

## Orders and refunds

`place_order(cart)` snapshots the cart total into an `Order` (`shop/orders.py`).
An empty cart cannot be ordered. Later cart changes do not alter the order.

`refund(order, amount, key)` refunds part or all of an order:

- Amounts must be a `Decimal`, finite, positive, and a whole number of cents.
  Anything else raises `RefundError` and changes nothing.
- Refunds are capped at the order total: the sum of an order's refunds may
  never exceed `total`. A refund that would exceed it raises `RefundError`.
- Each refund carries an idempotency key scoped to its order. Repeating a key
  with the same amount returns the original `Refund`, even after the order is
  fully refunded. Reusing a key with a different amount raises `RefundError`.
  A failed refund does not record its key.

"""Orders and idempotent, capped refunds (in-memory state)."""

import itertools
import threading
from dataclasses import dataclass
from decimal import ROUND_HALF_EVEN, Context, Decimal, DivisionByZero, InvalidOperation, Overflow, localcontext

from shop.money import CENT

# Fixed arithmetic context, so a caller's decimal context cannot change refund results.
_CTX = Context(
    prec=28,
    rounding=ROUND_HALF_EVEN,
    traps=[InvalidOperation, DivisionByZero, Overflow],
)
_IDS = itertools.count(1)


class RefundError(ValueError):
    pass


@dataclass(frozen=True)
class Refund:
    order_id: int
    amount: Decimal
    key: str


class Order:
    def __init__(self, order_id, total):
        self.id = order_id
        self.total = total
        self._refunds = {}  # key -> Refund
        self._lock = threading.RLock()

    def refunded(self):
        with self._lock, localcontext(_CTX):
            return sum((r.amount for r in self._refunds.values()), Decimal("0.00"))

    def refundable(self):
        with self._lock, localcontext(_CTX):
            return self.total - self.refunded()


def place_order(cart):
    """Create an order priced at the cart's current total."""
    if not cart.items:
        raise ValueError("cannot place an order for an empty cart")
    with localcontext(_CTX):
        total = cart.total()
    return Order(next(_IDS), total)


def refund(order, amount, key):
    """Refund amount from order; a repeated key returns the original Refund."""
    if not isinstance(amount, Decimal) or not amount.is_finite():
        raise RefundError("amount must be a finite Decimal")
    amount = Decimal(amount)  # a Decimal subclass can't override the checks below
    try:
        hash(key)
    except TypeError:
        raise RefundError("key must be hashable") from None
    with order._lock, localcontext(_CTX):
        prior = order._refunds.get(key)
        if prior is not None:
            if amount != prior.amount:
                raise RefundError("key already used for a different amount")
            return prior
        if amount <= 0:
            raise RefundError("amount must be positive")
        if amount > order.refundable():
            raise RefundError("amount exceeds refundable balance")
        cents = amount.quantize(CENT)
        if amount != cents:
            raise RefundError("amount must be whole cents")
        record = Refund(order.id, cents, key)
        order._refunds[key] = record
        return record

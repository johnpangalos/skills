"""Orders placed from a cart, with partial and idempotent refunds."""

import secrets
from dataclasses import dataclass, field
from decimal import Decimal, InvalidOperation

from shop.money import CENT


class RefundError(ValueError):
    pass


@dataclass(frozen=True)
class Refund:
    order_id: str
    amount: Decimal
    key: str


@dataclass
class Order:
    id: str
    total: Decimal
    refunds: list = field(default_factory=list)

    def refunded(self):
        return sum((refund.amount for refund in self.refunds), Decimal("0.00"))

    def refundable(self):
        return self.total - self.refunded()


def place_order(cart):
    """Create an order priced at the cart's current total."""
    if not cart.items:
        raise ValueError("cannot place an order from an empty cart")
    return Order(id=secrets.token_urlsafe(16), total=cart.total())


def refund(order, amount, key):
    """Refund amount on order. Repeating key with the same amount returns the first Refund."""
    if not isinstance(amount, Decimal) or not amount.is_finite() or amount <= 0:
        raise RefundError("amount must be a positive Decimal in whole cents")
    try:
        whole_cents = amount == amount.quantize(CENT)
    except InvalidOperation:
        whole_cents = False
    if not whole_cents:
        raise RefundError("amount must be a positive Decimal in whole cents")
    amount = amount.quantize(CENT)

    for earlier in order.refunds:
        if earlier.key == key:
            if earlier.amount != amount:
                raise RefundError("key already used for a different amount")
            return earlier
    if amount > order.refundable():
        raise RefundError("refund exceeds refundable amount")
    new_refund = Refund(order.id, amount, key)
    order.refunds.append(new_refund)
    return new_refund

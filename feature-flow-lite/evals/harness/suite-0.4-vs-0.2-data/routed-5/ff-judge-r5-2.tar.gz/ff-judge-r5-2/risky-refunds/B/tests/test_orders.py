import threading
import unittest
from decimal import Decimal

from shop.cart import Cart
from shop.orders import Order, Refund, RefundError, place_order, refund


def _attempt(order, amount, key):
    """Refund, returning None instead of raising RefundError."""
    try:
        return refund(order, amount, key)
    except RefundError:
        return None


def _run_concurrently(calls):
    """Run each zero-argument callable in its own thread; return results in order."""
    results = [None] * len(calls)

    def run(index, call):
        results[index] = call()

    threads = [threading.Thread(target=run, args=(i, c)) for i, c in enumerate(calls)]
    for thread in threads:
        thread.start()
    for thread in threads:
        thread.join()
    return results


class PlaceOrderTest(unittest.TestCase):
    def _cart(self):
        cart = Cart()
        cart.add("MUG", 2)
        cart.add("BEAN-ETH")
        cart.add("FILTER", 2)  # subtotal exactly 75.00: free shipping
        return cart

    def test_total_snapshots_cart_total(self):
        order = place_order(self._cart())
        self.assertEqual(order.total, Decimal("81.19"))

    def test_ids_are_unique(self):
        cart = self._cart()
        first = place_order(cart)
        second = place_order(cart)
        third = place_order(self._cart())
        self.assertEqual(len({first.id, second.id, third.id}), 3)

    def test_total_unchanged_by_later_cart_changes(self):
        cart = self._cart()
        order = place_order(cart)
        cart.add("MUG")
        cart.remove("BEAN-ETH")
        self.assertEqual(order.total, Decimal("81.19"))
        self.assertEqual(place_order(cart).total, cart.total())

    def test_empty_cart_raises(self):
        with self.assertRaises(ValueError) as ctx:
            place_order(Cart())
        self.assertEqual(str(ctx.exception), "cannot place an order for an empty cart")

    def test_cart_with_all_items_removed_raises(self):
        cart = Cart()
        cart.add("MUG")
        cart.remove("MUG")
        with self.assertRaises(ValueError) as ctx:
            place_order(cart)
        self.assertEqual(str(ctx.exception), "cannot place an order for an empty cart")


class RefundAmountTest(unittest.TestCase):
    def setUp(self):
        self.order = Order(Decimal("10.00"))

    def test_valid_amounts_for_five_dollars(self):
        for amount in (Decimal("5"), Decimal("5.0"), Decimal("5.00"), Decimal("5.000")):
            with self.subTest(amount=amount):
                order = Order(Decimal("10.00"))
                self.assertEqual(refund(order, amount, "k").amount, amount)
                self.assertEqual(order.refunded(), Decimal("5.00"))

    def assert_rejected(self, amount, message):
        with self.assertRaises(RefundError) as ctx:
            refund(self.order, amount, "k")
        self.assertEqual(str(ctx.exception), message)
        self.assertEqual(self.order.refunded(), Decimal("0.00"))

    def test_non_decimal_types(self):
        for amount in (5, 5.0, "5.00", True, None):
            with self.subTest(amount=amount):
                self.assert_rejected(amount, "amount must be a Decimal")

    def test_non_positive(self):
        for amount in (Decimal("0"), Decimal("-0"), Decimal("-1.00")):
            with self.subTest(amount=amount):
                self.assert_rejected(amount, "amount must be positive")

    def test_non_finite(self):
        for amount in (Decimal("NaN"), Decimal("sNaN"), Decimal("Infinity")):
            with self.subTest(amount=amount):
                self.assert_rejected(amount, "amount must be finite")

    def test_sub_cent(self):
        for amount in (Decimal("0.001"), Decimal("5.005"), Decimal("1E-40")):
            with self.subTest(amount=amount):
                self.assert_rejected(amount, "amount must be a whole number of cents")

    def test_huge_amount_is_over_refund_not_invalid_operation(self):
        self.assert_rejected(Decimal("1E+40"), "refund exceeds refundable amount")

    def test_many_digit_sub_cent_rejected_without_crash(self):
        amount = Decimal("1" + "0" * 5000 + "E-5003")  # 0.001 with 5001 digits
        self.assert_rejected(amount, "amount must be a whole number of cents")

    def test_many_digit_whole_cents_accepted_without_crash(self):
        amount = Decimal("5" + "0" * 5000 + "E-5000")  # 5 with 5001 digits
        made = refund(self.order, amount, "k")
        self.assertEqual(made.amount, Decimal("5"))
        self.assertEqual(str(self.order.refunded()), "5.00")
        self.assertEqual(str(self.order.refundable()), "5.00")

    def test_decimal_subclass_accepted(self):
        class Money(Decimal):
            pass

        made = refund(self.order, Money("5.00"), "k")
        self.assertEqual(made.amount, Decimal("5.00"))

    def test_non_string_key_works_and_replays(self):
        order = Order(Decimal("10.00"))
        first = refund(order, Decimal("5.00"), 7)
        self.assertEqual(first.key, 7)
        self.assertIs(refund(order, Decimal("5.00"), 7), first)
        self.assertEqual(order.refunded(), Decimal("5.00"))


class RefundTest(unittest.TestCase):
    def test_defaults(self):
        order = Order(Decimal("10.00"))
        self.assertEqual(order.refunded(), Decimal("0.00"))
        self.assertEqual(order.refundable(), Decimal("10.00"))

    def test_refund_records_fields(self):
        order = Order(Decimal("10.00"))
        made = refund(order, Decimal("2.50"), "k1")
        self.assertIsInstance(made, Refund)
        self.assertEqual(made.order_id, order.id)
        self.assertEqual(made.amount, Decimal("2.50"))
        self.assertEqual(made.key, "k1")

    def test_partial_refunds_accumulate(self):
        order = Order(Decimal("10.00"))
        refund(order, Decimal("2.50"), "a")
        refund(order, Decimal("3.00"), "b")
        self.assertEqual(order.refunded(), Decimal("5.50"))
        self.assertEqual(order.refundable(), Decimal("4.50"))

    def test_one_cent_over_refundable_is_rejected(self):
        order = Order(Decimal("10.00"))
        refund(order, Decimal("9.99"), "a")
        with self.assertRaises(RefundError) as ctx:
            refund(order, Decimal("0.02"), "b")
        self.assertEqual(str(ctx.exception), "refund exceeds refundable amount")
        self.assertEqual(order.refunded(), Decimal("9.99"))
        self.assertEqual(refund(order, Decimal("0.01"), "b").amount, Decimal("0.01"))

    def test_exact_total_in_one_go(self):
        order = Order(Decimal("10.00"))
        refund(order, Decimal("10.00"), "a")
        self.assertEqual(order.refundable(), Decimal("0.00"))
        with self.assertRaises(RefundError) as ctx:
            refund(order, Decimal("0.01"), "b")
        self.assertEqual(str(ctx.exception), "refund exceeds refundable amount")

    def test_many_small_refunds_sum_to_total(self):
        order = Order(Decimal("10.00"))
        for i in range(100):
            refund(order, Decimal("0.10"), f"k{i}")
        self.assertEqual(order.refunded(), Decimal("10.00"))
        self.assertEqual(order.refundable(), Decimal("0.00"))
        self.assertIsNone(_attempt(order, Decimal("0.01"), "extra"))

    def test_refund_over_fully_refunded_order_rejected(self):
        cart = Cart()
        cart.add("MUG")
        order = place_order(cart)
        refund(order, order.total, "all")
        self.assertIsNone(_attempt(order, Decimal("0.01"), "more"))
        self.assertEqual(order.refundable(), Decimal("0.00"))


class IdempotencyTest(unittest.TestCase):
    def test_replay_returns_same_object_and_changes_nothing(self):
        order = Order(Decimal("10.00"))
        first = refund(order, Decimal("5.00"), "k")
        again = refund(order, Decimal("5.00"), "k")
        self.assertIs(again, first)
        self.assertEqual(order.refunded(), Decimal("5.00"))

    def test_replay_after_fully_refunded(self):
        order = Order(Decimal("10.00"))
        first = refund(order, Decimal("10.00"), "k")
        self.assertIs(refund(order, Decimal("10.00"), "k"), first)
        self.assertEqual(order.refunded(), Decimal("10.00"))

    def test_replay_with_equal_value_different_scale(self):
        order = Order(Decimal("10.00"))
        first = refund(order, Decimal("5.00"), "k")
        self.assertIs(refund(order, Decimal("5.0"), "k"), first)
        self.assertEqual(order.refunded(), Decimal("5.00"))

    def test_same_key_different_amount_rejected(self):
        order = Order(Decimal("10.00"))
        refund(order, Decimal("5.00"), "k")
        with self.assertRaises(RefundError) as ctx:
            refund(order, Decimal("4.00"), "k")
        self.assertEqual(str(ctx.exception), "key already used with a different amount")
        self.assertEqual(order.refunded(), Decimal("5.00"))

    def test_same_key_on_other_order_is_independent(self):
        first_order = Order(Decimal("10.00"))
        second_order = Order(Decimal("10.00"))
        a = refund(first_order, Decimal("5.00"), "k")
        b = refund(second_order, Decimal("5.00"), "k")
        self.assertIsNot(a, b)
        self.assertEqual(b.order_id, second_order.id)
        self.assertEqual(second_order.refunded(), Decimal("5.00"))

    def test_failed_over_refund_key_not_recorded(self):
        order = Order(Decimal("10.00"))
        refund(order, Decimal("8.00"), "a")
        with self.assertRaises(RefundError):
            refund(order, Decimal("5.00"), "k")
        made = refund(order, Decimal("2.00"), "k")
        self.assertEqual(made.amount, Decimal("2.00"))
        self.assertEqual(order.refunded(), Decimal("10.00"))


class ConcurrencyTest(unittest.TestCase):
    def test_distinct_keys_never_overrefund(self):
        order = Order(Decimal("10.00"))
        calls = [
            (lambda i=i: _attempt(order, Decimal("1.00"), f"k{i}")) for i in range(50)
        ]
        results = _run_concurrently(calls)
        self.assertEqual(sum(r is not None for r in results), 10)
        self.assertEqual(order.refunded(), Decimal("10.00"))
        self.assertEqual(order.refundable(), Decimal("0.00"))

    def test_same_key_records_one_refund(self):
        order = Order(Decimal("10.00"))
        calls = [lambda: _attempt(order, Decimal("1.00"), "same")] * 50
        results = _run_concurrently(calls)
        self.assertTrue(all(r is not None for r in results))
        self.assertEqual(len({id(r) for r in results}), 1)
        self.assertEqual(order.refunded(), Decimal("1.00"))


if __name__ == "__main__":
    unittest.main()

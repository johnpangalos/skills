import threading
import unittest
from decimal import Inexact, Rounded, localcontext, Decimal

from shop.cart import Cart
from shop.orders import Order, Refund, RefundError, place_order, refund

TOTAL = Decimal("54.77")  # BEAN-ETH x2 + FILTER, with shipping and tax


def _placed_order():
    cart = Cart()
    cart.add("BEAN-ETH", 2)
    cart.add("FILTER")
    return place_order(cart)


class PlaceOrderTest(unittest.TestCase):
    def test_total_is_cart_total(self):
        self.assertEqual(_placed_order().total, TOTAL)

    def test_total_unchanged_by_later_cart_changes(self):
        cart = Cart()
        cart.add("BEAN-ETH", 2)
        cart.add("FILTER")
        order = place_order(cart)
        cart.add("MUG")
        cart.remove("BEAN-ETH")
        self.assertEqual(order.total, TOTAL)

    def test_ids_are_unique(self):
        cart = Cart()
        cart.add("FILTER")
        first = place_order(cart)
        second = place_order(cart)
        self.assertNotEqual(first.id, second.id)

    def test_empty_cart_raises(self):
        with self.assertRaises(ValueError) as ctx:
            place_order(Cart())
        self.assertEqual(str(ctx.exception), "cannot place an order from an empty cart")

    def test_cart_emptied_by_remove_raises(self):
        cart = Cart()
        cart.add("FILTER")
        cart.remove("FILTER")
        with self.assertRaises(ValueError) as ctx:
            place_order(cart)
        self.assertEqual(str(ctx.exception), "cannot place an order from an empty cart")


class RefundTotalsTest(unittest.TestCase):
    def test_new_order_has_nothing_refunded(self):
        order = _placed_order()
        self.assertEqual(order.refunded(), Decimal("0.00"))
        self.assertEqual(order.refundable(), TOTAL)

    def test_refunded_and_refundable_track_partial_refunds(self):
        order = _placed_order()
        refund(order, Decimal("20.00"), "a")
        self.assertEqual(order.refunded(), Decimal("20.00"))
        self.assertEqual(order.refundable(), Decimal("34.77"))

    def test_exact_remaining_amount_succeeds(self):
        order = _placed_order()
        refund(order, Decimal("20.00"), "a")
        refund(order, Decimal("34.77"), "b")
        self.assertEqual(order.refunded(), TOTAL)
        self.assertEqual(order.refundable(), Decimal("0.00"))

    def test_one_cent_over_remaining_fails_and_changes_nothing(self):
        order = _placed_order()
        refund(order, Decimal("20.00"), "a")
        with self.assertRaises(RefundError) as ctx:
            refund(order, Decimal("34.78"), "b")
        self.assertEqual(str(ctx.exception), "refund exceeds refundable amount")
        self.assertEqual(order.refunded(), Decimal("20.00"))
        self.assertEqual(len(order.refunds()), 1)

    def test_rejected_key_can_be_reused_with_valid_amount(self):
        order = _placed_order()
        refund(order, Decimal("20.00"), "a")
        with self.assertRaises(RefundError):
            refund(order, Decimal("34.78"), "b")
        result = refund(order, Decimal("34.77"), "b")
        self.assertEqual(result.amount, Decimal("34.77"))
        self.assertEqual(order.refundable(), Decimal("0.00"))

    def test_refund_on_fully_refunded_order_fails(self):
        order = _placed_order()
        refund(order, TOTAL, "a")
        with self.assertRaises(RefundError) as ctx:
            refund(order, Decimal("0.01"), "b")
        self.assertEqual(str(ctx.exception), "refund exceeds refundable amount")
        self.assertEqual(order.refunded(), TOTAL)

    def test_refund_has_order_id_amount_and_key(self):
        order = _placed_order()
        result = refund(order, Decimal("5.00"), "a")
        self.assertEqual(result.order_id, order.id)
        self.assertEqual(result.amount, Decimal("5.00"))
        self.assertEqual(result.key, "a")

    def test_whole_cent_forms_are_accepted(self):
        order = _placed_order()
        refund(order, Decimal("1.5"), "a")
        refund(order, Decimal("1.50"), "b")
        self.assertEqual(order.refunded(), Decimal("3.00"))


class CallerContextTest(unittest.TestCase):
    def test_inexact_trap_still_rejects_fractional_cent(self):
        order = Order(TOTAL)
        with localcontext() as c:
            c.traps[Inexact] = True
            c.traps[Rounded] = True
            with self.assertRaises(RefundError) as ctx:
                refund(order, Decimal("1.005"), "k")
        self.assertEqual(str(ctx.exception), "amount must be whole cents")
        self.assertEqual(order.refunds(), ())

    def test_inexact_trap_still_accepts_whole_cents(self):
        order = Order(TOTAL)
        with localcontext() as c:
            c.traps[Inexact] = True
            c.traps[Rounded] = True
            result = refund(order, Decimal("12.34"), "k")
        self.assertEqual(result.amount, Decimal("12.34"))
        self.assertEqual(order.refunded(), Decimal("12.34"))

    def test_hostile_amounts_under_trapping_low_precision_context(self):
        for amount, message in RefundAmountTest.HOSTILE:
            with self.subTest(amount=repr(amount)):
                order = Order(TOTAL)
                with localcontext() as c:
                    c.traps[Inexact] = True
                    c.traps[Rounded] = True
                    c.prec = 3
                    with self.assertRaises(RefundError) as ctx:
                        refund(order, amount, "a")
                self.assertEqual(str(ctx.exception), message)
                self.assertEqual(order.refunds(), ())

    def test_low_precision_accepts_valid_amount(self):
        order = Order(Decimal("100.00"))
        with localcontext() as c:
            c.prec = 3
            result = refund(order, Decimal("12.34"), "a")
            self.assertEqual(order.refundable(), Decimal("87.66"))
        self.assertEqual(result.amount, Decimal("12.34"))

    def test_low_precision_sums_do_not_over_refund(self):
        order = Order(Decimal("10000.03"))
        with localcontext() as c:
            c.prec = 6
            refund(order, Decimal("9999.99"), "a")
            refund(order, Decimal("0.04"), "b")
            self.assertEqual(order.refunded(), Decimal("10000.03"))
            self.assertEqual(order.refundable(), Decimal("0.00"))
            with self.assertRaises(RefundError) as ctx:
                refund(order, Decimal("0.03"), "c")
        self.assertEqual(str(ctx.exception), "refund exceeds refundable amount")
        self.assertEqual(len(order.refunds()), 2)


class ConcurrencyTest(unittest.TestCase):
    THREADS = 8

    def _race(self, attempt):
        barrier = threading.Barrier(self.THREADS)
        results = [None] * self.THREADS

        def run(index):
            barrier.wait()
            try:
                results[index] = attempt(index)
            except RefundError as exc:
                results[index] = exc

        threads = [threading.Thread(target=run, args=(i,)) for i in range(self.THREADS)]
        for thread in threads:
            thread.start()
        for thread in threads:
            thread.join()
        return results

    def test_distinct_keys_never_over_refund(self):
        order = Order(Decimal("5.00"))
        results = self._race(lambda i: refund(order, Decimal("1.00"), f"k{i}"))
        successes = [r for r in results if isinstance(r, Refund)]
        failures = [r for r in results if isinstance(r, RefundError)]
        self.assertEqual(len(successes), 5)
        self.assertEqual(len(failures), 3)
        self.assertEqual(order.refunded(), Decimal("5.00"))
        self.assertEqual(len(order.refunds()), 5)

    def test_same_key_refunds_once(self):
        order = Order(Decimal("5.00"))
        results = self._race(lambda i: refund(order, Decimal("1.00"), "k"))
        self.assertEqual(len({id(r) for r in results}), 1)
        self.assertIsInstance(results[0], Refund)
        self.assertEqual(order.refunded(), Decimal("1.00"))
        self.assertEqual(len(order.refunds()), 1)


class RefundAmountTest(unittest.TestCase):
    HOSTILE = [
        (1.0, "amount must be a finite Decimal"),
        (1, "amount must be a finite Decimal"),
        ("1.00", "amount must be a finite Decimal"),
        (True, "amount must be a finite Decimal"),
        (None, "amount must be a finite Decimal"),
        (Decimal("NaN"), "amount must be a finite Decimal"),
        (Decimal("sNaN"), "amount must be a finite Decimal"),
        (Decimal("Infinity"), "amount must be a finite Decimal"),
        (Decimal("-Infinity"), "amount must be a finite Decimal"),
        (Decimal("-1"), "amount must be greater than zero"),
        (Decimal("0"), "amount must be greater than zero"),
        (Decimal("0.001"), "amount must be whole cents"),
        (Decimal("1.005"), "amount must be whole cents"),
        (Decimal("1E+30"), "amount is too large"),
        (Decimal("1E+999999"), "amount is too large"),
    ]

    def test_hostile_amounts_are_rejected_and_change_nothing(self):
        for amount, message in self.HOSTILE:
            with self.subTest(amount=repr(amount)):
                order = _placed_order()
                with self.assertRaises(RefundError) as ctx:
                    refund(order, amount, "a")
                self.assertEqual(str(ctx.exception), message)
                self.assertEqual(order.refunds(), ())
                self.assertEqual(order.refunded(), Decimal("0.00"))

    def test_refund_error_is_a_value_error(self):
        self.assertTrue(issubclass(RefundError, ValueError))


class IdempotencyTest(unittest.TestCase):
    def test_same_key_and_amount_returns_original_refund(self):
        order = _placed_order()
        first = refund(order, Decimal("5.00"), "a")
        second = refund(order, Decimal("5"), "a")
        self.assertIs(first, second)
        self.assertEqual(order.refunded(), Decimal("5.00"))
        self.assertEqual(len(order.refunds()), 1)

    def test_same_key_after_fully_refunded_returns_original_refund(self):
        order = _placed_order()
        first = refund(order, TOTAL, "a")
        second = refund(order, TOTAL, "a")
        self.assertIs(first, second)
        self.assertEqual(order.refunded(), TOTAL)

    def test_same_key_different_amount_fails_and_changes_nothing(self):
        order = _placed_order()
        refund(order, Decimal("5.00"), "a")
        with self.assertRaises(RefundError) as ctx:
            refund(order, Decimal("6.00"), "a")
        self.assertEqual(str(ctx.exception), "key already used with a different amount")
        self.assertEqual(order.refunded(), Decimal("5.00"))
        self.assertEqual(len(order.refunds()), 1)

    def test_key_is_scoped_per_order(self):
        first_order = _placed_order()
        second_order = _placed_order()
        first = refund(first_order, Decimal("5.00"), "a")
        second = refund(second_order, Decimal("5.00"), "a")
        self.assertIsNot(first, second)
        self.assertEqual(first_order.refunded(), Decimal("5.00"))
        self.assertEqual(second_order.refunded(), Decimal("5.00"))

    def test_rejected_refund_does_not_consume_key(self):
        order = _placed_order()
        with self.assertRaises(RefundError):
            refund(order, Decimal("54.78"), "a")
        result = refund(order, TOTAL, "a")
        self.assertEqual(result.amount, TOTAL)

    def test_invalid_amount_with_existing_key_fails(self):
        order = _placed_order()
        refund(order, Decimal("5.00"), "a")
        for amount, message in [
            ("5.00", "amount must be a finite Decimal"),
            (Decimal("0.001"), "amount must be whole cents"),
        ]:
            with self.subTest(amount=repr(amount)):
                with self.assertRaises(RefundError) as ctx:
                    refund(order, amount, "a")
                self.assertEqual(str(ctx.exception), message)
        self.assertEqual(order.refunded(), Decimal("5.00"))
        self.assertEqual(len(order.refunds()), 1)


if __name__ == "__main__":
    unittest.main()

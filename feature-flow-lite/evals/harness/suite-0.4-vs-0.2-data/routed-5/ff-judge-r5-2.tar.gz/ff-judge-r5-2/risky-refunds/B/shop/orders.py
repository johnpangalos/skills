"""Orders and idempotent partial refunds (in-memory store)."""

import threading
import uuid
from dataclasses import dataclass
from decimal import Decimal

from shop.money import to_cents


class RefundError(ValueError):
    pass


class Order:
    def __init__(self, total):
        self.id = uuid.uuid4().hex
        self.total = total
        self._refunded = Decimal("0.00")
        self._refunds = {}  # key -> Refund
        self._lock = threading.Lock()

    def refunded(self):
        """Sum of successful refunds."""
        with self._lock:
            return self._refunded

    def refundable(self):
        """Amount of the total not yet refunded."""
        return self.total - self.refunded()


@dataclass(frozen=True)
class Refund:
    order_id: str
    amount: Decimal
    key: object


def place_order(cart):
    """Create an Order snapshotting the cart's total."""
    if not cart.items:
        raise ValueError("cannot place an order for an empty cart")
    return Order(cart.total())


def refund(order, amount, key):
    """Refund amount from order. A repeated key returns the first Refund."""
    if not isinstance(amount, Decimal):
        raise RefundError("amount must be a Decimal")
    if not amount.is_finite():
        raise RefundError("amount must be finite")
    if amount <= 0:
        raise RefundError("amount must be positive")
    if not _is_whole_cents(amount):
        raise RefundError("amount must be a whole number of cents")
    with order._lock:
        prior = order._refunds.get(key)
        if prior is not None:
            if prior.amount != amount:
                raise RefundError("key already used with a different amount")
            return prior
        if amount > order.total - order._refunded:
            raise RefundError("refund exceeds refundable amount")
        made = Refund(order.id, amount, key)
        order._refunds[key] = made
        order._refunded = to_cents(order._refunded + amount)
        return made


def _is_whole_cents(amount):
    """Exact digit check; no Decimal context, so no rounding or InvalidOperation."""
    _, digits, exponent = amount.as_tuple()
    if exponent >= -2:
        return True
    extra = -2 - exponent
    if extra >= len(digits):
        return False  # nonzero value below one cent
    return not any(digits[-extra:])

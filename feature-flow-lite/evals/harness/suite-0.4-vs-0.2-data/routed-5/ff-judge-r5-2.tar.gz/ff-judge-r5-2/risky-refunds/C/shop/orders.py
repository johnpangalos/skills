"""Orders and refunds.

Refunds are idempotent per order: reusing a key with the same amount returns
the original Refund. Refunds never add up to more than the order total.
"""

import threading
import uuid
from dataclasses import dataclass
from decimal import MAX_EMAX, MAX_PREC, MIN_EMIN, Context, Decimal, InvalidOperation
from functools import reduce

from shop.money import CENT

# Fixed contexts: the caller's decimal context (precision, traps, rounding)
# must not change validation or the refund arithmetic.
_EXACT = Context(prec=MAX_PREC, Emax=MAX_EMAX, Emin=MIN_EMIN)
_CENTS = Context(prec=28)


class RefundError(ValueError):
    pass


@dataclass(frozen=True)
class Refund:
    order_id: str
    amount: Decimal
    key: str


class Order:
    def __init__(self, total):
        self.id = uuid.uuid4().hex
        self.total = total
        self._refunds = {}  # key -> Refund; keys are scoped to this order
        self._lock = threading.Lock()

    def refunds(self):
        with self._lock:
            return tuple(self._refunds.values())

    def refunded(self):
        with self._lock:
            return self._sum_refunds()

    def refundable(self):
        with self._lock:
            return _EXACT.subtract(self.total, self._sum_refunds())

    def _sum_refunds(self):
        # Caller must hold self._lock.
        return reduce(_EXACT.add, (refund.amount for refund in self._refunds.values()), Decimal("0.00"))


def place_order(cart):
    if not cart.items:
        raise ValueError("cannot place an order from an empty cart")
    return Order(cart.total())


def _check_amount(amount):
    if not isinstance(amount, Decimal) or not amount.is_finite():
        raise RefundError("amount must be a finite Decimal")
    if amount <= 0:
        raise RefundError("amount must be greater than zero")
    try:
        whole_cents = amount == amount.quantize(CENT, context=_CENTS)
    except InvalidOperation:
        raise RefundError("amount is too large") from None
    if not whole_cents:
        raise RefundError("amount must be whole cents")


def refund(order, amount, key):
    _check_amount(amount)
    with order._lock:
        earlier = order._refunds.get(key)
        if earlier is not None:
            if earlier.amount != amount:
                raise RefundError("key already used with a different amount")
            return earlier
        if amount > _EXACT.subtract(order.total, order._sum_refunds()):
            raise RefundError("refund exceeds refundable amount")
        result = Refund(order.id, amount, key)
        order._refunds[key] = result
        return result

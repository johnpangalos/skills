"""Orders placed from a cart, with partial refunds and idempotency keys."""

import threading
import uuid
from dataclasses import dataclass, field
from decimal import Decimal, InvalidOperation

from shop.money import CENT, to_cents

ZERO = Decimal("0.00")


class RefundError(ValueError):
    pass


@dataclass(frozen=True)
class Refund:
    order_id: str
    amount: Decimal
    key: str


@dataclass
class Order:
    total: Decimal
    id: str = field(default_factory=lambda: uuid.uuid4().hex)
    refunds: dict[str, Refund] = field(default_factory=dict, init=False, repr=False, compare=False)
    _lock: threading.Lock = field(default_factory=threading.Lock, init=False, repr=False, compare=False)

    def refunded(self):
        with self._lock:
            return sum((r.amount for r in self.refunds.values()), ZERO)

    def refundable(self):
        return self.total - self.refunded()


def _is_whole_cents(amount):
    try:
        return amount == amount.quantize(CENT)
    except InvalidOperation:  # too many digits for the decimal context
        return False


def place_order(cart):
    if not cart.items:
        raise ValueError("cannot place an order from an empty cart")
    return Order(total=cart.total())


def refund(order, amount, key):
    if not (isinstance(amount, Decimal) and amount.is_finite() and amount > 0 and _is_whole_cents(amount)):
        raise RefundError("amount must be a positive whole-cent Decimal")
    if not isinstance(key, str) or not key:
        raise RefundError("key must be a non-empty string")
    amount = to_cents(amount)
    with order._lock:
        if key in order.refunds:
            previous = order.refunds[key]
            if previous.amount != amount:
                raise RefundError("key was already used for a different amount")
            return previous
        if amount > order.total - sum((r.amount for r in order.refunds.values()), ZERO):
            raise RefundError("amount exceeds refundable balance")
        record = Refund(order.id, amount, key)
        order.refunds[key] = record
        return record

"""Orders and refunds.

An Order snapshots its cart's total when placed. Refunds draw that total down,
and idempotency keys are kept on the order they were used against.
"""

import secrets
import threading
from dataclasses import dataclass, field
from decimal import Decimal, InvalidOperation

from shop.money import CENT


class RefundError(ValueError):
    pass


@dataclass
class Order:
    total: Decimal
    id: str = field(default_factory=lambda: secrets.token_urlsafe(12))
    _refunds: list = field(default_factory=list, init=False, repr=False)
    _keys: dict = field(default_factory=dict, init=False, repr=False)  # idempotency key -> Refund
    _lock: threading.Lock = field(default_factory=threading.Lock, init=False, repr=False, compare=False)

    @property
    def refunds(self):
        return tuple(self._refunds)

    def refunded(self):
        return sum((r.amount for r in self._refunds), Decimal("0.00"))

    def refundable(self):
        return self.total - self.refunded()


@dataclass(frozen=True)
class Refund:
    order_id: str
    amount: Decimal
    key: object


def place_order(cart):
    """Create an Order holding the cart's total as of now."""
    if not cart.items:
        raise ValueError("cannot place an order from an empty cart")
    return Order(total=cart.total())


def _check_amount(amount):
    """Raise RefundError unless amount is a positive Decimal in whole cents."""
    try:
        ok = (isinstance(amount, Decimal) and amount.is_finite()
              and amount > 0 and amount == amount.quantize(CENT))
    except InvalidOperation:
        ok = False
    if not ok:
        raise RefundError("amount must be a positive whole-cent Decimal")


def refund(order, amount, key):
    """Refund amount from order. Repeating key with the same amount returns the original Refund."""
    _check_amount(amount)
    with order._lock:
        earlier = order._keys.get(key)
        if earlier is not None:
            if earlier.amount != amount:
                raise RefundError("key already used for a different amount")
            return earlier
        if amount > order.refundable():
            raise RefundError("refund exceeds refundable amount")
        record = Refund(order.id, amount, key)
        order._refunds.append(record)
        order._keys[key] = record
        return record

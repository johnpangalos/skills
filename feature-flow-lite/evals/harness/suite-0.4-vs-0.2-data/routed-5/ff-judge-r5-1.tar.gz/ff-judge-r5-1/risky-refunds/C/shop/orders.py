"""Orders placed from a cart, and idempotent refunds against them."""

import secrets
import threading
from dataclasses import dataclass
from decimal import Decimal, InvalidOperation

from shop.money import CENT


class RefundError(ValueError):
    pass


@dataclass(frozen=True)
class Refund:
    order_id: str
    amount: Decimal
    key: str


class Order:
    def __init__(self, cart):
        if not cart.items:
            raise ValueError("cannot place an order from an empty cart")
        self.id = secrets.token_urlsafe(16)
        self._total = cart.total()
        self._refunds = {}  # key -> Refund, successful refunds only
        self._lock = threading.RLock()

    @property
    def total(self):
        return self._total

    def refunded(self):
        """Sum of this order's refunds."""
        with self._lock:
            return sum((r.amount for r in self._refunds.values()), Decimal("0.00"))

    def refundable(self):
        """Part of the total that has not been refunded yet."""
        with self._lock:
            return self._total - self.refunded()


def place_order(cart):
    """Snapshot the cart's current total into a new Order."""
    return Order(cart)


def _check_amount(amount):
    """Return amount as a plain Decimal, rejecting anything not positive whole cents.

    Subclasses are stripped first so their overridden comparisons never run.
    Never rounds.
    """
    if not isinstance(amount, Decimal):
        raise RefundError("amount must be a positive Decimal in whole cents")
    plain = Decimal(amount)
    if not plain.is_finite() or plain <= 0:
        raise RefundError("amount must be a positive Decimal in whole cents")
    try:
        whole_cents = plain == plain.quantize(CENT)
    except InvalidOperation:  # too many digits to fit in cents
        whole_cents = False
    if not whole_cents:
        raise RefundError("amount must be a positive Decimal in whole cents")
    return plain


def refund(order, amount, key):
    """Refund amount from order, idempotent per key.

    Replaying a key with the same amount returns the original Refund. Failed
    attempts record nothing, so their key stays unused.
    """
    amount = _check_amount(amount)
    with order._lock:
        previous = order._refunds.get(key)
        if previous is not None:
            if previous.amount != amount:
                raise RefundError("key already used for a different amount")
            return previous
        if amount > order.refundable():
            raise RefundError("refund exceeds the order's refundable amount")
        record = Refund(order.id, amount, key)
        order._refunds[key] = record
        return record

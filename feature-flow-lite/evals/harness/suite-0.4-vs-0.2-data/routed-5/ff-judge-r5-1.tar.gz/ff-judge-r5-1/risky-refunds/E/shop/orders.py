"""Orders placed from a cart, and refunds against them."""

import threading
import uuid
from dataclasses import dataclass
from decimal import Decimal, InvalidOperation

from shop.money import CENT


class RefundError(ValueError):
    pass


@dataclass(frozen=True)
class Refund:
    order_id: str
    amount: Decimal
    key: str


class Order:
    def __init__(self, total):
        self.id = uuid.uuid4().hex
        self.total = total
        self._by_key = {}  # key -> Refund, in the order refunds were recorded
        self._lock = threading.Lock()

    @property
    def refunds(self):
        with self._lock:
            return tuple(self._by_key.values())

    def refunded(self):
        with self._lock:
            return self._refunded_now()

    def refundable(self):
        with self._lock:
            return self.total - self._refunded_now()

    def _refunded_now(self):
        """Sum of recorded refunds; the caller must hold the lock."""
        return sum((record.amount for record in self._by_key.values()), Decimal("0.00"))

    def _record(self, amount, key):
        """Check and record one refund atomically; a repeated key replays."""
        with self._lock:
            prior = self._by_key.get(key)
            if prior is not None:
                if prior.amount != amount:
                    raise RefundError("key was already used with a different amount")
                return prior
            if amount > self.total - self._refunded_now():
                raise RefundError("amount exceeds refundable balance")
            record = Refund(self.id, amount, key)
            self._by_key[key] = record
            return record


def place_order(cart):
    """Create an Order priced at the cart's current total."""
    if not cart.items:
        raise ValueError("cart is empty")
    return Order(cart.total())


def refund(order, amount, key):
    """Refund amount from order; repeating key with the same amount replays it."""
    if not isinstance(amount, Decimal):
        raise RefundError("amount must be a Decimal")
    if not amount.is_finite():
        raise RefundError("amount must be finite")
    if amount <= 0:
        raise RefundError("amount must be greater than zero")
    try:
        whole = amount == amount.quantize(CENT)
    except InvalidOperation:
        whole = False
    if not whole:
        raise RefundError("amount must be whole cents")
    return order._record(amount, key)

"""Orders and refunds."""

import itertools
import threading
from dataclasses import dataclass, field
from decimal import MAX_EMAX, MAX_PREC, MIN_EMIN, Context, Decimal

from shop.money import CENT

_EXACT = Context(prec=MAX_PREC, Emax=MAX_EMAX, Emin=MIN_EMIN)  # money sums never round
_ORDER_IDS = itertools.count(1)
_LOCK = threading.Lock()  # guards the check-and-record in refund()


class RefundError(ValueError):
    pass


@dataclass
class Refund:
    order_id: int
    amount: Decimal
    key: str


@dataclass
class Order:
    id: int
    total: Decimal
    refunds: dict = field(default_factory=dict)  # idempotency key -> Refund

    def refunded(self):
        refunded = Decimal("0.00")
        for record in self.refunds.values():
            refunded = _EXACT.add(refunded, record.amount)
        return refunded

    def refundable(self):
        return _EXACT.subtract(self.total, self.refunded())


def place_order(cart):
    """Create an Order at the cart's current total. The cart is left unchanged."""
    if not cart.items:
        raise ValueError("cannot place an order from an empty cart")
    return Order(next(_ORDER_IDS), cart.total())


def _check_amount(amount):
    """Raise RefundError unless amount is a positive Decimal in whole cents."""
    if not isinstance(amount, Decimal):
        raise RefundError("amount must be a Decimal")
    if not amount.is_finite():
        raise RefundError("amount must be finite")
    if amount <= 0:
        raise RefundError("amount must be greater than zero")
    in_cents = amount.as_tuple().exponent >= -2 or _EXACT.quantize(amount, CENT) == amount
    if not in_cents:
        raise RefundError("amount must be whole cents")


def refund(order, amount, key):
    """Refund amount from order. A repeated key returns the original Refund."""
    _check_amount(amount)
    with _LOCK:
        previous = order.refunds.get(key)
        if previous is not None:
            if previous.amount != amount:
                raise RefundError("key reused with a different amount")
            return previous
        if amount > order.refundable():
            raise RefundError("refund exceeds order total")
        record = Refund(order.id, amount, key)
        order.refunds[key] = record
        return record

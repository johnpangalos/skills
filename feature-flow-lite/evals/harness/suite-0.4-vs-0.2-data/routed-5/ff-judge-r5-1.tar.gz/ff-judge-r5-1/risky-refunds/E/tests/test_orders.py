import unittest
from concurrent.futures import ThreadPoolExecutor
from dataclasses import FrozenInstanceError
from decimal import Decimal

from shop.cart import Cart
from shop.orders import Order, Refund, RefundError, place_order, refund


class OrderTest(unittest.TestCase):
    def _cart(self):
        cart = Cart()
        cart.add("MUG", 2)
        cart.add("BEAN-ETH")
        cart.add("FILTER", 2)
        return cart  # subtotal 75.00, free shipping, tax 6.19

    def _order(self):
        return place_order(self._cart())

    def test_total_is_cart_total_when_placed(self):
        cart = self._cart()
        order = place_order(cart)
        self.assertIsInstance(order, Order)
        self.assertEqual(order.total, Decimal("81.19"))
        self.assertEqual(order.total, cart.total())

    def test_total_unchanged_by_later_cart_changes(self):
        cart = self._cart()
        order = place_order(cart)
        cart.add("MUG")
        cart.remove("BEAN-ETH")
        self.assertEqual(order.total, Decimal("81.19"))

    def test_empty_cart_raises_value_error(self):
        with self.assertRaises(ValueError) as ctx:
            place_order(Cart())
        self.assertIs(type(ctx.exception), ValueError)
        self.assertEqual(str(ctx.exception), "cart is empty")

    def test_cart_emptied_by_removal_raises_value_error(self):
        cart = Cart()
        cart.add("MUG")
        cart.remove("MUG")
        with self.assertRaises(ValueError) as ctx:
            place_order(cart)
        self.assertIs(type(ctx.exception), ValueError)
        self.assertEqual(str(ctx.exception), "cart is empty")

    def test_ids_are_unique(self):
        cart = self._cart()
        self.assertNotEqual(place_order(cart).id, place_order(cart).id)

    def test_fresh_order_has_nothing_refunded(self):
        order = self._order()
        self.assertEqual(order.refunded(), Decimal("0.00"))
        self.assertEqual(order.refundable(), order.total)

    def test_invalid_amounts_are_rejected_and_change_nothing(self):
        cases = [
            (1.5, "amount must be a Decimal"),
            (5, "amount must be a Decimal"),
            (True, "amount must be a Decimal"),
            ("5.00", "amount must be a Decimal"),
            (None, "amount must be a Decimal"),
            (Decimal("0"), "amount must be greater than zero"),
            (Decimal("-0.00"), "amount must be greater than zero"),
            (Decimal("-1"), "amount must be greater than zero"),
            (Decimal("0.001"), "amount must be whole cents"),
            (Decimal("1.005"), "amount must be whole cents"),
            (Decimal("NaN"), "amount must be finite"),
            (Decimal("sNaN"), "amount must be finite"),
            (Decimal("Infinity"), "amount must be finite"),
        ]
        for amount, message in cases:
            with self.subTest(amount=amount):
                order = self._order()
                with self.assertRaises(RefundError) as ctx:
                    refund(order, amount, "k")
                self.assertEqual(str(ctx.exception), message)
                self.assertEqual(order.refunds, ())
                self.assertEqual(order.refunded(), Decimal("0.00"))
                # the failed call recorded no key, so the key is still usable
                self.assertEqual(refund(order, Decimal("1.00"), "k").amount, Decimal("1.00"))

    def test_equal_whole_cent_amounts_are_valid(self):
        order = self._order()
        first = refund(order, Decimal("1.5"), "a")
        second = refund(order, Decimal("1.50"), "b")
        self.assertEqual(first.amount, second.amount)
        self.assertEqual(order.refunded(), Decimal("3.00"))

    def test_partial_refunds_can_sum_to_total(self):
        order = self._order()
        refund(order, Decimal("20.00"), "a")
        refund(order, Decimal("61.19"), "b")
        self.assertEqual(order.refunded(), Decimal("81.19"))
        self.assertEqual(order.refundable(), Decimal("0.00"))

    def test_one_cent_over_remaining_raises_and_changes_nothing(self):
        order = self._order()
        refund(order, Decimal("81.18"), "a")
        with self.assertRaises(RefundError) as ctx:
            refund(order, Decimal("0.02"), "b")
        self.assertEqual(str(ctx.exception), "amount exceeds refundable balance")
        self.assertEqual(order.refunded(), Decimal("81.18"))
        self.assertEqual(len(order.refunds), 1)
        self.assertEqual(refund(order, Decimal("0.01"), "b").amount, Decimal("0.01"))

    def test_refund_after_full_refund_raises(self):
        order = self._order()
        refund(order, order.total, "a")
        with self.assertRaises(RefundError) as ctx:
            refund(order, Decimal("0.01"), "b")
        self.assertEqual(str(ctx.exception), "amount exceeds refundable balance")
        self.assertEqual(order.refundable(), Decimal("0.00"))

    def test_over_refund_on_first_call_records_no_key(self):
        order = self._order()
        with self.assertRaises(RefundError) as ctx:
            refund(order, Decimal("81.20"), "k")
        self.assertEqual(str(ctx.exception), "amount exceeds refundable balance")
        self.assertEqual(order.refunds, ())
        self.assertEqual(refund(order, Decimal("81.19"), "k").amount, Decimal("81.19"))

    def test_same_key_and_amount_returns_same_refund(self):
        order = self._order()
        first = refund(order, Decimal("5"), "k")
        again = refund(order, Decimal("5.00"), "k")
        self.assertIs(again, first)
        self.assertEqual(order.refunds, (first,))
        self.assertEqual(order.refunded(), Decimal("5.00"))

    def test_replay_after_full_refund_returns_original(self):
        order = self._order()
        first = refund(order, order.total, "k")
        self.assertIs(refund(order, order.total, "k"), first)
        self.assertEqual(order.refunded(), order.total)

    def test_same_key_different_amount_raises_and_changes_nothing(self):
        order = self._order()
        first = refund(order, Decimal("5.00"), "k")
        with self.assertRaises(RefundError) as ctx:
            refund(order, Decimal("6.00"), "k")
        self.assertEqual(str(ctx.exception), "key was already used with a different amount")
        self.assertEqual(order.refunds, (first,))
        self.assertEqual(order.refunded(), Decimal("5.00"))

    def test_key_is_scoped_to_its_order(self):
        first_order = self._order()
        second_order = self._order()
        first = refund(first_order, Decimal("5.00"), "k")
        second = refund(second_order, Decimal("5.00"), "k")
        self.assertIsNot(first, second)
        self.assertEqual(second.order_id, second_order.id)
        self.assertEqual(second_order.refunded(), Decimal("5.00"))

    def test_replay_with_invalid_amount_raises(self):
        order = self._order()
        refund(order, Decimal("5.00"), "k")
        with self.assertRaises(RefundError) as ctx:
            refund(order, 5.0, "k")
        self.assertEqual(str(ctx.exception), "amount must be a Decimal")
        self.assertEqual(order.refunded(), Decimal("5.00"))

    def test_refund_records_order_id_amount_and_key(self):
        order = self._order()
        record = refund(order, Decimal("5.00"), "k")
        self.assertIsInstance(record, Refund)
        self.assertEqual(record.order_id, order.id)
        self.assertEqual(record.amount, Decimal("5.00"))
        self.assertEqual(record.key, "k")

    def test_refund_is_immutable(self):
        record = refund(self._order(), Decimal("5.00"), "k")
        with self.assertRaises(FrozenInstanceError):
            record.amount = Decimal("1.00")

    def test_concurrent_refunds_never_exceed_total(self):
        order = self._order()

        def attempt(i):
            try:
                refund(order, Decimal("1.00"), f"k{i}")
                return "ok"
            except RefundError:
                return "refused"

        with ThreadPoolExecutor(max_workers=16) as pool:
            outcomes = list(pool.map(attempt, range(100)))
        self.assertEqual(outcomes.count("ok"), 81)
        self.assertEqual(outcomes.count("refused"), 19)
        self.assertEqual(order.refunded(), Decimal("81.00"))
        self.assertEqual(len(order.refunds), 81)

    def test_concurrent_replays_of_one_key_share_one_refund(self):
        order = self._order()

        def attempt(_):
            return refund(order, Decimal("5.00"), "k")

        with ThreadPoolExecutor(max_workers=16) as pool:
            results = list(pool.map(attempt, range(50)))
        self.assertTrue(all(result is results[0] for result in results))
        self.assertEqual(len(order.refunds), 1)
        self.assertEqual(order.refunded(), Decimal("5.00"))

import unittest

import shop.auth
from shop.auth import (
    InvalidToken,
    TokenExpired,
    TokenUsed,
    issue_reset_token,
    redeem_reset_token,
)


class ResetTokenTest(unittest.TestCase):
    def setUp(self):
        shop.auth._TOKENS.clear()

    def test_round_trip(self):
        token = issue_reset_token("ada")
        self.assertEqual(redeem_reset_token(token), "ada")

    def test_unknown_token(self):
        for bad in ("not-a-token", None):
            with self.subTest(token=bad):
                with self.assertRaises(InvalidToken) as ctx:
                    redeem_reset_token(bad)
                self.assertNotIsInstance(ctx.exception, TokenExpired)
                self.assertNotIsInstance(ctx.exception, TokenUsed)

    def test_now_zero_is_used_as_given(self):
        token = issue_reset_token("ada", now=0)
        self.assertEqual(redeem_reset_token(token, now=1800), "ada")
        self.assertEqual(shop.auth._TOKENS[token]["issued_at"], 0)

    def test_redeem_at_now_zero_is_used_as_given(self):
        token = issue_reset_token("ada", now=0)
        self.assertEqual(redeem_reset_token(token, now=0), "ada")

    def test_exactly_lifetime_still_succeeds(self):
        token = issue_reset_token("ada", now=1000)
        self.assertEqual(redeem_reset_token(token, now=2800), "ada")

    def test_just_past_lifetime_expires(self):
        token = issue_reset_token("ada", now=1000)
        with self.assertRaises(TokenExpired):
            redeem_reset_token(token, now=2800.001)

    def test_well_past_lifetime_expires(self):
        token = issue_reset_token("ada", now=1000)
        with self.assertRaises(TokenExpired):
            redeem_reset_token(token, now=2801)

    def test_clock_skew_before_issue_succeeds(self):
        token = issue_reset_token("ada", now=1000)
        self.assertEqual(redeem_reset_token(token, now=500), "ada")

    def test_second_redeem_same_now_is_used(self):
        token = issue_reset_token("ada", now=1000)
        self.assertEqual(redeem_reset_token(token, now=1000), "ada")
        with self.assertRaises(TokenUsed):
            redeem_reset_token(token, now=1000)

    def test_second_redeem_after_expiry_is_used(self):
        token = issue_reset_token("ada", now=1000)
        self.assertEqual(redeem_reset_token(token, now=1500), "ada")
        with self.assertRaises(TokenUsed):
            redeem_reset_token(token, now=5000)

    def test_expired_attempt_does_not_consume_token(self):
        token = issue_reset_token("ada", now=1000)
        with self.assertRaises(TokenExpired):
            redeem_reset_token(token, now=2801)
        with self.assertRaises(TokenExpired):
            redeem_reset_token(token, now=2802)

    def test_tokens_for_same_user_are_independent(self):
        first = issue_reset_token("ada", now=1000)
        second = issue_reset_token("ada", now=1000)
        self.assertNotEqual(first, second)
        self.assertEqual(redeem_reset_token(first, now=1000), "ada")
        self.assertEqual(redeem_reset_token(second, now=1000), "ada")
        with self.assertRaises(TokenUsed):
            redeem_reset_token(first, now=1000)
        with self.assertRaises(TokenUsed):
            redeem_reset_token(second, now=1000)

    def test_expired_and_used_are_invalid_token(self):
        self.assertTrue(issubclass(TokenExpired, InvalidToken))
        self.assertTrue(issubclass(TokenUsed, InvalidToken))
        used = issue_reset_token("ada", now=1000)
        redeem_reset_token(used, now=1000)
        expired = issue_reset_token("ada", now=1000)
        for token in (used, expired):
            with self.subTest(token=token):
                with self.assertRaises(InvalidToken):
                    redeem_reset_token(token, now=5000)

"""Password-reset tokens (in-memory store)."""

import secrets
import time

TOKEN_TTL = 1800  # seconds a token stays redeemable after issue

_TOKENS = {}  # token -> {"username": str, "issued_at": float, "used": bool}


class InvalidToken(Exception):
    pass


class TokenExpired(InvalidToken):
    pass


class TokenUsed(InvalidToken):
    pass


def issue_reset_token(username, now=None):
    """Create a reset token for username.

    now is a Unix timestamp in seconds; defaults to time.time().
    """
    if now is None:
        now = time.time()
    token = secrets.token_urlsafe(16)
    _TOKENS[token] = {"username": username, "issued_at": now, "used": False}
    return token


def redeem_reset_token(token, now=None):
    """Return the username a token was issued for and consume the token.

    now is a Unix timestamp in seconds; defaults to time.time().
    Raises TokenUsed if the token was already redeemed, TokenExpired if
    more than TOKEN_TTL seconds have passed since issue, and InvalidToken
    if the token is unknown. A failed redeem does not consume the token.
    """
    if now is None:
        now = time.time()
    record = _TOKENS.get(token)
    if record is None:
        raise InvalidToken("unknown token")
    if record["used"]:
        raise TokenUsed("token already used")
    if now - record["issued_at"] > TOKEN_TTL:
        raise TokenExpired("token expired")
    record["used"] = True
    return record["username"]

"""Password-reset tokens (in-memory store)."""

import secrets
import threading
import time

RESET_TOKEN_TTL = 1800  # seconds

_TOKENS = {}  # token -> (username, issued_at)
_USED = set()  # tokens already redeemed
_LOCK = threading.Lock()


class InvalidToken(Exception):
    pass


class TokenExpired(InvalidToken):
    pass


class TokenUsed(InvalidToken):
    pass


def issue_reset_token(username, now=None):
    """Create a reset token for username, issued at now (Unix seconds)."""
    if now is None:
        now = time.time()
    token = secrets.token_urlsafe(16)
    _TOKENS[token] = (username, now)
    return token


def redeem_reset_token(token, now=None):
    """Return the username a token was issued for.

    Raises TokenUsed if already redeemed, TokenExpired if more than
    RESET_TOKEN_TTL seconds passed since issue. A failed attempt does not
    consume the token.
    """
    if now is None:
        now = time.time()
    with _LOCK:
        issued = _TOKENS.get(token)
        if issued is None:
            raise InvalidToken("unknown token")
        if token in _USED:
            raise TokenUsed("token already used")
        username, issued_at = issued
        if not (now - issued_at <= RESET_TOKEN_TTL):
            raise TokenExpired("token expired")
        _USED.add(token)
    return username

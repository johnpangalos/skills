"""Password-reset tokens (in-memory store).

A token expires TOKEN_TTL seconds after it is issued and can be redeemed once.
Used and expired tokens stay in the store so a later redeem can say why it failed.
"""

import secrets
import threading
import time

TOKEN_TTL = 1800  # seconds

_TOKENS = {}  # token -> {"username": str, "issued_at": float, "used": bool}
_LOCK = threading.Lock()


class InvalidToken(Exception):
    pass


class TokenExpired(InvalidToken):
    pass


class TokenUsed(InvalidToken):
    pass


def issue_reset_token(username, now=None):
    """Create a reset token for username, issued at now (Unix seconds, default time.time())."""
    if now is None:
        now = time.time()
    token = secrets.token_urlsafe(16)
    _TOKENS[token] = {"username": username, "issued_at": now, "used": False}
    return token


def redeem_reset_token(token, now=None):
    """Return the username a token was issued for, marking the token used.

    Raises InvalidToken for unknown tokens, TokenUsed if already redeemed, and
    TokenExpired if more than TOKEN_TTL seconds have passed since issue.
    """
    if now is None:
        now = time.time()
    with _LOCK:
        record = _TOKENS.get(token) if isinstance(token, str) else None
        if record is None:
            raise InvalidToken("unknown token")
        if record["used"]:
            raise TokenUsed("token already used")
        if now - record["issued_at"] > TOKEN_TTL:
            raise TokenExpired("token expired")
        record["used"] = True
        return record["username"]

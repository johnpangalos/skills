import threading
import unittest
from unittest import mock

from shop.auth import (
    InvalidToken,
    TokenExpired,
    TokenUsed,
    issue_reset_token,
    redeem_reset_token,
)


class ResetTokenTest(unittest.TestCase):
    def test_round_trip(self):
        token = issue_reset_token("ada")
        self.assertEqual(redeem_reset_token(token), "ada")

    def test_unknown_token(self):
        with self.assertRaises(InvalidToken):
            redeem_reset_token("not-a-token")

    def test_none_token_is_invalid(self):
        with self.assertRaises(InvalidToken) as cm:
            redeem_reset_token(None)
        self.assertIs(type(cm.exception), InvalidToken)

    def test_exactly_1800_seconds_is_valid(self):
        token = issue_reset_token("ada", now=1000)
        self.assertEqual(redeem_reset_token(token, now=2800), "ada")

    def test_1801_seconds_is_expired(self):
        token = issue_reset_token("ada", now=1000)
        with self.assertRaises(TokenExpired):
            redeem_reset_token(token, now=2801)

    def test_fractional_overrun_is_expired(self):
        token = issue_reset_token("ada", now=1000.5)
        with self.assertRaises(TokenExpired):
            redeem_reset_token(token, now=1000.5 + 1800.001)

    def test_now_zero_is_used_as_zero(self):
        token = issue_reset_token("ada", now=0)
        self.assertEqual(redeem_reset_token(token, now=0), "ada")

    def test_default_now_uses_time_time(self):
        with mock.patch("shop.auth.time.time", return_value=5000.0):
            token = issue_reset_token("ada")
        with mock.patch("shop.auth.time.time", return_value=5000.0 + 1801):
            with self.assertRaises(TokenExpired):
                redeem_reset_token(token)

    def test_reuse_raises_token_used(self):
        token = issue_reset_token("ada", now=1000)
        redeem_reset_token(token, now=1000)
        with self.assertRaises(TokenUsed):
            redeem_reset_token(token, now=1000)

    def test_used_token_past_expiry_is_token_used(self):
        token = issue_reset_token("ada", now=1000)
        redeem_reset_token(token, now=1000)
        with self.assertRaises(TokenUsed):
            redeem_reset_token(token, now=1000 + 5000)

    def test_expired_attempt_does_not_consume_token(self):
        token = issue_reset_token("ada", now=1000)
        for _ in range(2):
            with self.assertRaises(TokenExpired):
                redeem_reset_token(token, now=3000)

    def test_concurrent_redemption_succeeds_once(self):
        token = issue_reset_token("ada", now=1000)
        results = []

        def attempt():
            try:
                results.append(redeem_reset_token(token, now=1000))
            except TokenUsed:
                results.append("used")

        threads = [threading.Thread(target=attempt) for _ in range(20)]
        for thread in threads:
            thread.start()
        for thread in threads:
            thread.join()
        self.assertEqual(results.count("ada"), 1)
        self.assertEqual(results.count("used"), 19)

    def test_nan_time_fails_closed(self):
        token = issue_reset_token("ada", now=0)
        with self.assertRaises(TokenExpired):
            redeem_reset_token(token, now=float("nan"))
        token = issue_reset_token("ada", now=float("nan"))
        with self.assertRaises(TokenExpired):
            redeem_reset_token(token, now=10**9)

    def test_expiry_and_used_subclass_invalid_token(self):
        self.assertTrue(issubclass(TokenExpired, InvalidToken))
        self.assertTrue(issubclass(TokenUsed, InvalidToken))

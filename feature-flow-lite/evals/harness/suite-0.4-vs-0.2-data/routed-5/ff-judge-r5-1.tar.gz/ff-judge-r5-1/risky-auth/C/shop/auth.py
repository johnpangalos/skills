"""Password-reset tokens (in-memory store).

A token expires 1800 seconds (30 minutes) after it is issued and can be
redeemed only once.
"""

import secrets
import time

TOKEN_TTL_SECONDS = 1800

_TOKENS = {}  # token -> {"username": str, "issued_at": float, "used": bool}


class InvalidToken(Exception):
    pass


class TokenExpired(InvalidToken):
    pass


class TokenUsed(InvalidToken):
    pass


def issue_reset_token(username, now=None):
    """Create a reset token for username, issued at now (Unix seconds)."""
    if now is None:
        now = time.time()
    token = secrets.token_urlsafe(16)
    _TOKENS[token] = {"username": username, "issued_at": now, "used": False}
    return token


def redeem_reset_token(token, now=None):
    """Return the username a token was issued for, consuming the token.

    Raises TokenUsed if the token was already redeemed, and TokenExpired if
    more than TOKEN_TTL_SECONDS have passed since it was issued. A failed
    attempt leaves the token unused.
    """
    record = _TOKENS.get(token)
    if record is None:
        raise InvalidToken("unknown token")
    if now is None:
        now = time.time()
    if record["used"]:
        raise TokenUsed("token already used")
    if now - record["issued_at"] > TOKEN_TTL_SECONDS:
        raise TokenExpired("token expired")
    record["used"] = True
    return record["username"]

import threading
import unittest

from shop import auth
from shop.auth import (
    InvalidToken,
    TokenExpired,
    TokenUsed,
    issue_reset_token,
    redeem_reset_token,
)


class ResetTokenTest(unittest.TestCase):
    def setUp(self):
        auth._TOKENS.clear()

    def test_round_trip(self):
        token = issue_reset_token("ada")
        self.assertEqual(redeem_reset_token(token), "ada")

    def test_positional_now(self):
        token = issue_reset_token("ada", 100)
        self.assertEqual(redeem_reset_token(token, 100), "ada")

    def test_now_zero_is_honoured(self):
        token = issue_reset_token("ada", 0)
        with self.assertRaises(TokenExpired) as cm:
            redeem_reset_token(token, 1801)
        self.assertEqual(str(cm.exception), "token expired")

    def test_exactly_at_limit_is_valid(self):
        token = issue_reset_token("ada", 1000)
        self.assertEqual(redeem_reset_token(token, 2800), "ada")

    def test_one_second_past_limit_is_expired(self):
        token = issue_reset_token("ada", 1000)
        with self.assertRaises(TokenExpired) as cm:
            redeem_reset_token(token, 2801)
        self.assertEqual(str(cm.exception), "token expired")

    def test_fraction_past_limit_is_expired(self):
        token = issue_reset_token("ada", 1000)
        with self.assertRaises(TokenExpired):
            redeem_reset_token(token, 2800.001)

    def test_reuse_raises_token_used(self):
        token = issue_reset_token("ada", 1000)
        self.assertEqual(redeem_reset_token(token, 1000), "ada")
        with self.assertRaises(TokenUsed) as cm:
            redeem_reset_token(token, 1001)
        self.assertEqual(str(cm.exception), "token already used")

    def test_reuse_after_window_raises_token_used(self):
        token = issue_reset_token("ada", 1000)
        self.assertEqual(redeem_reset_token(token, 1000), "ada")
        with self.assertRaises(TokenUsed):
            redeem_reset_token(token, 6000)

    def test_expired_then_retry_still_expired(self):
        token = issue_reset_token("ada", 1000)
        with self.assertRaises(TokenExpired):
            redeem_reset_token(token, 3000)
        with self.assertRaises(TokenExpired) as cm:
            redeem_reset_token(token, 3000)
        self.assertEqual(str(cm.exception), "token expired")

    def test_subclass_relationships(self):
        self.assertTrue(issubclass(TokenExpired, InvalidToken))
        self.assertTrue(issubclass(TokenUsed, InvalidToken))

    def test_unknown_token_raises_exact_invalid_token(self):
        for bad in ["not-a-token", "", None, ["list"]]:
            with self.subTest(token=bad):
                with self.assertRaises(InvalidToken) as cm:
                    redeem_reset_token(bad)
                self.assertIs(type(cm.exception), InvalidToken)
                self.assertEqual(str(cm.exception), "unknown token")

    def test_distinct_tokens_per_issue(self):
        first = issue_reset_token("ada", 1000)
        second = issue_reset_token("ada", 1000)
        self.assertNotEqual(first, second)
        self.assertEqual(redeem_reset_token(first, 1000), "ada")
        self.assertEqual(redeem_reset_token(second, 1000), "ada")

    def test_concurrent_redeem_succeeds_once(self):
        token = issue_reset_token("ada", 1000)
        threads_count = 20
        barrier = threading.Barrier(threads_count)
        outcomes = []

        def attempt():
            barrier.wait()
            try:
                outcomes.append(redeem_reset_token(token, 1000))
            except TokenUsed:
                outcomes.append("used")

        threads = [threading.Thread(target=attempt) for _ in range(threads_count)]
        for thread in threads:
            thread.start()
        for thread in threads:
            thread.join()
        self.assertEqual(outcomes.count("ada"), 1)
        self.assertEqual(outcomes.count("used"), threads_count - 1)


if __name__ == "__main__":
    unittest.main()

"""Password-reset tokens (in-memory store).

A token expires TOKEN_LIFETIME_SECONDS after it is issued and can be
redeemed only once. Redeeming an expired token raises TokenExpired without
consuming it. Redeeming a token that was already redeemed raises TokenUsed.
Pass `now` (Unix seconds) to control the clock; the default is time.time().
"""

import secrets
import time

TOKEN_LIFETIME_SECONDS = 1800

_TOKENS = {}  # token -> {"username": str, "issued_at": float, "used": bool}


class InvalidToken(Exception):
    pass


class TokenExpired(InvalidToken):
    pass


class TokenUsed(InvalidToken):
    pass


def issue_reset_token(username, now=None):
    """Create a reset token for username, issued at `now` (default time.time())."""
    token = secrets.token_urlsafe(16)
    issued_at = time.time() if now is None else now
    _TOKENS[token] = {"username": username, "issued_at": issued_at, "used": False}
    return token


def redeem_reset_token(token, now=None):
    """Return the username a token was issued for, marking the token used.

    Raises InvalidToken for unknown tokens, TokenUsed if the token was already
    redeemed, and TokenExpired if more than TOKEN_LIFETIME_SECONDS have passed
    since issue. `now` defaults to time.time().
    """
    record = _TOKENS.get(token)
    if record is None:
        raise InvalidToken("unknown token")
    if record["used"]:
        raise TokenUsed("token already used")
    current = time.time() if now is None else now
    if current - record["issued_at"] > TOKEN_LIFETIME_SECONDS:
        raise TokenExpired("token expired")
    record["used"] = True
    return record["username"]

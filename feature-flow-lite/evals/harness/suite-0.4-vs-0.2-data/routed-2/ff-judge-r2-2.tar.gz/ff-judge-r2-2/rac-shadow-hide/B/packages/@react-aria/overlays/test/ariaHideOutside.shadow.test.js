/*
 * Copyright 2026 Adobe. All rights reserved.
 * This file is licensed to you under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License. You may obtain a copy
 * of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software distributed under
 * the License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR REPRESENTATIONS
 * OF ANY KIND, either express or implied. See the License for the specific language
 * governing permissions and limitations under the License.
 */

import {ariaHideOutside} from '../src';
import {enableShadowDOM} from '@react-stately/flags';
import {waitFor} from '@react-spectrum/test-utils-internal';

// The shadow DOM flag cannot be turned off, so it is enabled in this file only.
describe('ariaHideOutside with shadow DOM', function () {
  beforeAll(function () {
    enableShadowDOM();
  });

  afterEach(function () {
    document.body.innerHTML = '';
  });

  function createHost(parent = document.body) {
    let host = document.createElement('div');
    parent.appendChild(host);
    return {host, shadowRoot: host.attachShadow({mode: 'open'})};
  }

  it('hides siblings of the target and its ancestors inside the shadow root, but not the host', function () {
    let light = document.createElement('span');
    document.body.appendChild(light);
    let {host, shadowRoot} = createHost();
    shadowRoot.innerHTML = '<div id="wrap"><input id="sibling" /><button id="target">Target</button></div><p id="outer">Other</p>';
    let target = shadowRoot.querySelector('#target');

    let revert = ariaHideOutside([target]);

    expect(shadowRoot.querySelector('#sibling')).toHaveAttribute('aria-hidden', 'true');
    expect(shadowRoot.querySelector('#outer')).toHaveAttribute('aria-hidden', 'true');
    expect(shadowRoot.querySelector('#wrap')).not.toHaveAttribute('aria-hidden');
    expect(target).not.toHaveAttribute('aria-hidden');
    expect(host).not.toHaveAttribute('aria-hidden');
    expect(light).toHaveAttribute('aria-hidden', 'true');

    revert();

    expect(shadowRoot.querySelector('#sibling')).not.toHaveAttribute('aria-hidden');
    expect(shadowRoot.querySelector('#outer')).not.toHaveAttribute('aria-hidden');
    expect(light).not.toHaveAttribute('aria-hidden');
  });

  it('hides siblings in every shadow root enclosing a target, nested two deep', function () {
    let {host: outerHost, shadowRoot: outerRoot} = createHost();
    outerRoot.innerHTML = '<p id="outer-sibling">Outer</p>';
    let {host: innerHost, shadowRoot: innerRoot} = createHost(outerRoot);
    innerRoot.innerHTML = '<input id="inner-sibling" /><button id="target">Target</button>';
    let target = innerRoot.querySelector('#target');

    let revert = ariaHideOutside([target]);

    expect(outerRoot.querySelector('#outer-sibling')).toHaveAttribute('aria-hidden', 'true');
    expect(innerRoot.querySelector('#inner-sibling')).toHaveAttribute('aria-hidden', 'true');
    expect(innerHost).not.toHaveAttribute('aria-hidden');
    expect(outerHost).not.toHaveAttribute('aria-hidden');
    expect(target).not.toHaveAttribute('aria-hidden');

    revert();

    expect(outerRoot.querySelector('#outer-sibling')).not.toHaveAttribute('aria-hidden');
    expect(innerRoot.querySelector('#inner-sibling')).not.toHaveAttribute('aria-hidden');
  });

  it('hides siblings when the target is a direct child of the shadow root', function () {
    let {shadowRoot} = createHost();
    shadowRoot.innerHTML = '<button id="target">Target</button><input id="sibling" />';
    let target = shadowRoot.querySelector('#target');

    let revert = ariaHideOutside([target]);

    expect(shadowRoot.querySelector('#sibling')).toHaveAttribute('aria-hidden', 'true');
    expect(target).not.toHaveAttribute('aria-hidden');

    revert();

    expect(shadowRoot.querySelector('#sibling')).not.toHaveAttribute('aria-hidden');
  });

  it('leaves a host and sibling that were already aria-hidden by someone else untouched', function () {
    let light = document.createElement('span');
    light.setAttribute('aria-hidden', 'true');
    document.body.appendChild(light);
    let {host, shadowRoot} = createHost();
    host.setAttribute('aria-hidden', 'true');
    shadowRoot.innerHTML = '<button id="target">Target</button><input id="sibling" />';
    let target = shadowRoot.querySelector('#target');

    let revert = ariaHideOutside([target]);

    expect(host).toHaveAttribute('aria-hidden', 'true');
    expect(light).toHaveAttribute('aria-hidden', 'true');

    revert();

    expect(host).toHaveAttribute('aria-hidden', 'true');
    expect(light).toHaveAttribute('aria-hidden', 'true');
  });

  it('keeps targets in different shadow roots and the light DOM visible, with their host chains', function () {
    let light = document.createElement('span');
    document.body.appendChild(light);
    let lightTarget = document.createElement('button');
    document.body.appendChild(lightTarget);
    let {host: hostA, shadowRoot: rootA} = createHost();
    rootA.innerHTML = '<input id="input" /><span id="a-other">A</span>';
    let {host: hostB, shadowRoot: rootB} = createHost();
    rootB.innerHTML = '<div id="popover">Popover</div><p id="b-other">B</p>';
    let input = rootA.querySelector('#input');
    let popover = rootB.querySelector('#popover');

    let revert = ariaHideOutside([input, popover, lightTarget]);

    expect(input).not.toHaveAttribute('aria-hidden');
    expect(popover).not.toHaveAttribute('aria-hidden');
    expect(lightTarget).not.toHaveAttribute('aria-hidden');
    expect(hostA).not.toHaveAttribute('aria-hidden');
    expect(hostB).not.toHaveAttribute('aria-hidden');
    expect(rootA.querySelector('#a-other')).toHaveAttribute('aria-hidden', 'true');
    expect(rootB.querySelector('#b-other')).toHaveAttribute('aria-hidden', 'true');
    expect(light).toHaveAttribute('aria-hidden', 'true');

    revert();

    expect(rootA.querySelector('#a-other')).not.toHaveAttribute('aria-hidden');
    expect(rootB.querySelector('#b-other')).not.toHaveAttribute('aria-hidden');
    expect(light).not.toHaveAttribute('aria-hidden');
  });

  it('keeps a target nested inside another target shadow root visible', function () {
    let light = document.createElement('span');
    document.body.appendChild(light);
    let {host: outerTarget, shadowRoot} = createHost();
    shadowRoot.innerHTML = '<button id="inner-target">Inner</button><input id="inner-sibling" />';
    let innerTarget = shadowRoot.querySelector('#inner-target');

    let revert = ariaHideOutside([outerTarget, innerTarget]);

    expect(outerTarget).not.toHaveAttribute('aria-hidden');
    expect(innerTarget).not.toHaveAttribute('aria-hidden');
    expect(shadowRoot.querySelector('#inner-sibling')).not.toHaveAttribute('aria-hidden');
    expect(light).toHaveAttribute('aria-hidden', 'true');

    revert();

    expect(shadowRoot.querySelector('#inner-sibling')).not.toHaveAttribute('aria-hidden');
    expect(light).not.toHaveAttribute('aria-hidden');
  });

  it('keeps two targets sharing a host visible and hides the rest of the shadow root', function () {
    let {host, shadowRoot} = createHost();
    shadowRoot.innerHTML = '<input id="first" /><button id="second">Second</button><span id="other">Other</span>';
    let first = shadowRoot.querySelector('#first');
    let second = shadowRoot.querySelector('#second');

    let revert = ariaHideOutside([first, second]);

    expect(first).not.toHaveAttribute('aria-hidden');
    expect(second).not.toHaveAttribute('aria-hidden');
    expect(host).not.toHaveAttribute('aria-hidden');
    expect(shadowRoot.querySelector('#other')).toHaveAttribute('aria-hidden', 'true');

    revert();

    expect(shadowRoot.querySelector('#other')).not.toHaveAttribute('aria-hidden');
  });

  it('hides elements added later to a shadow root', async function () {
    let {shadowRoot} = createHost();
    shadowRoot.innerHTML = '<button id="target">Target</button>';
    let target = shadowRoot.querySelector('#target');

    let revert = ariaHideOutside([target]);

    let added = document.createElement('span');
    shadowRoot.appendChild(added);
    await waitFor(() => expect(added).toHaveAttribute('aria-hidden', 'true'));
    expect(target).not.toHaveAttribute('aria-hidden');

    revert();
  });

  it('keeps live announcers and top layer elements in a shadow root visible', async function () {
    let {shadowRoot} = createHost();
    shadowRoot.innerHTML = '<button id="target">Target</button><div data-live-announcer="true" id="existing"></div>';
    let target = shadowRoot.querySelector('#target');

    let revert = ariaHideOutside([target]);

    let announcer = document.createElement('div');
    announcer.dataset.liveAnnouncer = 'true';
    let topLayer = document.createElement('div');
    topLayer.dataset.reactAriaTopLayer = 'true';
    let added = document.createElement('span');
    shadowRoot.append(announcer, topLayer, added);
    await waitFor(() => expect(added).toHaveAttribute('aria-hidden', 'true'));

    expect(announcer).not.toHaveAttribute('aria-hidden');
    expect(topLayer).not.toHaveAttribute('aria-hidden');
    expect(shadowRoot.querySelector('#existing')).not.toHaveAttribute('aria-hidden');

    revert();
  });

  it('does not hide added content inside a target or an already hidden subtree', async function () {
    let {shadowRoot} = createHost();
    shadowRoot.innerHTML = '<section id="section"><button>Inner</button></section><button id="target">Target</button>';
    let section = shadowRoot.querySelector('#section');
    let target = shadowRoot.querySelector('#target');

    let revert = ariaHideOutside([target]);
    expect(section).toHaveAttribute('aria-hidden', 'true');

    let insideHidden = document.createElement('span');
    section.appendChild(insideHidden);
    let insideTarget = document.createElement('span');
    target.appendChild(insideTarget);
    let added = document.createElement('span');
    shadowRoot.appendChild(added);
    await waitFor(() => expect(added).toHaveAttribute('aria-hidden', 'true'));

    expect(insideHidden).not.toHaveAttribute('aria-hidden');
    expect(insideTarget).not.toHaveAttribute('aria-hidden');

    revert();

    expect(section).not.toHaveAttribute('aria-hidden');
    expect(section.querySelector('button')).not.toHaveAttribute('aria-hidden');
  });

  it('stops observing and restores everything on cleanup', async function () {
    let {shadowRoot} = createHost();
    shadowRoot.innerHTML = '<button id="target">Target</button><input id="sibling" />';
    let target = shadowRoot.querySelector('#target');

    let revert = ariaHideOutside([target]);
    revert();

    expect(shadowRoot.querySelector('#sibling')).not.toHaveAttribute('aria-hidden');
    let late = document.createElement('span');
    shadowRoot.appendChild(late);
    await new Promise(resolve => setTimeout(resolve, 0));
    expect(late).not.toHaveAttribute('aria-hidden');
  });

  it('re-enables the outer shadow root observer when a nested call inside another shadow root is cleaned up', async function () {
    let {shadowRoot: outerRoot} = createHost();
    outerRoot.innerHTML = '<button id="outer-target">Outer</button><input id="outer-sibling" />';
    let {shadowRoot: innerRoot} = createHost();
    innerRoot.innerHTML = '<div id="inner-target">Inner</div><p id="inner-sibling">Sibling</p>';
    let outerTarget = outerRoot.querySelector('#outer-target');
    let innerTarget = innerRoot.querySelector('#inner-target');

    let revertOuter = ariaHideOutside([outerTarget]);
    let revertInner = ariaHideOutside([innerTarget]);
    expect(innerRoot.querySelector('#inner-sibling')).toHaveAttribute('aria-hidden', 'true');

    revertInner();
    expect(innerRoot.querySelector('#inner-sibling')).not.toHaveAttribute('aria-hidden');

    let late = document.createElement('span');
    outerRoot.appendChild(late);
    await waitFor(() => expect(late).toHaveAttribute('aria-hidden', 'true'));
    expect(outerTarget).not.toHaveAttribute('aria-hidden');

    revertOuter();
    expect(outerRoot.querySelector('#outer-sibling')).not.toHaveAttribute('aria-hidden');
  });

  it('keeps the siblings of a host inside a light target visible', function () {
    let light = document.createElement('span');
    document.body.appendChild(light);
    let target = document.createElement('div');
    document.body.appendChild(target);
    let {host, shadowRoot} = createHost(target);
    shadowRoot.innerHTML = '<input id="sibling" /><button id="inner">Inner</button>';
    let inner = shadowRoot.querySelector('#inner');

    let revert = ariaHideOutside([target, inner]);

    expect(target).not.toHaveAttribute('aria-hidden');
    expect(host).not.toHaveAttribute('aria-hidden');
    expect(inner).not.toHaveAttribute('aria-hidden');
    expect(shadowRoot.querySelector('#sibling')).not.toHaveAttribute('aria-hidden');
    expect(light).toHaveAttribute('aria-hidden', 'true');

    revert();

    expect(light).not.toHaveAttribute('aria-hidden');
  });

  it('does not hide siblings of a target in a shadow root whose host is outside root', function () {
    let app = document.createElement('div');
    document.body.appendChild(app);
    let {host, shadowRoot} = createHost();
    shadowRoot.innerHTML = '<button id="target">Target</button><input id="sibling" />';
    let target = shadowRoot.querySelector('#target');

    let revert = ariaHideOutside([target], {root: app});

    expect(host).not.toHaveAttribute('aria-hidden');
    expect(shadowRoot.querySelector('#sibling')).not.toHaveAttribute('aria-hidden');

    revert();

    expect(shadowRoot.querySelector('#sibling')).not.toHaveAttribute('aria-hidden');
  });

  it('keeps the host of a live announcer in a shadow root not on the target path visible', function () {
    let target = document.createElement('button');
    document.body.appendChild(target);
    let {host, shadowRoot} = createHost();
    shadowRoot.innerHTML = '<div data-live-announcer="true" id="announcer"></div><div data-react-aria-top-layer="true" id="top"></div><span id="sibling"></span>';

    let revert = ariaHideOutside([target]);

    expect(host).not.toHaveAttribute('aria-hidden');
    expect(shadowRoot.querySelector('#announcer')).not.toHaveAttribute('aria-hidden');
    expect(shadowRoot.querySelector('#top')).not.toHaveAttribute('aria-hidden');
    expect(shadowRoot.querySelector('#sibling')).toHaveAttribute('aria-hidden', 'true');

    revert();

    expect(shadowRoot.querySelector('#sibling')).not.toHaveAttribute('aria-hidden');
  });

  it('finds live announcers in nested shadow roots and keeps their hosts visible', function () {
    let target = document.createElement('button');
    document.body.appendChild(target);
    let {shadowRoot: outerRoot} = createHost();
    outerRoot.innerHTML = '<p id="outer-sibling">Outer</p>';
    let {host: innerHost, shadowRoot: innerRoot} = createHost(outerRoot);
    innerRoot.innerHTML = '<div data-live-announcer="true" id="announcer"></div><span id="inner-sibling"></span>';

    let revert = ariaHideOutside([target]);

    expect(innerHost).not.toHaveAttribute('aria-hidden');
    expect(innerRoot.querySelector('#announcer')).not.toHaveAttribute('aria-hidden');
    expect(outerRoot.querySelector('#outer-sibling')).toHaveAttribute('aria-hidden', 'true');
    expect(innerRoot.querySelector('#inner-sibling')).toHaveAttribute('aria-hidden', 'true');

    revert();

    expect(outerRoot.querySelector('#outer-sibling')).not.toHaveAttribute('aria-hidden');
    expect(innerRoot.querySelector('#inner-sibling')).not.toHaveAttribute('aria-hidden');
  });

  it('keeps live announcers and top layer elements added later visible, with their hosts', async function () {
    let target = document.createElement('button');
    document.body.appendChild(target);
    let {shadowRoot: existingRoot} = createHost();
    existingRoot.innerHTML = '<div data-live-announcer="true" id="existing"></div>';

    let revert = ariaHideOutside([target]);

    let announcer = document.createElement('div');
    announcer.dataset.liveAnnouncer = 'true';
    let late = document.createElement('span');
    existingRoot.append(announcer, late);

    let {host: newHost, shadowRoot: newRoot} = createHost();
    newRoot.innerHTML = '<div data-react-aria-top-layer="true" id="top"></div><span id="new-sibling"></span>';

    await waitFor(() => expect(late).toHaveAttribute('aria-hidden', 'true'));
    await waitFor(() => expect(newRoot.querySelector('#new-sibling')).toHaveAttribute('aria-hidden', 'true'));
    expect(announcer).not.toHaveAttribute('aria-hidden');
    expect(newHost).not.toHaveAttribute('aria-hidden');
    expect(newRoot.querySelector('#top')).not.toHaveAttribute('aria-hidden');

    revert();
  });

  it('hides siblings of a target in a closed shadow root', function () {
    let light = document.createElement('span');
    document.body.appendChild(light);
    let host = document.createElement('div');
    document.body.appendChild(host);
    let shadowRoot = host.attachShadow({mode: 'closed'});
    shadowRoot.innerHTML = '<button id="target">Target</button><input id="sibling" />';
    let target = shadowRoot.querySelector('#target');

    let revert = ariaHideOutside([target]);

    expect(shadowRoot.querySelector('#sibling')).toHaveAttribute('aria-hidden', 'true');
    expect(target).not.toHaveAttribute('aria-hidden');
    expect(host).not.toHaveAttribute('aria-hidden');
    expect(light).toHaveAttribute('aria-hidden', 'true');

    revert();

    expect(shadowRoot.querySelector('#sibling')).not.toHaveAttribute('aria-hidden');
    expect(light).not.toHaveAttribute('aria-hidden');
  });
});

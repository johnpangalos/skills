/*
 * Copyright 2020 Adobe. All rights reserved.
 * This file is licensed to you under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License. You may obtain a copy
 * of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software distributed under
 * the License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR REPRESENTATIONS
 * OF ANY KIND, either express or implied. See the License for the specific language
 * governing permissions and limitations under the License.
 */

import {act, createShadowRoot, render, waitFor} from '@react-spectrum/test-utils-internal';
import {ariaHideOutside} from '../src';
import {enableShadowDOM} from '@react-stately/flags';
import React, {useRef, useState} from 'react';

describe('ariaHideOutside', function () {
  it('should hide everything except the provided element [button]', function () {
    let {getByRole, getAllByRole} = render(
      <>
        <input type="checkbox" />
        <button>Button</button>
        <input type="checkbox" />
      </>
    );

    let checkboxes = getAllByRole('checkbox');
    let button = getByRole('button');

    let revert = ariaHideOutside([button]);

    expect(checkboxes[0]).toHaveAttribute('aria-hidden', 'true');
    expect(checkboxes[1]).toHaveAttribute('aria-hidden', 'true');
    expect(button).not.toHaveAttribute('aria-hidden');

    expect(() => getAllByRole('checkbox')).toThrow();
    expect(() => getByRole('button')).not.toThrow();

    revert();

    expect(checkboxes[0]).not.toHaveAttribute('aria-hidden');
    expect(checkboxes[1]).not.toHaveAttribute('aria-hidden');
    expect(button).not.toHaveAttribute('aria-hidden');

    expect(() => getAllByRole('checkbox')).not.toThrow();
    expect(() => getByRole('button')).not.toThrow();
  });

  it('should hide everything except multiple elements', function () {
    let {getByRole, getAllByRole, queryByRole, queryAllByRole} = render(
      <>
        <input type="checkbox" />
        <button>Button</button>
        <input type="checkbox" />
      </>
    );

    let checkboxes = getAllByRole('checkbox');
    let button = getByRole('button');

    let revert = ariaHideOutside(checkboxes);

    expect(checkboxes[0]).not.toHaveAttribute('aria-hidden', 'true');
    expect(checkboxes[1]).not.toHaveAttribute('aria-hidden', 'true');
    expect(button).toHaveAttribute('aria-hidden');

    expect(queryAllByRole('checkbox')).not.toBeNull();
    expect(queryByRole('button')).toBeNull();

    revert();

    expect(checkboxes[0]).not.toHaveAttribute('aria-hidden');
    expect(checkboxes[1]).not.toHaveAttribute('aria-hidden');
    expect(button).not.toHaveAttribute('aria-hidden');

    expect(() => getAllByRole('checkbox')).not.toThrow();
    expect(() => getByRole('button')).not.toThrow();
  });

  it('should not traverse into an already hidden container', function () {
    let {getByRole, getAllByRole} = render(
      <>
        <div>
          <input type="checkbox" />
        </div>
        <button>Button</button>
        <input type="checkbox" />
      </>
    );

    let checkboxes = getAllByRole('checkbox');
    let button = getByRole('button');

    let revert = ariaHideOutside([button]);

    expect(checkboxes[0].parentElement).toHaveAttribute('aria-hidden', 'true');
    expect(checkboxes[1]).toHaveAttribute('aria-hidden', 'true');
    expect(button).not.toHaveAttribute('aria-hidden');

    expect(() => getAllByRole('checkbox')).toThrow();
    expect(() => getByRole('button')).not.toThrow();

    revert();

    expect(checkboxes[0].parentElement).not.toHaveAttribute('aria-hidden');
    expect(checkboxes[1]).not.toHaveAttribute('aria-hidden');
    expect(button).not.toHaveAttribute('aria-hidden');

    expect(() => getAllByRole('checkbox')).not.toThrow();
    expect(() => getByRole('button')).not.toThrow();
  });

  it('should not overwrite an existing aria-hidden prop', function () {
    let {getByRole, getAllByRole} = render(
      <>
        <input type="checkbox" aria-hidden="true" />
        <button>Button</button>
        <input type="checkbox" />
      </>
    );

    let checkboxes = getAllByRole('checkbox');
    let button = getByRole('button');

    let revert = ariaHideOutside([button]);

    expect(checkboxes).toHaveLength(1);
    expect(checkboxes[0]).toHaveAttribute('aria-hidden', 'true');
    expect(button).not.toHaveAttribute('aria-hidden');

    expect(() => getAllByRole('checkbox')).toThrow();
    expect(() => getByRole('button')).not.toThrow();

    revert();

    checkboxes = getAllByRole('checkbox');
    expect(checkboxes).toHaveLength(1);
    expect(checkboxes[0]).not.toHaveAttribute('aria-hidden');
    expect(button).not.toHaveAttribute('aria-hidden');

    expect(() => getAllByRole('checkbox')).not.toThrow();
    expect(() => getByRole('button')).not.toThrow();
  });

  it('should handle when a new element is added outside while active', async function () {
    let Test = props => (
      <>
        {props.show && <input type="checkbox" />}
        <button>Button</button>
        {props.show && <input type="checkbox" />}
      </>
    );

    let {getByRole, getAllByRole, rerender} = render(<Test />);

    let button = getByRole('button');
    expect(() => getAllByRole('checkbox')).toThrow();

    let revert = ariaHideOutside([button]);

    rerender(<Test show />);

    // MutationObserver is async
    await waitFor(() => expect(() => getAllByRole('checkbox')).toThrow());
    expect(() => getByRole('button')).not.toThrow();

    revert();

    expect(getAllByRole('checkbox')).toHaveLength(2);
  });

  it('should handle when a new element is added to an already hidden container', async function () {
    let Test = props => (
      <>
        <div data-testid="test">
          {props.show && <input type="checkbox" />}
        </div>
        <button>Button</button>
        {props.show && <input type="checkbox" />}
      </>
    );

    let {getByRole, getAllByRole, getByTestId, rerender} = render(<Test />);

    let button = getByRole('button');
    let test = getByTestId('test');
    expect(() => getAllByRole('checkbox')).toThrow();

    let revert = ariaHideOutside([button]);

    expect(test).toHaveAttribute('aria-hidden');

    rerender(<Test show />);

    // MutationObserver is async
    await waitFor(() => expect(() => getAllByRole('checkbox')).toThrow());
    expect(() => getByRole('button')).not.toThrow();

    let checkboxes = getAllByRole('checkbox', {hidden: true});
    expect(test).toHaveAttribute('aria-hidden');
    expect(checkboxes[0]).not.toHaveAttribute('aria-hidden');
    expect(checkboxes[1]).toHaveAttribute('aria-hidden', 'true');

    revert();

    expect(getAllByRole('checkbox')).toHaveLength(2);
  });

  it('should handle when a new element is added along with a top layer element', async function () {
    let Test = props => (
      <>
        <button>Button</button>
        {props.show && <div>
          <div role="alert" data-react-aria-top-layer="true">Top layer</div>
          <input type="checkbox" />
        </div>}
      </>
    );

    let {getByRole, queryByRole, getAllByRole, rerender} = render(<Test />);

    let button = getByRole('button');
    expect(queryByRole('checkbox')).toBeNull();

    let revert = ariaHideOutside([button]);

    rerender(<Test show />);

    // MutationObserver is async
    await waitFor(() => queryByRole('checkbox') == null);
    expect(queryByRole('button')).not.toBeNull();
    expect(getByRole('alert')).toHaveTextContent('Top layer');

    revert();

    expect(getAllByRole('checkbox')).toHaveLength(1);
  });

  it('should handle when a new element is added inside a target element', async function () {
    let Test = props => (
      <>
        <input type="checkbox" />
        <div data-testid="test">
          <button>Button</button>
          {props.show && <input type="radio" />}
        </div>
        <input type="checkbox" />
      </>
    );

    let {queryByRole, getByRole, getAllByRole, getByTestId, rerender} = render(<Test />);

    let test = getByTestId('test');
    let revert = ariaHideOutside([test]);

    expect(() => getAllByRole('checkbox')).toThrow();
    expect(queryByRole('radio')).toBeNull();
    expect(queryByRole('button')).not.toBeNull();
    expect(() => getByTestId('test')).not.toThrow();

    rerender(<Test show />);

    // Wait for mutation observer tick
    await Promise.resolve();
    expect(() => getAllByRole('checkbox')).toThrow();
    expect(() => getByRole('radio')).not.toThrow();
    expect(() => getByRole('button')).not.toThrow();
    expect(() => getByTestId('test')).not.toThrow();

    revert();

    expect(() => getAllByRole('checkbox')).not.toThrow();
    expect(() => getByRole('radio')).not.toThrow();
    expect(() => getByRole('button')).not.toThrow();
    expect(() => getByTestId('test')).not.toThrow();
  });

  it('should handle when a new element is added and then reparented', async function () {

    let Test = () => {
      const ref = useRef(null);
      const mutate = () => {
        let parent = document.createElement('ul');
        let child = document.createElement('li');
        ref.current.append(parent);
        parent.appendChild(child);
        parent.remove(); // this results in a mutation record for a disconnected ul with a connected li (through the new ul parent) in `addedNodes`
        let newParent = document.createElement('ul');
        newParent.appendChild(child);
        ref.current.append(newParent);
      };

      return (
        <>
          <div data-testid="test" ref={ref}>
            <button onClick={mutate}>Mutate</button>
          </div>
        </>
      );
    };

    let {queryByRole, getAllByRole, getByTestId} = render(<Test />);

    ariaHideOutside([getByTestId('test')]);

    queryByRole('button').click();
    await Promise.resolve(); // Wait for mutation observer tick

    expect(getAllByRole('listitem')).toHaveLength(1);
  });

  it('should handle when a new element is added and then reparented to a hidden container', async function () {

    let Test = () => {
      const ref = useRef(null);
      const mutate = () => {
        let parent = document.createElement('ul');
        let child = document.createElement('li');
        ref.current.append(parent);
        parent.appendChild(child);
        parent.remove(); // this results in a mutation record for a disconnected ul with a connected li (through the new ul parent) in `addedNodes`
        let newParent = document.createElement('ul');
        newParent.appendChild(child);
        ref.current.append(newParent);
      };

      return (
        <>
          <div data-testid="test">
            <button onClick={mutate}>Mutate</button>
          </div>
          <div data-testid="sibling" ref={ref} />
        </>
      );
    };

    let {queryByRole, queryAllByRole, getByTestId} = render(<Test />);

    ariaHideOutside([getByTestId('test')]);

    queryByRole('button').click();
    await Promise.resolve(); // Wait for mutation observer tick

    expect(queryAllByRole('listitem')).toHaveLength(0);
  });


  it('work when called multiple times', function () {
    let {getByRole, getAllByRole} = render(
      <>
        <input type="checkbox" />
        <input type="radio" />
        <button>Button</button>
        <input type="radio" />
        <input type="checkbox" />
      </>
    );

    let radios = getAllByRole('radio');
    let button = getByRole('button');

    let revert1 = ariaHideOutside([button, ...radios]);

    expect(() => getAllByRole('checkbox')).toThrow();
    expect(() => getAllByRole('radio')).not.toThrow();
    expect(() => getByRole('button')).not.toThrow();

    let revert2 = ariaHideOutside([button]);

    expect(() => getAllByRole('checkbox')).toThrow();
    expect(() => getAllByRole('radio')).toThrow();
    expect(() => getByRole('button')).not.toThrow();

    revert2();

    expect(() => getAllByRole('checkbox')).toThrow();
    expect(() => getAllByRole('radio')).not.toThrow();
    expect(() => getByRole('button')).not.toThrow();

    revert1();

    expect(() => getAllByRole('checkbox')).not.toThrow();
    expect(() => getAllByRole('radio')).not.toThrow();
    expect(() => getByRole('button')).not.toThrow();
  });

  it('work when called multiple times and restored out of order', function () {
    let {getByRole, getAllByRole} = render(
      <>
        <input type="checkbox" />
        <input type="radio" />
        <button>Button</button>
        <input type="radio" />
        <input type="checkbox" />
      </>
    );

    let radios = getAllByRole('radio');
    let button = getByRole('button');

    let revert1 = ariaHideOutside([button, ...radios]);

    expect(() => getAllByRole('checkbox')).toThrow();
    expect(() => getAllByRole('radio')).not.toThrow();
    expect(() => getByRole('button')).not.toThrow();

    let revert2 = ariaHideOutside([button]);

    expect(() => getAllByRole('checkbox')).toThrow();
    expect(() => getAllByRole('radio')).toThrow();
    expect(() => getByRole('button')).not.toThrow();

    revert1();

    expect(() => getAllByRole('checkbox')).toThrow();
    expect(() => getAllByRole('radio')).toThrow();
    expect(() => getByRole('button')).not.toThrow();

    revert2();

    expect(() => getAllByRole('checkbox')).not.toThrow();
    expect(() => getAllByRole('radio')).not.toThrow();
    expect(() => getByRole('button')).not.toThrow();
  });

  it('should hide everything except the provided element [row]', function () {
    let {getAllByRole, getByTestId} = render(
      <div role="grid">
        <div role="row">
          <div role="gridcell">
            <span data-testid="test-span">
              Cell 1
            </span></div>
        </div>
        <div role="row">
          <div role="gridcell">Cell 2</div>
        </div>
      </div>
    );

    let cells = getAllByRole('gridcell');
    let rows = getAllByRole('row');
    let span = getByTestId('test-span');

    let revert = ariaHideOutside([rows[1]]);

    // Applies aria-hidden to the row and cell despite recursive nature of aria-hidden
    // for https://bugs.webkit.org/show_bug.cgi?id=222623
    expect(rows[0]).toHaveAttribute('aria-hidden', 'true');
    expect(cells[0]).toHaveAttribute('aria-hidden', 'true');
    expect(span).not.toHaveAttribute('aria-hidden');
    expect(rows[1]).not.toHaveAttribute('aria-hidden', 'true');
    expect(cells[1]).not.toHaveAttribute('aria-hidden', 'true');

    revert();

    expect(rows[0]).not.toHaveAttribute('aria-hidden', 'true');
    expect(cells[0]).not.toHaveAttribute('aria-hidden', 'true');
    expect(rows[1]).not.toHaveAttribute('aria-hidden', 'true');
    expect(cells[1]).not.toHaveAttribute('aria-hidden', 'true');
    expect(span).not.toHaveAttribute('aria-hidden');
  });

  it('should unhide after item reorder', async function () {
    function Item(props) {
      return (
        <div role="presentation">
          <div data-testid={props.testid} role="row">
            <div role="gridcell" />
          </div>
        </div>
      );
    }

    function Test() {
      let [count, setCount] = useState(0);
      let items = ['row1', 'row2', 'row3', 'row4', 'row5'];
      if (count === 1) {
        items = ['row2', 'row1', 'row3', 'row4', 'row5'];
      } else if (count === 2) {
        items = ['row2', 'row3', 'row1', 'row4', 'row5'];
      }

      return (
        <>
          <button onClick={() => setCount((old) => old + 1)}>press</button>
          {items.map((item) => <Item testid={item} key={item} />)}
        </>

      );
    }

    let {getByRole, getByTestId} = render(
      <Test />
    );

    let button = getByRole('button');
    let row = getByTestId('row1');
    let revert = ariaHideOutside([button]);

    act(() => button.click());
    await Promise.resolve();
    act(() => button.click());
    await Promise.resolve();
    revert();
    expect(row.parentElement).not.toHaveAttribute('aria-hidden', 'true');
  });
});

describe('ariaHideOutside with shadow DOM', function () {
  let cleanups = [];

  beforeAll(() => {
    enableShadowDOM();
  });

  afterEach(() => {
    for (let cleanup of cleanups) {
      cleanup();
    }
    cleanups = [];
  });

  function appendElement(parent, tag = 'div') {
    let element = document.createElement(tag);
    parent.appendChild(element);
    cleanups.push(() => element.remove());
    return element;
  }

  function appendShadowHost(parent) {
    let host = appendElement(parent);
    return {host, shadowRoot: host.attachShadow({mode: 'open'})};
  }

  function appendTopLevelShadowHost() {
    let {shadowHost, shadowRoot, cleanup} = createShadowRoot();
    cleanups.push(cleanup);
    return {host: shadowHost, shadowRoot};
  }

  it('hides siblings of a target that is a direct child of a shadow root', function () {
    let {host, shadowRoot} = appendTopLevelShadowHost();
    let sibling = appendElement(shadowRoot, 'button');
    let target = appendElement(shadowRoot, 'input');
    let unrelated = appendTopLevelShadowHost();
    let unrelatedInner = appendElement(unrelated.shadowRoot, 'button');
    let outside = appendElement(document.body, 'button');

    let revert = ariaHideOutside([target]);

    expect(sibling).toHaveAttribute('aria-hidden', 'true');
    expect(outside).toHaveAttribute('aria-hidden', 'true');
    expect(unrelated.host).toHaveAttribute('aria-hidden', 'true');
    expect(unrelatedInner).not.toHaveAttribute('aria-hidden');
    expect(target).not.toHaveAttribute('aria-hidden');
    expect(host).not.toHaveAttribute('aria-hidden');

    revert();
    expect(sibling).not.toHaveAttribute('aria-hidden');
    expect(outside).not.toHaveAttribute('aria-hidden');
    expect(unrelated.host).not.toHaveAttribute('aria-hidden');
  });

  it('hides siblings at each level of nested shadow roots', function () {
    let {host, shadowRoot: rootA} = appendTopLevelShadowHost();
    let siblingA = appendElement(rootA, 'button');
    let {host: hostB, shadowRoot: rootB} = appendShadowHost(rootA);
    let target = appendElement(rootB, 'input');
    let siblingB = appendElement(rootB, 'button');
    let outside = appendElement(document.body, 'button');

    let revert = ariaHideOutside([target]);

    expect(siblingA).toHaveAttribute('aria-hidden', 'true');
    expect(siblingB).toHaveAttribute('aria-hidden', 'true');
    expect(outside).toHaveAttribute('aria-hidden', 'true');
    expect(host).not.toHaveAttribute('aria-hidden');
    expect(hostB).not.toHaveAttribute('aria-hidden');
    expect(target).not.toHaveAttribute('aria-hidden');

    revert();
    expect(siblingA).not.toHaveAttribute('aria-hidden');
    expect(siblingB).not.toHaveAttribute('aria-hidden');
    expect(outside).not.toHaveAttribute('aria-hidden');
  });

  it('hides content added later to a target shadow root, but not content added inside a target', async function () {
    let {shadowRoot} = appendTopLevelShadowHost();
    let target = appendElement(shadowRoot);
    let revert = ariaHideOutside([target]);

    let added = appendElement(shadowRoot, 'button');
    let addedInTarget = appendElement(target, 'button');

    await waitFor(() => expect(added).toHaveAttribute('aria-hidden', 'true'));
    expect(addedInTarget).not.toHaveAttribute('aria-hidden');
    revert();
  });

  it('hides content added later to an enclosing shadow root of a target', async function () {
    let {shadowRoot: rootA} = appendTopLevelShadowHost();
    let {shadowRoot: rootB} = appendShadowHost(rootA);
    let target = appendElement(rootB);
    let revert = ariaHideOutside([target]);

    let added = appendElement(rootA, 'button');
    let addedInRootB = appendElement(rootB, 'button');

    await waitFor(() => expect(added).toHaveAttribute('aria-hidden', 'true'));
    await waitFor(() => expect(addedInRootB).toHaveAttribute('aria-hidden', 'true'));
    revert();
  });

  it('hides a shadow host added later as a whole without marking its shadow content', async function () {
    let {shadowRoot} = appendTopLevelShadowHost();
    let target = appendElement(shadowRoot);
    let revert = ariaHideOutside([target]);

    let {host: newHost, shadowRoot: newShadowRoot} = appendShadowHost(shadowRoot);
    let newInner = appendElement(newShadowRoot, 'button');

    await waitFor(() => expect(newHost).toHaveAttribute('aria-hidden', 'true'));
    expect(newInner).not.toHaveAttribute('aria-hidden');
    revert();
  });

  it('keeps live announcers and top layer elements visible in shadow roots', async function () {
    let {shadowRoot} = appendTopLevelShadowHost();
    let target = appendElement(shadowRoot);
    let existingAnnouncer = appendElement(shadowRoot);
    existingAnnouncer.dataset.liveAnnouncer = 'true';
    let revert = ariaHideOutside([target]);

    let addedAnnouncer = appendElement(shadowRoot);
    addedAnnouncer.dataset.liveAnnouncer = 'true';
    let addedTopLayer = appendElement(shadowRoot);
    addedTopLayer.dataset.reactAriaTopLayer = 'true';
    let plain = appendElement(shadowRoot);

    await waitFor(() => expect(plain).toHaveAttribute('aria-hidden', 'true'));
    expect(existingAnnouncer).not.toHaveAttribute('aria-hidden');
    expect(addedAnnouncer).not.toHaveAttribute('aria-hidden');
    expect(addedTopLayer).not.toHaveAttribute('aria-hidden');
    revert();
  });

  it('keeps targets in different shadow roots visible and hides the rest of both', async function () {
    let a = appendTopLevelShadowHost();
    let b = appendTopLevelShadowHost();
    let input = appendElement(a.shadowRoot, 'input');
    let popover = appendElement(b.shadowRoot);
    let siblingA = appendElement(a.shadowRoot);
    let siblingB = appendElement(b.shadowRoot);
    let outside = appendElement(document.body, 'button');

    let revert = ariaHideOutside([input, popover]);

    expect(a.host).not.toHaveAttribute('aria-hidden');
    expect(b.host).not.toHaveAttribute('aria-hidden');
    expect(input).not.toHaveAttribute('aria-hidden');
    expect(popover).not.toHaveAttribute('aria-hidden');
    expect(siblingA).toHaveAttribute('aria-hidden', 'true');
    expect(siblingB).toHaveAttribute('aria-hidden', 'true');
    expect(outside).toHaveAttribute('aria-hidden', 'true');

    let addedA = appendElement(a.shadowRoot);
    let addedB = appendElement(b.shadowRoot);
    await waitFor(() => expect(addedB).toHaveAttribute('aria-hidden', 'true'));
    expect(addedA).toHaveAttribute('aria-hidden', 'true');
    revert();
  });

  it('restores shadow root content and stops observing it after revert', async function () {
    let {shadowRoot} = appendTopLevelShadowHost();
    let target = appendElement(shadowRoot);
    let sibling = appendElement(shadowRoot);
    let revert = ariaHideOutside([target]);
    expect(sibling).toHaveAttribute('aria-hidden', 'true');

    revert();
    expect(sibling).not.toHaveAttribute('aria-hidden');

    let added = appendElement(shadowRoot);
    await new Promise((resolve) => setTimeout(resolve, 0));
    expect(added).not.toHaveAttribute('aria-hidden');
  });

  it('re-hides content added to shadow roots after a nested call reverts', async function () {
    let {host, shadowRoot: rootA} = appendTopLevelShadowHost();
    let x1 = appendElement(rootA, 'button');
    let outerTarget = appendElement(rootA);
    let {shadowRoot: rootB} = appendShadowHost(outerTarget);
    let innerTarget = appendElement(rootB);
    let y1 = appendElement(rootB, 'button');
    let outside = appendElement(document.body, 'button');

    let outerRevert = ariaHideOutside([outerTarget]);
    let innerRevert = ariaHideOutside([innerTarget]);

    expect(host).not.toHaveAttribute('aria-hidden');
    expect(outside).toHaveAttribute('aria-hidden', 'true');
    expect(x1).toHaveAttribute('aria-hidden', 'true');
    expect(y1).toHaveAttribute('aria-hidden', 'true');

    innerRevert();
    expect(y1).not.toHaveAttribute('aria-hidden');
    expect(x1).toHaveAttribute('aria-hidden', 'true');

    let added = appendElement(rootA, 'button');
    await waitFor(() => expect(added).toHaveAttribute('aria-hidden', 'true'));
    outerRevert();
    expect(x1).not.toHaveAttribute('aria-hidden');
    expect(added).not.toHaveAttribute('aria-hidden');
    expect(outside).not.toHaveAttribute('aria-hidden');
  });

  it('does not hide shadow-internal wrappers of a slotted target', function () {
    let {host, shadowRoot} = appendShadowHost(document.body);
    shadowRoot.innerHTML = '<div id="wrapper"><slot></slot></div>';
    let wrapper = shadowRoot.getElementById('wrapper');
    let target = appendElement(host, 'input');

    let revert = ariaHideOutside([target]);

    expect(target).not.toHaveAttribute('aria-hidden');
    expect(host).not.toHaveAttribute('aria-hidden');
    expect(wrapper).not.toHaveAttribute('aria-hidden');
    revert();
  });

  it('does not hide anything above or outside a root inside a shadow root, now or later', async function () {
    let {host, shadowRoot} = appendTopLevelShadowHost();
    let outsideRoot = appendElement(shadowRoot, 'button');
    let container = appendElement(shadowRoot);
    let target = appendElement(container, 'input');
    let insideSibling = appendElement(container, 'button');
    let bodySibling = appendElement(document.body, 'button');

    let revert = ariaHideOutside([target], {root: container});

    expect(insideSibling).toHaveAttribute('aria-hidden', 'true');
    expect(outsideRoot).not.toHaveAttribute('aria-hidden');
    expect(bodySibling).not.toHaveAttribute('aria-hidden');
    expect(host).not.toHaveAttribute('aria-hidden');
    expect(container).not.toHaveAttribute('aria-hidden');

    let addedOutsideRoot = appendElement(shadowRoot, 'button');
    let addedInRoot = appendElement(container, 'button');
    await waitFor(() => expect(addedInRoot).toHaveAttribute('aria-hidden', 'true'));
    expect(addedOutsideRoot).not.toHaveAttribute('aria-hidden');
    expect(outsideRoot).not.toHaveAttribute('aria-hidden');
    revert();
  });

  it('does not observe a shadow root whose host is outside a light DOM root', async function () {
    let {host, shadowRoot} = appendTopLevelShadowHost();
    let target = appendElement(shadowRoot);
    let sibling = appendElement(shadowRoot);
    let container = appendElement(document.body);

    let revert = ariaHideOutside([target], {root: container});

    expect(sibling).not.toHaveAttribute('aria-hidden');
    expect(host).not.toHaveAttribute('aria-hidden');

    let addedInShadowRoot = appendElement(shadowRoot, 'button');
    await new Promise((resolve) => setTimeout(resolve, 0));
    expect(addedInShadowRoot).not.toHaveAttribute('aria-hidden');
    expect(sibling).not.toHaveAttribute('aria-hidden');
    expect(host).not.toHaveAttribute('aria-hidden');
    revert();
  });
});

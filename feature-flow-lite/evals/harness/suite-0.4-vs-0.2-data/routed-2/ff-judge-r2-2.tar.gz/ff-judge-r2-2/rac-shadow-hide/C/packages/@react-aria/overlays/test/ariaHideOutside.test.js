/*
 * Copyright 2020 Adobe. All rights reserved.
 * This file is licensed to you under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License. You may obtain a copy
 * of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software distributed under
 * the License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR REPRESENTATIONS
 * OF ANY KIND, either express or implied. See the License for the specific language
 * governing permissions and limitations under the License.
 */

import {act, createShadowRoot, render, waitFor} from '@react-spectrum/test-utils-internal';
import {ariaHideOutside} from '../src';
import {enableShadowDOM} from '@react-stately/flags';
import React, {useRef, useState} from 'react';

describe('ariaHideOutside', function () {
  it('should hide everything except the provided element [button]', function () {
    let {getByRole, getAllByRole} = render(
      <>
        <input type="checkbox" />
        <button>Button</button>
        <input type="checkbox" />
      </>
    );

    let checkboxes = getAllByRole('checkbox');
    let button = getByRole('button');

    let revert = ariaHideOutside([button]);

    expect(checkboxes[0]).toHaveAttribute('aria-hidden', 'true');
    expect(checkboxes[1]).toHaveAttribute('aria-hidden', 'true');
    expect(button).not.toHaveAttribute('aria-hidden');

    expect(() => getAllByRole('checkbox')).toThrow();
    expect(() => getByRole('button')).not.toThrow();

    revert();

    expect(checkboxes[0]).not.toHaveAttribute('aria-hidden');
    expect(checkboxes[1]).not.toHaveAttribute('aria-hidden');
    expect(button).not.toHaveAttribute('aria-hidden');

    expect(() => getAllByRole('checkbox')).not.toThrow();
    expect(() => getByRole('button')).not.toThrow();
  });

  it('should hide everything except multiple elements', function () {
    let {getByRole, getAllByRole, queryByRole, queryAllByRole} = render(
      <>
        <input type="checkbox" />
        <button>Button</button>
        <input type="checkbox" />
      </>
    );

    let checkboxes = getAllByRole('checkbox');
    let button = getByRole('button');

    let revert = ariaHideOutside(checkboxes);

    expect(checkboxes[0]).not.toHaveAttribute('aria-hidden', 'true');
    expect(checkboxes[1]).not.toHaveAttribute('aria-hidden', 'true');
    expect(button).toHaveAttribute('aria-hidden');

    expect(queryAllByRole('checkbox')).not.toBeNull();
    expect(queryByRole('button')).toBeNull();

    revert();

    expect(checkboxes[0]).not.toHaveAttribute('aria-hidden');
    expect(checkboxes[1]).not.toHaveAttribute('aria-hidden');
    expect(button).not.toHaveAttribute('aria-hidden');

    expect(() => getAllByRole('checkbox')).not.toThrow();
    expect(() => getByRole('button')).not.toThrow();
  });

  it('should not traverse into an already hidden container', function () {
    let {getByRole, getAllByRole} = render(
      <>
        <div>
          <input type="checkbox" />
        </div>
        <button>Button</button>
        <input type="checkbox" />
      </>
    );

    let checkboxes = getAllByRole('checkbox');
    let button = getByRole('button');

    let revert = ariaHideOutside([button]);

    expect(checkboxes[0].parentElement).toHaveAttribute('aria-hidden', 'true');
    expect(checkboxes[1]).toHaveAttribute('aria-hidden', 'true');
    expect(button).not.toHaveAttribute('aria-hidden');

    expect(() => getAllByRole('checkbox')).toThrow();
    expect(() => getByRole('button')).not.toThrow();

    revert();

    expect(checkboxes[0].parentElement).not.toHaveAttribute('aria-hidden');
    expect(checkboxes[1]).not.toHaveAttribute('aria-hidden');
    expect(button).not.toHaveAttribute('aria-hidden');

    expect(() => getAllByRole('checkbox')).not.toThrow();
    expect(() => getByRole('button')).not.toThrow();
  });

  it('should not overwrite an existing aria-hidden prop', function () {
    let {getByRole, getAllByRole} = render(
      <>
        <input type="checkbox" aria-hidden="true" />
        <button>Button</button>
        <input type="checkbox" />
      </>
    );

    let checkboxes = getAllByRole('checkbox');
    let button = getByRole('button');

    let revert = ariaHideOutside([button]);

    expect(checkboxes).toHaveLength(1);
    expect(checkboxes[0]).toHaveAttribute('aria-hidden', 'true');
    expect(button).not.toHaveAttribute('aria-hidden');

    expect(() => getAllByRole('checkbox')).toThrow();
    expect(() => getByRole('button')).not.toThrow();

    revert();

    checkboxes = getAllByRole('checkbox');
    expect(checkboxes).toHaveLength(1);
    expect(checkboxes[0]).not.toHaveAttribute('aria-hidden');
    expect(button).not.toHaveAttribute('aria-hidden');

    expect(() => getAllByRole('checkbox')).not.toThrow();
    expect(() => getByRole('button')).not.toThrow();
  });

  it('should handle when a new element is added outside while active', async function () {
    let Test = props => (
      <>
        {props.show && <input type="checkbox" />}
        <button>Button</button>
        {props.show && <input type="checkbox" />}
      </>
    );

    let {getByRole, getAllByRole, rerender} = render(<Test />);

    let button = getByRole('button');
    expect(() => getAllByRole('checkbox')).toThrow();

    let revert = ariaHideOutside([button]);

    rerender(<Test show />);

    // MutationObserver is async
    await waitFor(() => expect(() => getAllByRole('checkbox')).toThrow());
    expect(() => getByRole('button')).not.toThrow();

    revert();

    expect(getAllByRole('checkbox')).toHaveLength(2);
  });

  it('should handle when a new element is added to an already hidden container', async function () {
    let Test = props => (
      <>
        <div data-testid="test">
          {props.show && <input type="checkbox" />}
        </div>
        <button>Button</button>
        {props.show && <input type="checkbox" />}
      </>
    );

    let {getByRole, getAllByRole, getByTestId, rerender} = render(<Test />);

    let button = getByRole('button');
    let test = getByTestId('test');
    expect(() => getAllByRole('checkbox')).toThrow();

    let revert = ariaHideOutside([button]);

    expect(test).toHaveAttribute('aria-hidden');

    rerender(<Test show />);

    // MutationObserver is async
    await waitFor(() => expect(() => getAllByRole('checkbox')).toThrow());
    expect(() => getByRole('button')).not.toThrow();

    let checkboxes = getAllByRole('checkbox', {hidden: true});
    expect(test).toHaveAttribute('aria-hidden');
    expect(checkboxes[0]).not.toHaveAttribute('aria-hidden');
    expect(checkboxes[1]).toHaveAttribute('aria-hidden', 'true');

    revert();

    expect(getAllByRole('checkbox')).toHaveLength(2);
  });

  it('should handle when a new element is added along with a top layer element', async function () {
    let Test = props => (
      <>
        <button>Button</button>
        {props.show && <div>
          <div role="alert" data-react-aria-top-layer="true">Top layer</div>
          <input type="checkbox" />
        </div>}
      </>
    );

    let {getByRole, queryByRole, getAllByRole, rerender} = render(<Test />);

    let button = getByRole('button');
    expect(queryByRole('checkbox')).toBeNull();

    let revert = ariaHideOutside([button]);

    rerender(<Test show />);

    // MutationObserver is async
    await waitFor(() => queryByRole('checkbox') == null);
    expect(queryByRole('button')).not.toBeNull();
    expect(getByRole('alert')).toHaveTextContent('Top layer');

    revert();

    expect(getAllByRole('checkbox')).toHaveLength(1);
  });

  it('should handle when a new element is added inside a target element', async function () {
    let Test = props => (
      <>
        <input type="checkbox" />
        <div data-testid="test">
          <button>Button</button>
          {props.show && <input type="radio" />}
        </div>
        <input type="checkbox" />
      </>
    );

    let {queryByRole, getByRole, getAllByRole, getByTestId, rerender} = render(<Test />);

    let test = getByTestId('test');
    let revert = ariaHideOutside([test]);

    expect(() => getAllByRole('checkbox')).toThrow();
    expect(queryByRole('radio')).toBeNull();
    expect(queryByRole('button')).not.toBeNull();
    expect(() => getByTestId('test')).not.toThrow();

    rerender(<Test show />);

    // Wait for mutation observer tick
    await Promise.resolve();
    expect(() => getAllByRole('checkbox')).toThrow();
    expect(() => getByRole('radio')).not.toThrow();
    expect(() => getByRole('button')).not.toThrow();
    expect(() => getByTestId('test')).not.toThrow();

    revert();

    expect(() => getAllByRole('checkbox')).not.toThrow();
    expect(() => getByRole('radio')).not.toThrow();
    expect(() => getByRole('button')).not.toThrow();
    expect(() => getByTestId('test')).not.toThrow();
  });

  it('should handle when a new element is added and then reparented', async function () {

    let Test = () => {
      const ref = useRef(null);
      const mutate = () => {
        let parent = document.createElement('ul');
        let child = document.createElement('li');
        ref.current.append(parent);
        parent.appendChild(child);
        parent.remove(); // this results in a mutation record for a disconnected ul with a connected li (through the new ul parent) in `addedNodes`
        let newParent = document.createElement('ul');
        newParent.appendChild(child);
        ref.current.append(newParent);
      };

      return (
        <>
          <div data-testid="test" ref={ref}>
            <button onClick={mutate}>Mutate</button>
          </div>
        </>
      );
    };

    let {queryByRole, getAllByRole, getByTestId} = render(<Test />);

    ariaHideOutside([getByTestId('test')]);

    queryByRole('button').click();
    await Promise.resolve(); // Wait for mutation observer tick

    expect(getAllByRole('listitem')).toHaveLength(1);
  });

  it('should handle when a new element is added and then reparented to a hidden container', async function () {

    let Test = () => {
      const ref = useRef(null);
      const mutate = () => {
        let parent = document.createElement('ul');
        let child = document.createElement('li');
        ref.current.append(parent);
        parent.appendChild(child);
        parent.remove(); // this results in a mutation record for a disconnected ul with a connected li (through the new ul parent) in `addedNodes`
        let newParent = document.createElement('ul');
        newParent.appendChild(child);
        ref.current.append(newParent);
      };

      return (
        <>
          <div data-testid="test">
            <button onClick={mutate}>Mutate</button>
          </div>
          <div data-testid="sibling" ref={ref} />
        </>
      );
    };

    let {queryByRole, queryAllByRole, getByTestId} = render(<Test />);

    ariaHideOutside([getByTestId('test')]);

    queryByRole('button').click();
    await Promise.resolve(); // Wait for mutation observer tick

    expect(queryAllByRole('listitem')).toHaveLength(0);
  });


  it('work when called multiple times', function () {
    let {getByRole, getAllByRole} = render(
      <>
        <input type="checkbox" />
        <input type="radio" />
        <button>Button</button>
        <input type="radio" />
        <input type="checkbox" />
      </>
    );

    let radios = getAllByRole('radio');
    let button = getByRole('button');

    let revert1 = ariaHideOutside([button, ...radios]);

    expect(() => getAllByRole('checkbox')).toThrow();
    expect(() => getAllByRole('radio')).not.toThrow();
    expect(() => getByRole('button')).not.toThrow();

    let revert2 = ariaHideOutside([button]);

    expect(() => getAllByRole('checkbox')).toThrow();
    expect(() => getAllByRole('radio')).toThrow();
    expect(() => getByRole('button')).not.toThrow();

    revert2();

    expect(() => getAllByRole('checkbox')).toThrow();
    expect(() => getAllByRole('radio')).not.toThrow();
    expect(() => getByRole('button')).not.toThrow();

    revert1();

    expect(() => getAllByRole('checkbox')).not.toThrow();
    expect(() => getAllByRole('radio')).not.toThrow();
    expect(() => getByRole('button')).not.toThrow();
  });

  it('work when called multiple times and restored out of order', function () {
    let {getByRole, getAllByRole} = render(
      <>
        <input type="checkbox" />
        <input type="radio" />
        <button>Button</button>
        <input type="radio" />
        <input type="checkbox" />
      </>
    );

    let radios = getAllByRole('radio');
    let button = getByRole('button');

    let revert1 = ariaHideOutside([button, ...radios]);

    expect(() => getAllByRole('checkbox')).toThrow();
    expect(() => getAllByRole('radio')).not.toThrow();
    expect(() => getByRole('button')).not.toThrow();

    let revert2 = ariaHideOutside([button]);

    expect(() => getAllByRole('checkbox')).toThrow();
    expect(() => getAllByRole('radio')).toThrow();
    expect(() => getByRole('button')).not.toThrow();

    revert1();

    expect(() => getAllByRole('checkbox')).toThrow();
    expect(() => getAllByRole('radio')).toThrow();
    expect(() => getByRole('button')).not.toThrow();

    revert2();

    expect(() => getAllByRole('checkbox')).not.toThrow();
    expect(() => getAllByRole('radio')).not.toThrow();
    expect(() => getByRole('button')).not.toThrow();
  });

  it('should hide everything except the provided element [row]', function () {
    let {getAllByRole, getByTestId} = render(
      <div role="grid">
        <div role="row">
          <div role="gridcell">
            <span data-testid="test-span">
              Cell 1
            </span></div>
        </div>
        <div role="row">
          <div role="gridcell">Cell 2</div>
        </div>
      </div>
    );

    let cells = getAllByRole('gridcell');
    let rows = getAllByRole('row');
    let span = getByTestId('test-span');

    let revert = ariaHideOutside([rows[1]]);

    // Applies aria-hidden to the row and cell despite recursive nature of aria-hidden
    // for https://bugs.webkit.org/show_bug.cgi?id=222623
    expect(rows[0]).toHaveAttribute('aria-hidden', 'true');
    expect(cells[0]).toHaveAttribute('aria-hidden', 'true');
    expect(span).not.toHaveAttribute('aria-hidden');
    expect(rows[1]).not.toHaveAttribute('aria-hidden', 'true');
    expect(cells[1]).not.toHaveAttribute('aria-hidden', 'true');

    revert();

    expect(rows[0]).not.toHaveAttribute('aria-hidden', 'true');
    expect(cells[0]).not.toHaveAttribute('aria-hidden', 'true');
    expect(rows[1]).not.toHaveAttribute('aria-hidden', 'true');
    expect(cells[1]).not.toHaveAttribute('aria-hidden', 'true');
    expect(span).not.toHaveAttribute('aria-hidden');
  });

  it('should unhide after item reorder', async function () {
    function Item(props) {
      return (
        <div role="presentation">
          <div data-testid={props.testid} role="row">
            <div role="gridcell" />
          </div>
        </div>
      );
    }

    function Test() {
      let [count, setCount] = useState(0);
      let items = ['row1', 'row2', 'row3', 'row4', 'row5'];
      if (count === 1) {
        items = ['row2', 'row1', 'row3', 'row4', 'row5'];
      } else if (count === 2) {
        items = ['row2', 'row3', 'row1', 'row4', 'row5'];
      }

      return (
        <>
          <button onClick={() => setCount((old) => old + 1)}>press</button>
          {items.map((item) => <Item testid={item} key={item} />)}
        </>

      );
    }

    let {getByRole, getByTestId} = render(
      <Test />
    );

    let button = getByRole('button');
    let row = getByTestId('row1');
    let revert = ariaHideOutside([button]);

    act(() => button.click());
    await Promise.resolve();
    act(() => button.click());
    await Promise.resolve();
    revert();
    expect(row.parentElement).not.toHaveAttribute('aria-hidden', 'true');
  });

  it('should not walk or observe shadow roots when shadow DOM is disabled', async function () {
    let {getByRole} = render(<button>Button</button>);
    let {shadowRoot, cleanup} = createShadowRoot();
    let sibling = document.createElement('input');
    shadowRoot.appendChild(sibling);

    let revert = ariaHideOutside([getByRole('button')]);

    let added = document.createElement('input');
    shadowRoot.appendChild(added);
    await Promise.resolve();

    expect(sibling).not.toHaveAttribute('aria-hidden');
    expect(added).not.toHaveAttribute('aria-hidden');

    revert();
    cleanup();
  });
});

describe('ariaHideOutside with shadow DOM', function () {
  let cleanups = [];

  beforeAll(() => {
    enableShadowDOM();
  });

  afterEach(() => {
    for (let cleanup of cleanups) {
      cleanup();
    }
    cleanups = [];
  });

  let append = (parent, tag, attrs = {}) => {
    let element = document.createElement(tag);
    for (let key in attrs) {
      element.setAttribute(key, attrs[key]);
    }
    parent.appendChild(element);
    return element;
  };

  // Creates a shadow host inside a shadow root, which is removed along with its parent host.
  let attachShadow = (parent) => {
    let host = append(parent, 'div');
    return {shadowHost: host, shadowRoot: host.attachShadow({mode: 'open'})};
  };

  let createHost = () => {
    let {shadowHost, shadowRoot, cleanup} = createShadowRoot();
    cleanups.push(cleanup);
    return {shadowHost, shadowRoot};
  };

  let addLightElement = (tag, attrs) => {
    let element = append(document.body, tag, attrs);
    cleanups.push(() => element.remove());
    return element;
  };

  it('should hide siblings in every shadow root that encloses a target, keeping hosts visible', function () {
    let outer = createHost();
    let inner = attachShadow(outer.shadowRoot);
    let light = addLightElement('button');
    let outerSibling = append(outer.shadowRoot, 'input', {type: 'checkbox'});
    let innerSibling = append(inner.shadowRoot, 'input', {type: 'checkbox'});
    let target = append(inner.shadowRoot, 'button');

    let revert = ariaHideOutside([target]);

    expect(light).toHaveAttribute('aria-hidden', 'true');
    expect(outerSibling).toHaveAttribute('aria-hidden', 'true');
    expect(innerSibling).toHaveAttribute('aria-hidden', 'true');
    expect(target).not.toHaveAttribute('aria-hidden');
    expect(inner.shadowHost).not.toHaveAttribute('aria-hidden');
    expect(outer.shadowHost).not.toHaveAttribute('aria-hidden');

    revert();
  });

  it('should hide siblings when the target is a direct child of a shadow root', function () {
    let host = createHost();
    let target = append(host.shadowRoot, 'button');
    let sibling = append(host.shadowRoot, 'input', {type: 'checkbox'});

    let revert = ariaHideOutside([target]);

    expect(sibling).toHaveAttribute('aria-hidden', 'true');
    expect(target).not.toHaveAttribute('aria-hidden');
    expect(host.shadowHost).not.toHaveAttribute('aria-hidden');

    revert();
  });

  it('should hide other shadow hosts without touching the contents of shadow roots with no target', function () {
    let targetHost = createHost();
    let target = append(targetHost.shadowRoot, 'button');
    let otherHost = createHost();
    let otherInput = append(otherHost.shadowRoot, 'input', {type: 'checkbox'});

    let revert = ariaHideOutside([target]);

    expect(otherHost.shadowHost).toHaveAttribute('aria-hidden', 'true');
    expect(otherInput).not.toHaveAttribute('aria-hidden');
    expect(targetHost.shadowHost).not.toHaveAttribute('aria-hidden');
    expect(target).not.toHaveAttribute('aria-hidden');

    revert();
  });

  it('should hide siblings in the shadow roots of targets in different shadow roots', async function () {
    let a = createHost();
    let b = createHost();
    let targetA = append(a.shadowRoot, 'button');
    let siblingA = append(a.shadowRoot, 'input', {type: 'checkbox'});
    let targetB = append(b.shadowRoot, 'button');
    let siblingB = append(b.shadowRoot, 'input', {type: 'checkbox'});

    let revert = ariaHideOutside([targetA, targetB]);

    expect(a.shadowHost).not.toHaveAttribute('aria-hidden');
    expect(b.shadowHost).not.toHaveAttribute('aria-hidden');
    expect(targetA).not.toHaveAttribute('aria-hidden');
    expect(targetB).not.toHaveAttribute('aria-hidden');
    expect(siblingA).toHaveAttribute('aria-hidden', 'true');
    expect(siblingB).toHaveAttribute('aria-hidden', 'true');

    let addedA = append(a.shadowRoot, 'input', {type: 'checkbox'});
    let addedB = append(b.shadowRoot, 'input', {type: 'checkbox'});
    // MutationObserver is async
    await waitFor(() => expect(addedB).toHaveAttribute('aria-hidden', 'true'));
    expect(addedA).toHaveAttribute('aria-hidden', 'true');
    expect(targetA).not.toHaveAttribute('aria-hidden');
    expect(targetB).not.toHaveAttribute('aria-hidden');

    revert();
  });

  it('should hide content added later to the target shadow root, enclosing roots, and the light DOM', async function () {
    let outer = createHost();
    let inner = attachShadow(outer.shadowRoot);
    let target = append(inner.shadowRoot, 'button');

    let revert = ariaHideOutside([target]);

    let innerAdded = append(inner.shadowRoot, 'input', {type: 'checkbox'});
    let outerAdded = append(outer.shadowRoot, 'input', {type: 'checkbox'});
    let lightAdded = addLightElement('input', {type: 'checkbox'});
    // MutationObserver is async
    await waitFor(() => expect(lightAdded).toHaveAttribute('aria-hidden', 'true'));
    expect(innerAdded).toHaveAttribute('aria-hidden', 'true');
    expect(outerAdded).toHaveAttribute('aria-hidden', 'true');
    expect(target).not.toHaveAttribute('aria-hidden');
    expect(inner.shadowHost).not.toHaveAttribute('aria-hidden');

    revert();
  });

  it('should not separately hide content added inside a hidden element or a target in a shadow root', async function () {
    let host = createHost();
    let target = append(host.shadowRoot, 'button');
    let panel = append(host.shadowRoot, 'div');

    let revert = ariaHideOutside([target]);

    let panelChild = append(panel, 'span');
    let targetChild = append(target, 'span');
    let sibling = append(host.shadowRoot, 'input', {type: 'checkbox'});
    // MutationObserver is async
    await waitFor(() => expect(sibling).toHaveAttribute('aria-hidden', 'true'));
    expect(panel).toHaveAttribute('aria-hidden', 'true');
    expect(panelChild).not.toHaveAttribute('aria-hidden');
    expect(targetChild).not.toHaveAttribute('aria-hidden');
    expect(target).not.toHaveAttribute('aria-hidden');

    revert();
  });

  it('should keep live announcers and top layer elements visible in shadow roots', async function () {
    let outer = createHost();
    let inner = attachShadow(outer.shadowRoot);
    let target = append(inner.shadowRoot, 'button');
    let existingAnnouncer = append(outer.shadowRoot, 'div', {'data-live-announcer': 'true'});

    let revert = ariaHideOutside([target]);

    let addedAnnouncer = append(inner.shadowRoot, 'div', {'data-live-announcer': 'true'});
    let addedTopLayer = append(outer.shadowRoot, 'div', {'data-react-aria-top-layer': 'true'});
    let sibling = append(inner.shadowRoot, 'input', {type: 'checkbox'});
    // MutationObserver is async
    await waitFor(() => expect(sibling).toHaveAttribute('aria-hidden', 'true'));
    expect(existingAnnouncer).not.toHaveAttribute('aria-hidden');
    expect(addedAnnouncer).not.toHaveAttribute('aria-hidden');
    expect(addedTopLayer).not.toHaveAttribute('aria-hidden');

    revert();
  });

  it('should restore everything and stop observing shadow roots after cleanup', async function () {
    let outer = createHost();
    let inner = attachShadow(outer.shadowRoot);
    let target = append(inner.shadowRoot, 'button');
    let sibling = append(outer.shadowRoot, 'input', {type: 'checkbox'});
    let preHidden = append(inner.shadowRoot, 'input', {type: 'checkbox', 'aria-hidden': 'true'});

    let revert = ariaHideOutside([target], {shouldUseInert: true});

    expect(sibling).toHaveAttribute('aria-hidden', 'true');

    revert();

    expect(sibling).not.toHaveAttribute('aria-hidden');
    expect(preHidden).toHaveAttribute('aria-hidden', 'true');

    let addedOuter = append(outer.shadowRoot, 'input', {type: 'checkbox'});
    let addedInner = append(inner.shadowRoot, 'input', {type: 'checkbox'});
    await Promise.resolve();
    expect(addedOuter).not.toHaveAttribute('aria-hidden');
    expect(addedInner).not.toHaveAttribute('aria-hidden');
  });

  it('should re-observe the outer shadow roots after a nested call is cleaned up', async function () {
    let host = createHost();
    let target = append(host.shadowRoot, 'button');
    let otherTarget = append(host.shadowRoot, 'button');

    let outerRevert = ariaHideOutside([target]);
    let innerRevert = ariaHideOutside([otherTarget]);
    innerRevert();

    expect(otherTarget).toHaveAttribute('aria-hidden', 'true');
    expect(target).not.toHaveAttribute('aria-hidden');

    let added = append(host.shadowRoot, 'input', {type: 'checkbox'});
    // MutationObserver is async
    await waitFor(() => expect(added).toHaveAttribute('aria-hidden', 'true'));
    expect(target).not.toHaveAttribute('aria-hidden');

    outerRevert();

    expect(otherTarget).not.toHaveAttribute('aria-hidden');
    expect(added).not.toHaveAttribute('aria-hidden');
  });

  it('should not walk shadow roots whose host is outside the root option', async function () {
    let container = addLightElement('div');
    let target = append(container, 'button');
    let lightSibling = append(container, 'input', {type: 'checkbox'});
    let outside = createHost();
    let outsideSibling = append(outside.shadowRoot, 'input', {type: 'checkbox'});

    let revert = ariaHideOutside([target], container);

    expect(lightSibling).toHaveAttribute('aria-hidden', 'true');
    expect(container).not.toHaveAttribute('aria-hidden');
    expect(outside.shadowHost).not.toHaveAttribute('aria-hidden');
    expect(outsideSibling).not.toHaveAttribute('aria-hidden');
    expect(target).not.toHaveAttribute('aria-hidden');

    revert();
  });

  it('should hide shadow siblings of a slotted target and keep the slot path visible', async function () {
    let host = createHost();
    let trigger = append(host.shadowRoot, 'button');
    let wrapper = append(host.shadowRoot, 'div');
    let slot = append(wrapper, 'slot');
    let target = append(host.shadowHost, 'button');

    let revert = ariaHideOutside([target]);

    expect(trigger).toHaveAttribute('aria-hidden', 'true');
    expect(wrapper).not.toHaveAttribute('aria-hidden');
    expect(slot).not.toHaveAttribute('aria-hidden');
    expect(target).not.toHaveAttribute('aria-hidden');
    expect(host.shadowHost).not.toHaveAttribute('aria-hidden');

    let added = append(host.shadowRoot, 'input', {type: 'checkbox'});
    // MutationObserver is async
    await waitFor(() => expect(added).toHaveAttribute('aria-hidden', 'true'));
    expect(slot).not.toHaveAttribute('aria-hidden');

    revert();

    expect(trigger).not.toHaveAttribute('aria-hidden');
    expect(wrapper).not.toHaveAttribute('aria-hidden');
    expect(added).not.toHaveAttribute('aria-hidden');
    expect(target).not.toHaveAttribute('aria-hidden');
    expect(host.shadowHost).not.toHaveAttribute('aria-hidden');
  });

  it('should hide shadow siblings of a host that is slotted into another shadow root', function () {
    let outer = createHost();
    let outerSibling = append(outer.shadowRoot, 'input', {type: 'checkbox'});
    let outerSlot = append(outer.shadowRoot, 'slot');
    let inner = attachShadow(outer.shadowHost);
    let innerTrigger = append(inner.shadowRoot, 'button');
    let target = append(inner.shadowRoot, 'button');

    let revert = ariaHideOutside([target]);

    expect(outerSibling).toHaveAttribute('aria-hidden', 'true');
    expect(outerSlot).not.toHaveAttribute('aria-hidden');
    expect(inner.shadowHost).not.toHaveAttribute('aria-hidden');
    expect(outer.shadowHost).not.toHaveAttribute('aria-hidden');
    expect(innerTrigger).toHaveAttribute('aria-hidden', 'true');
    expect(target).not.toHaveAttribute('aria-hidden');

    revert();

    expect(outerSibling).not.toHaveAttribute('aria-hidden');
    expect(innerTrigger).not.toHaveAttribute('aria-hidden');
  });

  it('should hide a slot the target is not projected through', function () {
    let host = createHost();
    let pathSlot = append(host.shadowRoot, 'slot');
    let otherSlot = append(host.shadowRoot, 'slot', {name: 'other'});
    let otherContent = append(host.shadowHost, 'span', {slot: 'other'});
    let target = append(host.shadowHost, 'button');

    let revert = ariaHideOutside([target]);

    expect(otherSlot).toHaveAttribute('aria-hidden', 'true');
    expect(otherContent).toHaveAttribute('aria-hidden', 'true');
    expect(pathSlot).not.toHaveAttribute('aria-hidden');
    expect(host.shadowHost).not.toHaveAttribute('aria-hidden');
    expect(target).not.toHaveAttribute('aria-hidden');

    revert();

    expect(otherSlot).not.toHaveAttribute('aria-hidden');
    expect(otherContent).not.toHaveAttribute('aria-hidden');
  });

  it('should keep a slot added later to a path host shadow root visible and hide siblings added in the same batch', async function () {
    let host = createHost();
    let target = append(host.shadowHost, 'button');

    let revert = ariaHideOutside([target]);

    let slot = append(host.shadowRoot, 'slot');
    let sibling = append(host.shadowRoot, 'input', {type: 'checkbox'});
    // MutationObserver is async
    await waitFor(() => expect(sibling).toHaveAttribute('aria-hidden', 'true'));
    expect(slot).not.toHaveAttribute('aria-hidden');
    expect(target).not.toHaveAttribute('aria-hidden');
    expect(host.shadowHost).not.toHaveAttribute('aria-hidden');

    revert();

    expect(slot).not.toHaveAttribute('aria-hidden');
    expect(sibling).not.toHaveAttribute('aria-hidden');
  });
});

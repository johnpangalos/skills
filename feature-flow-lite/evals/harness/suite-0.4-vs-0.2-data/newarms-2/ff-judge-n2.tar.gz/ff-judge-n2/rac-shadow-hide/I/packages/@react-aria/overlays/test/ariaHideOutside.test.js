/*
 * Copyright 2020 Adobe. All rights reserved.
 * This file is licensed to you under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License. You may obtain a copy
 * of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software distributed under
 * the License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR REPRESENTATIONS
 * OF ANY KIND, either express or implied. See the License for the specific language
 * governing permissions and limitations under the License.
 */

import {act, createShadowRoot, render, waitFor} from '@react-spectrum/test-utils-internal';
import {ariaHideOutside} from '../src';
import {enableShadowDOM} from '@react-stately/flags';
import {keepVisible} from '../src/ariaHideOutside';
import React, {useRef, useState} from 'react';

describe('ariaHideOutside', function () {
  it('should hide everything except the provided element [button]', function () {
    let {getByRole, getAllByRole} = render(
      <>
        <input type="checkbox" />
        <button>Button</button>
        <input type="checkbox" />
      </>
    );

    let checkboxes = getAllByRole('checkbox');
    let button = getByRole('button');

    let revert = ariaHideOutside([button]);

    expect(checkboxes[0]).toHaveAttribute('aria-hidden', 'true');
    expect(checkboxes[1]).toHaveAttribute('aria-hidden', 'true');
    expect(button).not.toHaveAttribute('aria-hidden');

    expect(() => getAllByRole('checkbox')).toThrow();
    expect(() => getByRole('button')).not.toThrow();

    revert();

    expect(checkboxes[0]).not.toHaveAttribute('aria-hidden');
    expect(checkboxes[1]).not.toHaveAttribute('aria-hidden');
    expect(button).not.toHaveAttribute('aria-hidden');

    expect(() => getAllByRole('checkbox')).not.toThrow();
    expect(() => getByRole('button')).not.toThrow();
  });

  it('should hide everything except multiple elements', function () {
    let {getByRole, getAllByRole, queryByRole, queryAllByRole} = render(
      <>
        <input type="checkbox" />
        <button>Button</button>
        <input type="checkbox" />
      </>
    );

    let checkboxes = getAllByRole('checkbox');
    let button = getByRole('button');

    let revert = ariaHideOutside(checkboxes);

    expect(checkboxes[0]).not.toHaveAttribute('aria-hidden', 'true');
    expect(checkboxes[1]).not.toHaveAttribute('aria-hidden', 'true');
    expect(button).toHaveAttribute('aria-hidden');

    expect(queryAllByRole('checkbox')).not.toBeNull();
    expect(queryByRole('button')).toBeNull();

    revert();

    expect(checkboxes[0]).not.toHaveAttribute('aria-hidden');
    expect(checkboxes[1]).not.toHaveAttribute('aria-hidden');
    expect(button).not.toHaveAttribute('aria-hidden');

    expect(() => getAllByRole('checkbox')).not.toThrow();
    expect(() => getByRole('button')).not.toThrow();
  });

  it('should not traverse into an already hidden container', function () {
    let {getByRole, getAllByRole} = render(
      <>
        <div>
          <input type="checkbox" />
        </div>
        <button>Button</button>
        <input type="checkbox" />
      </>
    );

    let checkboxes = getAllByRole('checkbox');
    let button = getByRole('button');

    let revert = ariaHideOutside([button]);

    expect(checkboxes[0].parentElement).toHaveAttribute('aria-hidden', 'true');
    expect(checkboxes[1]).toHaveAttribute('aria-hidden', 'true');
    expect(button).not.toHaveAttribute('aria-hidden');

    expect(() => getAllByRole('checkbox')).toThrow();
    expect(() => getByRole('button')).not.toThrow();

    revert();

    expect(checkboxes[0].parentElement).not.toHaveAttribute('aria-hidden');
    expect(checkboxes[1]).not.toHaveAttribute('aria-hidden');
    expect(button).not.toHaveAttribute('aria-hidden');

    expect(() => getAllByRole('checkbox')).not.toThrow();
    expect(() => getByRole('button')).not.toThrow();
  });

  it('should not overwrite an existing aria-hidden prop', function () {
    let {getByRole, getAllByRole} = render(
      <>
        <input type="checkbox" aria-hidden="true" />
        <button>Button</button>
        <input type="checkbox" />
      </>
    );

    let checkboxes = getAllByRole('checkbox');
    let button = getByRole('button');

    let revert = ariaHideOutside([button]);

    expect(checkboxes).toHaveLength(1);
    expect(checkboxes[0]).toHaveAttribute('aria-hidden', 'true');
    expect(button).not.toHaveAttribute('aria-hidden');

    expect(() => getAllByRole('checkbox')).toThrow();
    expect(() => getByRole('button')).not.toThrow();

    revert();

    checkboxes = getAllByRole('checkbox');
    expect(checkboxes).toHaveLength(1);
    expect(checkboxes[0]).not.toHaveAttribute('aria-hidden');
    expect(button).not.toHaveAttribute('aria-hidden');

    expect(() => getAllByRole('checkbox')).not.toThrow();
    expect(() => getByRole('button')).not.toThrow();
  });

  it('should handle when a new element is added outside while active', async function () {
    let Test = props => (
      <>
        {props.show && <input type="checkbox" />}
        <button>Button</button>
        {props.show && <input type="checkbox" />}
      </>
    );

    let {getByRole, getAllByRole, rerender} = render(<Test />);

    let button = getByRole('button');
    expect(() => getAllByRole('checkbox')).toThrow();

    let revert = ariaHideOutside([button]);

    rerender(<Test show />);

    // MutationObserver is async
    await waitFor(() => expect(() => getAllByRole('checkbox')).toThrow());
    expect(() => getByRole('button')).not.toThrow();

    revert();

    expect(getAllByRole('checkbox')).toHaveLength(2);
  });

  it('should handle when a new element is added to an already hidden container', async function () {
    let Test = props => (
      <>
        <div data-testid="test">
          {props.show && <input type="checkbox" />}
        </div>
        <button>Button</button>
        {props.show && <input type="checkbox" />}
      </>
    );

    let {getByRole, getAllByRole, getByTestId, rerender} = render(<Test />);

    let button = getByRole('button');
    let test = getByTestId('test');
    expect(() => getAllByRole('checkbox')).toThrow();

    let revert = ariaHideOutside([button]);

    expect(test).toHaveAttribute('aria-hidden');

    rerender(<Test show />);

    // MutationObserver is async
    await waitFor(() => expect(() => getAllByRole('checkbox')).toThrow());
    expect(() => getByRole('button')).not.toThrow();

    let checkboxes = getAllByRole('checkbox', {hidden: true});
    expect(test).toHaveAttribute('aria-hidden');
    expect(checkboxes[0]).not.toHaveAttribute('aria-hidden');
    expect(checkboxes[1]).toHaveAttribute('aria-hidden', 'true');

    revert();

    expect(getAllByRole('checkbox')).toHaveLength(2);
  });

  it('should handle when a new element is added along with a top layer element', async function () {
    let Test = props => (
      <>
        <button>Button</button>
        {props.show && <div>
          <div role="alert" data-react-aria-top-layer="true">Top layer</div>
          <input type="checkbox" />
        </div>}
      </>
    );

    let {getByRole, queryByRole, getAllByRole, rerender} = render(<Test />);

    let button = getByRole('button');
    expect(queryByRole('checkbox')).toBeNull();

    let revert = ariaHideOutside([button]);

    rerender(<Test show />);

    // MutationObserver is async
    await waitFor(() => queryByRole('checkbox') == null);
    expect(queryByRole('button')).not.toBeNull();
    expect(getByRole('alert')).toHaveTextContent('Top layer');

    revert();

    expect(getAllByRole('checkbox')).toHaveLength(1);
  });

  it('should handle when a new element is added inside a target element', async function () {
    let Test = props => (
      <>
        <input type="checkbox" />
        <div data-testid="test">
          <button>Button</button>
          {props.show && <input type="radio" />}
        </div>
        <input type="checkbox" />
      </>
    );

    let {queryByRole, getByRole, getAllByRole, getByTestId, rerender} = render(<Test />);

    let test = getByTestId('test');
    let revert = ariaHideOutside([test]);

    expect(() => getAllByRole('checkbox')).toThrow();
    expect(queryByRole('radio')).toBeNull();
    expect(queryByRole('button')).not.toBeNull();
    expect(() => getByTestId('test')).not.toThrow();

    rerender(<Test show />);

    // Wait for mutation observer tick
    await Promise.resolve();
    expect(() => getAllByRole('checkbox')).toThrow();
    expect(() => getByRole('radio')).not.toThrow();
    expect(() => getByRole('button')).not.toThrow();
    expect(() => getByTestId('test')).not.toThrow();

    revert();

    expect(() => getAllByRole('checkbox')).not.toThrow();
    expect(() => getByRole('radio')).not.toThrow();
    expect(() => getByRole('button')).not.toThrow();
    expect(() => getByTestId('test')).not.toThrow();
  });

  it('should handle when a new element is added and then reparented', async function () {

    let Test = () => {
      const ref = useRef(null);
      const mutate = () => {
        let parent = document.createElement('ul');
        let child = document.createElement('li');
        ref.current.append(parent);
        parent.appendChild(child);
        parent.remove(); // this results in a mutation record for a disconnected ul with a connected li (through the new ul parent) in `addedNodes`
        let newParent = document.createElement('ul');
        newParent.appendChild(child);
        ref.current.append(newParent);
      };

      return (
        <>
          <div data-testid="test" ref={ref}>
            <button onClick={mutate}>Mutate</button>
          </div>
        </>
      );
    };

    let {queryByRole, getAllByRole, getByTestId} = render(<Test />);

    ariaHideOutside([getByTestId('test')]);

    queryByRole('button').click();
    await Promise.resolve(); // Wait for mutation observer tick

    expect(getAllByRole('listitem')).toHaveLength(1);
  });

  it('should handle when a new element is added and then reparented to a hidden container', async function () {

    let Test = () => {
      const ref = useRef(null);
      const mutate = () => {
        let parent = document.createElement('ul');
        let child = document.createElement('li');
        ref.current.append(parent);
        parent.appendChild(child);
        parent.remove(); // this results in a mutation record for a disconnected ul with a connected li (through the new ul parent) in `addedNodes`
        let newParent = document.createElement('ul');
        newParent.appendChild(child);
        ref.current.append(newParent);
      };

      return (
        <>
          <div data-testid="test">
            <button onClick={mutate}>Mutate</button>
          </div>
          <div data-testid="sibling" ref={ref} />
        </>
      );
    };

    let {queryByRole, queryAllByRole, getByTestId} = render(<Test />);

    ariaHideOutside([getByTestId('test')]);

    queryByRole('button').click();
    await Promise.resolve(); // Wait for mutation observer tick

    expect(queryAllByRole('listitem')).toHaveLength(0);
  });


  it('work when called multiple times', function () {
    let {getByRole, getAllByRole} = render(
      <>
        <input type="checkbox" />
        <input type="radio" />
        <button>Button</button>
        <input type="radio" />
        <input type="checkbox" />
      </>
    );

    let radios = getAllByRole('radio');
    let button = getByRole('button');

    let revert1 = ariaHideOutside([button, ...radios]);

    expect(() => getAllByRole('checkbox')).toThrow();
    expect(() => getAllByRole('radio')).not.toThrow();
    expect(() => getByRole('button')).not.toThrow();

    let revert2 = ariaHideOutside([button]);

    expect(() => getAllByRole('checkbox')).toThrow();
    expect(() => getAllByRole('radio')).toThrow();
    expect(() => getByRole('button')).not.toThrow();

    revert2();

    expect(() => getAllByRole('checkbox')).toThrow();
    expect(() => getAllByRole('radio')).not.toThrow();
    expect(() => getByRole('button')).not.toThrow();

    revert1();

    expect(() => getAllByRole('checkbox')).not.toThrow();
    expect(() => getAllByRole('radio')).not.toThrow();
    expect(() => getByRole('button')).not.toThrow();
  });

  it('work when called multiple times and restored out of order', function () {
    let {getByRole, getAllByRole} = render(
      <>
        <input type="checkbox" />
        <input type="radio" />
        <button>Button</button>
        <input type="radio" />
        <input type="checkbox" />
      </>
    );

    let radios = getAllByRole('radio');
    let button = getByRole('button');

    let revert1 = ariaHideOutside([button, ...radios]);

    expect(() => getAllByRole('checkbox')).toThrow();
    expect(() => getAllByRole('radio')).not.toThrow();
    expect(() => getByRole('button')).not.toThrow();

    let revert2 = ariaHideOutside([button]);

    expect(() => getAllByRole('checkbox')).toThrow();
    expect(() => getAllByRole('radio')).toThrow();
    expect(() => getByRole('button')).not.toThrow();

    revert1();

    expect(() => getAllByRole('checkbox')).toThrow();
    expect(() => getAllByRole('radio')).toThrow();
    expect(() => getByRole('button')).not.toThrow();

    revert2();

    expect(() => getAllByRole('checkbox')).not.toThrow();
    expect(() => getAllByRole('radio')).not.toThrow();
    expect(() => getByRole('button')).not.toThrow();
  });

  it('should hide everything except the provided element [row]', function () {
    let {getAllByRole, getByTestId} = render(
      <div role="grid">
        <div role="row">
          <div role="gridcell">
            <span data-testid="test-span">
              Cell 1
            </span></div>
        </div>
        <div role="row">
          <div role="gridcell">Cell 2</div>
        </div>
      </div>
    );

    let cells = getAllByRole('gridcell');
    let rows = getAllByRole('row');
    let span = getByTestId('test-span');

    let revert = ariaHideOutside([rows[1]]);

    // Applies aria-hidden to the row and cell despite recursive nature of aria-hidden
    // for https://bugs.webkit.org/show_bug.cgi?id=222623
    expect(rows[0]).toHaveAttribute('aria-hidden', 'true');
    expect(cells[0]).toHaveAttribute('aria-hidden', 'true');
    expect(span).not.toHaveAttribute('aria-hidden');
    expect(rows[1]).not.toHaveAttribute('aria-hidden', 'true');
    expect(cells[1]).not.toHaveAttribute('aria-hidden', 'true');

    revert();

    expect(rows[0]).not.toHaveAttribute('aria-hidden', 'true');
    expect(cells[0]).not.toHaveAttribute('aria-hidden', 'true');
    expect(rows[1]).not.toHaveAttribute('aria-hidden', 'true');
    expect(cells[1]).not.toHaveAttribute('aria-hidden', 'true');
    expect(span).not.toHaveAttribute('aria-hidden');
  });

  it('should unhide after item reorder', async function () {
    function Item(props) {
      return (
        <div role="presentation">
          <div data-testid={props.testid} role="row">
            <div role="gridcell" />
          </div>
        </div>
      );
    }

    function Test() {
      let [count, setCount] = useState(0);
      let items = ['row1', 'row2', 'row3', 'row4', 'row5'];
      if (count === 1) {
        items = ['row2', 'row1', 'row3', 'row4', 'row5'];
      } else if (count === 2) {
        items = ['row2', 'row3', 'row1', 'row4', 'row5'];
      }

      return (
        <>
          <button onClick={() => setCount((old) => old + 1)}>press</button>
          {items.map((item) => <Item testid={item} key={item} />)}
        </>

      );
    }

    let {getByRole, getByTestId} = render(
      <Test />
    );

    let button = getByRole('button');
    let row = getByTestId('row1');
    let revert = ariaHideOutside([button]);

    act(() => button.click());
    await Promise.resolve();
    act(() => button.click());
    await Promise.resolve();
    revert();
    expect(row.parentElement).not.toHaveAttribute('aria-hidden', 'true');
  });

  it('should not hide siblings inside a target shadow root when shadow DOM is disabled', function () {
    let container = document.createElement('div');
    document.body.appendChild(container);
    let {shadowRoot} = createShadowRoot(container);
    let sibling = document.createElement('button');
    let target = document.createElement('button');
    shadowRoot.append(sibling, target);

    let revert = ariaHideOutside([target]);

    expect(sibling).not.toHaveAttribute('aria-hidden');

    revert();
    container.remove();
  });
});

describe('ariaHideOutside with shadow DOM', function () {
  let container;

  beforeAll(() => {
    enableShadowDOM();
  });

  beforeEach(() => {
    container = document.createElement('div');
    document.body.appendChild(container);
    // Earlier tests in this file leave an observer connected to document.body. Calling and reverting
    // a new hide disconnects it and drops its queued records, so it can't hide the container.
    ariaHideOutside([container])();
  });

  afterEach(() => {
    container.remove();
  });

  function addElement(parent, tag = 'button') {
    let element = document.createElement(tag);
    parent.appendChild(element);
    return element;
  }

  it('should hide light DOM and shadow DOM siblings but not the path to the target', function () {
    let lightSibling = addElement(container);
    let {shadowHost, shadowRoot} = createShadowRoot(container);
    let shadowSibling = addElement(shadowRoot);
    let wrapper = addElement(shadowRoot, 'div');
    let target = addElement(wrapper);
    let targetSibling = addElement(wrapper);

    let revert = ariaHideOutside([target]);

    expect(lightSibling).toHaveAttribute('aria-hidden', 'true');
    expect(shadowSibling).toHaveAttribute('aria-hidden', 'true');
    expect(targetSibling).toHaveAttribute('aria-hidden', 'true');
    expect(container).not.toHaveAttribute('aria-hidden');
    expect(shadowHost).not.toHaveAttribute('aria-hidden');
    expect(wrapper).not.toHaveAttribute('aria-hidden');
    expect(target).not.toHaveAttribute('aria-hidden');

    revert();

    expect(lightSibling).not.toHaveAttribute('aria-hidden');
    expect(shadowSibling).not.toHaveAttribute('aria-hidden');
    expect(targetSibling).not.toHaveAttribute('aria-hidden');
  });

  it('should hide siblings at every level when the target is in a nested shadow root', function () {
    let lightSibling = addElement(container);
    let outer = createShadowRoot(container);
    let outerSibling = addElement(outer.shadowRoot);
    let inner = createShadowRoot(outer.shadowRoot);
    let innerSibling = addElement(inner.shadowRoot);
    let target = addElement(inner.shadowRoot);

    let revert = ariaHideOutside([target]);

    expect(lightSibling).toHaveAttribute('aria-hidden', 'true');
    expect(outerSibling).toHaveAttribute('aria-hidden', 'true');
    expect(innerSibling).toHaveAttribute('aria-hidden', 'true');
    expect(outer.shadowHost).not.toHaveAttribute('aria-hidden');
    expect(inner.shadowHost).not.toHaveAttribute('aria-hidden');
    expect(target).not.toHaveAttribute('aria-hidden');

    revert();

    expect(lightSibling).not.toHaveAttribute('aria-hidden');
    expect(outerSibling).not.toHaveAttribute('aria-hidden');
    expect(innerSibling).not.toHaveAttribute('aria-hidden');
  });

  it('should hide content added to shadow roots after the call unless it is inside the target', async function () {
    let outer = createShadowRoot(container);
    let inner = createShadowRoot(outer.shadowRoot);
    let hiddenContainer = addElement(inner.shadowRoot, 'div');
    let wrapper = addElement(inner.shadowRoot, 'div');
    let target = addElement(wrapper);

    let revert = ariaHideOutside([target]);

    let directAdd = addElement(inner.shadowRoot);
    let addedToWrapper = addElement(wrapper);
    let addedToOuter = addElement(outer.shadowRoot);
    let addedToLight = addElement(container);
    let addedToTarget = addElement(target);
    let addedToHidden = addElement(hiddenContainer);

    await waitFor(() => expect(addedToLight).toHaveAttribute('aria-hidden', 'true'));
    expect(directAdd).toHaveAttribute('aria-hidden', 'true');
    expect(addedToWrapper).toHaveAttribute('aria-hidden', 'true');
    expect(addedToOuter).toHaveAttribute('aria-hidden', 'true');
    expect(addedToTarget).not.toHaveAttribute('aria-hidden');
    expect(addedToHidden).not.toHaveAttribute('aria-hidden');

    revert();
  });

  it('should keep live announcer and top layer elements in shadow roots visible', async function () {
    let {shadowRoot} = createShadowRoot(container);
    let target = addElement(shadowRoot);
    let existingAnnouncer = addElement(shadowRoot, 'div');
    existingAnnouncer.dataset.liveAnnouncer = 'true';

    let revert = ariaHideOutside([target]);

    let addedAnnouncer = addElement(shadowRoot, 'div');
    addedAnnouncer.dataset.liveAnnouncer = 'true';
    let addedTopLayer = addElement(shadowRoot, 'div');
    addedTopLayer.dataset.reactAriaTopLayer = 'true';
    let sentinel = addElement(shadowRoot);

    await waitFor(() => expect(sentinel).toHaveAttribute('aria-hidden', 'true'));
    expect(existingAnnouncer).not.toHaveAttribute('aria-hidden');
    expect(addedAnnouncer).not.toHaveAttribute('aria-hidden');
    expect(addedTopLayer).not.toHaveAttribute('aria-hidden');

    revert();
  });

  it('should keep targets in different shadow roots and a light DOM target visible', async function () {
    let a = createShadowRoot(container);
    let b = createShadowRoot(container);
    let lightTarget = addElement(container);
    let lightSibling = addElement(container);
    let targetA = addElement(a.shadowRoot);
    let siblingA = addElement(a.shadowRoot);
    let targetB = addElement(b.shadowRoot);
    let siblingB = addElement(b.shadowRoot);

    let revert = ariaHideOutside([targetA, targetB, lightTarget]);

    expect(lightSibling).toHaveAttribute('aria-hidden', 'true');
    expect(siblingA).toHaveAttribute('aria-hidden', 'true');
    expect(siblingB).toHaveAttribute('aria-hidden', 'true');
    expect(a.shadowHost).not.toHaveAttribute('aria-hidden');
    expect(b.shadowHost).not.toHaveAttribute('aria-hidden');
    expect(targetA).not.toHaveAttribute('aria-hidden');
    expect(targetB).not.toHaveAttribute('aria-hidden');
    expect(lightTarget).not.toHaveAttribute('aria-hidden');

    let addedA = addElement(a.shadowRoot);
    let addedB = addElement(b.shadowRoot);
    await waitFor(() => expect(addedB).toHaveAttribute('aria-hidden', 'true'));
    expect(addedA).toHaveAttribute('aria-hidden', 'true');

    revert();
  });

  it('should restore every attribute and disconnect every observer on revert', async function () {
    let {shadowRoot} = createShadowRoot(container);
    let target = addElement(shadowRoot);
    let sameRootTarget = addElement(shadowRoot);
    let sibling = addElement(shadowRoot);
    let preHidden = addElement(shadowRoot);
    preHidden.setAttribute('aria-hidden', 'true');
    let lightSibling = addElement(container);

    let revert = ariaHideOutside([target, sameRootTarget]);

    expect(sibling).toHaveAttribute('aria-hidden', 'true');
    expect(lightSibling).toHaveAttribute('aria-hidden', 'true');

    revert();

    expect(sibling).not.toHaveAttribute('aria-hidden');
    expect(lightSibling).not.toHaveAttribute('aria-hidden');
    expect(preHidden).toHaveAttribute('aria-hidden', 'true');

    let lateShadow = addElement(shadowRoot);
    await Promise.resolve(); // Wait for mutation observer tick
    expect(lateShadow).not.toHaveAttribute('aria-hidden');
  });

  it('should hide a shadow host added later, and its shadow content inherits', async function () {
    let {shadowRoot} = createShadowRoot(container);
    let target = addElement(shadowRoot);

    let revert = ariaHideOutside([target]);

    let newHost = addElement(shadowRoot, 'div');
    let newContent = addElement(newHost.attachShadow({mode: 'open'}));

    await waitFor(() => expect(newHost).toHaveAttribute('aria-hidden', 'true'));
    expect(newContent).not.toHaveAttribute('aria-hidden');

    revert();
  });

  it('should keep the shadow content of a target that is itself a shadow host visible', function () {
    let targetHost = addElement(container, 'div');
    let targetShadow = targetHost.attachShadow({mode: 'open'});
    let inside = addElement(targetShadow);
    let sibling = addElement(container);

    let revert = ariaHideOutside([targetHost]);

    expect(sibling).toHaveAttribute('aria-hidden', 'true');
    expect(targetHost).not.toHaveAttribute('aria-hidden');
    expect(inside).not.toHaveAttribute('aria-hidden');

    revert();
  });

  it('should hide siblings inside a closed shadow root', function () {
    let host = addElement(container, 'div');
    let closedRoot = host.attachShadow({mode: 'closed'});
    let sibling = addElement(closedRoot);
    let target = addElement(closedRoot);

    let revert = ariaHideOutside([target]);

    expect(sibling).toHaveAttribute('aria-hidden', 'true');
    expect(host).not.toHaveAttribute('aria-hidden');
    expect(target).not.toHaveAttribute('aria-hidden');

    revert();

    expect(sibling).not.toHaveAttribute('aria-hidden');
  });

  it('should not throw on revert when a shadow host was removed while active', function () {
    let {shadowHost, shadowRoot} = createShadowRoot(container);
    let target = addElement(shadowRoot);
    let lightSibling = addElement(container);

    let revert = ariaHideOutside([target]);
    shadowHost.remove();

    expect(() => revert()).not.toThrow();
    expect(lightSibling).not.toHaveAttribute('aria-hidden');
  });

  it('should only observe the shadow roots of the innermost call while it is active', async function () {
    let outer = createShadowRoot(container);
    let outerTarget = addElement(outer.shadowRoot);
    let inner = createShadowRoot(container);
    let innerTarget = addElement(inner.shadowRoot);

    let outerRevert = ariaHideOutside([outerTarget]);
    let innerRevert = ariaHideOutside([innerTarget]);

    let whileInner = addElement(outer.shadowRoot);
    let innerAdded = addElement(inner.shadowRoot);
    await waitFor(() => expect(innerAdded).toHaveAttribute('aria-hidden', 'true'));
    expect(whileInner).not.toHaveAttribute('aria-hidden');

    innerRevert();

    let afterInner = addElement(outer.shadowRoot);
    await waitFor(() => expect(afterInner).toHaveAttribute('aria-hidden', 'true'));

    outerRevert();
    expect(afterInner).not.toHaveAttribute('aria-hidden');
    expect(innerAdded).not.toHaveAttribute('aria-hidden');
  });

  it('should restore everything when nested calls are reverted out of order', function () {
    let outer = createShadowRoot(container);
    let outerSibling = addElement(outer.shadowRoot);
    let outerTarget = addElement(outer.shadowRoot);
    let inner = createShadowRoot(container);
    let innerSibling = addElement(inner.shadowRoot);
    let innerTarget = addElement(inner.shadowRoot);

    let outerRevert = ariaHideOutside([outerTarget]);
    let innerRevert = ariaHideOutside([innerTarget]);

    outerRevert();

    expect(outerSibling).not.toHaveAttribute('aria-hidden');
    expect(innerSibling).toHaveAttribute('aria-hidden', 'true');
    expect(outer.shadowHost).toHaveAttribute('aria-hidden', 'true');

    innerRevert();

    expect(innerSibling).not.toHaveAttribute('aria-hidden');
    expect(outer.shadowHost).not.toHaveAttribute('aria-hidden');
  });

  it('should keep an element added later to a shadow root visible when keepVisible is called', async function () {
    let {shadowRoot} = createShadowRoot(container);
    let target = addElement(shadowRoot);

    let revert = ariaHideOutside([target]);

    let kept = addElement(shadowRoot);
    let releaseKeep = keepVisible(kept);
    let sentinel = addElement(shadowRoot);

    await waitFor(() => expect(sentinel).toHaveAttribute('aria-hidden', 'true'));
    expect(kept).not.toHaveAttribute('aria-hidden');

    releaseKeep();
    revert();
  });

  it('should not hide anything outside of root, including shadow roots whose host is outside of root', async function () {
    let rootElement = addElement(container, 'div');
    let inside = createShadowRoot(rootElement);
    let insideTarget = addElement(inside.shadowRoot);
    let insideSibling = addElement(inside.shadowRoot);
    let outside = createShadowRoot(container);
    let outsideTarget = addElement(outside.shadowRoot);
    let outsideSibling = addElement(outside.shadowRoot);
    let lightSibling = addElement(container);

    let revert = ariaHideOutside([insideTarget], {root: rootElement});

    let lateOutside = addElement(outside.shadowRoot);
    let lateInside = addElement(inside.shadowRoot);
    await waitFor(() => expect(lateInside).toHaveAttribute('aria-hidden', 'true'));
    expect(insideSibling).toHaveAttribute('aria-hidden', 'true');
    expect(outsideSibling).not.toHaveAttribute('aria-hidden');
    expect(outsideTarget).not.toHaveAttribute('aria-hidden');
    expect(lateOutside).not.toHaveAttribute('aria-hidden');
    expect(lightSibling).not.toHaveAttribute('aria-hidden');
    expect(outside.shadowHost).not.toHaveAttribute('aria-hidden');

    revert();
  });

  it('should keep light DOM content slotted into a target visible, including content added later', async function () {
    let {shadowHost, shadowRoot} = createShadowRoot(container);
    let wrapper = addElement(shadowRoot, 'div');
    let target = addElement(wrapper, 'div');
    addElement(target, 'slot');
    let outsideSlot = addElement(wrapper, 'slot');
    outsideSlot.name = 'outside';
    let slotted = addElement(shadowHost, 'p');
    let unassigned = addElement(shadowHost, 'p');
    unassigned.slot = 'other';
    let outsideSlotted = addElement(shadowHost, 'p');
    outsideSlotted.slot = 'outside';

    let revert = ariaHideOutside([target]);

    expect(slotted).not.toHaveAttribute('aria-hidden');
    expect(unassigned).toHaveAttribute('aria-hidden', 'true');
    expect(outsideSlotted).toHaveAttribute('aria-hidden', 'true');
    expect(shadowHost).not.toHaveAttribute('aria-hidden');
    expect(target).not.toHaveAttribute('aria-hidden');

    let lateSlotted = addElement(shadowHost, 'p');
    let insideSlotted = addElement(slotted, 'span');
    let sentinel = addElement(container);
    await waitFor(() => expect(sentinel).toHaveAttribute('aria-hidden', 'true'));
    expect(lateSlotted).not.toHaveAttribute('aria-hidden');
    expect(insideSlotted).not.toHaveAttribute('aria-hidden');

    revert();

    for (let element of [slotted, unassigned, outsideSlotted, lateSlotted, insideSlotted, sentinel, shadowHost, wrapper, target]) {
      expect(element).not.toHaveAttribute('aria-hidden');
    }
  });
});

/*
 * Copyright 2020 Adobe. All rights reserved.
 * This file is licensed to you under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License. You may obtain a copy
 * of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software distributed under
 * the License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR REPRESENTATIONS
 * OF ANY KIND, either express or implied. See the License for the specific language
 * governing permissions and limitations under the License.
 */

import {act, createShadowRoot, render, waitFor} from '@react-spectrum/test-utils-internal';
import {ariaHideOutside} from '../src';
import {enableShadowDOM} from '@react-stately/flags';
import React, {useRef, useState} from 'react';

describe('ariaHideOutside', function () {
  it('should hide everything except the provided element [button]', function () {
    let {getByRole, getAllByRole} = render(
      <>
        <input type="checkbox" />
        <button>Button</button>
        <input type="checkbox" />
      </>
    );

    let checkboxes = getAllByRole('checkbox');
    let button = getByRole('button');

    let revert = ariaHideOutside([button]);

    expect(checkboxes[0]).toHaveAttribute('aria-hidden', 'true');
    expect(checkboxes[1]).toHaveAttribute('aria-hidden', 'true');
    expect(button).not.toHaveAttribute('aria-hidden');

    expect(() => getAllByRole('checkbox')).toThrow();
    expect(() => getByRole('button')).not.toThrow();

    revert();

    expect(checkboxes[0]).not.toHaveAttribute('aria-hidden');
    expect(checkboxes[1]).not.toHaveAttribute('aria-hidden');
    expect(button).not.toHaveAttribute('aria-hidden');

    expect(() => getAllByRole('checkbox')).not.toThrow();
    expect(() => getByRole('button')).not.toThrow();
  });

  it('should hide everything except multiple elements', function () {
    let {getByRole, getAllByRole, queryByRole, queryAllByRole} = render(
      <>
        <input type="checkbox" />
        <button>Button</button>
        <input type="checkbox" />
      </>
    );

    let checkboxes = getAllByRole('checkbox');
    let button = getByRole('button');

    let revert = ariaHideOutside(checkboxes);

    expect(checkboxes[0]).not.toHaveAttribute('aria-hidden', 'true');
    expect(checkboxes[1]).not.toHaveAttribute('aria-hidden', 'true');
    expect(button).toHaveAttribute('aria-hidden');

    expect(queryAllByRole('checkbox')).not.toBeNull();
    expect(queryByRole('button')).toBeNull();

    revert();

    expect(checkboxes[0]).not.toHaveAttribute('aria-hidden');
    expect(checkboxes[1]).not.toHaveAttribute('aria-hidden');
    expect(button).not.toHaveAttribute('aria-hidden');

    expect(() => getAllByRole('checkbox')).not.toThrow();
    expect(() => getByRole('button')).not.toThrow();
  });

  it('should not traverse into an already hidden container', function () {
    let {getByRole, getAllByRole} = render(
      <>
        <div>
          <input type="checkbox" />
        </div>
        <button>Button</button>
        <input type="checkbox" />
      </>
    );

    let checkboxes = getAllByRole('checkbox');
    let button = getByRole('button');

    let revert = ariaHideOutside([button]);

    expect(checkboxes[0].parentElement).toHaveAttribute('aria-hidden', 'true');
    expect(checkboxes[1]).toHaveAttribute('aria-hidden', 'true');
    expect(button).not.toHaveAttribute('aria-hidden');

    expect(() => getAllByRole('checkbox')).toThrow();
    expect(() => getByRole('button')).not.toThrow();

    revert();

    expect(checkboxes[0].parentElement).not.toHaveAttribute('aria-hidden');
    expect(checkboxes[1]).not.toHaveAttribute('aria-hidden');
    expect(button).not.toHaveAttribute('aria-hidden');

    expect(() => getAllByRole('checkbox')).not.toThrow();
    expect(() => getByRole('button')).not.toThrow();
  });

  it('should not overwrite an existing aria-hidden prop', function () {
    let {getByRole, getAllByRole} = render(
      <>
        <input type="checkbox" aria-hidden="true" />
        <button>Button</button>
        <input type="checkbox" />
      </>
    );

    let checkboxes = getAllByRole('checkbox');
    let button = getByRole('button');

    let revert = ariaHideOutside([button]);

    expect(checkboxes).toHaveLength(1);
    expect(checkboxes[0]).toHaveAttribute('aria-hidden', 'true');
    expect(button).not.toHaveAttribute('aria-hidden');

    expect(() => getAllByRole('checkbox')).toThrow();
    expect(() => getByRole('button')).not.toThrow();

    revert();

    checkboxes = getAllByRole('checkbox');
    expect(checkboxes).toHaveLength(1);
    expect(checkboxes[0]).not.toHaveAttribute('aria-hidden');
    expect(button).not.toHaveAttribute('aria-hidden');

    expect(() => getAllByRole('checkbox')).not.toThrow();
    expect(() => getByRole('button')).not.toThrow();
  });

  it('should handle when a new element is added outside while active', async function () {
    let Test = props => (
      <>
        {props.show && <input type="checkbox" />}
        <button>Button</button>
        {props.show && <input type="checkbox" />}
      </>
    );

    let {getByRole, getAllByRole, rerender} = render(<Test />);

    let button = getByRole('button');
    expect(() => getAllByRole('checkbox')).toThrow();

    let revert = ariaHideOutside([button]);

    rerender(<Test show />);

    // MutationObserver is async
    await waitFor(() => expect(() => getAllByRole('checkbox')).toThrow());
    expect(() => getByRole('button')).not.toThrow();

    revert();

    expect(getAllByRole('checkbox')).toHaveLength(2);
  });

  it('should handle when a new element is added to an already hidden container', async function () {
    let Test = props => (
      <>
        <div data-testid="test">
          {props.show && <input type="checkbox" />}
        </div>
        <button>Button</button>
        {props.show && <input type="checkbox" />}
      </>
    );

    let {getByRole, getAllByRole, getByTestId, rerender} = render(<Test />);

    let button = getByRole('button');
    let test = getByTestId('test');
    expect(() => getAllByRole('checkbox')).toThrow();

    let revert = ariaHideOutside([button]);

    expect(test).toHaveAttribute('aria-hidden');

    rerender(<Test show />);

    // MutationObserver is async
    await waitFor(() => expect(() => getAllByRole('checkbox')).toThrow());
    expect(() => getByRole('button')).not.toThrow();

    let checkboxes = getAllByRole('checkbox', {hidden: true});
    expect(test).toHaveAttribute('aria-hidden');
    expect(checkboxes[0]).not.toHaveAttribute('aria-hidden');
    expect(checkboxes[1]).toHaveAttribute('aria-hidden', 'true');

    revert();

    expect(getAllByRole('checkbox')).toHaveLength(2);
  });

  it('should handle when a new element is added along with a top layer element', async function () {
    let Test = props => (
      <>
        <button>Button</button>
        {props.show && <div>
          <div role="alert" data-react-aria-top-layer="true">Top layer</div>
          <input type="checkbox" />
        </div>}
      </>
    );

    let {getByRole, queryByRole, getAllByRole, rerender} = render(<Test />);

    let button = getByRole('button');
    expect(queryByRole('checkbox')).toBeNull();

    let revert = ariaHideOutside([button]);

    rerender(<Test show />);

    // MutationObserver is async
    await waitFor(() => queryByRole('checkbox') == null);
    expect(queryByRole('button')).not.toBeNull();
    expect(getByRole('alert')).toHaveTextContent('Top layer');

    revert();

    expect(getAllByRole('checkbox')).toHaveLength(1);
  });

  it('should handle when a new element is added inside a target element', async function () {
    let Test = props => (
      <>
        <input type="checkbox" />
        <div data-testid="test">
          <button>Button</button>
          {props.show && <input type="radio" />}
        </div>
        <input type="checkbox" />
      </>
    );

    let {queryByRole, getByRole, getAllByRole, getByTestId, rerender} = render(<Test />);

    let test = getByTestId('test');
    let revert = ariaHideOutside([test]);

    expect(() => getAllByRole('checkbox')).toThrow();
    expect(queryByRole('radio')).toBeNull();
    expect(queryByRole('button')).not.toBeNull();
    expect(() => getByTestId('test')).not.toThrow();

    rerender(<Test show />);

    // Wait for mutation observer tick
    await Promise.resolve();
    expect(() => getAllByRole('checkbox')).toThrow();
    expect(() => getByRole('radio')).not.toThrow();
    expect(() => getByRole('button')).not.toThrow();
    expect(() => getByTestId('test')).not.toThrow();

    revert();

    expect(() => getAllByRole('checkbox')).not.toThrow();
    expect(() => getByRole('radio')).not.toThrow();
    expect(() => getByRole('button')).not.toThrow();
    expect(() => getByTestId('test')).not.toThrow();
  });

  it('should handle when a new element is added and then reparented', async function () {

    let Test = () => {
      const ref = useRef(null);
      const mutate = () => {
        let parent = document.createElement('ul');
        let child = document.createElement('li');
        ref.current.append(parent);
        parent.appendChild(child);
        parent.remove(); // this results in a mutation record for a disconnected ul with a connected li (through the new ul parent) in `addedNodes`
        let newParent = document.createElement('ul');
        newParent.appendChild(child);
        ref.current.append(newParent);
      };

      return (
        <>
          <div data-testid="test" ref={ref}>
            <button onClick={mutate}>Mutate</button>
          </div>
        </>
      );
    };

    let {queryByRole, getAllByRole, getByTestId} = render(<Test />);

    ariaHideOutside([getByTestId('test')]);

    queryByRole('button').click();
    await Promise.resolve(); // Wait for mutation observer tick

    expect(getAllByRole('listitem')).toHaveLength(1);
  });

  it('should handle when a new element is added and then reparented to a hidden container', async function () {

    let Test = () => {
      const ref = useRef(null);
      const mutate = () => {
        let parent = document.createElement('ul');
        let child = document.createElement('li');
        ref.current.append(parent);
        parent.appendChild(child);
        parent.remove(); // this results in a mutation record for a disconnected ul with a connected li (through the new ul parent) in `addedNodes`
        let newParent = document.createElement('ul');
        newParent.appendChild(child);
        ref.current.append(newParent);
      };

      return (
        <>
          <div data-testid="test">
            <button onClick={mutate}>Mutate</button>
          </div>
          <div data-testid="sibling" ref={ref} />
        </>
      );
    };

    let {queryByRole, queryAllByRole, getByTestId} = render(<Test />);

    ariaHideOutside([getByTestId('test')]);

    queryByRole('button').click();
    await Promise.resolve(); // Wait for mutation observer tick

    expect(queryAllByRole('listitem')).toHaveLength(0);
  });


  it('work when called multiple times', function () {
    let {getByRole, getAllByRole} = render(
      <>
        <input type="checkbox" />
        <input type="radio" />
        <button>Button</button>
        <input type="radio" />
        <input type="checkbox" />
      </>
    );

    let radios = getAllByRole('radio');
    let button = getByRole('button');

    let revert1 = ariaHideOutside([button, ...radios]);

    expect(() => getAllByRole('checkbox')).toThrow();
    expect(() => getAllByRole('radio')).not.toThrow();
    expect(() => getByRole('button')).not.toThrow();

    let revert2 = ariaHideOutside([button]);

    expect(() => getAllByRole('checkbox')).toThrow();
    expect(() => getAllByRole('radio')).toThrow();
    expect(() => getByRole('button')).not.toThrow();

    revert2();

    expect(() => getAllByRole('checkbox')).toThrow();
    expect(() => getAllByRole('radio')).not.toThrow();
    expect(() => getByRole('button')).not.toThrow();

    revert1();

    expect(() => getAllByRole('checkbox')).not.toThrow();
    expect(() => getAllByRole('radio')).not.toThrow();
    expect(() => getByRole('button')).not.toThrow();
  });

  it('work when called multiple times and restored out of order', function () {
    let {getByRole, getAllByRole} = render(
      <>
        <input type="checkbox" />
        <input type="radio" />
        <button>Button</button>
        <input type="radio" />
        <input type="checkbox" />
      </>
    );

    let radios = getAllByRole('radio');
    let button = getByRole('button');

    let revert1 = ariaHideOutside([button, ...radios]);

    expect(() => getAllByRole('checkbox')).toThrow();
    expect(() => getAllByRole('radio')).not.toThrow();
    expect(() => getByRole('button')).not.toThrow();

    let revert2 = ariaHideOutside([button]);

    expect(() => getAllByRole('checkbox')).toThrow();
    expect(() => getAllByRole('radio')).toThrow();
    expect(() => getByRole('button')).not.toThrow();

    revert1();

    expect(() => getAllByRole('checkbox')).toThrow();
    expect(() => getAllByRole('radio')).toThrow();
    expect(() => getByRole('button')).not.toThrow();

    revert2();

    expect(() => getAllByRole('checkbox')).not.toThrow();
    expect(() => getAllByRole('radio')).not.toThrow();
    expect(() => getByRole('button')).not.toThrow();
  });

  it('should hide everything except the provided element [row]', function () {
    let {getAllByRole, getByTestId} = render(
      <div role="grid">
        <div role="row">
          <div role="gridcell">
            <span data-testid="test-span">
              Cell 1
            </span></div>
        </div>
        <div role="row">
          <div role="gridcell">Cell 2</div>
        </div>
      </div>
    );

    let cells = getAllByRole('gridcell');
    let rows = getAllByRole('row');
    let span = getByTestId('test-span');

    let revert = ariaHideOutside([rows[1]]);

    // Applies aria-hidden to the row and cell despite recursive nature of aria-hidden
    // for https://bugs.webkit.org/show_bug.cgi?id=222623
    expect(rows[0]).toHaveAttribute('aria-hidden', 'true');
    expect(cells[0]).toHaveAttribute('aria-hidden', 'true');
    expect(span).not.toHaveAttribute('aria-hidden');
    expect(rows[1]).not.toHaveAttribute('aria-hidden', 'true');
    expect(cells[1]).not.toHaveAttribute('aria-hidden', 'true');

    revert();

    expect(rows[0]).not.toHaveAttribute('aria-hidden', 'true');
    expect(cells[0]).not.toHaveAttribute('aria-hidden', 'true');
    expect(rows[1]).not.toHaveAttribute('aria-hidden', 'true');
    expect(cells[1]).not.toHaveAttribute('aria-hidden', 'true');
    expect(span).not.toHaveAttribute('aria-hidden');
  });

  it('should unhide after item reorder', async function () {
    function Item(props) {
      return (
        <div role="presentation">
          <div data-testid={props.testid} role="row">
            <div role="gridcell" />
          </div>
        </div>
      );
    }

    function Test() {
      let [count, setCount] = useState(0);
      let items = ['row1', 'row2', 'row3', 'row4', 'row5'];
      if (count === 1) {
        items = ['row2', 'row1', 'row3', 'row4', 'row5'];
      } else if (count === 2) {
        items = ['row2', 'row3', 'row1', 'row4', 'row5'];
      }

      return (
        <>
          <button onClick={() => setCount((old) => old + 1)}>press</button>
          {items.map((item) => <Item testid={item} key={item} />)}
        </>

      );
    }

    let {getByRole, getByTestId} = render(
      <Test />
    );

    let button = getByRole('button');
    let row = getByTestId('row1');
    let revert = ariaHideOutside([button]);

    act(() => button.click());
    await Promise.resolve();
    act(() => button.click());
    await Promise.resolve();
    revert();
    expect(row.parentElement).not.toHaveAttribute('aria-hidden', 'true');
  });
});

// The shadow DOM flag cannot be turned off, so these tests must stay after the flag-off tests above.
describe('ariaHideOutside with shadow DOM', function () {
  beforeAll(() => {
    enableShadowDOM();
  });

  afterEach(() => {
    document.body.innerHTML = '';
  });

  // Creates an open shadow root containing a wrapper, which holds a host with its own open shadow root.
  function createNestedShadowRoots() {
    let {shadowRoot: outerRoot} = createShadowRoot();
    let wrapper = document.createElement('div');
    outerRoot.append(wrapper);
    let innerHost = document.createElement('div');
    wrapper.append(innerHost);
    let innerRoot = innerHost.attachShadow({mode: 'open'});
    return {outerRoot, wrapper, innerHost, innerRoot};
  }

  it('hides siblings of a target inside a shadow root', function () {
    let outside = document.createElement('button');
    document.body.append(outside);
    let {shadowHost, shadowRoot} = createShadowRoot();
    let sibling = document.createElement('button');
    let target = document.createElement('button');
    shadowRoot.append(sibling, target);

    let revert = ariaHideOutside([target]);

    expect(sibling).toHaveAttribute('aria-hidden', 'true');
    expect(target).not.toHaveAttribute('aria-hidden');
    expect(shadowHost).not.toHaveAttribute('aria-hidden');
    expect(outside).toHaveAttribute('aria-hidden', 'true');

    revert();

    expect(sibling).not.toHaveAttribute('aria-hidden');
    expect(outside).not.toHaveAttribute('aria-hidden');
  });

  it('hides siblings at every shadow level above a nested target', function () {
    let outside = document.createElement('button');
    document.body.append(outside);
    let {outerRoot, wrapper, innerHost, innerRoot} = createNestedShadowRoots();
    let outerSibling = document.createElement('button');
    outerRoot.prepend(outerSibling);
    let innerSibling = document.createElement('button');
    let target = document.createElement('button');
    innerRoot.append(innerSibling, target);

    let revert = ariaHideOutside([target]);

    expect(innerSibling).toHaveAttribute('aria-hidden', 'true');
    expect(outerSibling).toHaveAttribute('aria-hidden', 'true');
    expect(outside).toHaveAttribute('aria-hidden', 'true');
    expect(wrapper).not.toHaveAttribute('aria-hidden');
    expect(innerHost).not.toHaveAttribute('aria-hidden');
    expect(target).not.toHaveAttribute('aria-hidden');

    revert();

    expect(innerSibling).not.toHaveAttribute('aria-hidden');
    expect(outerSibling).not.toHaveAttribute('aria-hidden');
  });

  it('hides shadow hosts without a target as a whole, without marking their shadow content', function () {
    let {shadowHost: otherHost, shadowRoot: otherRoot} = createShadowRoot();
    let otherButton = document.createElement('button');
    otherRoot.append(otherButton);
    let {shadowRoot} = createShadowRoot();
    let target = document.createElement('button');
    let nestedHost = document.createElement('div');
    let nestedButton = document.createElement('button');
    shadowRoot.append(target, nestedHost);
    nestedHost.attachShadow({mode: 'open'}).append(nestedButton);
    let button = document.createElement('button');
    document.body.append(button);

    let revert = ariaHideOutside([target]);

    expect(otherHost).toHaveAttribute('aria-hidden', 'true');
    expect(otherButton).not.toHaveAttribute('aria-hidden');
    expect(nestedHost).toHaveAttribute('aria-hidden', 'true');
    expect(nestedButton).not.toHaveAttribute('aria-hidden');
    expect(target).not.toHaveAttribute('aria-hidden');

    revert();

    expect(otherHost).not.toHaveAttribute('aria-hidden');
    expect(nestedHost).not.toHaveAttribute('aria-hidden');
  });

  it('hides content added to a target shadow root but keeps live announcers and top layer elements visible', async function () {
    let {shadowRoot} = createShadowRoot();
    let existingAnnouncer = document.createElement('div');
    existingAnnouncer.dataset.liveAnnouncer = 'true';
    let target = document.createElement('div');
    shadowRoot.append(existingAnnouncer, target);

    let revert = ariaHideOutside([target]);

    let added = document.createElement('button');
    let addedAnnouncer = document.createElement('div');
    addedAnnouncer.dataset.liveAnnouncer = 'true';
    let addedTopLayer = document.createElement('div');
    addedTopLayer.dataset.reactAriaTopLayer = 'true';
    let insideTarget = document.createElement('button');
    shadowRoot.append(added, addedAnnouncer, addedTopLayer);
    target.append(insideTarget);

    // MutationObserver is async
    await waitFor(() => expect(added).toHaveAttribute('aria-hidden', 'true'));
    expect(existingAnnouncer).not.toHaveAttribute('aria-hidden');
    expect(addedAnnouncer).not.toHaveAttribute('aria-hidden');
    expect(addedTopLayer).not.toHaveAttribute('aria-hidden');
    expect(insideTarget).not.toHaveAttribute('aria-hidden');

    revert();
  });

  it('hides content added to shadow roots that enclose a target', async function () {
    let {outerRoot, innerRoot} = createNestedShadowRoots();
    let target = document.createElement('button');
    innerRoot.append(target);

    let revert = ariaHideOutside([target]);

    let outerAdded = document.createElement('button');
    outerRoot.append(outerAdded);
    // MutationObserver is async
    await waitFor(() => expect(outerAdded).toHaveAttribute('aria-hidden', 'true'));

    revert();
  });

  it('keeps targets in different shadow roots visible and hides their siblings', async function () {
    let outside = document.createElement('button');
    document.body.append(outside);
    let first = createShadowRoot();
    let second = createShadowRoot();
    let firstTarget = document.createElement('input');
    let firstSibling = document.createElement('button');
    first.shadowRoot.append(firstSibling, firstTarget);
    let popover = document.createElement('div');
    let secondSibling = document.createElement('button');
    second.shadowRoot.append(secondSibling, popover);

    let revert = ariaHideOutside([firstTarget, popover]);

    expect(firstTarget).not.toHaveAttribute('aria-hidden');
    expect(popover).not.toHaveAttribute('aria-hidden');
    expect(first.shadowHost).not.toHaveAttribute('aria-hidden');
    expect(second.shadowHost).not.toHaveAttribute('aria-hidden');
    expect(firstSibling).toHaveAttribute('aria-hidden', 'true');
    expect(secondSibling).toHaveAttribute('aria-hidden', 'true');
    expect(outside).toHaveAttribute('aria-hidden', 'true');

    let addedFirst = document.createElement('button');
    let addedSecond = document.createElement('button');
    first.shadowRoot.append(addedFirst);
    second.shadowRoot.append(addedSecond);
    // MutationObserver is async
    await waitFor(() => {
      expect(addedFirst).toHaveAttribute('aria-hidden', 'true');
      expect(addedSecond).toHaveAttribute('aria-hidden', 'true');
    });

    revert();
  });

  it('observes a shadow root once when it holds two targets', function () {
    let {shadowRoot} = createShadowRoot();
    let first = document.createElement('button');
    let second = document.createElement('button');
    shadowRoot.append(first, second);
    let observeSpy = jest.spyOn(MutationObserver.prototype, 'observe');

    let revert = ariaHideOutside([first, second]);

    let shadowRootObserves = observeSpy.mock.calls.filter(([node]) => node === shadowRoot);
    observeSpy.mockRestore();
    expect(shadowRootObserves).toHaveLength(1);

    revert();
  });

  it('restores shadow content and stops observing shadow roots when reverted', async function () {
    let {outerRoot, innerRoot} = createNestedShadowRoots();
    let outerSibling = document.createElement('button');
    outerRoot.prepend(outerSibling);
    let innerSibling = document.createElement('button');
    let target = document.createElement('button');
    innerRoot.append(innerSibling, target);

    let revert = ariaHideOutside([target]);
    revert();

    expect(innerSibling).not.toHaveAttribute('aria-hidden');
    expect(outerSibling).not.toHaveAttribute('aria-hidden');

    let addedInner = document.createElement('button');
    let addedOuter = document.createElement('button');
    innerRoot.append(addedInner);
    outerRoot.append(addedOuter);
    await Promise.resolve();
    expect(addedInner).not.toHaveAttribute('aria-hidden');
    expect(addedOuter).not.toHaveAttribute('aria-hidden');
  });

  it('re-observes the first call shadow roots when a nested call is reverted', async function () {
    let {shadowRoot} = createShadowRoot();
    let target = document.createElement('button');
    shadowRoot.append(target);
    let outside = document.createElement('button');
    document.body.append(outside);

    let revert1 = ariaHideOutside([target]);
    let revert2 = ariaHideOutside([outside]);

    let whileNested = document.createElement('button');
    shadowRoot.append(whileNested);
    await Promise.resolve();
    expect(whileNested).not.toHaveAttribute('aria-hidden');

    revert2();

    let afterNested = document.createElement('button');
    shadowRoot.append(afterNested);
    // MutationObserver is async
    await waitFor(() => expect(afterNested).toHaveAttribute('aria-hidden', 'true'));

    revert1();
  });

  it('keeps a shadow element hidden until every call that hid it has reverted', function () {
    let {shadowRoot} = createShadowRoot();
    let sibling = document.createElement('button');
    let target = document.createElement('button');
    shadowRoot.append(sibling, target);

    let revert1 = ariaHideOutside([target]);
    let revert2 = ariaHideOutside([target]);
    expect(sibling).toHaveAttribute('aria-hidden', 'true');

    revert1();
    expect(sibling).toHaveAttribute('aria-hidden', 'true');

    revert2();
    expect(sibling).not.toHaveAttribute('aria-hidden');
  });

  it('does not unhide shadow elements that were already aria-hidden before the call', function () {
    let {shadowRoot} = createShadowRoot();
    let alreadyHidden = document.createElement('button');
    alreadyHidden.setAttribute('aria-hidden', 'true');
    let target = document.createElement('button');
    shadowRoot.append(alreadyHidden, target);

    let revert = ariaHideOutside([target]);
    expect(alreadyHidden).toHaveAttribute('aria-hidden', 'true');

    revert();
    expect(alreadyHidden).toHaveAttribute('aria-hidden', 'true');
  });

  it('keeps a light DOM target slotted into a shadow root visible', function () {
    let outside = document.createElement('button');
    document.body.append(outside);
    let host = document.createElement('div');
    document.body.append(host);
    let target = document.createElement('button');
    host.append(target);
    let shadowRoot = host.attachShadow({mode: 'open'});
    let wrapper = document.createElement('div');
    let slot = document.createElement('slot');
    wrapper.append(slot);
    let sibling = document.createElement('button');
    shadowRoot.append(wrapper, sibling);

    let revert = ariaHideOutside([target]);

    expect(host).not.toHaveAttribute('aria-hidden');
    expect(wrapper).not.toHaveAttribute('aria-hidden');
    expect(slot).not.toHaveAttribute('aria-hidden');
    expect(target).not.toHaveAttribute('aria-hidden');
    expect(sibling).toHaveAttribute('aria-hidden', 'true');
    expect(outside).toHaveAttribute('aria-hidden', 'true');

    revert();
  });

  it('does not hide the shadow content of a target that is a shadow host', function () {
    let outside = document.createElement('button');
    document.body.append(outside);
    let {shadowHost, shadowRoot} = createShadowRoot();
    let inner = document.createElement('button');
    shadowRoot.append(inner);

    let revert = ariaHideOutside([shadowHost]);

    expect(shadowHost).not.toHaveAttribute('aria-hidden');
    expect(inner).not.toHaveAttribute('aria-hidden');
    expect(outside).toHaveAttribute('aria-hidden', 'true');

    revert();
  });

  it('hides a shadow host added to a target shadow root without marking its shadow content', async function () {
    let {shadowRoot} = createShadowRoot();
    let target = document.createElement('button');
    shadowRoot.append(target);

    let revert = ariaHideOutside([target]);

    let newHost = document.createElement('div');
    shadowRoot.append(newHost);
    let newInner = newHost.attachShadow({mode: 'open'});
    let innerButton = document.createElement('button');
    newInner.append(innerButton);
    // MutationObserver is async
    await waitFor(() => expect(newHost).toHaveAttribute('aria-hidden', 'true'));
    expect(innerButton).not.toHaveAttribute('aria-hidden');

    revert();
  });

  it('does not hide content added to shadow roots outside of the root', async function () {
    let {shadowHost, shadowRoot} = createShadowRoot();
    let container = document.createElement('div');
    let target = document.createElement('button');
    container.append(target);
    shadowRoot.append(container);

    let revert = ariaHideOutside([target], container);

    let outsideRoot = document.createElement('button');
    shadowRoot.append(outsideRoot);
    let insideRoot = document.createElement('button');
    container.append(insideRoot);
    // MutationObserver is async
    await waitFor(() => expect(insideRoot).toHaveAttribute('aria-hidden', 'true'));
    expect(outsideRoot).not.toHaveAttribute('aria-hidden');
    expect(shadowHost).not.toHaveAttribute('aria-hidden');
    expect(target).not.toHaveAttribute('aria-hidden');

    revert();
  });
});

/*
 * Copyright 2020 Adobe. All rights reserved.
 * This file is licensed to you under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License. You may obtain a copy
 * of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software distributed under
 * the License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR REPRESENTATIONS
 * OF ANY KIND, either express or implied. See the License for the specific language
 * governing permissions and limitations under the License.
 */

import {act, createShadowRoot, render, waitFor} from '@react-spectrum/test-utils-internal';
import {ariaHideOutside} from '../src';
import {enableShadowDOM} from '@react-stately/flags';
import React, {useRef, useState} from 'react';

describe('ariaHideOutside', function () {
  it('should hide everything except the provided element [button]', function () {
    let {getByRole, getAllByRole} = render(
      <>
        <input type="checkbox" />
        <button>Button</button>
        <input type="checkbox" />
      </>
    );

    let checkboxes = getAllByRole('checkbox');
    let button = getByRole('button');

    let revert = ariaHideOutside([button]);

    expect(checkboxes[0]).toHaveAttribute('aria-hidden', 'true');
    expect(checkboxes[1]).toHaveAttribute('aria-hidden', 'true');
    expect(button).not.toHaveAttribute('aria-hidden');

    expect(() => getAllByRole('checkbox')).toThrow();
    expect(() => getByRole('button')).not.toThrow();

    revert();

    expect(checkboxes[0]).not.toHaveAttribute('aria-hidden');
    expect(checkboxes[1]).not.toHaveAttribute('aria-hidden');
    expect(button).not.toHaveAttribute('aria-hidden');

    expect(() => getAllByRole('checkbox')).not.toThrow();
    expect(() => getByRole('button')).not.toThrow();
  });

  it('should hide everything except multiple elements', function () {
    let {getByRole, getAllByRole, queryByRole, queryAllByRole} = render(
      <>
        <input type="checkbox" />
        <button>Button</button>
        <input type="checkbox" />
      </>
    );

    let checkboxes = getAllByRole('checkbox');
    let button = getByRole('button');

    let revert = ariaHideOutside(checkboxes);

    expect(checkboxes[0]).not.toHaveAttribute('aria-hidden', 'true');
    expect(checkboxes[1]).not.toHaveAttribute('aria-hidden', 'true');
    expect(button).toHaveAttribute('aria-hidden');

    expect(queryAllByRole('checkbox')).not.toBeNull();
    expect(queryByRole('button')).toBeNull();

    revert();

    expect(checkboxes[0]).not.toHaveAttribute('aria-hidden');
    expect(checkboxes[1]).not.toHaveAttribute('aria-hidden');
    expect(button).not.toHaveAttribute('aria-hidden');

    expect(() => getAllByRole('checkbox')).not.toThrow();
    expect(() => getByRole('button')).not.toThrow();
  });

  it('should not traverse into an already hidden container', function () {
    let {getByRole, getAllByRole} = render(
      <>
        <div>
          <input type="checkbox" />
        </div>
        <button>Button</button>
        <input type="checkbox" />
      </>
    );

    let checkboxes = getAllByRole('checkbox');
    let button = getByRole('button');

    let revert = ariaHideOutside([button]);

    expect(checkboxes[0].parentElement).toHaveAttribute('aria-hidden', 'true');
    expect(checkboxes[1]).toHaveAttribute('aria-hidden', 'true');
    expect(button).not.toHaveAttribute('aria-hidden');

    expect(() => getAllByRole('checkbox')).toThrow();
    expect(() => getByRole('button')).not.toThrow();

    revert();

    expect(checkboxes[0].parentElement).not.toHaveAttribute('aria-hidden');
    expect(checkboxes[1]).not.toHaveAttribute('aria-hidden');
    expect(button).not.toHaveAttribute('aria-hidden');

    expect(() => getAllByRole('checkbox')).not.toThrow();
    expect(() => getByRole('button')).not.toThrow();
  });

  it('should not overwrite an existing aria-hidden prop', function () {
    let {getByRole, getAllByRole} = render(
      <>
        <input type="checkbox" aria-hidden="true" />
        <button>Button</button>
        <input type="checkbox" />
      </>
    );

    let checkboxes = getAllByRole('checkbox');
    let button = getByRole('button');

    let revert = ariaHideOutside([button]);

    expect(checkboxes).toHaveLength(1);
    expect(checkboxes[0]).toHaveAttribute('aria-hidden', 'true');
    expect(button).not.toHaveAttribute('aria-hidden');

    expect(() => getAllByRole('checkbox')).toThrow();
    expect(() => getByRole('button')).not.toThrow();

    revert();

    checkboxes = getAllByRole('checkbox');
    expect(checkboxes).toHaveLength(1);
    expect(checkboxes[0]).not.toHaveAttribute('aria-hidden');
    expect(button).not.toHaveAttribute('aria-hidden');

    expect(() => getAllByRole('checkbox')).not.toThrow();
    expect(() => getByRole('button')).not.toThrow();
  });

  it('should handle when a new element is added outside while active', async function () {
    let Test = props => (
      <>
        {props.show && <input type="checkbox" />}
        <button>Button</button>
        {props.show && <input type="checkbox" />}
      </>
    );

    let {getByRole, getAllByRole, rerender} = render(<Test />);

    let button = getByRole('button');
    expect(() => getAllByRole('checkbox')).toThrow();

    let revert = ariaHideOutside([button]);

    rerender(<Test show />);

    // MutationObserver is async
    await waitFor(() => expect(() => getAllByRole('checkbox')).toThrow());
    expect(() => getByRole('button')).not.toThrow();

    revert();

    expect(getAllByRole('checkbox')).toHaveLength(2);
  });

  it('should handle when a new element is added to an already hidden container', async function () {
    let Test = props => (
      <>
        <div data-testid="test">
          {props.show && <input type="checkbox" />}
        </div>
        <button>Button</button>
        {props.show && <input type="checkbox" />}
      </>
    );

    let {getByRole, getAllByRole, getByTestId, rerender} = render(<Test />);

    let button = getByRole('button');
    let test = getByTestId('test');
    expect(() => getAllByRole('checkbox')).toThrow();

    let revert = ariaHideOutside([button]);

    expect(test).toHaveAttribute('aria-hidden');

    rerender(<Test show />);

    // MutationObserver is async
    await waitFor(() => expect(() => getAllByRole('checkbox')).toThrow());
    expect(() => getByRole('button')).not.toThrow();

    let checkboxes = getAllByRole('checkbox', {hidden: true});
    expect(test).toHaveAttribute('aria-hidden');
    expect(checkboxes[0]).not.toHaveAttribute('aria-hidden');
    expect(checkboxes[1]).toHaveAttribute('aria-hidden', 'true');

    revert();

    expect(getAllByRole('checkbox')).toHaveLength(2);
  });

  it('should handle when a new element is added along with a top layer element', async function () {
    let Test = props => (
      <>
        <button>Button</button>
        {props.show && <div>
          <div role="alert" data-react-aria-top-layer="true">Top layer</div>
          <input type="checkbox" />
        </div>}
      </>
    );

    let {getByRole, queryByRole, getAllByRole, rerender} = render(<Test />);

    let button = getByRole('button');
    expect(queryByRole('checkbox')).toBeNull();

    let revert = ariaHideOutside([button]);

    rerender(<Test show />);

    // MutationObserver is async
    await waitFor(() => queryByRole('checkbox') == null);
    expect(queryByRole('button')).not.toBeNull();
    expect(getByRole('alert')).toHaveTextContent('Top layer');

    revert();

    expect(getAllByRole('checkbox')).toHaveLength(1);
  });

  it('should handle when a new element is added inside a target element', async function () {
    let Test = props => (
      <>
        <input type="checkbox" />
        <div data-testid="test">
          <button>Button</button>
          {props.show && <input type="radio" />}
        </div>
        <input type="checkbox" />
      </>
    );

    let {queryByRole, getByRole, getAllByRole, getByTestId, rerender} = render(<Test />);

    let test = getByTestId('test');
    let revert = ariaHideOutside([test]);

    expect(() => getAllByRole('checkbox')).toThrow();
    expect(queryByRole('radio')).toBeNull();
    expect(queryByRole('button')).not.toBeNull();
    expect(() => getByTestId('test')).not.toThrow();

    rerender(<Test show />);

    // Wait for mutation observer tick
    await Promise.resolve();
    expect(() => getAllByRole('checkbox')).toThrow();
    expect(() => getByRole('radio')).not.toThrow();
    expect(() => getByRole('button')).not.toThrow();
    expect(() => getByTestId('test')).not.toThrow();

    revert();

    expect(() => getAllByRole('checkbox')).not.toThrow();
    expect(() => getByRole('radio')).not.toThrow();
    expect(() => getByRole('button')).not.toThrow();
    expect(() => getByTestId('test')).not.toThrow();
  });

  it('should handle when a new element is added and then reparented', async function () {

    let Test = () => {
      const ref = useRef(null);
      const mutate = () => {
        let parent = document.createElement('ul');
        let child = document.createElement('li');
        ref.current.append(parent);
        parent.appendChild(child);
        parent.remove(); // this results in a mutation record for a disconnected ul with a connected li (through the new ul parent) in `addedNodes`
        let newParent = document.createElement('ul');
        newParent.appendChild(child);
        ref.current.append(newParent);
      };

      return (
        <>
          <div data-testid="test" ref={ref}>
            <button onClick={mutate}>Mutate</button>
          </div>
        </>
      );
    };

    let {queryByRole, getAllByRole, getByTestId} = render(<Test />);

    ariaHideOutside([getByTestId('test')]);

    queryByRole('button').click();
    await Promise.resolve(); // Wait for mutation observer tick

    expect(getAllByRole('listitem')).toHaveLength(1);
  });

  it('should handle when a new element is added and then reparented to a hidden container', async function () {

    let Test = () => {
      const ref = useRef(null);
      const mutate = () => {
        let parent = document.createElement('ul');
        let child = document.createElement('li');
        ref.current.append(parent);
        parent.appendChild(child);
        parent.remove(); // this results in a mutation record for a disconnected ul with a connected li (through the new ul parent) in `addedNodes`
        let newParent = document.createElement('ul');
        newParent.appendChild(child);
        ref.current.append(newParent);
      };

      return (
        <>
          <div data-testid="test">
            <button onClick={mutate}>Mutate</button>
          </div>
          <div data-testid="sibling" ref={ref} />
        </>
      );
    };

    let {queryByRole, queryAllByRole, getByTestId} = render(<Test />);

    ariaHideOutside([getByTestId('test')]);

    queryByRole('button').click();
    await Promise.resolve(); // Wait for mutation observer tick

    expect(queryAllByRole('listitem')).toHaveLength(0);
  });


  it('work when called multiple times', function () {
    let {getByRole, getAllByRole} = render(
      <>
        <input type="checkbox" />
        <input type="radio" />
        <button>Button</button>
        <input type="radio" />
        <input type="checkbox" />
      </>
    );

    let radios = getAllByRole('radio');
    let button = getByRole('button');

    let revert1 = ariaHideOutside([button, ...radios]);

    expect(() => getAllByRole('checkbox')).toThrow();
    expect(() => getAllByRole('radio')).not.toThrow();
    expect(() => getByRole('button')).not.toThrow();

    let revert2 = ariaHideOutside([button]);

    expect(() => getAllByRole('checkbox')).toThrow();
    expect(() => getAllByRole('radio')).toThrow();
    expect(() => getByRole('button')).not.toThrow();

    revert2();

    expect(() => getAllByRole('checkbox')).toThrow();
    expect(() => getAllByRole('radio')).not.toThrow();
    expect(() => getByRole('button')).not.toThrow();

    revert1();

    expect(() => getAllByRole('checkbox')).not.toThrow();
    expect(() => getAllByRole('radio')).not.toThrow();
    expect(() => getByRole('button')).not.toThrow();
  });

  it('work when called multiple times and restored out of order', function () {
    let {getByRole, getAllByRole} = render(
      <>
        <input type="checkbox" />
        <input type="radio" />
        <button>Button</button>
        <input type="radio" />
        <input type="checkbox" />
      </>
    );

    let radios = getAllByRole('radio');
    let button = getByRole('button');

    let revert1 = ariaHideOutside([button, ...radios]);

    expect(() => getAllByRole('checkbox')).toThrow();
    expect(() => getAllByRole('radio')).not.toThrow();
    expect(() => getByRole('button')).not.toThrow();

    let revert2 = ariaHideOutside([button]);

    expect(() => getAllByRole('checkbox')).toThrow();
    expect(() => getAllByRole('radio')).toThrow();
    expect(() => getByRole('button')).not.toThrow();

    revert1();

    expect(() => getAllByRole('checkbox')).toThrow();
    expect(() => getAllByRole('radio')).toThrow();
    expect(() => getByRole('button')).not.toThrow();

    revert2();

    expect(() => getAllByRole('checkbox')).not.toThrow();
    expect(() => getAllByRole('radio')).not.toThrow();
    expect(() => getByRole('button')).not.toThrow();
  });

  it('should hide everything except the provided element [row]', function () {
    let {getAllByRole, getByTestId} = render(
      <div role="grid">
        <div role="row">
          <div role="gridcell">
            <span data-testid="test-span">
              Cell 1
            </span></div>
        </div>
        <div role="row">
          <div role="gridcell">Cell 2</div>
        </div>
      </div>
    );

    let cells = getAllByRole('gridcell');
    let rows = getAllByRole('row');
    let span = getByTestId('test-span');

    let revert = ariaHideOutside([rows[1]]);

    // Applies aria-hidden to the row and cell despite recursive nature of aria-hidden
    // for https://bugs.webkit.org/show_bug.cgi?id=222623
    expect(rows[0]).toHaveAttribute('aria-hidden', 'true');
    expect(cells[0]).toHaveAttribute('aria-hidden', 'true');
    expect(span).not.toHaveAttribute('aria-hidden');
    expect(rows[1]).not.toHaveAttribute('aria-hidden', 'true');
    expect(cells[1]).not.toHaveAttribute('aria-hidden', 'true');

    revert();

    expect(rows[0]).not.toHaveAttribute('aria-hidden', 'true');
    expect(cells[0]).not.toHaveAttribute('aria-hidden', 'true');
    expect(rows[1]).not.toHaveAttribute('aria-hidden', 'true');
    expect(cells[1]).not.toHaveAttribute('aria-hidden', 'true');
    expect(span).not.toHaveAttribute('aria-hidden');
  });

  it('should unhide after item reorder', async function () {
    function Item(props) {
      return (
        <div role="presentation">
          <div data-testid={props.testid} role="row">
            <div role="gridcell" />
          </div>
        </div>
      );
    }

    function Test() {
      let [count, setCount] = useState(0);
      let items = ['row1', 'row2', 'row3', 'row4', 'row5'];
      if (count === 1) {
        items = ['row2', 'row1', 'row3', 'row4', 'row5'];
      } else if (count === 2) {
        items = ['row2', 'row3', 'row1', 'row4', 'row5'];
      }

      return (
        <>
          <button onClick={() => setCount((old) => old + 1)}>press</button>
          {items.map((item) => <Item testid={item} key={item} />)}
        </>

      );
    }

    let {getByRole, getByTestId} = render(
      <Test />
    );

    let button = getByRole('button');
    let row = getByTestId('row1');
    let revert = ariaHideOutside([button]);

    act(() => button.click());
    await Promise.resolve();
    act(() => button.click());
    await Promise.resolve();
    revert();
    expect(row.parentElement).not.toHaveAttribute('aria-hidden', 'true');
  });

  // Shared helpers for the shadow DOM tests below. Everything registered here is removed after each test.
  let cleanups = [];
  let addToBody = (element) => {
    document.body.appendChild(element);
    cleanups.push(() => element.remove());
    return element;
  };
  let createShadow = (attachTo) => {
    let shadow = createShadowRoot(attachTo);
    cleanups.push(() => shadow.shadowHost.remove());
    return shadow;
  };
  afterEach(function () {
    for (let cleanup of cleanups.splice(0)) {
      cleanup();
    }
  });

  // These run before the flag is enabled below, since the flag cannot be reset.
  it('with shadowDOM disabled, does not hide a sibling inside a target shadow root', function () {
    let shadow = createShadow();
    shadow.shadowRoot.innerHTML = '<button>Button</button><input type="checkbox" />';
    let button = shadow.shadowRoot.querySelector('button');
    let checkbox = shadow.shadowRoot.querySelector('input');

    let revert = ariaHideOutside([button]);

    // Without shadow DOM support the target is not found under body, so body itself is hidden.
    expect(document.body).toHaveAttribute('aria-hidden', 'true');
    expect(shadow.shadowHost).not.toHaveAttribute('aria-hidden');
    expect(checkbox).not.toHaveAttribute('aria-hidden');
    expect(button).not.toHaveAttribute('aria-hidden');

    revert();
    expect(document.body).not.toHaveAttribute('aria-hidden');
  });

  it('with shadowDOM disabled, does not hide content added later to a target shadow root', async function () {
    let shadow = createShadow();
    shadow.shadowRoot.innerHTML = '<button>Button</button>';
    let button = shadow.shadowRoot.querySelector('button');

    let revert = ariaHideOutside([button]);

    let checkbox = document.createElement('input');
    checkbox.type = 'checkbox';
    shadow.shadowRoot.appendChild(checkbox);
    // MutationObserver is async
    await Promise.resolve();
    expect(checkbox).not.toHaveAttribute('aria-hidden');

    revert();
  });

  describe('with shadowDOM enabled', function () {
    beforeAll(function () {
      enableShadowDOM();
    });

    it('hides siblings in every shadow root enclosing a target, but not the hosts on the path', function () {
      let outer = createShadow();
      outer.shadowRoot.innerHTML = '<input type="radio" /><section></section>';
      let outerSibling = outer.shadowRoot.querySelector('input');
      let section = outer.shadowRoot.querySelector('section');
      let inner = createShadow(section);
      inner.shadowRoot.innerHTML = '<input type="checkbox" /><button>Button</button>';
      let innerSibling = inner.shadowRoot.querySelector('input');
      let button = inner.shadowRoot.querySelector('button');
      let lightSibling = addToBody(document.createElement('input'));

      let revert = ariaHideOutside([button]);

      expect(outer.shadowHost).not.toHaveAttribute('aria-hidden');
      expect(section).not.toHaveAttribute('aria-hidden');
      expect(inner.shadowHost).not.toHaveAttribute('aria-hidden');
      expect(button).not.toHaveAttribute('aria-hidden');
      expect(outerSibling).toHaveAttribute('aria-hidden', 'true');
      expect(innerSibling).toHaveAttribute('aria-hidden', 'true');
      expect(lightSibling).toHaveAttribute('aria-hidden', 'true');

      revert();
    });

    it('hides content added later to a target shadow root, and keeps content added inside the target visible', async function () {
      let shadow = createShadow();
      shadow.shadowRoot.innerHTML = '<div><button>Button</button></div>';
      let target = shadow.shadowRoot.querySelector('div');

      let revert = ariaHideOutside([target]);

      let checkbox = document.createElement('input');
      checkbox.type = 'checkbox';
      shadow.shadowRoot.appendChild(checkbox);
      let radio = document.createElement('input');
      radio.type = 'radio';
      target.appendChild(radio);

      await waitFor(() => expect(checkbox).toHaveAttribute('aria-hidden', 'true'));
      expect(radio).not.toHaveAttribute('aria-hidden');
      expect(target).not.toHaveAttribute('aria-hidden');

      revert();
    });

    it('hides content added later to enclosing shadow roots and to elements on the path', async function () {
      let outer = createShadow();
      outer.shadowRoot.innerHTML = '<section></section>';
      let section = outer.shadowRoot.querySelector('section');
      let inner = createShadow(section);
      inner.shadowRoot.innerHTML = '<button>Button</button>';
      let button = inner.shadowRoot.querySelector('button');

      let revert = ariaHideOutside([button]);

      let inSection = document.createElement('input');
      inSection.type = 'checkbox';
      section.appendChild(inSection);
      let inOuter = document.createElement('input');
      inOuter.type = 'radio';
      outer.shadowRoot.appendChild(inOuter);
      let onHost = document.createElement('input');
      onHost.type = 'checkbox';
      outer.shadowHost.appendChild(onHost);

      await waitFor(() => {
        expect(inSection).toHaveAttribute('aria-hidden', 'true');
        expect(inOuter).toHaveAttribute('aria-hidden', 'true');
        expect(onHost).toHaveAttribute('aria-hidden', 'true');
      });
      expect(section).not.toHaveAttribute('aria-hidden');
      expect(inner.shadowHost).not.toHaveAttribute('aria-hidden');
      expect(button).not.toHaveAttribute('aria-hidden');

      revert();
    });

    it('keeps live announcers and top layer elements visible in shadow roots, present or added later', async function () {
      let shadow = createShadow();
      shadow.shadowRoot.innerHTML = '<button>Button</button><div data-live-announcer="true">Announce</div><div data-react-aria-top-layer="true">Top</div>';
      let button = shadow.shadowRoot.querySelector('button');
      let announcer = shadow.shadowRoot.querySelector('[data-live-announcer]');
      let topLayer = shadow.shadowRoot.querySelector('[data-react-aria-top-layer]');

      let revert = ariaHideOutside([button]);

      expect(announcer).not.toHaveAttribute('aria-hidden');
      expect(topLayer).not.toHaveAttribute('aria-hidden');

      let laterAnnouncer = document.createElement('div');
      laterAnnouncer.dataset.liveAnnouncer = 'true';
      let laterTopLayer = document.createElement('div');
      laterTopLayer.dataset.reactAriaTopLayer = 'true';
      let checkbox = document.createElement('input');
      checkbox.type = 'checkbox';
      shadow.shadowRoot.append(laterAnnouncer, laterTopLayer, checkbox);

      await waitFor(() => expect(checkbox).toHaveAttribute('aria-hidden', 'true'));
      expect(laterAnnouncer).not.toHaveAttribute('aria-hidden');
      expect(laterTopLayer).not.toHaveAttribute('aria-hidden');
      expect(button).not.toHaveAttribute('aria-hidden');

      revert();
    });

    it('keeps targets in different shadow roots visible, and hides their siblings and later content in both roots', async function () {
      let first = createShadow();
      first.shadowRoot.innerHTML = '<input type="text" /><button>First sibling</button>';
      let second = createShadow();
      second.shadowRoot.innerHTML = '<div role="dialog"></div><button>Second sibling</button>';
      let input = first.shadowRoot.querySelector('input');
      let dialog = second.shadowRoot.querySelector('[role="dialog"]');
      let firstSibling = first.shadowRoot.querySelector('button');
      let secondSibling = second.shadowRoot.querySelector('button');

      let revert = ariaHideOutside([input, dialog]);

      expect(input).not.toHaveAttribute('aria-hidden');
      expect(dialog).not.toHaveAttribute('aria-hidden');
      expect(first.shadowHost).not.toHaveAttribute('aria-hidden');
      expect(second.shadowHost).not.toHaveAttribute('aria-hidden');
      expect(firstSibling).toHaveAttribute('aria-hidden', 'true');
      expect(secondSibling).toHaveAttribute('aria-hidden', 'true');

      let firstLater = document.createElement('button');
      first.shadowRoot.appendChild(firstLater);
      let secondLater = document.createElement('button');
      second.shadowRoot.appendChild(secondLater);

      await waitFor(() => {
        expect(firstLater).toHaveAttribute('aria-hidden', 'true');
        expect(secondLater).toHaveAttribute('aria-hidden', 'true');
      });

      revert();
    });

    it('keeps a target in a shadow root and a target in the light DOM visible', async function () {
      let shadow = createShadow();
      shadow.shadowRoot.innerHTML = '<input type="text" /><button>Sibling</button>';
      let input = shadow.shadowRoot.querySelector('input');
      let sibling = shadow.shadowRoot.querySelector('button');
      let popover = addToBody(document.createElement('div'));
      let lightSibling = addToBody(document.createElement('button'));

      let revert = ariaHideOutside([input, popover]);

      expect(input).not.toHaveAttribute('aria-hidden');
      expect(popover).not.toHaveAttribute('aria-hidden');
      expect(shadow.shadowHost).not.toHaveAttribute('aria-hidden');
      expect(sibling).toHaveAttribute('aria-hidden', 'true');
      expect(lightSibling).toHaveAttribute('aria-hidden', 'true');

      let later = document.createElement('input');
      shadow.shadowRoot.appendChild(later);
      await waitFor(() => expect(later).toHaveAttribute('aria-hidden', 'true'));

      revert();
    });

    it('restores shadow root content and stops observing shadow roots when reverted', async function () {
      let shadow = createShadow();
      shadow.shadowRoot.innerHTML = '<button>Button</button><input type="checkbox" />';
      let button = shadow.shadowRoot.querySelector('button');
      let checkbox = shadow.shadowRoot.querySelector('input');

      let revert = ariaHideOutside([button]);
      expect(checkbox).toHaveAttribute('aria-hidden', 'true');

      revert();
      expect(checkbox).not.toHaveAttribute('aria-hidden');

      let radio = document.createElement('input');
      radio.type = 'radio';
      shadow.shadowRoot.appendChild(radio);
      // MutationObserver is async
      await Promise.resolve();
      expect(radio).not.toHaveAttribute('aria-hidden');
    });

    it('pauses the outer shadow root observation during a nested call and resumes it after', async function () {
      let shadow = createShadow();
      shadow.shadowRoot.innerHTML = '<button>Button</button>';
      let button = shadow.shadowRoot.querySelector('button');
      let container = addToBody(document.createElement('div'));
      let lightButton = document.createElement('button');
      container.appendChild(lightButton);

      let revertOuter = ariaHideOutside([button]);
      let revertInner = ariaHideOutside([lightButton], {root: container});

      let paused = document.createElement('input');
      paused.type = 'checkbox';
      shadow.shadowRoot.appendChild(paused);
      // MutationObserver is async
      await Promise.resolve();
      expect(paused).not.toHaveAttribute('aria-hidden');

      revertInner();

      let resumed = document.createElement('input');
      resumed.type = 'radio';
      shadow.shadowRoot.appendChild(resumed);
      await waitFor(() => expect(resumed).toHaveAttribute('aria-hidden', 'true'));

      revertOuter();
    });

    it('does not hide the contents of a target that is itself a shadow host', function () {
      let target = createShadow();
      target.shadowRoot.innerHTML = '<button>Inside</button>';
      let inside = target.shadowRoot.querySelector('button');
      let outside = addToBody(document.createElement('button'));

      let revert = ariaHideOutside([target.shadowHost]);

      expect(target.shadowHost).not.toHaveAttribute('aria-hidden');
      expect(inside).not.toHaveAttribute('aria-hidden');
      expect(outside).toHaveAttribute('aria-hidden', 'true');

      revert();
    });

    it('hides a sibling shadow host as a whole without hiding its contents individually', function () {
      let target = addToBody(document.createElement('button'));
      let sibling = createShadow();
      sibling.shadowRoot.innerHTML = '<input type="checkbox" />';
      let checkbox = sibling.shadowRoot.querySelector('input');

      let revert = ariaHideOutside([target]);

      expect(sibling.shadowHost).toHaveAttribute('aria-hidden', 'true');
      expect(checkbox).not.toHaveAttribute('aria-hidden');

      revert();
      expect(sibling.shadowHost).not.toHaveAttribute('aria-hidden');
    });

    it('hides a new shadow host added next to the target without hiding its contents individually', async function () {
      let shadow = createShadow();
      shadow.shadowRoot.innerHTML = '<button>Button</button>';
      let button = shadow.shadowRoot.querySelector('button');

      let revert = ariaHideOutside([button]);

      let newHost = document.createElement('div');
      shadow.shadowRoot.appendChild(newHost);
      let newShadow = newHost.attachShadow({mode: 'open'});
      newShadow.innerHTML = '<input type="checkbox" />';

      await waitFor(() => expect(newHost).toHaveAttribute('aria-hidden', 'true'));
      expect(newShadow.querySelector('input')).not.toHaveAttribute('aria-hidden');
      expect(button).not.toHaveAttribute('aria-hidden');

      revert();
    });

    it('does not throw when the target is inside a closed shadow root, and restores', function () {
      let host = addToBody(document.createElement('div'));
      let closed = host.attachShadow({mode: 'closed'});
      closed.innerHTML = '<button>Button</button>';
      let button = closed.querySelector('button');
      let outside = addToBody(document.createElement('button'));

      let revert;
      expect(() => {
        revert = ariaHideOutside([button]);
      }).not.toThrow();
      expect(outside).toHaveAttribute('aria-hidden', 'true');

      expect(() => revert()).not.toThrow();
      expect(outside).not.toHaveAttribute('aria-hidden');
    });

    it('restores hidden elements when a shadow host was removed from the DOM before restore', function () {
      let shadow = createShadow();
      shadow.shadowRoot.innerHTML = '<button>Button</button>';
      let button = shadow.shadowRoot.querySelector('button');
      let outside = addToBody(document.createElement('button'));

      let revert = ariaHideOutside([button]);
      expect(outside).toHaveAttribute('aria-hidden', 'true');

      shadow.shadowHost.remove();
      expect(() => revert()).not.toThrow();
      expect(outside).not.toHaveAttribute('aria-hidden');
    });

    it('handles a light DOM element slotted next to the target', function () {
      let host = addToBody(document.createElement('div'));
      let shadow = host.attachShadow({mode: 'open'});
      shadow.innerHTML = '<slot></slot><button>Button</button>';
      let button = shadow.querySelector('button');
      let light = document.createElement('span');
      host.appendChild(light);

      let revert;
      expect(() => {
        revert = ariaHideOutside([button]);
      }).not.toThrow();
      expect(light).toHaveAttribute('aria-hidden', 'true');
      expect(button).not.toHaveAttribute('aria-hidden');
      expect(host).not.toHaveAttribute('aria-hidden');

      expect(() => revert()).not.toThrow();
      expect(light).not.toHaveAttribute('aria-hidden');
    });

    it('hides a sibling of the slot that holds the target, but not the slot or the host', function () {
      let host = addToBody(document.createElement('div'));
      let shadow = host.attachShadow({mode: 'open'});
      shadow.innerHTML = '<i id="sib"></i><slot id="sl"></slot>';
      let sib = shadow.querySelector('#sib');
      let slot = shadow.querySelector('#sl');
      let button = document.createElement('button');
      host.appendChild(button);

      let revert = ariaHideOutside([button]);

      expect(sib).toHaveAttribute('aria-hidden', 'true');
      expect(slot).not.toHaveAttribute('aria-hidden');
      expect(host).not.toHaveAttribute('aria-hidden');
      expect(button).not.toHaveAttribute('aria-hidden');

      revert();
    });

    it('hides a sibling of a wrapper around the slot that holds the target, but not the wrapper or the slot', function () {
      let host = addToBody(document.createElement('div'));
      let shadow = host.attachShadow({mode: 'open'});
      shadow.innerHTML = '<i id="sib"></i><section id="wrap"><slot id="sl"></slot></section>';
      let sib = shadow.querySelector('#sib');
      let wrap = shadow.querySelector('#wrap');
      let slot = shadow.querySelector('#sl');
      let button = document.createElement('button');
      host.appendChild(button);

      let revert = ariaHideOutside([button]);

      expect(sib).toHaveAttribute('aria-hidden', 'true');
      expect(wrap).not.toHaveAttribute('aria-hidden');
      expect(slot).not.toHaveAttribute('aria-hidden');
      expect(host).not.toHaveAttribute('aria-hidden');
      expect(button).not.toHaveAttribute('aria-hidden');

      revert();
    });

    it('hides content added later to the shadow root holding the slot that holds the target', async function () {
      let host = addToBody(document.createElement('div'));
      let shadow = host.attachShadow({mode: 'open'});
      shadow.innerHTML = '<section><slot></slot></section>';
      let button = document.createElement('button');
      host.appendChild(button);

      let revert = ariaHideOutside([button]);

      let later = document.createElement('input');
      shadow.appendChild(later);
      await waitFor(() => expect(later).toHaveAttribute('aria-hidden', 'true'));
      expect(shadow.querySelector('section')).not.toHaveAttribute('aria-hidden');
      expect(host).not.toHaveAttribute('aria-hidden');
      expect(button).not.toHaveAttribute('aria-hidden');

      revert();
    });

    it('hides the sibling of a target reached through a slot in an outer shadow root, but not the hosts or wrapper on the path', function () {
      let outer = addToBody(document.createElement('div'));
      let outerShadow = outer.attachShadow({mode: 'open'});
      outerShadow.innerHTML = '<div id="wrapper"><slot></slot></div><i id="sib"></i>';
      let wrapper = outerShadow.querySelector('#wrapper');
      let sib = outerShadow.querySelector('#sib');
      let inner = document.createElement('div');
      outer.appendChild(inner);
      inner.attachShadow({mode: 'open'}).innerHTML = '<slot></slot>';
      let button = document.createElement('button');
      inner.appendChild(button);

      let revert = ariaHideOutside([button]);

      expect(sib).toHaveAttribute('aria-hidden', 'true');
      expect(wrapper).not.toHaveAttribute('aria-hidden');
      expect(outer).not.toHaveAttribute('aria-hidden');
      expect(inner).not.toHaveAttribute('aria-hidden');
      expect(button).not.toHaveAttribute('aria-hidden');

      revert();
    });

    it('hides a light DOM sibling of the target that is slotted into the same slot', function () {
      let host = addToBody(document.createElement('div'));
      host.attachShadow({mode: 'open'}).innerHTML = '<slot></slot>';
      let button = document.createElement('button');
      let sibling = document.createElement('input');
      host.append(button, sibling);

      let revert = ariaHideOutside([button]);

      expect(sibling).toHaveAttribute('aria-hidden', 'true');
      expect(button).not.toHaveAttribute('aria-hidden');
      expect(host).not.toHaveAttribute('aria-hidden');

      revert();
    });

    it('hides a light DOM sibling of the target that is slotted into a different slot', function () {
      let host = addToBody(document.createElement('div'));
      host.attachShadow({mode: 'open'}).innerHTML = '<slot name="first"></slot><slot id="second"></slot>';
      let button = document.createElement('button');
      button.slot = 'first';
      let sibling = document.createElement('input');
      host.append(button, sibling);
      let second = host.shadowRoot.querySelector('#second');

      let revert = ariaHideOutside([button]);

      expect(second).toHaveAttribute('aria-hidden', 'true');
      expect(host.shadowRoot.querySelector('slot[name="first"]')).not.toHaveAttribute('aria-hidden');
      expect(button).not.toHaveAttribute('aria-hidden');
      expect(host).not.toHaveAttribute('aria-hidden');

      revert();
    });
  });

  describe('with shouldUseInert in shadow roots', function () {
    let ariaHideOutsideWithInert;
    beforeAll(function () {
      // jsdom does not implement inert, so define it before the module checks for support.
      Object.defineProperty(HTMLElement.prototype, 'inert', {configurable: true, writable: true, value: false});
      jest.isolateModules(function () {
        require('@react-stately/flags').enableShadowDOM();
        ariaHideOutsideWithInert = require('../src').ariaHideOutside;
      });
    });

    afterAll(function () {
      delete HTMLElement.prototype.inert;
    });

    it('sets inert instead of aria-hidden on shadow root content', async function () {
      let shadow = createShadow();
      shadow.shadowRoot.innerHTML = '<button>Button</button><input type="checkbox" />';
      let button = shadow.shadowRoot.querySelector('button');
      let checkbox = shadow.shadowRoot.querySelector('input');

      let revert = ariaHideOutsideWithInert([button], {shouldUseInert: true});

      expect(checkbox.inert).toBe(true);
      expect(checkbox).not.toHaveAttribute('aria-hidden');
      expect(button.inert).toBe(false);

      let radio = document.createElement('input');
      radio.type = 'radio';
      shadow.shadowRoot.appendChild(radio);
      await waitFor(() => expect(radio.inert).toBe(true));

      revert();
      expect(checkbox.inert).toBe(false);
      expect(radio.inert).toBe(false);
    });
  });
});

/*
 * Copyright 2020 Adobe. All rights reserved.
 * This file is licensed to you under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License. You may obtain a copy
 * of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software distributed under
 * the License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR REPRESENTATIONS
 * OF ANY KIND, either express or implied. See the License for the specific language
 * governing permissions and limitations under the License.
 */

import {act, render, waitFor} from '@react-spectrum/test-utils-internal';
import {ariaHideOutside} from '../src';
import {enableShadowDOM} from '@react-stately/flags';
import {keepVisible} from '../src/ariaHideOutside';
import React, {useRef, useState} from 'react';

describe('ariaHideOutside', function () {
  it('should hide everything except the provided element [button]', function () {
    let {getByRole, getAllByRole} = render(
      <>
        <input type="checkbox" />
        <button>Button</button>
        <input type="checkbox" />
      </>
    );

    let checkboxes = getAllByRole('checkbox');
    let button = getByRole('button');

    let revert = ariaHideOutside([button]);

    expect(checkboxes[0]).toHaveAttribute('aria-hidden', 'true');
    expect(checkboxes[1]).toHaveAttribute('aria-hidden', 'true');
    expect(button).not.toHaveAttribute('aria-hidden');

    expect(() => getAllByRole('checkbox')).toThrow();
    expect(() => getByRole('button')).not.toThrow();

    revert();

    expect(checkboxes[0]).not.toHaveAttribute('aria-hidden');
    expect(checkboxes[1]).not.toHaveAttribute('aria-hidden');
    expect(button).not.toHaveAttribute('aria-hidden');

    expect(() => getAllByRole('checkbox')).not.toThrow();
    expect(() => getByRole('button')).not.toThrow();
  });

  it('should hide everything except multiple elements', function () {
    let {getByRole, getAllByRole, queryByRole, queryAllByRole} = render(
      <>
        <input type="checkbox" />
        <button>Button</button>
        <input type="checkbox" />
      </>
    );

    let checkboxes = getAllByRole('checkbox');
    let button = getByRole('button');

    let revert = ariaHideOutside(checkboxes);

    expect(checkboxes[0]).not.toHaveAttribute('aria-hidden', 'true');
    expect(checkboxes[1]).not.toHaveAttribute('aria-hidden', 'true');
    expect(button).toHaveAttribute('aria-hidden');

    expect(queryAllByRole('checkbox')).not.toBeNull();
    expect(queryByRole('button')).toBeNull();

    revert();

    expect(checkboxes[0]).not.toHaveAttribute('aria-hidden');
    expect(checkboxes[1]).not.toHaveAttribute('aria-hidden');
    expect(button).not.toHaveAttribute('aria-hidden');

    expect(() => getAllByRole('checkbox')).not.toThrow();
    expect(() => getByRole('button')).not.toThrow();
  });

  it('should not traverse into an already hidden container', function () {
    let {getByRole, getAllByRole} = render(
      <>
        <div>
          <input type="checkbox" />
        </div>
        <button>Button</button>
        <input type="checkbox" />
      </>
    );

    let checkboxes = getAllByRole('checkbox');
    let button = getByRole('button');

    let revert = ariaHideOutside([button]);

    expect(checkboxes[0].parentElement).toHaveAttribute('aria-hidden', 'true');
    expect(checkboxes[1]).toHaveAttribute('aria-hidden', 'true');
    expect(button).not.toHaveAttribute('aria-hidden');

    expect(() => getAllByRole('checkbox')).toThrow();
    expect(() => getByRole('button')).not.toThrow();

    revert();

    expect(checkboxes[0].parentElement).not.toHaveAttribute('aria-hidden');
    expect(checkboxes[1]).not.toHaveAttribute('aria-hidden');
    expect(button).not.toHaveAttribute('aria-hidden');

    expect(() => getAllByRole('checkbox')).not.toThrow();
    expect(() => getByRole('button')).not.toThrow();
  });

  it('should not overwrite an existing aria-hidden prop', function () {
    let {getByRole, getAllByRole} = render(
      <>
        <input type="checkbox" aria-hidden="true" />
        <button>Button</button>
        <input type="checkbox" />
      </>
    );

    let checkboxes = getAllByRole('checkbox');
    let button = getByRole('button');

    let revert = ariaHideOutside([button]);

    expect(checkboxes).toHaveLength(1);
    expect(checkboxes[0]).toHaveAttribute('aria-hidden', 'true');
    expect(button).not.toHaveAttribute('aria-hidden');

    expect(() => getAllByRole('checkbox')).toThrow();
    expect(() => getByRole('button')).not.toThrow();

    revert();

    checkboxes = getAllByRole('checkbox');
    expect(checkboxes).toHaveLength(1);
    expect(checkboxes[0]).not.toHaveAttribute('aria-hidden');
    expect(button).not.toHaveAttribute('aria-hidden');

    expect(() => getAllByRole('checkbox')).not.toThrow();
    expect(() => getByRole('button')).not.toThrow();
  });

  it('should handle when a new element is added outside while active', async function () {
    let Test = props => (
      <>
        {props.show && <input type="checkbox" />}
        <button>Button</button>
        {props.show && <input type="checkbox" />}
      </>
    );

    let {getByRole, getAllByRole, rerender} = render(<Test />);

    let button = getByRole('button');
    expect(() => getAllByRole('checkbox')).toThrow();

    let revert = ariaHideOutside([button]);

    rerender(<Test show />);

    // MutationObserver is async
    await waitFor(() => expect(() => getAllByRole('checkbox')).toThrow());
    expect(() => getByRole('button')).not.toThrow();

    revert();

    expect(getAllByRole('checkbox')).toHaveLength(2);
  });

  it('should handle when a new element is added to an already hidden container', async function () {
    let Test = props => (
      <>
        <div data-testid="test">
          {props.show && <input type="checkbox" />}
        </div>
        <button>Button</button>
        {props.show && <input type="checkbox" />}
      </>
    );

    let {getByRole, getAllByRole, getByTestId, rerender} = render(<Test />);

    let button = getByRole('button');
    let test = getByTestId('test');
    expect(() => getAllByRole('checkbox')).toThrow();

    let revert = ariaHideOutside([button]);

    expect(test).toHaveAttribute('aria-hidden');

    rerender(<Test show />);

    // MutationObserver is async
    await waitFor(() => expect(() => getAllByRole('checkbox')).toThrow());
    expect(() => getByRole('button')).not.toThrow();

    let checkboxes = getAllByRole('checkbox', {hidden: true});
    expect(test).toHaveAttribute('aria-hidden');
    expect(checkboxes[0]).not.toHaveAttribute('aria-hidden');
    expect(checkboxes[1]).toHaveAttribute('aria-hidden', 'true');

    revert();

    expect(getAllByRole('checkbox')).toHaveLength(2);
  });

  it('should handle when a new element is added along with a top layer element', async function () {
    let Test = props => (
      <>
        <button>Button</button>
        {props.show && <div>
          <div role="alert" data-react-aria-top-layer="true">Top layer</div>
          <input type="checkbox" />
        </div>}
      </>
    );

    let {getByRole, queryByRole, getAllByRole, rerender} = render(<Test />);

    let button = getByRole('button');
    expect(queryByRole('checkbox')).toBeNull();

    let revert = ariaHideOutside([button]);

    rerender(<Test show />);

    // MutationObserver is async
    await waitFor(() => queryByRole('checkbox') == null);
    expect(queryByRole('button')).not.toBeNull();
    expect(getByRole('alert')).toHaveTextContent('Top layer');

    revert();

    expect(getAllByRole('checkbox')).toHaveLength(1);
  });

  it('should handle when a new element is added inside a target element', async function () {
    let Test = props => (
      <>
        <input type="checkbox" />
        <div data-testid="test">
          <button>Button</button>
          {props.show && <input type="radio" />}
        </div>
        <input type="checkbox" />
      </>
    );

    let {queryByRole, getByRole, getAllByRole, getByTestId, rerender} = render(<Test />);

    let test = getByTestId('test');
    let revert = ariaHideOutside([test]);

    expect(() => getAllByRole('checkbox')).toThrow();
    expect(queryByRole('radio')).toBeNull();
    expect(queryByRole('button')).not.toBeNull();
    expect(() => getByTestId('test')).not.toThrow();

    rerender(<Test show />);

    // Wait for mutation observer tick
    await Promise.resolve();
    expect(() => getAllByRole('checkbox')).toThrow();
    expect(() => getByRole('radio')).not.toThrow();
    expect(() => getByRole('button')).not.toThrow();
    expect(() => getByTestId('test')).not.toThrow();

    revert();

    expect(() => getAllByRole('checkbox')).not.toThrow();
    expect(() => getByRole('radio')).not.toThrow();
    expect(() => getByRole('button')).not.toThrow();
    expect(() => getByTestId('test')).not.toThrow();
  });

  it('should handle when a new element is added and then reparented', async function () {

    let Test = () => {
      const ref = useRef(null);
      const mutate = () => {
        let parent = document.createElement('ul');
        let child = document.createElement('li');
        ref.current.append(parent);
        parent.appendChild(child);
        parent.remove(); // this results in a mutation record for a disconnected ul with a connected li (through the new ul parent) in `addedNodes`
        let newParent = document.createElement('ul');
        newParent.appendChild(child);
        ref.current.append(newParent);
      };

      return (
        <>
          <div data-testid="test" ref={ref}>
            <button onClick={mutate}>Mutate</button>
          </div>
        </>
      );
    };

    let {queryByRole, getAllByRole, getByTestId} = render(<Test />);

    ariaHideOutside([getByTestId('test')]);

    queryByRole('button').click();
    await Promise.resolve(); // Wait for mutation observer tick

    expect(getAllByRole('listitem')).toHaveLength(1);
  });

  it('should handle when a new element is added and then reparented to a hidden container', async function () {

    let Test = () => {
      const ref = useRef(null);
      const mutate = () => {
        let parent = document.createElement('ul');
        let child = document.createElement('li');
        ref.current.append(parent);
        parent.appendChild(child);
        parent.remove(); // this results in a mutation record for a disconnected ul with a connected li (through the new ul parent) in `addedNodes`
        let newParent = document.createElement('ul');
        newParent.appendChild(child);
        ref.current.append(newParent);
      };

      return (
        <>
          <div data-testid="test">
            <button onClick={mutate}>Mutate</button>
          </div>
          <div data-testid="sibling" ref={ref} />
        </>
      );
    };

    let {queryByRole, queryAllByRole, getByTestId} = render(<Test />);

    ariaHideOutside([getByTestId('test')]);

    queryByRole('button').click();
    await Promise.resolve(); // Wait for mutation observer tick

    expect(queryAllByRole('listitem')).toHaveLength(0);
  });


  it('work when called multiple times', function () {
    let {getByRole, getAllByRole} = render(
      <>
        <input type="checkbox" />
        <input type="radio" />
        <button>Button</button>
        <input type="radio" />
        <input type="checkbox" />
      </>
    );

    let radios = getAllByRole('radio');
    let button = getByRole('button');

    let revert1 = ariaHideOutside([button, ...radios]);

    expect(() => getAllByRole('checkbox')).toThrow();
    expect(() => getAllByRole('radio')).not.toThrow();
    expect(() => getByRole('button')).not.toThrow();

    let revert2 = ariaHideOutside([button]);

    expect(() => getAllByRole('checkbox')).toThrow();
    expect(() => getAllByRole('radio')).toThrow();
    expect(() => getByRole('button')).not.toThrow();

    revert2();

    expect(() => getAllByRole('checkbox')).toThrow();
    expect(() => getAllByRole('radio')).not.toThrow();
    expect(() => getByRole('button')).not.toThrow();

    revert1();

    expect(() => getAllByRole('checkbox')).not.toThrow();
    expect(() => getAllByRole('radio')).not.toThrow();
    expect(() => getByRole('button')).not.toThrow();
  });

  it('work when called multiple times and restored out of order', function () {
    let {getByRole, getAllByRole} = render(
      <>
        <input type="checkbox" />
        <input type="radio" />
        <button>Button</button>
        <input type="radio" />
        <input type="checkbox" />
      </>
    );

    let radios = getAllByRole('radio');
    let button = getByRole('button');

    let revert1 = ariaHideOutside([button, ...radios]);

    expect(() => getAllByRole('checkbox')).toThrow();
    expect(() => getAllByRole('radio')).not.toThrow();
    expect(() => getByRole('button')).not.toThrow();

    let revert2 = ariaHideOutside([button]);

    expect(() => getAllByRole('checkbox')).toThrow();
    expect(() => getAllByRole('radio')).toThrow();
    expect(() => getByRole('button')).not.toThrow();

    revert1();

    expect(() => getAllByRole('checkbox')).toThrow();
    expect(() => getAllByRole('radio')).toThrow();
    expect(() => getByRole('button')).not.toThrow();

    revert2();

    expect(() => getAllByRole('checkbox')).not.toThrow();
    expect(() => getAllByRole('radio')).not.toThrow();
    expect(() => getByRole('button')).not.toThrow();
  });

  it('should hide everything except the provided element [row]', function () {
    let {getAllByRole, getByTestId} = render(
      <div role="grid">
        <div role="row">
          <div role="gridcell">
            <span data-testid="test-span">
              Cell 1
            </span></div>
        </div>
        <div role="row">
          <div role="gridcell">Cell 2</div>
        </div>
      </div>
    );

    let cells = getAllByRole('gridcell');
    let rows = getAllByRole('row');
    let span = getByTestId('test-span');

    let revert = ariaHideOutside([rows[1]]);

    // Applies aria-hidden to the row and cell despite recursive nature of aria-hidden
    // for https://bugs.webkit.org/show_bug.cgi?id=222623
    expect(rows[0]).toHaveAttribute('aria-hidden', 'true');
    expect(cells[0]).toHaveAttribute('aria-hidden', 'true');
    expect(span).not.toHaveAttribute('aria-hidden');
    expect(rows[1]).not.toHaveAttribute('aria-hidden', 'true');
    expect(cells[1]).not.toHaveAttribute('aria-hidden', 'true');

    revert();

    expect(rows[0]).not.toHaveAttribute('aria-hidden', 'true');
    expect(cells[0]).not.toHaveAttribute('aria-hidden', 'true');
    expect(rows[1]).not.toHaveAttribute('aria-hidden', 'true');
    expect(cells[1]).not.toHaveAttribute('aria-hidden', 'true');
    expect(span).not.toHaveAttribute('aria-hidden');
  });

  it('should unhide after item reorder', async function () {
    function Item(props) {
      return (
        <div role="presentation">
          <div data-testid={props.testid} role="row">
            <div role="gridcell" />
          </div>
        </div>
      );
    }

    function Test() {
      let [count, setCount] = useState(0);
      let items = ['row1', 'row2', 'row3', 'row4', 'row5'];
      if (count === 1) {
        items = ['row2', 'row1', 'row3', 'row4', 'row5'];
      } else if (count === 2) {
        items = ['row2', 'row3', 'row1', 'row4', 'row5'];
      }

      return (
        <>
          <button onClick={() => setCount((old) => old + 1)}>press</button>
          {items.map((item) => <Item testid={item} key={item} />)}
        </>

      );
    }

    let {getByRole, getByTestId} = render(
      <Test />
    );

    let button = getByRole('button');
    let row = getByTestId('row1');
    let revert = ariaHideOutside([button]);

    act(() => button.click());
    await Promise.resolve();
    act(() => button.click());
    await Promise.resolve();
    revert();
    expect(row.parentElement).not.toHaveAttribute('aria-hidden', 'true');
  });
});

describe('ariaHideOutside without shadow DOM enabled', function () {
  it('does not walk or observe shadow roots', async function () {
    let host = document.createElement('div');
    document.body.appendChild(host);
    let shadowRoot = host.attachShadow({mode: 'open'});
    let target = document.createElement('button');
    let sibling = document.createElement('button');
    shadowRoot.append(target, sibling);

    let revert = ariaHideOutside([target]);
    expect(sibling).not.toHaveAttribute('aria-hidden');
    expect(target).not.toHaveAttribute('aria-hidden');

    let added = document.createElement('button');
    shadowRoot.appendChild(added);
    await Promise.resolve(); // Wait for mutation observer tick
    expect(added).not.toHaveAttribute('aria-hidden');

    revert();
    host.remove();
  });
});

describe('ariaHideOutside with Shadow DOM', function () {
  let created = [];

  let addElement = (parent, tag, attributes = {}) => {
    let element = document.createElement(tag);
    for (let [name, value] of Object.entries(attributes)) {
      element.setAttribute(name, value);
    }
    parent.appendChild(element);
    created.push(element);
    return element;
  };

  let addShadowHost = (parent = document.body) => {
    let host = addElement(parent, 'div');
    return {host, shadowRoot: host.attachShadow({mode: 'open'})};
  };

  beforeAll(function () {
    enableShadowDOM();
  });

  afterEach(function () {
    for (let element of created) {
      element.remove();
    }
    created = [];
  });

  it('hides siblings inside the shadow root of a target', function () {
    let {host, shadowRoot} = addShadowHost();
    let lightSibling = addElement(document.body, 'button');
    let container = addElement(shadowRoot, 'div');
    let target = addElement(container, 'button');
    let sibling = addElement(shadowRoot, 'button');
    let innerSibling = addElement(container, 'button');

    let revert = ariaHideOutside([target]);

    expect(sibling).toHaveAttribute('aria-hidden', 'true');
    expect(innerSibling).toHaveAttribute('aria-hidden', 'true');
    expect(lightSibling).toHaveAttribute('aria-hidden', 'true');
    expect(host).not.toHaveAttribute('aria-hidden');
    expect(container).not.toHaveAttribute('aria-hidden');
    expect(target).not.toHaveAttribute('aria-hidden');

    revert();

    expect(sibling).not.toHaveAttribute('aria-hidden');
    expect(innerSibling).not.toHaveAttribute('aria-hidden');
    expect(lightSibling).not.toHaveAttribute('aria-hidden');
  });

  it('hides siblings in every shadow root enclosing a target nested 3 levels deep', function () {
    let a = addShadowHost();
    let siblingA = addElement(a.shadowRoot, 'button');
    let b = addShadowHost(a.shadowRoot);
    let siblingB = addElement(b.shadowRoot, 'button');
    let c = addShadowHost(b.shadowRoot);
    let siblingC = addElement(c.shadowRoot, 'button');
    let target = addElement(c.shadowRoot, 'button');
    let lightSibling = addElement(document.body, 'button');

    let revert = ariaHideOutside([target]);

    expect(siblingA).toHaveAttribute('aria-hidden', 'true');
    expect(siblingB).toHaveAttribute('aria-hidden', 'true');
    expect(siblingC).toHaveAttribute('aria-hidden', 'true');
    expect(lightSibling).toHaveAttribute('aria-hidden', 'true');
    expect(a.host).not.toHaveAttribute('aria-hidden');
    expect(b.host).not.toHaveAttribute('aria-hidden');
    expect(c.host).not.toHaveAttribute('aria-hidden');
    expect(target).not.toHaveAttribute('aria-hidden');

    revert();

    expect(siblingA).not.toHaveAttribute('aria-hidden');
    expect(siblingB).not.toHaveAttribute('aria-hidden');
    expect(siblingC).not.toHaveAttribute('aria-hidden');
    expect(lightSibling).not.toHaveAttribute('aria-hidden');
  });

  it('hides siblings when the target is a direct child of a shadow root', function () {
    let {shadowRoot} = addShadowHost();
    let target = addElement(shadowRoot, 'button');
    let sibling = addElement(shadowRoot, 'button');

    let revert = ariaHideOutside([target]);

    expect(sibling).toHaveAttribute('aria-hidden', 'true');
    expect(target).not.toHaveAttribute('aria-hidden');

    revert();

    expect(sibling).not.toHaveAttribute('aria-hidden');
  });

  it('keeps an existing aria-hidden sibling in a shadow root hidden after restore', function () {
    let {shadowRoot} = addShadowHost();
    let target = addElement(shadowRoot, 'button');
    let sibling = addElement(shadowRoot, 'button', {'aria-hidden': 'true'});

    let revert = ariaHideOutside([target]);
    expect(sibling).toHaveAttribute('aria-hidden', 'true');

    revert();
    expect(sibling).toHaveAttribute('aria-hidden', 'true');
  });

  it('hides cells of a non-target row in a shadow root', function () {
    let {shadowRoot} = addShadowHost();
    let grid = addElement(shadowRoot, 'div', {role: 'grid'});
    let row1 = addElement(grid, 'div', {role: 'row'});
    let cell1 = addElement(row1, 'div', {role: 'gridcell'});
    let row2 = addElement(grid, 'div', {role: 'row'});
    let cell2 = addElement(row2, 'div', {role: 'gridcell'});

    let revert = ariaHideOutside([row2]);

    expect(row1).toHaveAttribute('aria-hidden', 'true');
    expect(cell1).toHaveAttribute('aria-hidden', 'true');
    expect(row2).not.toHaveAttribute('aria-hidden');
    expect(cell2).not.toHaveAttribute('aria-hidden');

    revert();

    expect(row1).not.toHaveAttribute('aria-hidden');
    expect(cell1).not.toHaveAttribute('aria-hidden');
  });

  it('hides elements added later to a shadow root enclosing a target', async function () {
    let a = addShadowHost();
    let target = addElement(a.shadowRoot, 'button');
    let b = addShadowHost(a.shadowRoot);
    let c = addShadowHost(b.shadowRoot);
    let deepTarget = addElement(c.shadowRoot, 'button');

    let revert = ariaHideOutside([deepTarget]);

    let added = addElement(a.shadowRoot, 'button');
    let addedNextToHost = addElement(b.host.parentNode, 'span');
    let addedInsideHost = addElement(b.host, 'button');
    let addedInDeepRoot = addElement(c.shadowRoot, 'button');
    await Promise.resolve(); // Wait for mutation observer tick

    expect(added).toHaveAttribute('aria-hidden', 'true');
    expect(addedNextToHost).toHaveAttribute('aria-hidden', 'true');
    expect(addedInsideHost).toHaveAttribute('aria-hidden', 'true');
    expect(addedInDeepRoot).toHaveAttribute('aria-hidden', 'true');
    expect(target).toHaveAttribute('aria-hidden', 'true');
    expect(b.host).not.toHaveAttribute('aria-hidden');
    expect(deepTarget).not.toHaveAttribute('aria-hidden');

    revert();
  });

  it('does not hide nodes added inside a target', async function () {
    let {shadowRoot} = addShadowHost();
    let target = addElement(shadowRoot, 'div');

    let revert = ariaHideOutside([target]);

    let added = addElement(target, 'button');
    await Promise.resolve(); // Wait for mutation observer tick

    expect(added).not.toHaveAttribute('aria-hidden');
    expect(target).not.toHaveAttribute('aria-hidden');

    revert();
  });

  it('does not add a refcount or double hide nodes added inside an already hidden shadow sibling', async function () {
    let {shadowRoot} = addShadowHost();
    let target = addElement(shadowRoot, 'button');
    let sibling = addElement(shadowRoot, 'div');

    let revert = ariaHideOutside([target]);
    expect(sibling).toHaveAttribute('aria-hidden', 'true');

    let added = addElement(sibling, 'button');
    await Promise.resolve(); // Wait for mutation observer tick

    expect(added).not.toHaveAttribute('aria-hidden');

    revert();

    expect(sibling).not.toHaveAttribute('aria-hidden');
    expect(added).not.toHaveAttribute('aria-hidden');
  });

  it('keeps live announcers and top layer elements added later in a shadow root visible', async function () {
    let {shadowRoot} = addShadowHost();
    let target = addElement(shadowRoot, 'button');

    let revert = ariaHideOutside([target]);

    let announcer = addElement(shadowRoot, 'div', {'data-live-announcer': 'true'});
    let topLayer = addElement(shadowRoot, 'div', {'data-react-aria-top-layer': 'true'});
    let sibling = addElement(shadowRoot, 'button');
    await Promise.resolve(); // Wait for mutation observer tick

    expect(announcer).not.toHaveAttribute('aria-hidden');
    expect(topLayer).not.toHaveAttribute('aria-hidden');
    expect(sibling).toHaveAttribute('aria-hidden', 'true');

    revert();
  });

  it('keeps live announcers and top layer elements present at call time in a shadow root visible', function () {
    let {shadowRoot} = addShadowHost();
    let target = addElement(shadowRoot, 'button');
    let announcer = addElement(shadowRoot, 'div', {'data-live-announcer': 'true'});
    let topLayer = addElement(shadowRoot, 'div', {'data-react-aria-top-layer': 'true'});
    let sibling = addElement(shadowRoot, 'button');

    let revert = ariaHideOutside([target]);

    expect(announcer).not.toHaveAttribute('aria-hidden');
    expect(topLayer).not.toHaveAttribute('aria-hidden');
    expect(sibling).toHaveAttribute('aria-hidden', 'true');

    revert();
  });

  it('hides siblings of targets in different shadow roots and additions to both roots', async function () {
    let a = addShadowHost();
    let b = addShadowHost();
    let input = addElement(a.shadowRoot, 'input');
    let aSibling = addElement(a.shadowRoot, 'button');
    let popover = addElement(b.shadowRoot, 'div');
    let bSibling = addElement(b.shadowRoot, 'button');
    let lightSibling = addElement(document.body, 'button');

    let revert = ariaHideOutside([input, popover]);

    expect(input).not.toHaveAttribute('aria-hidden');
    expect(popover).not.toHaveAttribute('aria-hidden');
    expect(a.host).not.toHaveAttribute('aria-hidden');
    expect(b.host).not.toHaveAttribute('aria-hidden');
    expect(aSibling).toHaveAttribute('aria-hidden', 'true');
    expect(bSibling).toHaveAttribute('aria-hidden', 'true');
    expect(lightSibling).toHaveAttribute('aria-hidden', 'true');

    let aAdded = addElement(a.shadowRoot, 'button');
    let bAdded = addElement(b.shadowRoot, 'button');
    await Promise.resolve(); // Wait for mutation observer tick

    expect(aAdded).toHaveAttribute('aria-hidden', 'true');
    expect(bAdded).toHaveAttribute('aria-hidden', 'true');

    revert();
  });

  it('handles a light DOM target and a shadow root target together', function () {
    let lightTarget = addElement(document.body, 'button');
    let {host, shadowRoot} = addShadowHost();
    let shadowTarget = addElement(shadowRoot, 'button');
    let shadowSibling = addElement(shadowRoot, 'button');
    let lightSibling = addElement(document.body, 'button');

    let revert = ariaHideOutside([lightTarget, shadowTarget]);

    expect(lightTarget).not.toHaveAttribute('aria-hidden');
    expect(shadowTarget).not.toHaveAttribute('aria-hidden');
    expect(host).not.toHaveAttribute('aria-hidden');
    expect(shadowSibling).toHaveAttribute('aria-hidden', 'true');
    expect(lightSibling).toHaveAttribute('aria-hidden', 'true');

    revert();

    expect(shadowSibling).not.toHaveAttribute('aria-hidden');
    expect(lightSibling).not.toHaveAttribute('aria-hidden');
  });

  it('restores all shadow root elements and stops observing them on cleanup', async function () {
    let {shadowRoot} = addShadowHost();
    let target = addElement(shadowRoot, 'button');
    let sibling = addElement(shadowRoot, 'button');
    let lightSibling = addElement(document.body, 'button');

    let revert = ariaHideOutside([target]);
    expect(sibling).toHaveAttribute('aria-hidden', 'true');

    revert();

    expect(sibling).not.toHaveAttribute('aria-hidden');
    expect(lightSibling).not.toHaveAttribute('aria-hidden');

    let added = addElement(shadowRoot, 'button');
    await Promise.resolve(); // Wait for mutation observer tick

    expect(added).not.toHaveAttribute('aria-hidden');
  });

  it('keeps shadow root content hidden by the outer call after a nested call is cleaned up', async function () {
    let {shadowRoot} = addShadowHost();
    let outerTarget = addElement(shadowRoot, 'button');
    let innerTarget = addElement(shadowRoot, 'button');
    let sibling = addElement(shadowRoot, 'button');

    let revertOuter = ariaHideOutside([outerTarget]);
    let revertInner = ariaHideOutside([innerTarget]);
    expect(sibling).toHaveAttribute('aria-hidden', 'true');

    revertInner();

    expect(sibling).toHaveAttribute('aria-hidden', 'true');
    let added = addElement(shadowRoot, 'button');
    await Promise.resolve(); // Wait for mutation observer tick
    expect(added).toHaveAttribute('aria-hidden', 'true');

    revertOuter();

    expect(sibling).not.toHaveAttribute('aria-hidden');
    expect(added).not.toHaveAttribute('aria-hidden');
    expect(innerTarget).not.toHaveAttribute('aria-hidden');
  });

  it('keeps an element in a shadow root visible when kept visible', async function () {
    let {shadowRoot} = addShadowHost();
    let target = addElement(shadowRoot, 'button');

    let revert = ariaHideOutside([target]);

    let popover = document.createElement('div');
    created.push(popover);
    let removeKeepVisible = keepVisible(popover);
    shadowRoot.appendChild(popover);
    await Promise.resolve(); // Wait for mutation observer tick

    expect(popover).not.toHaveAttribute('aria-hidden');

    removeKeepVisible();
    revert();
  });

  it('uses the inert mechanism for shadow root elements when supported', function () {
    let {shadowRoot} = addShadowHost();
    let target = addElement(shadowRoot, 'button');
    let sibling = addElement(shadowRoot, 'button');

    let revert = ariaHideOutside([target], {shouldUseInert: true});

    // jsdom does not implement inert, in which case aria-hidden is used instead.
    if ('inert' in HTMLElement.prototype) {
      expect(sibling.inert).toBe(true);
      expect(sibling).not.toHaveAttribute('aria-hidden');
    } else {
      expect(sibling).toHaveAttribute('aria-hidden', 'true');
    }
    expect(target).not.toHaveAttribute('aria-hidden');

    revert();

    expect(sibling).not.toHaveAttribute('aria-hidden');
  });

  it('does not hide elements in a shadow root enclosing the root option', function () {
    let {shadowRoot} = addShadowHost();
    let outside = addElement(shadowRoot, 'button');
    let root = addElement(shadowRoot, 'div');
    let target = addElement(root, 'button');

    let revert = ariaHideOutside([target], {root});

    expect(outside).not.toHaveAttribute('aria-hidden');
    expect(root).not.toHaveAttribute('aria-hidden');
    expect(target).not.toHaveAttribute('aria-hidden');

    revert();
  });

  it('hides siblings in a shadow root nested inside the root option', function () {
    let root = addElement(document.body, 'div');
    let lightSibling = addElement(document.body, 'button');
    let nested = addShadowHost(root);
    let sibling = addElement(nested.shadowRoot, 'button');
    let target = addElement(nested.shadowRoot, 'button');

    let revert = ariaHideOutside([target], {root});

    expect(sibling).toHaveAttribute('aria-hidden', 'true');
    expect(nested.host).not.toHaveAttribute('aria-hidden');
    expect(target).not.toHaveAttribute('aria-hidden');
    expect(lightSibling).not.toHaveAttribute('aria-hidden');

    revert();

    expect(sibling).not.toHaveAttribute('aria-hidden');
  });

  it('does not hide light DOM children slotted into a visible node', async function () {
    let {host, shadowRoot} = addShadowHost();
    let pop = addElement(shadowRoot, 'div');
    addElement(pop, 'slot');
    let slotted = addElement(host, 'button');
    let lightSibling = addElement(document.body, 'button');

    let revert = ariaHideOutside([pop]);

    expect(slotted).not.toHaveAttribute('aria-hidden');
    expect(host).not.toHaveAttribute('aria-hidden');
    expect(lightSibling).toHaveAttribute('aria-hidden', 'true');

    let added = addElement(host, 'button');
    await Promise.resolve(); // Wait for mutation observer tick

    expect(added).not.toHaveAttribute('aria-hidden');

    let nested = addElement(slotted, 'span');
    await Promise.resolve(); // Wait for mutation observer tick

    expect(nested).not.toHaveAttribute('aria-hidden');

    revert();

    expect(slotted).not.toHaveAttribute('aria-hidden');
    expect(lightSibling).not.toHaveAttribute('aria-hidden');
  });
});

/*
 * Copyright 2020 Adobe. All rights reserved.
 * This file is licensed to you under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License. You may obtain a copy
 * of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software distributed under
 * the License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR REPRESENTATIONS
 * OF ANY KIND, either express or implied. See the License for the specific language
 * governing permissions and limitations under the License.
 */

import {act, createShadowRoot, render, waitFor} from '@react-spectrum/test-utils-internal';
import {ariaHideOutside} from '../src';
import {enableShadowDOM} from '@react-stately/flags';
import {keepVisible} from '../src/ariaHideOutside';
import React, {useRef, useState} from 'react';

describe('ariaHideOutside', function () {
  it('should hide everything except the provided element [button]', function () {
    let {getByRole, getAllByRole} = render(
      <>
        <input type="checkbox" />
        <button>Button</button>
        <input type="checkbox" />
      </>
    );

    let checkboxes = getAllByRole('checkbox');
    let button = getByRole('button');

    let revert = ariaHideOutside([button]);

    expect(checkboxes[0]).toHaveAttribute('aria-hidden', 'true');
    expect(checkboxes[1]).toHaveAttribute('aria-hidden', 'true');
    expect(button).not.toHaveAttribute('aria-hidden');

    expect(() => getAllByRole('checkbox')).toThrow();
    expect(() => getByRole('button')).not.toThrow();

    revert();

    expect(checkboxes[0]).not.toHaveAttribute('aria-hidden');
    expect(checkboxes[1]).not.toHaveAttribute('aria-hidden');
    expect(button).not.toHaveAttribute('aria-hidden');

    expect(() => getAllByRole('checkbox')).not.toThrow();
    expect(() => getByRole('button')).not.toThrow();
  });

  it('should hide everything except multiple elements', function () {
    let {getByRole, getAllByRole, queryByRole, queryAllByRole} = render(
      <>
        <input type="checkbox" />
        <button>Button</button>
        <input type="checkbox" />
      </>
    );

    let checkboxes = getAllByRole('checkbox');
    let button = getByRole('button');

    let revert = ariaHideOutside(checkboxes);

    expect(checkboxes[0]).not.toHaveAttribute('aria-hidden', 'true');
    expect(checkboxes[1]).not.toHaveAttribute('aria-hidden', 'true');
    expect(button).toHaveAttribute('aria-hidden');

    expect(queryAllByRole('checkbox')).not.toBeNull();
    expect(queryByRole('button')).toBeNull();

    revert();

    expect(checkboxes[0]).not.toHaveAttribute('aria-hidden');
    expect(checkboxes[1]).not.toHaveAttribute('aria-hidden');
    expect(button).not.toHaveAttribute('aria-hidden');

    expect(() => getAllByRole('checkbox')).not.toThrow();
    expect(() => getByRole('button')).not.toThrow();
  });

  it('should not traverse into an already hidden container', function () {
    let {getByRole, getAllByRole} = render(
      <>
        <div>
          <input type="checkbox" />
        </div>
        <button>Button</button>
        <input type="checkbox" />
      </>
    );

    let checkboxes = getAllByRole('checkbox');
    let button = getByRole('button');

    let revert = ariaHideOutside([button]);

    expect(checkboxes[0].parentElement).toHaveAttribute('aria-hidden', 'true');
    expect(checkboxes[1]).toHaveAttribute('aria-hidden', 'true');
    expect(button).not.toHaveAttribute('aria-hidden');

    expect(() => getAllByRole('checkbox')).toThrow();
    expect(() => getByRole('button')).not.toThrow();

    revert();

    expect(checkboxes[0].parentElement).not.toHaveAttribute('aria-hidden');
    expect(checkboxes[1]).not.toHaveAttribute('aria-hidden');
    expect(button).not.toHaveAttribute('aria-hidden');

    expect(() => getAllByRole('checkbox')).not.toThrow();
    expect(() => getByRole('button')).not.toThrow();
  });

  it('should not overwrite an existing aria-hidden prop', function () {
    let {getByRole, getAllByRole} = render(
      <>
        <input type="checkbox" aria-hidden="true" />
        <button>Button</button>
        <input type="checkbox" />
      </>
    );

    let checkboxes = getAllByRole('checkbox');
    let button = getByRole('button');

    let revert = ariaHideOutside([button]);

    expect(checkboxes).toHaveLength(1);
    expect(checkboxes[0]).toHaveAttribute('aria-hidden', 'true');
    expect(button).not.toHaveAttribute('aria-hidden');

    expect(() => getAllByRole('checkbox')).toThrow();
    expect(() => getByRole('button')).not.toThrow();

    revert();

    checkboxes = getAllByRole('checkbox');
    expect(checkboxes).toHaveLength(1);
    expect(checkboxes[0]).not.toHaveAttribute('aria-hidden');
    expect(button).not.toHaveAttribute('aria-hidden');

    expect(() => getAllByRole('checkbox')).not.toThrow();
    expect(() => getByRole('button')).not.toThrow();
  });

  it('should handle when a new element is added outside while active', async function () {
    let Test = props => (
      <>
        {props.show && <input type="checkbox" />}
        <button>Button</button>
        {props.show && <input type="checkbox" />}
      </>
    );

    let {getByRole, getAllByRole, rerender} = render(<Test />);

    let button = getByRole('button');
    expect(() => getAllByRole('checkbox')).toThrow();

    let revert = ariaHideOutside([button]);

    rerender(<Test show />);

    // MutationObserver is async
    await waitFor(() => expect(() => getAllByRole('checkbox')).toThrow());
    expect(() => getByRole('button')).not.toThrow();

    revert();

    expect(getAllByRole('checkbox')).toHaveLength(2);
  });

  it('should handle when a new element is added to an already hidden container', async function () {
    let Test = props => (
      <>
        <div data-testid="test">
          {props.show && <input type="checkbox" />}
        </div>
        <button>Button</button>
        {props.show && <input type="checkbox" />}
      </>
    );

    let {getByRole, getAllByRole, getByTestId, rerender} = render(<Test />);

    let button = getByRole('button');
    let test = getByTestId('test');
    expect(() => getAllByRole('checkbox')).toThrow();

    let revert = ariaHideOutside([button]);

    expect(test).toHaveAttribute('aria-hidden');

    rerender(<Test show />);

    // MutationObserver is async
    await waitFor(() => expect(() => getAllByRole('checkbox')).toThrow());
    expect(() => getByRole('button')).not.toThrow();

    let checkboxes = getAllByRole('checkbox', {hidden: true});
    expect(test).toHaveAttribute('aria-hidden');
    expect(checkboxes[0]).not.toHaveAttribute('aria-hidden');
    expect(checkboxes[1]).toHaveAttribute('aria-hidden', 'true');

    revert();

    expect(getAllByRole('checkbox')).toHaveLength(2);
  });

  it('should handle when a new element is added along with a top layer element', async function () {
    let Test = props => (
      <>
        <button>Button</button>
        {props.show && <div>
          <div role="alert" data-react-aria-top-layer="true">Top layer</div>
          <input type="checkbox" />
        </div>}
      </>
    );

    let {getByRole, queryByRole, getAllByRole, rerender} = render(<Test />);

    let button = getByRole('button');
    expect(queryByRole('checkbox')).toBeNull();

    let revert = ariaHideOutside([button]);

    rerender(<Test show />);

    // MutationObserver is async
    await waitFor(() => queryByRole('checkbox') == null);
    expect(queryByRole('button')).not.toBeNull();
    expect(getByRole('alert')).toHaveTextContent('Top layer');

    revert();

    expect(getAllByRole('checkbox')).toHaveLength(1);
  });

  it('should handle when a new element is added inside a target element', async function () {
    let Test = props => (
      <>
        <input type="checkbox" />
        <div data-testid="test">
          <button>Button</button>
          {props.show && <input type="radio" />}
        </div>
        <input type="checkbox" />
      </>
    );

    let {queryByRole, getByRole, getAllByRole, getByTestId, rerender} = render(<Test />);

    let test = getByTestId('test');
    let revert = ariaHideOutside([test]);

    expect(() => getAllByRole('checkbox')).toThrow();
    expect(queryByRole('radio')).toBeNull();
    expect(queryByRole('button')).not.toBeNull();
    expect(() => getByTestId('test')).not.toThrow();

    rerender(<Test show />);

    // Wait for mutation observer tick
    await Promise.resolve();
    expect(() => getAllByRole('checkbox')).toThrow();
    expect(() => getByRole('radio')).not.toThrow();
    expect(() => getByRole('button')).not.toThrow();
    expect(() => getByTestId('test')).not.toThrow();

    revert();

    expect(() => getAllByRole('checkbox')).not.toThrow();
    expect(() => getByRole('radio')).not.toThrow();
    expect(() => getByRole('button')).not.toThrow();
    expect(() => getByTestId('test')).not.toThrow();
  });

  it('should handle when a new element is added and then reparented', async function () {

    let Test = () => {
      const ref = useRef(null);
      const mutate = () => {
        let parent = document.createElement('ul');
        let child = document.createElement('li');
        ref.current.append(parent);
        parent.appendChild(child);
        parent.remove(); // this results in a mutation record for a disconnected ul with a connected li (through the new ul parent) in `addedNodes`
        let newParent = document.createElement('ul');
        newParent.appendChild(child);
        ref.current.append(newParent);
      };

      return (
        <>
          <div data-testid="test" ref={ref}>
            <button onClick={mutate}>Mutate</button>
          </div>
        </>
      );
    };

    let {queryByRole, getAllByRole, getByTestId} = render(<Test />);

    ariaHideOutside([getByTestId('test')]);

    queryByRole('button').click();
    await Promise.resolve(); // Wait for mutation observer tick

    expect(getAllByRole('listitem')).toHaveLength(1);
  });

  it('should handle when a new element is added and then reparented to a hidden container', async function () {

    let Test = () => {
      const ref = useRef(null);
      const mutate = () => {
        let parent = document.createElement('ul');
        let child = document.createElement('li');
        ref.current.append(parent);
        parent.appendChild(child);
        parent.remove(); // this results in a mutation record for a disconnected ul with a connected li (through the new ul parent) in `addedNodes`
        let newParent = document.createElement('ul');
        newParent.appendChild(child);
        ref.current.append(newParent);
      };

      return (
        <>
          <div data-testid="test">
            <button onClick={mutate}>Mutate</button>
          </div>
          <div data-testid="sibling" ref={ref} />
        </>
      );
    };

    let {queryByRole, queryAllByRole, getByTestId} = render(<Test />);

    ariaHideOutside([getByTestId('test')]);

    queryByRole('button').click();
    await Promise.resolve(); // Wait for mutation observer tick

    expect(queryAllByRole('listitem')).toHaveLength(0);
  });


  it('work when called multiple times', function () {
    let {getByRole, getAllByRole} = render(
      <>
        <input type="checkbox" />
        <input type="radio" />
        <button>Button</button>
        <input type="radio" />
        <input type="checkbox" />
      </>
    );

    let radios = getAllByRole('radio');
    let button = getByRole('button');

    let revert1 = ariaHideOutside([button, ...radios]);

    expect(() => getAllByRole('checkbox')).toThrow();
    expect(() => getAllByRole('radio')).not.toThrow();
    expect(() => getByRole('button')).not.toThrow();

    let revert2 = ariaHideOutside([button]);

    expect(() => getAllByRole('checkbox')).toThrow();
    expect(() => getAllByRole('radio')).toThrow();
    expect(() => getByRole('button')).not.toThrow();

    revert2();

    expect(() => getAllByRole('checkbox')).toThrow();
    expect(() => getAllByRole('radio')).not.toThrow();
    expect(() => getByRole('button')).not.toThrow();

    revert1();

    expect(() => getAllByRole('checkbox')).not.toThrow();
    expect(() => getAllByRole('radio')).not.toThrow();
    expect(() => getByRole('button')).not.toThrow();
  });

  it('work when called multiple times and restored out of order', function () {
    let {getByRole, getAllByRole} = render(
      <>
        <input type="checkbox" />
        <input type="radio" />
        <button>Button</button>
        <input type="radio" />
        <input type="checkbox" />
      </>
    );

    let radios = getAllByRole('radio');
    let button = getByRole('button');

    let revert1 = ariaHideOutside([button, ...radios]);

    expect(() => getAllByRole('checkbox')).toThrow();
    expect(() => getAllByRole('radio')).not.toThrow();
    expect(() => getByRole('button')).not.toThrow();

    let revert2 = ariaHideOutside([button]);

    expect(() => getAllByRole('checkbox')).toThrow();
    expect(() => getAllByRole('radio')).toThrow();
    expect(() => getByRole('button')).not.toThrow();

    revert1();

    expect(() => getAllByRole('checkbox')).toThrow();
    expect(() => getAllByRole('radio')).toThrow();
    expect(() => getByRole('button')).not.toThrow();

    revert2();

    expect(() => getAllByRole('checkbox')).not.toThrow();
    expect(() => getAllByRole('radio')).not.toThrow();
    expect(() => getByRole('button')).not.toThrow();
  });

  it('should hide everything except the provided element [row]', function () {
    let {getAllByRole, getByTestId} = render(
      <div role="grid">
        <div role="row">
          <div role="gridcell">
            <span data-testid="test-span">
              Cell 1
            </span></div>
        </div>
        <div role="row">
          <div role="gridcell">Cell 2</div>
        </div>
      </div>
    );

    let cells = getAllByRole('gridcell');
    let rows = getAllByRole('row');
    let span = getByTestId('test-span');

    let revert = ariaHideOutside([rows[1]]);

    // Applies aria-hidden to the row and cell despite recursive nature of aria-hidden
    // for https://bugs.webkit.org/show_bug.cgi?id=222623
    expect(rows[0]).toHaveAttribute('aria-hidden', 'true');
    expect(cells[0]).toHaveAttribute('aria-hidden', 'true');
    expect(span).not.toHaveAttribute('aria-hidden');
    expect(rows[1]).not.toHaveAttribute('aria-hidden', 'true');
    expect(cells[1]).not.toHaveAttribute('aria-hidden', 'true');

    revert();

    expect(rows[0]).not.toHaveAttribute('aria-hidden', 'true');
    expect(cells[0]).not.toHaveAttribute('aria-hidden', 'true');
    expect(rows[1]).not.toHaveAttribute('aria-hidden', 'true');
    expect(cells[1]).not.toHaveAttribute('aria-hidden', 'true');
    expect(span).not.toHaveAttribute('aria-hidden');
  });

  it('should unhide after item reorder', async function () {
    function Item(props) {
      return (
        <div role="presentation">
          <div data-testid={props.testid} role="row">
            <div role="gridcell" />
          </div>
        </div>
      );
    }

    function Test() {
      let [count, setCount] = useState(0);
      let items = ['row1', 'row2', 'row3', 'row4', 'row5'];
      if (count === 1) {
        items = ['row2', 'row1', 'row3', 'row4', 'row5'];
      } else if (count === 2) {
        items = ['row2', 'row3', 'row1', 'row4', 'row5'];
      }

      return (
        <>
          <button onClick={() => setCount((old) => old + 1)}>press</button>
          {items.map((item) => <Item testid={item} key={item} />)}
        </>

      );
    }

    let {getByRole, getByTestId} = render(
      <Test />
    );

    let button = getByRole('button');
    let row = getByTestId('row1');
    let revert = ariaHideOutside([button]);

    act(() => button.click());
    await Promise.resolve();
    act(() => button.click());
    await Promise.resolve();
    revert();
    expect(row.parentElement).not.toHaveAttribute('aria-hidden', 'true');
  });

  // Runs before the shadow DOM block below calls enableShadowDOM(), so it documents the flag-off behavior.
  it('does not hide siblings inside a target shadow root when shadow DOM is off', function () {
    let {shadowRoot, cleanup} = createShadowRoot();
    let sibling = document.createElement('button');
    let target = document.createElement('input');
    shadowRoot.append(sibling, target);

    let revert = ariaHideOutside([target]);

    expect(sibling).not.toHaveAttribute('aria-hidden');
    expect(target).not.toHaveAttribute('aria-hidden');

    revert();
    cleanup();
  });
});

describe('ariaHideOutside with shadow DOM', function () {
  let cleanups = [];

  beforeAll(function () {
    enableShadowDOM();
  });

  afterEach(function () {
    for (let cleanup of [...cleanups].reverse()) {
      cleanup();
    }
    cleanups = [];
  });

  // Creates a shadow host inside attachTo (document.body by default) and tracks it for cleanup.
  let createHost = (attachTo) => {
    let {shadowHost, shadowRoot, cleanup} = createShadowRoot(attachTo);
    cleanups.push(cleanup);
    return {shadowHost, shadowRoot};
  };

  let append = (parent, tag = 'button') => {
    let element = document.createElement(tag);
    parent.appendChild(element);
    return element;
  };

  // Light DOM element that is removed after the test.
  let createLight = (tag) => {
    let element = append(document.body, tag);
    cleanups.push(() => element.remove());
    return element;
  };

  let flush = () => new Promise(resolve => setTimeout(resolve, 0));

  // body > [light, hostA > #shadowA > [siblingA, hostB > #shadowB > [siblingB, target]]]
  let createNestedFixture = () => {
    let light = createLight();
    let outer = createHost();
    let siblingA = append(outer.shadowRoot);
    let inner = createHost(outer.shadowRoot);
    let siblingB = append(inner.shadowRoot);
    let target = append(inner.shadowRoot, 'input');
    return {light, outer, inner, siblingA, siblingB, target};
  };

  it('hides siblings in the shadow root and the light DOM and keeps the host and target visible', function () {
    let light = createLight();
    let {shadowHost, shadowRoot} = createHost();
    let sibling = append(shadowRoot);
    let target = append(shadowRoot, 'input');

    let revert = ariaHideOutside([target]);

    expect(light).toHaveAttribute('aria-hidden', 'true');
    expect(sibling).toHaveAttribute('aria-hidden', 'true');
    expect(shadowHost).not.toHaveAttribute('aria-hidden');
    expect(target).not.toHaveAttribute('aria-hidden');

    revert();
  });

  it('hides siblings at every shadow level for a target two shadow levels deep', function () {
    let {light, outer, inner, siblingA, siblingB, target} = createNestedFixture();

    let revert = ariaHideOutside([target]);

    expect(light).toHaveAttribute('aria-hidden', 'true');
    expect(siblingA).toHaveAttribute('aria-hidden', 'true');
    expect(siblingB).toHaveAttribute('aria-hidden', 'true');
    expect(outer.shadowHost).not.toHaveAttribute('aria-hidden');
    expect(inner.shadowHost).not.toHaveAttribute('aria-hidden');
    expect(target).not.toHaveAttribute('aria-hidden');

    revert();
    expect(light).not.toHaveAttribute('aria-hidden');
    expect(siblingA).not.toHaveAttribute('aria-hidden');
    expect(siblingB).not.toHaveAttribute('aria-hidden');
  });

  describe('with shouldUseInert', function () {
    let ariaHideOutsideWithInert;

    beforeAll(function () {
      // jsdom does not implement inert, and the module checks for it on import, so define it and load a fresh copy.
      Object.defineProperty(HTMLElement.prototype, 'inert', {configurable: true, writable: true, value: false});
      jest.isolateModules(() => {
        require('@react-stately/flags').enableShadowDOM();
        ariaHideOutsideWithInert = require('../src/ariaHideOutside').ariaHideOutside;
      });
    });

    afterAll(function () {
      delete HTMLElement.prototype.inert;
    });

    it('uses inert instead of aria-hidden for shadow siblings', function () {
      let {light, outer, inner, siblingA, siblingB, target} = createNestedFixture();

      let revert = ariaHideOutsideWithInert([target], {shouldUseInert: true});

      expect(light.inert).toBe(true);
      expect(siblingA.inert).toBe(true);
      expect(siblingB.inert).toBe(true);
      expect(outer.shadowHost.inert).toBe(false);
      expect(inner.shadowHost.inert).toBe(false);
      expect(target.inert).toBe(false);
      expect(siblingA).not.toHaveAttribute('aria-hidden');

      revert();
      expect(siblingA.inert).toBe(false);
    });
  });

  it('keeps the shadow content of a target host visible', function () {
    let light = createLight();
    let {shadowHost, shadowRoot} = createHost();
    let content = append(shadowRoot);

    let revert = ariaHideOutside([shadowHost]);

    expect(light).toHaveAttribute('aria-hidden', 'true');
    expect(shadowHost).not.toHaveAttribute('aria-hidden');
    expect(content).not.toHaveAttribute('aria-hidden');

    revert();
  });

  it('hides elements added later to the target shadow root, enclosing shadow roots, and the light DOM', async function () {
    let {outer, inner, target} = createNestedFixture();

    let revert = ariaHideOutside([target]);

    let addedInner = append(inner.shadowRoot);
    let addedOuter = append(outer.shadowRoot);
    let addedLight = createLight();
    await waitFor(() => {
      expect(addedInner).toHaveAttribute('aria-hidden', 'true');
      expect(addedOuter).toHaveAttribute('aria-hidden', 'true');
      expect(addedLight).toHaveAttribute('aria-hidden', 'true');
    });
    expect(target).not.toHaveAttribute('aria-hidden');

    revert();
  });

  it('keeps elements added inside a target visible', async function () {
    let {shadowRoot} = createHost();
    let target = append(shadowRoot, 'div');

    let revert = ariaHideOutside([target]);

    let inside = append(target);
    let outside = append(shadowRoot);
    await waitFor(() => expect(outside).toHaveAttribute('aria-hidden', 'true'));
    expect(inside).not.toHaveAttribute('aria-hidden');

    revert();
  });

  it('hides an element added directly to a shadow root', async function () {
    let {shadowRoot} = createHost();
    let target = append(shadowRoot);

    let revert = ariaHideOutside([target]);

    let added = document.createElement('button');
    shadowRoot.appendChild(added);

    await waitFor(() => expect(added).toHaveAttribute('aria-hidden', 'true'));
    expect(target).not.toHaveAttribute('aria-hidden');

    revert();
  });

  it('does not hide elements added inside a shadow host that is already hidden', async function () {
    let {shadowRoot} = createHost();
    let target = append(shadowRoot, 'input');
    let hiddenHost = append(shadowRoot, 'div');
    let hiddenShadow = createHost(hiddenHost);

    let revert = ariaHideOutside([target]);
    expect(hiddenHost).toHaveAttribute('aria-hidden', 'true');

    let child = append(hiddenHost);
    let sentinel = append(shadowRoot);
    await waitFor(() => expect(sentinel).toHaveAttribute('aria-hidden', 'true'));
    expect(child).not.toHaveAttribute('aria-hidden');

    let grandchild = append(hiddenShadow.shadowRoot);
    await flush();
    expect(grandchild).not.toHaveAttribute('aria-hidden');

    revert();
  });

  it('keeps live announcers and top layer elements added later visible in target and enclosing shadow roots', async function () {
    let {outer, inner, target} = createNestedFixture();

    let revert = ariaHideOutside([target]);

    let announcer = append(inner.shadowRoot, 'div');
    announcer.dataset.liveAnnouncer = 'true';
    let topLayer = append(outer.shadowRoot, 'div');
    topLayer.dataset.reactAriaTopLayer = 'true';
    let sentinel = append(outer.shadowRoot);
    await waitFor(() => expect(sentinel).toHaveAttribute('aria-hidden', 'true'));
    expect(announcer).not.toHaveAttribute('aria-hidden');
    expect(topLayer).not.toHaveAttribute('aria-hidden');

    revert();
  });

  it('keeps live announcers and top layer elements present before the call visible in a shadow root', function () {
    let {shadowRoot} = createHost();
    let target = append(shadowRoot, 'input');
    let sibling = append(shadowRoot);
    let wrapper = append(shadowRoot, 'div');
    let announcer = append(wrapper, 'div');
    announcer.dataset.liveAnnouncer = 'true';
    let topLayer = append(shadowRoot, 'div');
    topLayer.dataset.reactAriaTopLayer = 'true';

    let revert = ariaHideOutside([target]);

    expect(sibling).toHaveAttribute('aria-hidden', 'true');
    expect(announcer).not.toHaveAttribute('aria-hidden');
    expect(topLayer).not.toHaveAttribute('aria-hidden');

    revert();
  });

  it('keeps targets in different shadow roots and their hosts visible', async function () {
    let light = createLight();
    let hostA = createHost();
    let siblingA = append(hostA.shadowRoot);
    let inputA = append(hostA.shadowRoot, 'input');
    let hostB = createHost();
    let siblingB = append(hostB.shadowRoot);
    let popover = append(hostB.shadowRoot, 'div');

    let revert = ariaHideOutside([inputA, popover]);

    expect(light).toHaveAttribute('aria-hidden', 'true');
    expect(siblingA).toHaveAttribute('aria-hidden', 'true');
    expect(siblingB).toHaveAttribute('aria-hidden', 'true');
    expect(hostA.shadowHost).not.toHaveAttribute('aria-hidden');
    expect(hostB.shadowHost).not.toHaveAttribute('aria-hidden');
    expect(inputA).not.toHaveAttribute('aria-hidden');
    expect(popover).not.toHaveAttribute('aria-hidden');

    let addedA = append(hostA.shadowRoot);
    let addedB = append(hostB.shadowRoot);
    await waitFor(() => {
      expect(addedA).toHaveAttribute('aria-hidden', 'true');
      expect(addedB).toHaveAttribute('aria-hidden', 'true');
    });

    revert();
  });

  it('restores every hidden element and stops observing shadow roots on revert', async function () {
    let {light, outer, inner, siblingA, siblingB, target} = createNestedFixture();

    let revert = ariaHideOutside([target]);
    expect(light).toHaveAttribute('aria-hidden', 'true');
    expect(siblingA).toHaveAttribute('aria-hidden', 'true');
    expect(siblingB).toHaveAttribute('aria-hidden', 'true');
    revert();

    expect(light).not.toHaveAttribute('aria-hidden');
    expect(siblingA).not.toHaveAttribute('aria-hidden');
    expect(siblingB).not.toHaveAttribute('aria-hidden');

    let addedInner = append(inner.shadowRoot);
    let addedOuter = append(outer.shadowRoot);
    await flush();
    expect(addedInner).not.toHaveAttribute('aria-hidden');
    expect(addedOuter).not.toHaveAttribute('aria-hidden');
  });

  it('re-observes the first call shadow roots when a nested call is reverted', async function () {
    let {outer, target} = createNestedFixture();
    let lightTarget = createLight('input');

    let revertFirst = ariaHideOutside([target]);
    let revertSecond = ariaHideOutside([lightTarget]);

    let addedWhileNested = append(outer.shadowRoot);
    await flush();
    expect(addedWhileNested).not.toHaveAttribute('aria-hidden');

    revertSecond();
    let addedAfter = append(outer.shadowRoot);
    await waitFor(() => expect(addedAfter).toHaveAttribute('aria-hidden', 'true'));

    revertFirst();
  });

  it('keeps aria-hidden on a shadow sibling that already had it after revert', function () {
    let {shadowRoot} = createHost();
    let sibling = append(shadowRoot);
    sibling.setAttribute('aria-hidden', 'true');
    let other = append(shadowRoot);
    let target = append(shadowRoot, 'input');

    let revert = ariaHideOutside([target]);
    expect(other).toHaveAttribute('aria-hidden', 'true');
    revert();

    expect(other).not.toHaveAttribute('aria-hidden');
    expect(sibling).toHaveAttribute('aria-hidden', 'true');
  });

  it('does not throw on revert when a target was removed', function () {
    let {siblingA, siblingB, target} = createNestedFixture();

    let revert = ariaHideOutside([target]);
    expect(siblingA).toHaveAttribute('aria-hidden', 'true');
    target.remove();

    expect(() => revert()).not.toThrow();
    expect(siblingA).not.toHaveAttribute('aria-hidden');
    expect(siblingB).not.toHaveAttribute('aria-hidden');
  });

  it('keeps an element kept visible with keepVisible visible when added to a shadow root', async function () {
    let {shadowRoot} = createHost();
    let target = append(shadowRoot, 'input');

    let revert = ariaHideOutside([target]);

    let kept = document.createElement('button');
    keepVisible(kept);
    shadowRoot.appendChild(kept);
    let sibling = append(shadowRoot);
    await waitFor(() => expect(sibling).toHaveAttribute('aria-hidden', 'true'));
    expect(kept).not.toHaveAttribute('aria-hidden');

    revert();
  });

  it('does not give elements inside a shadow host within a hidden container their own aria-hidden', function () {
    let target = append(document.body, 'input');
    cleanups.push(() => target.remove());
    let container = append(document.body, 'div');
    cleanups.push(() => container.remove());
    let {shadowHost, shadowRoot} = createHost(container);
    let button = append(shadowRoot);

    let revert = ariaHideOutside([target]);
    expect(container).toHaveAttribute('aria-hidden', 'true');
    expect(shadowHost).not.toHaveAttribute('aria-hidden');
    expect(button).not.toHaveAttribute('aria-hidden');

    revert();
  });

  it('does not give elements inside a shadow host that is a light child of a hidden host their own aria-hidden', function () {
    let target = append(document.body, 'input');
    cleanups.push(() => target.remove());
    let {shadowHost} = createHost();
    let lightChild = append(shadowHost, 'div');
    let nestedShadow = createHost(lightChild);
    let button = append(nestedShadow.shadowRoot);

    let revert = ariaHideOutside([target]);
    expect(shadowHost).toHaveAttribute('aria-hidden', 'true');
    expect(lightChild).not.toHaveAttribute('aria-hidden');
    expect(button).not.toHaveAttribute('aria-hidden');

    revert();
  });
});

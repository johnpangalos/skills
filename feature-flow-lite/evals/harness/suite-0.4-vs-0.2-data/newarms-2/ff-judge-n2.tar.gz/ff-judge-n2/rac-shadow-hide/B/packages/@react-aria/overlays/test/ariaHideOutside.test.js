/*
 * Copyright 2020 Adobe. All rights reserved.
 * This file is licensed to you under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License. You may obtain a copy
 * of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software distributed under
 * the License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR REPRESENTATIONS
 * OF ANY KIND, either express or implied. See the License for the specific language
 * governing permissions and limitations under the License.
 */

import {act, createShadowRoot, render, waitFor} from '@react-spectrum/test-utils-internal';
import {ariaHideOutside} from '../src';
import {enableShadowDOM} from '@react-stately/flags';
import React, {useRef, useState} from 'react';

describe('ariaHideOutside', function () {
  it('should hide everything except the provided element [button]', function () {
    let {getByRole, getAllByRole} = render(
      <>
        <input type="checkbox" />
        <button>Button</button>
        <input type="checkbox" />
      </>
    );

    let checkboxes = getAllByRole('checkbox');
    let button = getByRole('button');

    let revert = ariaHideOutside([button]);

    expect(checkboxes[0]).toHaveAttribute('aria-hidden', 'true');
    expect(checkboxes[1]).toHaveAttribute('aria-hidden', 'true');
    expect(button).not.toHaveAttribute('aria-hidden');

    expect(() => getAllByRole('checkbox')).toThrow();
    expect(() => getByRole('button')).not.toThrow();

    revert();

    expect(checkboxes[0]).not.toHaveAttribute('aria-hidden');
    expect(checkboxes[1]).not.toHaveAttribute('aria-hidden');
    expect(button).not.toHaveAttribute('aria-hidden');

    expect(() => getAllByRole('checkbox')).not.toThrow();
    expect(() => getByRole('button')).not.toThrow();
  });

  it('should hide everything except multiple elements', function () {
    let {getByRole, getAllByRole, queryByRole, queryAllByRole} = render(
      <>
        <input type="checkbox" />
        <button>Button</button>
        <input type="checkbox" />
      </>
    );

    let checkboxes = getAllByRole('checkbox');
    let button = getByRole('button');

    let revert = ariaHideOutside(checkboxes);

    expect(checkboxes[0]).not.toHaveAttribute('aria-hidden', 'true');
    expect(checkboxes[1]).not.toHaveAttribute('aria-hidden', 'true');
    expect(button).toHaveAttribute('aria-hidden');

    expect(queryAllByRole('checkbox')).not.toBeNull();
    expect(queryByRole('button')).toBeNull();

    revert();

    expect(checkboxes[0]).not.toHaveAttribute('aria-hidden');
    expect(checkboxes[1]).not.toHaveAttribute('aria-hidden');
    expect(button).not.toHaveAttribute('aria-hidden');

    expect(() => getAllByRole('checkbox')).not.toThrow();
    expect(() => getByRole('button')).not.toThrow();
  });

  it('should not traverse into an already hidden container', function () {
    let {getByRole, getAllByRole} = render(
      <>
        <div>
          <input type="checkbox" />
        </div>
        <button>Button</button>
        <input type="checkbox" />
      </>
    );

    let checkboxes = getAllByRole('checkbox');
    let button = getByRole('button');

    let revert = ariaHideOutside([button]);

    expect(checkboxes[0].parentElement).toHaveAttribute('aria-hidden', 'true');
    expect(checkboxes[1]).toHaveAttribute('aria-hidden', 'true');
    expect(button).not.toHaveAttribute('aria-hidden');

    expect(() => getAllByRole('checkbox')).toThrow();
    expect(() => getByRole('button')).not.toThrow();

    revert();

    expect(checkboxes[0].parentElement).not.toHaveAttribute('aria-hidden');
    expect(checkboxes[1]).not.toHaveAttribute('aria-hidden');
    expect(button).not.toHaveAttribute('aria-hidden');

    expect(() => getAllByRole('checkbox')).not.toThrow();
    expect(() => getByRole('button')).not.toThrow();
  });

  it('should not overwrite an existing aria-hidden prop', function () {
    let {getByRole, getAllByRole} = render(
      <>
        <input type="checkbox" aria-hidden="true" />
        <button>Button</button>
        <input type="checkbox" />
      </>
    );

    let checkboxes = getAllByRole('checkbox');
    let button = getByRole('button');

    let revert = ariaHideOutside([button]);

    expect(checkboxes).toHaveLength(1);
    expect(checkboxes[0]).toHaveAttribute('aria-hidden', 'true');
    expect(button).not.toHaveAttribute('aria-hidden');

    expect(() => getAllByRole('checkbox')).toThrow();
    expect(() => getByRole('button')).not.toThrow();

    revert();

    checkboxes = getAllByRole('checkbox');
    expect(checkboxes).toHaveLength(1);
    expect(checkboxes[0]).not.toHaveAttribute('aria-hidden');
    expect(button).not.toHaveAttribute('aria-hidden');

    expect(() => getAllByRole('checkbox')).not.toThrow();
    expect(() => getByRole('button')).not.toThrow();
  });

  it('should handle when a new element is added outside while active', async function () {
    let Test = props => (
      <>
        {props.show && <input type="checkbox" />}
        <button>Button</button>
        {props.show && <input type="checkbox" />}
      </>
    );

    let {getByRole, getAllByRole, rerender} = render(<Test />);

    let button = getByRole('button');
    expect(() => getAllByRole('checkbox')).toThrow();

    let revert = ariaHideOutside([button]);

    rerender(<Test show />);

    // MutationObserver is async
    await waitFor(() => expect(() => getAllByRole('checkbox')).toThrow());
    expect(() => getByRole('button')).not.toThrow();

    revert();

    expect(getAllByRole('checkbox')).toHaveLength(2);
  });

  it('should handle when a new element is added to an already hidden container', async function () {
    let Test = props => (
      <>
        <div data-testid="test">
          {props.show && <input type="checkbox" />}
        </div>
        <button>Button</button>
        {props.show && <input type="checkbox" />}
      </>
    );

    let {getByRole, getAllByRole, getByTestId, rerender} = render(<Test />);

    let button = getByRole('button');
    let test = getByTestId('test');
    expect(() => getAllByRole('checkbox')).toThrow();

    let revert = ariaHideOutside([button]);

    expect(test).toHaveAttribute('aria-hidden');

    rerender(<Test show />);

    // MutationObserver is async
    await waitFor(() => expect(() => getAllByRole('checkbox')).toThrow());
    expect(() => getByRole('button')).not.toThrow();

    let checkboxes = getAllByRole('checkbox', {hidden: true});
    expect(test).toHaveAttribute('aria-hidden');
    expect(checkboxes[0]).not.toHaveAttribute('aria-hidden');
    expect(checkboxes[1]).toHaveAttribute('aria-hidden', 'true');

    revert();

    expect(getAllByRole('checkbox')).toHaveLength(2);
  });

  it('should handle when a new element is added along with a top layer element', async function () {
    let Test = props => (
      <>
        <button>Button</button>
        {props.show && <div>
          <div role="alert" data-react-aria-top-layer="true">Top layer</div>
          <input type="checkbox" />
        </div>}
      </>
    );

    let {getByRole, queryByRole, getAllByRole, rerender} = render(<Test />);

    let button = getByRole('button');
    expect(queryByRole('checkbox')).toBeNull();

    let revert = ariaHideOutside([button]);

    rerender(<Test show />);

    // MutationObserver is async
    await waitFor(() => queryByRole('checkbox') == null);
    expect(queryByRole('button')).not.toBeNull();
    expect(getByRole('alert')).toHaveTextContent('Top layer');

    revert();

    expect(getAllByRole('checkbox')).toHaveLength(1);
  });

  it('should handle when a new element is added inside a target element', async function () {
    let Test = props => (
      <>
        <input type="checkbox" />
        <div data-testid="test">
          <button>Button</button>
          {props.show && <input type="radio" />}
        </div>
        <input type="checkbox" />
      </>
    );

    let {queryByRole, getByRole, getAllByRole, getByTestId, rerender} = render(<Test />);

    let test = getByTestId('test');
    let revert = ariaHideOutside([test]);

    expect(() => getAllByRole('checkbox')).toThrow();
    expect(queryByRole('radio')).toBeNull();
    expect(queryByRole('button')).not.toBeNull();
    expect(() => getByTestId('test')).not.toThrow();

    rerender(<Test show />);

    // Wait for mutation observer tick
    await Promise.resolve();
    expect(() => getAllByRole('checkbox')).toThrow();
    expect(() => getByRole('radio')).not.toThrow();
    expect(() => getByRole('button')).not.toThrow();
    expect(() => getByTestId('test')).not.toThrow();

    revert();

    expect(() => getAllByRole('checkbox')).not.toThrow();
    expect(() => getByRole('radio')).not.toThrow();
    expect(() => getByRole('button')).not.toThrow();
    expect(() => getByTestId('test')).not.toThrow();
  });

  it('should handle when a new element is added and then reparented', async function () {

    let Test = () => {
      const ref = useRef(null);
      const mutate = () => {
        let parent = document.createElement('ul');
        let child = document.createElement('li');
        ref.current.append(parent);
        parent.appendChild(child);
        parent.remove(); // this results in a mutation record for a disconnected ul with a connected li (through the new ul parent) in `addedNodes`
        let newParent = document.createElement('ul');
        newParent.appendChild(child);
        ref.current.append(newParent);
      };

      return (
        <>
          <div data-testid="test" ref={ref}>
            <button onClick={mutate}>Mutate</button>
          </div>
        </>
      );
    };

    let {queryByRole, getAllByRole, getByTestId} = render(<Test />);

    ariaHideOutside([getByTestId('test')]);

    queryByRole('button').click();
    await Promise.resolve(); // Wait for mutation observer tick

    expect(getAllByRole('listitem')).toHaveLength(1);
  });

  it('should handle when a new element is added and then reparented to a hidden container', async function () {

    let Test = () => {
      const ref = useRef(null);
      const mutate = () => {
        let parent = document.createElement('ul');
        let child = document.createElement('li');
        ref.current.append(parent);
        parent.appendChild(child);
        parent.remove(); // this results in a mutation record for a disconnected ul with a connected li (through the new ul parent) in `addedNodes`
        let newParent = document.createElement('ul');
        newParent.appendChild(child);
        ref.current.append(newParent);
      };

      return (
        <>
          <div data-testid="test">
            <button onClick={mutate}>Mutate</button>
          </div>
          <div data-testid="sibling" ref={ref} />
        </>
      );
    };

    let {queryByRole, queryAllByRole, getByTestId} = render(<Test />);

    ariaHideOutside([getByTestId('test')]);

    queryByRole('button').click();
    await Promise.resolve(); // Wait for mutation observer tick

    expect(queryAllByRole('listitem')).toHaveLength(0);
  });


  it('work when called multiple times', function () {
    let {getByRole, getAllByRole} = render(
      <>
        <input type="checkbox" />
        <input type="radio" />
        <button>Button</button>
        <input type="radio" />
        <input type="checkbox" />
      </>
    );

    let radios = getAllByRole('radio');
    let button = getByRole('button');

    let revert1 = ariaHideOutside([button, ...radios]);

    expect(() => getAllByRole('checkbox')).toThrow();
    expect(() => getAllByRole('radio')).not.toThrow();
    expect(() => getByRole('button')).not.toThrow();

    let revert2 = ariaHideOutside([button]);

    expect(() => getAllByRole('checkbox')).toThrow();
    expect(() => getAllByRole('radio')).toThrow();
    expect(() => getByRole('button')).not.toThrow();

    revert2();

    expect(() => getAllByRole('checkbox')).toThrow();
    expect(() => getAllByRole('radio')).not.toThrow();
    expect(() => getByRole('button')).not.toThrow();

    revert1();

    expect(() => getAllByRole('checkbox')).not.toThrow();
    expect(() => getAllByRole('radio')).not.toThrow();
    expect(() => getByRole('button')).not.toThrow();
  });

  it('work when called multiple times and restored out of order', function () {
    let {getByRole, getAllByRole} = render(
      <>
        <input type="checkbox" />
        <input type="radio" />
        <button>Button</button>
        <input type="radio" />
        <input type="checkbox" />
      </>
    );

    let radios = getAllByRole('radio');
    let button = getByRole('button');

    let revert1 = ariaHideOutside([button, ...radios]);

    expect(() => getAllByRole('checkbox')).toThrow();
    expect(() => getAllByRole('radio')).not.toThrow();
    expect(() => getByRole('button')).not.toThrow();

    let revert2 = ariaHideOutside([button]);

    expect(() => getAllByRole('checkbox')).toThrow();
    expect(() => getAllByRole('radio')).toThrow();
    expect(() => getByRole('button')).not.toThrow();

    revert1();

    expect(() => getAllByRole('checkbox')).toThrow();
    expect(() => getAllByRole('radio')).toThrow();
    expect(() => getByRole('button')).not.toThrow();

    revert2();

    expect(() => getAllByRole('checkbox')).not.toThrow();
    expect(() => getAllByRole('radio')).not.toThrow();
    expect(() => getByRole('button')).not.toThrow();
  });

  it('should hide everything except the provided element [row]', function () {
    let {getAllByRole, getByTestId} = render(
      <div role="grid">
        <div role="row">
          <div role="gridcell">
            <span data-testid="test-span">
              Cell 1
            </span></div>
        </div>
        <div role="row">
          <div role="gridcell">Cell 2</div>
        </div>
      </div>
    );

    let cells = getAllByRole('gridcell');
    let rows = getAllByRole('row');
    let span = getByTestId('test-span');

    let revert = ariaHideOutside([rows[1]]);

    // Applies aria-hidden to the row and cell despite recursive nature of aria-hidden
    // for https://bugs.webkit.org/show_bug.cgi?id=222623
    expect(rows[0]).toHaveAttribute('aria-hidden', 'true');
    expect(cells[0]).toHaveAttribute('aria-hidden', 'true');
    expect(span).not.toHaveAttribute('aria-hidden');
    expect(rows[1]).not.toHaveAttribute('aria-hidden', 'true');
    expect(cells[1]).not.toHaveAttribute('aria-hidden', 'true');

    revert();

    expect(rows[0]).not.toHaveAttribute('aria-hidden', 'true');
    expect(cells[0]).not.toHaveAttribute('aria-hidden', 'true');
    expect(rows[1]).not.toHaveAttribute('aria-hidden', 'true');
    expect(cells[1]).not.toHaveAttribute('aria-hidden', 'true');
    expect(span).not.toHaveAttribute('aria-hidden');
  });

  it('should unhide after item reorder', async function () {
    function Item(props) {
      return (
        <div role="presentation">
          <div data-testid={props.testid} role="row">
            <div role="gridcell" />
          </div>
        </div>
      );
    }

    function Test() {
      let [count, setCount] = useState(0);
      let items = ['row1', 'row2', 'row3', 'row4', 'row5'];
      if (count === 1) {
        items = ['row2', 'row1', 'row3', 'row4', 'row5'];
      } else if (count === 2) {
        items = ['row2', 'row3', 'row1', 'row4', 'row5'];
      }

      return (
        <>
          <button onClick={() => setCount((old) => old + 1)}>press</button>
          {items.map((item) => <Item testid={item} key={item} />)}
        </>

      );
    }

    let {getByRole, getByTestId} = render(
      <Test />
    );

    let button = getByRole('button');
    let row = getByTestId('row1');
    let revert = ariaHideOutside([button]);

    act(() => button.click());
    await Promise.resolve();
    act(() => button.click());
    await Promise.resolve();
    revert();
    expect(row.parentElement).not.toHaveAttribute('aria-hidden', 'true');
  });

  it('should not hide a sibling inside a shadow root when shadow DOM is off', function () {
    let {getByRole} = render(<button>Button</button>);
    let {shadowHost, shadowRoot, cleanup} = createShadowRoot();
    shadowRoot.innerHTML = '<input type="checkbox" />';

    let revert = ariaHideOutside([getByRole('button')]);

    expect(shadowRoot.querySelector('input')).not.toHaveAttribute('aria-hidden');
    expect(shadowHost).toHaveAttribute('aria-hidden', 'true');

    revert();
    cleanup();
  });
});

describe('ariaHideOutside with shadow DOM', function () {
  let cleanups = [];
  let createRoot = (attachTo) => {
    let result = createShadowRoot(attachTo);
    cleanups.push(result.cleanup);
    return result;
  };

  // A light DOM checkbox, and an outer shadow root holding a sibling, a non-target element and
  // an element that hosts a nested shadow root. The target is a button inside the nested root.
  let setupNested = () => {
    let {getByTestId} = render(<input type="checkbox" data-testid="light-sibling" />);
    let outer = createRoot();
    outer.shadowRoot.innerHTML = '<input type="checkbox" id="outer-sibling" /><div id="mid"></div><div id="other"><button id="other-button">Other</button></div>';
    let mid = outer.shadowRoot.getElementById('mid');
    let inner = createRoot(mid);
    inner.shadowRoot.innerHTML = '<input type="radio" id="mid-sibling" /><button id="target"><span id="target-child">Target</span></button>';
    return {
      lightSibling: getByTestId('light-sibling'),
      outer,
      mid,
      inner,
      outerSibling: outer.shadowRoot.getElementById('outer-sibling'),
      otherButton: outer.shadowRoot.getElementById('other-button'),
      midSibling: inner.shadowRoot.getElementById('mid-sibling'),
      target: inner.shadowRoot.getElementById('target')
    };
  };

  beforeAll(function () {
    enableShadowDOM();
  });

  afterEach(function () {
    while (cleanups.length) {
      cleanups.pop()();
    }
    jest.restoreAllMocks();
  });

  it('hides siblings in every enclosing shadow root and keeps the path hosts and target visible', function () {
    let {lightSibling, outer, mid, inner, outerSibling, midSibling, target} = setupNested();
    let targetChild = target.querySelector('span');

    let revert = ariaHideOutside([target]);

    // The render container is hidden as a whole, so check the nearest hidden ancestor.
    expect(lightSibling.closest('[aria-hidden="true"]')).not.toBeNull();
    expect(outer.shadowHost).not.toHaveAttribute('aria-hidden');
    expect(outerSibling).toHaveAttribute('aria-hidden', 'true');
    expect(mid).not.toHaveAttribute('aria-hidden');
    expect(inner.shadowHost).not.toHaveAttribute('aria-hidden');
    expect(midSibling).toHaveAttribute('aria-hidden', 'true');
    expect(target).not.toHaveAttribute('aria-hidden');
    expect(targetChild).not.toHaveAttribute('aria-hidden');

    revert();
  });

  it('keeps a target that is a direct child of the shadow root visible', function () {
    let outer = createRoot();
    outer.shadowRoot.innerHTML = '<input type="checkbox" id="sibling" /><button id="target">Target</button>';
    let sibling = outer.shadowRoot.getElementById('sibling');
    let target = outer.shadowRoot.getElementById('target');
    expect(target.parentElement).toBeNull();

    let revert = ariaHideOutside([target]);

    expect(sibling).toHaveAttribute('aria-hidden', 'true');
    expect(outer.shadowHost).not.toHaveAttribute('aria-hidden');
    expect(target).not.toHaveAttribute('aria-hidden');

    revert();

    expect(sibling).not.toHaveAttribute('aria-hidden');
  });

  it('hides content added later to an enclosing shadow root but not content added inside the target', async function () {
    let {outer, inner, mid, target} = setupNested();

    let revert = ariaHideOutside([target]);

    let outerAdded = document.createElement('input');
    outer.shadowRoot.appendChild(outerAdded);
    let deepAdded = document.createElement('button');
    mid.appendChild(deepAdded);
    let innerAdded = document.createElement('input');
    inner.shadowRoot.appendChild(innerAdded);
    let targetAdded = document.createElement('span');
    target.appendChild(targetAdded);

    // MutationObserver is async
    await Promise.resolve();
    expect(outerAdded).toHaveAttribute('aria-hidden', 'true');
    expect(deepAdded).toHaveAttribute('aria-hidden', 'true');
    expect(innerAdded).toHaveAttribute('aria-hidden', 'true');
    expect(targetAdded).not.toHaveAttribute('aria-hidden');

    revert();
  });

  it('keeps live announcer and top layer elements in shadow roots visible at call time and when added later', async function () {
    let outer = createRoot();
    outer.shadowRoot.innerHTML = '<div data-live-announcer="true" id="announcer"></div><div data-react-aria-top-layer="true" id="toast"></div><div id="wrap"><div data-react-aria-top-layer="true" id="nested-toast"></div></div><input type="checkbox" id="sibling" /><button id="target">Target</button>';
    let target = outer.shadowRoot.getElementById('target');
    let sibling = outer.shadowRoot.getElementById('sibling');

    let revert = ariaHideOutside([target]);

    let lateAnnouncer = document.createElement('div');
    lateAnnouncer.dataset.liveAnnouncer = 'true';
    let lateToast = document.createElement('div');
    lateToast.dataset.reactAriaTopLayer = 'true';
    outer.shadowRoot.append(lateAnnouncer, lateToast);

    // MutationObserver is async
    await Promise.resolve();
    expect(outer.shadowRoot.getElementById('announcer')).not.toHaveAttribute('aria-hidden');
    expect(outer.shadowRoot.getElementById('toast')).not.toHaveAttribute('aria-hidden');
    expect(outer.shadowRoot.getElementById('nested-toast')).not.toHaveAttribute('aria-hidden');
    expect(lateAnnouncer).not.toHaveAttribute('aria-hidden');
    expect(lateToast).not.toHaveAttribute('aria-hidden');
    expect(sibling).toHaveAttribute('aria-hidden', 'true');

    revert();
  });

  it('keeps targets in different shadow roots visible along with both hosts', function () {
    let {getByTestId} = render(<><input type="checkbox" data-testid="light-sibling" /><button data-testid="light-target">Light</button></>);
    let rootA = createRoot();
    rootA.shadowRoot.innerHTML = '<button id="sibling-a">Sibling</button><input id="input-a" />';
    let rootB = createRoot();
    rootB.shadowRoot.innerHTML = '<button id="sibling-b">Sibling</button><div id="popover"></div>';
    let inputA = rootA.shadowRoot.getElementById('input-a');
    let popover = rootB.shadowRoot.getElementById('popover');

    let revert = ariaHideOutside([inputA, popover, getByTestId('light-target')]);

    expect(rootA.shadowHost).not.toHaveAttribute('aria-hidden');
    expect(rootB.shadowHost).not.toHaveAttribute('aria-hidden');
    expect(inputA).not.toHaveAttribute('aria-hidden');
    expect(popover).not.toHaveAttribute('aria-hidden');
    expect(getByTestId('light-target')).not.toHaveAttribute('aria-hidden');
    expect(getByTestId('light-sibling')).toHaveAttribute('aria-hidden', 'true');
    expect(rootA.shadowRoot.getElementById('sibling-a')).toHaveAttribute('aria-hidden', 'true');
    expect(rootB.shadowRoot.getElementById('sibling-b')).toHaveAttribute('aria-hidden', 'true');

    revert();
  });

  it('keeps the shadow content of a target visible when another target is inside it', function () {
    let {getByTestId} = render(<><input type="checkbox" data-testid="light-sibling" /><div data-testid="outer-target"><div data-testid="host" /></div></>);
    let host = getByTestId('host');
    let shadowRoot = host.attachShadow({mode: 'open'});
    shadowRoot.innerHTML = '<input id="sibling" /><button id="inner-target">Inner</button>';

    let revert = ariaHideOutside([getByTestId('outer-target'), shadowRoot.getElementById('inner-target')]);

    expect(getByTestId('light-sibling')).toHaveAttribute('aria-hidden', 'true');
    expect(getByTestId('outer-target')).not.toHaveAttribute('aria-hidden');
    expect(host).not.toHaveAttribute('aria-hidden');
    expect(shadowRoot.getElementById('sibling')).not.toHaveAttribute('aria-hidden');
    expect(shadowRoot.getElementById('inner-target')).not.toHaveAttribute('aria-hidden');

    revert();
  });

  it('restores every element it hid in shadow roots when reverted', function () {
    let {lightSibling, outerSibling, midSibling, target} = setupNested();

    let revert = ariaHideOutside([target]);

    expect(outerSibling).toHaveAttribute('aria-hidden', 'true');
    expect(midSibling).toHaveAttribute('aria-hidden', 'true');

    revert();

    expect(lightSibling).not.toHaveAttribute('aria-hidden');
    expect(outerSibling).not.toHaveAttribute('aria-hidden');
    expect(midSibling).not.toHaveAttribute('aria-hidden');
  });

  it('does not hide a node appended to a shadow root after revert', async function () {
    let {outer, inner, target} = setupNested();

    let revert = ariaHideOutside([target]);
    revert();

    let outerAdded = document.createElement('input');
    outer.shadowRoot.appendChild(outerAdded);
    let innerAdded = document.createElement('input');
    inner.shadowRoot.appendChild(innerAdded);

    // MutationObserver is async
    await Promise.resolve();
    expect(outerAdded).not.toHaveAttribute('aria-hidden');
    expect(innerAdded).not.toHaveAttribute('aria-hidden');
  });

  it('pauses the outer shadow root observers during a nested call and resumes them on revert', async function () {
    let {inner, target, otherButton} = setupNested();
    let revertOuter = ariaHideOutside([target]);
    let revertInner = ariaHideOutside([otherButton]);

    // The outer observer is paused while the inner call is active, so content added to its shadow root is not hidden yet.
    let duringInner = document.createElement('input');
    inner.shadowRoot.appendChild(duringInner);
    await Promise.resolve();
    expect(duringInner).not.toHaveAttribute('aria-hidden');

    revertInner();

    let afterInner = document.createElement('input');
    inner.shadowRoot.appendChild(afterInner);
    await Promise.resolve();
    expect(afterInner).toHaveAttribute('aria-hidden', 'true');
    expect(target).not.toHaveAttribute('aria-hidden');

    revertOuter();
    expect(afterInner).not.toHaveAttribute('aria-hidden');
  });

  it('keeps a shadow element hidden until every call that hid it is reverted', function () {
    let {outer, target, otherButton} = setupNested();
    let outerSibling = outer.shadowRoot.getElementById('outer-sibling');

    let revertOuter = ariaHideOutside([target]);
    let revertInner = ariaHideOutside([otherButton]);

    expect(outerSibling).toHaveAttribute('aria-hidden', 'true');

    revertInner();

    expect(outerSibling).toHaveAttribute('aria-hidden', 'true');

    revertOuter();

    expect(outerSibling).not.toHaveAttribute('aria-hidden');
  });

  it('walks and observes a shadow root once when two targets are inside it', function () {
    let outer = createRoot();
    outer.shadowRoot.innerHTML = '<button id="first">First</button><button id="second">Second</button><input id="sibling" />';
    let first = outer.shadowRoot.getElementById('first');
    let second = outer.shadowRoot.getElementById('second');
    let sibling = outer.shadowRoot.getElementById('sibling');
    let walkerSpy = jest.spyOn(document, 'createTreeWalker');
    let observeSpy = jest.spyOn(MutationObserver.prototype, 'observe');

    let revert = ariaHideOutside([first, second]);

    expect(walkerSpy.mock.calls.filter(([node]) => node === outer.shadowRoot)).toHaveLength(1);
    expect(observeSpy.mock.calls.filter(([node]) => node === outer.shadowRoot)).toHaveLength(1);
    expect(sibling).toHaveAttribute('aria-hidden', 'true');
    expect(first).not.toHaveAttribute('aria-hidden');
    expect(second).not.toHaveAttribute('aria-hidden');

    revert();

    expect(sibling).not.toHaveAttribute('aria-hidden');
    expect(first).not.toHaveAttribute('aria-hidden');
    expect(second).not.toHaveAttribute('aria-hidden');
  });

  it('hides an unrelated shadow host as a whole without hiding its shadow content', function () {
    let {getByTestId} = render(<button data-testid="target">Target</button>);
    let unrelated = createRoot();
    unrelated.shadowRoot.innerHTML = '<input id="inner" />';

    let revert = ariaHideOutside([getByTestId('target')]);

    expect(unrelated.shadowHost).toHaveAttribute('aria-hidden', 'true');
    expect(unrelated.shadowRoot.getElementById('inner')).not.toHaveAttribute('aria-hidden');

    revert();

    expect(unrelated.shadowHost).not.toHaveAttribute('aria-hidden');
  });

  it('keeps a shadow sibling that was already aria-hidden hidden after revert', function () {
    let outer = createRoot();
    outer.shadowRoot.innerHTML = '<input id="already" type="checkbox" aria-hidden="true" /><button id="target">Target</button>';
    let already = outer.shadowRoot.getElementById('already');
    let target = outer.shadowRoot.getElementById('target');

    let revert = ariaHideOutside([target]);

    expect(already).toHaveAttribute('aria-hidden', 'true');

    revert();

    expect(already).toHaveAttribute('aria-hidden', 'true');
  });

  it('uses inert for shadow siblings and leaves the path hosts alone when shouldUseInert is set', function () {
    let {outer, mid, inner, outerSibling, midSibling, target} = setupNested();
    // jsdom does not implement inert, so define it and load the module again so it detects support for inert.
    Object.defineProperty(HTMLElement.prototype, 'inert', {configurable: true, writable: true, value: false});
    let hideOutside;
    try {
      jest.isolateModules(() => {
        hideOutside = require('../src').ariaHideOutside;
        require('@react-stately/flags').enableShadowDOM();
      });

      let revert = hideOutside([target], {shouldUseInert: true});

      expect(outerSibling.inert).toBe(true);
      expect(outerSibling).not.toHaveAttribute('aria-hidden');
      expect(midSibling.inert).toBe(true);
      expect(outer.shadowHost.inert).toBe(false);
      expect(mid.inert).toBe(false);
      expect(inner.shadowHost.inert).toBe(false);
      expect(target.inert).toBe(false);

      revert();

      expect(outerSibling.inert).toBe(false);
    } finally {
      delete HTMLElement.prototype.inert;
    }
  });
});

/*
 * Copyright 2020 Adobe. All rights reserved.
 * This file is licensed to you under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License. You may obtain a copy
 * of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software distributed under
 * the License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR REPRESENTATIONS
 * OF ANY KIND, either express or implied. See the License for the specific language
 * governing permissions and limitations under the License.
 */

import {act, createShadowRoot, render, waitFor} from '@react-spectrum/test-utils-internal';
import {ariaHideOutside} from '../src';
import {enableShadowDOM} from '@react-stately/flags';
import React, {useRef, useState} from 'react';

describe('ariaHideOutside', function () {
  it('should hide everything except the provided element [button]', function () {
    let {getByRole, getAllByRole} = render(
      <>
        <input type="checkbox" />
        <button>Button</button>
        <input type="checkbox" />
      </>
    );

    let checkboxes = getAllByRole('checkbox');
    let button = getByRole('button');

    let revert = ariaHideOutside([button]);

    expect(checkboxes[0]).toHaveAttribute('aria-hidden', 'true');
    expect(checkboxes[1]).toHaveAttribute('aria-hidden', 'true');
    expect(button).not.toHaveAttribute('aria-hidden');

    expect(() => getAllByRole('checkbox')).toThrow();
    expect(() => getByRole('button')).not.toThrow();

    revert();

    expect(checkboxes[0]).not.toHaveAttribute('aria-hidden');
    expect(checkboxes[1]).not.toHaveAttribute('aria-hidden');
    expect(button).not.toHaveAttribute('aria-hidden');

    expect(() => getAllByRole('checkbox')).not.toThrow();
    expect(() => getByRole('button')).not.toThrow();
  });

  it('should hide everything except multiple elements', function () {
    let {getByRole, getAllByRole, queryByRole, queryAllByRole} = render(
      <>
        <input type="checkbox" />
        <button>Button</button>
        <input type="checkbox" />
      </>
    );

    let checkboxes = getAllByRole('checkbox');
    let button = getByRole('button');

    let revert = ariaHideOutside(checkboxes);

    expect(checkboxes[0]).not.toHaveAttribute('aria-hidden', 'true');
    expect(checkboxes[1]).not.toHaveAttribute('aria-hidden', 'true');
    expect(button).toHaveAttribute('aria-hidden');

    expect(queryAllByRole('checkbox')).not.toBeNull();
    expect(queryByRole('button')).toBeNull();

    revert();

    expect(checkboxes[0]).not.toHaveAttribute('aria-hidden');
    expect(checkboxes[1]).not.toHaveAttribute('aria-hidden');
    expect(button).not.toHaveAttribute('aria-hidden');

    expect(() => getAllByRole('checkbox')).not.toThrow();
    expect(() => getByRole('button')).not.toThrow();
  });

  it('should not traverse into an already hidden container', function () {
    let {getByRole, getAllByRole} = render(
      <>
        <div>
          <input type="checkbox" />
        </div>
        <button>Button</button>
        <input type="checkbox" />
      </>
    );

    let checkboxes = getAllByRole('checkbox');
    let button = getByRole('button');

    let revert = ariaHideOutside([button]);

    expect(checkboxes[0].parentElement).toHaveAttribute('aria-hidden', 'true');
    expect(checkboxes[1]).toHaveAttribute('aria-hidden', 'true');
    expect(button).not.toHaveAttribute('aria-hidden');

    expect(() => getAllByRole('checkbox')).toThrow();
    expect(() => getByRole('button')).not.toThrow();

    revert();

    expect(checkboxes[0].parentElement).not.toHaveAttribute('aria-hidden');
    expect(checkboxes[1]).not.toHaveAttribute('aria-hidden');
    expect(button).not.toHaveAttribute('aria-hidden');

    expect(() => getAllByRole('checkbox')).not.toThrow();
    expect(() => getByRole('button')).not.toThrow();
  });

  it('should not overwrite an existing aria-hidden prop', function () {
    let {getByRole, getAllByRole} = render(
      <>
        <input type="checkbox" aria-hidden="true" />
        <button>Button</button>
        <input type="checkbox" />
      </>
    );

    let checkboxes = getAllByRole('checkbox');
    let button = getByRole('button');

    let revert = ariaHideOutside([button]);

    expect(checkboxes).toHaveLength(1);
    expect(checkboxes[0]).toHaveAttribute('aria-hidden', 'true');
    expect(button).not.toHaveAttribute('aria-hidden');

    expect(() => getAllByRole('checkbox')).toThrow();
    expect(() => getByRole('button')).not.toThrow();

    revert();

    checkboxes = getAllByRole('checkbox');
    expect(checkboxes).toHaveLength(1);
    expect(checkboxes[0]).not.toHaveAttribute('aria-hidden');
    expect(button).not.toHaveAttribute('aria-hidden');

    expect(() => getAllByRole('checkbox')).not.toThrow();
    expect(() => getByRole('button')).not.toThrow();
  });

  it('should handle when a new element is added outside while active', async function () {
    let Test = props => (
      <>
        {props.show && <input type="checkbox" />}
        <button>Button</button>
        {props.show && <input type="checkbox" />}
      </>
    );

    let {getByRole, getAllByRole, rerender} = render(<Test />);

    let button = getByRole('button');
    expect(() => getAllByRole('checkbox')).toThrow();

    let revert = ariaHideOutside([button]);

    rerender(<Test show />);

    // MutationObserver is async
    await waitFor(() => expect(() => getAllByRole('checkbox')).toThrow());
    expect(() => getByRole('button')).not.toThrow();

    revert();

    expect(getAllByRole('checkbox')).toHaveLength(2);
  });

  it('should handle when a new element is added to an already hidden container', async function () {
    let Test = props => (
      <>
        <div data-testid="test">
          {props.show && <input type="checkbox" />}
        </div>
        <button>Button</button>
        {props.show && <input type="checkbox" />}
      </>
    );

    let {getByRole, getAllByRole, getByTestId, rerender} = render(<Test />);

    let button = getByRole('button');
    let test = getByTestId('test');
    expect(() => getAllByRole('checkbox')).toThrow();

    let revert = ariaHideOutside([button]);

    expect(test).toHaveAttribute('aria-hidden');

    rerender(<Test show />);

    // MutationObserver is async
    await waitFor(() => expect(() => getAllByRole('checkbox')).toThrow());
    expect(() => getByRole('button')).not.toThrow();

    let checkboxes = getAllByRole('checkbox', {hidden: true});
    expect(test).toHaveAttribute('aria-hidden');
    expect(checkboxes[0]).not.toHaveAttribute('aria-hidden');
    expect(checkboxes[1]).toHaveAttribute('aria-hidden', 'true');

    revert();

    expect(getAllByRole('checkbox')).toHaveLength(2);
  });

  it('should handle when a new element is added along with a top layer element', async function () {
    let Test = props => (
      <>
        <button>Button</button>
        {props.show && <div>
          <div role="alert" data-react-aria-top-layer="true">Top layer</div>
          <input type="checkbox" />
        </div>}
      </>
    );

    let {getByRole, queryByRole, getAllByRole, rerender} = render(<Test />);

    let button = getByRole('button');
    expect(queryByRole('checkbox')).toBeNull();

    let revert = ariaHideOutside([button]);

    rerender(<Test show />);

    // MutationObserver is async
    await waitFor(() => queryByRole('checkbox') == null);
    expect(queryByRole('button')).not.toBeNull();
    expect(getByRole('alert')).toHaveTextContent('Top layer');

    revert();

    expect(getAllByRole('checkbox')).toHaveLength(1);
  });

  it('should handle when a new element is added inside a target element', async function () {
    let Test = props => (
      <>
        <input type="checkbox" />
        <div data-testid="test">
          <button>Button</button>
          {props.show && <input type="radio" />}
        </div>
        <input type="checkbox" />
      </>
    );

    let {queryByRole, getByRole, getAllByRole, getByTestId, rerender} = render(<Test />);

    let test = getByTestId('test');
    let revert = ariaHideOutside([test]);

    expect(() => getAllByRole('checkbox')).toThrow();
    expect(queryByRole('radio')).toBeNull();
    expect(queryByRole('button')).not.toBeNull();
    expect(() => getByTestId('test')).not.toThrow();

    rerender(<Test show />);

    // Wait for mutation observer tick
    await Promise.resolve();
    expect(() => getAllByRole('checkbox')).toThrow();
    expect(() => getByRole('radio')).not.toThrow();
    expect(() => getByRole('button')).not.toThrow();
    expect(() => getByTestId('test')).not.toThrow();

    revert();

    expect(() => getAllByRole('checkbox')).not.toThrow();
    expect(() => getByRole('radio')).not.toThrow();
    expect(() => getByRole('button')).not.toThrow();
    expect(() => getByTestId('test')).not.toThrow();
  });

  it('should handle when a new element is added and then reparented', async function () {

    let Test = () => {
      const ref = useRef(null);
      const mutate = () => {
        let parent = document.createElement('ul');
        let child = document.createElement('li');
        ref.current.append(parent);
        parent.appendChild(child);
        parent.remove(); // this results in a mutation record for a disconnected ul with a connected li (through the new ul parent) in `addedNodes`
        let newParent = document.createElement('ul');
        newParent.appendChild(child);
        ref.current.append(newParent);
      };

      return (
        <>
          <div data-testid="test" ref={ref}>
            <button onClick={mutate}>Mutate</button>
          </div>
        </>
      );
    };

    let {queryByRole, getAllByRole, getByTestId} = render(<Test />);

    ariaHideOutside([getByTestId('test')]);

    queryByRole('button').click();
    await Promise.resolve(); // Wait for mutation observer tick

    expect(getAllByRole('listitem')).toHaveLength(1);
  });

  it('should handle when a new element is added and then reparented to a hidden container', async function () {

    let Test = () => {
      const ref = useRef(null);
      const mutate = () => {
        let parent = document.createElement('ul');
        let child = document.createElement('li');
        ref.current.append(parent);
        parent.appendChild(child);
        parent.remove(); // this results in a mutation record for a disconnected ul with a connected li (through the new ul parent) in `addedNodes`
        let newParent = document.createElement('ul');
        newParent.appendChild(child);
        ref.current.append(newParent);
      };

      return (
        <>
          <div data-testid="test">
            <button onClick={mutate}>Mutate</button>
          </div>
          <div data-testid="sibling" ref={ref} />
        </>
      );
    };

    let {queryByRole, queryAllByRole, getByTestId} = render(<Test />);

    ariaHideOutside([getByTestId('test')]);

    queryByRole('button').click();
    await Promise.resolve(); // Wait for mutation observer tick

    expect(queryAllByRole('listitem')).toHaveLength(0);
  });


  it('work when called multiple times', function () {
    let {getByRole, getAllByRole} = render(
      <>
        <input type="checkbox" />
        <input type="radio" />
        <button>Button</button>
        <input type="radio" />
        <input type="checkbox" />
      </>
    );

    let radios = getAllByRole('radio');
    let button = getByRole('button');

    let revert1 = ariaHideOutside([button, ...radios]);

    expect(() => getAllByRole('checkbox')).toThrow();
    expect(() => getAllByRole('radio')).not.toThrow();
    expect(() => getByRole('button')).not.toThrow();

    let revert2 = ariaHideOutside([button]);

    expect(() => getAllByRole('checkbox')).toThrow();
    expect(() => getAllByRole('radio')).toThrow();
    expect(() => getByRole('button')).not.toThrow();

    revert2();

    expect(() => getAllByRole('checkbox')).toThrow();
    expect(() => getAllByRole('radio')).not.toThrow();
    expect(() => getByRole('button')).not.toThrow();

    revert1();

    expect(() => getAllByRole('checkbox')).not.toThrow();
    expect(() => getAllByRole('radio')).not.toThrow();
    expect(() => getByRole('button')).not.toThrow();
  });

  it('work when called multiple times and restored out of order', function () {
    let {getByRole, getAllByRole} = render(
      <>
        <input type="checkbox" />
        <input type="radio" />
        <button>Button</button>
        <input type="radio" />
        <input type="checkbox" />
      </>
    );

    let radios = getAllByRole('radio');
    let button = getByRole('button');

    let revert1 = ariaHideOutside([button, ...radios]);

    expect(() => getAllByRole('checkbox')).toThrow();
    expect(() => getAllByRole('radio')).not.toThrow();
    expect(() => getByRole('button')).not.toThrow();

    let revert2 = ariaHideOutside([button]);

    expect(() => getAllByRole('checkbox')).toThrow();
    expect(() => getAllByRole('radio')).toThrow();
    expect(() => getByRole('button')).not.toThrow();

    revert1();

    expect(() => getAllByRole('checkbox')).toThrow();
    expect(() => getAllByRole('radio')).toThrow();
    expect(() => getByRole('button')).not.toThrow();

    revert2();

    expect(() => getAllByRole('checkbox')).not.toThrow();
    expect(() => getAllByRole('radio')).not.toThrow();
    expect(() => getByRole('button')).not.toThrow();
  });

  it('should hide everything except the provided element [row]', function () {
    let {getAllByRole, getByTestId} = render(
      <div role="grid">
        <div role="row">
          <div role="gridcell">
            <span data-testid="test-span">
              Cell 1
            </span></div>
        </div>
        <div role="row">
          <div role="gridcell">Cell 2</div>
        </div>
      </div>
    );

    let cells = getAllByRole('gridcell');
    let rows = getAllByRole('row');
    let span = getByTestId('test-span');

    let revert = ariaHideOutside([rows[1]]);

    // Applies aria-hidden to the row and cell despite recursive nature of aria-hidden
    // for https://bugs.webkit.org/show_bug.cgi?id=222623
    expect(rows[0]).toHaveAttribute('aria-hidden', 'true');
    expect(cells[0]).toHaveAttribute('aria-hidden', 'true');
    expect(span).not.toHaveAttribute('aria-hidden');
    expect(rows[1]).not.toHaveAttribute('aria-hidden', 'true');
    expect(cells[1]).not.toHaveAttribute('aria-hidden', 'true');

    revert();

    expect(rows[0]).not.toHaveAttribute('aria-hidden', 'true');
    expect(cells[0]).not.toHaveAttribute('aria-hidden', 'true');
    expect(rows[1]).not.toHaveAttribute('aria-hidden', 'true');
    expect(cells[1]).not.toHaveAttribute('aria-hidden', 'true');
    expect(span).not.toHaveAttribute('aria-hidden');
  });

  it('should unhide after item reorder', async function () {
    function Item(props) {
      return (
        <div role="presentation">
          <div data-testid={props.testid} role="row">
            <div role="gridcell" />
          </div>
        </div>
      );
    }

    function Test() {
      let [count, setCount] = useState(0);
      let items = ['row1', 'row2', 'row3', 'row4', 'row5'];
      if (count === 1) {
        items = ['row2', 'row1', 'row3', 'row4', 'row5'];
      } else if (count === 2) {
        items = ['row2', 'row3', 'row1', 'row4', 'row5'];
      }

      return (
        <>
          <button onClick={() => setCount((old) => old + 1)}>press</button>
          {items.map((item) => <Item testid={item} key={item} />)}
        </>

      );
    }

    let {getByRole, getByTestId} = render(
      <Test />
    );

    let button = getByRole('button');
    let row = getByTestId('row1');
    let revert = ariaHideOutside([button]);

    act(() => button.click());
    await Promise.resolve();
    act(() => button.click());
    await Promise.resolve();
    revert();
    expect(row.parentElement).not.toHaveAttribute('aria-hidden', 'true');
  });
});

// The shadow DOM flag cannot be turned off again, so this block runs after the tests above.
describe('ariaHideOutside with shadow DOM', function () {
  let cleanups = [];

  beforeAll(function () {
    enableShadowDOM();
  });

  afterEach(function () {
    for (let cleanup of cleanups) {
      cleanup();
    }
    cleanups = [];
  });

  let createContainer = function () {
    let container = document.createElement('div');
    document.body.appendChild(container);
    cleanups.push(() => container.remove());
    return container;
  };

  it('should hide siblings of a target inside a shadow root, but not its host or ancestors', function () {
    let container = createContainer();
    let light = document.createElement('input');
    container.appendChild(light);
    let {shadowHost, shadowRoot} = createShadowRoot(container);
    shadowRoot.innerHTML = '<input id="before" type="checkbox"><div id="ancestor"><input id="inner" type="checkbox"><button id="target">Button</button></div><input id="after" type="checkbox">';
    let target = shadowRoot.getElementById('target');

    let revert = ariaHideOutside([target]);

    expect(light).toHaveAttribute('aria-hidden', 'true');
    expect(shadowHost).not.toHaveAttribute('aria-hidden');
    expect(container).not.toHaveAttribute('aria-hidden');
    expect(shadowRoot.getElementById('before')).toHaveAttribute('aria-hidden', 'true');
    expect(shadowRoot.getElementById('ancestor')).not.toHaveAttribute('aria-hidden');
    expect(shadowRoot.getElementById('inner')).toHaveAttribute('aria-hidden', 'true');
    expect(shadowRoot.getElementById('after')).toHaveAttribute('aria-hidden', 'true');
    expect(target).not.toHaveAttribute('aria-hidden');

    revert();

    expect(light).not.toHaveAttribute('aria-hidden');
    expect(shadowRoot.getElementById('before')).not.toHaveAttribute('aria-hidden');
    expect(shadowRoot.getElementById('inner')).not.toHaveAttribute('aria-hidden');
    expect(shadowRoot.getElementById('after')).not.toHaveAttribute('aria-hidden');
  });

  it('should hide siblings at every level of nested shadow roots', async function () {
    let container = createContainer();
    let outer = createShadowRoot(container);
    outer.shadowRoot.innerHTML = '<input id="outerSibling" type="checkbox">';
    let innerHost = document.createElement('div');
    outer.shadowRoot.appendChild(innerHost);
    let inner = innerHost.attachShadow({mode: 'open'});
    inner.innerHTML = '<input id="innerSibling" type="checkbox"><button id="target">Button</button>';
    let target = inner.getElementById('target');

    let revert = ariaHideOutside([target]);

    expect(outer.shadowRoot.getElementById('outerSibling')).toHaveAttribute('aria-hidden', 'true');
    expect(innerHost).not.toHaveAttribute('aria-hidden');
    expect(outer.shadowHost).not.toHaveAttribute('aria-hidden');
    expect(inner.getElementById('innerSibling')).toHaveAttribute('aria-hidden', 'true');
    expect(target).not.toHaveAttribute('aria-hidden');

    let added = document.createElement('input');
    outer.shadowRoot.appendChild(added);
    await waitFor(() => expect(added).toHaveAttribute('aria-hidden', 'true'));

    revert();

    expect(outer.shadowRoot.getElementById('outerSibling')).not.toHaveAttribute('aria-hidden');
    expect(inner.getElementById('innerSibling')).not.toHaveAttribute('aria-hidden');
    expect(added).not.toHaveAttribute('aria-hidden');
  });

  it('should hide content added to a shadow root, but not content added inside a target', async function () {
    let container = createContainer();
    let {shadowRoot} = createShadowRoot(container);
    shadowRoot.innerHTML = '<button id="target">Button</button>';
    let target = shadowRoot.getElementById('target');

    let revert = ariaHideOutside([target]);

    let added = document.createElement('input');
    let insideTarget = document.createElement('input');
    shadowRoot.appendChild(added);
    target.appendChild(insideTarget);

    await waitFor(() => expect(added).toHaveAttribute('aria-hidden', 'true'));
    expect(insideTarget).not.toHaveAttribute('aria-hidden');
    expect(target).not.toHaveAttribute('aria-hidden');

    revert();

    expect(added).not.toHaveAttribute('aria-hidden');
  });

  it('should keep live announcer and top layer elements in shadow roots visible', async function () {
    let container = createContainer();
    let {shadowRoot} = createShadowRoot(container);
    shadowRoot.innerHTML = '<div id="existing" data-live-announcer="true"></div><button id="target">Button</button>';
    let target = shadowRoot.getElementById('target');

    let revert = ariaHideOutside([target]);

    let sibling = document.createElement('input');
    let announcer = document.createElement('div');
    announcer.dataset.liveAnnouncer = 'true';
    let topLayer = document.createElement('div');
    topLayer.dataset.reactAriaTopLayer = 'true';
    shadowRoot.append(sibling, announcer, topLayer);

    await waitFor(() => expect(sibling).toHaveAttribute('aria-hidden', 'true'));
    expect(shadowRoot.getElementById('existing')).not.toHaveAttribute('aria-hidden');
    expect(announcer).not.toHaveAttribute('aria-hidden');
    expect(topLayer).not.toHaveAttribute('aria-hidden');

    revert();
  });

  it('should keep targets in different shadow roots visible and hide everything else', function () {
    let container = createContainer();
    let light = document.createElement('input');
    container.appendChild(light);
    let a = createShadowRoot(container);
    a.shadowRoot.innerHTML = '<input id="aSibling" type="checkbox"><input id="aTarget" type="text">';
    let b = createShadowRoot(container);
    b.shadowRoot.innerHTML = '<input id="bSibling" type="checkbox"><div id="bTarget" role="dialog"></div>';
    let aTarget = a.shadowRoot.getElementById('aTarget');
    let bTarget = b.shadowRoot.getElementById('bTarget');

    let revert = ariaHideOutside([aTarget, bTarget]);

    expect(a.shadowRoot.getElementById('aSibling')).toHaveAttribute('aria-hidden', 'true');
    expect(b.shadowRoot.getElementById('bSibling')).toHaveAttribute('aria-hidden', 'true');
    expect(light).toHaveAttribute('aria-hidden', 'true');
    expect(a.shadowHost).not.toHaveAttribute('aria-hidden');
    expect(b.shadowHost).not.toHaveAttribute('aria-hidden');
    expect(aTarget).not.toHaveAttribute('aria-hidden');
    expect(bTarget).not.toHaveAttribute('aria-hidden');

    revert();

    expect(a.shadowRoot.getElementById('aSibling')).not.toHaveAttribute('aria-hidden');
    expect(b.shadowRoot.getElementById('bSibling')).not.toHaveAttribute('aria-hidden');
    expect(light).not.toHaveAttribute('aria-hidden');
  });

  it('should restore shadow root aria-hidden and stop observing shadow roots on revert', async function () {
    let container = createContainer();
    let light = document.createElement('input');
    container.appendChild(light);
    let {shadowRoot} = createShadowRoot(container);
    shadowRoot.innerHTML = '<input id="sibling" type="checkbox"><button id="target">Button</button>';
    let sibling = shadowRoot.getElementById('sibling');
    let target = shadowRoot.getElementById('target');

    let revert = ariaHideOutside([target]);
    expect(sibling).toHaveAttribute('aria-hidden', 'true');
    expect(light).toHaveAttribute('aria-hidden', 'true');

    revert();

    expect(sibling).not.toHaveAttribute('aria-hidden');
    expect(light).not.toHaveAttribute('aria-hidden');

    let added = document.createElement('input');
    shadowRoot.appendChild(added);
    await act(() => new Promise(r => setTimeout(r, 0))); // Wait for mutation observer tick
    expect(added).not.toHaveAttribute('aria-hidden');
  });

  it('should re-observe the shadow roots of an outer call when a nested call is restored', async function () {
    let container = createContainer();
    let {shadowRoot} = createShadowRoot(container);
    shadowRoot.innerHTML = '<input id="sibling" type="checkbox"><button id="target">Button</button>';
    let target = shadowRoot.getElementById('target');
    let button = document.createElement('button');
    container.appendChild(button);

    let revert1 = ariaHideOutside([target]);
    let revert2 = ariaHideOutside([button]);

    // The nested call stops observing the shadow root, so content added to it is not hidden.
    let ignored = document.createElement('input');
    shadowRoot.appendChild(ignored);
    await act(() => new Promise(r => setTimeout(r, 0))); // Wait for mutation observer tick
    expect(ignored).not.toHaveAttribute('aria-hidden');

    revert2();

    // Restoring the nested call observes the shadow root again.
    let added = document.createElement('input');
    shadowRoot.appendChild(added);
    await waitFor(() => expect(added).toHaveAttribute('aria-hidden', 'true'));

    revert1();

    expect(shadowRoot.getElementById('sibling')).not.toHaveAttribute('aria-hidden');
    expect(added).not.toHaveAttribute('aria-hidden');
    expect(ignored).not.toHaveAttribute('aria-hidden');
    expect(button).not.toHaveAttribute('aria-hidden');
  });

  it('should hide siblings of targets that are direct children of a shadow root, once per root', function () {
    let container = createContainer();
    let {shadowRoot} = createShadowRoot(container);
    shadowRoot.innerHTML = '<input id="sibling" type="checkbox"><button id="first">One</button><button id="second">Two</button>';
    let sibling = shadowRoot.getElementById('sibling');
    let first = shadowRoot.getElementById('first');
    let second = shadowRoot.getElementById('second');
    expect(first.parentElement).toBeNull();

    let revert = ariaHideOutside([first, second]);

    expect(sibling).toHaveAttribute('aria-hidden', 'true');
    expect(first).not.toHaveAttribute('aria-hidden');
    expect(second).not.toHaveAttribute('aria-hidden');

    revert();

    expect(sibling).not.toHaveAttribute('aria-hidden');
    expect(first).not.toHaveAttribute('aria-hidden');
    expect(second).not.toHaveAttribute('aria-hidden');
  });

  it('should not walk or hide anything when the shadow root host is outside root', async function () {
    let container = createContainer();
    let root = document.createElement('div');
    container.appendChild(root);
    let outsideLight = document.createElement('input');
    container.appendChild(outsideLight);
    let {shadowRoot} = createShadowRoot(container);
    shadowRoot.innerHTML = '<input id="sibling" type="checkbox"><button id="target">Button</button>';
    let sibling = shadowRoot.getElementById('sibling');
    let target = shadowRoot.getElementById('target');

    let revert = ariaHideOutside([target], {root});

    expect(root).toHaveAttribute('aria-hidden', 'true');
    expect(sibling).not.toHaveAttribute('aria-hidden');
    expect(outsideLight).not.toHaveAttribute('aria-hidden');

    let added = document.createElement('input');
    shadowRoot.appendChild(added);
    await act(() => new Promise(r => setTimeout(r, 0))); // Wait for mutation observer tick
    expect(added).not.toHaveAttribute('aria-hidden');

    revert();

    expect(root).not.toHaveAttribute('aria-hidden');
    expect(sibling).not.toHaveAttribute('aria-hidden');
  });

  it('should not double count an element added inside a newly hidden element in a shadow root', async function () {
    let container = createContainer();
    let {shadowRoot} = createShadowRoot(container);
    shadowRoot.innerHTML = '<button id="target">Button</button>';
    let target = shadowRoot.getElementById('target');

    let revert = ariaHideOutside([target]);

    let parent = document.createElement('div');
    let child = document.createElement('input');
    shadowRoot.appendChild(parent);
    parent.appendChild(child);

    await waitFor(() => expect(parent).toHaveAttribute('aria-hidden', 'true'));
    expect(child).not.toHaveAttribute('aria-hidden');

    revert();

    expect(parent).not.toHaveAttribute('aria-hidden');
    expect(child).not.toHaveAttribute('aria-hidden');
  });

  it('should use inert for shadow root siblings when shouldUseInert is set', function () {
    // jsdom does not implement inert, and ariaHideOutside checks for it when the module loads.
    // Stub the property and load a fresh copy of the module (with its own flags) that sees it.
    Object.defineProperty(HTMLElement.prototype, 'inert', {configurable: true, writable: true, value: false});
    let ariaHideOutsideWithInert;
    jest.isolateModules(() => {
      require('@react-stately/flags').enableShadowDOM();
      ariaHideOutsideWithInert = require('../src').ariaHideOutside;
    });

    try {
      let container = createContainer();
      let {shadowRoot} = createShadowRoot(container);
      shadowRoot.innerHTML = '<input id="sibling" type="checkbox"><button id="target">Button</button>';
      let sibling = shadowRoot.getElementById('sibling');
      let target = shadowRoot.getElementById('target');

      let revert = ariaHideOutsideWithInert([target], {shouldUseInert: true});

      expect(sibling.inert).toBe(true);
      expect(sibling).not.toHaveAttribute('aria-hidden');
      expect(target.inert).toBe(false);

      revert();

      expect(sibling.inert).toBe(false);
    } finally {
      delete HTMLElement.prototype.inert;
    }
  });

  it('should keep light DOM children slotted into a target visible', function () {
    let container = createContainer();
    let {shadowHost, shadowRoot} = createShadowRoot(container);
    shadowRoot.innerHTML = '<div role="dialog" id="dlg"><button id="t"></button><slot></slot></div>';
    let dialog = shadowRoot.getElementById('dlg');
    let light = document.createElement('p');
    shadowHost.appendChild(light);

    let revert = ariaHideOutside([dialog]);

    expect(light).not.toHaveAttribute('aria-hidden');
    expect(shadowHost).not.toHaveAttribute('aria-hidden');
    expect(shadowRoot.getElementById('t')).not.toHaveAttribute('aria-hidden');

    revert();

    expect(light).not.toHaveAttribute('aria-hidden');
  });

  it('should keep light DOM children added later and slotted into a target visible', async function () {
    let container = createContainer();
    let {shadowHost, shadowRoot} = createShadowRoot(container);
    shadowRoot.innerHTML = '<div role="dialog" id="dlg"><button id="t"></button><slot></slot></div>';
    let dialog = shadowRoot.getElementById('dlg');

    let revert = ariaHideOutside([dialog]);

    let light = document.createElement('p');
    shadowHost.appendChild(light);
    let sibling = document.createElement('input');
    shadowRoot.appendChild(sibling);

    await act(() => new Promise(r => setTimeout(r, 0))); // Wait for mutation observer tick
    expect(sibling).toHaveAttribute('aria-hidden', 'true');
    expect(light).not.toHaveAttribute('aria-hidden');

    revert();

    expect(light).not.toHaveAttribute('aria-hidden');
    expect(sibling).not.toHaveAttribute('aria-hidden');
  });

  it('should restore every aria-hidden when a light DOM child is slotted outside the target', function () {
    let container = createContainer();
    let {shadowHost, shadowRoot} = createShadowRoot(container);
    shadowRoot.innerHTML = '<div role="dialog" id="dlg"><button id="t"></button></div><slot name="other"></slot>';
    let dialog = shadowRoot.getElementById('dlg');
    let light = document.createElement('p');
    light.setAttribute('slot', 'other');
    shadowHost.appendChild(light);

    let revert = ariaHideOutside([dialog]);
    revert();

    expect(light).not.toHaveAttribute('aria-hidden');
    expect(shadowRoot.querySelectorAll('[aria-hidden]')).toHaveLength(0);
    expect(shadowHost).not.toHaveAttribute('aria-hidden');
  });

  it('should skip null targets when shadow DOM is enabled', function () {
    let container = createContainer();
    let {shadowRoot} = createShadowRoot(container);
    shadowRoot.innerHTML = '<input id="sibling" type="checkbox"><button id="target">Button</button>';
    let sibling = shadowRoot.getElementById('sibling');
    let target = shadowRoot.getElementById('target');

    let revert;
    expect(() => {
      revert = ariaHideOutside([null, target]);
    }).not.toThrow();

    expect(sibling).toHaveAttribute('aria-hidden', 'true');
    expect(target).not.toHaveAttribute('aria-hidden');

    revert();

    expect(sibling).not.toHaveAttribute('aria-hidden');
  });
});

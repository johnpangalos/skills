/*
 * Copyright 2020 Adobe. All rights reserved.
 * This file is licensed to you under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License. You may obtain a copy
 * of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software distributed under
 * the License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR REPRESENTATIONS
 * OF ANY KIND, either express or implied. See the License for the specific language
 * governing permissions and limitations under the License.
 */

import {act, createShadowRoot, render, waitFor} from '@react-spectrum/test-utils-internal';
import {ariaHideOutside} from '../src';
import {enableShadowDOM} from '@react-stately/flags';
import React, {useRef, useState} from 'react';

describe('ariaHideOutside', function () {
  it('should hide everything except the provided element [button]', function () {
    let {getByRole, getAllByRole} = render(
      <>
        <input type="checkbox" />
        <button>Button</button>
        <input type="checkbox" />
      </>
    );

    let checkboxes = getAllByRole('checkbox');
    let button = getByRole('button');

    let revert = ariaHideOutside([button]);

    expect(checkboxes[0]).toHaveAttribute('aria-hidden', 'true');
    expect(checkboxes[1]).toHaveAttribute('aria-hidden', 'true');
    expect(button).not.toHaveAttribute('aria-hidden');

    expect(() => getAllByRole('checkbox')).toThrow();
    expect(() => getByRole('button')).not.toThrow();

    revert();

    expect(checkboxes[0]).not.toHaveAttribute('aria-hidden');
    expect(checkboxes[1]).not.toHaveAttribute('aria-hidden');
    expect(button).not.toHaveAttribute('aria-hidden');

    expect(() => getAllByRole('checkbox')).not.toThrow();
    expect(() => getByRole('button')).not.toThrow();
  });

  it('should hide everything except multiple elements', function () {
    let {getByRole, getAllByRole, queryByRole, queryAllByRole} = render(
      <>
        <input type="checkbox" />
        <button>Button</button>
        <input type="checkbox" />
      </>
    );

    let checkboxes = getAllByRole('checkbox');
    let button = getByRole('button');

    let revert = ariaHideOutside(checkboxes);

    expect(checkboxes[0]).not.toHaveAttribute('aria-hidden', 'true');
    expect(checkboxes[1]).not.toHaveAttribute('aria-hidden', 'true');
    expect(button).toHaveAttribute('aria-hidden');

    expect(queryAllByRole('checkbox')).not.toBeNull();
    expect(queryByRole('button')).toBeNull();

    revert();

    expect(checkboxes[0]).not.toHaveAttribute('aria-hidden');
    expect(checkboxes[1]).not.toHaveAttribute('aria-hidden');
    expect(button).not.toHaveAttribute('aria-hidden');

    expect(() => getAllByRole('checkbox')).not.toThrow();
    expect(() => getByRole('button')).not.toThrow();
  });

  it('should not traverse into an already hidden container', function () {
    let {getByRole, getAllByRole} = render(
      <>
        <div>
          <input type="checkbox" />
        </div>
        <button>Button</button>
        <input type="checkbox" />
      </>
    );

    let checkboxes = getAllByRole('checkbox');
    let button = getByRole('button');

    let revert = ariaHideOutside([button]);

    expect(checkboxes[0].parentElement).toHaveAttribute('aria-hidden', 'true');
    expect(checkboxes[1]).toHaveAttribute('aria-hidden', 'true');
    expect(button).not.toHaveAttribute('aria-hidden');

    expect(() => getAllByRole('checkbox')).toThrow();
    expect(() => getByRole('button')).not.toThrow();

    revert();

    expect(checkboxes[0].parentElement).not.toHaveAttribute('aria-hidden');
    expect(checkboxes[1]).not.toHaveAttribute('aria-hidden');
    expect(button).not.toHaveAttribute('aria-hidden');

    expect(() => getAllByRole('checkbox')).not.toThrow();
    expect(() => getByRole('button')).not.toThrow();
  });

  it('should not overwrite an existing aria-hidden prop', function () {
    let {getByRole, getAllByRole} = render(
      <>
        <input type="checkbox" aria-hidden="true" />
        <button>Button</button>
        <input type="checkbox" />
      </>
    );

    let checkboxes = getAllByRole('checkbox');
    let button = getByRole('button');

    let revert = ariaHideOutside([button]);

    expect(checkboxes).toHaveLength(1);
    expect(checkboxes[0]).toHaveAttribute('aria-hidden', 'true');
    expect(button).not.toHaveAttribute('aria-hidden');

    expect(() => getAllByRole('checkbox')).toThrow();
    expect(() => getByRole('button')).not.toThrow();

    revert();

    checkboxes = getAllByRole('checkbox');
    expect(checkboxes).toHaveLength(1);
    expect(checkboxes[0]).not.toHaveAttribute('aria-hidden');
    expect(button).not.toHaveAttribute('aria-hidden');

    expect(() => getAllByRole('checkbox')).not.toThrow();
    expect(() => getByRole('button')).not.toThrow();
  });

  it('should handle when a new element is added outside while active', async function () {
    let Test = props => (
      <>
        {props.show && <input type="checkbox" />}
        <button>Button</button>
        {props.show && <input type="checkbox" />}
      </>
    );

    let {getByRole, getAllByRole, rerender} = render(<Test />);

    let button = getByRole('button');
    expect(() => getAllByRole('checkbox')).toThrow();

    let revert = ariaHideOutside([button]);

    rerender(<Test show />);

    // MutationObserver is async
    await waitFor(() => expect(() => getAllByRole('checkbox')).toThrow());
    expect(() => getByRole('button')).not.toThrow();

    revert();

    expect(getAllByRole('checkbox')).toHaveLength(2);
  });

  it('should handle when a new element is added to an already hidden container', async function () {
    let Test = props => (
      <>
        <div data-testid="test">
          {props.show && <input type="checkbox" />}
        </div>
        <button>Button</button>
        {props.show && <input type="checkbox" />}
      </>
    );

    let {getByRole, getAllByRole, getByTestId, rerender} = render(<Test />);

    let button = getByRole('button');
    let test = getByTestId('test');
    expect(() => getAllByRole('checkbox')).toThrow();

    let revert = ariaHideOutside([button]);

    expect(test).toHaveAttribute('aria-hidden');

    rerender(<Test show />);

    // MutationObserver is async
    await waitFor(() => expect(() => getAllByRole('checkbox')).toThrow());
    expect(() => getByRole('button')).not.toThrow();

    let checkboxes = getAllByRole('checkbox', {hidden: true});
    expect(test).toHaveAttribute('aria-hidden');
    expect(checkboxes[0]).not.toHaveAttribute('aria-hidden');
    expect(checkboxes[1]).toHaveAttribute('aria-hidden', 'true');

    revert();

    expect(getAllByRole('checkbox')).toHaveLength(2);
  });

  it('should handle when a new element is added along with a top layer element', async function () {
    let Test = props => (
      <>
        <button>Button</button>
        {props.show && <div>
          <div role="alert" data-react-aria-top-layer="true">Top layer</div>
          <input type="checkbox" />
        </div>}
      </>
    );

    let {getByRole, queryByRole, getAllByRole, rerender} = render(<Test />);

    let button = getByRole('button');
    expect(queryByRole('checkbox')).toBeNull();

    let revert = ariaHideOutside([button]);

    rerender(<Test show />);

    // MutationObserver is async
    await waitFor(() => queryByRole('checkbox') == null);
    expect(queryByRole('button')).not.toBeNull();
    expect(getByRole('alert')).toHaveTextContent('Top layer');

    revert();

    expect(getAllByRole('checkbox')).toHaveLength(1);
  });

  it('should handle when a new element is added inside a target element', async function () {
    let Test = props => (
      <>
        <input type="checkbox" />
        <div data-testid="test">
          <button>Button</button>
          {props.show && <input type="radio" />}
        </div>
        <input type="checkbox" />
      </>
    );

    let {queryByRole, getByRole, getAllByRole, getByTestId, rerender} = render(<Test />);

    let test = getByTestId('test');
    let revert = ariaHideOutside([test]);

    expect(() => getAllByRole('checkbox')).toThrow();
    expect(queryByRole('radio')).toBeNull();
    expect(queryByRole('button')).not.toBeNull();
    expect(() => getByTestId('test')).not.toThrow();

    rerender(<Test show />);

    // Wait for mutation observer tick
    await Promise.resolve();
    expect(() => getAllByRole('checkbox')).toThrow();
    expect(() => getByRole('radio')).not.toThrow();
    expect(() => getByRole('button')).not.toThrow();
    expect(() => getByTestId('test')).not.toThrow();

    revert();

    expect(() => getAllByRole('checkbox')).not.toThrow();
    expect(() => getByRole('radio')).not.toThrow();
    expect(() => getByRole('button')).not.toThrow();
    expect(() => getByTestId('test')).not.toThrow();
  });

  it('should handle when a new element is added and then reparented', async function () {

    let Test = () => {
      const ref = useRef(null);
      const mutate = () => {
        let parent = document.createElement('ul');
        let child = document.createElement('li');
        ref.current.append(parent);
        parent.appendChild(child);
        parent.remove(); // this results in a mutation record for a disconnected ul with a connected li (through the new ul parent) in `addedNodes`
        let newParent = document.createElement('ul');
        newParent.appendChild(child);
        ref.current.append(newParent);
      };

      return (
        <>
          <div data-testid="test" ref={ref}>
            <button onClick={mutate}>Mutate</button>
          </div>
        </>
      );
    };

    let {queryByRole, getAllByRole, getByTestId} = render(<Test />);

    ariaHideOutside([getByTestId('test')]);

    queryByRole('button').click();
    await Promise.resolve(); // Wait for mutation observer tick

    expect(getAllByRole('listitem')).toHaveLength(1);
  });

  it('should handle when a new element is added and then reparented to a hidden container', async function () {

    let Test = () => {
      const ref = useRef(null);
      const mutate = () => {
        let parent = document.createElement('ul');
        let child = document.createElement('li');
        ref.current.append(parent);
        parent.appendChild(child);
        parent.remove(); // this results in a mutation record for a disconnected ul with a connected li (through the new ul parent) in `addedNodes`
        let newParent = document.createElement('ul');
        newParent.appendChild(child);
        ref.current.append(newParent);
      };

      return (
        <>
          <div data-testid="test">
            <button onClick={mutate}>Mutate</button>
          </div>
          <div data-testid="sibling" ref={ref} />
        </>
      );
    };

    let {queryByRole, queryAllByRole, getByTestId} = render(<Test />);

    ariaHideOutside([getByTestId('test')]);

    queryByRole('button').click();
    await Promise.resolve(); // Wait for mutation observer tick

    expect(queryAllByRole('listitem')).toHaveLength(0);
  });


  it('work when called multiple times', function () {
    let {getByRole, getAllByRole} = render(
      <>
        <input type="checkbox" />
        <input type="radio" />
        <button>Button</button>
        <input type="radio" />
        <input type="checkbox" />
      </>
    );

    let radios = getAllByRole('radio');
    let button = getByRole('button');

    let revert1 = ariaHideOutside([button, ...radios]);

    expect(() => getAllByRole('checkbox')).toThrow();
    expect(() => getAllByRole('radio')).not.toThrow();
    expect(() => getByRole('button')).not.toThrow();

    let revert2 = ariaHideOutside([button]);

    expect(() => getAllByRole('checkbox')).toThrow();
    expect(() => getAllByRole('radio')).toThrow();
    expect(() => getByRole('button')).not.toThrow();

    revert2();

    expect(() => getAllByRole('checkbox')).toThrow();
    expect(() => getAllByRole('radio')).not.toThrow();
    expect(() => getByRole('button')).not.toThrow();

    revert1();

    expect(() => getAllByRole('checkbox')).not.toThrow();
    expect(() => getAllByRole('radio')).not.toThrow();
    expect(() => getByRole('button')).not.toThrow();
  });

  it('work when called multiple times and restored out of order', function () {
    let {getByRole, getAllByRole} = render(
      <>
        <input type="checkbox" />
        <input type="radio" />
        <button>Button</button>
        <input type="radio" />
        <input type="checkbox" />
      </>
    );

    let radios = getAllByRole('radio');
    let button = getByRole('button');

    let revert1 = ariaHideOutside([button, ...radios]);

    expect(() => getAllByRole('checkbox')).toThrow();
    expect(() => getAllByRole('radio')).not.toThrow();
    expect(() => getByRole('button')).not.toThrow();

    let revert2 = ariaHideOutside([button]);

    expect(() => getAllByRole('checkbox')).toThrow();
    expect(() => getAllByRole('radio')).toThrow();
    expect(() => getByRole('button')).not.toThrow();

    revert1();

    expect(() => getAllByRole('checkbox')).toThrow();
    expect(() => getAllByRole('radio')).toThrow();
    expect(() => getByRole('button')).not.toThrow();

    revert2();

    expect(() => getAllByRole('checkbox')).not.toThrow();
    expect(() => getAllByRole('radio')).not.toThrow();
    expect(() => getByRole('button')).not.toThrow();
  });

  it('should hide everything except the provided element [row]', function () {
    let {getAllByRole, getByTestId} = render(
      <div role="grid">
        <div role="row">
          <div role="gridcell">
            <span data-testid="test-span">
              Cell 1
            </span></div>
        </div>
        <div role="row">
          <div role="gridcell">Cell 2</div>
        </div>
      </div>
    );

    let cells = getAllByRole('gridcell');
    let rows = getAllByRole('row');
    let span = getByTestId('test-span');

    let revert = ariaHideOutside([rows[1]]);

    // Applies aria-hidden to the row and cell despite recursive nature of aria-hidden
    // for https://bugs.webkit.org/show_bug.cgi?id=222623
    expect(rows[0]).toHaveAttribute('aria-hidden', 'true');
    expect(cells[0]).toHaveAttribute('aria-hidden', 'true');
    expect(span).not.toHaveAttribute('aria-hidden');
    expect(rows[1]).not.toHaveAttribute('aria-hidden', 'true');
    expect(cells[1]).not.toHaveAttribute('aria-hidden', 'true');

    revert();

    expect(rows[0]).not.toHaveAttribute('aria-hidden', 'true');
    expect(cells[0]).not.toHaveAttribute('aria-hidden', 'true');
    expect(rows[1]).not.toHaveAttribute('aria-hidden', 'true');
    expect(cells[1]).not.toHaveAttribute('aria-hidden', 'true');
    expect(span).not.toHaveAttribute('aria-hidden');
  });

  it('should unhide after item reorder', async function () {
    function Item(props) {
      return (
        <div role="presentation">
          <div data-testid={props.testid} role="row">
            <div role="gridcell" />
          </div>
        </div>
      );
    }

    function Test() {
      let [count, setCount] = useState(0);
      let items = ['row1', 'row2', 'row3', 'row4', 'row5'];
      if (count === 1) {
        items = ['row2', 'row1', 'row3', 'row4', 'row5'];
      } else if (count === 2) {
        items = ['row2', 'row3', 'row1', 'row4', 'row5'];
      }

      return (
        <>
          <button onClick={() => setCount((old) => old + 1)}>press</button>
          {items.map((item) => <Item testid={item} key={item} />)}
        </>

      );
    }

    let {getByRole, getByTestId} = render(
      <Test />
    );

    let button = getByRole('button');
    let row = getByTestId('row1');
    let revert = ariaHideOutside([button]);

    act(() => button.click());
    await Promise.resolve();
    act(() => button.click());
    await Promise.resolve();
    revert();
    expect(row.parentElement).not.toHaveAttribute('aria-hidden', 'true');
  });

  it('does not hide or observe shadow roots when shadowDOM is off', async function () {
    let {shadowRoot, cleanup} = createShadowRoot();
    shadowRoot.innerHTML = '<button id="target">Button</button><input id="sibling" />';
    let outside = document.createElement('input');
    document.body.appendChild(outside);
    let target = shadowRoot.getElementById('target');

    let revert = ariaHideOutside([target]);

    expect(shadowRoot.getElementById('sibling')).not.toHaveAttribute('aria-hidden');
    expect(target).not.toHaveAttribute('aria-hidden');

    let added = document.createElement('input');
    shadowRoot.appendChild(added);
    await Promise.resolve();
    expect(added).not.toHaveAttribute('aria-hidden');

    revert();
    outside.remove();
    cleanup();
  });
});

describe('ariaHideOutside with Shadow DOM', function () {
  let cleanups = [];

  beforeAll(() => {
    enableShadowDOM();
  });

  afterEach(() => {
    for (let cleanup of cleanups.reverse()) {
      cleanup();
    }
    cleanups = [];
  });

  let shadowRootIn = (attachTo) => {
    let {shadowHost, shadowRoot, cleanup} = createShadowRoot(attachTo);
    cleanups.push(cleanup);
    return {shadowHost, shadowRoot};
  };

  let appendToBody = (tagName) => {
    let element = document.createElement(tagName);
    document.body.appendChild(element);
    cleanups.push(() => element.remove());
    return element;
  };

  it('hides siblings of the target inside its shadow root and body siblings of the host', function () {
    let {shadowHost, shadowRoot} = shadowRootIn();
    shadowRoot.innerHTML = '<input id="before" /><button id="target">Button</button><input id="after" />';
    let outside = appendToBody('input');
    let target = shadowRoot.getElementById('target');

    let revert = ariaHideOutside([target]);

    expect(shadowRoot.getElementById('before')).toHaveAttribute('aria-hidden', 'true');
    expect(shadowRoot.getElementById('after')).toHaveAttribute('aria-hidden', 'true');
    expect(outside).toHaveAttribute('aria-hidden', 'true');
    expect(shadowHost).not.toHaveAttribute('aria-hidden');
    expect(target).not.toHaveAttribute('aria-hidden');

    revert();
  });

  it('hides siblings at every shadow level around a deeply nested target', function () {
    let {shadowHost: hostA, shadowRoot: rootA} = shadowRootIn();
    rootA.innerHTML = '<input id="sibling-a" />';
    let {shadowHost: hostB, shadowRoot: rootB} = shadowRootIn(rootA);
    rootB.innerHTML = '<input id="sibling-b" /><button id="target">Button</button>';
    let target = rootB.getElementById('target');

    let revert = ariaHideOutside([target]);

    expect(rootA.getElementById('sibling-a')).toHaveAttribute('aria-hidden', 'true');
    expect(rootB.getElementById('sibling-b')).toHaveAttribute('aria-hidden', 'true');
    expect(hostA).not.toHaveAttribute('aria-hidden');
    expect(hostB).not.toHaveAttribute('aria-hidden');
    expect(target).not.toHaveAttribute('aria-hidden');

    revert();
  });

  it('leaves the shadow content of a target that is a shadow host untouched', function () {
    let {shadowHost: target, shadowRoot: targetRoot} = shadowRootIn();
    targetRoot.innerHTML = '<button id="inner">Inner</button>';
    let outside = appendToBody('input');

    let revert = ariaHideOutside([target]);

    expect(outside).toHaveAttribute('aria-hidden', 'true');
    expect(target).not.toHaveAttribute('aria-hidden');
    expect(targetRoot.getElementById('inner')).not.toHaveAttribute('aria-hidden');

    revert();
  });

  it('does not hide the shadow root of a host whose light DOM child is the target', function () {
    let {shadowHost: host, shadowRoot} = shadowRootIn();
    shadowRoot.innerHTML = '<div id="wrapper"><slot></slot></div><span id="shadow-sibling">Shadow</span>';
    let slotted = document.createElement('input');
    host.appendChild(slotted);
    let outside = appendToBody('input');

    let revert = ariaHideOutside([slotted]);

    expect(shadowRoot.getElementById('wrapper')).not.toHaveAttribute('aria-hidden');
    expect(shadowRoot.querySelector('slot')).not.toHaveAttribute('aria-hidden');
    expect(shadowRoot.getElementById('shadow-sibling')).not.toHaveAttribute('aria-hidden');
    expect(host).not.toHaveAttribute('aria-hidden');
    expect(slotted).not.toHaveAttribute('aria-hidden');
    expect(outside).toHaveAttribute('aria-hidden', 'true');

    revert();
  });

  it('hides elements added to the target shadow root after the call', async function () {
    let {shadowRoot} = shadowRootIn();
    shadowRoot.innerHTML = '<button id="target">Button</button>';
    let target = shadowRoot.getElementById('target');

    let revert = ariaHideOutside([target]);

    let added = document.createElement('input');
    shadowRoot.appendChild(added);
    await Promise.resolve(); // Wait for mutation observer tick
    expect(added).toHaveAttribute('aria-hidden', 'true');
    expect(target).not.toHaveAttribute('aria-hidden');

    revert();
  });

  it('hides elements added to every enclosing shadow root, including the nested one', async function () {
    let {shadowRoot: rootA} = shadowRootIn();
    let {shadowRoot: rootB} = shadowRootIn(rootA);
    rootB.innerHTML = '<button id="target">Button</button>';
    let target = rootB.getElementById('target');

    let revert = ariaHideOutside([target]);

    let addedA = document.createElement('input');
    let addedB = document.createElement('input');
    rootA.appendChild(addedA);
    rootB.appendChild(addedB);
    await Promise.resolve(); // Wait for mutation observer tick
    expect(addedA).toHaveAttribute('aria-hidden', 'true');
    expect(addedB).toHaveAttribute('aria-hidden', 'true');

    revert();
  });

  it('does not hide elements added inside the target', async function () {
    let {shadowRoot} = shadowRootIn();
    shadowRoot.innerHTML = '<div id="target"></div>';
    let target = shadowRoot.getElementById('target');

    let revert = ariaHideOutside([target]);

    let added = document.createElement('input');
    target.appendChild(added);
    await Promise.resolve(); // Wait for mutation observer tick
    expect(added).not.toHaveAttribute('aria-hidden');

    revert();
  });

  it('keeps live announcer and top layer elements added to a shadow root visible', async function () {
    let {shadowRoot} = shadowRootIn();
    shadowRoot.innerHTML = '<button id="target">Button</button>';
    let target = shadowRoot.getElementById('target');

    let revert = ariaHideOutside([target]);

    let announcer = document.createElement('div');
    announcer.dataset.liveAnnouncer = 'true';
    let topLayer = document.createElement('div');
    topLayer.dataset.reactAriaTopLayer = 'true';
    let added = document.createElement('input');
    shadowRoot.append(announcer, topLayer, added);
    await Promise.resolve(); // Wait for mutation observer tick
    expect(added).toHaveAttribute('aria-hidden', 'true');
    expect(announcer).not.toHaveAttribute('aria-hidden');
    expect(topLayer).not.toHaveAttribute('aria-hidden');

    revert();
  });

  it('does not hide a new child of a container already hidden in a shadow root', async function () {
    let {shadowRoot} = shadowRootIn();
    shadowRoot.innerHTML = '<div id="container"></div><button id="target">Button</button>';
    let container = shadowRoot.getElementById('container');
    let target = shadowRoot.getElementById('target');

    let revert = ariaHideOutside([target]);
    expect(container).toHaveAttribute('aria-hidden', 'true');

    let added = document.createElement('input');
    container.appendChild(added);
    await Promise.resolve(); // Wait for mutation observer tick
    expect(added).not.toHaveAttribute('aria-hidden');
    expect(container).toHaveAttribute('aria-hidden', 'true');

    revert();
  });

  it('keeps live announcer and top layer elements already in a shadow root visible', function () {
    let {shadowRoot} = shadowRootIn();
    shadowRoot.innerHTML = '<div id="announcer" data-live-announcer="true"></div><div id="toast" data-react-aria-top-layer="true"></div><button id="target">Button</button>';

    let revert = ariaHideOutside([shadowRoot.getElementById('target')]);

    expect(shadowRoot.getElementById('announcer')).not.toHaveAttribute('aria-hidden');
    expect(shadowRoot.getElementById('toast')).not.toHaveAttribute('aria-hidden');

    revert();
  });

  let twoShadowRoots = () => {
    let {shadowHost: hostOne, shadowRoot: rootOne} = shadowRootIn();
    let {shadowHost: hostTwo, shadowRoot: rootTwo} = shadowRootIn();
    rootOne.innerHTML = '<input id="sibling-one" /><input id="target-one" />';
    rootTwo.innerHTML = '<input id="sibling-two" /><button id="target-two">Popover</button>';
    return {
      hostOne,
      hostTwo,
      rootOne,
      rootTwo,
      targets: [rootOne.getElementById('target-one'), rootTwo.getElementById('target-two')]
    };
  };

  it('hides siblings in each shadow root when targets are in different shadow roots', function () {
    let {hostOne, hostTwo, rootOne, rootTwo, targets} = twoShadowRoots();
    let outside = appendToBody('input');

    let revert = ariaHideOutside(targets);

    expect(rootOne.getElementById('sibling-one')).toHaveAttribute('aria-hidden', 'true');
    expect(rootTwo.getElementById('sibling-two')).toHaveAttribute('aria-hidden', 'true');
    expect(outside).toHaveAttribute('aria-hidden', 'true');
    expect(hostOne).not.toHaveAttribute('aria-hidden');
    expect(hostTwo).not.toHaveAttribute('aria-hidden');
    expect(targets[0]).not.toHaveAttribute('aria-hidden');
    expect(targets[1]).not.toHaveAttribute('aria-hidden');

    revert();
  });

  it('hides elements added to either shadow root while active', async function () {
    let {rootOne, rootTwo, targets} = twoShadowRoots();

    let revert = ariaHideOutside(targets);

    let addedOne = document.createElement('input');
    let addedTwo = document.createElement('input');
    rootOne.appendChild(addedOne);
    rootTwo.appendChild(addedTwo);
    await Promise.resolve(); // Wait for mutation observer tick
    expect(addedOne).toHaveAttribute('aria-hidden', 'true');
    expect(addedTwo).toHaveAttribute('aria-hidden', 'true');

    revert();
  });

  it('restores every shadow root element and stops observing on revert', async function () {
    let {shadowRoot} = shadowRootIn();
    shadowRoot.innerHTML = '<input id="before" /><button id="target">Button</button>';
    let outside = appendToBody('input');
    let before = shadowRoot.getElementById('before');

    let revert = ariaHideOutside([shadowRoot.getElementById('target')]);
    expect(before).toHaveAttribute('aria-hidden', 'true');
    expect(outside).toHaveAttribute('aria-hidden', 'true');

    revert();
    expect(before).not.toHaveAttribute('aria-hidden');
    expect(outside).not.toHaveAttribute('aria-hidden');

    let added = document.createElement('input');
    shadowRoot.appendChild(added);
    await Promise.resolve(); // Wait for mutation observer tick
    expect(added).not.toHaveAttribute('aria-hidden');
  });

  it('resumes the outer observer after a nested call in a shadow root is reverted', async function () {
    let {shadowRoot} = shadowRootIn();
    shadowRoot.innerHTML = '<input id="sibling" /><button id="outer-target">Outer</button><span id="inner-target">Inner</span>';
    let outside = appendToBody('input');
    let sibling = shadowRoot.getElementById('sibling');
    let outerTarget = shadowRoot.getElementById('outer-target');
    let innerTarget = shadowRoot.getElementById('inner-target');

    let revertOuter = ariaHideOutside([outerTarget]);
    let revertInner = ariaHideOutside([innerTarget]);
    expect(outerTarget).toHaveAttribute('aria-hidden', 'true');
    expect(innerTarget).toHaveAttribute('aria-hidden', 'true');

    revertInner();
    expect(outerTarget).not.toHaveAttribute('aria-hidden');
    expect(innerTarget).toHaveAttribute('aria-hidden', 'true');
    expect(sibling).toHaveAttribute('aria-hidden', 'true');

    let added = document.createElement('input');
    shadowRoot.appendChild(added);
    await Promise.resolve(); // Wait for mutation observer tick
    expect(added).toHaveAttribute('aria-hidden', 'true');

    revertOuter();
    expect(sibling).not.toHaveAttribute('aria-hidden');
    expect(innerTarget).not.toHaveAttribute('aria-hidden');
    expect(outside).not.toHaveAttribute('aria-hidden');
    expect(added).not.toHaveAttribute('aria-hidden');
  });

  it('restores nested calls in a shadow root when reverted out of order', async function () {
    let {shadowRoot} = shadowRootIn();
    shadowRoot.innerHTML = '<input id="sibling" /><button id="outer-target">Outer</button><span id="inner-target">Inner</span>';
    let outside = appendToBody('input');
    let sibling = shadowRoot.getElementById('sibling');
    let outerTarget = shadowRoot.getElementById('outer-target');
    let innerTarget = shadowRoot.getElementById('inner-target');

    let revertOuter = ariaHideOutside([outerTarget]);
    let revertInner = ariaHideOutside([innerTarget]);

    revertOuter();
    expect(outerTarget).toHaveAttribute('aria-hidden', 'true');
    expect(innerTarget).not.toHaveAttribute('aria-hidden');
    expect(sibling).toHaveAttribute('aria-hidden', 'true');
    expect(outside).toHaveAttribute('aria-hidden', 'true');

    let added = document.createElement('input');
    shadowRoot.appendChild(added);
    await Promise.resolve(); // Wait for mutation observer tick
    expect(added).toHaveAttribute('aria-hidden', 'true');

    revertInner();
    expect(outerTarget).not.toHaveAttribute('aria-hidden');
    expect(sibling).not.toHaveAttribute('aria-hidden');
    expect(outside).not.toHaveAttribute('aria-hidden');
    expect(added).not.toHaveAttribute('aria-hidden');
  });

  it('does not remove an aria-hidden that was already in a shadow root', function () {
    let {shadowRoot} = shadowRootIn();
    shadowRoot.innerHTML = '<input id="existing" aria-hidden="true" /><button id="target">Button</button>';

    let revert = ariaHideOutside([shadowRoot.getElementById('target')]);
    revert();

    expect(shadowRoot.getElementById('existing')).toHaveAttribute('aria-hidden', 'true');
  });

  it('does not hide above the root option when the root is inside a shadow root', function () {
    let {shadowRoot} = shadowRootIn();
    shadowRoot.innerHTML = '<input id="outside-root" /><div id="root"><button id="target">Button</button><input id="inside-root" /></div>';
    let target = shadowRoot.getElementById('target');

    let revert = ariaHideOutside([target], {root: shadowRoot.getElementById('root')});

    expect(shadowRoot.getElementById('outside-root')).not.toHaveAttribute('aria-hidden');
    expect(shadowRoot.getElementById('inside-root')).toHaveAttribute('aria-hidden', 'true');
    expect(target).not.toHaveAttribute('aria-hidden');

    revert();
  });
});

/*
 * Copyright 2020 Adobe. All rights reserved.
 * This file is licensed to you under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License. You may obtain a copy
 * of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software distributed under
 * the License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR REPRESENTATIONS
 * OF ANY KIND, either express or implied. See the License for the specific language
 * governing permissions and limitations under the License.
 */

import {act, createShadowRoot, render, waitFor} from '@react-spectrum/test-utils-internal';
import {ariaHideOutside} from '../src';
import {enableShadowDOM} from '@react-stately/flags';
import {keepVisible} from '../src/ariaHideOutside';
import React, {useRef, useState} from 'react';

describe('ariaHideOutside', function () {
  it('should hide everything except the provided element [button]', function () {
    let {getByRole, getAllByRole} = render(
      <>
        <input type="checkbox" />
        <button>Button</button>
        <input type="checkbox" />
      </>
    );

    let checkboxes = getAllByRole('checkbox');
    let button = getByRole('button');

    let revert = ariaHideOutside([button]);

    expect(checkboxes[0]).toHaveAttribute('aria-hidden', 'true');
    expect(checkboxes[1]).toHaveAttribute('aria-hidden', 'true');
    expect(button).not.toHaveAttribute('aria-hidden');

    expect(() => getAllByRole('checkbox')).toThrow();
    expect(() => getByRole('button')).not.toThrow();

    revert();

    expect(checkboxes[0]).not.toHaveAttribute('aria-hidden');
    expect(checkboxes[1]).not.toHaveAttribute('aria-hidden');
    expect(button).not.toHaveAttribute('aria-hidden');

    expect(() => getAllByRole('checkbox')).not.toThrow();
    expect(() => getByRole('button')).not.toThrow();
  });

  it('should hide everything except multiple elements', function () {
    let {getByRole, getAllByRole, queryByRole, queryAllByRole} = render(
      <>
        <input type="checkbox" />
        <button>Button</button>
        <input type="checkbox" />
      </>
    );

    let checkboxes = getAllByRole('checkbox');
    let button = getByRole('button');

    let revert = ariaHideOutside(checkboxes);

    expect(checkboxes[0]).not.toHaveAttribute('aria-hidden', 'true');
    expect(checkboxes[1]).not.toHaveAttribute('aria-hidden', 'true');
    expect(button).toHaveAttribute('aria-hidden');

    expect(queryAllByRole('checkbox')).not.toBeNull();
    expect(queryByRole('button')).toBeNull();

    revert();

    expect(checkboxes[0]).not.toHaveAttribute('aria-hidden');
    expect(checkboxes[1]).not.toHaveAttribute('aria-hidden');
    expect(button).not.toHaveAttribute('aria-hidden');

    expect(() => getAllByRole('checkbox')).not.toThrow();
    expect(() => getByRole('button')).not.toThrow();
  });

  it('should not traverse into an already hidden container', function () {
    let {getByRole, getAllByRole} = render(
      <>
        <div>
          <input type="checkbox" />
        </div>
        <button>Button</button>
        <input type="checkbox" />
      </>
    );

    let checkboxes = getAllByRole('checkbox');
    let button = getByRole('button');

    let revert = ariaHideOutside([button]);

    expect(checkboxes[0].parentElement).toHaveAttribute('aria-hidden', 'true');
    expect(checkboxes[1]).toHaveAttribute('aria-hidden', 'true');
    expect(button).not.toHaveAttribute('aria-hidden');

    expect(() => getAllByRole('checkbox')).toThrow();
    expect(() => getByRole('button')).not.toThrow();

    revert();

    expect(checkboxes[0].parentElement).not.toHaveAttribute('aria-hidden');
    expect(checkboxes[1]).not.toHaveAttribute('aria-hidden');
    expect(button).not.toHaveAttribute('aria-hidden');

    expect(() => getAllByRole('checkbox')).not.toThrow();
    expect(() => getByRole('button')).not.toThrow();
  });

  it('should not overwrite an existing aria-hidden prop', function () {
    let {getByRole, getAllByRole} = render(
      <>
        <input type="checkbox" aria-hidden="true" />
        <button>Button</button>
        <input type="checkbox" />
      </>
    );

    let checkboxes = getAllByRole('checkbox');
    let button = getByRole('button');

    let revert = ariaHideOutside([button]);

    expect(checkboxes).toHaveLength(1);
    expect(checkboxes[0]).toHaveAttribute('aria-hidden', 'true');
    expect(button).not.toHaveAttribute('aria-hidden');

    expect(() => getAllByRole('checkbox')).toThrow();
    expect(() => getByRole('button')).not.toThrow();

    revert();

    checkboxes = getAllByRole('checkbox');
    expect(checkboxes).toHaveLength(1);
    expect(checkboxes[0]).not.toHaveAttribute('aria-hidden');
    expect(button).not.toHaveAttribute('aria-hidden');

    expect(() => getAllByRole('checkbox')).not.toThrow();
    expect(() => getByRole('button')).not.toThrow();
  });

  it('should handle when a new element is added outside while active', async function () {
    let Test = props => (
      <>
        {props.show && <input type="checkbox" />}
        <button>Button</button>
        {props.show && <input type="checkbox" />}
      </>
    );

    let {getByRole, getAllByRole, rerender} = render(<Test />);

    let button = getByRole('button');
    expect(() => getAllByRole('checkbox')).toThrow();

    let revert = ariaHideOutside([button]);

    rerender(<Test show />);

    // MutationObserver is async
    await waitFor(() => expect(() => getAllByRole('checkbox')).toThrow());
    expect(() => getByRole('button')).not.toThrow();

    revert();

    expect(getAllByRole('checkbox')).toHaveLength(2);
  });

  it('should handle when a new element is added to an already hidden container', async function () {
    let Test = props => (
      <>
        <div data-testid="test">
          {props.show && <input type="checkbox" />}
        </div>
        <button>Button</button>
        {props.show && <input type="checkbox" />}
      </>
    );

    let {getByRole, getAllByRole, getByTestId, rerender} = render(<Test />);

    let button = getByRole('button');
    let test = getByTestId('test');
    expect(() => getAllByRole('checkbox')).toThrow();

    let revert = ariaHideOutside([button]);

    expect(test).toHaveAttribute('aria-hidden');

    rerender(<Test show />);

    // MutationObserver is async
    await waitFor(() => expect(() => getAllByRole('checkbox')).toThrow());
    expect(() => getByRole('button')).not.toThrow();

    let checkboxes = getAllByRole('checkbox', {hidden: true});
    expect(test).toHaveAttribute('aria-hidden');
    expect(checkboxes[0]).not.toHaveAttribute('aria-hidden');
    expect(checkboxes[1]).toHaveAttribute('aria-hidden', 'true');

    revert();

    expect(getAllByRole('checkbox')).toHaveLength(2);
  });

  it('should handle when a new element is added along with a top layer element', async function () {
    let Test = props => (
      <>
        <button>Button</button>
        {props.show && <div>
          <div role="alert" data-react-aria-top-layer="true">Top layer</div>
          <input type="checkbox" />
        </div>}
      </>
    );

    let {getByRole, queryByRole, getAllByRole, rerender} = render(<Test />);

    let button = getByRole('button');
    expect(queryByRole('checkbox')).toBeNull();

    let revert = ariaHideOutside([button]);

    rerender(<Test show />);

    // MutationObserver is async
    await waitFor(() => queryByRole('checkbox') == null);
    expect(queryByRole('button')).not.toBeNull();
    expect(getByRole('alert')).toHaveTextContent('Top layer');

    revert();

    expect(getAllByRole('checkbox')).toHaveLength(1);
  });

  it('should handle when a new element is added inside a target element', async function () {
    let Test = props => (
      <>
        <input type="checkbox" />
        <div data-testid="test">
          <button>Button</button>
          {props.show && <input type="radio" />}
        </div>
        <input type="checkbox" />
      </>
    );

    let {queryByRole, getByRole, getAllByRole, getByTestId, rerender} = render(<Test />);

    let test = getByTestId('test');
    let revert = ariaHideOutside([test]);

    expect(() => getAllByRole('checkbox')).toThrow();
    expect(queryByRole('radio')).toBeNull();
    expect(queryByRole('button')).not.toBeNull();
    expect(() => getByTestId('test')).not.toThrow();

    rerender(<Test show />);

    // Wait for mutation observer tick
    await Promise.resolve();
    expect(() => getAllByRole('checkbox')).toThrow();
    expect(() => getByRole('radio')).not.toThrow();
    expect(() => getByRole('button')).not.toThrow();
    expect(() => getByTestId('test')).not.toThrow();

    revert();

    expect(() => getAllByRole('checkbox')).not.toThrow();
    expect(() => getByRole('radio')).not.toThrow();
    expect(() => getByRole('button')).not.toThrow();
    expect(() => getByTestId('test')).not.toThrow();
  });

  it('should handle when a new element is added and then reparented', async function () {

    let Test = () => {
      const ref = useRef(null);
      const mutate = () => {
        let parent = document.createElement('ul');
        let child = document.createElement('li');
        ref.current.append(parent);
        parent.appendChild(child);
        parent.remove(); // this results in a mutation record for a disconnected ul with a connected li (through the new ul parent) in `addedNodes`
        let newParent = document.createElement('ul');
        newParent.appendChild(child);
        ref.current.append(newParent);
      };

      return (
        <>
          <div data-testid="test" ref={ref}>
            <button onClick={mutate}>Mutate</button>
          </div>
        </>
      );
    };

    let {queryByRole, getAllByRole, getByTestId} = render(<Test />);

    ariaHideOutside([getByTestId('test')]);

    queryByRole('button').click();
    await Promise.resolve(); // Wait for mutation observer tick

    expect(getAllByRole('listitem')).toHaveLength(1);
  });

  it('should handle when a new element is added and then reparented to a hidden container', async function () {

    let Test = () => {
      const ref = useRef(null);
      const mutate = () => {
        let parent = document.createElement('ul');
        let child = document.createElement('li');
        ref.current.append(parent);
        parent.appendChild(child);
        parent.remove(); // this results in a mutation record for a disconnected ul with a connected li (through the new ul parent) in `addedNodes`
        let newParent = document.createElement('ul');
        newParent.appendChild(child);
        ref.current.append(newParent);
      };

      return (
        <>
          <div data-testid="test">
            <button onClick={mutate}>Mutate</button>
          </div>
          <div data-testid="sibling" ref={ref} />
        </>
      );
    };

    let {queryByRole, queryAllByRole, getByTestId} = render(<Test />);

    ariaHideOutside([getByTestId('test')]);

    queryByRole('button').click();
    await Promise.resolve(); // Wait for mutation observer tick

    expect(queryAllByRole('listitem')).toHaveLength(0);
  });


  it('work when called multiple times', function () {
    let {getByRole, getAllByRole} = render(
      <>
        <input type="checkbox" />
        <input type="radio" />
        <button>Button</button>
        <input type="radio" />
        <input type="checkbox" />
      </>
    );

    let radios = getAllByRole('radio');
    let button = getByRole('button');

    let revert1 = ariaHideOutside([button, ...radios]);

    expect(() => getAllByRole('checkbox')).toThrow();
    expect(() => getAllByRole('radio')).not.toThrow();
    expect(() => getByRole('button')).not.toThrow();

    let revert2 = ariaHideOutside([button]);

    expect(() => getAllByRole('checkbox')).toThrow();
    expect(() => getAllByRole('radio')).toThrow();
    expect(() => getByRole('button')).not.toThrow();

    revert2();

    expect(() => getAllByRole('checkbox')).toThrow();
    expect(() => getAllByRole('radio')).not.toThrow();
    expect(() => getByRole('button')).not.toThrow();

    revert1();

    expect(() => getAllByRole('checkbox')).not.toThrow();
    expect(() => getAllByRole('radio')).not.toThrow();
    expect(() => getByRole('button')).not.toThrow();
  });

  it('work when called multiple times and restored out of order', function () {
    let {getByRole, getAllByRole} = render(
      <>
        <input type="checkbox" />
        <input type="radio" />
        <button>Button</button>
        <input type="radio" />
        <input type="checkbox" />
      </>
    );

    let radios = getAllByRole('radio');
    let button = getByRole('button');

    let revert1 = ariaHideOutside([button, ...radios]);

    expect(() => getAllByRole('checkbox')).toThrow();
    expect(() => getAllByRole('radio')).not.toThrow();
    expect(() => getByRole('button')).not.toThrow();

    let revert2 = ariaHideOutside([button]);

    expect(() => getAllByRole('checkbox')).toThrow();
    expect(() => getAllByRole('radio')).toThrow();
    expect(() => getByRole('button')).not.toThrow();

    revert1();

    expect(() => getAllByRole('checkbox')).toThrow();
    expect(() => getAllByRole('radio')).toThrow();
    expect(() => getByRole('button')).not.toThrow();

    revert2();

    expect(() => getAllByRole('checkbox')).not.toThrow();
    expect(() => getAllByRole('radio')).not.toThrow();
    expect(() => getByRole('button')).not.toThrow();
  });

  it('should hide everything except the provided element [row]', function () {
    let {getAllByRole, getByTestId} = render(
      <div role="grid">
        <div role="row">
          <div role="gridcell">
            <span data-testid="test-span">
              Cell 1
            </span></div>
        </div>
        <div role="row">
          <div role="gridcell">Cell 2</div>
        </div>
      </div>
    );

    let cells = getAllByRole('gridcell');
    let rows = getAllByRole('row');
    let span = getByTestId('test-span');

    let revert = ariaHideOutside([rows[1]]);

    // Applies aria-hidden to the row and cell despite recursive nature of aria-hidden
    // for https://bugs.webkit.org/show_bug.cgi?id=222623
    expect(rows[0]).toHaveAttribute('aria-hidden', 'true');
    expect(cells[0]).toHaveAttribute('aria-hidden', 'true');
    expect(span).not.toHaveAttribute('aria-hidden');
    expect(rows[1]).not.toHaveAttribute('aria-hidden', 'true');
    expect(cells[1]).not.toHaveAttribute('aria-hidden', 'true');

    revert();

    expect(rows[0]).not.toHaveAttribute('aria-hidden', 'true');
    expect(cells[0]).not.toHaveAttribute('aria-hidden', 'true');
    expect(rows[1]).not.toHaveAttribute('aria-hidden', 'true');
    expect(cells[1]).not.toHaveAttribute('aria-hidden', 'true');
    expect(span).not.toHaveAttribute('aria-hidden');
  });

  it('should unhide after item reorder', async function () {
    function Item(props) {
      return (
        <div role="presentation">
          <div data-testid={props.testid} role="row">
            <div role="gridcell" />
          </div>
        </div>
      );
    }

    function Test() {
      let [count, setCount] = useState(0);
      let items = ['row1', 'row2', 'row3', 'row4', 'row5'];
      if (count === 1) {
        items = ['row2', 'row1', 'row3', 'row4', 'row5'];
      } else if (count === 2) {
        items = ['row2', 'row3', 'row1', 'row4', 'row5'];
      }

      return (
        <>
          <button onClick={() => setCount((old) => old + 1)}>press</button>
          {items.map((item) => <Item testid={item} key={item} />)}
        </>

      );
    }

    let {getByRole, getByTestId} = render(
      <Test />
    );

    let button = getByRole('button');
    let row = getByTestId('row1');
    let revert = ariaHideOutside([button]);

    act(() => button.click());
    await Promise.resolve();
    act(() => button.click());
    await Promise.resolve();
    revert();
    expect(row.parentElement).not.toHaveAttribute('aria-hidden', 'true');
  });

  it('should not hide siblings inside a target shadow root when shadow DOM is disabled', function () {
    let {shadowRoot, cleanup} = createShadowRoot();
    shadowRoot.innerHTML = '<input type="checkbox" /><button>Target</button>';
    let checkbox = shadowRoot.querySelector('input');
    let button = shadowRoot.querySelector('button');

    let revert = ariaHideOutside([button]);

    expect(checkbox).not.toHaveAttribute('aria-hidden');
    expect(button).not.toHaveAttribute('aria-hidden');

    revert();
    cleanup();
  });
});

describe('ariaHideOutside with Shadow DOM', function () {
  let cleanups = [];

  beforeAll(() => {
    enableShadowDOM();
  });

  afterEach(() => {
    for (let cleanup of cleanups) {
      cleanup();
    }
    cleanups = [];
  });

  let createHost = () => {
    let host = createShadowRoot();
    cleanups.push(host.cleanup);
    return host;
  };

  let createNestedHost = (shadowRoot) => {
    let host = document.createElement('div');
    shadowRoot.appendChild(host);
    return {shadowHost: host, shadowRoot: host.attachShadow({mode: 'open'})};
  };

  let createLightCheckbox = () => {
    let checkbox = document.createElement('input');
    checkbox.type = 'checkbox';
    document.body.appendChild(checkbox);
    cleanups.push(() => checkbox.remove());
    return checkbox;
  };

  it('should hide light and shadow DOM siblings but not the target or its host', function () {
    let light = createLightCheckbox();
    let {shadowHost, shadowRoot} = createHost();
    shadowRoot.innerHTML = '<input type="checkbox" /><button>Target</button><input type="radio" />';
    let checkbox = shadowRoot.querySelector('input[type="checkbox"]');
    let radio = shadowRoot.querySelector('input[type="radio"]');
    let button = shadowRoot.querySelector('button');

    let revert = ariaHideOutside([button]);

    expect(light).toHaveAttribute('aria-hidden', 'true');
    expect(checkbox).toHaveAttribute('aria-hidden', 'true');
    expect(radio).toHaveAttribute('aria-hidden', 'true');
    expect(button).not.toHaveAttribute('aria-hidden');
    expect(shadowHost).not.toHaveAttribute('aria-hidden');

    revert();
  });

  it('should hide siblings at every shadow level when the target is nested two shadow roots deep', function () {
    let light = createLightCheckbox();
    let outer = createHost();
    outer.shadowRoot.innerHTML = '<input type="checkbox" />';
    let inner = createNestedHost(outer.shadowRoot);
    inner.shadowRoot.innerHTML = '<input type="radio" /><button>Target</button>';
    let outerCheckbox = outer.shadowRoot.querySelector('input');
    let innerRadio = inner.shadowRoot.querySelector('input');
    let button = inner.shadowRoot.querySelector('button');

    let revert = ariaHideOutside([button]);

    expect(light).toHaveAttribute('aria-hidden', 'true');
    expect(outerCheckbox).toHaveAttribute('aria-hidden', 'true');
    expect(innerRadio).toHaveAttribute('aria-hidden', 'true');
    expect(button).not.toHaveAttribute('aria-hidden');
    expect(outer.shadowHost).not.toHaveAttribute('aria-hidden');
    expect(inner.shadowHost).not.toHaveAttribute('aria-hidden');

    revert();
  });

  it('should not hide anything inside the shadow root when the target is the shadow host', function () {
    let light = createLightCheckbox();
    let {shadowHost, shadowRoot} = createHost();
    shadowRoot.innerHTML = '<input type="checkbox" />';
    let checkbox = shadowRoot.querySelector('input');

    let revert = ariaHideOutside([shadowHost]);

    expect(light).toHaveAttribute('aria-hidden', 'true');
    expect(shadowHost).not.toHaveAttribute('aria-hidden');
    expect(checkbox).not.toHaveAttribute('aria-hidden');

    revert();
  });

  it('should hide elements added in the target or enclosing shadow roots, but not inside the target', async function () {
    let outer = createHost();
    outer.shadowRoot.innerHTML = '<div class="deep"><span>Deep</span></div><div class="path"><div class="wrapper"></div></div>';
    let wrapper = outer.shadowRoot.querySelector('.wrapper');
    let inner = createNestedHost(wrapper);
    inner.shadowRoot.innerHTML = '<button>Target</button>';
    let button = inner.shadowRoot.querySelector('button');
    let deep = outer.shadowRoot.querySelector('.deep');

    let revert = ariaHideOutside([button]);
    expect(wrapper).not.toHaveAttribute('aria-hidden');

    let addedInInner = document.createElement('input');
    let addedInOuter = document.createElement('input');
    let addedInPath = document.createElement('input');
    let addedInDeep = document.createElement('input');
    let addedInTarget = document.createElement('input');
    inner.shadowRoot.appendChild(addedInInner);
    outer.shadowRoot.appendChild(addedInOuter);
    // Added deep inside the outer shadow root, under ancestors of the target that stay visible.
    wrapper.appendChild(addedInPath);
    deep.appendChild(addedInDeep);
    button.appendChild(addedInTarget);

    await waitFor(() => expect(addedInInner).toHaveAttribute('aria-hidden', 'true'));
    expect(addedInOuter).toHaveAttribute('aria-hidden', 'true');
    expect(addedInPath).toHaveAttribute('aria-hidden', 'true');
    // The deep node is inside a hidden subtree, so it is hidden through its ancestor.
    expect(addedInDeep.closest('[aria-hidden="true"]')).not.toBeNull();
    expect(addedInTarget).not.toHaveAttribute('aria-hidden');
    expect(button).not.toHaveAttribute('aria-hidden');

    revert();
  });

  it('should keep live announcers and top layer elements visible in shadow roots', async function () {
    let outer = createHost();
    outer.shadowRoot.innerHTML = '<div data-live-announcer="true">Announce</div><div data-react-aria-top-layer="true">Toast</div><button>Target</button>';
    let inner = createNestedHost(outer.shadowRoot);
    inner.shadowRoot.innerHTML = '<button>Inner target</button>';
    let innerButton = inner.shadowRoot.querySelector('button');
    let announcer = outer.shadowRoot.querySelector('[data-live-announcer]');
    let toast = outer.shadowRoot.querySelector('[data-react-aria-top-layer]');

    let revert = ariaHideOutside([innerButton]);

    let laterAnnouncer = document.createElement('div');
    laterAnnouncer.dataset.liveAnnouncer = 'true';
    let laterToast = document.createElement('div');
    laterToast.dataset.reactAriaTopLayer = 'true';
    let sentinel = document.createElement('input');
    inner.shadowRoot.append(laterAnnouncer, laterToast);
    outer.shadowRoot.appendChild(sentinel);

    await waitFor(() => expect(sentinel).toHaveAttribute('aria-hidden', 'true'));
    expect(announcer).not.toHaveAttribute('aria-hidden');
    expect(toast).not.toHaveAttribute('aria-hidden');
    expect(laterAnnouncer).not.toHaveAttribute('aria-hidden');
    expect(laterToast).not.toHaveAttribute('aria-hidden');

    revert();
  });

  it('should hide a new shadow host appended inside the target shadow root as a whole', async function () {
    let {shadowRoot} = createHost();
    shadowRoot.innerHTML = '<button>Target</button>';
    let button = shadowRoot.querySelector('button');

    let revert = ariaHideOutside([button]);

    let newHost = document.createElement('div');
    shadowRoot.appendChild(newHost);
    newHost.attachShadow({mode: 'open'}).innerHTML = '<input type="checkbox" />';

    await waitFor(() => expect(newHost).toHaveAttribute('aria-hidden', 'true'));
    expect(button).not.toHaveAttribute('aria-hidden');

    revert();
    expect(newHost).not.toHaveAttribute('aria-hidden');
  });

  it('should keep targets in different shadow roots visible and hide siblings in both roots', async function () {
    let hostA = createHost();
    let hostB = createHost();
    hostA.shadowRoot.innerHTML = '<input type="checkbox" /><input type="text" />';
    hostB.shadowRoot.innerHTML = '<input type="radio" /><button>Popover</button>';
    let checkboxA = hostA.shadowRoot.querySelector('input[type="checkbox"]');
    let textA = hostA.shadowRoot.querySelector('input[type="text"]');
    let radioB = hostB.shadowRoot.querySelector('input[type="radio"]');
    let buttonB = hostB.shadowRoot.querySelector('button');

    let revert = ariaHideOutside([textA, buttonB]);

    expect(hostA.shadowHost).not.toHaveAttribute('aria-hidden');
    expect(hostB.shadowHost).not.toHaveAttribute('aria-hidden');
    expect(textA).not.toHaveAttribute('aria-hidden');
    expect(buttonB).not.toHaveAttribute('aria-hidden');
    expect(checkboxA).toHaveAttribute('aria-hidden', 'true');
    expect(radioB).toHaveAttribute('aria-hidden', 'true');

    let addedA = document.createElement('input');
    let addedB = document.createElement('input');
    hostA.shadowRoot.appendChild(addedA);
    hostB.shadowRoot.appendChild(addedB);

    await waitFor(() => expect(addedA).toHaveAttribute('aria-hidden', 'true'));
    expect(addedB).toHaveAttribute('aria-hidden', 'true');

    revert();
  });

  it('should keep two targets in the same shadow root visible and restore without leftover aria-hidden', function () {
    let light = createLightCheckbox();
    let {shadowRoot} = createHost();
    shadowRoot.innerHTML = '<button>One</button><button>Two</button><input type="checkbox" />';
    let [one, two] = shadowRoot.querySelectorAll('button');
    let checkbox = shadowRoot.querySelector('input');

    let revert = ariaHideOutside([one, two]);

    expect(checkbox).toHaveAttribute('aria-hidden', 'true');
    expect(one).not.toHaveAttribute('aria-hidden');
    expect(two).not.toHaveAttribute('aria-hidden');

    revert();

    expect(light).not.toHaveAttribute('aria-hidden');
    expect(shadowRoot.querySelectorAll('[aria-hidden]')).toHaveLength(0);
  });

  it('should restore shadow DOM elements and stop observing shadow roots when reverted', async function () {
    let light = createLightCheckbox();
    let {shadowRoot} = createHost();
    shadowRoot.innerHTML = '<input type="checkbox" /><button>Target</button>';
    let checkbox = shadowRoot.querySelector('input');
    let button = shadowRoot.querySelector('button');

    let revert = ariaHideOutside([button]);

    expect(checkbox).toHaveAttribute('aria-hidden', 'true');

    revert();

    expect(light).not.toHaveAttribute('aria-hidden');
    expect(checkbox).not.toHaveAttribute('aria-hidden');

    let added = document.createElement('input');
    shadowRoot.appendChild(added);
    await Promise.resolve();
    expect(added).not.toHaveAttribute('aria-hidden');
  });

  it('should leave pre-existing aria-hidden in shadow DOM after restore', function () {
    let {shadowRoot} = createHost();
    shadowRoot.innerHTML = '<input type="checkbox" aria-hidden="true" /><button>Target</button>';
    let checkbox = shadowRoot.querySelector('input');
    let button = shadowRoot.querySelector('button');

    let revert = ariaHideOutside([button]);
    revert();

    expect(checkbox).toHaveAttribute('aria-hidden', 'true');
    expect(button).not.toHaveAttribute('aria-hidden');
  });

  it('should not hide anything when the root does not contain the shadow host', function () {
    let root = document.createElement('div');
    document.body.appendChild(root);
    cleanups.push(() => root.remove());
    let light = createLightCheckbox();
    let {shadowRoot} = createHost();
    shadowRoot.innerHTML = '<input type="checkbox" /><button>Target</button>';
    let checkbox = shadowRoot.querySelector('input');
    let button = shadowRoot.querySelector('button');

    let revert;
    expect(() => {
      revert = ariaHideOutside([button], {root});
    }).not.toThrow();

    expect(checkbox).not.toHaveAttribute('aria-hidden');
    expect(light).not.toHaveAttribute('aria-hidden');

    revert();
  });

  it('should keep observing outer shadow roots after a nested call is restored', async function () {
    let {shadowRoot} = createHost();
    shadowRoot.innerHTML = '<input type="checkbox" /><button>Outer</button>';
    let button = shadowRoot.querySelector('button');
    let innerButton = document.createElement('button');
    document.body.appendChild(innerButton);
    cleanups.push(() => innerButton.remove());

    let outerRevert = ariaHideOutside([button]);
    let innerRevert = ariaHideOutside([innerButton]);
    innerRevert();

    let added = document.createElement('input');
    shadowRoot.appendChild(added);
    await waitFor(() => expect(added).toHaveAttribute('aria-hidden', 'true'));

    let popover = document.createElement('div');
    shadowRoot.appendChild(popover);
    let undoKeepVisible = keepVisible(popover);
    let sentinel = document.createElement('input');
    shadowRoot.appendChild(sentinel);

    await waitFor(() => expect(sentinel).toHaveAttribute('aria-hidden', 'true'));
    expect(popover).not.toHaveAttribute('aria-hidden');

    undoKeepVisible();
    outerRevert();
  });
});

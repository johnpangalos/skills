"""Password-reset tokens (in-memory store)."""

import secrets
import threading
import time

TOKEN_TTL = 1800  # seconds after issue

_TOKENS = {}  # token -> (username, issued_at)
_USED = set()  # tokens redeemed successfully
_LOCK = threading.Lock()  # serializes redeem_reset_token's check-then-mark


class InvalidToken(Exception):
    pass


class TokenExpired(InvalidToken):
    pass


class TokenUsed(InvalidToken):
    pass


def issue_reset_token(username, now=None):
    """Create a reset token for username, issued at now.

    now is Unix seconds (default time.time()). Tokens expire 30 minutes
    after issue and are single-use.
    """
    if now is None:
        now = time.time()
    token = secrets.token_urlsafe(16)
    _TOKENS[token] = (username, now)
    return token


def redeem_reset_token(token, now=None):
    """Return the username a token was issued for, checked at now.

    now is Unix seconds (default time.time()). Raises TokenUsed if the token
    was already redeemed, TokenExpired more than 30 minutes after issue, and
    InvalidToken if it was never issued. Tokens are single-use.
    """
    if now is None:
        now = time.time()
    with _LOCK:
        if token in _USED:
            raise TokenUsed("token already used")
        entry = _TOKENS.get(token)
        if entry is None:
            raise InvalidToken("unknown token")
        username, issued_at = entry
        if now - issued_at > TOKEN_TTL:
            raise TokenExpired("token expired")
        _USED.add(token)
        return username

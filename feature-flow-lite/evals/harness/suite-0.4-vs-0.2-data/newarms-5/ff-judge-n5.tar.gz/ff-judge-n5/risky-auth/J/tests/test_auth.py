import unittest
from unittest import mock

from shop import auth
from shop.auth import InvalidToken, issue_reset_token, redeem_reset_token


class ResetTokenTest(unittest.TestCase):
    def setUp(self):
        auth._TOKENS.clear()

    def test_round_trip(self):
        token = issue_reset_token("ada")
        self.assertEqual(redeem_reset_token(token), "ada")

    def test_unknown_token(self):
        with self.assertRaises(InvalidToken):
            redeem_reset_token("not-a-token")

    def test_empty_and_none_tokens_are_plain_invalid_token(self):
        for bad in ("", None):
            with self.subTest(token=bad):
                with self.assertRaises(InvalidToken) as cm:
                    redeem_reset_token(bad, now=1000)
                self.assertIs(type(cm.exception), InvalidToken)

    def test_ttl_constant_is_1800_seconds(self):
        self.assertEqual(auth.RESET_TOKEN_TTL, 1800)

    def test_now_zero_is_honoured_on_issue(self):
        token = issue_reset_token("ada", now=0)
        with self.assertRaises(auth.TokenExpired):
            redeem_reset_token(token, now=1801)

    def test_now_zero_is_honoured_on_redeem(self):
        token = issue_reset_token("ada", now=1000)
        self.assertEqual(redeem_reset_token(token, now=0), "ada")

    def test_redeem_at_exact_ttl_succeeds(self):
        token = issue_reset_token("ada", now=1000)
        self.assertEqual(redeem_reset_token(token, now=1000 + 1800), "ada")

    def test_redeem_just_past_ttl_expires(self):
        token = issue_reset_token("ada", now=1000)
        with self.assertRaises(auth.TokenExpired):
            redeem_reset_token(token, now=1000 + 1800.001)

    def test_float_timestamps_are_accepted(self):
        token = issue_reset_token("ada", now=1000.5)
        self.assertEqual(redeem_reset_token(token, now=1000.5 + 1800), "ada")

    def test_default_now_reads_time_time_at_call_time(self):
        with mock.patch("shop.auth.time.time", return_value=1000.0) as clock:
            token = issue_reset_token("ada")
            clock.return_value = 1000.0 + 1801
            with self.assertRaises(auth.TokenExpired):
                redeem_reset_token(token)
        self.assertTrue(clock.called)

    def test_default_now_on_redeem_reads_time_time_at_call_time(self):
        token = issue_reset_token("ada", now=1000)
        with mock.patch("shop.auth.time.time", return_value=2800.0):
            self.assertEqual(redeem_reset_token(token), "ada")
        second = issue_reset_token("ada", now=1000)
        with mock.patch("shop.auth.time.time", return_value=2801.0):
            with self.assertRaises(auth.TokenExpired):
                redeem_reset_token(second)

    def test_redeem_before_issue_time_succeeds(self):
        token = issue_reset_token("ada", now=10000)
        self.assertEqual(redeem_reset_token(token, now=1000), "ada")

    def test_second_redemption_raises_token_used(self):
        token = issue_reset_token("ada", now=1000)
        self.assertEqual(redeem_reset_token(token, now=1000), "ada")
        with self.assertRaises(auth.TokenUsed):
            redeem_reset_token(token, now=1001)

    def test_used_token_past_expiry_raises_token_used(self):
        token = issue_reset_token("ada", now=1000)
        redeem_reset_token(token, now=1000)
        with self.assertRaises(auth.TokenUsed):
            redeem_reset_token(token, now=1000 + 1801)

    def test_expired_redemption_does_not_mark_used(self):
        token = issue_reset_token("ada", now=1000)
        for _ in range(2):
            with self.assertRaises(auth.TokenExpired):
                redeem_reset_token(token, now=1000 + 1801)

    def test_expired_and_used_are_invalid_token_subclasses(self):
        self.assertTrue(issubclass(auth.TokenExpired, InvalidToken))
        self.assertTrue(issubclass(auth.TokenUsed, InvalidToken))

    def test_except_invalid_token_catches_expired_and_used(self):
        used = issue_reset_token("ada", now=1000)
        redeem_reset_token(used, now=1000)
        expired = issue_reset_token("ada", now=1000)
        caught = []
        for token in (used, expired):
            try:
                redeem_reset_token(token, now=1000 + 1801)
            except InvalidToken as exc:
                caught.append(type(exc))
        self.assertEqual(caught, [auth.TokenUsed, auth.TokenExpired])

    def test_two_tokens_for_same_user_are_independent(self):
        first = issue_reset_token("ada", now=1000)
        second = issue_reset_token("ada", now=1000)
        self.assertEqual(redeem_reset_token(first, now=1000), "ada")
        self.assertEqual(redeem_reset_token(second, now=1000), "ada")

        old = issue_reset_token("ada", now=1000)
        fresh = issue_reset_token("ada", now=2000)
        with self.assertRaises(auth.TokenExpired):
            redeem_reset_token(old, now=2801)
        self.assertEqual(redeem_reset_token(fresh, now=2801), "ada")

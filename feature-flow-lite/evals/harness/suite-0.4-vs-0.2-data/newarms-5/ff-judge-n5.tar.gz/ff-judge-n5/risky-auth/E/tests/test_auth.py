import time
import unittest

from shop.auth import (
    InvalidToken,
    TokenExpired,
    TokenUsed,
    issue_reset_token,
    redeem_reset_token,
)


class ResetTokenTest(unittest.TestCase):
    def test_round_trip(self):
        token = issue_reset_token("ada")
        self.assertEqual(redeem_reset_token(token), "ada")

    def test_default_now_expires_after_ttl(self):
        token = issue_reset_token("ada")
        with self.assertRaises(TokenExpired):
            redeem_reset_token(token, now=time.time() + 1801)

    def test_unknown_and_empty_tokens_raise_plain_invalid_token(self):
        for bad in ("not-a-token", ""):
            with self.subTest(token=bad):
                with self.assertRaises(InvalidToken) as cm:
                    redeem_reset_token(bad)
                self.assertIs(type(cm.exception), InvalidToken)

    def test_expired_and_used_subclass_invalid_token(self):
        self.assertTrue(issubclass(TokenExpired, InvalidToken))
        self.assertTrue(issubclass(TokenUsed, InvalidToken))

    def test_exactly_1800_seconds_valid_and_1801_expired(self):
        token = issue_reset_token("ada", now=1000)
        self.assertEqual(redeem_reset_token(token, now=2800), "ada")
        token = issue_reset_token("ada", now=1000)
        with self.assertRaises(TokenExpired):
            redeem_reset_token(token, now=2801)

    def test_float_timestamps_at_and_past_boundary(self):
        token = issue_reset_token("ada", now=1000.5)
        self.assertEqual(redeem_reset_token(token, now=2800.5), "ada")
        token = issue_reset_token("ada", now=1000.5)
        with self.assertRaises(TokenExpired):
            redeem_reset_token(token, now=2801.0)

    def test_zero_timestamps_are_honored(self):
        token = issue_reset_token("ada", now=0)
        self.assertEqual(redeem_reset_token(token, now=0), "ada")
        token = issue_reset_token("ada", now=0)
        with self.assertRaises(TokenExpired):
            redeem_reset_token(token, now=1801)

    def test_redeem_before_issue_is_not_expired(self):
        token = issue_reset_token("ada", now=10_000)
        self.assertEqual(redeem_reset_token(token, now=0), "ada")

    def test_single_use(self):
        token = issue_reset_token("ada", now=1000)
        self.assertEqual(redeem_reset_token(token, now=1000), "ada")
        with self.assertRaises(TokenUsed) as cm:
            redeem_reset_token(token, now=1001)
        self.assertIs(type(cm.exception), TokenUsed)

    def test_used_wins_over_expired(self):
        token = issue_reset_token("ada", now=1000)
        redeem_reset_token(token, now=1000)
        with self.assertRaises(TokenUsed) as cm:
            redeem_reset_token(token, now=5000)
        self.assertIs(type(cm.exception), TokenUsed)

    def test_failed_expired_redeem_does_not_mark_used(self):
        token = issue_reset_token("ada", now=1000)
        with self.assertRaises(TokenExpired):
            redeem_reset_token(token, now=3000)
        with self.assertRaises(TokenExpired):
            redeem_reset_token(token, now=3001)

    def test_two_tokens_for_same_user_are_independent(self):
        first = issue_reset_token("ada", now=1000)
        second = issue_reset_token("ada", now=1000)
        self.assertEqual(redeem_reset_token(first, now=1000), "ada")
        self.assertEqual(redeem_reset_token(second, now=1000), "ada")

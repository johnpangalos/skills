import unittest
from unittest import mock

from shop import auth
from shop.auth import InvalidToken, issue_reset_token, redeem_reset_token


class ResetTokenTest(unittest.TestCase):
    def test_round_trip(self):
        token = issue_reset_token("ada")
        self.assertEqual(redeem_reset_token(token), "ada")

    def test_unknown_token(self):
        with self.assertRaises(InvalidToken):
            redeem_reset_token("not-a-token")

    def test_now_defaults_to_time_at_call_time(self):
        with mock.patch("shop.auth.time") as clock:
            clock.time.return_value = 1000.0
            token = issue_reset_token("ada")
            clock.time.return_value = 2801.0
            with self.assertRaises(auth.TokenExpired):
                redeem_reset_token(token)

    def test_now_zero_is_a_real_timestamp(self):
        token = issue_reset_token("ada", now=0)
        self.assertEqual(redeem_reset_token(token, now=1800), "ada")

    def test_now_zero_expires_after_window(self):
        token = issue_reset_token("ada", now=0)
        with self.assertRaises(auth.TokenExpired):
            redeem_reset_token(token, now=1801)

    def test_redeem_at_exact_window_end_succeeds(self):
        token = issue_reset_token("ada", now=1000)
        self.assertEqual(redeem_reset_token(token, now=2800), "ada")

    def test_redeem_just_past_window_is_expired(self):
        token = issue_reset_token("ada", now=1000)
        with self.assertRaises(auth.TokenExpired):
            redeem_reset_token(token, now=2800.001)

    def test_float_timestamps(self):
        token = issue_reset_token("ada", now=1000.5)
        self.assertEqual(redeem_reset_token(token, now=2800.5), "ada")
        token = issue_reset_token("ada", now=1000.5)
        with self.assertRaises(auth.TokenExpired):
            redeem_reset_token(token, now=2800.6)

    def test_success_marks_token_used(self):
        token = issue_reset_token("ada", now=1000)
        self.assertEqual(redeem_reset_token(token, now=1001), "ada")
        with self.assertRaises(auth.TokenUsed) as ctx:
            redeem_reset_token(token, now=1002)
        self.assertEqual(str(ctx.exception), "token already used")

    def test_second_redeem_after_expiry_is_used_not_expired(self):
        token = issue_reset_token("ada", now=0)
        self.assertEqual(redeem_reset_token(token, now=100), "ada")
        with self.assertRaises(auth.TokenUsed):
            redeem_reset_token(token, now=5000)

    def test_expired_attempt_does_not_consume_token(self):
        token = issue_reset_token("ada", now=0)
        for _ in range(2):
            with self.assertRaises(auth.TokenExpired) as ctx:
                redeem_reset_token(token, now=1801)
            self.assertEqual(str(ctx.exception), "token expired")

    def test_expired_and_used_are_invalid_token_subclasses(self):
        self.assertTrue(issubclass(auth.TokenExpired, InvalidToken))
        self.assertTrue(issubclass(auth.TokenUsed, InvalidToken))
        token = issue_reset_token("ada", now=0)
        with self.assertRaises(InvalidToken):
            redeem_reset_token(token, now=1801)
        fresh = issue_reset_token("ada", now=0)
        redeem_reset_token(fresh, now=1)
        with self.assertRaises(InvalidToken):
            redeem_reset_token(fresh, now=2)

    def test_unknown_token_is_plain_invalid_token(self):
        token = issue_reset_token("ada", now=0)
        altered = token[:-1] + ("A" if token[-1] != "A" else "B")
        for bad in ["", None, altered]:
            with self.subTest(bad=bad):
                with self.assertRaises(InvalidToken) as ctx:
                    redeem_reset_token(bad, now=1)
                self.assertIs(type(ctx.exception), InvalidToken)
                self.assertEqual(str(ctx.exception), "unknown token")

    def test_tokens_for_same_user_are_independent(self):
        first = issue_reset_token("ada", now=1000)
        second = issue_reset_token("ada", now=1000)
        self.assertEqual(redeem_reset_token(first, now=1001), "ada")
        self.assertEqual(redeem_reset_token(second, now=2800), "ada")

    def test_redeem_before_issue_time_succeeds(self):
        token = issue_reset_token("ada", now=1000)
        self.assertEqual(redeem_reset_token(token, now=500), "ada")

    def test_redeem_now_zero_is_a_real_timestamp(self):
        token = issue_reset_token("ada", now=-1000)
        self.assertEqual(redeem_reset_token(token, now=0), "ada")

    def test_redeem_far_before_issue_time_is_not_expired(self):
        token = issue_reset_token("ada", now=10000)
        self.assertEqual(redeem_reset_token(token, now=5000), "ada")

    def test_redeem_with_nan_now_fails_closed(self):
        token = issue_reset_token("ada", now=1000)
        with self.assertRaises(auth.TokenExpired) as ctx:
            redeem_reset_token(token, now=float("nan"))
        self.assertEqual(str(ctx.exception), "token expired")

    def test_issue_with_nan_now_fails_closed(self):
        token = issue_reset_token("ada", now=float("nan"))
        with self.assertRaises(auth.TokenExpired):
            redeem_reset_token(token, now=1)

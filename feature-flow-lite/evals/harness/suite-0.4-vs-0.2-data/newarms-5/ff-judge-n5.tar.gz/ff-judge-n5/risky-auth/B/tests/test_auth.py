import sys
import threading
import unittest
from unittest import mock

from shop.auth import (
    RESET_TOKEN_TTL,
    InvalidToken,
    TokenExpired,
    TokenUsed,
    issue_reset_token,
    redeem_reset_token,
)


class ResetTokenTest(unittest.TestCase):
    def test_round_trip(self):
        token = issue_reset_token("ada")
        self.assertEqual(redeem_reset_token(token), "ada")

    def test_unknown_token(self):
        with self.assertRaises(InvalidToken):
            redeem_reset_token("not-a-token")

    def test_unknown_token_raises_plain_invalid_token(self):
        with self.assertRaises(InvalidToken) as cm:
            redeem_reset_token("not-a-token", now=0)
        self.assertIs(type(cm.exception), InvalidToken)

    def test_odd_input_raises_invalid_token(self):
        for odd in (None, "", []):
            with self.subTest(odd=odd):
                with self.assertRaises(InvalidToken) as cm:
                    redeem_reset_token(odd, now=0)
                self.assertIs(type(cm.exception), InvalidToken)

    def test_ttl_is_1800_seconds(self):
        self.assertEqual(RESET_TOKEN_TTL, 1800)

    def test_now_zero_is_honored_not_replaced_by_clock(self):
        with mock.patch("shop.auth.time.time", return_value=1000000.0):
            token = issue_reset_token("ada", now=0)
            self.assertEqual(redeem_reset_token(token, now=1800), "ada")

    def test_exactly_ttl_after_issue_succeeds(self):
        token = issue_reset_token("ada", now=1000)
        self.assertEqual(redeem_reset_token(token, now=1000 + 1800), "ada")

    def test_just_past_ttl_raises_expired(self):
        token = issue_reset_token("ada", now=1000)
        with self.assertRaises(TokenExpired):
            redeem_reset_token(token, now=1000 + 1800.5)

    def test_clock_skew_before_issue_is_not_expired(self):
        token = issue_reset_token("ada", now=1000)
        self.assertEqual(redeem_reset_token(token, now=0), "ada")

    def test_large_clock_skew_before_issue_is_not_expired(self):
        token = issue_reset_token("ada", now=100000)
        self.assertEqual(redeem_reset_token(token, now=0), "ada")

    def test_issue_default_clock_honors_now_zero(self):
        with mock.patch("shop.auth.time.time", return_value=1000000.0):
            token = issue_reset_token("ada", now=0)
            with self.assertRaises(TokenExpired):
                redeem_reset_token(token, now=1801)

    def test_concurrent_redeem_succeeds_once(self):
        token = issue_reset_token("ada", now=0)
        barrier = threading.Barrier(8)
        results = []
        results_lock = threading.Lock()

        def redeem():
            barrier.wait()
            try:
                outcome = redeem_reset_token(token, now=0)
            except TokenUsed as exc:
                outcome = exc
            with results_lock:
                results.append(outcome)

        threads = [threading.Thread(target=redeem) for _ in range(8)]
        old_interval = sys.getswitchinterval()
        sys.setswitchinterval(1e-6)
        try:
            for thread in threads:
                thread.start()
            for thread in threads:
                thread.join()
        finally:
            sys.setswitchinterval(old_interval)
        successes = [r for r in results if r == "ada"]
        failures = [r for r in results if isinstance(r, TokenUsed)]
        self.assertEqual(len(successes), 1)
        self.assertEqual(len(failures), 7)

    def test_default_clock_read_at_call_time(self):
        with mock.patch("shop.auth.time.time", return_value=1000.0):
            token = issue_reset_token("ada")
        with mock.patch("shop.auth.time.time", return_value=1000.0 + 1800):
            self.assertEqual(redeem_reset_token(token), "ada")

    def test_default_clock_expiry(self):
        with mock.patch("shop.auth.time.time", return_value=1000.0):
            token = issue_reset_token("ada")
        with mock.patch("shop.auth.time.time", return_value=1000.0 + 1801):
            with self.assertRaises(TokenExpired):
                redeem_reset_token(token)

    def test_second_redeem_raises_token_used(self):
        token = issue_reset_token("ada", now=0)
        self.assertEqual(redeem_reset_token(token, now=0), "ada")
        with self.assertRaises(TokenUsed):
            redeem_reset_token(token, now=0)

    def test_used_token_past_expiry_raises_token_used(self):
        token = issue_reset_token("ada", now=0)
        self.assertEqual(redeem_reset_token(token, now=1), "ada")
        with self.assertRaises(TokenUsed):
            redeem_reset_token(token, now=5000)

    def test_expired_token_keeps_raising_expired(self):
        token = issue_reset_token("ada", now=0)
        with self.assertRaises(TokenExpired):
            redeem_reset_token(token, now=1801)
        with self.assertRaises(TokenExpired):
            redeem_reset_token(token, now=1801)

    def test_expired_and_used_are_invalid_token_subclasses(self):
        self.assertTrue(issubclass(TokenExpired, InvalidToken))
        self.assertTrue(issubclass(TokenUsed, InvalidToken))
        token = issue_reset_token("ada", now=0)
        with self.assertRaises(InvalidToken):
            redeem_reset_token(token, now=1801)

    def test_tokens_are_independent(self):
        first = issue_reset_token("ada", now=0)
        second = issue_reset_token("ada", now=0)
        self.assertEqual(redeem_reset_token(first, now=10), "ada")
        self.assertEqual(redeem_reset_token(second, now=20), "ada")
        with self.assertRaises(TokenUsed):
            redeem_reset_token(first, now=30)

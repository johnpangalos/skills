"""Password-reset tokens (in-memory store).

A token expires RESET_TTL_SECONDS after it is issued and can be redeemed once.
"""

import secrets
import time

RESET_TTL_SECONDS = 1800

_TOKENS = {}  # token -> {"username": str, "issued": float, "used": bool}


class InvalidToken(Exception):
    pass


class TokenExpired(InvalidToken):
    pass


class TokenUsed(InvalidToken):
    pass


def issue_reset_token(username, now=None):
    """Create a reset token for username, issued at now (Unix seconds, default time.time())."""
    if now is None:
        now = time.time()
    token = secrets.token_urlsafe(16)
    _TOKENS[token] = {"username": username, "issued": now, "used": False}
    return token


def redeem_reset_token(token, now=None):
    """Return the username a token was issued for, consuming the token.

    Raises InvalidToken for unknown tokens, TokenUsed if the token was already
    redeemed, and TokenExpired if more than RESET_TTL_SECONDS have passed since
    issue. A failed redeem never consumes the token.
    """
    if now is None:
        now = time.time()
    record = _TOKENS.get(token)
    if record is None:
        raise InvalidToken("unknown token")
    if record["used"]:
        raise TokenUsed("token already used")
    if now > record["issued"] + RESET_TTL_SECONDS:
        raise TokenExpired("token expired")
    record["used"] = True
    return record["username"]

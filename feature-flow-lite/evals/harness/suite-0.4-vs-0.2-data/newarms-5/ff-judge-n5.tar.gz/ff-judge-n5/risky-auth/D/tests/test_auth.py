import threading
import unittest
from unittest import mock

from shop import auth
from shop.auth import (
    InvalidToken,
    TokenExpired,
    TokenUsed,
    issue_reset_token,
    redeem_reset_token,
)

ISSUED = 1_000_000


class ResetTokenTest(unittest.TestCase):
    def setUp(self):
        auth._TOKENS.clear()

    def test_round_trip(self):
        token = issue_reset_token("ada")
        self.assertEqual(redeem_reset_token(token), "ada")

    def test_unknown_token(self):
        with self.assertRaises(InvalidToken):
            redeem_reset_token("not-a-token")

    def test_round_trip_with_explicit_now(self):
        token = issue_reset_token("ada", now=ISSUED)
        self.assertEqual(redeem_reset_token(token, now=ISSUED + 1), "ada")

    def test_unknown_and_empty_tokens_are_plain_invalid_token(self):
        for bad in ("", "never-issued"):
            with self.subTest(token=bad):
                with self.assertRaises(InvalidToken) as cm:
                    redeem_reset_token(bad, now=ISSUED)
                self.assertIs(type(cm.exception), InvalidToken)
                self.assertEqual(str(cm.exception), "unknown token")

    def test_expired_and_used_subclass_invalid_token(self):
        self.assertTrue(issubclass(TokenExpired, InvalidToken))
        self.assertTrue(issubclass(TokenUsed, InvalidToken))

    def test_redeem_at_exact_ttl_succeeds(self):
        token = issue_reset_token("ada", now=ISSUED)
        self.assertEqual(redeem_reset_token(token, now=ISSUED + 1800), "ada")

    def test_redeem_one_second_past_ttl_is_expired(self):
        token = issue_reset_token("ada", now=ISSUED)
        with self.assertRaises(TokenExpired) as cm:
            redeem_reset_token(token, now=ISSUED + 1801)
        self.assertEqual(str(cm.exception), "token expired")

    def test_redeem_just_past_ttl_float_is_expired(self):
        token = issue_reset_token("ada", now=ISSUED)
        with self.assertRaises(TokenExpired):
            redeem_reset_token(token, now=ISSUED + 1800.001)

    def test_redeem_before_issue_clock_skew_is_not_expired(self):
        token = issue_reset_token("ada", now=ISSUED)
        self.assertEqual(redeem_reset_token(token, now=ISSUED - 5000), "ada")

    def test_float_timestamps_work(self):
        token = issue_reset_token("ada", now=ISSUED + 0.5)
        self.assertEqual(redeem_reset_token(token, now=ISSUED + 1800.5), "ada")

    def test_now_zero_and_zero_float_are_honored(self):
        token = issue_reset_token("ada", now=0)
        with self.assertRaises(TokenExpired):
            redeem_reset_token(token, now=1801)
        self.assertEqual(redeem_reset_token(token, now=0.0), "ada")

    def test_default_now_uses_time_time_at_call_time(self):
        with mock.patch("shop.auth.time.time", return_value=ISSUED):
            token = issue_reset_token("ada")
        with mock.patch("shop.auth.time.time", return_value=ISSUED + 1801):
            with self.assertRaises(TokenExpired):
                redeem_reset_token(token)

    def test_reuse_raises_token_used(self):
        token = issue_reset_token("ada", now=ISSUED)
        redeem_reset_token(token, now=ISSUED)
        with self.assertRaises(TokenUsed) as cm:
            redeem_reset_token(token, now=ISSUED)
        self.assertEqual(str(cm.exception), "token already used")

    def test_used_then_expired_raises_token_used(self):
        token = issue_reset_token("ada", now=ISSUED)
        redeem_reset_token(token, now=ISSUED)
        with self.assertRaises(TokenUsed):
            redeem_reset_token(token, now=ISSUED + 1801)

    def test_expired_attempt_does_not_consume_token(self):
        token = issue_reset_token("ada", now=ISSUED)
        with self.assertRaises(TokenExpired):
            redeem_reset_token(token, now=ISSUED + 1801)
        with self.assertRaises(TokenExpired):
            redeem_reset_token(token, now=ISSUED + 1801)
        self.assertEqual(redeem_reset_token(token, now=ISSUED + 1800), "ada")

    def test_tokens_for_same_username_are_independent(self):
        first = issue_reset_token("ada", now=ISSUED)
        second = issue_reset_token("ada", now=ISSUED)
        redeem_reset_token(first, now=ISSUED)
        self.assertEqual(redeem_reset_token(second, now=ISSUED), "ada")

    def test_concurrent_redeem_succeeds_exactly_once(self):
        token = issue_reset_token("ada", now=ISSUED)
        workers = 8
        barrier = threading.Barrier(workers)
        outcomes = []

        def attempt():
            barrier.wait()
            try:
                outcomes.append(redeem_reset_token(token, now=ISSUED))
            except TokenUsed:
                outcomes.append("used")

        threads = [threading.Thread(target=attempt) for _ in range(workers)]
        for thread in threads:
            thread.start()
        for thread in threads:
            thread.join()
        self.assertEqual(outcomes.count("ada"), 1)
        self.assertEqual(outcomes.count("used"), workers - 1)

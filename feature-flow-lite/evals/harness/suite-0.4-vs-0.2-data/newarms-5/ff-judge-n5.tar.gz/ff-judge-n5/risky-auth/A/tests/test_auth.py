import threading
import time
import unittest

from shop.auth import InvalidToken, TokenExpired, TokenUsed, issue_reset_token, redeem_reset_token


class ResetTokenTest(unittest.TestCase):
    def test_round_trip(self):
        token = issue_reset_token("ada")
        self.assertEqual(redeem_reset_token(token), "ada")

    def test_unknown_token(self):
        with self.assertRaises(InvalidToken):
            redeem_reset_token("not-a-token")

    def test_default_now(self):
        token = issue_reset_token("ada")
        self.assertEqual(redeem_reset_token(token), "ada")
        token = issue_reset_token("ada")
        with self.assertRaises(TokenExpired):
            redeem_reset_token(token, now=time.time() + 1801)

    def test_exactly_ttl_is_valid(self):
        token = issue_reset_token("ada", now=1000)
        self.assertEqual(redeem_reset_token(token, now=2800), "ada")

    def test_past_ttl_is_expired(self):
        for offset in (1800.001, 1800.5, 1801):
            with self.subTest(offset=offset):
                token = issue_reset_token("ada", now=1000)
                with self.assertRaises(TokenExpired) as cm:
                    redeem_reset_token(token, now=1000 + offset)
                self.assertEqual(str(cm.exception), "token expired")

    def test_redeem_before_issue_is_valid(self):
        token = issue_reset_token("ada", now=1000)
        self.assertEqual(redeem_reset_token(token, now=500), "ada")

    def test_reuse_is_token_used(self):
        token = issue_reset_token("ada", now=1000)
        self.assertEqual(redeem_reset_token(token, now=1000), "ada")
        with self.assertRaises(TokenUsed) as cm:
            redeem_reset_token(token, now=1000)
        self.assertEqual(str(cm.exception), "token already used")

    def test_reuse_after_expiry_window_is_token_used(self):
        token = issue_reset_token("ada", now=1000)
        self.assertEqual(redeem_reset_token(token, now=1000), "ada")
        with self.assertRaises(TokenUsed):
            redeem_reset_token(token, now=3000)

    def test_expired_twice_is_expired_both_times(self):
        token = issue_reset_token("ada", now=1000)
        for _ in range(2):
            with self.assertRaises(TokenExpired) as cm:
                redeem_reset_token(token, now=3000)
            self.assertEqual(str(cm.exception), "token expired")

    def test_now_zero_issue_and_redeem(self):
        token = issue_reset_token("ada", now=0)
        self.assertEqual(redeem_reset_token(token, now=0), "ada")

    def test_now_zero_boundary(self):
        token = issue_reset_token("ada", now=0)
        self.assertEqual(redeem_reset_token(token, now=1800), "ada")
        token = issue_reset_token("ada", now=0)
        with self.assertRaises(TokenExpired):
            redeem_reset_token(token, now=1801)

    def test_expired_and_used_are_invalid_tokens(self):
        self.assertTrue(issubclass(TokenExpired, InvalidToken))
        self.assertTrue(issubclass(TokenUsed, InvalidToken))
        self.assertFalse(issubclass(TokenExpired, TokenUsed))
        self.assertFalse(issubclass(TokenUsed, TokenExpired))

        used = issue_reset_token("ada", now=1000)
        redeem_reset_token(used, now=1000)
        with self.assertRaises(InvalidToken) as cm:
            redeem_reset_token(used, now=1000)
        self.assertIs(type(cm.exception), TokenUsed)

        expired = issue_reset_token("ada", now=1000)
        with self.assertRaises(InvalidToken) as cm:
            redeem_reset_token(expired, now=3000)
        self.assertIs(type(cm.exception), TokenExpired)

    def test_unknown_token_is_plain_invalid_token(self):
        for bad in ("not-a-token", "", None):
            with self.subTest(token=bad):
                with self.assertRaises(InvalidToken) as cm:
                    redeem_reset_token(bad, now=1000)
                self.assertIs(type(cm.exception), InvalidToken)
                self.assertEqual(str(cm.exception), "unknown token")

    def test_same_user_tokens_are_independent(self):
        first = issue_reset_token("ada", now=1000)
        second = issue_reset_token("ada", now=1000)
        self.assertNotEqual(first, second)
        self.assertEqual(redeem_reset_token(first, now=1000), "ada")
        self.assertEqual(redeem_reset_token(second, now=1000), "ada")
        with self.assertRaises(TokenUsed):
            redeem_reset_token(first, now=1000)

    def test_concurrent_redeem_succeeds_once(self):
        token = issue_reset_token("ada", now=1000)
        barrier = threading.Barrier(8)
        outcomes = []

        def attempt():
            barrier.wait()
            try:
                outcomes.append(redeem_reset_token(token, now=1000))
            except TokenUsed:
                outcomes.append("used")

        threads = [threading.Thread(target=attempt) for _ in range(8)]
        for thread in threads:
            thread.start()
        for thread in threads:
            thread.join()
        self.assertEqual(sorted(outcomes), ["ada"] + ["used"] * 7)

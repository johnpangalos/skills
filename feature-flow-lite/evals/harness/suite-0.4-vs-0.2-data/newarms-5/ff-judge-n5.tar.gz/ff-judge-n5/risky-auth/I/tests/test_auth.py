import unittest
from unittest import mock

from shop.auth import (
    RESET_TTL_SECONDS,
    InvalidToken,
    TokenExpired,
    TokenUsed,
    issue_reset_token,
    redeem_reset_token,
)


class ResetTokenTest(unittest.TestCase):
    def test_round_trip(self):
        token = issue_reset_token("ada")
        self.assertEqual(redeem_reset_token(token), "ada")

    def test_unknown_token(self):
        with self.assertRaises(InvalidToken):
            redeem_reset_token("not-a-token")

    def test_ttl_is_1800_seconds(self):
        self.assertEqual(RESET_TTL_SECONDS, 1800)

    def test_now_zero_is_a_real_timestamp(self):
        token = issue_reset_token("ada", now=0)
        self.assertEqual(redeem_reset_token(token, now=1800), "ada")

    def test_now_zero_expires_after_ttl(self):
        token = issue_reset_token("ada", now=0)
        with self.assertRaises(TokenExpired):
            redeem_reset_token(token, now=1801)

    def test_redeem_exactly_at_ttl_succeeds(self):
        token = issue_reset_token("ada", now=1000)
        self.assertEqual(redeem_reset_token(token, now=2800), "ada")

    def test_redeem_just_past_ttl_expires(self):
        token = issue_reset_token("ada", now=1000)
        with self.assertRaises(TokenExpired) as cm:
            redeem_reset_token(token, now=2800.001)
        self.assertEqual(str(cm.exception), "token expired")

    def test_float_timestamps(self):
        token = issue_reset_token("ada", now=1000.5)
        self.assertEqual(redeem_reset_token(token, now=2800.5), "ada")

    def test_float_boundary_has_no_rounding_error(self):
        # (issued + 1800) - issued == 1800.0000002384186 for this value.
        issued = 2147483647.26
        token = issue_reset_token("ada", now=issued)
        self.assertEqual(redeem_reset_token(token, now=issued + 1800), "ada")

    def test_default_now_uses_time_time_at_call_time(self):
        with mock.patch("shop.auth.time.time", return_value=5000.0):
            token = issue_reset_token("ada")
        with mock.patch("shop.auth.time.time", return_value=5000.0 + 1801):
            with self.assertRaises(TokenExpired):
                redeem_reset_token(token)

    def test_default_now_within_ttl_succeeds(self):
        with mock.patch("shop.auth.time.time", return_value=5000.0):
            token = issue_reset_token("ada")
        with mock.patch("shop.auth.time.time", return_value=5000.0 + 60):
            self.assertEqual(redeem_reset_token(token), "ada")

    def test_redeem_returns_username_then_token_is_used(self):
        token = issue_reset_token("ada", now=0)
        self.assertEqual(redeem_reset_token(token, now=10), "ada")
        with self.assertRaises(TokenUsed) as cm:
            redeem_reset_token(token, now=20)
        self.assertEqual(str(cm.exception), "token already used")

    def test_used_token_past_expiry_raises_token_used(self):
        token = issue_reset_token("ada", now=0)
        redeem_reset_token(token, now=100)
        with self.assertRaises(TokenUsed):
            redeem_reset_token(token, now=1801)

    def test_expired_redeem_does_not_consume_token(self):
        token = issue_reset_token("ada", now=0)
        with self.assertRaises(TokenExpired) as first:
            redeem_reset_token(token, now=1801)
        self.assertEqual(str(first.exception), "token expired")
        with self.assertRaises(TokenExpired) as second:
            redeem_reset_token(token, now=1801)
        self.assertEqual(str(second.exception), "token expired")

    def test_token_expired_is_invalid_token(self):
        self.assertTrue(issubclass(TokenExpired, InvalidToken))

    def test_token_used_is_invalid_token(self):
        self.assertTrue(issubclass(TokenUsed, InvalidToken))

    def test_unknown_empty_token_is_plain_invalid_token(self):
        with self.assertRaises(InvalidToken) as cm:
            redeem_reset_token("", now=0)
        self.assertIs(type(cm.exception), InvalidToken)
        self.assertEqual(str(cm.exception), "unknown token")

    def test_unknown_none_token_is_plain_invalid_token(self):
        with self.assertRaises(InvalidToken) as cm:
            redeem_reset_token(None, now=0)
        self.assertIs(type(cm.exception), InvalidToken)
        self.assertEqual(str(cm.exception), "unknown token")

    def test_two_tokens_for_same_user_are_independent(self):
        first = issue_reset_token("ada", now=0)
        second = issue_reset_token("ada", now=0)
        self.assertEqual(redeem_reset_token(first, now=1), "ada")
        self.assertEqual(redeem_reset_token(second, now=1), "ada")

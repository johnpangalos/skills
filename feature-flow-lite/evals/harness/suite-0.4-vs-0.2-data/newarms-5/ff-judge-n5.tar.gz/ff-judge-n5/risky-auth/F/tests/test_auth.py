import threading
import unittest
from unittest import mock

from shop.auth import (
    InvalidToken,
    TokenExpired,
    TokenUsed,
    issue_reset_token,
    redeem_reset_token,
)


class ResetTokenTest(unittest.TestCase):
    def test_round_trip(self):
        token = issue_reset_token("ada")
        self.assertEqual(redeem_reset_token(token), "ada")

    def test_unknown_token(self):
        with self.assertRaises(InvalidToken):
            redeem_reset_token("not-a-token")

    def test_default_now_uses_time_at_call(self):
        with mock.patch("shop.auth.time") as fake_time:
            fake_time.time.return_value = 1000.0
            token = issue_reset_token("ada")
            fake_time.time.return_value = 1000.0 + 1801
            with self.assertRaises(TokenExpired):
                redeem_reset_token(token)

    def test_exact_boundary_is_valid(self):
        token = issue_reset_token("ada", now=1000)
        self.assertEqual(redeem_reset_token(token, now=1000 + 1800), "ada")

    def test_just_past_boundary_is_expired(self):
        token = issue_reset_token("ada", now=1000)
        with self.assertRaises(TokenExpired) as cm:
            redeem_reset_token(token, now=1000 + 1800.001)
        self.assertEqual(str(cm.exception), "token expired")

    def test_reuse_is_token_used(self):
        token = issue_reset_token("ada", now=1000)
        redeem_reset_token(token, now=1000)
        with self.assertRaises(TokenUsed) as cm:
            redeem_reset_token(token, now=1000)
        self.assertEqual(str(cm.exception), "token already used")

    def test_reuse_after_expiry_window_is_token_used(self):
        token = issue_reset_token("ada", now=1000)
        redeem_reset_token(token, now=1000)
        with self.assertRaises(TokenUsed):
            redeem_reset_token(token, now=5000)

    def test_expired_twice_stays_expired(self):
        token = issue_reset_token("ada", now=1000)
        with self.assertRaises(TokenExpired):
            redeem_reset_token(token, now=3000)
        with self.assertRaises(TokenExpired):
            redeem_reset_token(token, now=3000)

    def test_now_zero_is_honoured(self):
        expired = issue_reset_token("ada", now=0)
        with self.assertRaises(TokenExpired):
            redeem_reset_token(expired, now=1801)
        valid = issue_reset_token("ada", now=0)
        self.assertEqual(redeem_reset_token(valid, now=0), "ada")

    def test_concurrent_redemption_succeeds_once(self):
        token = issue_reset_token("ada", now=1000)
        threads = 8
        barrier = threading.Barrier(threads)
        outcomes = []

        def attempt():
            barrier.wait()
            try:
                outcomes.append(redeem_reset_token(token, now=1000))
            except TokenUsed:
                outcomes.append("used")

        workers = [threading.Thread(target=attempt) for _ in range(threads)]
        for worker in workers:
            worker.start()
        for worker in workers:
            worker.join()
        self.assertEqual(outcomes.count("ada"), 1)
        self.assertEqual(outcomes.count("used"), threads - 1)

    def test_float_timestamps(self):
        token = issue_reset_token("ada", now=1000.5)
        self.assertEqual(redeem_reset_token(token, now=2800.5), "ada")

    def test_clock_skew_before_issue_is_not_expired(self):
        token = issue_reset_token("ada", now=5000)
        self.assertEqual(redeem_reset_token(token, now=1000), "ada")

    def test_expired_and_used_are_invalid_tokens(self):
        self.assertTrue(issubclass(TokenExpired, InvalidToken))
        self.assertTrue(issubclass(TokenUsed, InvalidToken))

    def test_unknown_token_is_plain_invalid_token(self):
        with self.assertRaises(InvalidToken) as cm:
            redeem_reset_token("not-a-token")
        self.assertIs(type(cm.exception), InvalidToken)
        self.assertEqual(str(cm.exception), "unknown token")

    def test_empty_token_is_invalid(self):
        with self.assertRaises(InvalidToken) as cm:
            redeem_reset_token("")
        self.assertIs(type(cm.exception), InvalidToken)

    def test_tokens_for_same_user_are_independent(self):
        first = issue_reset_token("ada", now=1000)
        second = issue_reset_token("ada", now=1000)
        self.assertEqual(redeem_reset_token(first, now=1000), "ada")
        self.assertEqual(redeem_reset_token(second, now=1000), "ada")

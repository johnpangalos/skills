"""Password-reset tokens (in-memory store)."""

import secrets
import time
from dataclasses import dataclass

RESET_TOKEN_TTL = 1800  # seconds

_TOKENS = {}  # token -> _Token


@dataclass
class _Token:
    username: str
    issued_at: float
    used: bool = False


class InvalidToken(Exception):
    pass


class TokenExpired(InvalidToken):
    pass


class TokenUsed(InvalidToken):
    pass


def issue_reset_token(username, now=None):
    """Create a reset token for username."""
    if now is None:
        now = time.time()
    token = secrets.token_urlsafe(16)
    _TOKENS[token] = _Token(username, now)
    return token


def redeem_reset_token(token, now=None):
    """Return the username a token was issued for, once."""
    if now is None:
        now = time.time()
    record = _TOKENS.get(token)
    if record is None:
        raise InvalidToken("unknown token")
    if record.used:
        raise TokenUsed("token already used")
    if now - record.issued_at > RESET_TOKEN_TTL:
        raise TokenExpired("token expired")
    record.used = True
    return record.username

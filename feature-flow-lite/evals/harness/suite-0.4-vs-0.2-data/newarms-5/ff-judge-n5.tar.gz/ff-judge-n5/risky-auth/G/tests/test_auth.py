import unittest
from unittest import mock

from shop.auth import (
    InvalidToken,
    TokenExpired,
    TokenUsed,
    issue_reset_token,
    redeem_reset_token,
)


class ResetTokenTest(unittest.TestCase):
    def test_round_trip(self):
        token = issue_reset_token("ada")
        self.assertEqual(redeem_reset_token(token), "ada")

    def test_unknown_token(self):
        with self.assertRaises(InvalidToken):
            redeem_reset_token("not-a-token")

    def test_default_now_reads_clock_at_call_time(self):
        with mock.patch("shop.auth.time") as fake_time:
            fake_time.time.return_value = 5000.0
            token = issue_reset_token("ada")
            fake_time.time.return_value = 5000.0 + 1801
            with self.assertRaises(TokenExpired):
                redeem_reset_token(token)

    def test_valid_at_exactly_ttl(self):
        token = issue_reset_token("ada", now=100)
        self.assertEqual(redeem_reset_token(token, now=1900), "ada")

    def test_expired_just_past_ttl(self):
        token = issue_reset_token("ada", now=100)
        with self.assertRaises(TokenExpired) as ctx:
            redeem_reset_token(token, now=1900.001)
        self.assertEqual(str(ctx.exception), "token expired")

    def test_zero_issue_time_is_valid_at_ttl(self):
        token = issue_reset_token("ada", now=0)
        self.assertEqual(redeem_reset_token(token, now=1800), "ada")

    def test_redeem_earlier_than_issue_is_valid(self):
        token = issue_reset_token("ada", now=1000)
        self.assertEqual(redeem_reset_token(token, now=900), "ada")

    def test_float_times_valid_at_ttl(self):
        token = issue_reset_token("ada", now=100.5)
        self.assertEqual(redeem_reset_token(token, now=1900.5), "ada")

    def test_float_times_expired_past_ttl(self):
        token = issue_reset_token("ada", now=100.5)
        with self.assertRaises(TokenExpired):
            redeem_reset_token(token, now=1900.6)

    def test_second_redeem_is_token_used(self):
        token = issue_reset_token("ada", now=0)
        self.assertEqual(redeem_reset_token(token, now=0), "ada")
        with self.assertRaises(TokenUsed) as ctx:
            redeem_reset_token(token, now=0)
        self.assertEqual(str(ctx.exception), "token already used")

    def test_used_token_redeemed_past_expiry_is_token_used(self):
        token = issue_reset_token("ada", now=0)
        self.assertEqual(redeem_reset_token(token, now=10), "ada")
        with self.assertRaises(TokenUsed):
            redeem_reset_token(token, now=5000)

    def test_expired_token_stays_expired_on_second_redeem(self):
        token = issue_reset_token("ada", now=0)
        with self.assertRaises(TokenExpired):
            redeem_reset_token(token, now=1801)
        with self.assertRaises(TokenExpired) as ctx:
            redeem_reset_token(token, now=1801)
        self.assertEqual(str(ctx.exception), "token expired")

    def test_token_used_and_expired_are_invalid_tokens(self):
        self.assertTrue(issubclass(TokenExpired, InvalidToken))
        self.assertTrue(issubclass(TokenUsed, InvalidToken))

    def test_unknown_none_and_empty_tokens_are_plain_invalid_token(self):
        for bad in ("not-a-token", None, ""):
            with self.subTest(token=bad):
                with self.assertRaises(InvalidToken) as ctx:
                    redeem_reset_token(bad)
                self.assertIs(type(ctx.exception), InvalidToken)
                self.assertEqual(str(ctx.exception), "unknown token")

    def test_second_token_for_same_user_leaves_first_valid(self):
        first = issue_reset_token("ada", now=0)
        second = issue_reset_token("ada", now=0)
        self.assertEqual(redeem_reset_token(first, now=0), "ada")
        self.assertEqual(redeem_reset_token(second, now=0), "ada")

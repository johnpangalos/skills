import fs from 'node:fs'
import path from 'node:path'
import { describe, expect, it, test } from 'vitest'
import { compile, Features, Polyfills } from '.'
import { cartesian } from './cartesian'
import type { PluginAPI } from './compat/plugin-api'
import plugin from './plugin'
import { compileCss, run } from './test-utils/run'

const css = String.raw

describe('compiling CSS', () => {
  test('`@tailwind utilities` is replaced with the generated utility classes', async () => {
    expect(
      await run(
        ['flex', 'md:grid', 'hover:underline', 'dark:bg-black'],
        css`
          @theme {
            --color-black: #000;
            --breakpoint-md: 768px;
          }

          @layer utilities {
            @tailwind utilities;
          }
        `,
      ),
    ).toMatchInlineSnapshot(`
      "
      :root, :host {
        --color-black: #000;
      }

      @layer utilities {
        .flex {
          display: flex;
        }

        @media (hover: hover) {
          .hover\\:underline:hover {
            text-decoration-line: underline;
          }
        }

        @media (min-width: 768px) {
          .md\\:grid {
            display: grid;
          }
        }

        @media (prefers-color-scheme: dark) {
          .dark\\:bg-black {
            background-color: var(--color-black);
          }
        }
      }
      "
    `)
  })

  test('that only CSS variables are allowed', () => {
    return expect(
      run(
        ['bg-primary'],
        css`
          @theme {
            --color-primary: red;
            .foo {
              --color-primary: blue;
            }
          }
          @tailwind utilities;
        `,
      ),
    ).rejects.toThrowErrorMatchingInlineSnapshot(`
      [Error: \`@theme\` blocks must only contain custom properties or \`@keyframes\`.

        @theme {
      >   .foo {
      >     --color-primary: blue;
      >   }
        }
        ]
    `)
  })

  test('`@tailwind utilities` is only processed once', async () => {
    expect(
      await run(
        ['flex', 'grid'],
        css`
          @tailwind utilities;
          @tailwind utilities;
        `,
      ),
    ).toMatchInlineSnapshot(`
      "
      .flex {
        display: flex;
      }

      .grid {
        display: grid;
      }
      "
    `)
  })

  test('`@tailwind utilities` is replaced by utilities using the default theme', async () => {
    let defaultTheme = fs.readFileSync(path.resolve(__dirname, '..', 'theme.css'), 'utf-8')

    expect(
      await run(
        ['bg-red-500', 'w-4', 'sm:flex', 'shadow-sm'],
        css`
          ${defaultTheme}
          @tailwind utilities;
        `,
      ),
    ).toMatchSnapshot()
  })

  test('prefix all CSS variables inside preflight', async () => {
    expect(
      await run(
        ['font-mono'],
        css`
          @import 'tailwindcss' prefix(tw);
          @tailwind utilities;
        `,
        {
          async loadStylesheet(id) {
            return {
              path: '',
              base: '',
              content: fs.readFileSync(
                path.resolve(__dirname, '..', id === 'tailwindcss' ? 'index.css' : id),
                'utf-8',
              ),
            }
          },
        },
      ),
    ).toMatchSnapshot()
  })

  test('unescapes underscores to spaces inside arbitrary values except for `url()` and first argument of `var()` and `theme()`', async () => {
    expect(
      await run(
        [
          'bg-[no-repeat_url(./my_file.jpg)]',
          'ml-[var(--spacing-1_5,_var(--spacing-2_5,_1rem))]',
          'ml-[theme(--spacing-1_5,theme(--spacing-2_5,_1rem)))]',
        ],
        css`
          @theme {
            --spacing-1_5: 1.5rem;
            --spacing-2_5: 2.5rem;
          }
          @tailwind utilities;
        `,
      ),
    ).toMatchInlineSnapshot(`
      "
      :root, :host {
        --spacing-1_5: 1.5rem;
        --spacing-2_5: 2.5rem;
      }

      .ml-\\[theme\\(--spacing-1_5\\,theme\\(--spacing-2_5\\,_1rem\\)\\)\\)\\] {
        margin-left: 1.5rem;
      }

      .ml-\\[var\\(--spacing-1_5\\,_var\\(--spacing-2_5\\,_1rem\\)\\)\\] {
        margin-left: var(--spacing-1_5, var(--spacing-2_5, 1rem));
      }

      .bg-\\[no-repeat_url\\(\\.\\/my_file\\.jpg\\)\\] {
        background-color: no-repeat url("./my_file.jpg");
      }
      "
    `)
  })

  test('unescapes theme variables and handles dots as underscore', async () => {
    expect(
      await run(
        ['m-1.5', 'm-2.5', 'm-2_5', 'm-3.5', 'm-foo/bar'],
        css`
          @theme {
            --spacing-*: initial;
            --spacing-1\.5: 1.5px;
            --spacing-2_5: 2.5px;
            --spacing-3\.5: 3.5px;
            --spacing-3_5: 3.5px;
            --spacing-foo\/bar: 3rem;
          }
          @tailwind utilities;
        `,
      ),
    ).toMatchInlineSnapshot(`
      "
      :root, :host {
        --spacing-1\\.5: 1.5px;
        --spacing-2_5: 2.5px;
        --spacing-3\\.5: 3.5px;
        --spacing-foo\\/bar: 3rem;
      }

      .m-1\\.5 {
        margin: var(--spacing-1\\.5);
      }

      .m-2\\.5, .m-2_5 {
        margin: var(--spacing-2_5);
      }

      .m-3\\.5 {
        margin: var(--spacing-3\\.5);
      }

      .m-foo\\/bar {
        margin: var(--spacing-foo\\/bar);
      }
      "
    `)
  })

  test('adds vendor prefixes', async () => {
    expect(await run(['[text-size-adjust:none]'])).toMatchInlineSnapshot(`
      "
      .\\[text-size-adjust\\:none\\] {
        -webkit-text-size-adjust: none;
        -moz-text-size-adjust: none;
        text-size-adjust: none;
      }
      "
    `)
  })
})

describe('arbitrary properties', () => {
  it('should generate arbitrary properties', async () => {
    expect(await run(['[color:red]'])).toMatchInlineSnapshot(`
      "
      .\\[color\\:red\\] {
        color: red;
      }
      "
    `)
  })

  it('should generate arbitrary properties with modifiers', async () => {
    expect(await run(['[color:red]/50'])).toMatchInlineSnapshot(`
      "
      .\\[color\\:red\\]\\/50 {
        color: oklab(62.7955% .224 .125 / .5);
      }
      "
    `)
  })

  it('should not generate arbitrary properties with invalid modifiers', async () => {
    expect(await run(['[color:red]/not-a-percentage'])).toEqual('')
  })

  it('should generate arbitrary properties with variables and with modifiers', async () => {
    expect(await run(['[color:var(--my-color)]/50'])).toMatchInlineSnapshot(`
      "
      .\\[color\\:var\\(--my-color\\)\\]\\/50 {
        color: var(--my-color);
      }

      @supports (color: color-mix(in lab, red, red)) {
        .\\[color\\:var\\(--my-color\\)\\]\\/50 {
          color: color-mix(in oklab, var(--my-color) 50%, transparent);
        }
      }
      "
    `)
  })
})

describe('@apply', () => {
  it('@apply in @keyframes is not allowed', () => {
    return expect(() =>
      compileCss(css`
        @keyframes foo {
          0% {
            @apply bg-red-500;
          }
        }
      `),
    ).rejects.toThrowErrorMatchingInlineSnapshot(
      `[Error: You cannot use \`@apply\` inside \`@keyframes\`.]`,
    )
  })

  it('@apply referencing theme values without `@tailwind utilities` or `@reference` should error', () => {
    return expect(() =>
      compileCss(css`
        .foo {
          @apply p-2;
        }
      `),
    ).rejects.toThrowErrorMatchingInlineSnapshot(
      `[Error: Cannot apply unknown utility class \`p-2\`. Are you using CSS modules or similar and missing \`@reference\`? https://tailwindcss.com/docs/functions-and-directives#reference-directive]`,
    )
  })

  it('@apply referencing theme values with `@tailwind utilities` should work', async () => {
    return expect(
      await compileCss(
        css`
          @import 'tailwindcss';

          .foo {
            @apply p-2;
          }
        `,
        {
          async loadStylesheet() {
            return {
              path: '',
              base: '/',
              content: css`
                @theme {
                  --spacing: 0.25rem;
                }
                @tailwind utilities;
              `,
            }
          },
        },
      ),
    ).toMatchInlineSnapshot(`
      "
      :root, :host {
        --spacing: .25rem;
      }

      .foo {
        padding: calc(var(--spacing) * 2);
      }
      "
    `)
  })

  it('@apply referencing theme values with `@reference` should work', async () => {
    return expect(
      await compileCss(
        css`
          @reference "style.css";

          .foo {
            @apply p-2;
          }
        `,
        {
          async loadStylesheet() {
            return {
              path: '',
              base: '/',
              content: css`
                @theme {
                  --spacing: 0.25rem;
                }
                @tailwind utilities;
              `,
            }
          },
        },
      ),
    ).toMatchInlineSnapshot(`
      "
      .foo {
        padding: calc(var(--spacing, .25rem) * 2);
      }
      "
    `)
  })

  it('should replace @apply with the correct result', async () => {
    expect(
      await compileCss(css`
        @theme {
          --color-red-200: #fecaca;
          --color-red-500: #ef4444;
          --color-blue-500: #3b82f6;
          --color-green-200: #bbf7d0;
          --color-green-500: #22c55e;
          --breakpoint-md: 768px;
          --animate-spin: spin 1s linear infinite;

          @keyframes spin {
            to {
              transform: rotate(360deg);
            }
          }
        }

        @tailwind utilities;

        .foo {
          @apply underline bg-red-500 hover:bg-blue-500 md:bg-green-500 animate-spin translate-x-full;

          &:hover:focus {
            @apply bg-red-200 md:bg-green-200;
          }
        }
      `),
    ).toMatchInlineSnapshot(`
      "
      @layer properties {
        @supports (((-webkit-hyphens: none)) and (not (margin-trim: inline))) or ((-moz-orient: inline) and (not (color: rgb(from red r g b)))) {
          *, :before, :after, ::backdrop {
            --tw-translate-x: 0;
            --tw-translate-y: 0;
            --tw-translate-z: 0;
          }
        }
      }

      :root, :host {
        --color-red-200: #fecaca;
        --color-red-500: #ef4444;
        --color-blue-500: #3b82f6;
        --color-green-200: #bbf7d0;
        --color-green-500: #22c55e;
        --animate-spin: spin 1s linear infinite;
      }

      .foo {
        --tw-translate-x: 100%;
        translate: var(--tw-translate-x) var(--tw-translate-y);
        animation: var(--animate-spin);
        background-color: var(--color-red-500);
        text-decoration-line: underline;
      }

      @media (hover: hover) {
        .foo:hover {
          background-color: var(--color-blue-500);
        }
      }

      @media (min-width: 768px) {
        .foo {
          background-color: var(--color-green-500);
        }
      }

      .foo:hover:focus {
        background-color: var(--color-red-200);
      }

      @media (min-width: 768px) {
        .foo:hover:focus {
          background-color: var(--color-green-200);
        }
      }

      @property --tw-translate-x {
        syntax: "*";
        inherits: false;
        initial-value: 0;
      }

      @property --tw-translate-y {
        syntax: "*";
        inherits: false;
        initial-value: 0;
      }

      @property --tw-translate-z {
        syntax: "*";
        inherits: false;
        initial-value: 0;
      }

      @keyframes spin {
        to {
          transform: rotate(360deg);
        }
      }
      "
    `)
  })

  it('should replace @apply with the correct result inside imported stylesheets', async () => {
    expect(
      await compileCss(
        css`
          @import './bar.css';
          @tailwind utilities;
        `,
        {
          async loadStylesheet() {
            return {
              path: '',
              base: '/bar.css',
              content: css`
                .foo {
                  @apply underline;
                }
              `,
            }
          },
        },
      ),
    ).toMatchInlineSnapshot(`
      "
      .foo {
        text-decoration-line: underline;
      }
      "
    `)
  })

  it('should @apply in order the utilities would be sorted in if they were used in HTML', async () => {
    expect(
      await compileCss(css`
        @tailwind utilities;

        .foo {
          @apply content-["a"] content-["b"];
        }

        .bar {
          @apply content-["b"] content-["a"];
        }
      `),
    ).toMatchInlineSnapshot(`
      "
      @layer properties {
        @supports (((-webkit-hyphens: none)) and (not (margin-trim: inline))) or ((-moz-orient: inline) and (not (color: rgb(from red r g b)))) {
          *, :before, :after, ::backdrop {
            --tw-content: "";
          }
        }
      }

      .foo, .bar {
        --tw-content: "b";
        content: var(--tw-content);
      }

      @property --tw-content {
        syntax: "*";
        inherits: false;
        initial-value: "";
      }
      "
    `)
  })

  it('@apply does not cache important state', async () => {
    expect(
      await compileCss(css`
        .c1 {
          @apply leading-none;
        }
        .c2 {
          @apply leading-none!;
        }
        .c3 {
          @apply leading-none;
        }
      `),
    ).toMatchInlineSnapshot(`
      "
      @layer properties {
        @supports (((-webkit-hyphens: none)) and (not (margin-trim: inline))) or ((-moz-orient: inline) and (not (color: rgb(from red r g b)))) {
          *, :before, :after, ::backdrop {
            --tw-leading: initial;
          }
        }
      }

      .c1 {
        --tw-leading: 1;
        line-height: 1;
      }

      .c2 {
        --tw-leading: 1 !important;
        line-height: 1 !important;
      }

      .c3 {
        --tw-leading: 1;
        line-height: 1;
      }

      @property --tw-leading {
        syntax: "*";
        inherits: false
      }
      "
    `)
  })

  it('should error when using @apply with a utility that does not exist', async () => {
    await expect(
      compile(css`
        @tailwind utilities;

        .foo {
          @apply bg-not-found;
        }
      `),
    ).rejects.toThrowErrorMatchingInlineSnapshot(
      `[Error: Cannot apply unknown utility class \`bg-not-found\`. Are you using CSS modules or similar and missing \`@reference\`? https://tailwindcss.com/docs/functions-and-directives#reference-directive]`,
    )
  })

  it('should error when using @apply with a variant that does not exist', async () => {
    await expect(
      compile(css`
        @tailwind utilities;
        @theme {
          --color-red-500: red;
        }

        .foo {
          @apply hocus:hover:pocus:bg-red-500;
        }
      `),
    ).rejects.toThrowErrorMatchingInlineSnapshot(
      `[Error: Cannot apply utility class \`hocus:hover:pocus:bg-red-500\` because the \`hocus\` and \`pocus\` variants do not exist.]`,
    )
  })

  it('should not error with trailing whitespace', async () => {
    expect(
      await compileCss(`
        @tailwind utilities;

        .foo {
          @apply flex ;
        }
      `),
    ).toMatchInlineSnapshot(`
      "
      .foo {
        display: flex;
      }
      "
    `)
  })

  it('should be possible to apply a custom utility', async () => {
    expect(
      await compileCss(css`
        @utility bar {
          &:before {
            content: 'bar';
          }
        }

        .foo {
          /* Baz is defined after this rule, but should work */
          @apply bar baz;
        }

        @utility baz {
          &:after {
            content: 'baz';
          }
        }

        @tailwind utilities;
      `),
    ).toMatchInlineSnapshot(`
      "
      .foo:before {
        content: "bar";
      }

      .foo:after {
        content: "baz";
      }
      "
    `)
  })

  it('should recursively apply with custom `@utility`, which is used before it is defined', async () => {
    expect(
      await run(
        ['a', 'b', 'c', 'flex', 'my-flex'],
        css`
          @tailwind utilities;

          @layer base {
            body {
              @apply a;
            }
          }

          @utility a {
            @apply b;
          }

          @utility b {
            @apply focus:c;
          }

          @utility c {
            @apply my-flex!;
          }

          @utility my-flex {
            @apply flex;
          }
        `,
      ),
    ).toMatchInlineSnapshot(`
      "
      .a:focus, .b:focus, .c {
        display: flex !important;
      }

      .flex, .my-flex {
        display: flex;
      }

      @layer base {
        body:focus {
          display: flex !important;
        }
      }
      "
    `)
  })

  // https://github.com/tailwindlabs/tailwindcss/issues/16935
  it('should not swallow @utility declarations when @apply is used in nested rules', async () => {
    expect(
      await run(
        ['custom-utility'],
        css`
          @tailwind utilities;

          .ignore-me {
            @apply underline;
            div {
              @apply custom-utility;
            }
          }

          @utility custom-utility {
            @apply flex;
          }
        `,
      ),
    ).toMatchInlineSnapshot(`
      "
      .custom-utility {
        display: flex;
      }

      .ignore-me {
        text-decoration-line: underline;
      }

      .ignore-me div {
        display: flex;
      }
      "
    `)
  })

  // https://github.com/tailwindlabs/tailwindcss/issues/17924
  it('should correctly apply nested usages of @apply when one @utility applies another', async () => {
    expect(
      await run(
        ['foo', 'test', 'test2'],
        css`
          @theme {
            --color-green-500: green;
            --color-red-500: red;
            --color-indigo-500: indigo;
          }

          @tailwind utilities;

          @utility test2 {
            @apply test;
          }

          @utility test {
            @apply bg-green-500;
            &:hover {
              @apply bg-red-500;
            }
            &:disabled {
              @apply bg-indigo-500;
            }
          }

          .foo {
            @apply test2;
          }
        `,
      ),
    ).toMatchInlineSnapshot(`
      "
      :root, :host {
        --color-green-500: green;
        --color-red-500: red;
        --color-indigo-500: indigo;
      }

      .test {
        background-color: var(--color-green-500);
      }

      .test:hover {
        background-color: var(--color-red-500);
      }

      .test:disabled {
        background-color: var(--color-indigo-500);
      }

      .test2 {
        background-color: var(--color-green-500);
      }

      .test2:hover {
        background-color: var(--color-red-500);
      }

      .test2:disabled {
        background-color: var(--color-indigo-500);
      }

      .foo {
        background-color: var(--color-green-500);
      }

      .foo:hover {
        background-color: var(--color-red-500);
      }

      .foo:disabled {
        background-color: var(--color-indigo-500);
      }
      "
    `)
  })

  // https://github.com/tailwindlabs/tailwindcss/issues/18400
  it('should ignore the design systems `important` flag when using @apply', async () => {
    expect(
      await run(
        ['flex'],
        css`
          @import 'tailwindcss/utilities' important;
          .flex-explicitly-important {
            @apply flex!;
          }
          .flex-not-important {
            @apply flex;
          }
        `,
        {
          async loadStylesheet(_, base) {
            return {
              content: '@tailwind utilities;',
              base,
              path: '',
            }
          },
        },
      ),
    ).toMatchInlineSnapshot(`
      "
      .flex, .flex-explicitly-important {
        display: flex !important;
      }

      .flex-not-important {
        display: flex;
      }
      "
    `)
  })

  it('should be usable with CSS mixins', async () => {
    let input = css`
      .foo {
        /* Utility usage */
        @apply underline;

        /* CSS mixin usage */
        @apply --my-mixin-1;
        @apply --my-mixin-1();
        @apply --my-mixin-1 --my-mixin-2;
        @apply --my-mixin-1() --my-mixin-2();
        @apply --my-mixin-3 {
          color: red;
        }
      }
    `

    expect(await compileCss(input)).toMatchInlineSnapshot(`
      "
      .foo {
        text-decoration-line: underline;
        @apply --my-mixin-1;
        @apply --my-mixin-1();
        @apply --my-mixin-1 --my-mixin-2;
        @apply --my-mixin-1() --my-mixin-2();
        @apply --my-mixin-3 {
          color: red;
        }
      }
      "
    `)
  })

  it('should error when trying to use mixins and utilities together', async () => {
    await expect(
      compile(css`
        .foo {
          @apply underline --my-mixin-1;
        }
      `),
    ).rejects.toThrowErrorMatchingInlineSnapshot(
      `[Error: You cannot use \`@apply\` with both mixins and utilities. Please move \`@apply --my-mixin-1\` into a separate rule.]`,
    )

    await expect(
      compile(css`
        .foo {
          @apply --my-mixin-1 underline;
        }
      `),
    ).rejects.toThrowErrorMatchingInlineSnapshot(
      `[Error: You cannot use \`@apply\` with both mixins and utilities. Please move \`@apply --my-mixin-1\` into a separate rule.]`,
    )
  })

  it('should error when used with a body', async () => {
    await expect(
      compile(css`
        .foo {
          @apply underline {
            color: red;
          }
        }
      `),
    ).rejects.toThrowErrorMatchingInlineSnapshot(
      `[Error: The rule \`@apply underline\` must not have a body.]`,
    )
  })
})

describe('arbitrary variants', () => {
  it('should generate arbitrary variants', async () => {
    expect(await run(['[&_p]:flex'])).toMatchInlineSnapshot(`
      "
      .\\[\\&_p\\]\\:flex p {
        display: flex;
      }
      "
    `)
  })

  it('should generate arbitrary at-rule variants', async () => {
    expect(await run(['[@media(width>=123px)]:flex'])).toMatchInlineSnapshot(`
      "
      @media (min-width: 123px) {
        .\\[\\@media\\(width\\>\\=123px\\)\\]\\:flex {
          display: flex;
        }
      }
      "
    `)
  })

  it('discards arbitrary variants using relative selectors', async () => {
    expect(await run(['[>img]:flex', '[+img]:flex', '[~img]:flex'])).toBe('')
  })
})

describe('variant stacking', () => {
  it('should stack simple variants', async () => {
    expect(await run(['focus:hover:flex'])).toMatchInlineSnapshot(`
      "
      @media (hover: hover) {
        .focus\\:hover\\:flex:focus:hover {
          display: flex;
        }
      }
      "
    `)
  })

  it('should stack arbitrary variants and simple variants', async () => {
    expect(await run(['[&_p]:hover:flex'])).toMatchInlineSnapshot(`
      "
      @media (hover: hover) {
        .\\[\\&_p\\]\\:hover\\:flex p:hover {
          display: flex;
        }
      }
      "
    `)
  })

  it('should stack multiple arbitrary variants', async () => {
    expect(await run(['[&_p]:[@media(width>=123px)]:flex'])).toMatchInlineSnapshot(`
      "
      @media (min-width: 123px) {
        .\\[\\&_p\\]\\:\\[\\@media\\(width\\>\\=123px\\)\\]\\:flex p {
          display: flex;
        }
      }
      "
    `)
  })

  it('pseudo element variants are re-ordered', async () => {
    expect(await run(['before:hover:flex', 'hover:before:flex'])).toMatchInlineSnapshot(`
      "
      @layer properties {
        @supports (((-webkit-hyphens: none)) and (not (margin-trim: inline))) or ((-moz-orient: inline) and (not (color: rgb(from red r g b)))) {
          *, :before, :after, ::backdrop {
            --tw-content: "";
          }
        }
      }

      .before\\:hover\\:flex:before {
        content: var(--tw-content);
      }

      @media (hover: hover) {
        .before\\:hover\\:flex:before:hover {
          display: flex;
        }

        .hover\\:before\\:flex:hover:before {
          content: var(--tw-content);
          display: flex;
        }
      }

      @property --tw-content {
        syntax: "*";
        inherits: false;
        initial-value: "";
      }
      "
    `)
  })
})

describe('important', () => {
  it('should generate an important utility', async () => {
    expect(await run(['underline!'])).toMatchInlineSnapshot(`
      "
      .underline\\! {
        text-decoration-line: underline !important;
      }
      "
    `)
  })

  it('should generate an important utility with legacy syntax', async () => {
    expect(await run(['!underline'])).toMatchInlineSnapshot(`
      "
      .\\!underline {
        text-decoration-line: underline !important;
      }
      "
    `)
  })

  it('should not mark declarations inside of @keyframes as important', async () => {
    expect(
      await run(
        ['animate-spin!'],
        css`
          @theme {
            --animate-spin: spin 1s linear infinite;

            @keyframes spin {
              to {
                transform: rotate(360deg);
              }
            }
          }
          @tailwind utilities;
        `,
      ),
    ).toMatchInlineSnapshot(`
      "
      :root, :host {
        --animate-spin: spin 1s linear infinite;
      }

      .animate-spin\\! {
        animation: var(--animate-spin) !important;
      }

      @keyframes spin {
        to {
          transform: rotate(360deg);
        }
      }
      "
    `)
  })

  it('should generate an important arbitrary property utility', async () => {
    expect(await run(['[color:red]!'])).toMatchInlineSnapshot(`
      "
      .\\[color\\:red\\]\\! {
        color: red !important;
      }
      "
    `)
  })
})

describe('sorting', () => {
  it('should sort utilities based on their property order', async () => {
    expect(
      await run(
        ['pointer-events-none', 'flex', 'p-1', 'px-1', 'pl-1'].sort(() => Math.random() - 0.5),
        css`
          @theme {
            --spacing-1: 0.25rem;
          }
          @tailwind utilities;
        `,
      ),
    ).toMatchInlineSnapshot(`
      "
      :root, :host {
        --spacing-1: .25rem;
      }

      .pointer-events-none {
        pointer-events: none;
      }

      .flex {
        display: flex;
      }

      .p-1 {
        padding: var(--spacing-1);
      }

      .px-1 {
        padding-inline: var(--spacing-1);
      }

      .pl-1 {
        padding-left: var(--spacing-1);
      }
      "
    `)
  })

  it('should sort based on amount of properties', async () => {
    expect(await run(['text-clip', 'truncate', 'overflow-scroll'])).toMatchInlineSnapshot(`
      "
      .truncate {
        text-overflow: ellipsis;
        white-space: nowrap;
        overflow: hidden;
      }

      .overflow-scroll {
        overflow: scroll;
      }

      .text-clip {
        text-overflow: clip;
      }
      "
    `)
  })

  /**
   * Space utilities are implemented using margin, but they act more like a
   * polyfill for gap. This means that they should be sorted near gap, not
   * margin.
   */
  it('should sort utilities with a custom internal --tw-sort correctly', async () => {
    expect(
      await run(
        ['mx-0', 'gap-4', 'space-x-2'].sort(() => Math.random() - 0.5),
        css`
          @theme {
            --spacing-0: 0px;
            --spacing-2: 0.5rem;
            --spacing-4: 1rem;
          }
          @tailwind utilities;
        `,
      ),
    ).toMatchInlineSnapshot(`
      "
      @layer properties {
        @supports (((-webkit-hyphens: none)) and (not (margin-trim: inline))) or ((-moz-orient: inline) and (not (color: rgb(from red r g b)))) {
          *, :before, :after, ::backdrop {
            --tw-space-x-reverse: 0;
          }
        }
      }

      :root, :host {
        --spacing-0: 0px;
        --spacing-2: .5rem;
        --spacing-4: 1rem;
      }

      .mx-0 {
        margin-inline: var(--spacing-0);
      }

      .gap-4 {
        gap: var(--spacing-4);
      }

      :where(.space-x-2 > :not(:last-child)) {
        --tw-space-x-reverse: 0;
        margin-inline-start: calc(var(--spacing-2) * var(--tw-space-x-reverse));
        margin-inline-end: calc(var(--spacing-2) * calc(1 - var(--tw-space-x-reverse)));
      }

      @property --tw-space-x-reverse {
        syntax: "*";
        inherits: false;
        initial-value: 0;
      }
      "
    `)
  })

  it('should sort individual logical properties later than left/right pairs', async () => {
    expect(
      await run(
        [
          // scroll-margin
          'scroll-ms-1',
          'scroll-me-2',
          'scroll-mx-3',

          // scroll-padding
          'scroll-ps-1',
          'scroll-pe-2',
          'scroll-px-3',

          // margin
          'ms-1',
          'me-2',
          'mx-3',

          // padding
          'ps-1',
          'pe-2',
          'px-3',
        ].sort(() => Math.random() - 0.5),
        css`
          @theme {
            --spacing-1: 1px;
            --spacing-2: 2px;
            --spacing-3: 3px;
          }
          @tailwind utilities;
        `,
      ),
    ).toMatchInlineSnapshot(`
      "
      :root, :host {
        --spacing-1: 1px;
        --spacing-2: 2px;
        --spacing-3: 3px;
      }

      .mx-3 {
        margin-inline: var(--spacing-3);
      }

      .ms-1 {
        margin-inline-start: var(--spacing-1);
      }

      .me-2 {
        margin-inline-end: var(--spacing-2);
      }

      .scroll-mx-3 {
        scroll-margin-inline: var(--spacing-3);
      }

      .scroll-ms-1 {
        scroll-margin-inline-start: var(--spacing-1);
      }

      .scroll-me-2 {
        scroll-margin-inline-end: var(--spacing-2);
      }

      .scroll-px-3 {
        scroll-padding-inline: var(--spacing-3);
      }

      .scroll-ps-1 {
        scroll-padding-inline-start: var(--spacing-1);
      }

      .scroll-pe-2 {
        scroll-padding-inline-end: var(--spacing-2);
      }

      .px-3 {
        padding-inline: var(--spacing-3);
      }

      .ps-1 {
        padding-inline-start: var(--spacing-1);
      }

      .pe-2 {
        padding-inline-end: var(--spacing-2);
      }
      "
    `)
  })

  it('should move variants to the end while sorting', async () => {
    expect(
      await run(
        ['pointer-events-none', 'flex', 'hover:flex', 'focus:pointer-events-none'].sort(
          () => Math.random() - 0.5,
        ),
      ),
    ).toMatchInlineSnapshot(`
      "
      .pointer-events-none {
        pointer-events: none;
      }

      .flex {
        display: flex;
      }

      @media (hover: hover) {
        .hover\\:flex:hover {
          display: flex;
        }
      }

      .focus\\:pointer-events-none:focus {
        pointer-events: none;
      }
      "
    `)
  })

  /**
   * Every variant should be sorted by its position in the variant list. Every
   * combination of variants that exist before the current variant should always
   * be sorted before the current variant.
   *
   * Given the following list of variants:
   * 1. `hover`
   * 2. `focus`
   * 3. `disabled`
   *
   * This means that `hover` should be before `focus`, `focus` should be before
   * `disabled`. This also means that the combination of `hover` and `focus`
   * (stacked variants) should be before `disabled` because all used variants
   * are defined before the `disabled` variant.
   */
  it('should sort variants and stacked variants by variant position', async () => {
    expect(
      await run(
        ['flex', 'hover:flex', 'focus:flex', 'disabled:flex', 'hover:focus:flex'].sort(
          () => Math.random() - 0.5,
        ),
      ),
    ).toMatchInlineSnapshot(`
      "
      .flex {
        display: flex;
      }

      @media (hover: hover) {
        .hover\\:flex:hover {
          display: flex;
        }
      }

      .focus\\:flex:focus {
        display: flex;
      }

      @media (hover: hover) {
        .hover\\:focus\\:flex:hover:focus {
          display: flex;
        }
      }

      .disabled\\:flex:disabled {
        display: flex;
      }
      "
    `)
  })

  // TODO: Extend this test with user-defined variants to ensure they are sorted
  // correctly.
  it('should order group-* and peer-* variants based on the sort order of the group and peer variant but also based on the variant they are wrapping', async () => {
    expect(
      await run(
        [
          'hover:flex',

          'group-hover:flex',
          'group-focus:flex',

          'peer-hover:flex',
          'peer-focus:flex',

          'group-hover:peer-hover:flex',
          'group-hover:peer-focus:flex',
          'peer-hover:group-hover:flex',
          'peer-hover:group-focus:flex',
          'group-focus:peer-hover:flex',
          'group-focus:peer-focus:flex',
          'peer-focus:group-hover:flex',
          'peer-focus:group-focus:flex',
        ].sort(() => Math.random() - 0.5),
      ),
    ).toMatchInlineSnapshot(`
      "
      @media (hover: hover) {
        :is(:where(.group):hover .group-hover\\:flex) {
          display: flex;
        }
      }

      :is(:where(.group):focus .group-focus\\:flex) {
        display: flex;
      }

      @media (hover: hover) {
        :is(:where(.peer):hover ~ .peer-hover\\:flex) {
          display: flex;
        }

        @media (hover: hover) {
          :is(:where(.peer):hover ~ :is(:where(.group):hover .group-hover\\:peer-hover\\:flex)), :is(:where(.group):hover :is(:where(.peer):hover ~ .peer-hover\\:group-hover\\:flex)) {
            display: flex;
          }
        }

        :is(:where(.peer):hover ~ :is(:where(.group):focus .group-focus\\:peer-hover\\:flex)), :is(:where(.group):focus :is(:where(.peer):hover ~ .peer-hover\\:group-focus\\:flex)) {
          display: flex;
        }
      }

      :is(:where(.peer):focus ~ .peer-focus\\:flex) {
        display: flex;
      }

      @media (hover: hover) {
        :is(:where(.peer):focus ~ :is(:where(.group):hover .group-hover\\:peer-focus\\:flex)), :is(:where(.group):hover :is(:where(.peer):focus ~ .peer-focus\\:group-hover\\:flex)) {
          display: flex;
        }
      }

      :is(:where(.peer):focus ~ :is(:where(.group):focus .group-focus\\:peer-focus\\:flex)), :is(:where(.group):focus :is(:where(.peer):focus ~ .peer-focus\\:group-focus\\:flex)) {
        display: flex;
      }

      @media (hover: hover) {
        .hover\\:flex:hover {
          display: flex;
        }
      }
      "
    `)
  })

  // https://github.com/tailwindlabs/tailwindcss/issues/16973
  it('should not take undefined values into account when sorting', async () => {
    expect(
      await run(
        ['fancy-text', 'text-sm'],
        css`
          @theme {
            --text-sm: 0.875rem;
            --text-sm--line-height: calc(1.25 / 0.875);
          }
          @tailwind utilities;
          @utility fancy-text {
            font-size: var(--text-4xl);
            line-height: var(--text-4xl--line-height);
            font-weight: var(--font-weight-bold);
          }
        `,
      ),
    ).toMatchInlineSnapshot(`
      "
      :root, :host {
        --text-sm: .875rem;
        --text-sm--line-height: calc(1.25 / .875);
      }

      .fancy-text {
        font-size: var(--text-4xl);
        line-height: var(--text-4xl--line-height);
        font-weight: var(--font-weight-bold);
      }

      .text-sm {
        font-size: var(--text-sm);
        line-height: var(--tw-leading, var(--text-sm--line-height));
      }
      "
    `)
  })
})

describe('Parsing theme values from CSS', () => {
  test('Can read values from `@theme`', async () => {
    expect(
      await run(
        ['accent-red-500'],
        css`
          @theme {
            --color-red-500: #f00;
          }
          @tailwind utilities;
        `,
      ),
    ).toMatchInlineSnapshot(`
      "
      :root, :host {
        --color-red-500: red;
      }

      .accent-red-500 {
        accent-color: var(--color-red-500);
      }
      "
    `)
  })

  test('Later values from `@theme` override earlier ones', async () => {
    expect(
      await run(
        ['accent-red-500'],
        css`
          @theme {
            --color-red-500: #f00;
            --color-red-500: #f10;
          }
          @tailwind utilities;
        `,
      ),
    ).toMatchInlineSnapshot(`
      "
      :root, :host {
        --color-red-500: #f10;
      }

      .accent-red-500 {
        accent-color: var(--color-red-500);
      }
      "
    `)
  })

  test('Multiple `@theme` blocks are merged', async () => {
    expect(
      await run(
        ['accent-red-500', 'accent-blue-500'],
        css`
          @theme {
            --color-red-500: #f00;
          }
          @theme {
            --color-blue-500: #00f;
          }
          @tailwind utilities;
        `,
      ),
    ).toMatchInlineSnapshot(`
      "
      :root, :host {
        --color-red-500: red;
        --color-blue-500: #00f;
      }

      .accent-blue-500 {
        accent-color: var(--color-blue-500);
      }

      .accent-red-500 {
        accent-color: var(--color-red-500);
      }
      "
    `)
  })

  test('`@theme` values with escaped forward slashes map to unescaped slashes in candidate values', async () => {
    expect(
      await run(
        ['w-1/2', 'w-75%'],
        css`
          @theme {
            /* Cursed but we want this to work */
            --width-1\/2: 75%;
            --width-75\%: 50%;
          }
          @tailwind utilities;
        `,
      ),
    ).toMatchInlineSnapshot(`
      "
      :root, :host {
        --width-1\\/2: 75%;
        --width-75\\%: 50%;
      }

      .w-1\\/2 {
        width: var(--width-1\\/2);
      }

      .w-75\\% {
        width: var(--width-75\\%);
      }
      "
    `)
  })

  // https://github.com/tailwindlabs/tailwindcss/issues/19786
  test('out-of-range escaped CSS variable candidates do not crash the build', async () => {
    // Shouldn't crash
    await run([
      String.raw`--Coding-Projects-CharacterMapper-Master-Workspace\d8819554-4725-4235-9d22-2d0ed572e924`,
    ])
  })

  test('`@keyframes` in `@theme` are hoisted', async () => {
    expect(
      await run(
        ['accent-red', 'text-lg'],
        css`
          @theme {
            --color-red: red;
            --animate-foo: foo 1s infinite;

            @keyframes foo {
              to {
                opacity: 1;
              }
            }

            --text-lg: 20px;
          }
          @tailwind utilities;
        `,
      ),
    ).toMatchInlineSnapshot(`
      "
      :root, :host {
        --color-red: red;
        --text-lg: 20px;
      }

      .text-lg {
        font-size: var(--text-lg);
      }

      .accent-red {
        accent-color: var(--color-red);
      }
      "
    `)
  })

  test('`@keyframes` in `@theme` are generated when name contains a new line', async () => {
    expect(
      await run(
        ['animate-very-long-animation-name'],
        css`
          @theme {
            --animate-very-long-animation-name: very-long-animation-name
              var(
                --very-long-animation-name-configuration,
                2.5s ease-in-out 0s infinite normal none running
              );

            @keyframes very-long-animation-name {
              to {
                opacity: 1;
              }
            }
          }

          @tailwind utilities;
        `,
      ),
    ).toMatchInlineSnapshot(`
      "
      :root, :host {
        --animate-very-long-animation-name: very-long-animation-name
                    var(--very-long-animation-name-configuration, 2.5s ease-in-out 0s infinite normal none running);
      }

      .animate-very-long-animation-name {
        animation: var(--animate-very-long-animation-name);
      }

      @keyframes very-long-animation-name {
        to {
          opacity: 1;
        }
      }
      "
    `)
  })

  test('`@theme` values can be unset', async () => {
    expect(
      await run(
        ['accent-red', 'accent-blue', 'accent-green', 'text-sm', 'text-md'],
        css`
          @theme {
            --color-red: #f00;
            --color-blue: #00f;
            --text-sm: 13px;
            --text-md: 16px;

            --animate-spin: spin 1s infinite linear;

            @keyframes spin {
              to {
                transform: rotate(360deg);
              }
            }
          }
          @theme {
            --color-*: initial;
            --text-md: initial;
            --animate-*: initial;
            --keyframes-*: initial;
          }
          @theme {
            --color-green: #0f0;
          }
          @tailwind utilities;
        `,
      ),
    ).toMatchInlineSnapshot(`
      "
      :root, :host {
        --text-sm: 13px;
        --color-green: #0f0;
      }

      .text-sm {
        font-size: var(--text-sm);
      }

      .accent-green {
        accent-color: var(--color-green);
      }
      "
    `)
  })

  test('`@theme` values can be unset (using the escaped syntax)', async () => {
    expect(
      await run(
        ['accent-red', 'accent-blue', 'accent-green', 'text-sm', 'text-md'],
        css`
          @theme {
            --color-red: #f00;
            --color-blue: #00f;
            --text-sm: 13px;
            --text-md: 16px;

            --animate-spin: spin 1s infinite linear;

            @keyframes spin {
              to {
                transform: rotate(360deg);
              }
            }
          }
          @theme {
            --color-\*: initial;
            --text-md: initial;
            --animate-\*: initial;
            --keyframes-\*: initial;
          }
          @theme {
            --color-green: #0f0;
          }
          @tailwind utilities;
        `,
      ),
    ).toMatchInlineSnapshot(`
      "
      :root, :host {
        --text-sm: 13px;
        --color-green: #0f0;
      }

      .text-sm {
        font-size: var(--text-sm);
      }

      .accent-green {
        accent-color: var(--color-green);
      }
      "
    `)
  })

  test('all `@theme` values can be unset at once', async () => {
    expect(
      await run(
        ['accent-red', 'accent-blue', 'accent-green', 'text-sm', 'text-md'],
        css`
          @theme {
            --color-red: #f00;
            --color-blue: #00f;
            --font-size-sm: 13px;
            --font-size-md: 16px;
          }
          @theme {
            --*: initial;
          }
          @theme {
            --color-green: #0f0;
          }
          @tailwind utilities;
        `,
      ),
    ).toMatchInlineSnapshot(`
      "
      :root, :host {
        --color-green: #0f0;
      }

      .accent-green {
        accent-color: var(--color-green);
      }
      "
    `)
  })

  test('unsetting `--font-*` does not unset `--font-weight-*`', async () => {
    expect(
      await run(
        ['font-bold', 'font-sans', 'font-serif', 'font-body'],
        css`
          @theme {
            --font-weight-bold: bold;
            --font-sans: sans-serif;
            --font-serif: serif;
          }
          @theme {
            --font-*: initial;
            --font-body: Inter;
          }
          @tailwind utilities;
        `,
      ),
    ).toMatchInlineSnapshot(`
      "
      @layer properties {
        @supports (((-webkit-hyphens: none)) and (not (margin-trim: inline))) or ((-moz-orient: inline) and (not (color: rgb(from red r g b)))) {
          *, :before, :after, ::backdrop {
            --tw-font-weight: initial;
          }
        }
      }

      :root, :host {
        --font-weight-bold: bold;
        --font-body: Inter;
      }

      .font-body {
        font-family: var(--font-body);
      }

      .font-bold {
        --tw-font-weight: var(--font-weight-bold);
        font-weight: var(--font-weight-bold);
      }

      @property --tw-font-weight {
        syntax: "*";
        inherits: false
      }
      "
    `)
  })

  test('unsetting `--inset-*` does not unset `--inset-shadow-*`', async () => {
    expect(
      await run(
        ['inset-shadow-sm', 'inset-ring-thick', 'inset-lg', 'inset-sm', 'inset-md'],
        css`
          @theme {
            --inset-shadow-sm: inset 0 2px 4px rgb(0 0 0 / 0.05);
            --inset-lg: 100px;
            --inset-sm: 10px;
          }
          @theme {
            --inset-*: initial;
            --inset-md: 50px;
          }
          @tailwind utilities;
        `,
      ),
    ).toMatchInlineSnapshot(`
      "
      @layer properties {
        @supports (((-webkit-hyphens: none)) and (not (margin-trim: inline))) or ((-moz-orient: inline) and (not (color: rgb(from red r g b)))) {
          *, :before, :after, ::backdrop {
            --tw-shadow: 0 0 #0000;
            --tw-shadow-color: initial;
            --tw-shadow-alpha: 100%;
            --tw-inset-shadow: 0 0 #0000;
            --tw-inset-shadow-color: initial;
            --tw-inset-shadow-alpha: 100%;
            --tw-ring-color: initial;
            --tw-ring-shadow: 0 0 #0000;
            --tw-inset-ring-color: initial;
            --tw-inset-ring-shadow: 0 0 #0000;
            --tw-ring-inset: initial;
            --tw-ring-offset-width: 0px;
            --tw-ring-offset-color: #fff;
            --tw-ring-offset-shadow: 0 0 #0000;
          }
        }
      }

      :root, :host {
        --inset-md: 50px;
      }

      .inset-md {
        inset: var(--inset-md);
      }

      .inset-shadow-sm {
        --tw-inset-shadow: inset 0 2px 4px var(--tw-inset-shadow-color, #0000000d);
        box-shadow: var(--tw-inset-shadow), var(--tw-inset-ring-shadow), var(--tw-ring-offset-shadow), var(--tw-ring-shadow), var(--tw-shadow);
      }

      @property --tw-shadow {
        syntax: "*";
        inherits: false;
        initial-value: 0 0 #0000;
      }

      @property --tw-shadow-color {
        syntax: "*";
        inherits: false
      }

      @property --tw-shadow-alpha {
        syntax: "<percentage>";
        inherits: false;
        initial-value: 100%;
      }

      @property --tw-inset-shadow {
        syntax: "*";
        inherits: false;
        initial-value: 0 0 #0000;
      }

      @property --tw-inset-shadow-color {
        syntax: "*";
        inherits: false
      }

      @property --tw-inset-shadow-alpha {
        syntax: "<percentage>";
        inherits: false;
        initial-value: 100%;
      }

      @property --tw-ring-color {
        syntax: "*";
        inherits: false
      }

      @property --tw-ring-shadow {
        syntax: "*";
        inherits: false;
        initial-value: 0 0 #0000;
      }

      @property --tw-inset-ring-color {
        syntax: "*";
        inherits: false
      }

      @property --tw-inset-ring-shadow {
        syntax: "*";
        inherits: false;
        initial-value: 0 0 #0000;
      }

      @property --tw-ring-inset {
        syntax: "*";
        inherits: false
      }

      @property --tw-ring-offset-width {
        syntax: "<length>";
        inherits: false;
        initial-value: 0;
      }

      @property --tw-ring-offset-color {
        syntax: "*";
        inherits: false;
        initial-value: #fff;
      }

      @property --tw-ring-offset-shadow {
        syntax: "*";
        inherits: false;
        initial-value: 0 0 #0000;
      }
      "
    `)
  })

  test('unsetting `--text-*` does not unset `--text-color-*`, `--text-underline-offset-*`, `--text-indent-*`, `--text-decoration-thickness-*` or `--text-decoration-color-*`', async () => {
    expect(
      await run(
        [
          'text-potato',
          'underline-offset-potato',
          'indent-potato',
          'decoration-potato',
          'decoration-salad',
          'text-lg',
        ],
        css`
          @theme {
            --text-color-potato: brown;
            --text-underline-offset-potato: 4px;
            --text-indent-potato: 6px;
            --text-decoration-thickness-potato: 8px;
            --text-decoration-color-salad: yellow;
            --text-4xl: 60px;
          }
          @theme {
            --text-*: initial;
            --text-lg: 20px;
          }
          @tailwind utilities;
        `,
      ),
    ).toMatchInlineSnapshot(`
      "
      :root, :host {
        --text-color-potato: brown;
        --text-underline-offset-potato: 4px;
        --text-indent-potato: 6px;
        --text-decoration-thickness-potato: 8px;
        --text-decoration-color-salad: yellow;
        --text-lg: 20px;
      }

      .indent-potato {
        text-indent: var(--text-indent-potato);
      }

      .text-lg {
        font-size: var(--text-lg);
      }

      .text-potato {
        color: var(--text-color-potato);
      }

      .decoration-salad {
        -webkit-text-decoration-color: var(--text-decoration-color-salad);
        -webkit-text-decoration-color: var(--text-decoration-color-salad);
        text-decoration-color: var(--text-decoration-color-salad);
      }

      .decoration-potato {
        text-decoration-thickness: var(--text-decoration-thickness-potato);
      }

      .underline-offset-potato {
        text-underline-offset: var(--text-underline-offset-potato);
      }
      "
    `)
  })

  test('unused keyframes are removed when an animation is unset', async () => {
    expect(
      await run(
        ['animate-foo', 'animate-foobar'],
        css`
          @theme {
            --animate-foo: foo 1s infinite;
            --animate-foobar: foobar 1s infinite;

            @keyframes foo {
              to {
                opacity: 1;
              }
            }

            @keyframes foobar {
              to {
                opacity: 0;
              }
            }
          }
          @theme {
            --animate-foo: initial;
          }
          @tailwind utilities;
        `,
      ),
    ).toMatchInlineSnapshot(`
      "
      :root, :host {
        --animate-foobar: foobar 1s infinite;
      }

      .animate-foobar {
        animation: var(--animate-foobar);
      }

      @keyframes foobar {
        to {
          opacity: 0;
        }
      }
      "
    `)
  })

  test('keyframes are generated when used in an animation', async () => {
    expect(
      await run(
        ['animate-foo'],
        css`
          @theme {
            --animate-foo: used 1s infinite;
            --animate-bar: unused 1s infinite;

            @keyframes used {
              to {
                opacity: 1;
              }
            }

            @keyframes unused {
              to {
                opacity: 0;
              }
            }
          }

          @tailwind utilities;
        `,
      ),
    ).toMatchInlineSnapshot(`
      "
      :root, :host {
        --animate-foo: used 1s infinite;
      }

      .animate-foo {
        animation: var(--animate-foo);
      }

      @keyframes used {
        to {
          opacity: 1;
        }
      }
      "
    `)
  })

  test('keyframes are generated when used in an animation within a prefixed setup', async () => {
    expect(
      await run(
        ['tw:animate-foo'],
        css`
          @theme prefix(tw) {
            --animate-foo: used 1s infinite;
            --animate-bar: unused 1s infinite;

            @keyframes used {
              to {
                opacity: 1;
              }
            }

            @keyframes unused {
              to {
                opacity: 0;
              }
            }
          }

          @tailwind utilities;
        `,
      ),
    ).toMatchInlineSnapshot(`
      "
      :root, :host {
        --tw-animate-foo: used 1s infinite;
      }

      .tw\\:animate-foo {
        animation: var(--tw-animate-foo);
      }

      @keyframes used {
        to {
          opacity: 1;
        }
      }
      "
    `)
  })

  test('custom properties are generated when used from a CSS var with a prefixed setup', async () => {
    expect(
      await compileCss(css`
        @theme prefix(tw) {
          --color-tomato: #e10c04;
        }
        @tailwind utilities;
        .red {
          color: var(--tw-color-tomato);
        }
      `),
    ).toMatchInlineSnapshot(`
      "
      :root, :host {
        --tw-color-tomato: #e10c04;
      }

      .red {
        color: var(--tw-color-tomato);
      }
      "
    `)
  })

  // https://github.com/tailwindlabs/tailwindcss/issues/16374
  test('custom properties in keyframes preserved', async () => {
    expect(
      await run(
        ['animate-foo'],
        css`
          @theme {
            --animate-foo: used 1s infinite;

            @keyframes used {
              to {
                --other: var(--angle);
                --angle: 360deg;
              }
            }
          }

          @tailwind utilities;
        `,
      ),
    ).toMatchInlineSnapshot(`
      "
      :root, :host {
        --animate-foo: used 1s infinite;
      }

      .animate-foo {
        animation: var(--animate-foo);
      }

      @keyframes used {
        to {
          --other: var(--angle);
          --angle: 360deg;
        }
      }
      "
    `)
  })

  test('keyframes are generated when used in an animation using `@theme inline`', async () => {
    expect(
      await run(
        ['animate-foo'],
        css`
          @theme inline {
            --animate-foo: used 1s infinite;
            --animate-bar: unused 1s infinite;

            @keyframes used {
              to {
                opacity: 1;
              }
            }

            @keyframes unused {
              to {
                opacity: 0;
              }
            }
          }

          @tailwind utilities;
        `,
      ),
    ).toMatchInlineSnapshot(`
      "
      .animate-foo {
        animation: 1s infinite used;
      }

      @keyframes used {
        to {
          opacity: 1;
        }
      }
      "
    `)
  })

  test('keyframes are generated when used in an animation using `@theme static`', async () => {
    expect(
      await run(
        ['animate-foo'],
        css`
          @theme static {
            --animate-foo: used 1s infinite;
            --animate-bar: unused-but-kept 1s infinite;

            @keyframes used {
              to {
                opacity: 1;
              }
            }

            @keyframes unused-but-kept {
              to {
                opacity: 0;
              }
            }
          }

          @tailwind utilities;
        `,
      ),
    ).toMatchInlineSnapshot(`
      "
      :root, :host {
        --animate-foo: used 1s infinite;
        --animate-bar: unused-but-kept 1s infinite;
      }

      .animate-foo {
        animation: var(--animate-foo);
      }

      @keyframes used {
        to {
          opacity: 1;
        }
      }

      @keyframes unused-but-kept {
        to {
          opacity: 0;
        }
      }
      "
    `)
  })

  test('keyframes are generated when used in user CSS', async () => {
    expect(
      await compileCss(css`
        @theme {
          @keyframes used {
            to {
              opacity: 1;
            }
          }

          @keyframes unused {
            to {
              opacity: 0;
            }
          }
        }

        .foo {
          animation: used 1s infinite;
        }

        @tailwind utilities;
      `),
    ).toMatchInlineSnapshot(`
      "
      .foo {
        animation: 1s infinite used;
      }

      @keyframes used {
        to {
          opacity: 1;
        }
      }
      "
    `)
  })

  // https://github.com/tailwindlabs/tailwindcss/issues/17332
  test('extracts keyframe names followed by comma', async () => {
    expect(
      await run(
        ['animate-test'],
        css`
          @theme {
            --animate-test: 500ms both fade-in, 1000ms linear 500ms spin infinite;

            @keyframes fade-in {
              from {
                opacity: 0%;
              }
              to {
                opacity: 100%;
              }
            }
          }

          @tailwind utilities;
        `,
      ),
    ).toMatchInlineSnapshot(`
      "
      :root, :host {
        --animate-test: .5s both fade-in, 1s linear .5s spin infinite;
      }

      .animate-test {
        animation: var(--animate-test);
      }

      @keyframes fade-in {
        from {
          opacity: 0;
        }

        to {
          opacity: 1;
        }
      }
      "
    `)
  })

  test('keyframes outside of `@theme are always preserved', async () => {
    expect(
      await compileCss(css`
        @theme {
          @keyframes used {
            to {
              opacity: 1;
            }
          }
        }

        @keyframes unused {
          to {
            opacity: 0;
          }
        }

        .foo {
          animation: used 1s infinite;
        }

        @tailwind utilities;
      `),
    ).toMatchInlineSnapshot(`
      "
      @keyframes unused {
        to {
          opacity: 0;
        }
      }

      .foo {
        animation: 1s infinite used;
      }

      @keyframes used {
        to {
          opacity: 1;
        }
      }
      "
    `)
  })

  test('theme values added as reference are not included in the output as variables but emit fallback values', async () => {
    expect(
      await run(
        ['bg-tomato', 'bg-potato'],
        css`
          @theme {
            --color-tomato: #e10c04;
          }
          @theme reference {
            --color-potato: #ac855b;
          }
          @tailwind utilities;
        `,
      ),
    ).toMatchInlineSnapshot(`
      "
      :root, :host {
        --color-tomato: #e10c04;
      }

      .bg-potato {
        background-color: var(--color-potato, #ac855b);
      }

      .bg-tomato {
        background-color: var(--color-tomato);
      }
      "
    `)
  })

  test('`@keyframes` added in `@theme reference` should not be emitted', async () => {
    return expect(
      await run(
        ['animate-foo'],
        css`
          @theme reference {
            --animate-foo: foo 1s infinite;

            @keyframes foo {
              0%,
              100% {
                color: red;
              }
              50% {
                color: blue;
              }
            }
          }
          @tailwind utilities;
        `,
      ),
    ).toMatchInlineSnapshot(`
      "
      .animate-foo {
        animation: var(--animate-foo, foo 1s infinite);
      }

      @keyframes foo {
        0%, 100% {
          color: red;
        }

        50% {
          color: #00f;
        }
      }
      "
    `)
  })

  test('`@keyframes` added in `@theme reference` should not be emitted, even if another `@theme` block exists', async () => {
    return expect(
      await run(
        ['bg-pink', 'animate-foo'],
        css`
          @theme reference {
            --animate-foo: foo 1s infinite;

            @keyframes foo {
              0%,
              100% {
                color: red;
              }
              50% {
                color: blue;
              }
            }
          }

          @theme {
            --color-pink: pink;
          }

          @tailwind utilities;
        `,
      ),
    ).toMatchInlineSnapshot(`
      "
      :root, :host {
        --color-pink: pink;
      }

      .animate-foo {
        animation: var(--animate-foo, foo 1s infinite);
      }

      .bg-pink {
        background-color: var(--color-pink);
      }

      @keyframes foo {
        0%, 100% {
          color: red;
        }

        50% {
          color: #00f;
        }
      }
      "
    `)
  })

  test('theme values added as reference that override existing theme value suppress the output of the original theme value as a variable', async () => {
    expect(
      await run(
        ['bg-potato'],
        css`
          @theme {
            --color-potato: #ac855b;
          }
          @theme reference {
            --color-potato: #c794aa;
          }
          @tailwind utilities;
        `,
      ),
    ).toMatchInlineSnapshot(`
      "
      .bg-potato {
        background-color: var(--color-potato, #c794aa);
      }
      "
    `)
  })

  test('overriding a reference theme value with a non-reference theme value includes it in the output as a variable', async () => {
    expect(
      await run(
        ['bg-potato'],
        css`
          @theme reference {
            --color-potato: #ac855b;
          }
          @theme {
            --color-potato: #c794aa;
          }
          @tailwind utilities;
        `,
      ),
    ).toMatchInlineSnapshot(`
      "
      :root, :host {
        --color-potato: #c794aa;
      }

      .bg-potato {
        background-color: var(--color-potato);
      }
      "
    `)
  })

  test('wrapping `@theme` with `@media reference` behaves like `@theme reference` to support `@import` statements', async () => {
    expect(
      await run(
        ['bg-tomato', 'bg-potato', 'bg-avocado'],
        css`
          @theme {
            --color-tomato: #e10c04;
          }
          @media theme(reference) {
            @theme {
              --color-potato: #ac855b;
            }
            @theme {
              --color-avocado: #c0cc6d;
            }
          }
          @tailwind utilities;
        `,
      ),
    ).toMatchInlineSnapshot(`
      "
      :root, :host {
        --color-tomato: #e10c04;
      }

      .bg-avocado {
        background-color: var(--color-avocado, #c0cc6d);
      }

      .bg-potato {
        background-color: var(--color-potato, #ac855b);
      }

      .bg-tomato {
        background-color: var(--color-tomato);
      }
      "
    `)
  })

  test('`@import "tailwindcss" theme(static)` will always generate theme values, regardless of whether they were used or not', async () => {
    expect(
      await run(
        ['bg-tomato'],
        css`
          @import 'tailwindcss' theme(static);
        `,
        {
          async loadStylesheet() {
            return {
              path: '',
              base: '',
              content: css`
                @theme {
                  --color-tomato: #e10c04;
                  --color-potato: #ac855b;
                  --color-primary: var(--primary);
                }

                @tailwind utilities;
              `,
            }
          },
        },
      ),
    ).toMatchInlineSnapshot(`
      "
      :root, :host {
        --color-tomato: #e10c04;
        --color-potato: #ac855b;
        --color-primary: var(--primary);
      }

      .bg-tomato {
        background-color: var(--color-tomato);
      }
      "
    `)
  })

  test('`@media theme(reference)` can only contain `@theme` rules', () => {
    return expect(
      run(
        ['bg-tomato', 'bg-potato', 'bg-avocado'],
        css`
          @media theme(reference) {
            .not-a-theme-rule {
              color: cursed;
            }
          }
          @tailwind utilities;
        `,
      ),
    ).rejects.toThrowErrorMatchingInlineSnapshot(
      `
      [Error: Files imported with \`@import "…" theme(reference)\` must only contain \`@theme\` blocks.
      Use \`@reference "…";\` instead.]
    `,
    )
  })

  test('theme values added as `inline` are not wrapped in `var(…)` when used as utility values', async () => {
    expect(
      await run(
        ['bg-tomato', 'bg-potato', 'bg-primary'],
        css`
          @theme inline {
            --color-tomato: #e10c04;
            --color-potato: #ac855b;
            --color-primary: var(--primary);
          }

          @tailwind utilities;
        `,
      ),
    ).toMatchInlineSnapshot(`
      "
      .bg-potato {
        background-color: #ac855b;
      }

      .bg-primary {
        background-color: var(--primary);
      }

      .bg-tomato {
        background-color: #e10c04;
      }
      "
    `)
  })

  test('`@import "tailwindcss" theme(inline)` theme values added as `inline` are not wrapped in `var(…)` when used as utility values', async () => {
    expect(
      await run(
        ['bg-tomato'],
        css`
          @import 'tailwindcss' theme(inline);
        `,
        {
          async loadStylesheet() {
            return {
              path: '',
              base: '',
              content: css`
                @theme {
                  --color-tomato: #e10c04;
                  --color-potato: #ac855b;
                  --color-primary: var(--primary);
                }

                @tailwind utilities;
              `,
            }
          },
        },
      ),
    ).toMatchInlineSnapshot(`
      "
      .bg-tomato {
        background-color: #e10c04;
      }
      "
    `)
  })

  test('theme values added as `static` will always be generated, regardless of whether they were used or not', async () => {
    expect(
      await run(
        ['bg-tomato'],
        css`
          @theme static {
            --color-tomato: #e10c04;
            --color-potato: #ac855b;
            --color-primary: var(--primary);
          }

          @tailwind utilities;
        `,
      ),
    ).toMatchInlineSnapshot(`
      "
      :root, :host {
        --color-tomato: #e10c04;
        --color-potato: #ac855b;
        --color-primary: var(--primary);
      }

      .bg-tomato {
        background-color: var(--color-tomato);
      }
      "
    `)
  })

  test('when no theme values are emitted, empty layers can be removed', async () => {
    expect(
      await run(
        ['underline'],
        css`
          @layer theme1 {
            @layer theme2 {
              @theme {
                --color-tomato: #e10c04;
                --color-potato: #ac855b;
              }
            }
          }

          @tailwind utilities;
        `,
      ),
    ).toMatchInlineSnapshot(`
      "
      .underline {
        text-decoration-line: underline;
      }
      "
    `)
  })

  test('wrapping `@theme` with `@media theme(inline)` behaves like `@theme inline` to support `@import` statements', async () => {
    expect(
      await run(
        ['bg-tomato', 'bg-potato', 'bg-primary'],
        css`
          @media theme(inline) {
            @theme {
              --color-tomato: #e10c04;
              --color-potato: #ac855b;
              --color-primary: var(--primary);
            }
          }

          @tailwind utilities;
        `,
      ),
    ).toMatchInlineSnapshot(`
      "
      .bg-potato {
        background-color: #ac855b;
      }

      .bg-primary {
        background-color: var(--primary);
      }

      .bg-tomato {
        background-color: #e10c04;
      }
      "
    `)
  })

  test('`inline` and `reference` can be used together', async () => {
    expect(
      await run(
        ['bg-tomato', 'bg-potato', 'bg-primary'],
        css`
          @theme reference inline {
            --color-tomato: #e10c04;
            --color-potato: #ac855b;
            --color-primary: var(--primary);
          }

          @tailwind utilities;
        `,
      ),
    ).toMatchInlineSnapshot(`
      "
      .bg-potato {
        background-color: #ac855b;
      }

      .bg-primary {
        background-color: var(--primary);
      }

      .bg-tomato {
        background-color: #e10c04;
      }
      "
    `)
  })

  test('`inline` and `reference` can be used together in `media(…)`', async () => {
    expect(
      await run(
        ['bg-tomato', 'bg-potato', 'bg-primary'],
        css`
          @media theme(reference inline) {
            @theme {
              --color-tomato: #e10c04;
              --color-potato: #ac855b;
              --color-primary: var(--primary);
            }
          }

          @tailwind utilities;
        `,
      ),
    ).toMatchInlineSnapshot(`
      "
      .bg-potato {
        background-color: #ac855b;
      }

      .bg-primary {
        background-color: var(--primary);
      }

      .bg-tomato {
        background-color: #e10c04;
      }
      "
    `)
  })

  test('`default` theme values can be overridden by regular theme values`', async () => {
    expect(
      await run(
        ['bg-potato'],
        css`
          @theme {
            --color-potato: #ac855b;
          }
          @theme default {
            --color-potato: #efb46b;
          }

          @tailwind utilities;
        `,
      ),
    ).toMatchInlineSnapshot(`
      "
      :root, :host {
        --color-potato: #ac855b;
      }

      .bg-potato {
        background-color: var(--color-potato);
      }
      "
    `)
  })

  test('`default` and `inline` can be used together', async () => {
    expect(
      await run(
        ['bg-potato'],
        css`
          @theme default inline {
            --color-potato: #efb46b;
          }

          @tailwind utilities;
        `,
      ),
    ).toMatchInlineSnapshot(`
      "
      .bg-potato {
        background-color: #efb46b;
      }
      "
    `)
  })

  test('`default` and `reference` can be used together', async () => {
    expect(
      await run(
        ['bg-potato'],
        css`
          @theme default reference {
            --color-potato: #efb46b;
          }

          @tailwind utilities;
        `,
      ),
    ).toMatchInlineSnapshot(`
      "
      .bg-potato {
        background-color: var(--color-potato, #efb46b);
      }
      "
    `)
  })

  test('`default`, `inline`, and `reference` can be used together', async () => {
    expect(
      await run(
        ['bg-potato'],
        css`
          @theme default reference inline {
            --color-potato: #efb46b;
          }

          @tailwind utilities;
        `,
      ),
    ).toMatchInlineSnapshot(`
      "
      .bg-potato {
        background-color: #efb46b;
      }
      "
    `)
  })

  test('`default` can be used in `media(…)`', async () => {
    expect(
      await run(
        ['bg-potato', 'bg-tomato'],
        css`
          @media theme() {
            @theme {
              --color-potato: #ac855b;
            }
          }
          @media theme(default) {
            @theme {
              --color-potato: #efb46b;
              --color-tomato: tomato;
            }
          }

          @tailwind utilities;
        `,
      ),
    ).toMatchInlineSnapshot(`
      "
      :root, :host {
        --color-potato: #ac855b;
        --color-tomato: tomato;
      }

      .bg-potato {
        background-color: var(--color-potato);
      }

      .bg-tomato {
        background-color: var(--color-tomato);
      }
      "
    `)
  })

  test('`default` theme values can be overridden by plugin theme values', async () => {
    expect(
      await run(
        ['text-red', 'text-orange'],
        css`
          @theme default {
            --color-red: red;
          }
          @theme {
            --color-orange: orange;
          }
          @plugin "my-plugin";
          @tailwind utilities;
        `,
        {
          loadModule: async () => {
            return {
              path: '',
              base: '/root',
              module: plugin(({}) => {}, {
                theme: {
                  extend: {
                    colors: {
                      red: 'tomato',
                      orange: '#f28500',
                    },
                  },
                },
              }),
            }
          },
        },
      ),
    ).toMatchInlineSnapshot(`
      "
      :root, :host {
        --color-orange: orange;
      }

      .text-orange {
        color: var(--color-orange);
      }

      .text-red {
        color: tomato;
      }
      "
    `)
  })

  test('`default` theme values can be overridden by config theme values', async () => {
    expect(
      await run(
        ['text-red', 'text-orange'],
        css`
          @theme default {
            --color-red: red;
          }
          @theme {
            --color-orange: orange;
          }
          @config "./my-config.js";
          @tailwind utilities;
        `,
        {
          loadModule: async () => {
            return {
              path: '',
              base: '/root',
              module: {
                theme: {
                  extend: {
                    colors: {
                      red: 'tomato',
                      orange: '#f28500',
                    },
                  },
                },
              },
            }
          },
        },
      ),
    ).toMatchInlineSnapshot(`
      "
      :root, :host {
        --color-orange: orange;
      }

      .text-orange {
        color: var(--color-orange);
      }

      .text-red {
        color: tomato;
      }
      "
    `)
  })

  test('only emits theme variables that are used outside of being defined by another variable', async () => {
    expect(
      await run(
        ['get-var-b', 'get-var-two'],
        css`
          @theme {
            --var-a: var(--var-b);
            --var-b: var(--var-c);
            --var-c: var(--var-d);
            --var-d: red;

            --var-four: green;
            --var-three: var(--var-four);
            --var-two: var(--var-three);
            --var-one: var(--var-two);

            --var-eins: var(--var-zwei);
            --var-zwei: var(--var-drei);
            --var-drei: var(--var-vier);
            --var-vier: blue;
          }

          @utility get-var-* {
            color: --value(--var-\*);
          }
          @tailwind utilities;
        `,
      ),
    ).toMatchInlineSnapshot(`
      "
      :root, :host {
        --var-b: var(--var-c);
        --var-c: var(--var-d);
        --var-d: red;
        --var-four: green;
        --var-three: var(--var-four);
        --var-two: var(--var-three);
      }

      .get-var-b {
        color: var(--var-b);
      }

      .get-var-two {
        color: var(--var-two);
      }
      "
    `)
  })
})

describe('plugins', () => {
  test('@plugin need a path', () => {
    return expect(
      compile(
        css`
          @plugin;
        `,
        {
          loadModule: async () => ({
            path: '',
            base: '/root',
            module: ({ addVariant }: PluginAPI) => {
              addVariant('hocus', '&:hover, &:focus')
            },
          }),
        },
      ),
    ).rejects.toThrowErrorMatchingInlineSnapshot(`[Error: \`@plugin\` must have a path.]`)
  })

  test('@plugin cannot have an empty path', () => {
    return expect(
      compile(
        css`
          @plugin '';
        `,
        {
          loadModule: async () => ({
            path: '',
            base: '/root',
            module: ({ addVariant }: PluginAPI) => {
              addVariant('hocus', '&:hover, &:focus')
            },
          }),
        },
      ),
    ).rejects.toThrowErrorMatchingInlineSnapshot(`[Error: \`@plugin\` must have a path.]`)
  })

  test('@plugin cannot be nested.', () => {
    return expect(
      compile(
        css`
          div {
            @plugin "my-plugin";
          }
        `,
        {
          loadModule: async () => ({
            path: '',
            base: '/root',
            module: ({ addVariant }: PluginAPI) => {
              addVariant('hocus', '&:hover, &:focus')
            },
          }),
        },
      ),
    ).rejects.toThrowErrorMatchingInlineSnapshot(`[Error: \`@plugin\` cannot be nested.]`)
  })

  test('@plugin can accept options', async () => {
    expect.hasAssertions()

    expect(
      await run(
        ['text-primary'],
        css`
          @tailwind utilities;
          @plugin "my-plugin" {
            color: red;
          }
        `,
        {
          loadModule: async () => ({
            path: '',
            base: '/root',
            module: plugin.withOptions((options) => {
              expect(options).toEqual({
                color: 'red',
              })

              return ({ addUtilities }) => {
                addUtilities({
                  '.text-primary': {
                    color: options.color,
                  },
                })
              }
            }),
          }),
        },
      ),
    ).toMatchInlineSnapshot(`
      "
      .text-primary {
        color: red;
      }
      "
    `)
  })

  test('@plugin options can be null, booleans, string, numbers, or arrays including those types', async () => {
    expect.hasAssertions()

    await compile(
      css`
        @tailwind utilities;
        @plugin "my-plugin" {
          is-null: null;
          is-true: true;
          is-false: false;
          is-int: 1234567;
          is-float: 1.35;
          is-sci: 1.35e-5;
          is-str-null: 'null';
          is-str-true: 'true';
          is-str-false: 'false';
          is-str-int: '1234567';
          is-str-float: '1.35';
          is-str-sci: '1.35e-5';
          is-arr: foo, bar;
          is-arr-mixed: null, true, false, 1234567, 1.35, foo, 'bar', 'true';
        }
      `,
      {
        loadModule: async () => ({
          path: '',
          base: '/root',
          module: plugin.withOptions((options) => {
            expect(options).toEqual({
              'is-null': null,
              'is-true': true,
              'is-false': false,
              'is-int': 1234567,
              'is-float': 1.35,
              'is-sci': 1.35e-5,
              'is-str-null': 'null',
              'is-str-true': 'true',
              'is-str-false': 'false',
              'is-str-int': '1234567',
              'is-str-float': '1.35',
              'is-str-sci': '1.35e-5',
              'is-arr': ['foo', 'bar'],
              'is-arr-mixed': [null, true, false, 1234567, 1.35, 'foo', 'bar', 'true'],
            })

            return () => {}
          }),
        }),
      },
    )
  })

  test('@plugin options can only be simple key/value pairs', () => {
    return expect(
      compile(
        css`
          @plugin "my-plugin" {
            color: red;
            sizes {
              sm: 1rem;
              md: 2rem;
            }
          }
        `,
        {
          loadModule: async () => ({
            path: '',
            base: '/root',
            module: plugin.withOptions((options) => {
              return ({ addUtilities }) => {
                addUtilities({
                  '.text-primary': {
                    color: options.color,
                  },
                })
              }
            }),
          }),
        },
      ),
    ).rejects.toThrowErrorMatchingInlineSnapshot(
      `
      [Error: Unexpected \`@plugin\` option:

      sizes {
        sm: 1rem;
        md: 2rem;
      }


      \`@plugin\` options must be a flat list of declarations.]
    `,
    )
  })

  test('@plugin options can only be provided to plugins using withOptions', () => {
    return expect(
      compile(
        css`
          @plugin "my-plugin" {
            color: red;
          }
        `,
        {
          loadModule: async () => ({
            path: '',
            base: '/root',
            module: plugin(({ addUtilities }) => {
              addUtilities({
                '.text-primary': {
                  color: 'red',
                },
              })
            }),
          }),
        },
      ),
    ).rejects.toThrowErrorMatchingInlineSnapshot(
      `[Error: The plugin "my-plugin" does not accept options]`,
    )
  })

  test('@plugin errors on array-like syntax', () => {
    return expect(
      compile(
        css`
          @plugin "my-plugin" {
            --color: [ 'red', 'green', 'blue'];
          }
        `,
        {
          loadModule: async () => ({
            path: '',
            base: '/root',
            module: plugin(() => {}),
          }),
        },
      ),
    ).rejects.toThrowErrorMatchingInlineSnapshot(
      `[Error: The plugin "my-plugin" does not accept options]`,
    )
  })

  test('@plugin errors on object-like syntax', () => {
    return expect(
      compile(
        css`
          @plugin "my-plugin" {
            --color: {
              red: 100;
              green: 200;
              blue: 300;
            };
          }
        `,
        {
          loadModule: async () => ({
            path: '',
            base: '/root',
            module: plugin(() => {}),
          }),
        },
      ),
    ).rejects.toThrowErrorMatchingInlineSnapshot(`
      [Error: Unexpected \`@plugin\` option: Value of declaration \`--color: {
                    red: 100;
                    green: 200;
                    blue: 300;
                  };\` is not supported.

      Using an object as a plugin option is currently only supported in JavaScript configuration files.]
    `)
  })

  test('addVariant with string selector', async () => {
    expect(
      await run(
        ['hocus:underline', 'group-hocus:flex'],
        css`
          @plugin "my-plugin";
          @layer utilities {
            @tailwind utilities;
          }
        `,
        {
          loadModule: async () => ({
            path: '',
            base: '/root',
            module: ({ addVariant }: PluginAPI) => {
              addVariant('hocus', '&:hover, &:focus')
            },
          }),
        },
      ),
    ).toMatchInlineSnapshot(`
      "
      @layer utilities {
        :is(:is(:where(.group):hover, :where(.group):focus) .group-hocus\\:flex) {
          display: flex;
        }

        .hocus\\:underline:hover, .hocus\\:underline:focus {
          text-decoration-line: underline;
        }
      }
      "
    `)
  })

  test('addVariant with array of selectors', async () => {
    expect(
      await run(
        ['hocus:underline', 'group-hocus:flex'],
        css`
          @plugin "my-plugin";
          @layer utilities {
            @tailwind utilities;
          }
        `,
        {
          loadModule: async () => ({
            path: '',
            base: '/root',
            module: ({ addVariant }: PluginAPI) => {
              addVariant('hocus', ['&:hover', '&:focus'])
            },
          }),
        },
      ),
    ).toMatchInlineSnapshot(`
      "
      @layer utilities {
        :is(:where(.group):hover .group-hocus\\:flex), :is(:where(.group):focus .group-hocus\\:flex) {
          display: flex;
        }

        .hocus\\:underline:hover, .hocus\\:underline:focus {
          text-decoration-line: underline;
        }
      }
      "
    `)
  })

  test('addVariant with object syntax and @slot', async () => {
    expect(
      await run(
        ['hocus:underline', 'group-hocus:flex'],
        css`
          @plugin "my-plugin";
          @layer utilities {
            @tailwind utilities;
          }
        `,
        {
          loadModule: async () => ({
            path: '',
            base: '/root',
            module: ({ addVariant }: PluginAPI) => {
              addVariant('hocus', {
                '&:hover': '@slot',
                '&:focus': '@slot',
              })
            },
          }),
        },
      ),
    ).toMatchInlineSnapshot(`
      "
      @layer utilities {
        :is(:where(.group):hover .group-hocus\\:flex), :is(:where(.group):focus .group-hocus\\:flex) {
          display: flex;
        }

        .hocus\\:underline:hover, .hocus\\:underline:focus {
          text-decoration-line: underline;
        }
      }
      "
    `)
  })

  test('addVariant with object syntax, media, nesting and multiple @slot', async () => {
    expect(
      await run(
        ['hocus:underline', 'group-hocus:flex'],
        css`
          @plugin "my-plugin";
          @layer utilities {
            @tailwind utilities;
          }
        `,
        {
          loadModule: async () => ({
            path: '',
            base: '/root',
            module: ({ addVariant }: PluginAPI) => {
              addVariant('hocus', {
                '@media (hover: hover)': {
                  '&:hover': '@slot',
                },
                '&:focus': '@slot',
              })
            },
          }),
        },
      ),
    ).toMatchInlineSnapshot(`
      "
      @layer utilities {
        @media (hover: hover) {
          :is(:where(.group):hover .group-hocus\\:flex) {
            display: flex;
          }
        }

        :is(:where(.group):focus .group-hocus\\:flex) {
          display: flex;
        }

        @media (hover: hover) {
          .hocus\\:underline:hover {
            text-decoration-line: underline;
          }
        }

        .hocus\\:underline:focus {
          text-decoration-line: underline;
        }
      }
      "
    `)
  })

  test('@slot is preserved when used as a custom property value', async () => {
    expect(
      await run(
        ['hocus:underline'],
        css`
          @plugin "my-plugin";
          @layer utilities {
            @tailwind utilities;
          }
        `,
        {
          loadModule: async () => ({
            path: '',
            base: '/root',
            module: ({ addVariant }: PluginAPI) => {
              addVariant('hocus', {
                '&': {
                  '--custom-property': '@slot',
                  '&:hover': '@slot',
                  '&:focus': '@slot',
                },
              })
            },
          }),
        },
      ),
    ).toMatchInlineSnapshot(`
      "
      @layer utilities {
        .hocus\\:underline {
          --custom-property: @slot;
        }

        .hocus\\:underline:hover, .hocus\\:underline:focus {
          text-decoration-line: underline;
        }
      }
      "
    `)
  })

  test('built-in variants can be overridden while keeping their order', async () => {
    expect(
      await run(
        // Make sure the order does not change by including the variants
        // immediately before and after `dark`
        ['rtl:flex', 'dark:flex', 'starting:flex'],
        css`
          @plugin "my-plugin";
          @layer utilities {
            @tailwind utilities;
          }
        `,
        {
          loadModule: async () => ({
            path: '',
            base: '/root',
            module: ({ addVariant }: PluginAPI) => {
              addVariant('dark', '&:is([data-theme=dark] *)')
            },
          }),
        },
      ),
    ).toMatchInlineSnapshot(`
      "
      @layer utilities {
        .rtl\\:flex:where(:dir(rtl), [dir="rtl"], [dir="rtl"] *), .dark\\:flex:is([data-theme="dark"] *) {
          display: flex;
        }

        @starting-style {
          .starting\\:flex {
            display: flex;
          }
        }
      }
      "
    `)
  })
})

describe('@source', () => {
  test('emits @source files', async () => {
    let { sources } = await compile(
      css`
        @source "./foo/bar/*.ts";
      `,
      { base: '/root' },
    )

    expect(sources).toEqual([{ pattern: './foo/bar/*.ts', base: '/root', negated: false }])
  })

  test('emits multiple @source files', async () => {
    let { sources } = await compile(
      css`
        @source "./foo/**/*.ts";
        @source "./php/secr3t/smarty.php";
      `,
      { base: '/root' },
    )

    expect(sources).toEqual([
      { pattern: './foo/**/*.ts', base: '/root', negated: false },
      { pattern: './php/secr3t/smarty.php', base: '/root', negated: false },
    ])
  })

  test('emits negated @source files', async () => {
    let { sources } = await compile(
      css`
        @source not "./foo/**/*.ts";
        @source not "./php/secr3t/smarty.php";
      `,
      { base: '/root' },
    )

    expect(sources).toEqual([
      { pattern: './foo/**/*.ts', base: '/root', negated: true },
      { pattern: './php/secr3t/smarty.php', base: '/root', negated: true },
    ])
  })

  describe('@source inline(…)', () => {
    test('always includes the candidate', async () => {
      expect(
        await compileCss(css`
          @source inline("underline");
          @tailwind utilities;
        `),
      ).toMatchInlineSnapshot(`
        "
        .underline {
          text-decoration-line: underline;
        }
        "
      `)
    })

    test('applies brace expansion', async () => {
      expect(
        await compileCss(css`
          @theme {
            --color-red-50: oklch(0.971 0.013 17.38);
            --color-red-100: oklch(0.936 0.032 17.717);
            --color-red-200: oklch(0.885 0.062 18.334);
            --color-red-300: oklch(0.808 0.114 19.571);
            --color-red-400: oklch(0.704 0.191 22.216);
            --color-red-500: oklch(0.637 0.237 25.331);
            --color-red-600: oklch(0.577 0.245 27.325);
            --color-red-700: oklch(0.505 0.213 27.518);
            --color-red-800: oklch(0.444 0.177 26.899);
            --color-red-900: oklch(0.396 0.141 25.723);
            --color-red-950: oklch(0.258 0.092 26.042);
          }
          @source inline("bg-red-{50,{100..900..100},950}");
          @tailwind utilities;
        `),
      ).toMatchInlineSnapshot(`
        "
        :root, :host {
          --color-red-50: oklch(97.1% .013 17.38);
          --color-red-100: oklch(93.6% .032 17.717);
          --color-red-200: oklch(88.5% .062 18.334);
          --color-red-300: oklch(80.8% .114 19.571);
          --color-red-400: oklch(70.4% .191 22.216);
          --color-red-500: oklch(63.7% .237 25.331);
          --color-red-600: oklch(57.7% .245 27.325);
          --color-red-700: oklch(50.5% .213 27.518);
          --color-red-800: oklch(44.4% .177 26.899);
          --color-red-900: oklch(39.6% .141 25.723);
          --color-red-950: oklch(25.8% .092 26.042);
        }

        .bg-red-50 {
          background-color: var(--color-red-50);
        }

        .bg-red-100 {
          background-color: var(--color-red-100);
        }

        .bg-red-200 {
          background-color: var(--color-red-200);
        }

        .bg-red-300 {
          background-color: var(--color-red-300);
        }

        .bg-red-400 {
          background-color: var(--color-red-400);
        }

        .bg-red-500 {
          background-color: var(--color-red-500);
        }

        .bg-red-600 {
          background-color: var(--color-red-600);
        }

        .bg-red-700 {
          background-color: var(--color-red-700);
        }

        .bg-red-800 {
          background-color: var(--color-red-800);
        }

        .bg-red-900 {
          background-color: var(--color-red-900);
        }

        .bg-red-950 {
          background-color: var(--color-red-950);
        }
        "
      `)
    })

    test('adds multiple inline sources separated by spaces', async () => {
      expect(
        await compileCss(css`
          @theme {
            --color-red-100: oklch(0.936 0.032 17.717);
            --color-red-200: oklch(0.885 0.062 18.334);
          }
          @source inline("block bg-red-{100..200..100}");
          @tailwind utilities;
        `),
      ).toMatchInlineSnapshot(`
        "
        :root, :host {
          --color-red-100: oklch(93.6% .032 17.717);
          --color-red-200: oklch(88.5% .062 18.334);
        }

        .block {
          display: block;
        }

        .bg-red-100 {
          background-color: var(--color-red-100);
        }

        .bg-red-200 {
          background-color: var(--color-red-200);
        }
        "
      `)
    })

    test('ignores invalid inline candidates', async () => {
      expect(
        await compileCss(css`
          @source inline("my-cucumber");
          @tailwind utilities;
        `),
      ).toEqual('')
    })

    test('can be negated', async () => {
      expect(
        await run(
          ['container'],
          css`
            @theme {
              --breakpoint-sm: 40rem;
              --breakpoint-md: 48rem;
              --breakpoint-lg: 64rem;
              --breakpoint-xl: 80rem;
              --breakpoint-2xl: 96rem;
            }
            @source not inline("container");
            @tailwind utilities;
          `,
        ),
      ).toEqual('')
    })

    test('applies brace expansion to negated sources', async () => {
      expect(
        await run(
          ['bg-red-500', 'bg-red-700'],
          css`
            @theme {
              --color-red-50: oklch(0.971 0.013 17.38);
              --color-red-100: oklch(0.936 0.032 17.717);
              --color-red-200: oklch(0.885 0.062 18.334);
              --color-red-300: oklch(0.808 0.114 19.571);
              --color-red-400: oklch(0.704 0.191 22.216);
              --color-red-500: oklch(0.637 0.237 25.331);
              --color-red-600: oklch(0.577 0.245 27.325);
              --color-red-700: oklch(0.505 0.213 27.518);
              --color-red-800: oklch(0.444 0.177 26.899);
              --color-red-900: oklch(0.396 0.141 25.723);
              --color-red-950: oklch(0.258 0.092 26.042);
            }
            @source not inline("bg-red-{50,{100..900..100},950}");
            @tailwind utilities;
          `,
        ),
      ).toEqual('')
    })

    test('works with whitespace around the argument', async () => {
      expect(
        await compileCss(css`
          /* prettier-ignore */
          @source inline( "underline" );
          @tailwind utilities;
        `),
      ).toMatchInlineSnapshot(`
        "
        .underline {
          text-decoration-line: underline;
        }
        "
      `)
    })

    test('works with newlines around the argument', async () => {
      expect(
        await compileCss(css`
          /* prettier-ignore */
          @source inline(
            "underline"
          );
          @tailwind utilities;
        `),
      ).toMatchInlineSnapshot(`
        "
        .underline {
          text-decoration-line: underline;
        }
        "
      `)
    })
  })
})

describe('@custom-variant', () => {
  test('@custom-variant must be top-level and cannot be nested', () => {
    return expect(
      compileCss(css`
        @custom-variant foo:bar (&:hover, &:focus);
      `),
    ).rejects.toThrowErrorMatchingInlineSnapshot(
      `[Error: \`@custom-variant foo:bar\` defines an invalid variant name. Variants should only contain alphanumeric, dashes, or underscore characters and start with a lowercase letter or number.]`,
    )
  })

  test.each([
    // Cannot be a dash on its own
    [`@custom-variant - (&);`],
    // Cannot be multiple dashes on their own
    [`@custom-variant --- (&);`],
    // Cannot be an underscore on its own
    [`@custom-variant _ (&);`],
    // Cannot be multiple underscores on their own
    [`@custom-variant ___ (&);`],

    // Cannot start with a dash
    [`@custom-variant -foo (&);`],
    [`@custom-variant --foo (&);`],
    // Cannot start with an underscore
    [`@custom-variant _foo (&);`],
    [`@custom-variant __foo (&);`],

    // Cannot end with a dash
    [`@custom-variant foo- (&);`],
    [`@custom-variant foo-- (&);`],
    // Cannot end with an underscore
    [`@custom-variant foo_ (&);`],
    [`@custom-variant foo__ (&);`],
  ])('@custom-variant must have a valid name', (input) => {
    return expect(compileCss(input)).rejects.toThrow()
  })

  test('@custom-variant must not contain special characters', () => {
    return expect(
      compileCss(css`
        .foo {
          @custom-variant foo:bar (&:hover, &:focus);
        }
      `),
    ).rejects.toThrowErrorMatchingInlineSnapshot(`[Error: \`@custom-variant\` cannot be nested.]`)
  })

  test('@custom-variant must not have an empty selector', () => {
    return expect(
      compileCss(css`
        @custom-variant foo ();
      `),
    ).rejects.toThrowErrorMatchingInlineSnapshot(
      `[Error: \`@custom-variant foo ()\` selector is invalid.]`,
    )
  })

  test('@custom-variant with multiple selectors, cannot be empty', () => {
    return expect(
      compileCss(css`
        @custom-variant foo (.foo, .bar, );
      `),
    ).rejects.toThrowErrorMatchingInlineSnapshot(
      `[Error: \`@custom-variant foo (.foo, .bar, )\` selector is invalid.]`,
    )
  })

  test('@custom-variant with no body must include a selector', () => {
    return expect(
      compileCss(css`
        @custom-variant hocus;
      `),
    ).rejects.toThrowErrorMatchingInlineSnapshot(
      '[Error: `@custom-variant hocus` has no selector or body.]',
    )
  })

  test('@custom-variant with selector must include a body', () => {
    return expect(
      compileCss(css`
        @custom-variant hocus {
        }
      `),
    ).rejects.toThrowErrorMatchingInlineSnapshot(
      '[Error: `@custom-variant hocus` has no selector or body.]',
    )
  })

  test('@custom-variant cannot have both a selector and a body', () => {
    return expect(
      compileCss(css`
        @custom-variant hocus (&:hover, &:focus) {
          &:is(.potato) {
            @slot;
          }
        }
      `),
    ).rejects.toThrowErrorMatchingInlineSnapshot(
      `[Error: \`@custom-variant hocus\` cannot have both a selector and a body.]`,
    )
  })

  describe('body-less syntax', () => {
    test('selector variant', async () => {
      expect(
        await run(
          ['hocus:underline', 'group-hocus:flex'],
          css`
            @custom-variant hocus (&:hover, &:focus);

            @layer utilities {
              @tailwind utilities;
            }
          `,
        ),
      ).toMatchInlineSnapshot(`
        "
        @layer utilities {
          :is(:is(:where(.group):hover, :where(.group):focus) .group-hocus\\:flex) {
            display: flex;
          }

          .hocus\\:underline:hover, .hocus\\:underline:focus {
            text-decoration-line: underline;
          }
        }
        "
      `)
    })

    test('at-rule variant', async () => {
      expect(
        await run(
          ['any-hover:hover:underline'],
          css`
            @custom-variant any-hover (@media (any-hover: hover));

            @layer utilities {
              @tailwind utilities;
            }
          `,
        ),
      ).toMatchInlineSnapshot(`
        "
        @layer utilities {
          @media (any-hover: hover) {
            @media (hover: hover) {
              .any-hover\\:hover\\:underline:hover {
                text-decoration-line: underline;
              }
            }
          }
        }
        "
      `)
    })

    test('style-rules and at-rules', async () => {
      expect(
        await run(
          ['cant-hover:focus:underline'],
          css`
            @custom-variant cant-hover (&:not(:hover), &:not(:active), @media not (any-hover: hover), @media not (pointer: fine));

            @layer utilities {
              @tailwind utilities;
            }
          `,
        ),
      ).toMatchInlineSnapshot(`
        "
        @layer utilities {
          :is(.cant-hover\\:focus\\:underline:not(:hover), .cant-hover\\:focus\\:underline:not(:active)):focus {
            text-decoration-line: underline;
          }

          @media not all and (any-hover: hover) {
            .cant-hover\\:focus\\:underline:focus {
              text-decoration-line: underline;
            }
          }

          @media not all and (pointer: fine) {
            .cant-hover\\:focus\\:underline:focus {
              text-decoration-line: underline;
            }
          }
        }
        "
      `)
    })
  })

  describe('body with @slot syntax', () => {
    test('selector with @slot', async () => {
      expect(
        await run(
          ['selected:underline', 'group-selected:underline'],
          css`
            @custom-variant selected {
              &[data-selected] {
                @slot;
              }
            }

            @layer utilities {
              @tailwind utilities;
            }
          `,
        ),
      ).toMatchInlineSnapshot(`
        "
        @layer utilities {
          :is(:where(.group)[data-selected] .group-selected\\:underline), .selected\\:underline[data-selected] {
            text-decoration-line: underline;
          }
        }
        "
      `)
    })

    test('grouped selectors with @slot', async () => {
      expect(
        await run(
          ['hocus:underline', 'group-hocus:underline'],
          css`
            @custom-variant hocus {
              &:hover,
              &:focus {
                @slot;
              }
            }

            @layer utilities {
              @tailwind utilities;
            }
          `,
        ),
      ).toMatchInlineSnapshot(`
        "
        @layer utilities {
          :is(:is(:where(.group):hover, :where(.group):focus) .group-hocus\\:underline), .hocus\\:underline:hover, .hocus\\:underline:focus {
            text-decoration-line: underline;
          }
        }
        "
      `)
    })

    test('multiple selectors with @slot', async () => {
      expect(
        await run(
          ['hocus:underline', 'group-hocus:underline'],
          css`
            @custom-variant hocus {
              &:hover {
                @slot;
              }

              &:focus {
                @slot;
              }
            }

            @layer utilities {
              @tailwind utilities;
            }
          `,
        ),
      ).toMatchInlineSnapshot(`
        "
        @layer utilities {
          :is(:where(.group):hover .group-hocus\\:underline), :is(:where(.group):focus .group-hocus\\:underline), .hocus\\:underline:hover, .hocus\\:underline:focus {
            text-decoration-line: underline;
          }
        }
        "
      `)
    })

    test('nested selector with @slot', async () => {
      expect(
        await run(
          ['custom-before:underline'],
          css`
            @custom-variant custom-before {
              & {
                --has-before: 1;
                &::before {
                  @slot;
                }
              }
            }

            @layer utilities {
              @tailwind utilities;
            }
          `,
        ),
      ).toMatchInlineSnapshot(`
        "
        @layer utilities {
          .custom-before\\:underline {
            --has-before: 1;
          }

          .custom-before\\:underline:before {
            text-decoration-line: underline;
          }
        }
        "
      `)
    })

    test('grouped nested selectors with @slot', async () => {
      expect(
        await run(
          ['custom-before:underline'],
          css`
            @custom-variant custom-before {
              & {
                --has-before: 1;
                &::before {
                  &:hover,
                  &:focus {
                    @slot;
                  }
                }
              }
            }

            @layer utilities {
              @tailwind utilities;
            }
          `,
        ),
      ).toMatchInlineSnapshot(`
        "
        @layer utilities {
          .custom-before\\:underline {
            --has-before: 1;
          }

          .custom-before\\:underline:before:hover, .custom-before\\:underline:before:focus {
            text-decoration-line: underline;
          }
        }
        "
      `)
    })

    test('nested multiple selectors with @slot', async () => {
      expect(
        await run(
          ['hocus:underline', 'group-hocus:underline'],
          css`
            @custom-variant hocus {
              &:hover {
                @media (hover: hover) {
                  @slot;
                }
              }

              &:focus {
                @slot;
              }
            }

            @layer utilities {
              @tailwind utilities;
            }
          `,
        ),
      ).toMatchInlineSnapshot(`
        "
        @layer utilities {
          @media (hover: hover) {
            :is(:where(.group):hover .group-hocus\\:underline) {
              text-decoration-line: underline;
            }
          }

          :is(:where(.group):focus .group-hocus\\:underline) {
            text-decoration-line: underline;
          }

          @media (hover: hover) {
            .hocus\\:underline:hover {
              text-decoration-line: underline;
            }
          }

          .hocus\\:underline:focus {
            text-decoration-line: underline;
          }
        }
        "
      `)
    })

    test('selector nested under at-rule with @slot', async () => {
      expect(
        await run(
          ['hocus:underline', 'group-hocus:underline'],
          css`
            @custom-variant hocus {
              @media (hover: hover) {
                &:hover {
                  @slot;
                }
              }
            }

            @layer utilities {
              @tailwind utilities;
            }
          `,
        ),
      ).toMatchInlineSnapshot(`
        "
        @layer utilities {
          @media (hover: hover) {
            :is(:where(.group):hover .group-hocus\\:underline), .hocus\\:underline:hover {
              text-decoration-line: underline;
            }
          }
        }
        "
      `)
    })

    test('at-rule with @slot', async () => {
      expect(
        await run(
          ['any-hover:underline'],
          css`
            @custom-variant any-hover {
              @media (any-hover: hover) {
                @slot;
              }
            }

            @layer utilities {
              @tailwind utilities;
            }
          `,
        ),
      ).toMatchInlineSnapshot(`
        "
        @layer utilities {
          @media (any-hover: hover) {
            .any-hover\\:underline {
              text-decoration-line: underline;
            }
          }
        }
        "
      `)
    })

    test('multiple at-rules with @slot', async () => {
      expect(
        await run(
          ['desktop:underline'],
          css`
            @custom-variant desktop {
              @media (any-hover: hover) {
                @slot;
              }

              @media (pointer: fine) {
                @slot;
              }
            }

            @layer utilities {
              @tailwind utilities;
            }
          `,
        ),
      ).toMatchInlineSnapshot(`
        "
        @layer utilities {
          @media (any-hover: hover) {
            .desktop\\:underline {
              text-decoration-line: underline;
            }
          }

          @media (pointer: fine) {
            .desktop\\:underline {
              text-decoration-line: underline;
            }
          }
        }
        "
      `)
    })

    test('nested at-rules with @slot', async () => {
      expect(
        await run(
          ['custom-variant:underline'],
          css`
            @custom-variant custom-variant {
              @media (orientation: landscape) {
                @media screen {
                  @slot;
                }

                @media print {
                  display: none;
                }
              }
            }

            @layer utilities {
              @tailwind utilities;
            }
          `,
        ),
      ).toMatchInlineSnapshot(`
        "
        @layer utilities {
          @media (orientation: landscape) {
            @media screen {
              .custom-variant\\:underline {
                text-decoration-line: underline;
              }
            }

            @media print {
              .custom-variant\\:underline {
                display: none;
              }
            }
          }
        }
        "
      `)
    })

    test('at-rule and selector with @slot', async () => {
      expect(
        await run(
          ['custom-dark:underline'],
          css`
            @custom-variant custom-dark {
              @media (prefers-color-scheme: dark) {
                @slot;
              }
              &:is(.dark *) {
                @slot;
              }
            }

            @layer utilities {
              @tailwind utilities;
            }
          `,
        ),
      ).toMatchInlineSnapshot(`
        "
        @layer utilities {
          @media (prefers-color-scheme: dark) {
            .custom-dark\\:underline {
              text-decoration-line: underline;
            }
          }

          .custom-dark\\:underline:is(.dark *) {
            text-decoration-line: underline;
          }
        }
        "
      `)
    })
  })

  describe('@scope', () => {
    test('arbitrary variant', async () => {
      expect(await run(['[@scope_(.from)_to_(.to)]:underline'])).toMatchInlineSnapshot(`
        "
        @scope (.from) to (.to) {
          .\\[\\@scope_\\(\\.from\\)_to_\\(\\.to\\)\\]\\:underline {
            text-decoration-line: underline;
          }
        }
        "
      `)
    })

    test('shorthand syntax', async () => {
      expect(
        await run(
          ['scoped:underline'],
          css`
            @custom-variant scoped (@scope (.from) to (.to));

            @layer utilities {
              @tailwind utilities;
            }
          `,
        ),
      ).toMatchInlineSnapshot(`
        "
        @layer utilities {
          @scope (.from) to (.to) {
            .scoped\\:underline {
              text-decoration-line: underline;
            }
          }
        }
        "
      `)
    })

    test('with @slot syntax', async () => {
      expect(
        await run(
          ['scoped:underline'],
          css`
            @custom-variant scoped {
              @scope (.from) to (.to) {
                @slot;
              }
            }

            @layer utilities {
              @tailwind utilities;
            }
          `,
        ),
      ).toMatchInlineSnapshot(`
        "
        @layer utilities {
          @scope (.from) to (.to) {
            .scoped\\:underline {
              text-decoration-line: underline;
            }
          }
        }
        "
      `)
    })

    test('@scope in a custom variant combined with user-authored `@scope` rules', async () => {
      expect(
        await run(
          ['blue:bg-blue-500'],
          css`
            @layer utilities {
              @tailwind utilities;
            }

            @theme inline {
              --color-blue-500: blue;
            }

            /* In a variant */
            @custom-variant blue {
              @scope ([data-theme='blue']) to ([data-theme]) {
                @slot;
              }
            }

            /* User CSS */
            .parent {
              /* @scope with bare declarations */
              @scope (.from) to (.to) {
                --x: 1;
              }

              .child {
                .a {
                  /* Variant with @scope used by @apply */
                  @apply blue:[--x:2];
                }
                .b {
                  /* Variant with @scope used by @apply combined with another variant */
                  @apply blue:hover:[--x:3];
                }
                .c {
                  /* Variant with @scoped used by @variant */
                  @variant blue {
                    --x: 4;
                  }
                }
              }
            }
          `,
        ),
      ).toMatchInlineSnapshot(`
        "
        @layer utilities {
          @scope ([data-theme="blue"]) to ([data-theme]) {
            .blue\\:bg-blue-500 {
              background-color: #00f;
            }
          }
        }

        @scope (.parent .from) to (.to) {
          :where(:scope) {
            --x: 1;
          }
        }

        @scope ([data-theme="blue"]) to ([data-theme]) {
          .parent .child .a {
            --x: 2;
          }

          @media (hover: hover) {
            .parent .child .b:hover {
              --x: 3;
            }
          }

          .parent .child .c {
            --x: 4;
          }
        }
        "
      `)
    })

    test('`&` in the `@scope` prelude of a custom variant controls the composition', async () => {
      expect(
        await run(
          ['in-blue:flex', 'blue-self:flex', 'scoped-panel:flex', 'in-blue:hover:flex'],
          css`
            /* Default: the utility applies to elements inside the scope */
            @custom-variant in-blue {
              @scope ([data-theme='blue']) to ([data-theme]) {
                @slot;
              }
            }

            /* Trailing &: the utility itself becomes the scoping root */
            @custom-variant blue-self {
              @scope ([data-theme='blue'] &) to ([data-theme]) {
                @slot;
              }
            }

            /* Leading &: the scoping roots are found inside the utility */
            @custom-variant scoped-panel {
              @scope (& .panel) {
                @slot;
              }
            }

            @layer utilities {
              @tailwind utilities;
            }
          `,
        ),
      ).toMatchInlineSnapshot(`
        "
        @layer utilities {
          @scope ([data-theme="blue"]) to ([data-theme]) {
            .in-blue\\:flex {
              display: flex;
            }

            @media (hover: hover) {
              .in-blue\\:hover\\:flex:hover {
                display: flex;
              }
            }
          }

          @scope ([data-theme="blue"] .blue-self\\:flex) to ([data-theme]) {
            :where(:scope) {
              display: flex;
            }
          }

          @scope (.scoped-panel\\:flex .panel) {
            :where(:scope) {
              display: flex;
            }
          }
        }
        "
      `)
    })

    test('user-authored `@scope` inside `@variant` keeps its native semantics', async () => {
      // The `hocus` variant does not use `@scope` itself, so the inner `@scope`
      // is user CSS and compiles with the native CSS nesting semantics: the
      // parent selector moves into the prelude, and bare declarations apply to
      // the scoping root.
      expect(
        await compileCss(css`
          @custom-variant hocus (&:hover, &:focus);

          .btn {
            @variant hocus {
              @scope (.from) to (.to) {
                --x: 1;
              }
            }
          }
        `),
      ).toMatchInlineSnapshot(`
        "
        @scope (:is(.btn:hover, .btn:focus) .from) to (.to) {
          :where(:scope) {
            --x: 1;
          }
        }
        "
      `)
    })

    test('user-authored `@scope` inside a `@variant` that uses `@scope` keeps its native semantics', async () => {
      // The `blue` variant uses `@scope` itself, so its own `@scope` takes the
      // variant composition. But the user CSS slotted into its body is marked
      // as `user` content, so the inner `@scope` keeps its native CSS nesting
      // semantics: the parent selector moves into the prelude, and bare
      // declarations apply to the scoping root.
      expect(
        await compileCss(css`
          @custom-variant blue {
            @scope ([data-theme='blue']) to ([data-theme]) {
              @slot;
            }
          }

          .btn {
            @variant blue {
              @scope (.from) to (.to) {
                --x: 1;
              }
            }
          }
        `),
      ).toMatchInlineSnapshot(`
        "
        @scope ([data-theme="blue"]) to ([data-theme]) {
          @scope (.btn .from) to (.to) {
            :where(:scope) {
              --x: 1;
            }
          }
        }
        "
      `)
    })

    test('@scope nested in a rule, nested in another @scope, with @slot', async () => {
      // Both `@scope` rules take the variant composition: neither prelude is
      // made relative to a parent, the outer/inner nesting order is preserved,
      // and the rule between them composes into the body with the utility's
      // selector.
      expect(
        await run(
          ['foo:underline'],
          css`
            @custom-variant foo {
              @scope (.outer) to (.outer-limit) {
                .middle {
                  @scope (.inner) to (.inner-limit) {
                    @slot;
                  }
                }
              }
            }

            @layer utilities {
              @tailwind utilities;
            }
          `,
        ),
      ).toMatchInlineSnapshot(`
        "
        @layer utilities {
          @scope (.outer) to (.outer-limit) {
            @scope (.inner) to (.inner-limit) {
              .foo\\:underline .middle {
                text-decoration-line: underline;
              }
            }
          }
        }
        "
      `)
    })
  })

  test('built-in variants can be overridden while keeping their order', async () => {
    expect(
      await run(
        // Make sure the order does not change by including the variants
        // immediately before and after `dark`
        ['rtl:flex', 'dark:flex', 'starting:flex'],
        css`
          @custom-variant dark (&:is([data-theme='dark'] *));
          @layer utilities {
            @tailwind utilities;
          }
        `,
      ),
    ).toMatchInlineSnapshot(`
      "
      @layer utilities {
        .rtl\\:flex:where(:dir(rtl), [dir="rtl"], [dir="rtl"] *), .dark\\:flex:is([data-theme="dark"] *) {
          display: flex;
        }

        @starting-style {
          .starting\\:flex {
            display: flex;
          }
        }
      }
      "
    `)
  })

  test('at-rule-only variants cannot be used with compound variants', async () => {
    expect(
      await run(
        ['foo:flex', 'group-foo:flex', 'peer-foo:flex', 'has-foo:flex', 'not-foo:flex'],
        css`
          @custom-variant foo (@media foo);

          @layer utilities {
            @tailwind utilities;
          }
        `,
      ),
    ).toMatchInlineSnapshot(`
      "
      @layer utilities {
        @media not foo {
          .not-foo\\:flex {
            display: flex;
          }
        }

        @media foo {
          .foo\\:flex {
            display: flex;
          }
        }
      }
      "
    `)
  })

  test('@custom-variant can reuse existing @variant in the definition', async () => {
    expect(
      await run(
        ['hocus:flex'],
        css`
          @custom-variant hocus {
            @variant hover {
              @variant focus {
                @slot;
              }
            }
          }

          @tailwind utilities;
        `,
      ),
    ).toMatchInlineSnapshot(`
      "
      @media (hover: hover) {
        .hocus\\:flex:hover:focus {
          display: flex;
        }
      }
      "
    `)
  })

  test('@custom-variant can reuse @custom-variant that is defined later', async () => {
    expect(
      await run(
        ['hocus:flex'],
        css`
          @custom-variant hocus {
            @variant custom-hover {
              @variant focus {
                @slot;
              }
            }
          }

          @custom-variant custom-hover (&:hover);

          @tailwind utilities;
        `,
      ),
    ).toMatchInlineSnapshot(`
      "
      .hocus\\:flex:hover:focus {
        display: flex;
      }
      "
    `)
  })

  test('@custom-variant can reuse existing @variant that is overwritten later', async () => {
    expect(
      await run(
        ['hocus:flex'],
        css`
          @custom-variant hocus {
            @variant hover {
              @variant focus {
                @slot;
              }
            }
          }

          @custom-variant hover (&:hover);

          @tailwind utilities;
        `,
      ),
    ).toMatchInlineSnapshot(`
      "
      .hocus\\:flex:hover:focus {
        display: flex;
      }
      "
    `)
  })

  test('@custom-variant cannot use @variant that eventually results in a circular dependency', async () => {
    return expect(() =>
      run(
        ['foo:flex'],
        css`
          @custom-variant custom-variant {
            @variant foo {
              @slot;
            }
          }

          @custom-variant foo {
            @variant hover {
              @variant bar {
                @slot;
              }
            }
          }

          @custom-variant bar {
            @variant focus {
              @variant baz {
                @slot;
              }
            }
          }

          @custom-variant baz {
            @variant active {
              @variant foo {
                @slot;
              }
            }
          }

          @tailwind utilities;
        `,
      ),
    ).rejects.toThrowErrorMatchingInlineSnapshot(`
      [Error: Circular dependency detected in custom variants:

      @custom-variant custom-variant {
        @variant foo { … }
      }
      @custom-variant foo { /* ← */
        @variant bar { … }
      }
      @custom-variant bar {
        @variant baz { … }
      }
      @custom-variant baz {
        @variant foo { … }
      }
      ]
    `)
  })

  // https://github.com/tailwindlabs/tailwindcss/issues/19618
  test('@custom-variant can use a @variant that eventually uses another @custom-variant', async () => {
    expect(
      await run(
        ['a:flex', 'b:flex', 'a:b:flex', 'b:a:flex'],
        css`
          @custom-variant a {
            @slot;
          }

          @custom-variant b {
            @variant a {
              @slot;
            }
          }

          @tailwind utilities;
        `,
      ),
    ).toMatchInlineSnapshot(`
      "
      .a\\:flex, .b\\:flex, .a\\:b\\:flex, .b\\:a\\:flex {
        display: flex;
      }
      "
    `)
  })

  test('@custom-variant can use a @variant that eventually uses another @custom-variant (2)', async () => {
    expect(
      await run(
        ['a:flex', 'b:flex', 'a:b:flex', 'b:a:flex'],
        css`
          @custom-variant a {
            .a {
              @slot;
            }
          }

          @custom-variant b {
            .b {
              @variant a {
                .a-inside-b {
                  @slot;
                }
              }
            }
          }

          @tailwind utilities;
        `,
      ),
    ).toMatchInlineSnapshot(`
      "
      .a\\:flex .a, .b\\:flex .b .a .a-inside-b, .a\\:b\\:flex .a .b .a .a-inside-b, .b\\:a\\:flex .b .a .a-inside-b .a {
        display: flex;
      }
      "
    `)
  })

  // https://github.com/tailwindlabs/tailwindcss/issues/19618#issuecomment-3830775912
  test('@custom-variant can use existing @slot @variants', async () => {
    expect(
      await run(
        ['hocus:flex'],
        css`
          @custom-variant hocus {
            @variant hover {
              @variant focus {
                @slot;
              }
            }
          }

          @custom-variant hover {
            &:hover {
              @slot;
            }

            &[data-hover] {
              @slot;
            }
          }

          @tailwind utilities;
        `,
      ),
    ).toMatchInlineSnapshot(`
      "
      .hocus\\:flex:hover:focus, .hocus\\:flex[data-hover]:focus {
        display: flex;
      }
      "
    `)
  })

  test('@custom-variant setup that results in a circular dependency error can be solved', async () => {
    expect(
      await run(
        ['baz:flex'],
        css`
          @custom-variant foo {
            @variant hover {
              @variant bar {
                @slot;
              }
            }
          }

          @custom-variant bar {
            @variant focus {
              @variant baz {
                @slot;
              }
            }
          }

          @custom-variant baz {
            @variant active {
              @variant foo {
                @slot;
              }
            }
          }

          /* Break the circle */
          @custom-variant foo ([data-broken-circle] &);

          @tailwind utilities;
        `,
      ),
    ).toMatchInlineSnapshot(`
      "
      [data-broken-circle] .baz\\:flex:active {
        display: flex;
      }
      "
    `)
  })
})

describe('@utility', () => {
  test('@utility must be top-level and cannot be nested', () => {
    return expect(
      compileCss(css`
        .foo {
          @utility foo {
            color: red;
          }
        }
      `),
    ).rejects.toThrowErrorMatchingInlineSnapshot(`[Error: \`@utility\` cannot be nested.]`)
  })

  test('@utility must include a body', () => {
    return expect(
      compileCss(css`
        @utility foo {
        }
      `),
    ).rejects.toThrowErrorMatchingInlineSnapshot(
      `[Error: \`@utility foo\` is empty. Utilities should include at least one property.]`,
    )
  })

  test('@utility cannot contain any special characters', () => {
    return expect(
      compileCss(css`
        @utility 💨 {
          color: red;
        }
      `),
    ).rejects.toThrowErrorMatchingInlineSnapshot(
      `[Error: \`@utility 💨\` defines an invalid utility name. Utilities should be alphanumeric and start with a lowercase letter.]`,
    )
  })

  test('@utility can handle escape sequences correctly', async () => {
    expect(
      await run(
        ['push-1/2', 'push-50%'],
        css`
          @layer utilities {
            @tailwind utilities;
          }

          @utility push-1\/2 {
            right: 50%;
          }

          @utility push-50\% {
            right: 50%;
          }
        `,
      ),
    ).toMatchInlineSnapshot(`
      "
      @layer utilities {
        .push-1\\/2, .push-50\\% {
          right: 50%;
        }
      }
      "
    `)
  })

  test('A functional @utility must end in -*', () => {
    return expect(
      compileCss(css`
        @utility foo* {
          color: red;
        }
      `),
    ).rejects.toThrowErrorMatchingInlineSnapshot(
      `[Error: \`@utility foo*\` defines an invalid utility name. A functional utility must end in \`-*\`.]`,
    )
  })

  test('Only the last part of a functional @utility can be dynamic', () => {
    return expect(
      compileCss(css`
        @utility my-*-utility {
          color: red;
        }
      `),
    ).rejects.toThrowErrorMatchingInlineSnapshot(
      `[Error: \`@utility my-*-utility\` defines an invalid utility name. The dynamic portion marked by \`-*\` must appear once at the end.]`,
    )
  })

  // https://github.com/tailwindlabs/tailwindcss/issues/19505
  test('@utility name cannot contain multiple `/` characters', async () => {
    expect(
      await run(
        ['ui/button'],
        css`
          @utility ui/button {
            display: inline-flex;
            background: blue;
          }
          @tailwind utilities;
        `,
      ),
    ).toMatchInlineSnapshot(
      `
      "
      .ui\\/button {
        background: #00f;
        display: inline-flex;
      }
      "
    `,
    )

    await expect(
      compileCss(css`
        @utility ui/button/sm {
          display: inline-flex;
          background: blue;
          font-size: 12px;
        }
      `),
    ).rejects.toThrowErrorMatchingInlineSnapshot(
      `[Error: \`@utility ui/button/sm\` defines an invalid utility name. Utilities should be alphanumeric and start with a lowercase letter.]`,
    )
  })
})

test('addBase', async () => {
  expect(
    await run(
      ['underline'],
      css`
        @plugin "my-plugin";
        @layer base, utilities;
        @layer utilities {
          @tailwind utilities;
        }
      `,
      {
        loadModule: async () => ({
          path: '',
          base: '/root',
          module: ({ addBase }: PluginAPI) => {
            addBase({
              body: {
                'font-feature-settings': '"tnum"',
              },
            })
          },
        }),
      },
    ),
  ).toMatchInlineSnapshot(`
    "
    @layer base {
      body {
        font-feature-settings: "tnum";
      }
    }

    @layer utilities {
      .underline {
        text-decoration-line: underline;
      }
    }
    "
  `)
})

test('JS APIs support @variant', async () => {
  expect(
    await run(
      ['underline', 'foo', 'bar-one'],
      css`
        @plugin "my-plugin";
        @layer base, utilities;
        @layer utilities {
          @tailwind utilities;
        }
      `,
      {
        loadModule: async () => ({
          path: '',
          base: '/root',
          module: ({ addBase, addUtilities, matchUtilities }: PluginAPI) => {
            addBase({ body: { '@variant dark': { color: 'red' } } })
            addUtilities({ '.foo': { '@variant dark': { '--foo': 'foo' } } })
            matchUtilities(
              { bar: (value) => ({ '@variant dark': { '--bar': value } }) },
              { values: { one: '1' } },
            )
          },
        }),
      },
    ),
  ).toMatchInlineSnapshot(`
    "
    @layer base {
      @media (prefers-color-scheme: dark) {
        body {
          color: red;
        }
      }
    }

    @layer utilities {
      .underline {
        text-decoration-line: underline;
      }

      @media (prefers-color-scheme: dark) {
        .bar-one {
          --bar: 1;
        }

        .foo {
          --foo: foo;
        }
      }
    }
    "
  `)
})

it("should error when `layer(…)` is used, but it's not the first param", async () => {
  await expect(async () => {
    return await compileCss(
      css`
        @import './bar.css' supports(display: grid) layer(utilities);
      `,
      {
        async loadStylesheet() {
          return {
            path: '',
            base: '/bar.css',
            content: css`
              .foo {
                @apply underline;
              }
            `,
          }
        },
      },
    )
  }).rejects.toThrowErrorMatchingInlineSnapshot(
    `[Error: \`layer(…)\` in an \`@import\` should come before any other functions or conditions]`,
  )
})

describe('`@reference "…" imports`', () => {
  test('recursively removes styles', async () => {
    let loadStylesheet = async (id: string, base = '/root/foo') => {
      if (id === './foo/baz.css') {
        return {
          base,
          path: '',
          content: css`
            .foo {
              color: red;
            }
            @utility foo {
              color: red;
            }
            @theme {
              --breakpoint-md: 768px;
            }
            @custom-variant hocus (&:hover, &:focus);
          `,
        }
      }
      return {
        path: '',
        base: '/root/foo',
        content: css`
          @import './foo/baz.css';
        `,
      }
    }

    expect(
      await compileCss(
        css`
          @reference './foo/bar.css';

          .bar {
            @apply md:hocus:foo;
          }
        `,
        { loadStylesheet },
      ),
    ).toMatchInlineSnapshot(`
      "
      @media (min-width: 768px) {
        .bar:hover, .bar:focus {
          color: red;
        }
      }
      "
    `)
  })

  test('does not generate utilities', async () => {
    expect(
      await run(
        ['text-underline', 'border'],
        css`
          @reference './foo/bar.css';
        `,
        {
          loadStylesheet: async (id: string, base = '/root/foo') => {
            if (id === './foo/baz.css') {
              return {
                base,
                path: '',
                content: css`
                  @layer utilities {
                    @tailwind utilities;
                  }
                `,
              }
            }
            return {
              path: '',
              base: '/root/foo',
              content: css`
                @import './foo/baz.css';
              `,
            }
          },
        },
      ),
    ).toEqual('')
  })

  test('removes all @keyframes, even those contributed by JavasScript plugins', async () => {
    expect(
      await run(
        ['animate-spin', 'match-utility-initial', 'match-components-initial'],
        css`
          @media reference {
            @layer theme, base, components, utilities;
            @layer theme {
              @theme {
                --animate-spin: spin 1s linear infinite;
                --animate-ping: ping 1s cubic-bezier(0, 0, 0.2, 1) infinite;
                @keyframes spin {
                  to {
                    transform: rotate(360deg);
                  }
                }
              }
            }
            @layer base {
              @keyframes ping {
                75%,
                100% {
                  transform: scale(2);
                  opacity: 0;
                }
              }
            }
            @plugin "my-plugin";
          }

          .bar {
            @apply animate-spin;
          }
        `,
        {
          loadModule: async () => ({
            path: '',
            base: '/root',
            module: ({
              addBase,
              addUtilities,
              addComponents,
              matchUtilities,
              matchComponents,
            }: PluginAPI) => {
              addBase({
                '@keyframes base': { '100%': { opacity: '0' } },
              })
              addUtilities({
                '@keyframes utilities': { '100%': { opacity: '0' } },
              })
              addComponents({
                '@keyframes components ': { '100%': { opacity: '0' } },
              })
              matchUtilities(
                {
                  'match-utility': (_value) => ({
                    '@keyframes match-utilities': { '100%': { opacity: '0' } },
                  }),
                },
                { values: { initial: 'initial' } },
              )
              matchComponents(
                {
                  'match-components': (_value) => ({
                    '@keyframes match-components': { '100%': { opacity: '0' } },
                  }),
                },
                { values: { initial: 'initial' } },
              )
            },
          }),
        },
      ),
    ).toMatchInlineSnapshot(`
      "
      .bar {
        animation: var(--animate-spin, spin 1s linear infinite);
      }

      @keyframes spin {
        to {
          transform: rotate(360deg);
        }
      }
      "
    `)
  })

  test('emits CSS variable fallback and keyframes defined inside @reference-ed files', async () => {
    let loadStylesheet = async (id: string, base = '/root') => {
      switch (id) {
        case './one.css': {
          return {
            base,
            path: '',
            content: css`
              @import './two.css' layer(two);
            `,
          }
        }
        case './two.css': {
          return {
            base,
            path: '',
            content: css`
              @import './three.css' layer(three);
            `,
          }
        }
        case './three.css': {
          return {
            base,
            path: '',
            content: css`
              .foo {
                color: red;
              }
              @theme {
                --color-red: red;
                --animate-wiggle: wiggle 1s ease-in-out infinite;
                @keyframes wiggle {
                  0%,
                  100% {
                    transform: rotate(-3deg);
                  }
                  50% {
                    transform: rotate(3deg);
                  }
                }
              }
            `,
          }
        }
      }

      throw new Error('unreachable')
    }

    expect(
      await compileCss(
        css`
          @reference './one.css';
          .bar {
            @apply text-red animate-wiggle;
          }
        `,
        { loadStylesheet },
      ),
    ).toMatchInlineSnapshot(`
      "
      .bar {
        animation: var(--animate-wiggle, wiggle 1s ease-in-out infinite);
        color: var(--color-red, red);
      }

      @keyframes wiggle {
        0%, 100% {
          transform: rotate(-3deg);
        }

        50% {
          transform: rotate(3deg);
        }
      }
      "
    `)
  })

  test('supports `@import "…" reference` syntax', async () => {
    let loadStylesheet = async () => {
      return {
        path: '',
        base: '/root/foo',
        content: css`
          .foo {
            color: red;
          }
          @utility foo {
            color: red;
          }
          @theme {
            --breakpoint-md: 768px;
          }
          @custom-variant hocus (&:hover, &:focus);
        `,
      }
    }

    expect(
      await compileCss(
        css`
          @import './foo/bar.css' reference;

          .bar {
            @apply md:hocus:foo;
          }
        `,
        { loadStylesheet },
      ),
    ).toMatchInlineSnapshot(`
      "
      @media (min-width: 768px) {
        .bar:hover, .bar:focus {
          color: red;
        }
      }
      "
    `)
  })

  test('removes styles when the import resolver was handled outside of Tailwind CSS', async () => {
    expect(
      await compileCss(css`
        @media reference {
          @layer theme {
            @theme {
              --breakpoint-md: 48rem;
            }
            .foo {
              color: red;
            }
          }
          @utility foo {
            color: red;
          }
          @custom-variant hocus (&:hover, &:focus);
        }

        .bar {
          @apply md:hocus:foo;
        }
      `),
    ).toMatchInlineSnapshot(`
      "
      @media (min-width: 48rem) {
        .bar:hover, .bar:focus {
          color: red;
        }
      }
      "
    `)
  })
})

describe('@variant', () => {
  it('should convert legacy body-less `@variant` as a `@custom-variant`', async () => {
    expect(
      await run(
        ['hocus:underline'],
        css`
          @variant hocus (&:hover, &:focus);
          @tailwind utilities;
        `,
      ),
    ).toMatchInlineSnapshot(`
      "
      .hocus\\:underline:hover, .hocus\\:underline:focus {
        text-decoration-line: underline;
      }
      "
    `)
  })

  it('should convert legacy `@variant` with `@slot` as a `@custom-variant`', async () => {
    expect(
      await run(
        ['hocus:underline'],
        css`
          @variant hocus {
            &:hover {
              @slot;
            }

            &:focus {
              @slot;
            }
          }
          @tailwind utilities;
        `,
      ),
    ).toMatchInlineSnapshot(`
      "
      .hocus\\:underline:hover, .hocus\\:underline:focus {
        text-decoration-line: underline;
      }
      "
    `)
  })

  it('should be possible to use `@variant` in your CSS', async () => {
    expect(
      await compileCss(css`
        .btn {
          background: black;

          @variant dark {
            background: white;
          }
        }

        @variant hover {
          @variant landscape {
            .btn2 {
              color: red;
            }
          }
        }

        @variant hover {
          .foo {
            color: red;
          }
          @variant landscape {
            .bar {
              color: blue;
            }
          }
          .baz {
            @variant portrait {
              color: green;
            }
          }
        }

        @media something {
          @variant landscape {
            @page {
              color: red;
            }
          }
        }
      `),
    ).toMatchInlineSnapshot(`
      "
      .btn {
        background: #000;
      }

      @media (prefers-color-scheme: dark) {
        .btn {
          background: #fff;
        }
      }

      @media (hover: hover) {
        @media (orientation: landscape) {
          :scope:hover .btn2 {
            color: red;
          }
        }

        :scope:hover .foo {
          color: red;
        }

        @media (orientation: landscape) {
          :scope:hover .bar {
            color: #00f;
          }
        }

        @media (orientation: portrait) {
          :scope:hover .baz {
            color: green;
          }
        }
      }

      @media something {
        @media (orientation: landscape) {
          @page {
            color: red;
          }
        }
      }
      "
    `)
  })

  it('should be possible to use `@variant` in your CSS with a `@custom-variant` that is defined later', async () => {
    expect(
      await compileCss(css`
        .btn {
          background: black;

          @variant hocus {
            background: white;
          }
        }

        @custom-variant hocus (&:hover, &:focus);
      `),
    ).toMatchInlineSnapshot(`
      "
      .btn {
        background: #000;
      }

      .btn:hover, .btn:focus {
        background: #fff;
      }
      "
    `)
  })

  it('should be possible to use nested `@variant` rules', async () => {
    expect(
      await run(
        ['disabled:focus:underline'],
        css`
          .btn {
            background: black;

            @variant disabled {
              @variant focus {
                background: white;
              }
            }
          }
          @tailwind utilities;
        `,
      ),
    ).toMatchInlineSnapshot(`
      "
      .btn {
        background: #000;
      }

      .btn:disabled:focus {
        background: #fff;
      }

      .disabled\\:focus\\:underline:disabled:focus {
        text-decoration-line: underline;
      }
      "
    `)
  })

  describe('comma-separated `@variant` rules', () => {
    it('should be possible to use comma-separated `@variant` rules', async () => {
      let input = css`
        .btn {
          background: black;

          @variant hover, focus {
            background: red;
          }
        }
        @tailwind utilities;
      `

      expect(await compileCss(input)).toMatchInlineSnapshot(`
        "
        .btn {
          background: #000;
        }

        @media (hover: hover) {
          .btn:hover {
            background: red;
          }
        }

        .btn:focus {
          background: red;
        }
        "
      `)

      expect(await compileCss(input)).toEqual(
        await compileCss(css`
          .btn {
            background: black;

            @variant hover {
              background: red;
            }
            @variant focus {
              background: red;
            }
          }
          @tailwind utilities;
        `),
      )
    })

    it.each(
      Array.from(
        cartesian(
          ['', ' ', '  ', '\t', '\t\t'], // Before
          ['', ' ', '  ', '\t', '\t\t'], // After
        ),
      ),
    )(
      "should handle optional whitespace ('%s', '%s') between `@variant` variants",
      async (before, after) => {
        expect(
          await compileCss(css`
            .btn {
              background: black;

              @variant hover${before},${after}focus {
                background: red;
              }
            }
            @tailwind utilities;
          `),
        ).toMatchInlineSnapshot(`
          "
          .btn {
            background: #000;
          }

          @media (hover: hover) {
            .btn:hover {
              background: red;
            }
          }

          .btn:focus {
            background: red;
          }
          "
        `)
      },
    )

    it('should handle variants containing a `,` inside', async () => {
      expect(
        await compileCss(css`
          .btn {
            background: black;

            @variant [&:is(:hover,:focus)], disabled {
              background: red;
            }
          }
          @tailwind utilities;
        `),
      ).toMatchInlineSnapshot(`
        "
        .btn {
          background: #000;
        }

        .btn:is(:hover, :focus), .btn:disabled {
          background: red;
        }
        "
      `)
    })

    it('should handle nested comma-separated variants', async () => {
      let input = css`
        .btn {
          background: black;

          @variant hover, focus {
            background: red;

            @variant active, disabled {
              background: blue;
            }
          }
        }
        @tailwind utilities;
      `

      expect(await compileCss(input)).toMatchInlineSnapshot(`
        "
        .btn {
          background: #000;
        }

        @media (hover: hover) {
          .btn:hover {
            background: red;
          }

          .btn:hover:active, .btn:hover:disabled {
            background: #00f;
          }
        }

        .btn:focus {
          background: red;
        }

        .btn:focus:active, .btn:focus:disabled {
          background: #00f;
        }
        "
      `)

      expect(await compileCss(input)).toEqual(
        await compileCss(css`
          .btn {
            background: black;

            @variant hover {
              background: red;

              @variant active {
                background: blue;
              }

              @variant disabled {
                background: blue;
              }
            }

            @variant focus {
              background: red;

              @variant active {
                background: blue;
              }

              @variant disabled {
                background: blue;
              }
            }
          }
          @tailwind utilities;
        `),
      )
    })

    it('should error on invalid variants (trailing comma)', async () => {
      await expect(
        compileCss(css`
          .btn {
            background: black;

            @variant hover,focus, {
              background: red;
            }
          }
          @tailwind utilities;
        `),
      ).rejects.toThrowErrorMatchingInlineSnapshot(
        `[Error: Cannot use \`@variant\` with empty variant]`,
      )
    })

    it('should error on invalid variants (double comma)', async () => {
      await expect(
        compileCss(css`
          .btn {
            background: black;

            @variant hover,,focus {
              background: red;
            }
          }
          @tailwind utilities;
        `),
      ).rejects.toThrowErrorMatchingInlineSnapshot(
        `[Error: Cannot use \`@variant\` with empty variant]`,
      )
    })
  })

  describe('stacked `@variant` rules', () => {
    it('should handle stacked variants', async () => {
      expect(
        await compileCss(css`
          .btn {
            background: black;

            @variant hover:focus {
              background: red;
            }
          }
          @tailwind utilities;
        `),
      ).toMatchInlineSnapshot(`
        "
        .btn {
          background: #000;
        }

        @media (hover: hover) {
          .btn:hover:focus {
            background: red;
          }
        }
        "
      `)
    })

    it('should handle stacked variants & comma-separated variants', async () => {
      expect(
        await compileCss(css`
          .btn {
            background: black;

            @variant hover:focus, disabled {
              background: red;
            }
          }
          @tailwind utilities;
        `),
      ).toMatchInlineSnapshot(`
        "
        .btn {
          background: #000;
        }

        @media (hover: hover) {
          .btn:hover:focus {
            background: red;
          }
        }

        .btn:disabled {
          background: red;
        }
        "
      `)
    })

    it('should handle variants containing a `:` inside', async () => {
      expect(
        await compileCss(css`
          .btn {
            background: black;

            @variant [&:is(:hover,:focus)]:disabled, aria-disabled:hover {
              background: red;
            }
          }
          @tailwind utilities;
        `),
      ).toMatchInlineSnapshot(`
        "
        .btn {
          background: #000;
        }

        .btn:is(:hover, :focus):disabled {
          background: red;
        }

        @media (hover: hover) {
          .btn[aria-disabled="true"]:hover {
            background: red;
          }
        }
        "
      `)
    })
  })

  it('should be possible to use compound and stacked variants in `@variant`', async () => {
    let input = css`
      .btn {
        background: black;

        @variant data-a, data-b:data-c {
          background: red;

          @variant data-d, data-e:data-f {
            background: blue;
          }
        }
      }
      @tailwind utilities;
    `

    expect(await compileCss(input)).toMatchInlineSnapshot(`
      "
      .btn {
        background: #000;
      }

      .btn[data-a] {
        background: red;
      }

      .btn[data-a][data-d], .btn[data-a][data-e][data-f] {
        background: #00f;
      }

      .btn[data-b][data-c] {
        background: red;
      }

      .btn[data-b][data-c][data-d], .btn[data-b][data-c][data-e][data-f] {
        background: #00f;
      }
      "
    `)

    expect(await compileCss(input)).toEqual(
      await compileCss(css`
        .btn {
          background: black;

          @variant data-a {
            background: red;

            @variant data-d {
              background: blue;
            }

            @variant data-e {
              @variant data-f {
                background: blue;
              }
            }
          }

          @variant data-b {
            @variant data-c {
              background: red;

              @variant data-d {
                background: blue;
              }

              @variant data-e {
                @variant data-f {
                  background: blue;
                }
              }
            }
          }
        }
        @tailwind utilities;
      `),
    )
  })

  it('should be possible to use `@variant` with a funky looking variants', async () => {
    expect(
      await compileCss(css`
        @theme inline reference {
          --container-md: 768px;
        }

        .btn {
          background: black;

          @variant @md {
            @variant [&.foo] {
              background: white;
            }
          }
        }
      `),
    ).toMatchInlineSnapshot(`
      "
      .btn {
        background: #000;
      }

      @container (min-width: 768px) {
        .btn.foo {
          background: #fff;
        }
      }
      "
    `)
  })
})

describe('`color-mix(…)` polyfill', () => {
  it('creates an inlined variable version of the color-mix(…) usages', async () => {
    expect(
      await run(
        ['text-red-500/50'],
        css`
          @theme {
            --color-red-500: oklch(63.7% 0.237 25.331);
          }
          @tailwind utilities;
        `,
      ),
    ).toMatchInlineSnapshot(`
      "
      :root, :host {
        --color-red-500: oklch(63.7% .237 25.331);
      }

      .text-red-500\\/50 {
        color: #fb2c3680;
      }

      @supports (color: color-mix(in lab, red, red)) {
        .text-red-500\\/50 {
          color: color-mix(in oklab, var(--color-red-500) 50%, transparent);
        }
      }
      "
    `)
  })

  it('creates an inlined variable version of the color-mix(…) usages when it resolves to a var(…) containing another theme variable', async () => {
    expect(
      await run(
        ['text-red/50'],
        css`
          @theme {
            --color-red: var(--color-red-500);
            --color-red-500: oklch(63.7% 0.237 25.331);
          }
          @tailwind utilities;
        `,
      ),
    ).toMatchInlineSnapshot(`
      "
      :root, :host {
        --color-red: var(--color-red-500);
        --color-red-500: oklch(63.7% .237 25.331);
      }

      .text-red\\/50 {
        color: #fb2c3680;
      }

      @supports (color: color-mix(in lab, red, red)) {
        .text-red\\/50 {
          color: color-mix(in oklab, var(--color-red) 50%, transparent);
        }
      }
      "
    `)
  })

  it('works for color values in the first and second position', async () => {
    expect(
      await compileCss(css`
        @theme {
          --color-red-500: oklch(63.7% 0.237 25.331);
          --color-orange-500: oklch(70.5% 0.213 47.604);
        }
        @tailwind utilities;
        .mixed {
          color: color-mix(in lch, var(--color-red-500) 50%, var(--color-orange-500));
        }
      `),
    ).toMatchInlineSnapshot(`
      "
      :root, :host {
        --color-red-500: oklch(63.7% .237 25.331);
        --color-orange-500: oklch(70.5% .213 47.604);
      }

      .mixed {
        color: #fc4d1b;
      }

      @supports (color: color-mix(in lab, red, red)) {
        .mixed {
          color: color-mix(in lch, var(--color-red-500) 50%, var(--color-orange-500));
        }
      }
      "
    `)
  })

  it('works for nested `color-mix(…)` calls', async () => {
    expect(
      await compileCss(css`
        @theme {
          --color-red-500: oklch(63.7% 0.237 25.331);
        }
        @tailwind utilities;
        .stacked {
          color: color-mix(
            in lch,
            color-mix(in lch, var(--color-red-500) 50%, transparent) 50%,
            transparent
          );
        }
      `),
    ).toMatchInlineSnapshot(`
      "
      :root, :host {
        --color-red-500: oklch(63.7% .237 25.331);
      }

      .stacked {
        color: lch(55.5764% 89.7903 33.1932 / .25098);
      }

      @supports (color: color-mix(in lab, red, red)) {
        .stacked {
          color: color-mix(in lch, color-mix(in lch, var(--color-red-500) 50%, transparent) 50%, transparent);
        }
      }
      "
    `)
  })

  it('works with multiple `color-mix(…)` functions in one declaration', async () => {
    expect(
      await compileCss(css`
        @theme {
          --color-red-500: oklch(63.7% 0.237 25.331);
          --color-orange-500: oklch(70.5% 0.213 47.604);
        }
        @tailwind utilities;
        .gradient {
          background: linear-gradient(
            90deg,
            color-mix(in oklab, var(--color-red-500) 50%, transparent) 0%,
            color-mix(in oklab, var(--color-orange-500) 50%, transparent) 0%,
            100%
          );
        }
      `),
    ).toMatchInlineSnapshot(`
      "
      :root, :host {
        --color-red-500: oklch(63.7% .237 25.331);
        --color-orange-500: oklch(70.5% .213 47.604);
      }

      .gradient {
        background: linear-gradient(90deg, #fb2c3680 0%, #fe6e0080 0%, 100%);
      }

      @supports (color: color-mix(in lab, red, red)) {
        .gradient {
          background: linear-gradient(90deg, color-mix(in oklab, var(--color-red-500) 50%, transparent) 0%, color-mix(in oklab, var(--color-orange-500) 50%, transparent) 0%, 100%);
        }
      }
      "
    `)
  })

  it('works with no spaces after the `var(…)`', async () => {
    expect(
      await compileCss(
        // prettier-ignore
        css`
          @theme {
            --color-red-500: oklch(63.7% 0.237 25.331);
          }
          @tailwind utilities;
          .text-red-500\/50 {
            color: color-mix(in oklab,var(--color-red-500)50%,transparent);
          }
        `,
      ),
    ).toMatchInlineSnapshot(`
      "
      :root, :host {
        --color-red-500: oklch(63.7% .237 25.331);
      }

      .text-red-500\\/50 {
        color: #fb2c3680;
      }

      @supports (color: color-mix(in lab, red, red)) {
        .text-red-500\\/50 {
          color: color-mix(in oklab,var(--color-red-500)50%,transparent);
        }
      }
      "
    `)
  })

  it('uses the first color value as the fallback when the `color-mix(…)` function contains non-theme variables', async () => {
    expect(
      await run(
        ['text-(--my-color)/50', 'text-red-500/(--my-opacity)', 'text-(--my-color)/(--my-opacity)'],
        css`
          @theme {
            --color-red-500: oklch(63.7% 0.237 25.331);
          }
          @tailwind utilities;
        `,
      ),
    ).toMatchInlineSnapshot(`
      "
      :root, :host {
        --color-red-500: oklch(63.7% .237 25.331);
      }

      .text-\\(--my-color\\)\\/\\(--my-opacity\\) {
        color: var(--my-color);
      }

      @supports (color: color-mix(in lab, red, red)) {
        .text-\\(--my-color\\)\\/\\(--my-opacity\\) {
          color: color-mix(in oklab, var(--my-color) var(--my-opacity), transparent);
        }
      }

      .text-\\(--my-color\\)\\/50 {
        color: var(--my-color);
      }

      @supports (color: color-mix(in lab, red, red)) {
        .text-\\(--my-color\\)\\/50 {
          color: color-mix(in oklab, var(--my-color) 50%, transparent);
        }
      }

      .text-red-500\\/\\(--my-opacity\\) {
        color: oklch(63.7% .237 25.331);
      }

      @supports (color: color-mix(in lab, red, red)) {
        .text-red-500\\/\\(--my-opacity\\) {
          color: color-mix(in oklab, var(--color-red-500) var(--my-opacity), transparent);
        }
      }
      "
    `)
  })

  it('uses the first color value as the fallback when the `color-mix(…)` function contains currentcolor', async () => {
    expect(await run(['text-current/50'])).toMatchInlineSnapshot(`
      "
      .text-current\\/50 {
        color: currentColor;
      }

      @supports (color: color-mix(in lab, red, red)) {
        .text-current\\/50 {
          color: color-mix(in oklab, currentcolor 50%, transparent);
        }
      }
      "
    `)
  })

  it('uses the first color value as the fallback when the `color-mix(…)` function contains theme variables that resolves to other variables', async () => {
    expect(
      await run(
        ['text-red/50'],
        css`
          @tailwind utilities;
          @theme {
            --color-red: var(--my-red);
          }
        `,
      ),
    ).toMatchInlineSnapshot(`
      "
      .text-red\\/50 {
        color: var(--color-red);
      }

      @supports (color: color-mix(in lab, red, red)) {
        .text-red\\/50 {
          color: color-mix(in oklab, var(--color-red) 50%, transparent);
        }
      }

      :root, :host {
        --color-red: var(--my-red);
      }
      "
    `)
  })

  it('uses the first color value of the inner most `color-mix(…)` function as the fallback when nested `color-mix(…)` function all contain non-theme variables', async () => {
    expect(
      await compileCss(css`
        @tailwind utilities;
        .stacked {
          color: color-mix(
            in oklab,
            color-mix(in oklab, var(--my-color) var(--my-inner-opacity), transparent)
              var(--my-outer-opacity),
            transparent
          );
        }
      `),
    ).toMatchInlineSnapshot(`
      "
      .stacked {
        color: var(--my-color);
      }

      @supports (color: color-mix(in lab, red, red)) {
        .stacked {
          color: color-mix(in oklab, color-mix(in oklab, var(--my-color) var(--my-inner-opacity), transparent) var(--my-outer-opacity), transparent);
        }
      }
      "
    `)
  })

  it('does not create a fallback when all color values are statically analyzable (lightningcss will flatten this)', async () => {
    expect(
      await run(
        ['text-red-500/50'],
        css`
          @theme inline {
            --color-red-500: oklch(63.7% 0.237 25.331);
          }
          @tailwind utilities;
        `,
      ),
    ).toMatchInlineSnapshot(`
      "
      .text-red-500\\/50 {
        color: oklab(63.7% .214 .101 / .5);
      }
      "
    `)
  })

  it('also replaces eventual variables in opacity values', async () => {
    expect(
      await run(
        ['text-red-500/(--my-half)'],
        css`
          @theme {
            --my-half: 50%;
            --color-red-500: oklch(63.7% 0.237 25.331);
          }
          @tailwind utilities;
        `,
      ),
    ).toMatchInlineSnapshot(`
      "
      :root, :host {
        --my-half: 50%;
        --color-red-500: oklch(63.7% .237 25.331);
      }

      .text-red-500\\/\\(--my-half\\) {
        color: #fb2c3680;
      }

      @supports (color: color-mix(in lab, red, red)) {
        .text-red-500\\/\\(--my-half\\) {
          color: color-mix(in oklab, var(--color-red-500) var(--my-half), transparent);
        }
      }
      "
    `)
  })

  it('does not delete theme variables from the output', async () => {
    expect(
      await run(
        ['text-red-500', 'shadow-xl', 'opacity-disabled'],
        css`
          @layer theme {
            @theme {
              --color-red-500: red;
              --shadow-xl: 0 6px 18px 4px color-mix(in oklab, var(--color-red-500) 25%, transparent);
              --opacity-disabled: 50%;
            }
          }
          @tailwind utilities;
        `,
      ),
    ).toMatchInlineSnapshot(`
      "
      @layer properties {
        @supports (((-webkit-hyphens: none)) and (not (margin-trim: inline))) or ((-moz-orient: inline) and (not (color: rgb(from red r g b)))) {
          *, :before, :after, ::backdrop {
            --tw-shadow: 0 0 #0000;
            --tw-shadow-color: initial;
            --tw-shadow-alpha: 100%;
            --tw-inset-shadow: 0 0 #0000;
            --tw-inset-shadow-color: initial;
            --tw-inset-shadow-alpha: 100%;
            --tw-ring-color: initial;
            --tw-ring-shadow: 0 0 #0000;
            --tw-inset-ring-color: initial;
            --tw-inset-ring-shadow: 0 0 #0000;
            --tw-ring-inset: initial;
            --tw-ring-offset-width: 0px;
            --tw-ring-offset-color: #fff;
            --tw-ring-offset-shadow: 0 0 #0000;
          }
        }
      }

      @layer theme {
        :root, :host {
          --color-red-500: red;
          --opacity-disabled: 50%;
        }
      }

      .text-red-500 {
        color: var(--color-red-500);
      }

      .opacity-disabled {
        opacity: var(--opacity-disabled);
      }

      .shadow-xl {
        --tw-shadow: 0 6px 18px 4px var(--tw-shadow-color, #ff000040);
      }

      @supports (color: color-mix(in lab, red, red)) {
        .shadow-xl {
          --tw-shadow: 0 6px 18px 4px var(--tw-shadow-color, color-mix(in oklab, var(--color-red-500) 25%, transparent));
        }
      }

      .shadow-xl {
        box-shadow: var(--tw-inset-shadow), var(--tw-inset-ring-shadow), var(--tw-ring-offset-shadow), var(--tw-ring-shadow), var(--tw-shadow);
      }

      @property --tw-shadow {
        syntax: "*";
        inherits: false;
        initial-value: 0 0 #0000;
      }

      @property --tw-shadow-color {
        syntax: "*";
        inherits: false
      }

      @property --tw-shadow-alpha {
        syntax: "<percentage>";
        inherits: false;
        initial-value: 100%;
      }

      @property --tw-inset-shadow {
        syntax: "*";
        inherits: false;
        initial-value: 0 0 #0000;
      }

      @property --tw-inset-shadow-color {
        syntax: "*";
        inherits: false
      }

      @property --tw-inset-shadow-alpha {
        syntax: "<percentage>";
        inherits: false;
        initial-value: 100%;
      }

      @property --tw-ring-color {
        syntax: "*";
        inherits: false
      }

      @property --tw-ring-shadow {
        syntax: "*";
        inherits: false;
        initial-value: 0 0 #0000;
      }

      @property --tw-inset-ring-color {
        syntax: "*";
        inherits: false
      }

      @property --tw-inset-ring-shadow {
        syntax: "*";
        inherits: false;
        initial-value: 0 0 #0000;
      }

      @property --tw-ring-inset {
        syntax: "*";
        inherits: false
      }

      @property --tw-ring-offset-width {
        syntax: "<length>";
        inherits: false;
        initial-value: 0;
      }

      @property --tw-ring-offset-color {
        syntax: "*";
        inherits: false;
        initial-value: #fff;
      }

      @property --tw-ring-offset-shadow {
        syntax: "*";
        inherits: false;
        initial-value: 0 0 #0000;
      }
      "
    `)
  })

  it('does not apply optimizations when already inside a @supports (color: color-mix... block', async () => {
    expect(
      await run(
        ['mixed'],
        css`
          @tailwind utilities;
          @utility mixed {
            @supports (color: color-mix(in lab, red, red)) {
              background: color-mix(in oklab, var(--color-1), var(--color-2) 0%);
            }
          }
        `,
      ),
    ).toMatchInlineSnapshot(`
      "
      @supports (color: color-mix(in lab, red, red)) {
        .mixed {
          background: color-mix(in oklab, var(--color-1), var(--color-2) 0%);
        }
      }
      "
    `)
  })
})

describe('`@property` polyfill', async () => {
  it('emits fallbacks', async () => {
    expect(
      await compileCss(css`
        @tailwind utilities;

        @property --no-inherit-no-value {
          syntax: '*';
          inherits: false;
        }
        @property --no-inherit-value {
          syntax: '*';
          inherits: false;
          initial-value: red;
        }
        @property --inherit-no-value {
          syntax: '*';
          inherits: true;
        }
        @property --inherit-value {
          syntax: '*';
          inherits: true;
          initial-value: red;
        }
      `),
    ).toMatchInlineSnapshot(`
      "
      @layer properties {
        @supports (((-webkit-hyphens: none)) and (not (margin-trim: inline))) or ((-moz-orient: inline) and (not (color: rgb(from red r g b)))) {
          :root, :host {
            --inherit-no-value: initial;
            --inherit-value: red;
          }

          *, :before, :after, ::backdrop {
            --no-inherit-no-value: initial;
            --no-inherit-value: red;
          }
        }
      }

      @property --no-inherit-no-value {
        syntax: "*";
        inherits: false
      }

      @property --no-inherit-value {
        syntax: "*";
        inherits: false;
        initial-value: red;
      }

      @property --inherit-no-value {
        syntax: "*";
        inherits: true
      }

      @property --inherit-value {
        syntax: "*";
        inherits: true;
        initial-value: red;
      }
      "
    `)
  })

  it('emitting fallbacks can be disabled (necessary for CSS modules)', async () => {
    expect(
      await compileCss(
        css`
          @tailwind utilities;

          @property --no-inherit-no-value {
            syntax: '*';
            inherits: false;
          }
          @property --no-inherit-value {
            syntax: '*';
            inherits: false;
            initial-value: red;
          }
          @property --inherit-no-value {
            syntax: '*';
            inherits: true;
          }
          @property --inherit-value {
            syntax: '*';
            inherits: true;
            initial-value: red;
          }
        `,
        {
          polyfills: Polyfills.None,
        },
      ),
    ).toMatchInlineSnapshot(`
      "
      @property --no-inherit-no-value {
        syntax: "*";
        inherits: false
      }

      @property --no-inherit-value {
        syntax: "*";
        inherits: false;
        initial-value: red;
      }

      @property --inherit-no-value {
        syntax: "*";
        inherits: true
      }

      @property --inherit-value {
        syntax: "*";
        inherits: true;
        initial-value: red;
      }
      "
    `)
  })
})

describe('feature detection', () => {
  test('using `@tailwind utilities`', async () => {
    let compiler = await compile(css`
      @tailwind utilities;
    `)

    expect(compiler.features & Features.Utilities).toBeTruthy()
  })

  test('using `@apply`', async () => {
    let compiler = await compile(css`
      .foo {
        @apply underline;
      }
    `)

    expect(compiler.features & Features.AtApply).toBeTruthy()
  })

  test('using `@import`', async () => {
    let compiler = await compile(
      css`
        @import 'tailwindcss/preflight';
      `,
      { loadStylesheet: async (_, base) => ({ base, path: '', content: '' }) },
    )

    expect(compiler.features & Features.AtImport).toBeTruthy()
  })

  test('using `@reference`', async () => {
    let compiler = await compile(
      css`
        @reference 'tailwindcss/preflight';
      `,
      { loadStylesheet: async (_, base) => ({ base, path: '', content: '' }) },
    )

    // There's little difference between `@reference` and `@import` on a feature
    // level as it's just like an import but with side-effect behavior.
    //
    // It's really just shorthand for `@import "…" reference;`
    expect(compiler.features & Features.AtImport).toBeTruthy()
  })

  test('using `theme(…)`', async () => {
    let compiler = await compile(
      css`
        @theme {
          --color-red: #f00;
        }

        .foo {
          color: theme(--color-red);
        }
      `,
      { loadStylesheet: async (_, base) => ({ base, path: '', content: '' }) },
    )

    expect(compiler.features & Features.ThemeFunction).toBeTruthy()
  })

  test('using `@plugin`', async () => {
    let compiler = await compile(
      css`
        @plugin "./some-plugin.js";
      `,
      { loadModule: async (_, base) => ({ base, path: '', module: () => {} }) },
    )

    expect(compiler.features & Features.JsPluginCompat).toBeTruthy()
  })

  test('using `@config`', async () => {
    let compiler = await compile(
      css`
        @config "./some-config.js";
      `,
      { loadModule: async (_, base) => ({ base, path: '', module: {} }) },
    )

    expect(compiler.features & Features.JsPluginCompat).toBeTruthy()
  })

  test('using `@variant`', async () => {
    let compiler = await compile(css`
      .foo {
        @variant dark {
          color: red;
        }
      }
    `)

    expect(compiler.features & Features.Variants).toBeTruthy()
  })

  test('legacy `@variant` syntax does not trigger the variant feature', async () => {
    let compiler = await compile(css`
      @variant dark (&:is(.dark, .dark *));
    `)

    expect(compiler.features & Features.Variants).toBeFalsy()
  })

  test('`@tailwind utilities` is ignored inside `@reference`', async () => {
    let compiler = await compile(
      css`
        @reference "tailwindcss/utilities";
      `,
      {
        async loadStylesheet(_id, base) {
          return {
            base,
            path: '',
            content: css`
              @tailwind utilities;
            `,
          }
        },
      },
    )

    // We see @tailwind utilities but because of @reference it is ignored
    expect(compiler.features & Features.AtImport).toBeTruthy()
    expect(compiler.features & Features.Utilities).toBeFalsy()
  })

  test('using `@theme`', async () => {
    let compiler = await compile(css`
      @theme {
        --tracking-narrower: -0.02em;
      }
    `)

    // We see @theme
    expect(compiler.features & Features.AtTheme).toBeTruthy()

    // And this produces no output because no other CSS is present
    expect(compiler.build([])).toEqual('')
  })
})

import unittest
from unittest import mock

from shop.auth import (
    InvalidToken,
    TokenExpired,
    TokenUsed,
    issue_reset_token,
    redeem_reset_token,
)


class ResetTokenTest(unittest.TestCase):
    def test_round_trip(self):
        token = issue_reset_token("ada")
        self.assertEqual(redeem_reset_token(token), "ada")

    def test_unknown_token(self):
        with self.assertRaises(InvalidToken):
            redeem_reset_token("not-a-token")

    def test_exceptions_subclass_invalid_token(self):
        self.assertTrue(issubclass(TokenExpired, InvalidToken))
        self.assertTrue(issubclass(TokenUsed, InvalidToken))

    def test_redeem_at_exactly_ttl_is_valid(self):
        token = issue_reset_token("ada", now=1000)
        self.assertEqual(redeem_reset_token(token, now=1000 + 1800), "ada")

    def test_redeem_after_ttl_expires(self):
        token = issue_reset_token("ada", now=1000)
        with self.assertRaises(TokenExpired):
            redeem_reset_token(token, now=1000 + 1800.001)

    def test_expired_token_stays_expired(self):
        token = issue_reset_token("ada", now=1000)
        with self.assertRaises(TokenExpired):
            redeem_reset_token(token, now=5000)
        with self.assertRaises(TokenExpired):
            redeem_reset_token(token, now=6000)

    def test_issue_at_time_zero(self):
        token = issue_reset_token("ada", now=0)
        with self.assertRaises(TokenExpired):
            redeem_reset_token(token, now=1801)

    def test_second_redeem_raises_used(self):
        token = issue_reset_token("ada", now=1000)
        self.assertEqual(redeem_reset_token(token, now=1001), "ada")
        with self.assertRaises(TokenUsed):
            redeem_reset_token(token, now=1002)
        # still used even after it would have expired
        with self.assertRaises(TokenUsed):
            redeem_reset_token(token, now=99999)

    def test_tokens_are_independent(self):
        a = issue_reset_token("ada", now=1000)
        b = issue_reset_token("bob", now=1000)
        self.assertNotEqual(a, b)
        self.assertEqual(redeem_reset_token(a, now=1000), "ada")
        self.assertEqual(redeem_reset_token(b, now=1000), "bob")

    def test_now_defaults_to_time_time(self):
        with mock.patch("shop.auth.time.time", return_value=5000.0):
            token = issue_reset_token("ada")
        with mock.patch("shop.auth.time.time", return_value=5000.0 + 1801):
            with self.assertRaises(TokenExpired):
                redeem_reset_token(token)


if __name__ == "__main__":
    unittest.main()

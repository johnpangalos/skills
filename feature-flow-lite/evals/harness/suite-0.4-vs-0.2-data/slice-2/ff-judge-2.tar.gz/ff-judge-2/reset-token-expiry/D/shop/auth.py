"""Password-reset tokens (in-memory store)."""

import secrets
import time

TOKEN_TTL = 1800  # seconds a reset token stays redeemable

_TOKENS = {}  # token -> {"username": str, "issued": float, "used": bool}


class InvalidToken(Exception):
    pass


class TokenExpired(InvalidToken):
    pass


class TokenUsed(InvalidToken):
    pass


def issue_reset_token(username, now=None):
    """Create a reset token for username, issued at now (Unix seconds)."""
    if now is None:
        now = time.time()
    token = secrets.token_urlsafe(16)
    _TOKENS[token] = {"username": username, "issued": now, "used": False}
    return token


def redeem_reset_token(token, now=None):
    """Return the username a token was issued for, consuming the token.

    Raises TokenUsed if the token was already redeemed (checked first, so a
    used token stays TokenUsed after its window passes), and TokenExpired if
    more than TOKEN_TTL seconds have passed since issue. A failed expiry check
    does not consume the token.
    """
    if now is None:
        now = time.time()
    record = _TOKENS.get(token)
    if record is None:
        raise InvalidToken("unknown token")
    if record["used"]:
        raise TokenUsed("token already used")
    if now - record["issued"] > TOKEN_TTL:
        raise TokenExpired("token expired")
    record["used"] = True
    return record["username"]

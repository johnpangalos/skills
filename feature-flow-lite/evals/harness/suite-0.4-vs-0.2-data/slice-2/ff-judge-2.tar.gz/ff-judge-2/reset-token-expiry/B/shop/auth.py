"""Password-reset tokens (in-memory store)."""

import secrets
import time

TOKEN_TTL_SECONDS = 1800  # 30 minutes

_TOKENS = {}  # token -> (username, issued_at)
_USED = set()  # tokens that have already been redeemed


class InvalidToken(Exception):
    pass


class TokenExpired(InvalidToken):
    pass


class TokenUsed(InvalidToken):
    pass


def issue_reset_token(username, now=None):
    """Create a reset token for username, issued at now (Unix seconds)."""
    if now is None:
        now = time.time()
    token = secrets.token_urlsafe(16)
    _TOKENS[token] = (username, now)
    return token


def redeem_reset_token(token, now=None):
    """Return the username a token was issued for and mark it used.

    Raises TokenUsed if it was already redeemed, TokenExpired if more than
    TOKEN_TTL_SECONDS have passed since it was issued, and InvalidToken if
    the token is unknown.
    """
    if now is None:
        now = time.time()
    if token in _USED:
        raise TokenUsed("token already used")
    entry = _TOKENS.get(token)
    if entry is None:
        raise InvalidToken("unknown token")
    username, issued_at = entry
    if now - issued_at > TOKEN_TTL_SECONDS:
        raise TokenExpired("token expired")
    del _TOKENS[token]
    _USED.add(token)
    return username

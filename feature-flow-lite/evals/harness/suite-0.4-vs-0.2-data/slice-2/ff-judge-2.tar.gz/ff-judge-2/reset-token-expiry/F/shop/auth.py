"""Password-reset tokens (in-memory store)."""

import secrets
import time

RESET_TOKEN_TTL = 1800  # seconds after issue during which a token can be redeemed

_TOKENS = {}  # token -> (username, issued_at)
_USED = set()  # tokens that have been successfully redeemed


class InvalidToken(Exception):
    pass


class TokenExpired(InvalidToken):
    pass


class TokenUsed(InvalidToken):
    pass


def issue_reset_token(username, now=None):
    """Create a reset token for username, redeemable for RESET_TOKEN_TTL seconds after now."""
    if now is None:
        now = time.time()
    token = secrets.token_urlsafe(16)
    _TOKENS[token] = (username, now)
    return token


def redeem_reset_token(token, now=None):
    """Return the username for a valid token and mark it used.

    Raises TokenUsed if the token was already redeemed (checked before expiry),
    TokenExpired if more than RESET_TOKEN_TTL seconds have passed, and plain
    InvalidToken if the token is unknown. An expired attempt does not use up the token.
    """
    if token not in _TOKENS:
        raise InvalidToken("unknown token")
    if token in _USED:
        raise TokenUsed("token already used")
    username, issued_at = _TOKENS[token]
    if now is None:
        now = time.time()
    if not now - issued_at <= RESET_TOKEN_TTL:
        raise TokenExpired("token expired")
    _USED.add(token)
    return username

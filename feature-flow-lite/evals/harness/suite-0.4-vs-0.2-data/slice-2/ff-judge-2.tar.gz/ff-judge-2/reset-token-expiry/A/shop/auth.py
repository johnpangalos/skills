"""Password-reset tokens (in-memory store)."""

import secrets
import time

TOKEN_LIFETIME = 1800  # seconds after issue

_TOKENS = {}  # token -> {"username", "issued_at", "used"}


class InvalidToken(Exception):
    pass


class TokenExpired(InvalidToken):
    pass


class TokenUsed(InvalidToken):
    pass


def issue_reset_token(username, now=None):
    """Create a reset token for username, issued at Unix time now."""
    if now is None:
        now = time.time()
    token = secrets.token_urlsafe(16)
    _TOKENS[token] = {"username": username, "issued_at": now, "used": False}
    return token


def redeem_reset_token(token, now=None):
    """Return the username a token was issued for, marking it used."""
    if now is None:
        now = time.time()
    entry = _TOKENS.get(token)
    if entry is None:
        raise InvalidToken("unknown token")
    if entry["used"]:
        raise TokenUsed("token already used")
    if now - entry["issued_at"] > TOKEN_LIFETIME:
        raise TokenExpired("token expired")
    entry["used"] = True
    return entry["username"]

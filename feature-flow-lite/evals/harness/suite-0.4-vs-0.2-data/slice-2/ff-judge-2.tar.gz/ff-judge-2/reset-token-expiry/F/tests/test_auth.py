import unittest

from shop.auth import (
    InvalidToken,
    TokenExpired,
    TokenUsed,
    issue_reset_token,
    redeem_reset_token,
)


class ResetTokenTest(unittest.TestCase):
    def test_round_trip(self):
        token = issue_reset_token("ada")
        self.assertEqual(redeem_reset_token(token), "ada")

    def test_unknown_token(self):
        with self.assertRaises(InvalidToken):
            redeem_reset_token("not-a-token")

    def test_default_now_uses_current_time(self):
        token = issue_reset_token("ada")
        self.assertEqual(redeem_reset_token(token), "ada")

    def test_default_now_expires_token_issued_at_zero(self):
        token = issue_reset_token("ada", now=0)
        with self.assertRaises(TokenExpired):
            redeem_reset_token(token)

    def test_nan_now_fails_closed(self):
        token = issue_reset_token("ada", now=0)
        with self.assertRaises(TokenExpired) as cm:
            redeem_reset_token(token, now=float("nan"))
        self.assertEqual(str(cm.exception), "token expired")

    def test_now_zero_is_a_real_timestamp(self):
        token = issue_reset_token("ada", now=0)
        self.assertEqual(redeem_reset_token(token, now=0), "ada")

    def test_redeem_inside_window(self):
        token = issue_reset_token("ada", now=1000)
        self.assertEqual(redeem_reset_token(token, now=2799), "ada")

    def test_redeem_exactly_at_ttl_is_valid(self):
        token = issue_reset_token("ada", now=0)
        self.assertEqual(redeem_reset_token(token, now=1800), "ada")

    def test_redeem_just_past_ttl_expires(self):
        token = issue_reset_token("ada", now=0)
        with self.assertRaises(TokenExpired) as cm:
            redeem_reset_token(token, now=1800.001)
        self.assertEqual(str(cm.exception), "token expired")

    def test_redeem_well_past_ttl_expires(self):
        token = issue_reset_token("ada", now=0)
        with self.assertRaises(TokenExpired):
            redeem_reset_token(token, now=1801)

    def test_reuse_inside_window_raises_token_used(self):
        token = issue_reset_token("ada", now=0)
        self.assertEqual(redeem_reset_token(token, now=1), "ada")
        with self.assertRaises(TokenUsed) as cm:
            redeem_reset_token(token, now=2)
        self.assertEqual(str(cm.exception), "token already used")

    def test_reuse_after_window_raises_token_used_not_expired(self):
        token = issue_reset_token("ada", now=0)
        self.assertEqual(redeem_reset_token(token, now=1), "ada")
        with self.assertRaises(TokenUsed):
            redeem_reset_token(token, now=1801)

    def test_expired_attempt_does_not_consume_token(self):
        token = issue_reset_token("ada", now=0)
        with self.assertRaises(TokenExpired):
            redeem_reset_token(token, now=1801)
        with self.assertRaises(TokenExpired) as cm:
            redeem_reset_token(token, now=1802)
        self.assertEqual(str(cm.exception), "token expired")

    def test_expired_and_used_are_invalid_token(self):
        expired = issue_reset_token("ada", now=0)
        with self.assertRaises(InvalidToken):
            redeem_reset_token(expired, now=1801)
        used = issue_reset_token("ada", now=0)
        redeem_reset_token(used, now=1)
        with self.assertRaises(InvalidToken):
            redeem_reset_token(used, now=2)

    def test_unknown_tokens_are_neither_expired_nor_used(self):
        for token in ["", "never-issued"]:
            with self.subTest(token=token):
                with self.assertRaises(InvalidToken) as cm:
                    redeem_reset_token(token, now=0)
                self.assertNotIsInstance(cm.exception, (TokenExpired, TokenUsed))
                self.assertEqual(str(cm.exception), "unknown token")

    def test_tokens_for_same_user_are_independent(self):
        first = issue_reset_token("ada", now=0)
        second = issue_reset_token("ada", now=0)
        self.assertEqual(redeem_reset_token(first, now=1), "ada")
        self.assertEqual(redeem_reset_token(second, now=1800), "ada")
        with self.assertRaises(TokenUsed):
            redeem_reset_token(first, now=1800)

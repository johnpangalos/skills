import unittest
from unittest import mock

from shop.auth import (
    InvalidToken,
    TokenExpired,
    TokenUsed,
    issue_reset_token,
    redeem_reset_token,
)


class ResetTokenTest(unittest.TestCase):
    def test_round_trip(self):
        token = issue_reset_token("ada")
        self.assertEqual(redeem_reset_token(token), "ada")

    def test_unknown_token(self):
        with self.assertRaises(InvalidToken):
            redeem_reset_token("not-a-token")

    def test_valid_at_exactly_ttl(self):
        token = issue_reset_token("ada", now=1000)
        self.assertEqual(redeem_reset_token(token, now=2800), "ada")

    def test_expired_after_ttl(self):
        token = issue_reset_token("ada", now=1000)
        with self.assertRaises(TokenExpired):
            redeem_reset_token(token, now=2800.5)

    def test_now_zero_is_not_treated_as_default(self):
        token = issue_reset_token("ada", now=0)
        with self.assertRaises(TokenExpired):
            redeem_reset_token(token, now=1801)

    def test_now_defaults_to_time_time(self):
        with mock.patch("shop.auth.time.time", return_value=1000.0):
            token = issue_reset_token("ada")
        with mock.patch("shop.auth.time.time", return_value=2801.0):
            with self.assertRaises(TokenExpired):
                redeem_reset_token(token)

    def test_single_use(self):
        token = issue_reset_token("ada", now=1000)
        self.assertEqual(redeem_reset_token(token, now=1001), "ada")
        with self.assertRaises(TokenUsed):
            redeem_reset_token(token, now=1002)

    def test_used_wins_over_expired(self):
        token = issue_reset_token("ada", now=1000)
        redeem_reset_token(token, now=1001)
        with self.assertRaises(TokenUsed):
            redeem_reset_token(token, now=9999)

    def test_expired_attempt_does_not_consume_other_tokens(self):
        a = issue_reset_token("ada", now=1000)
        b = issue_reset_token("bob", now=2000)
        with self.assertRaises(TokenExpired):
            redeem_reset_token(a, now=3000)
        self.assertEqual(redeem_reset_token(b, now=3000), "bob")

    def test_subclasses(self):
        self.assertTrue(issubclass(TokenExpired, InvalidToken))
        self.assertTrue(issubclass(TokenUsed, InvalidToken))
        token = issue_reset_token("ada", now=0)
        redeem_reset_token(token, now=1)
        with self.assertRaises(InvalidToken):
            redeem_reset_token(token, now=2)

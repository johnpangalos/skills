import unittest

from shop import auth
from shop.auth import (
    InvalidToken,
    TokenExpired,
    TokenUsed,
    issue_reset_token,
    redeem_reset_token,
)


class ResetTokenTest(unittest.TestCase):
    def setUp(self):
        auth._TOKENS.clear()

    def test_round_trip(self):
        token = issue_reset_token("ada")
        self.assertEqual(redeem_reset_token(token), "ada")

    def test_default_now_round_trip(self):
        self.assertEqual(redeem_reset_token(issue_reset_token("ada")), "ada")

    def test_unknown_token(self):
        with self.assertRaises(InvalidToken):
            redeem_reset_token("not-a-token")

    def test_unknown_token_is_plain_invalid_token(self):
        for bad in ("", "not-a-token", None):
            with self.subTest(token=bad):
                with self.assertRaises(InvalidToken) as cm:
                    redeem_reset_token(bad)
                self.assertIs(type(cm.exception), InvalidToken)
                self.assertEqual(str(cm.exception), "unknown token")

    def test_zero_timestamp_is_honored(self):
        token = issue_reset_token("ada", now=0)
        self.assertEqual(redeem_reset_token(token, now=1800), "ada")
        token = issue_reset_token("ada", now=0)
        with self.assertRaises(TokenExpired):
            redeem_reset_token(token, now=1801)

    def test_float_timestamps(self):
        token = issue_reset_token("ada", now=100.5)
        self.assertEqual(redeem_reset_token(token, now=1900.5), "ada")
        token = issue_reset_token("ada", now=100.5)
        with self.assertRaises(TokenExpired):
            redeem_reset_token(token, now=1900.6)

    def test_exact_boundary_succeeds(self):
        token = issue_reset_token("ada", now=1000)
        self.assertEqual(redeem_reset_token(token, now=2800), "ada")

    def test_just_past_boundary_expires(self):
        token = issue_reset_token("ada", now=1000)
        with self.assertRaises(TokenExpired) as cm:
            redeem_reset_token(token, now=2800.001)
        self.assertEqual(str(cm.exception), "token expired")

    def test_well_past_boundary_expires(self):
        token = issue_reset_token("ada", now=1000)
        with self.assertRaises(TokenExpired):
            redeem_reset_token(token, now=2801)

    def test_redeem_before_issue_does_not_expire(self):
        token = issue_reset_token("ada", now=1000)
        self.assertEqual(redeem_reset_token(token, now=500), "ada")

    def test_second_redeem_is_used(self):
        token = issue_reset_token("ada", now=1000)
        self.assertEqual(redeem_reset_token(token, now=1001), "ada")
        with self.assertRaises(TokenUsed) as cm:
            redeem_reset_token(token, now=1002)
        self.assertEqual(str(cm.exception), "token already used")

    def test_used_takes_precedence_over_expiry(self):
        token = issue_reset_token("ada", now=1000)
        self.assertEqual(redeem_reset_token(token, now=1001), "ada")
        with self.assertRaises(TokenUsed):
            redeem_reset_token(token, now=5000)

    def test_expired_redeem_does_not_consume_token(self):
        token = issue_reset_token("ada", now=1000)
        with self.assertRaises(TokenExpired):
            redeem_reset_token(token, now=3000)
        with self.assertRaises(TokenExpired):
            redeem_reset_token(token, now=3001)

    def test_tokens_for_same_user_are_independent(self):
        first = issue_reset_token("ada", now=1000)
        second = issue_reset_token("ada", now=1000)
        self.assertEqual(redeem_reset_token(first, now=1001), "ada")
        self.assertEqual(redeem_reset_token(second, now=1002), "ada")

    def test_subclasses_of_invalid_token(self):
        self.assertTrue(issubclass(TokenExpired, InvalidToken))
        self.assertTrue(issubclass(TokenUsed, InvalidToken))
        expired = issue_reset_token("ada", now=1000)
        with self.assertRaises(InvalidToken) as cm:
            redeem_reset_token(expired, now=3000)
        self.assertIs(type(cm.exception), TokenExpired)
        used = issue_reset_token("ada", now=1000)
        redeem_reset_token(used, now=1001)
        with self.assertRaises(InvalidToken) as cm:
            redeem_reset_token(used, now=1002)
        self.assertIs(type(cm.exception), TokenUsed)

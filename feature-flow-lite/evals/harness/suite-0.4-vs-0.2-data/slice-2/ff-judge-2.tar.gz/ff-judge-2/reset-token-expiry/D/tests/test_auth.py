import unittest
from unittest import mock

from shop.auth import (
    InvalidToken,
    TokenExpired,
    TokenUsed,
    issue_reset_token,
    redeem_reset_token,
)


class ResetTokenTest(unittest.TestCase):
    def test_round_trip(self):
        token = issue_reset_token("ada")
        self.assertEqual(redeem_reset_token(token), "ada")

    def test_unknown_token(self):
        with self.assertRaises(InvalidToken) as cm:
            redeem_reset_token("not-a-token")
        self.assertIs(type(cm.exception), InvalidToken)

    def test_empty_and_none_tokens_are_invalid(self):
        for bad in ("", None):
            with self.subTest(token=bad):
                with self.assertRaises(InvalidToken) as cm:
                    redeem_reset_token(bad)
                self.assertIs(type(cm.exception), InvalidToken)

    def test_error_classes_subclass_invalid_token(self):
        self.assertTrue(issubclass(TokenExpired, InvalidToken))
        self.assertTrue(issubclass(TokenUsed, InvalidToken))

    def test_redeem_within_window(self):
        token = issue_reset_token("ada", now=1000)
        self.assertEqual(redeem_reset_token(token, now=2000), "ada")

    def test_exactly_1800_seconds_is_still_valid(self):
        token = issue_reset_token("ada", now=1000)
        self.assertEqual(redeem_reset_token(token, now=2800), "ada")

    def test_just_over_1800_seconds_is_expired(self):
        token = issue_reset_token("ada", now=1000)
        with self.assertRaises(TokenExpired) as cm:
            redeem_reset_token(token, now=2800.001)
        self.assertIs(type(cm.exception), TokenExpired)

    def test_now_zero_is_a_real_timestamp(self):
        token = issue_reset_token("ada", now=0)
        with self.assertRaises(TokenExpired):
            redeem_reset_token(token, now=1800.5)

    def test_now_zero_redeem_is_a_real_timestamp(self):
        token = issue_reset_token("ada", now=0)
        self.assertEqual(redeem_reset_token(token, now=0), "ada")

    def test_float_timestamps(self):
        token = issue_reset_token("ada", now=100.5)
        self.assertEqual(redeem_reset_token(token, now=1900.5), "ada")
        token = issue_reset_token("ada", now=100.5)
        with self.assertRaises(TokenExpired):
            redeem_reset_token(token, now=1900.6)

    def test_default_now_uses_time_at_call_time(self):
        with mock.patch("shop.auth.time.time", return_value=1000.0):
            token = issue_reset_token("ada")
        with mock.patch("shop.auth.time.time", return_value=2800.001):
            with self.assertRaises(TokenExpired):
                redeem_reset_token(token)

    def test_default_now_within_window(self):
        with mock.patch("shop.auth.time.time", return_value=1000.0):
            token = issue_reset_token("ada")
        with mock.patch("shop.auth.time.time", return_value=1500.0):
            self.assertEqual(redeem_reset_token(token), "ada")

    def test_second_redeem_is_used(self):
        token = issue_reset_token("ada", now=1000)
        redeem_reset_token(token, now=1001)
        with self.assertRaises(TokenUsed) as cm:
            redeem_reset_token(token, now=1002)
        self.assertIs(type(cm.exception), TokenUsed)

    def test_used_beats_expired(self):
        token = issue_reset_token("ada", now=0)
        redeem_reset_token(token, now=0)
        with self.assertRaises(TokenUsed):
            redeem_reset_token(token, now=5000)

    def test_expired_attempt_does_not_consume_token(self):
        token = issue_reset_token("ada", now=0)
        with self.assertRaises(TokenExpired):
            redeem_reset_token(token, now=2000)
        with self.assertRaises(TokenExpired):
            redeem_reset_token(token, now=2001)

    def test_existing_call_signatures_still_work(self):
        token = issue_reset_token("ada")
        self.assertEqual(redeem_reset_token(token), "ada")


if __name__ == "__main__":
    unittest.main()

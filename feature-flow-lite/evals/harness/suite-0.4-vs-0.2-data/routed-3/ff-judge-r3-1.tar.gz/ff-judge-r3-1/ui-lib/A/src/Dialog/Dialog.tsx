import {
  useEffect,
  useId,
  useLayoutEffect,
  useRef,
  type ComponentPropsWithoutRef,
  type MouseEvent as ReactMouseEvent,
  type ReactNode,
} from "react";
import { createPortal } from "react-dom";

export type DialogProps = Omit<ComponentPropsWithoutRef<"div">, "title"> & {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  title: ReactNode;
  description?: ReactNode;
  overlayClassName?: string;
};

// Disabled and tabindex="-1" elements are not tabbable, so they are excluded from the focus trap.
const TABBABLE_SELECTOR = [
  "a[href]",
  "button",
  "input:not([type='hidden'])",
  "select",
  "textarea",
  "[tabindex]",
]
  .map((selector) => `${selector}:not([disabled]):not([tabindex^='-'])`)
  .join(", ");

// Elements inside a hidden or inert ancestor cannot receive focus, so they are skipped as well.
function tabbables(panel: HTMLElement): HTMLElement[] {
  return Array.from(panel.querySelectorAll<HTMLElement>(TABBABLE_SELECTOR)).filter(
    (item) => !item.closest("[hidden], [inert]"),
  );
}

// The first tabbable after the active element in DOM order, wrapping to the first. Works when the active element is not tabbable.
function nextTabbable(items: HTMLElement[], active: Element | null): HTMLElement {
  const following = items.find(
    (item) => active !== null && Boolean(active.compareDocumentPosition(item) & Node.DOCUMENT_POSITION_FOLLOWING),
  );
  return following ?? items[0];
}

// The last tabbable before the active element in DOM order, wrapping to the last.
function previousTabbable(items: HTMLElement[], active: Element | null): HTMLElement {
  const preceding = [...items]
    .reverse()
    .find((item) => active !== null && Boolean(active.compareDocumentPosition(item) & Node.DOCUMENT_POSITION_PRECEDING));
  return preceding ?? items[items.length - 1];
}

// Tab is always handled here, so focus never falls through to <body> from a non-tabbable element at the end of the panel.
function trapFocus(event: KeyboardEvent, panel: HTMLElement) {
  event.preventDefault();
  const items = tabbables(panel);
  if (items.length === 0) {
    panel.focus();
    return;
  }
  const active = document.activeElement;
  (event.shiftKey ? previousTabbable(items, active) : nextTabbable(items, active)).focus();
}

type DialogPanelProps = Omit<DialogProps, "open">;

function DialogPanel({ onOpenChange, title, description, overlayClassName, children, ...rest }: DialogPanelProps) {
  const titleId = useId();
  const descriptionId = useId();
  const panelRef = useRef<HTMLDivElement>(null);
  const pressedOnBackdrop = useRef(false);
  const hasDescription = description !== undefined && description !== null;

  // Runs on mount and unmount, so it covers open becoming false as well as unmounting while open.
  useLayoutEffect(() => {
    const opener = document.activeElement;
    const panel = panelRef.current;
    if (panel) (tabbables(panel)[0] ?? panel).focus();
    return () => {
      if (opener instanceof HTMLElement && opener.isConnected) opener.focus();
    };
  }, []);

  useEffect(() => {
    const onKeyDown = (event: KeyboardEvent) => {
      const panel = panelRef.current;
      if (event.key === "Escape" && !event.defaultPrevented) {
        onOpenChange(false);
      } else if (event.key === "Tab" && panel) {
        trapFocus(event, panel);
      }
    };
    document.addEventListener("keydown", onKeyDown);
    return () => document.removeEventListener("keydown", onKeyDown);
  }, [onOpenChange]);

  // A click only dismisses when the press started on the backdrop, was released on it, and the click landed on it.
  // The browser fires click on the common ancestor, so the release check is what rules out a press that started outside.
  const onOverlayMouseDown = (event: ReactMouseEvent<HTMLDivElement>) => {
    pressedOnBackdrop.current = event.target === event.currentTarget;
  };

  const onOverlayMouseUp = (event: ReactMouseEvent<HTMLDivElement>) => {
    pressedOnBackdrop.current = pressedOnBackdrop.current && event.target === event.currentTarget;
  };

  const onOverlayClick = (event: ReactMouseEvent<HTMLDivElement>) => {
    const dismiss = pressedOnBackdrop.current && event.target === event.currentTarget;
    pressedOnBackdrop.current = false;
    if (dismiss) onOpenChange(false);
  };

  return (
    <div
      className={overlayClassName}
      onMouseDown={onOverlayMouseDown}
      onMouseUp={onOverlayMouseUp}
      onClick={onOverlayClick}
    >
      <div
        {...rest}
        ref={panelRef}
        role="dialog"
        aria-modal="true"
        aria-labelledby={titleId}
        aria-describedby={hasDescription ? descriptionId : undefined}
        tabIndex={-1}
      >
        <h2 id={titleId}>{title}</h2>
        {hasDescription && <p id={descriptionId}>{description}</p>}
        {children}
      </div>
    </div>
  );
}

export function Dialog({ open, ...rest }: DialogProps) {
  if (!open) return null;
  return createPortal(<DialogPanel {...rest} />, document.body);
}

import { useState } from "react";
import { render, screen } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { Combobox, type ComboboxOption } from "./Combobox";

const fruits: ComboboxOption[] = [
  { value: "apple", label: "Apple" },
  { value: "banana", label: "Banana", disabled: true },
  { value: "cherry", label: "Cherry" },
  { value: "blueberry", label: "Blueberry" },
];

function Harness({ options = fruits, initial = null }: { options?: ComboboxOption[]; initial?: string | null }) {
  const [value, setValue] = useState<string | null>(initial);
  return (
    <form onSubmit={(event) => event.preventDefault()}>
      <Combobox label="Fruit" options={options} value={value} onChange={setValue} placeholder="Pick" />
      <button type="submit">Submit</button>
    </form>
  );
}

function getInput() {
  return screen.getByRole("combobox", { name: "Fruit" });
}

describe("Combobox markup", () => {
  it("renders a labelled combobox wired to a listbox", () => {
    render(<Harness />);
    const input = getInput();
    expect(input).toHaveAttribute("aria-autocomplete", "list");
    expect(input).toHaveAttribute("aria-expanded", "false");
    expect(input).toHaveAttribute("placeholder", "Pick");
    expect(input).not.toHaveAttribute("aria-activedescendant");
    const listbox = document.getElementById(input.getAttribute("aria-controls")!);
    expect(listbox).toHaveAttribute("role", "listbox");
    expect(listbox).toHaveAttribute("hidden");
  });

  it("renders options with aria-selected and aria-disabled, and unique ids", async () => {
    const user = userEvent.setup();
    render(<Harness initial="cherry" />);
    await user.click(getInput());
    expect(screen.getByRole("listbox", { name: "Fruit" })).toBeInTheDocument();
    expect(screen.getByRole("option", { name: "Cherry" })).toHaveAttribute("aria-selected", "true");
    expect(screen.getByRole("option", { name: "Apple" })).toHaveAttribute("aria-selected", "false");
    expect(screen.getByRole("option", { name: "Banana" })).toHaveAttribute("aria-disabled", "true");
    const ids = screen.getAllByRole("option").map((option) => option.id);
    expect(new Set(ids).size).toBe(ids.length);
  });

  it("gives two instances distinct ids", () => {
    render(
      <>
        <Harness />
        <Harness />
      </>,
    );
    const inputs = screen.getAllByRole("combobox");
    expect(inputs[0].id).not.toBe(inputs[1].id);
  });

  it("forwards className and native props to the input", () => {
    render(<Combobox label="Fruit" options={fruits} value={null} onChange={() => {}} className="field" data-testid="cb" />);
    expect(screen.getByTestId("cb")).toHaveClass("field");
    expect(screen.getByTestId("cb")).toBe(getInput());
  });
});

describe("Combobox filtering and value text", () => {
  it("opens and filters case-insensitively by substring when typing", async () => {
    const user = userEvent.setup();
    render(<Harness />);
    await user.type(getInput(), "BERR");
    expect(getInput()).toHaveAttribute("aria-expanded", "true");
    expect(screen.getAllByRole("option").map((o) => o.textContent)).toEqual(["Blueberry"]);
  });

  it("shows all options again when the input is cleared", async () => {
    const user = userEvent.setup();
    render(<Harness />);
    await user.type(getInput(), "ch");
    expect(screen.getAllByRole("option")).toHaveLength(1);
    await user.clear(getInput());
    expect(screen.getAllByRole("option")).toHaveLength(fruits.length);
  });

  it("shows the selected label when not editing and updates it when value changes from the parent", async () => {
    const user = userEvent.setup();
    function Parent() {
      const [value, setValue] = useState<string | null>("apple");
      return (
        <>
          <Combobox label="Fruit" options={fruits} value={value} onChange={setValue} />
          <button type="button" onClick={() => setValue("cherry")}>
            Set cherry
          </button>
          <button type="button" onClick={() => setValue(null)}>
            Clear
          </button>
        </>
      );
    }
    render(<Parent />);
    expect(getInput()).toHaveValue("Apple");
    await user.click(screen.getByRole("button", { name: "Set cherry" }));
    expect(getInput()).toHaveValue("Cherry");
  });

  it("treats regex metacharacters in the query literally", async () => {
    const user = userEvent.setup();
    const options: ComboboxOption[] = [
      { value: "1", label: "Price (USD)" },
      { value: "2", label: "Any.thing" },
      { value: "3", label: "Plain" },
    ];
    render(<Harness options={options} />);
    await user.type(getInput(), "(");
    expect(screen.getAllByRole("option").map((o) => o.textContent)).toEqual(["Price (USD)"]);
    await user.clear(getInput());
    await user.type(getInput(), ".");
    expect(screen.getAllByRole("option").map((o) => o.textContent)).toEqual(["Any.thing"]);
    await user.clear(getInput());
    await user.type(getInput(), "[[");
    expect(screen.queryAllByRole("option")).toHaveLength(0);
    expect(screen.getByText("No results")).toBeInTheDocument();
  });

  it("trims leading and trailing whitespace from the query", async () => {
    const user = userEvent.setup();
    render(<Harness />);
    await user.type(getInput(), "  apple  ");
    expect(screen.getAllByRole("option").map((o) => o.textContent)).toEqual(["Apple"]);
  });

  it("handles an option with an empty label", async () => {
    const user = userEvent.setup();
    render(<Harness options={[{ value: "none", label: "" }, { value: "a", label: "Apple" }]} />);
    await user.type(getInput(), "app");
    expect(screen.getAllByRole("option").map((o) => o.textContent)).toEqual(["Apple"]);
  });

  it("shows an empty input for a value that matches no option", () => {
    render(<Harness initial="does-not-exist" />);
    expect(getInput()).toHaveValue("");
  });
});

describe("Combobox keyboard", () => {
  it("opens with ArrowDown and moves the active option with aria-activedescendant", async () => {
    const user = userEvent.setup();
    render(<Harness />);
    await user.click(getInput());
    await user.keyboard("{Escape}");
    expect(getInput()).toHaveAttribute("aria-expanded", "false");
    await user.keyboard("{ArrowDown}");
    expect(getInput()).toHaveAttribute("aria-expanded", "true");
    expect(getInput()).toHaveFocus();
    expect(getInput()).not.toHaveAttribute("aria-activedescendant");
    await user.keyboard("{ArrowDown}");
    expect(getInput()).toHaveAttribute(
      "aria-activedescendant",
      screen.getByRole("option", { name: "Apple" }).id,
    );
    await user.keyboard("{ArrowDown}");
    expect(getInput()).toHaveAttribute(
      "aria-activedescendant",
      screen.getByRole("option", { name: "Cherry" }).id,
    );
  });

  it("skips disabled options and wraps at both ends", async () => {
    const user = userEvent.setup();
    render(<Harness />);
    await user.click(getInput());
    await user.keyboard("{ArrowUp}");
    expect(getInput()).toHaveAttribute("aria-activedescendant", screen.getByRole("option", { name: "Blueberry" }).id);
    await user.keyboard("{ArrowDown}");
    expect(getInput()).toHaveAttribute("aria-activedescendant", screen.getByRole("option", { name: "Apple" }).id);
    await user.keyboard("{ArrowUp}");
    expect(getInput()).toHaveAttribute("aria-activedescendant", screen.getByRole("option", { name: "Blueberry" }).id);
    expect(getInput()).toHaveFocus();
  });

  it("does not use aria-selected to mark the active option", async () => {
    const user = userEvent.setup();
    render(<Harness />);
    await user.click(getInput());
    await user.keyboard("{ArrowDown}");
    expect(screen.getByRole("option", { name: "Apple" })).toHaveAttribute("aria-selected", "false");
    expect(screen.getByRole("option", { name: "Apple" })).toHaveAttribute("data-active");
  });

  it("chooses the active option on Enter, closes, and sets the label", async () => {
    const user = userEvent.setup();
    const onChange = vi.fn();
    render(<Combobox label="Fruit" options={fruits} value={null} onChange={onChange} />);
    await user.click(getInput());
    await user.keyboard("{ArrowDown}{Enter}");
    expect(onChange).toHaveBeenCalledTimes(1);
    expect(onChange).toHaveBeenCalledWith("apple");
    expect(getInput()).toHaveAttribute("aria-expanded", "false");
  });

  it("sets the input text to the chosen label when the parent updates value", async () => {
    const user = userEvent.setup();
    render(<Harness />);
    await user.click(getInput());
    await user.keyboard("{ArrowDown}{Enter}");
    expect(getInput()).toHaveValue("Apple");
  });

  it("does nothing on Enter with no active option and does not submit the form", async () => {
    const user = userEvent.setup();
    const onChange = vi.fn();
    const onSubmit = vi.fn((event: { preventDefault: () => void }) => event.preventDefault());
    render(
      <form onSubmit={onSubmit}>
        <Combobox label="Fruit" options={fruits} value={null} onChange={onChange} />
      </form>,
    );
    await user.click(getInput());
    await user.keyboard("{Enter}");
    expect(onChange).not.toHaveBeenCalled();
    expect(onSubmit).not.toHaveBeenCalled();
    expect(getInput()).toHaveAttribute("aria-expanded", "true");
  });

  it("lets Enter behave natively when the listbox is closed", async () => {
    const user = userEvent.setup();
    const onSubmit = vi.fn((event: { preventDefault: () => void }) => event.preventDefault());
    render(
      <form onSubmit={onSubmit}>
        <Combobox label="Fruit" options={fruits} value={null} onChange={() => {}} />
      </form>,
    );
    getInput().focus();
    await user.keyboard("{Enter}");
    expect(onSubmit).toHaveBeenCalledTimes(1);
  });

  it("does nothing when all filtered options are disabled", async () => {
    const user = userEvent.setup();
    const onChange = vi.fn();
    render(
      <Combobox
        label="Fruit"
        options={[{ value: "b", label: "Banana", disabled: true }]}
        value={null}
        onChange={onChange}
      />,
    );
    await user.click(getInput());
    await user.keyboard("{ArrowDown}{Enter}");
    expect(getInput()).not.toHaveAttribute("aria-activedescendant");
    expect(onChange).not.toHaveBeenCalled();
  });

  it("resets the active option when the filter removes it", async () => {
    const user = userEvent.setup();
    render(<Harness />);
    await user.click(getInput());
    await user.keyboard("{ArrowDown}{ArrowDown}");
    expect(getInput()).toHaveAttribute("aria-activedescendant");
    await user.type(getInput(), "z");
    expect(getInput()).not.toHaveAttribute("aria-activedescendant");
  });

  it("keeps the only option active when there is a single option", async () => {
    const user = userEvent.setup();
    render(<Harness options={[{ value: "a", label: "Apple" }]} />);
    await user.click(getInput());
    await user.keyboard("{ArrowDown}{ArrowDown}{ArrowUp}");
    expect(getInput()).toHaveAttribute("aria-activedescendant", screen.getByRole("option", { name: "Apple" }).id);
  });
});

describe("Combobox mouse, escape and blur", () => {
  it("chooses an enabled option on click and keeps focus in the input", async () => {
    const user = userEvent.setup();
    const onChange = vi.fn();
    render(<Combobox label="Fruit" options={fruits} value={null} onChange={onChange} />);
    await user.click(getInput());
    await user.click(screen.getByRole("option", { name: "Cherry" }));
    expect(onChange).toHaveBeenCalledWith("cherry");
    expect(getInput()).toHaveAttribute("aria-expanded", "false");
  });

  it("ignores clicks on disabled options", async () => {
    const user = userEvent.setup();
    const onChange = vi.fn();
    render(<Combobox label="Fruit" options={fruits} value={null} onChange={onChange} />);
    await user.click(getInput());
    await user.click(screen.getByRole("option", { name: "Banana" }));
    expect(onChange).not.toHaveBeenCalled();
    expect(getInput()).toHaveAttribute("aria-expanded", "true");
  });

  it("closes on Escape without calling onChange and restores the selected label", async () => {
    const user = userEvent.setup();
    const onChange = vi.fn();
    function Parent() {
      const [value, setValue] = useState<string | null>("apple");
      return (
        <Combobox
          label="Fruit"
          options={fruits}
          value={value}
          onChange={(next) => {
            onChange(next);
            setValue(next);
          }}
        />
      );
    }
    render(<Parent />);
    await user.clear(getInput());
    await user.type(getInput(), "ban");
    await user.keyboard("{Escape}");
    expect(onChange).not.toHaveBeenCalled();
    expect(getInput()).toHaveAttribute("aria-expanded", "false");
    expect(getInput()).toHaveValue("Apple");
  });

  it("stops Escape from reaching an enclosing dialog while the listbox is open", async () => {
    const user = userEvent.setup();
    const onDocumentKeyDown = vi.fn();
    document.addEventListener("keydown", onDocumentKeyDown);
    render(<Harness />);
    await user.click(getInput());
    await user.keyboard("{Escape}");
    expect(onDocumentKeyDown).not.toHaveBeenCalled();
    document.removeEventListener("keydown", onDocumentKeyDown);
  });

  it("closes on blur without calling onChange and restores the selected label", async () => {
    const user = userEvent.setup();
    const onChange = vi.fn();
    render(
      <>
        <Combobox label="Fruit" options={fruits} value="cherry" onChange={onChange} />
        <button type="button">Elsewhere</button>
      </>,
    );
    await user.clear(getInput());
    await user.type(getInput(), "app");
    await user.click(screen.getByRole("button", { name: "Elsewhere" }));
    expect(onChange).not.toHaveBeenCalled();
    expect(getInput()).toHaveAttribute("aria-expanded", "false");
    expect(getInput()).toHaveValue("Cherry");
  });

  it("shows the parent's value label after blur when the parent ignores onChange", async () => {
    const user = userEvent.setup();
    const onChange = vi.fn();
    render(
      <>
        <Combobox label="Fruit" options={fruits} value="apple" onChange={onChange} />
        <button type="button">Elsewhere</button>
      </>,
    );
    await user.click(getInput());
    await user.click(screen.getByRole("option", { name: "Cherry" }));
    expect(onChange).toHaveBeenCalledWith("cherry");
    expect(getInput()).toHaveValue("Apple");
  });

  it("does not call onChange when the text is cleared", async () => {
    const user = userEvent.setup();
    const onChange = vi.fn();
    render(<Combobox label="Fruit" options={fruits} value="apple" onChange={onChange} />);
    await user.clear(getInput());
    await user.tab();
    expect(onChange).not.toHaveBeenCalled();
    expect(getInput()).toHaveValue("Apple");
  });
});

describe("Combobox regressions", () => {
  it("drops typed text when the parent changes value while the user is editing", async () => {
    const user = userEvent.setup();
    const onChange = vi.fn();
    const { rerender } = render(<Combobox label="Fruit" options={fruits} value={null} onChange={onChange} />);
    await user.type(getInput(), "ch");
    expect(getInput()).toHaveValue("ch");
    rerender(<Combobox label="Fruit" options={fruits} value="apple" onChange={onChange} />);
    expect(getInput()).toHaveValue("Apple");
    expect(onChange).not.toHaveBeenCalled();
  });

  it("clears the active option when it leaves the list, so it is not chosen when it returns", async () => {
    const user = userEvent.setup();
    const onChange = vi.fn();
    const { rerender } = render(<Combobox label="Fruit" options={fruits} value={null} onChange={onChange} />);
    await user.click(getInput());
    await user.keyboard("{ArrowDown}");
    expect(getInput()).toHaveAttribute("aria-activedescendant", screen.getByRole("option", { name: "Apple" }).id);
    rerender(<Combobox label="Fruit" options={fruits.slice(1)} value={null} onChange={onChange} />);
    rerender(<Combobox label="Fruit" options={fruits} value={null} onChange={onChange} />);
    expect(getInput()).not.toHaveAttribute("aria-activedescendant");
    await user.keyboard("{Enter}");
    expect(onChange).not.toHaveBeenCalled();
  });

  it("renders the no-results message outside the listbox, which stays empty", async () => {
    const user = userEvent.setup();
    render(<Harness />);
    await user.type(getInput(), "zzz");
    const listbox = screen.getByRole("listbox", { name: "Fruit" });
    expect(screen.getByText("No results")).toBeInTheDocument();
    expect(listbox).toBeEmptyDOMElement();
    expect(listbox).toHaveAttribute("id", getInput().getAttribute("aria-controls"));
    expect(screen.queryByRole("option")).toBeNull();
    expect(getInput()).not.toHaveAttribute("aria-activedescendant");
  });
});

import { useState } from "react";
import { render, screen, waitFor } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { Dialog } from "./Dialog";

function Harness({ initialOpen = false, description }: { initialOpen?: boolean; description?: string }) {
  const [open, setOpen] = useState(initialOpen);
  return (
    <>
      <button type="button" onClick={() => setOpen(true)}>
        Open
      </button>
      <Dialog open={open} onOpenChange={setOpen} title="Confirm" description={description}>
        <input aria-label="Name" />
        <button type="button">Save</button>
      </Dialog>
    </>
  );
}

describe("Dialog rendering", () => {
  it("renders nothing when closed", () => {
    render(<Dialog open={false} onOpenChange={() => {}} title="Confirm" />);
    expect(screen.queryByRole("dialog")).toBeNull();
    expect(document.querySelector("[data-backdrop]")).toBeNull();
  });

  it("renders a modal dialog labelled by its title in a portal on document.body", () => {
    const { container } = render(<Dialog open onOpenChange={() => {}} title="Confirm">Body</Dialog>);
    const dialog = screen.getByRole("dialog", { name: "Confirm" });
    expect(dialog).toHaveAttribute("aria-modal", "true");
    expect(dialog.parentElement).toBe(document.body);
    expect(container).toBeEmptyDOMElement();
    expect(screen.getByRole("heading", { level: 2, name: "Confirm" })).toBeInTheDocument();
    expect(document.querySelector("[data-backdrop]")).not.toBeNull();
  });

  it("sets aria-describedby only when a description is given", () => {
    const { unmount } = render(<Dialog open onOpenChange={() => {}} title="Confirm" description="Are you sure?" />);
    const dialog = screen.getByRole("dialog");
    expect(dialog).toHaveAttribute("aria-describedby");
    expect(document.getElementById(dialog.getAttribute("aria-describedby")!)).toHaveTextContent("Are you sure?");
    unmount();
    render(<Dialog open onOpenChange={() => {}} title="Confirm" />);
    expect(screen.getByRole("dialog")).not.toHaveAttribute("aria-describedby");
  });

  it("forwards className and native props to the dialog element", () => {
    render(<Dialog open onOpenChange={() => {}} title="Confirm" className="panel" data-testid="dlg" />);
    expect(screen.getByTestId("dlg")).toHaveClass("panel");
    expect(screen.getByTestId("dlg")).toBe(screen.getByRole("dialog"));
  });
});

describe("Dialog focus", () => {
  it("moves focus to the first focusable element on open and back to the opener on close", async () => {
    const user = userEvent.setup();
    render(<Harness />);
    const opener = screen.getByRole("button", { name: "Open" });
    await user.click(opener);
    expect(screen.getByRole("textbox", { name: "Name" })).toHaveFocus();
    await user.keyboard("{Escape}");
    expect(screen.queryByRole("dialog")).toBeNull();
    expect(opener).toHaveFocus();
  });

  it("focuses the dialog container when it has no focusable elements", () => {
    render(<Dialog open onOpenChange={() => {}} title="Confirm">Just text</Dialog>);
    expect(screen.getByRole("dialog")).toHaveFocus();
    expect(screen.getByRole("dialog")).toHaveAttribute("tabindex", "-1");
  });

  it("does not count disabled controls or tabindex -1 as focusable", () => {
    render(
      <Dialog open onOpenChange={() => {}} title="Confirm">
        <button type="button" disabled>
          Nope
        </button>
        <button type="button" tabIndex={-1}>
          Skip
        </button>
        <button type="button">Yes</button>
      </Dialog>,
    );
    expect(screen.getByRole("button", { name: "Yes" })).toHaveFocus();
  });

  it("focuses a visibility:visible child inside a visibility:hidden parent", () => {
    render(
      <Dialog open onOpenChange={() => {}} title="Confirm">
        <div style={{ visibility: "hidden" }}>
          <button type="button" style={{ visibility: "visible" }}>
            Inner
          </button>
        </div>
        <button type="button">Outer</button>
      </Dialog>,
    );
    expect(screen.getByRole("button", { name: "Inner" })).toHaveFocus();
  });

  it("wraps Tab over a visibility:visible child inside a visibility:hidden parent", async () => {
    const user = userEvent.setup();
    render(
      <Dialog open onOpenChange={() => {}} title="Confirm">
        <div style={{ visibility: "hidden" }}>
          <button type="button" style={{ visibility: "visible" }}>
            Inner
          </button>
        </div>
        <button type="button">Outer</button>
      </Dialog>,
    );
    expect(screen.getByRole("button", { name: "Inner" })).toHaveFocus();
    await user.tab();
    expect(screen.getByRole("button", { name: "Outer" })).toHaveFocus();
    await user.tab();
    expect(screen.getByRole("button", { name: "Inner" })).toHaveFocus();
  });

  it("wraps Tab from the last focusable element to the first", async () => {
    const user = userEvent.setup();
    render(<Harness initialOpen />);
    const name = screen.getByRole("textbox", { name: "Name" });
    const save = screen.getByRole("button", { name: "Save" });
    save.focus();
    await user.tab();
    expect(name).toHaveFocus();
  });

  it("wraps Shift+Tab from the first focusable element to the last", async () => {
    const user = userEvent.setup();
    render(<Harness initialOpen />);
    expect(screen.getByRole("textbox", { name: "Name" })).toHaveFocus();
    await user.tab({ shift: true });
    expect(screen.getByRole("button", { name: "Save" })).toHaveFocus();
  });

  it("keeps focus on the dialog container when Tab is pressed with no focusable children", async () => {
    const user = userEvent.setup();
    render(<Dialog open onOpenChange={() => {}} title="Confirm">Text</Dialog>);
    await user.tab();
    expect(screen.getByRole("dialog")).toHaveFocus();
  });

  it("pulls focus back inside when Tab is pressed while focus is outside", async () => {
    const user = userEvent.setup();
    render(
      <>
        <button type="button">Background</button>
        <Dialog open onOpenChange={() => {}} title="Confirm">
          <button type="button">Inside</button>
        </Dialog>
      </>,
    );
    screen.getByRole("button", { name: "Background" }).focus();
    await user.tab();
    expect(screen.getByRole("button", { name: "Inside" })).toHaveFocus();
  });

  it("returns focus to the opener when unmounted while open", () => {
    const opener = document.createElement("button");
    document.body.appendChild(opener);
    opener.focus();
    const { unmount } = render(<Dialog open onOpenChange={() => {}} title="Confirm">x</Dialog>);
    expect(screen.getByRole("dialog")).toHaveFocus();
    unmount();
    expect(opener).toHaveFocus();
    opener.remove();
  });

  it("does not throw when the opener was removed before close", async () => {
    const user = userEvent.setup();
    function Removable() {
      const [open, setOpen] = useState(false);
      const [showOpener, setShowOpener] = useState(true);
      return (
        <>
          {showOpener && (
            <button
              type="button"
              onClick={() => {
                setOpen(true);
                setShowOpener(false);
              }}
            >
              Open
            </button>
          )}
          <Dialog open={open} onOpenChange={setOpen} title="Confirm">
            <button type="button">Close me</button>
          </Dialog>
        </>
      );
    }
    render(<Removable />);
    await user.click(screen.getByRole("button", { name: "Open" }));
    expect(screen.getByRole("button", { name: "Close me" })).toHaveFocus();
    await user.keyboard("{Escape}");
    expect(screen.queryByRole("dialog")).toBeNull();
    expect(screen.queryByRole("button", { name: "Open" })).toBeNull();
    expect(document.body).toHaveFocus();
  });

  it("moves focus in and restores it when mounted with open=true", async () => {
    const user = userEvent.setup();
    const opener = document.createElement("button");
    document.body.appendChild(opener);
    opener.focus();
    function Start() {
      const [open, setOpen] = useState(true);
      return (
        <Dialog open={open} onOpenChange={setOpen} title="Confirm">
          <button type="button" onClick={() => setOpen(false)}>
            Done
          </button>
        </Dialog>
      );
    }
    render(<Start />);
    expect(screen.getByRole("button", { name: "Done" })).toHaveFocus();
    await user.click(screen.getByRole("button", { name: "Done" }));
    expect(opener).toHaveFocus();
    opener.remove();
  });
});

describe("Dialog closing", () => {
  it("calls onOpenChange(false) on Escape and does not close itself", async () => {
    const user = userEvent.setup();
    const onOpenChange = vi.fn();
    render(<Dialog open onOpenChange={onOpenChange} title="Confirm">x</Dialog>);
    await user.keyboard("{Escape}");
    expect(onOpenChange).toHaveBeenCalledWith(false);
    expect(screen.getByRole("dialog")).toBeInTheDocument();
  });

  it("calls onOpenChange(false) on Escape pressed in a nested input", async () => {
    const user = userEvent.setup();
    const onOpenChange = vi.fn();
    render(
      <Dialog open onOpenChange={onOpenChange} title="Confirm">
        <input aria-label="Nested" />
      </Dialog>,
    );
    await user.click(screen.getByRole("textbox", { name: "Nested" }));
    await user.keyboard("{Escape}");
    expect(onOpenChange).toHaveBeenCalledTimes(1);
    expect(onOpenChange).toHaveBeenCalledWith(false);
  });

  it("ignores keys other than Escape", async () => {
    const user = userEvent.setup();
    const onOpenChange = vi.fn();
    render(<Dialog open onOpenChange={onOpenChange} title="Confirm">x</Dialog>);
    await user.keyboard("{Enter}a{ArrowDown}");
    expect(onOpenChange).not.toHaveBeenCalled();
  });

  it("calls onOpenChange(false) on a backdrop click", async () => {
    const user = userEvent.setup();
    const onOpenChange = vi.fn();
    render(<Dialog open onOpenChange={onOpenChange} title="Confirm">x</Dialog>);
    const backdrop = document.querySelector("[data-backdrop]") as HTMLElement;
    await user.click(backdrop);
    expect(onOpenChange).toHaveBeenCalledWith(false);
  });

  it("does not call onOpenChange on clicks inside the dialog", async () => {
    const user = userEvent.setup();
    const onOpenChange = vi.fn();
    render(
      <Dialog open onOpenChange={onOpenChange} title="Confirm" description="Details">
        <button type="button">Inside</button>
      </Dialog>,
    );
    await user.click(screen.getByRole("button", { name: "Inside" }));
    await user.click(screen.getByRole("heading", { name: "Confirm" }));
    await user.click(screen.getByRole("dialog"));
    expect(onOpenChange).not.toHaveBeenCalled();
  });

  it("does not call onOpenChange for a drag that starts inside and ends on the backdrop", async () => {
    const user = userEvent.setup();
    const onOpenChange = vi.fn();
    render(
      <Dialog open onOpenChange={onOpenChange} title="Confirm">
        <button type="button">Inside</button>
      </Dialog>,
    );
    const inside = screen.getByRole("button", { name: "Inside" });
    const backdrop = document.querySelector("[data-backdrop]") as HTMLElement;
    await user.pointer([{ keys: "[MouseLeft>]", target: inside }, { target: backdrop }, { keys: "[/MouseLeft]", target: backdrop }]);
    expect(onOpenChange).not.toHaveBeenCalled();
  });

  it("restores focus to the opener after the parent closes it", async () => {
    const user = userEvent.setup();
    render(<Harness />);
    const opener = screen.getByRole("button", { name: "Open" });
    await user.click(opener);
    await user.click(screen.getByRole("button", { name: "Save" }));
    await user.keyboard("{Escape}");
    await waitFor(() => expect(opener).toHaveFocus());
  });
});

describe("Dialog regressions", () => {
  it.each([null, false])("omits the description element and aria-describedby when description is %s", (description) => {
    render(
      <Dialog open onOpenChange={() => {}} title="Confirm" description={description}>
        x
      </Dialog>,
    );
    const dialog = screen.getByRole("dialog");
    expect(dialog).not.toHaveAttribute("aria-describedby");
    expect(dialog.querySelector("p")).toBeNull();
  });

  it.each([
    ["a hidden ancestor", <div hidden><button type="button">Hidden</button></div>],
    ["an inert ancestor", <div inert><button type="button">Hidden</button></div>],
    ["a display:none ancestor", <div style={{ display: "none" }}><button type="button">Hidden</button></div>],
    ["a visibility:hidden ancestor", <div style={{ visibility: "hidden" }}><button type="button">Hidden</button></div>],
    ["display:none on itself", <button type="button" style={{ display: "none" }}>Hidden</button>],
    ["visibility:hidden on itself", <button type="button" style={{ visibility: "hidden" }}>Hidden</button>],
  ])("skips a button inside %s for initial focus and Tab wrapping", async (_name, hidden) => {
    const user = userEvent.setup();
    render(
      <Dialog open onOpenChange={() => {}} title="Confirm">
        {hidden}
        <button type="button">Start</button>
        <button type="button">End</button>
        {hidden}
      </Dialog>,
    );
    expect(screen.getByRole("button", { name: "Start" })).toHaveFocus();
    await user.tab({ shift: true });
    expect(screen.getByRole("button", { name: "End" })).toHaveFocus();
    await user.tab();
    expect(screen.getByRole("button", { name: "Start" })).toHaveFocus();
  });
});

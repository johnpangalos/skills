import { render, screen } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { Combobox, type ComboboxOption, type ComboboxProps } from "./Combobox";

const fruits: ComboboxOption[] = [
  { value: "apple", label: "Apple" },
  { value: "banana", label: "Banana" },
  { value: "cherry", label: "Cherry", disabled: true },
  { value: "apricot", label: "Apricot" },
];

function renderCombobox(props: Partial<ComboboxProps> = {}) {
  const onChange = vi.fn();
  const utils = render(<Combobox label="Fruit" options={fruits} value={null} onChange={onChange} {...props} />);
  return { ...utils, onChange, input: screen.getByRole("combobox", { name: "Fruit" }) };
}

function optionLabels(): string[] {
  return screen.queryAllByRole("option").map((option) => option.textContent ?? "");
}

describe("Combobox", () => {
  it("associates a visible label with a combobox wired to its listbox", () => {
    const { input } = renderCombobox();
    expect(input).toHaveAttribute("aria-autocomplete", "list");
    expect(input).toHaveAttribute("aria-expanded", "false");
    const listbox = screen.getByRole("listbox", { hidden: true });
    expect(input).toHaveAttribute("aria-controls", listbox.id);
    expect(listbox).toHaveAttribute("aria-labelledby", screen.getByText("Fruit").id);
  });

  it("names the open listbox by the label", async () => {
    const user = userEvent.setup();
    renderCombobox();
    await user.tab();
    await user.keyboard("{ArrowDown}");
    expect(screen.getByRole("listbox", { name: "Fruit" })).toBeInTheDocument();
  });

  it("marks the current value as selected and disabled options as aria-disabled", async () => {
    const user = userEvent.setup();
    const { input } = renderCombobox({ value: "apple" });
    await user.tab();
    await user.keyboard("{ArrowDown}");
    expect(input).toHaveAttribute("aria-expanded", "true");
    expect(screen.getByRole("option", { name: "Apple" })).toHaveAttribute("aria-selected", "true");
    expect(screen.getByRole("option", { name: "Banana" })).toHaveAttribute("aria-selected", "false");
    expect(screen.getByRole("option", { name: "Cherry" })).toHaveAttribute("aria-disabled", "true");
  });

  it("opens when typing and filters case-insensitively by substring", async () => {
    const user = userEvent.setup();
    const { input } = renderCombobox();
    await user.type(input, "an");
    expect(input).toHaveAttribute("aria-expanded", "true");
    expect(optionLabels()).toEqual(["Banana"]);
    await user.clear(input);
    await user.type(input, "AP");
    expect(optionLabels()).toEqual(["Apple", "Apricot"]);
  });

  it("matches uppercase input against lowercase labels", async () => {
    const user = userEvent.setup();
    renderCombobox();
    await user.type(screen.getByRole("combobox", { name: "Fruit" }), "APP");
    expect(optionLabels()).toEqual(["Apple"]);
  });

  it("shows all options again when the text is cleared", async () => {
    const user = userEvent.setup();
    const { input } = renderCombobox();
    await user.type(input, "zzz");
    await user.clear(input);
    expect(optionLabels()).toEqual(["Apple", "Banana", "Cherry", "Apricot"]);
  });

  it("opens on ArrowDown when closed", async () => {
    const user = userEvent.setup();
    const { input } = renderCombobox();
    await user.tab();
    expect(input).toHaveAttribute("aria-expanded", "false");
    await user.keyboard("{ArrowDown}");
    expect(input).toHaveAttribute("aria-expanded", "true");
  });

  it("moves the active option with ArrowDown and ArrowUp, skipping disabled options and wrapping", async () => {
    const user = userEvent.setup();
    const { input } = renderCombobox();
    await user.tab();
    await user.keyboard("{ArrowDown}");
    expect(input).toHaveAttribute("aria-activedescendant", screen.getByRole("option", { name: "Apple" }).id);
    await user.keyboard("{ArrowDown}");
    expect(input).toHaveAttribute("aria-activedescendant", screen.getByRole("option", { name: "Banana" }).id);
    await user.keyboard("{ArrowDown}");
    expect(input).toHaveAttribute("aria-activedescendant", screen.getByRole("option", { name: "Apricot" }).id);
    await user.keyboard("{ArrowDown}");
    expect(input).toHaveAttribute("aria-activedescendant", screen.getByRole("option", { name: "Apple" }).id);
    await user.keyboard("{ArrowUp}");
    expect(input).toHaveAttribute("aria-activedescendant", screen.getByRole("option", { name: "Apricot" }).id);
    expect(input).toHaveFocus();
  });

  it("selects the active option on Enter, sets its label, and closes", async () => {
    const user = userEvent.setup();
    const { input, onChange, rerender } = renderCombobox();
    await user.tab();
    await user.keyboard("{ArrowDown}{ArrowDown}{Enter}");
    expect(onChange).toHaveBeenCalledTimes(1);
    expect(onChange).toHaveBeenCalledWith("banana");
    rerender(<Combobox label="Fruit" options={fruits} value="banana" onChange={onChange} />);
    expect(input).toHaveValue("Banana");
    expect(input).toHaveAttribute("aria-expanded", "false");
    expect(input).not.toHaveAttribute("aria-activedescendant");
  });

  it("selects an enabled option on click", async () => {
    const user = userEvent.setup();
    const { input, onChange, rerender } = renderCombobox();
    await user.type(input, "ban");
    await user.click(screen.getByRole("option", { name: "Banana" }));
    expect(onChange).toHaveBeenCalledWith("banana");
    rerender(<Combobox label="Fruit" options={fruits} value="banana" onChange={onChange} />);
    expect(input).toHaveValue("Banana");
    expect(input).toHaveAttribute("aria-expanded", "false");
  });

  it("does nothing when a disabled option is clicked", async () => {
    const user = userEvent.setup();
    const { input, onChange } = renderCombobox();
    await user.type(input, "ch");
    await user.click(screen.getByRole("option", { name: "Cherry" }));
    expect(onChange).not.toHaveBeenCalled();
    expect(input).toHaveAttribute("aria-expanded", "true");
  });

  it("does not select on Enter when no option is active", async () => {
    const user = userEvent.setup();
    const { input, onChange } = renderCombobox();
    await user.type(input, "ban");
    await user.keyboard("{Enter}");
    expect(onChange).not.toHaveBeenCalled();
    expect(input).toHaveAttribute("aria-expanded", "true");
  });

  it("closes on Escape without selecting and reverts the text to the selected label", async () => {
    const user = userEvent.setup();
    const { input, onChange } = renderCombobox({ value: "banana" });
    await user.clear(input);
    await user.type(input, "ap");
    await user.keyboard("{Escape}");
    expect(onChange).not.toHaveBeenCalled();
    expect(input).toHaveAttribute("aria-expanded", "false");
    expect(input).toHaveValue("Banana");
  });

  it("reverts to empty on Escape when nothing is selected", async () => {
    const user = userEvent.setup();
    const { input, onChange } = renderCombobox();
    await user.type(input, "ap");
    await user.keyboard("{Escape}");
    expect(onChange).not.toHaveBeenCalled();
    expect(input).toHaveValue("");
  });

  it("does nothing on Escape when already closed", async () => {
    const user = userEvent.setup();
    const { input, onChange } = renderCombobox({ value: "apple" });
    await user.tab();
    await user.keyboard("{Escape}");
    expect(onChange).not.toHaveBeenCalled();
    expect(input).toHaveValue("Apple");
    expect(input).toHaveFocus();
  });

  it("shows a No results message without options or activedescendant when nothing matches", async () => {
    const user = userEvent.setup();
    const { input } = renderCombobox();
    await user.type(input, "zzz");
    expect(screen.getByText("No results")).toBeInTheDocument();
    expect(screen.queryAllByRole("option")).toHaveLength(0);
    expect(input).not.toHaveAttribute("aria-activedescendant");
  });

  it.each(["(", ".", "*"])("treats %s in typed text literally without throwing", async (typed) => {
    const user = userEvent.setup();
    const { input } = renderCombobox();
    await user.type(input, typed);
    expect(screen.getByText("No results")).toBeInTheDocument();
    expect(input).toHaveValue(typed);
  });

  it("closes on blur and reverts to the selected label without calling onChange", async () => {
    const user = userEvent.setup();
    const { input, onChange } = renderCombobox({ value: "apple" });
    await user.clear(input);
    await user.type(input, "ban");
    await user.tab();
    expect(input).toHaveAttribute("aria-expanded", "false");
    expect(input).toHaveValue("Apple");
    expect(onChange).not.toHaveBeenCalled();
  });

  it("does not call onChange(null) when the text is cleared", async () => {
    const user = userEvent.setup();
    const { input, onChange } = renderCombobox({ value: "apple" });
    await user.clear(input);
    expect(onChange).not.toHaveBeenCalled();
  });

  it("keeps the selected label after choosing when a controlled parent ignores onChange", async () => {
    const user = userEvent.setup();
    const { input, onChange } = renderCombobox({ value: "apple" });
    await user.click(input);
    await user.keyboard("{ArrowDown}{ArrowDown}{Enter}");
    expect(onChange).toHaveBeenCalledWith("banana");
    expect(input).toHaveValue("Apple");
  });

  it("calls onChange(null) on Enter after the text is cleared", async () => {
    const user = userEvent.setup();
    const { input, onChange } = renderCombobox({ value: "apple" });
    await user.clear(input);
    await user.keyboard("{Enter}");
    expect(onChange).toHaveBeenCalledTimes(1);
    expect(onChange).toHaveBeenCalledWith(null);
  });

  it("calls onChange(null) on blur after the text is cleared and reverts when the parent ignores it", async () => {
    const user = userEvent.setup();
    const { input, onChange } = renderCombobox({ value: "apple" });
    await user.clear(input);
    await user.tab();
    expect(onChange).toHaveBeenCalledTimes(1);
    expect(onChange).toHaveBeenCalledWith(null);
    expect(input).toHaveValue("Apple");
  });

  it("does not call onChange(null) on Enter or blur when nothing was selected", async () => {
    const user = userEvent.setup();
    const { input, onChange } = renderCombobox({ value: null });
    await user.click(input);
    await user.keyboard("{Enter}");
    await user.tab();
    expect(onChange).not.toHaveBeenCalled();
  });

  it("treats regex metacharacters in the typed text as plain text", async () => {
    const user = userEvent.setup();
    const { input } = renderCombobox();
    await user.type(input, "(.*");
    expect(optionLabels()).toEqual([]);
    expect(screen.getByText("No results")).toBeInTheDocument();
  });

  it("shows the selected label when the controlled value changes externally", () => {
    const { input, rerender, onChange } = renderCombobox({ value: "apple" });
    expect(input).toHaveValue("Apple");
    rerender(<Combobox label="Fruit" options={fruits} value="banana" onChange={onChange} />);
    expect(input).toHaveValue("Banana");
  });

  it("clears the active option when all options are disabled", async () => {
    const user = userEvent.setup();
    const allDisabled = fruits.map((fruit) => ({ ...fruit, disabled: true }));
    const { input } = renderCombobox({ options: allDisabled });
    await user.tab();
    await user.keyboard("{ArrowDown}{ArrowUp}");
    expect(input).not.toHaveAttribute("aria-activedescendant");
    expect(input).toHaveAttribute("aria-expanded", "true");
  });

  it("drops the active option when the options change while open", async () => {
    const user = userEvent.setup();
    const { input, rerender, onChange } = renderCombobox();
    await user.tab();
    await user.keyboard("{ArrowDown}");
    expect(input).toHaveAttribute("aria-activedescendant", screen.getByRole("option", { name: "Apple" }).id);
    rerender(<Combobox label="Fruit" options={fruits.slice(1)} value={null} onChange={onChange} />);
    expect(input).not.toHaveAttribute("aria-activedescendant");
    await user.keyboard("{ArrowDown}");
    expect(input).toHaveAttribute("aria-activedescendant", screen.getByRole("option", { name: "Banana" }).id);
  });

  it("gives instances on one page distinct ids", () => {
    render(
      <>
        <Combobox label="First" options={fruits} value={null} onChange={() => {}} />
        <Combobox label="Second" options={fruits} value={null} onChange={() => {}} />
      </>,
    );
    const [first, second] = screen.getAllByRole("combobox", { hidden: true });
    expect(first.id).not.toBe(second.id);
    expect(first.getAttribute("aria-controls")).not.toBe(second.getAttribute("aria-controls"));
  });
});

import {
  useEffect,
  useId,
  useRef,
  type HTMLAttributes,
  type KeyboardEvent,
  type MouseEvent,
  type SyntheticEvent,
} from "react";
import { createPortal } from "react-dom";

export interface DialogProps extends Omit<HTMLAttributes<HTMLDivElement>, "title"> {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  title: string;
  description?: string;
}

const FOCUSABLE_SELECTOR = [
  "a[href]",
  "button",
  "input:not([type='hidden'])",
  "select",
  "textarea",
  "iframe",
  "audio[controls]",
  "video[controls]",
  "embed",
  "object",
  "details > summary",
  "[tabindex]",
  "[contenteditable]:not([contenteditable='false'])",
].join(",");

function isDisplayed(element: HTMLElement): boolean {
  for (let node: HTMLElement | null = element; node; node = node.parentElement) {
    if (getComputedStyle(node).display === "none") return false;
  }
  return getComputedStyle(element).visibility !== "hidden";
}

function isRadio(element: HTMLElement): element is HTMLInputElement {
  return element instanceof HTMLInputElement && element.type === "radio";
}

function isTabbable(element: HTMLElement): boolean {
  if (element.matches(":disabled") || element.closest("[hidden]")) return false;
  // A negative tabindex opts out; an element with no tabindex keeps its native focusability.
  if (element.hasAttribute("tabindex") && element.tabIndex < 0) return false;
  // Content of a closed <details> is not rendered; only its summary is a tab stop.
  const closedDetails = element.closest("details:not([open])");
  if (closedDetails && !(element.parentElement === closedDetails && element.tagName === "SUMMARY")) return false;
  return isDisplayed(element);
}

// A radio group is one tab stop: its checked radio, or else its first radio.
function keepOneRadioPerGroup(elements: HTMLElement[]): HTMLElement[] {
  const radios = elements.filter(isRadio);
  return elements.filter((element) => {
    if (!isRadio(element) || !element.name) return true;
    const group = radios.filter((radio) => radio.name === element.name);
    return element === (group.find((radio) => radio.checked) ?? group[0]);
  });
}

function getFocusable(container: HTMLElement): HTMLElement[] {
  const tabbable = Array.from(container.querySelectorAll<HTMLElement>(FOCUSABLE_SELECTOR)).filter(isTabbable);
  return keepOneRadioPerGroup(tabbable);
}

// Every Tab and Shift+Tab inside the dialog is handled here, so the cycle wraps at both ends.
function trapFocus(event: KeyboardEvent<HTMLDivElement>, dialog: HTMLElement) {
  event.preventDefault();
  const focusable = getFocusable(dialog);
  if (focusable.length === 0) {
    dialog.focus();
    return;
  }
  const active = document.activeElement as HTMLElement;
  const index = focusable.indexOf(active);
  if (index !== -1) {
    const step = event.shiftKey ? -1 : 1;
    focusable[(index + step + focusable.length) % focusable.length].focus();
    return;
  }
  const first = focusable[0];
  const last = focusable[focusable.length - 1];
  if (!dialog.contains(active)) {
    first.focus();
    return;
  }
  // Focus is on the dialog or on a non-stop element inside it: move to the neighbouring stop in document order.
  const target = event.shiftKey
    ? focusable.filter((element) => active.compareDocumentPosition(element) & Node.DOCUMENT_POSITION_PRECEDING).at(-1)
    : focusable.find((element) => active.compareDocumentPosition(element) & Node.DOCUMENT_POSITION_FOLLOWING);
  (target ?? (event.shiftKey ? last : first)).focus();
}

export function Dialog({ open, onOpenChange, title, description, children, onKeyDown, ...rest }: DialogProps) {
  const baseId = useId();
  const dialogRef = useRef<HTMLDivElement>(null);
  const openerRef = useRef<Element | null>(null);
  const wasOpenRef = useRef(false);
  const pressedOnBackdrop = useRef(false);
  const titleId = `${baseId}-title`;
  const descriptionId = `${baseId}-description`;

  // Recorded during render: by the time an effect runs, a child's autoFocus has already moved focus.
  if (open && !wasOpenRef.current) openerRef.current = document.activeElement;
  wasOpenRef.current = open;

  useEffect(() => {
    if (!open) return;
    const dialog = dialogRef.current;
    if (dialog && !dialog.contains(document.activeElement)) (getFocusable(dialog).at(0) ?? dialog).focus();
    return () => {
      const opener = openerRef.current;
      if (opener instanceof HTMLElement && opener.isConnected) opener.focus();
    };
  }, [open]);

  if (!open) return null;

  const handleKeyDown = (event: KeyboardEvent<HTMLDivElement>) => {
    onKeyDown?.(event);
    // Keys from a nested dialog bubble through its portal; that dialog owns them.
    if (!event.currentTarget.contains(event.target as Node)) return;
    if (event.key === "Escape") {
      // A focused child (such as an open Combobox list) may already have handled Escape.
      if (!event.defaultPrevented) onOpenChange(false);
    } else if (event.key === "Tab") {
      trapFocus(event, event.currentTarget);
    }
  };

  const rememberPress = (event: SyntheticEvent<HTMLDivElement>) => {
    pressedOnBackdrop.current = event.target === event.currentTarget;
  };

  const handleBackdropClick = (event: MouseEvent<HTMLDivElement>) => {
    const closes = pressedOnBackdrop.current && event.target === event.currentTarget;
    pressedOnBackdrop.current = false;
    if (closes) onOpenChange(false);
  };

  return createPortal(
    <>
      <div
        data-backdrop
        onPointerDown={rememberPress}
        onMouseDown={(event) => {
          // Keeps focus where it is; otherwise a press on the backdrop moves focus to BODY.
          event.preventDefault();
          rememberPress(event);
        }}
        onClick={handleBackdropClick}
      />
      <div
        {...rest}
        ref={dialogRef}
        role="dialog"
        aria-modal="true"
        aria-labelledby={titleId}
        aria-describedby={description ? descriptionId : undefined}
        tabIndex={-1}
        onKeyDown={handleKeyDown}
      >
        <h2 id={titleId}>{title}</h2>
        {description ? <p id={descriptionId}>{description}</p> : null}
        {children}
      </div>
    </>,
    document.body,
  );
}

import { fireEvent, render, screen } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { useState } from "react";
import { Combobox, type ComboboxOption } from "./Combobox";

const FRUITS: ComboboxOption[] = [
  { value: "apple", label: "Apple" },
  { value: "banana", label: "Banana", disabled: true },
  { value: "cherry", label: "Cherry" },
  { value: "grape", label: "Grape" },
];

const noop = () => {};

function Controlled({
  options = FRUITS,
  initial = null,
  onChange = noop,
}: {
  options?: ComboboxOption[];
  initial?: string | null;
  onChange?: (value: string | null) => void;
}) {
  const [value, setValue] = useState<string | null>(initial);
  return (
    <Combobox
      label="Fruit"
      options={options}
      value={value}
      onChange={(next) => {
        onChange(next);
        setValue(next);
      }}
    />
  );
}

const input = () => screen.getByRole("combobox", { name: "Fruit" });
const optionNames = () => screen.queryAllByRole("option").map((option) => option.textContent);

describe("Combobox", () => {
  it("associates a visible label with the combobox and wires up the listbox", () => {
    render(<Controlled />);
    expect(input()).toHaveAttribute("aria-expanded", "false");
    expect(input()).toHaveAttribute("aria-autocomplete", "list");
    expect(input()).not.toHaveAttribute("aria-activedescendant");
    const listbox = document.getElementById(input().getAttribute("aria-controls") ?? "");
    expect(listbox).toHaveAttribute("role", "listbox");
    expect(listbox).toHaveAttribute("aria-labelledby", screen.getByText("Fruit").id);
  });

  it("shows the selected option's label", () => {
    render(<Controlled initial="cherry" />);
    expect(input()).toHaveValue("Cherry");
  });

  it("shows an empty input when the value is not one of the options", () => {
    render(<Controlled initial="kiwi" />);
    expect(input()).toHaveValue("");
  });

  it("opens and filters by case-insensitive substring when typing", async () => {
    const user = userEvent.setup();
    render(<Controlled />);
    await user.type(input(), "AP");
    expect(input()).toHaveAttribute("aria-expanded", "true");
    expect(optionNames()).toEqual(["Apple", "Grape"]);
  });

  it("treats regex characters in the filter literally", async () => {
    const user = userEvent.setup();
    render(<Controlled />);
    await user.type(input(), "(");
    expect(screen.getByText("No results")).toBeInTheDocument();
    await user.clear(input());
    await user.type(input(), ".*");
    expect(screen.getByText("No results")).toBeInTheDocument();
  });

  it("opens with ArrowDown and moves the active option, skipping disabled ones", async () => {
    const user = userEvent.setup();
    render(<Controlled />);
    input().focus();
    await user.keyboard("{ArrowDown}");
    expect(input()).toHaveAttribute("aria-expanded", "true");
    expect(input()).toHaveAttribute("aria-activedescendant", screen.getByRole("option", { name: "Apple" }).id);
    await user.keyboard("{ArrowDown}");
    expect(input()).toHaveAttribute("aria-activedescendant", screen.getByRole("option", { name: "Cherry" }).id);
  });

  it("wraps active option from the last enabled option to the first, and ArrowUp from none picks the last", async () => {
    const user = userEvent.setup();
    render(<Controlled />);
    input().focus();
    await user.keyboard("{ArrowUp}");
    expect(input()).toHaveAttribute("aria-activedescendant", screen.getByRole("option", { name: "Grape" }).id);
    await user.keyboard("{ArrowDown}");
    expect(input()).toHaveAttribute("aria-activedescendant", screen.getByRole("option", { name: "Apple" }).id);
    await user.keyboard("{ArrowUp}");
    expect(input()).toHaveAttribute("aria-activedescendant", screen.getByRole("option", { name: "Grape" }).id);
  });

  it("selects the active option on Enter, closes the popup, and shows its label", async () => {
    const user = userEvent.setup();
    const onChange = vi.fn();
    render(<Controlled onChange={onChange} />);
    input().focus();
    await user.keyboard("{ArrowDown}{ArrowDown}{Enter}");
    expect(onChange).toHaveBeenCalledWith("cherry");
    expect(onChange).toHaveBeenCalledTimes(1);
    expect(input()).toHaveAttribute("aria-expanded", "false");
    expect(input()).toHaveValue("Cherry");
  });

  it("does nothing on Enter with no active option, and does not submit a form while open", async () => {
    const user = userEvent.setup();
    const onChange = vi.fn();
    render(<Controlled onChange={onChange} />);
    await user.type(input(), "a");
    expect(fireEvent.keyDown(input(), { key: "Enter" })).toBe(false);
    expect(onChange).not.toHaveBeenCalled();
    expect(input()).toHaveAttribute("aria-expanded", "true");
  });

  it("lets Enter through when the popup is closed", () => {
    render(<Controlled />);
    expect(fireEvent.keyDown(input(), { key: "Enter" })).toBe(true);
  });

  it("selects an enabled option on click", async () => {
    const user = userEvent.setup();
    const onChange = vi.fn();
    render(<Controlled onChange={onChange} />);
    await user.type(input(), "gr");
    await user.click(screen.getByRole("option", { name: "Grape" }));
    expect(onChange).toHaveBeenCalledWith("grape");
    expect(input()).toHaveValue("Grape");
    expect(input()).toHaveAttribute("aria-expanded", "false");
  });

  it("does not select a disabled option on click", async () => {
    const user = userEvent.setup();
    const onChange = vi.fn();
    render(<Controlled onChange={onChange} />);
    await user.click(input());
    input().focus();
    await user.keyboard("{ArrowDown}");
    await user.click(screen.getByRole("option", { name: "Banana" }));
    expect(onChange).not.toHaveBeenCalled();
    expect(screen.getByRole("option", { name: "Banana" })).toHaveAttribute("aria-disabled", "true");
    expect(input()).toHaveAttribute("aria-expanded", "true");
  });

  it("keeps focus in the input when an option is pressed", async () => {
    const user = userEvent.setup();
    render(<Controlled />);
    await user.type(input(), "ch");
    expect(fireEvent.mouseDown(screen.getByRole("option", { name: "Cherry" }))).toBe(false);
    await user.click(screen.getByRole("option", { name: "Cherry" }));
    expect(input()).toHaveValue("Cherry");
  });

  it("closes on Escape without calling onChange and restores the selected label", async () => {
    const user = userEvent.setup();
    const onChange = vi.fn();
    render(<Controlled initial="apple" onChange={onChange} />);
    await user.type(input(), "ban");
    await user.keyboard("{Escape}");
    expect(onChange).not.toHaveBeenCalled();
    expect(input()).toHaveAttribute("aria-expanded", "false");
    expect(input()).toHaveValue("Apple");
  });

  it("restores empty text on Escape when nothing is selected", async () => {
    const user = userEvent.setup();
    render(<Controlled />);
    await user.type(input(), "ch");
    await user.keyboard("{Escape}");
    expect(input()).toHaveValue("");
  });

  it("shows a No results message, not an option, when nothing matches", async () => {
    const user = userEvent.setup();
    render(<Controlled />);
    await user.type(input(), "zzz");
    expect(screen.getByText("No results")).toBeInTheDocument();
    expect(screen.queryAllByRole("option")).toHaveLength(0);
    expect(input()).not.toHaveAttribute("aria-activedescendant");
  });

  it("shows No results when there are no options at all", async () => {
    const user = userEvent.setup();
    render(<Controlled options={[]} />);
    input().focus();
    await user.keyboard("{ArrowDown}");
    expect(screen.getByText("No results")).toBeInTheDocument();
    expect(input()).not.toHaveAttribute("aria-activedescendant");
  });

  it("clears the value when the text is cleared and the field is left", async () => {
    const user = userEvent.setup();
    const onChange = vi.fn();
    render(<Controlled initial="apple" onChange={onChange} />);
    await user.clear(input());
    await user.tab();
    expect(onChange).toHaveBeenCalledTimes(1);
    expect(onChange).toHaveBeenCalledWith(null);
    expect(input()).toHaveValue("");
  });

  it("closes the popup and restores the label on blur", async () => {
    const user = userEvent.setup();
    const onChange = vi.fn();
    render(<Controlled initial="apple" onChange={onChange} />);
    await user.type(input(), "ch");
    expect(input()).toHaveAttribute("aria-expanded", "true");
    await user.tab();
    expect(input()).toHaveAttribute("aria-expanded", "false");
    expect(input()).toHaveValue("Apple");
    expect(onChange).not.toHaveBeenCalled();
  });

  it("updates the input text when the parent changes value", () => {
    const { rerender } = render(<Combobox label="Fruit" options={FRUITS} value="apple" onChange={noop} />);
    expect(input()).toHaveValue("Apple");
    rerender(<Combobox label="Fruit" options={FRUITS} value="grape" onChange={noop} />);
    expect(input()).toHaveValue("Grape");
  });

  it("keeps the displayed value when a controlled parent ignores onChange", async () => {
    const user = userEvent.setup();
    const onChange = vi.fn();
    render(<Combobox label="Fruit" options={FRUITS} value="apple" onChange={onChange} />);
    input().focus();
    await user.keyboard("{ArrowDown}{ArrowDown}{Enter}");
    expect(onChange).toHaveBeenCalledWith("cherry");
    expect(input()).toHaveValue("Apple");
    expect(input()).toHaveAttribute("aria-expanded", "false");
  });

  it("runs a consumer onKeyDown before its own handling", async () => {
    const user = userEvent.setup();
    const seen: string[] = [];
    render(
      <Combobox
        label="Fruit"
        options={FRUITS}
        value={null}
        onChange={noop}
        onKeyDown={(event) => seen.push(`${event.key}:${input().getAttribute("aria-expanded")}`)}
      />,
    );
    input().focus();
    await user.keyboard("{ArrowDown}");
    expect(seen).toEqual(["ArrowDown:false"]);
    expect(input()).toHaveAttribute("aria-expanded", "true");
  });

  it("skips its own Enter handling when a consumer onKeyDown calls preventDefault", async () => {
    const user = userEvent.setup();
    const onChange = vi.fn();
    render(
      <Combobox
        label="Fruit"
        options={FRUITS}
        value={null}
        onChange={onChange}
        onKeyDown={(event) => event.key === "Enter" && event.preventDefault()}
      />,
    );
    input().focus();
    await user.keyboard("{ArrowDown}{Enter}");
    expect(onChange).not.toHaveBeenCalled();
    expect(input()).toHaveAttribute("aria-expanded", "true");
  });

  it("steps down from a disabled active option to the next enabled one after it", async () => {
    const user = userEvent.setup();
    const { rerender } = render(<Combobox label="Fruit" options={FRUITS} value={null} onChange={noop} />);
    input().focus();
    await user.keyboard("{ArrowDown}{ArrowDown}");
    expect(input()).toHaveAttribute("aria-activedescendant", screen.getByRole("option", { name: "Cherry" }).id);
    const disabledCherry = FRUITS.map((option) => (option.value === "cherry" ? { ...option, disabled: true } : option));
    rerender(<Combobox label="Fruit" options={disabledCherry} value={null} onChange={noop} />);
    await user.keyboard("{ArrowDown}");
    expect(input()).toHaveAttribute("aria-activedescendant", screen.getByRole("option", { name: "Grape" }).id);
  });

  it("steps up from a disabled active option to the previous enabled one before it", async () => {
    const user = userEvent.setup();
    const { rerender } = render(<Combobox label="Fruit" options={FRUITS} value={null} onChange={noop} />);
    input().focus();
    await user.keyboard("{ArrowDown}{ArrowDown}");
    const disabledCherry = FRUITS.map((option) => (option.value === "cherry" ? { ...option, disabled: true } : option));
    rerender(<Combobox label="Fruit" options={disabledCherry} value={null} onChange={noop} />);
    await user.keyboard("{ArrowUp}");
    expect(input()).toHaveAttribute("aria-activedescendant", screen.getByRole("option", { name: "Apple" }).id);
  });

  it("stays on no active option when every option becomes disabled while one is active", async () => {
    const user = userEvent.setup();
    const onChange = vi.fn();
    const { rerender } = render(<Combobox label="Fruit" options={FRUITS} value={null} onChange={onChange} />);
    input().focus();
    await user.keyboard("{ArrowDown}");
    const allDisabled = FRUITS.map((option) => ({ ...option, disabled: true }));
    rerender(<Combobox label="Fruit" options={allDisabled} value={null} onChange={onChange} />);
    await user.keyboard("{ArrowDown}{ArrowUp}{Enter}");
    expect(input()).not.toHaveAttribute("aria-activedescendant");
    expect(onChange).not.toHaveBeenCalled();
  });

  it("calls a consumer onBlur along with its own blur handling", async () => {
    const user = userEvent.setup();
    const onBlur = vi.fn();
    render(<Combobox label="Fruit" options={FRUITS} value={null} onChange={noop} onBlur={onBlur} />);
    input().focus();
    await user.keyboard("{ArrowDown}");
    await user.tab();
    expect(onBlur).toHaveBeenCalledTimes(1);
    expect(input()).toHaveAttribute("aria-expanded", "false");
  });

  it("does not select an option that became disabled while it was active", async () => {
    const user = userEvent.setup();
    const onChange = vi.fn();
    const { rerender } = render(<Combobox label="Fruit" options={FRUITS} value={null} onChange={onChange} />);
    input().focus();
    await user.keyboard("{ArrowDown}");
    expect(input()).toHaveAttribute("aria-activedescendant", screen.getByRole("option", { name: "Apple" }).id);
    const disabledApple = FRUITS.map((option) => (option.value === "apple" ? { ...option, disabled: true } : option));
    rerender(<Combobox label="Fruit" options={disabledApple} value={null} onChange={onChange} />);
    expect(input()).not.toHaveAttribute("aria-activedescendant");
    await user.keyboard("{Enter}");
    expect(onChange).not.toHaveBeenCalled();
  });

  it("announces No results as a status message", async () => {
    const user = userEvent.setup();
    render(<Controlled />);
    await user.type(input(), "zzz");
    expect(screen.getByRole("status")).toHaveTextContent(/^No results$/);
  });

  it("does not loop or select anything when every option is disabled", async () => {
    const user = userEvent.setup();
    const onChange = vi.fn();
    const allDisabled = [{ value: "a", label: "Alpha", disabled: true }];
    render(<Controlled options={allDisabled} onChange={onChange} />);
    input().focus();
    await user.keyboard("{ArrowDown}{ArrowDown}{ArrowUp}{Enter}");
    expect(input()).not.toHaveAttribute("aria-activedescendant");
    expect(onChange).not.toHaveBeenCalled();
  });

  it("produces valid option ids and resolves activedescendant for values with spaces", async () => {
    const user = userEvent.setup();
    render(<Controlled options={[{ value: "new york", label: "New York" }]} />);
    input().focus();
    await user.keyboard("{ArrowDown}");
    const activeId = input().getAttribute("aria-activedescendant") ?? "";
    expect(activeId).not.toMatch(/\s/);
    expect(document.getElementById(activeId)).toHaveTextContent("New York");
  });

  it("resets the active option when the filter changes", async () => {
    const user = userEvent.setup();
    render(<Controlled />);
    input().focus();
    await user.keyboard("{ArrowDown}");
    expect(input()).toHaveAttribute("aria-activedescendant", screen.getByRole("option", { name: "Apple" }).id);
    await user.type(input(), "c");
    expect(optionNames()).toEqual(["Cherry"]);
    expect(input()).not.toHaveAttribute("aria-activedescendant");
  });
});

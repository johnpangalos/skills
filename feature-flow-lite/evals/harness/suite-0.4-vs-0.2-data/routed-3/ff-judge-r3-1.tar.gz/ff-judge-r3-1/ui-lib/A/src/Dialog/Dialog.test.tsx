import { fireEvent, render, screen } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { useState } from "react";
import { Tab, TabList, TabPanel, Tabs } from "../Tabs/Tabs";
import { Dialog } from "./Dialog";

const noop = () => {};

function Host() {
  const [open, setOpen] = useState(false);
  return (
    <>
      <button onClick={() => setOpen(true)}>Open</button>
      <Dialog open={open} onOpenChange={setOpen} title="Settings">
        <button>Close inside</button>
      </Dialog>
    </>
  );
}

// The backdrop is the element wrapping the dialog panel.
const backdropOf = (dialog: HTMLElement) => dialog.parentElement as HTMLElement;

describe("Dialog", () => {
  it("renders nothing when closed", () => {
    render(
      <Dialog open={false} onOpenChange={noop} title="Hidden">
        body
      </Dialog>,
    );
    expect(screen.queryByRole("dialog")).toBeNull();
  });

  it("is a modal dialog labelled by its title", () => {
    render(
      <Dialog open onOpenChange={noop} title="Delete file">
        body
      </Dialog>,
    );
    const dialog = screen.getByRole("dialog", { name: "Delete file" });
    expect(dialog).toHaveAttribute("aria-modal", "true");
    expect(dialog).not.toHaveAttribute("aria-describedby");
  });

  it("points aria-describedby at the description when one is given", () => {
    render(
      <Dialog open onOpenChange={noop} title="Delete file" description="This cannot be undone">
        body
      </Dialog>,
    );
    expect(screen.getByRole("dialog")).toHaveAccessibleDescription("This cannot be undone");
  });

  it("renders through a portal into document.body", () => {
    const { container } = render(
      <Dialog open onOpenChange={noop} title="Portal">
        body
      </Dialog>,
    );
    expect(container).toBeEmptyDOMElement();
    expect(document.body).toContainElement(screen.getByRole("dialog"));
  });

  it("moves focus to the first focusable element on open", () => {
    render(
      <Dialog open onOpenChange={noop} title="Name">
        <input aria-label="Name" />
        <button>Save</button>
      </Dialog>,
    );
    expect(screen.getByRole("textbox", { name: "Name" })).toHaveFocus();
  });

  it("focuses the dialog itself when it has no focusable children", () => {
    render(
      <Dialog open onOpenChange={noop} title="Notice">
        <p>Just text</p>
      </Dialog>,
    );
    expect(screen.getByRole("dialog")).toHaveFocus();
  });

  it("wraps Tab from the last focusable element to the first", async () => {
    const user = userEvent.setup();
    render(
      <Dialog open onOpenChange={noop} title="Name">
        <input aria-label="Name" />
        <button>Save</button>
      </Dialog>,
    );
    await user.tab();
    expect(screen.getByRole("button", { name: "Save" })).toHaveFocus();
    await user.tab();
    expect(screen.getByRole("textbox", { name: "Name" })).toHaveFocus();
  });

  it("wraps Shift+Tab from the first focusable element to the last", async () => {
    const user = userEvent.setup();
    render(
      <Dialog open onOpenChange={noop} title="Name">
        <input aria-label="Name" />
        <button>Save</button>
      </Dialog>,
    );
    await user.tab({ shift: true });
    expect(screen.getByRole("button", { name: "Save" })).toHaveFocus();
  });

  it("keeps focus on the dialog when there are no focusable children and Tab is pressed", async () => {
    const user = userEvent.setup();
    render(
      <Dialog open onOpenChange={noop} title="Notice">
        <p>Just text</p>
      </Dialog>,
    );
    await user.tab();
    expect(screen.getByRole("dialog")).toHaveFocus();
  });

  it("ignores disabled and tabindex=-1 elements when trapping focus", async () => {
    const user = userEvent.setup();
    render(
      <Dialog open onOpenChange={noop} title="Choose">
        <button disabled>Unavailable</button>
        <button tabIndex={-1}>Programmatic</button>
        <button>OK</button>
      </Dialog>,
    );
    expect(screen.getByRole("button", { name: "OK" })).toHaveFocus();
    await user.tab();
    expect(screen.getByRole("button", { name: "OK" })).toHaveFocus();
  });

  it("moves Tab from a tabIndex=-1 element at the end of the panel to the first tabbable", async () => {
    const user = userEvent.setup();
    render(
      <Dialog open onOpenChange={noop} title="Notes">
        <button>First</button>
        <button>Second</button>
        <span tabIndex={-1}>Note</span>
      </Dialog>,
    );
    screen.getByText("Note").focus();
    await user.tab();
    expect(screen.getByRole("button", { name: "First" })).toHaveFocus();
  });

  it("moves Shift+Tab from a tabIndex=-1 element at the end of the panel to the last tabbable", async () => {
    const user = userEvent.setup();
    render(
      <Dialog open onOpenChange={noop} title="Notes">
        <button>First</button>
        <button>Second</button>
        <span tabIndex={-1}>Note</span>
      </Dialog>,
    );
    screen.getByText("Note").focus();
    await user.tab({ shift: true });
    expect(screen.getByRole("button", { name: "Second" })).toHaveFocus();
  });

  it("wraps Shift+Tab from the first focusable to the last visible tabbable, skipping a hidden panel", async () => {
    const user = userEvent.setup();
    render(
      <Dialog open onOpenChange={noop} title="Tabbed">
        <Tabs defaultValue="a">
          <TabList aria-label="Sections">
            <Tab value="a">Tab A</Tab>
            <Tab value="b">Tab B</Tab>
          </TabList>
          <TabPanel value="a">
            <button>Visible A</button>
          </TabPanel>
          <TabPanel value="b">
            <button>Hidden B</button>
          </TabPanel>
        </Tabs>
      </Dialog>,
    );
    expect(screen.getByRole("tab", { name: "Tab A" })).toHaveFocus();
    await user.tab({ shift: true });
    expect(screen.getByRole("button", { name: "Visible A" })).toHaveFocus();
    await user.tab();
    expect(screen.getByRole("tab", { name: "Tab A" })).toHaveFocus();
  });

  it("does not close on Escape from a nested element that calls preventDefault", () => {
    const onOpenChange = vi.fn();
    render(
      <Dialog open onOpenChange={onOpenChange} title="Editing">
        <input aria-label="Name" onKeyDown={(event) => event.key === "Escape" && event.preventDefault()} />
      </Dialog>,
    );
    fireEvent.keyDown(screen.getByRole("textbox", { name: "Name" }), { key: "Escape" });
    expect(onOpenChange).not.toHaveBeenCalled();
  });

  it("does not close on Escape from a nested element whose React handler calls stopPropagation", () => {
    const onOpenChange = vi.fn();
    render(
      <Dialog open onOpenChange={onOpenChange} title="Editing">
        <input aria-label="Name" onKeyDown={(event) => event.stopPropagation()} />
      </Dialog>,
    );
    fireEvent.keyDown(screen.getByRole("textbox", { name: "Name" }), { key: "Escape" });
    expect(onOpenChange).not.toHaveBeenCalled();
  });

  it("calls onOpenChange(false) on Escape", async () => {
    const user = userEvent.setup();
    const onOpenChange = vi.fn();
    render(
      <Dialog open onOpenChange={onOpenChange} title="Escape">
        <button>Inside</button>
      </Dialog>,
    );
    await user.keyboard("{Escape}");
    expect(onOpenChange).toHaveBeenCalledTimes(1);
    expect(onOpenChange).toHaveBeenCalledWith(false);
  });

  it("calls onOpenChange(false) on Escape pressed inside a nested element", () => {
    const onOpenChange = vi.fn();
    render(
      <Dialog open onOpenChange={onOpenChange} title="Nested">
        <div>
          <button>Deep</button>
        </div>
      </Dialog>,
    );
    fireEvent.keyDown(screen.getByRole("button", { name: "Deep" }), { key: "Escape" });
    expect(onOpenChange).toHaveBeenCalledWith(false);
  });

  it("closes on a backdrop click", async () => {
    const user = userEvent.setup();
    const onOpenChange = vi.fn();
    render(
      <Dialog open onOpenChange={onOpenChange} title="Backdrop">
        body
      </Dialog>,
    );
    await user.click(backdropOf(screen.getByRole("dialog")));
    expect(onOpenChange).toHaveBeenCalledTimes(1);
    expect(onOpenChange).toHaveBeenCalledWith(false);
  });

  it("does not close when clicking inside the panel", async () => {
    const user = userEvent.setup();
    const onOpenChange = vi.fn();
    render(
      <Dialog open onOpenChange={onOpenChange} title="Inside">
        <p>body text</p>
      </Dialog>,
    );
    await user.click(screen.getByText("body text"));
    fireEvent.mouseDown(screen.getByRole("dialog"));
    expect(onOpenChange).not.toHaveBeenCalled();
  });

  it("does not close when a press starts inside and ends on the backdrop", () => {
    const onOpenChange = vi.fn();
    render(
      <Dialog open onOpenChange={onOpenChange} title="Drag">
        body
      </Dialog>,
    );
    const dialog = screen.getByRole("dialog");
    fireEvent.mouseDown(dialog);
    fireEvent.mouseUp(backdropOf(dialog));
    fireEvent.click(backdropOf(dialog));
    expect(onOpenChange).not.toHaveBeenCalled();
  });

  it("does not close when a press starts on the backdrop and is released inside the panel", () => {
    const onOpenChange = vi.fn();
    render(
      <Dialog open onOpenChange={onOpenChange} title="Drag in">
        <p>body text</p>
      </Dialog>,
    );
    const backdrop = backdropOf(screen.getByRole("dialog"));
    fireEvent.mouseDown(backdrop);
    fireEvent.mouseUp(screen.getByText("body text"));
    fireEvent.click(backdrop);
    expect(onOpenChange).not.toHaveBeenCalled();
  });

  it("returns focus to the opener when open becomes false", async () => {
    const user = userEvent.setup();
    render(<Host />);
    await user.click(screen.getByRole("button", { name: "Open" }));
    expect(screen.getByRole("button", { name: "Close inside" })).toHaveFocus();
    await user.keyboard("{Escape}");
    expect(screen.queryByRole("dialog")).toBeNull();
    expect(screen.getByRole("button", { name: "Open" })).toHaveFocus();
  });

  it("returns focus to the opener when unmounted while open", () => {
    const opener = document.createElement("button");
    document.body.appendChild(opener);
    opener.focus();
    const { unmount } = render(
      <Dialog open onOpenChange={noop} title="Unmount">
        <button>Inside</button>
      </Dialog>,
    );
    expect(screen.getByRole("button", { name: "Inside" })).toHaveFocus();
    unmount();
    expect(opener).toHaveFocus();
    opener.remove();
  });

  it("moves focus in when it mounts already open", () => {
    render(
      <Dialog open onOpenChange={noop} title="Initially open">
        <button>First</button>
      </Dialog>,
    );
    expect(screen.getByRole("button", { name: "First" })).toHaveFocus();
  });

  it("gives two open dialogs distinct, resolvable title ids", () => {
    render(
      <>
        <Dialog open onOpenChange={noop} title="Alpha">
          a
        </Dialog>
        <Dialog open onOpenChange={noop} title="Beta">
          b
        </Dialog>
      </>,
    );
    const [first, second] = screen.getAllByRole("dialog");
    const firstLabel = first.getAttribute("aria-labelledby") ?? "";
    const secondLabel = second.getAttribute("aria-labelledby") ?? "";
    expect(firstLabel).not.toBe(secondLabel);
    expect(document.getElementById(firstLabel)).toHaveTextContent("Alpha");
    expect(document.getElementById(secondLabel)).toHaveTextContent("Beta");
  });

  it("accepts a ReactNode title", () => {
    render(
      <Dialog open onOpenChange={noop} title={<span>Hello <strong>there</strong></span>}>
        body
      </Dialog>,
    );
    expect(screen.getByRole("dialog", { name: "Hello there" })).toBeInTheDocument();
  });
});

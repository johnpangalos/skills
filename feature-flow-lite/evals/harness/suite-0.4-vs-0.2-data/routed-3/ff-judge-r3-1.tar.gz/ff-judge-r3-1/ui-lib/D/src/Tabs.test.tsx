import { fireEvent, render, screen } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { Tab, TabList, TabPanel, Tabs, type TabsProps } from "./Tabs";

function Example(props: Partial<TabsProps>) {
  return (
    <Tabs {...props}>
      <TabList aria-label="Pages">
        <Tab value="one">One</Tab>
        <Tab value="two" disabled>
          Two
        </Tab>
        <Tab value="three">Three</Tab>
      </TabList>
      <TabPanel value="one">Panel one</TabPanel>
      <TabPanel value="two">Panel two</TabPanel>
      <TabPanel value="three">Panel three</TabPanel>
    </Tabs>
  );
}

describe("Tabs", () => {
  it("selects the first enabled tab when neither value nor defaultValue is given", () => {
    render(<Example />);
    expect(screen.getByRole("tab", { name: "One" })).toHaveAttribute("aria-selected", "true");
    expect(screen.getByRole("tabpanel", { name: "One" })).toHaveTextContent("Panel one");
  });

  it("uses defaultValue when uncontrolled", () => {
    render(<Example defaultValue="three" />);
    expect(screen.getByRole("tab", { name: "Three" })).toHaveAttribute("aria-selected", "true");
    expect(screen.getByRole("tabpanel")).toHaveTextContent("Panel three");
  });

  it.each(["two", "missing"])("falls back to the first enabled tab when defaultValue is %s", (defaultValue) => {
    render(<Example defaultValue={defaultValue} />);
    expect(screen.getByRole("tab", { name: "One" })).toHaveAttribute("aria-selected", "true");
    expect(screen.getByRole("tab", { name: "One" })).toHaveAttribute("tabindex", "0");
    expect(screen.getByRole("tab", { name: "Three" })).toHaveAttribute("tabindex", "-1");
  });

  it("renders a horizontal tablist with the given label", () => {
    render(<Example />);
    const tablist = screen.getByRole("tablist", { name: "Pages" });
    expect(tablist).toHaveAttribute("aria-orientation", "horizontal");
  });

  it("links each tab to its panel with aria-controls and aria-labelledby", () => {
    render(<Example />);
    const tab = screen.getByRole("tab", { name: "One" });
    const panel = screen.getByRole("tabpanel");
    expect(tab.tagName).toBe("BUTTON");
    expect(tab).toHaveAttribute("aria-controls", panel.id);
    expect(panel).toHaveAttribute("aria-labelledby", tab.id);
    expect(panel).toHaveAttribute("tabindex", "0");
  });

  it("gives tabIndex 0 only to the selected tab", () => {
    render(<Example defaultValue="three" />);
    expect(screen.getByRole("tab", { name: "Three" })).toHaveAttribute("tabindex", "0");
    expect(screen.getByRole("tab", { name: "One" })).toHaveAttribute("tabindex", "-1");
    expect(screen.getByRole("tab", { name: "Two" })).toHaveAttribute("tabindex", "-1");
  });

  it("does not select a disabled tab on click", async () => {
    const user = userEvent.setup();
    const onValueChange = vi.fn();
    render(<Example onValueChange={onValueChange} />);
    await user.click(screen.getByRole("tab", { name: "Two" }));
    expect(onValueChange).not.toHaveBeenCalled();
    expect(screen.getByRole("tab", { name: "Two" })).toHaveAttribute("aria-selected", "false");
  });

  it("moves focus and selection with ArrowRight, skipping disabled tabs", async () => {
    const user = userEvent.setup();
    const onValueChange = vi.fn();
    render(<Example onValueChange={onValueChange} />);
    await user.tab();
    await user.keyboard("{ArrowRight}");
    expect(screen.getByRole("tab", { name: "Three" })).toHaveFocus();
    expect(screen.getByRole("tab", { name: "Three" })).toHaveAttribute("aria-selected", "true");
    expect(onValueChange).toHaveBeenCalledTimes(1);
    expect(onValueChange).toHaveBeenCalledWith("three");
  });

  it("wraps ArrowRight from last to first and ArrowLeft from first to last", async () => {
    const user = userEvent.setup();
    render(<Example defaultValue="three" />);
    await user.tab();
    await user.keyboard("{ArrowRight}");
    expect(screen.getByRole("tab", { name: "One" })).toHaveFocus();
    await user.keyboard("{ArrowLeft}");
    expect(screen.getByRole("tab", { name: "Three" })).toHaveFocus();
  });

  it("moves to the first and last enabled tabs with Home and End", async () => {
    const user = userEvent.setup();
    render(<Example />);
    await user.tab();
    await user.keyboard("{End}");
    expect(screen.getByRole("tab", { name: "Three" })).toHaveFocus();
    expect(screen.getByRole("tab", { name: "Three" })).toHaveAttribute("aria-selected", "true");
    await user.keyboard("{Home}");
    expect(screen.getByRole("tab", { name: "One" })).toHaveFocus();
  });

  it("does not handle ArrowUp or ArrowDown", async () => {
    const user = userEvent.setup();
    const onValueChange = vi.fn();
    render(<Example onValueChange={onValueChange} />);
    await user.tab();
    await user.keyboard("{ArrowDown}{ArrowUp}");
    expect(screen.getByRole("tab", { name: "One" })).toHaveFocus();
    expect(onValueChange).not.toHaveBeenCalled();
  });

  it("prevents the default behaviour of handled keys", () => {
    render(<Example />);
    const tab = screen.getByRole("tab", { name: "One" });
    expect(fireEvent.keyDown(tab, { key: "ArrowRight" })).toBe(false);
    expect(fireEvent.keyDown(tab, { key: "End" })).toBe(false);
  });

  it("keeps the only enabled tab focused when all others are disabled", async () => {
    const user = userEvent.setup();
    render(
      <Tabs defaultValue="a">
        <TabList aria-label="Only">
          <Tab value="a">A</Tab>
          <Tab value="b" disabled>
            B
          </Tab>
          <Tab value="c" disabled>
            C
          </Tab>
        </TabList>
        <TabPanel value="a">Panel A</TabPanel>
      </Tabs>,
    );
    await user.tab();
    await user.keyboard("{ArrowRight}{ArrowLeft}{End}");
    expect(screen.getByRole("tab", { name: "A" })).toHaveFocus();
    expect(screen.getByRole("tab", { name: "A" })).toHaveAttribute("aria-selected", "true");
  });

  it("does not move selection when a controlled parent ignores onValueChange", async () => {
    const user = userEvent.setup();
    const onValueChange = vi.fn();
    render(<Example value="one" onValueChange={onValueChange} />);
    await user.tab();
    await user.keyboard("{ArrowRight}");
    expect(onValueChange).toHaveBeenCalledWith("three");
    expect(screen.getByRole("tab", { name: "One" })).toHaveAttribute("aria-selected", "true");
    expect(screen.getByRole("tabpanel")).toHaveTextContent("Panel one");
  });

  it("follows the value prop when a controlled parent updates it", () => {
    const { rerender } = render(<Example value="one" />);
    rerender(<Example value="three" />);
    expect(screen.getByRole("tab", { name: "Three" })).toHaveAttribute("aria-selected", "true");
    expect(screen.getByRole("tabpanel")).toHaveTextContent("Panel three");
  });

  it("calls onValueChange on click but not when re-selecting the selected tab", async () => {
    const user = userEvent.setup();
    const onValueChange = vi.fn();
    render(<Example onValueChange={onValueChange} />);
    await user.click(screen.getByRole("tab", { name: "One" }));
    expect(onValueChange).not.toHaveBeenCalled();
    await user.click(screen.getByRole("tab", { name: "Three" }));
    expect(onValueChange).toHaveBeenCalledTimes(1);
    expect(onValueChange).toHaveBeenCalledWith("three");
    expect(screen.getByRole("tab", { name: "Three" })).toHaveAttribute("aria-selected", "true");
  });

  it("calls onValueChange once per click when a controlled parent ignores it", async () => {
    const user = userEvent.setup();
    const onValueChange = vi.fn();
    render(<Example value="one" onValueChange={onValueChange} />);
    await user.click(screen.getByRole("tab", { name: "Three" }));
    expect(onValueChange).toHaveBeenCalledTimes(1);
    expect(onValueChange).toHaveBeenCalledWith("three");
    expect(screen.getByRole("tab", { name: "One" })).toHaveAttribute("aria-selected", "true");
  });

  it("fires onValueChange once for a single click when a controlled parent ignores it", async () => {
    const user = userEvent.setup();
    const onValueChange = vi.fn();
    render(<Example value="one" onValueChange={onValueChange} />);
    await user.click(screen.getByRole("tab", { name: "Three" }));
    expect(onValueChange).toHaveBeenCalledTimes(1);
  });

  it("fires onValueChange again on a second click on the focused tab when a controlled parent ignores it", async () => {
    const user = userEvent.setup();
    const onValueChange = vi.fn();
    render(<Example value="one" onValueChange={onValueChange} />);
    await user.click(screen.getByRole("tab", { name: "Three" }));
    await user.click(screen.getByRole("tab", { name: "Three" }));
    expect(onValueChange).toHaveBeenCalledTimes(2);
    expect(onValueChange).toHaveBeenLastCalledWith("three");
  });

  it("fires onValueChange on each arrow, Enter and Space selection when a controlled parent ignores it", async () => {
    const user = userEvent.setup();
    const onValueChange = vi.fn();
    render(<Example value="one" onValueChange={onValueChange} />);
    await user.tab();
    await user.keyboard("{ArrowRight}");
    expect(onValueChange).toHaveBeenCalledTimes(1);
    await user.keyboard("{Enter}");
    expect(onValueChange).toHaveBeenCalledTimes(2);
    await user.keyboard(" ");
    expect(onValueChange).toHaveBeenCalledTimes(3);
    expect(onValueChange).toHaveBeenLastCalledWith("three");
    expect(screen.getByRole("tab", { name: "One" })).toHaveAttribute("aria-selected", "true");
  });

  it("selects a tab reached by keyboard after a mouse press on another tab left no click", async () => {
    const user = userEvent.setup();
    render(<Example />);
    const one = screen.getByRole("tab", { name: "One" });
    const three = screen.getByRole("tab", { name: "Three" });
    fireEvent.mouseDown(three);
    one.focus();
    await user.keyboard("{ArrowRight}");
    expect(three).toHaveFocus();
    expect(three).toHaveAttribute("aria-selected", "true");
  });

  it("gives instances on one page distinct ids", () => {
    render(
      <>
        <Example />
        <Example />
      </>,
    );
    const tabs = screen.getAllByRole("tab", { name: "One" });
    const panels = screen.getAllByRole("tabpanel", { hidden: true });
    expect(tabs[0].id).not.toBe(tabs[1].id);
    expect(panels[0].id).not.toBe(panels[1].id);
  });

  it("throws when Tab is rendered outside Tabs", () => {
    const consoleError = vi.spyOn(console, "error").mockImplementation(() => {});
    expect(() =>
      render(
        <TabList aria-label="Loose">
          <Tab value="a">A</Tab>
        </TabList>,
      ),
    ).toThrow("TabList must be used inside <Tabs>");
    consoleError.mockRestore();
  });
});

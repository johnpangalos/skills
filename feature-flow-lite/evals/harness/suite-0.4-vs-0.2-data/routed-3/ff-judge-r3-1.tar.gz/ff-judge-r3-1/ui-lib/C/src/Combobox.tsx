import {
  useId,
  useState,
  type ChangeEvent,
  type FocusEvent,
  type InputHTMLAttributes,
  type KeyboardEvent,
} from "react";

export interface ComboboxOption {
  value: string;
  label: string;
  disabled?: boolean;
}

export interface ComboboxProps
  extends Omit<InputHTMLAttributes<HTMLInputElement>, "value" | "defaultValue" | "onChange" | "type" | "role"> {
  label: string;
  options: ComboboxOption[];
  value: string | null;
  onChange: (value: string | null) => void;
}

function filterOptions(options: ComboboxOption[], query: string | null): ComboboxOption[] {
  const needle = (query ?? "").trim().toLowerCase();
  return options.filter((option) => option.label.toLowerCase().includes(needle));
}

function stepOption(options: ComboboxOption[], activeValue: string | null, delta: 1 | -1): ComboboxOption | undefined {
  if (options.length === 0) return undefined;
  const index = options.findIndex((option) => option.value === activeValue);
  if (index === -1) return delta === 1 ? options[0] : options[options.length - 1];
  return options[(index + delta + options.length) % options.length];
}

export function Combobox({
  label,
  options,
  value,
  onChange,
  onKeyDown,
  onBlur,
  placeholder,
  ...rest
}: ComboboxProps) {
  const baseId = useId();
  const inputId = `${baseId}-input`;
  const listboxId = `${baseId}-listbox`;
  const labelId = `${baseId}-label`;
  const optionId = (optionValue: string) => `${baseId}-option-${encodeURIComponent(optionValue)}`;

  const [open, setOpen] = useState(false);
  // null while not editing: the input shows the selected label and all options are listed.
  const [query, setQuery] = useState<string | null>(null);
  const [activeValue, setActiveValue] = useState<string | null>(null);

  const shown = filterOptions(options, query);
  const enabled = shown.filter((option) => !option.disabled);
  const active = open ? enabled.find((option) => option.value === activeValue) : undefined;
  const selected = options.find((option) => option.value === value);
  const text = query ?? selected?.label ?? "";
  const isCleared = query !== null && query.trim() === "";

  const close = () => {
    setOpen(false);
    setQuery(null);
    setActiveValue(null);
  };

  const choose = (option: ComboboxOption) => {
    onChange(option.value);
    close();
  };

  const clearSelection = () => {
    if (isCleared && value !== null) onChange(null);
  };

  const handleChange = (event: ChangeEvent<HTMLInputElement>) => {
    setQuery(event.target.value);
    setOpen(true);
    setActiveValue(null);
  };

  const handleKeyDown = (event: KeyboardEvent<HTMLInputElement>) => {
    onKeyDown?.(event);
    switch (event.key) {
      case "ArrowDown":
      case "ArrowUp":
        event.preventDefault();
        if (!open) {
          setOpen(true);
          return;
        }
        setActiveValue(stepOption(enabled, activeValue, event.key === "ArrowDown" ? 1 : -1)?.value ?? null);
        return;
      case "Enter":
        if (active) {
          event.preventDefault();
          choose(active);
        } else if (isCleared) {
          event.preventDefault();
          clearSelection();
          close();
        }
        return;
      case "Escape":
        if (!open) return;
        event.preventDefault();
        close();
        return;
    }
  };

  const handleBlur = (event: FocusEvent<HTMLInputElement>) => {
    onBlur?.(event);
    clearSelection();
    close();
  };

  const handleOptionClick = (option: ComboboxOption) => {
    if (!option.disabled) choose(option);
  };

  return (
    <div>
      <label id={labelId} htmlFor={inputId}>
        {label}
      </label>
      <input
        {...rest}
        id={inputId}
        type="text"
        role="combobox"
        autoComplete="off"
        aria-autocomplete="list"
        aria-expanded={open}
        aria-controls={listboxId}
        aria-activedescendant={active ? optionId(active.value) : undefined}
        placeholder={placeholder}
        value={text}
        onChange={handleChange}
        onKeyDown={handleKeyDown}
        onBlur={handleBlur}
      />
      <ul
        id={listboxId}
        role="listbox"
        aria-labelledby={labelId}
        hidden={!open}
        onMouseDown={(event) => event.preventDefault()}
      >
        {shown.map((option) => (
          <li
            key={option.value}
            id={optionId(option.value)}
            role="option"
            aria-selected={option.value === value}
            aria-disabled={option.disabled || undefined}
            data-active={active?.value === option.value ? "true" : undefined}
            onClick={() => handleOptionClick(option)}
          >
            {option.label}
          </li>
        ))}
      </ul>
      {open && shown.length === 0 ? <div role="status">No results</div> : null}
    </div>
  );
}

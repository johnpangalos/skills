import { fireEvent, render, screen } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { useState } from "react";
import { describe, expect, it, vi } from "vitest";
import { Combobox } from "./Combobox";
import { Dialog, type DialogProps } from "./Dialog";
import { Tab, TabList, TabPanel, Tabs } from "./Tabs";

function Harness({ onOpenChange, initialOpen = false }: { onOpenChange?: (open: boolean) => void; initialOpen?: boolean }) {
  const [open, setOpen] = useState(initialOpen);
  return (
    <>
      <button onClick={() => setOpen(true)}>Open</button>
      <Dialog
        open={open}
        onOpenChange={(next) => {
          onOpenChange?.(next);
          setOpen(next);
        }}
        title="Delete file"
        description="This cannot be undone."
      >
        <button>Confirm</button>
        <button>Cancel</button>
      </Dialog>
    </>
  );
}

function Subject({ open, showDetails = true, ...props }: Omit<DialogProps, "title" | "onOpenChange"> & { showDetails?: boolean }) {
  return (
    <Dialog {...props} open={open} onOpenChange={() => {}} title="Details">
      {showDetails && <button>Details</button>}
      <button>Save</button>
    </Dialog>
  );
}

function outsideButton(): HTMLButtonElement {
  const button = document.createElement("button");
  button.textContent = "Trigger";
  document.body.append(button);
  button.focus();
  return button;
}

const dialog = () => screen.getByRole("dialog");
const backdrop = () => document.querySelector<HTMLElement>("[data-backdrop]") as HTMLElement;

describe("Dialog rendering", () => {
  it("renders nothing when closed", () => {
    render(<Subject open={false} />);
    expect(screen.queryByRole("dialog")).not.toBeInTheDocument();
    expect(document.querySelector("[data-backdrop]")).toBeNull();
  });

  it("renders a modal labelled by its title and described by its description in a portal", () => {
    const { container } = render(
      <Dialog open onOpenChange={() => {}} title="Delete file" description="This cannot be undone.">
        <button>Confirm</button>
      </Dialog>,
    );
    const element = dialog();
    expect(element).toHaveAttribute("aria-modal", "true");
    expect(element).toHaveAccessibleName("Delete file");
    expect(element).toHaveAccessibleDescription("This cannot be undone.");
    expect(container.contains(element)).toBe(false);
    expect(document.body).toContainElement(backdrop());
  });

  it("omits aria-describedby when no description is given", () => {
    render(<Subject open />);
    expect(dialog()).not.toHaveAttribute("aria-describedby");
  });

  it("passes native props through to the dialog element", () => {
    render(<Subject open className="confirm" />);
    expect(dialog()).toHaveClass("confirm");
  });

  it("gives unique ids to multiple dialogs on one page", () => {
    render(
      <>
        <Subject open />
        <Subject open />
      </>,
    );
    const labels = screen.getAllByRole("dialog").map((element) => element.getAttribute("aria-labelledby"));
    expect(new Set(labels).size).toBe(2);
  });
});

describe("Dialog focus", () => {
  it("moves focus to the first focusable element when opened", async () => {
    const user = userEvent.setup();
    render(<Harness />);
    await user.click(screen.getByRole("button", { name: "Open" }));
    expect(screen.getByRole("button", { name: "Confirm" })).toHaveFocus();
  });

  it("focuses the dialog container when nothing inside is focusable", () => {
    render(
      <Dialog open onOpenChange={() => {}} title="Notice">
        Just text
      </Dialog>,
    );
    expect(dialog()).toHaveFocus();
    expect(dialog()).toHaveAttribute("tabindex", "-1");
  });

  it("wraps Tab from the last focusable element to the first", async () => {
    const user = userEvent.setup();
    render(<Harness />);
    await user.click(screen.getByRole("button", { name: "Open" }));
    screen.getByRole("button", { name: "Cancel" }).focus();
    await user.keyboard("{Tab}");
    expect(screen.getByRole("button", { name: "Confirm" })).toHaveFocus();
  });

  it("wraps Shift+Tab from the first focusable element to the last", async () => {
    const user = userEvent.setup();
    render(<Harness />);
    await user.click(screen.getByRole("button", { name: "Open" }));
    expect(screen.getByRole("button", { name: "Confirm" })).toHaveFocus();
    await user.keyboard("{Shift>}{Tab}{/Shift}");
    expect(screen.getByRole("button", { name: "Cancel" })).toHaveFocus();
  });

  it("keeps Tab moving normally between inner focusable elements", async () => {
    const user = userEvent.setup();
    render(<Harness />);
    await user.click(screen.getByRole("button", { name: "Open" }));
    await user.keyboard("{Tab}");
    expect(screen.getByRole("button", { name: "Cancel" })).toHaveFocus();
  });

  it("keeps focus on the dialog when there are no focusable elements", async () => {
    const user = userEvent.setup();
    render(
      <Dialog open onOpenChange={() => {}} title="Notice">
        Just text
      </Dialog>,
    );
    await user.keyboard("{Tab}");
    expect(dialog()).toHaveFocus();
    await user.keyboard("{Shift>}{Tab}{/Shift}");
    expect(dialog()).toHaveFocus();
  });

  it("moves focus back inside when it has escaped the dialog", () => {
    const outside = outsideButton();
    render(<Subject open />);
    outside.focus();
    fireEvent.keyDown(dialog(), { key: "Tab" });
    expect(screen.getByRole("button", { name: "Details" })).toHaveFocus();
    outside.remove();
  });
});

describe("Dialog closing", () => {
  it("calls onOpenChange(false) on Escape", async () => {
    const user = userEvent.setup();
    const onOpenChange = vi.fn();
    render(<Harness onOpenChange={onOpenChange} />);
    await user.click(screen.getByRole("button", { name: "Open" }));
    await user.keyboard("{Escape}");
    expect(onOpenChange).toHaveBeenCalledTimes(1);
    expect(onOpenChange).toHaveBeenCalledWith(false);
    expect(screen.queryByRole("dialog")).not.toBeInTheDocument();
  });

  it("calls onOpenChange(false) on a click on the backdrop", async () => {
    const user = userEvent.setup();
    const onOpenChange = vi.fn();
    render(<Harness onOpenChange={onOpenChange} />);
    await user.click(screen.getByRole("button", { name: "Open" }));
    await user.click(backdrop());
    expect(onOpenChange).toHaveBeenCalledWith(false);
  });

  it("does not close on a click inside the dialog content", async () => {
    const user = userEvent.setup();
    const onOpenChange = vi.fn();
    render(<Harness onOpenChange={onOpenChange} />);
    await user.click(screen.getByRole("button", { name: "Open" }));
    await user.click(screen.getByText("This cannot be undone."));
    expect(onOpenChange).not.toHaveBeenCalled();
    expect(dialog()).toBeInTheDocument();
  });

  it("does not close when the press started inside the content and ended on the backdrop", () => {
    const onOpenChange = vi.fn();
    render(
      <Dialog open onOpenChange={onOpenChange} title="Delete file">
        <button>Confirm</button>
      </Dialog>,
    );
    fireEvent.mouseDown(dialog());
    fireEvent.click(backdrop());
    expect(onOpenChange).not.toHaveBeenCalled();
  });
});

describe("Dialog focus restore", () => {
  it("returns focus to the trigger when closed with Escape", async () => {
    const user = userEvent.setup();
    render(<Harness />);
    const trigger = screen.getByRole("button", { name: "Open" });
    await user.click(trigger);
    await user.keyboard("{Escape}");
    expect(trigger).toHaveFocus();
  });

  it("restores focus on every reopen", async () => {
    const user = userEvent.setup();
    render(<Harness />);
    const trigger = screen.getByRole("button", { name: "Open" });
    for (let round = 0; round < 2; round++) {
      trigger.focus();
      await user.keyboard("{Enter}");
      expect(screen.getByRole("button", { name: "Confirm" })).toHaveFocus();
      await user.keyboard("{Escape}");
      expect(trigger).toHaveFocus();
    }
  });

  it("restores focus when unmounted while open", () => {
    const outside = outsideButton();
    const { unmount } = render(<Subject open />);
    expect(screen.getByRole("button", { name: "Details" })).toHaveFocus();
    unmount();
    expect(outside).toHaveFocus();
    outside.remove();
  });

  it("restores focus when the dialog was open on mount and then closes", () => {
    const outside = outsideButton();
    const { rerender } = render(<Subject open />);
    rerender(<Subject open={false} />);
    expect(outside).toHaveFocus();
    outside.remove();
  });

  it("does not throw or restore focus to a trigger removed before closing", () => {
    const trigger = outsideButton();
    const { rerender } = render(<Subject open={false} />);
    rerender(<Subject open />);
    trigger.remove();
    expect(() => rerender(<Subject open={false} />)).not.toThrow();
    expect(document.activeElement).toBe(document.body);
  });

  it("does not throw when a focused element inside the dialog is removed before closing", () => {
    const outside = outsideButton();
    const { rerender } = render(<Subject open />);
    expect(screen.getByRole("button", { name: "Details" })).toHaveFocus();
    rerender(<Subject open showDetails={false} />);
    expect(() => rerender(<Subject open={false} showDetails={false} />)).not.toThrow();
    expect(outside).toHaveFocus();
    outside.remove();
  });
});

const options = [
  { value: "apple", label: "Apple" },
  { value: "banana", label: "Banana" },
];

function NestedHarness({ onOuterChange, onInnerChange }: { onOuterChange: (open: boolean) => void; onInnerChange: (open: boolean) => void }) {
  const [outer, setOuter] = useState(true);
  const [inner, setInner] = useState(false);
  return (
    <Dialog
      open={outer}
      onOpenChange={(next) => {
        onOuterChange(next);
        setOuter(next);
      }}
      title="Outer"
    >
      <button onClick={() => setInner(true)}>Open inner</button>
      <Dialog
        open={inner}
        onOpenChange={(next) => {
          onInnerChange(next);
          setInner(next);
        }}
        title="Inner"
      >
        <button>Inner action</button>
      </Dialog>
    </Dialog>
  );
}

describe("Dialog composition", () => {
  it("lets an open Combobox close its list on Escape without closing the dialog", async () => {
    const user = userEvent.setup();
    const onOpenChange = vi.fn();
    function ComboHarness() {
      const [value, setValue] = useState<string | null>(null);
      return (
        <Dialog open onOpenChange={onOpenChange} title="Pick a fruit">
          <Combobox label="Fruit" options={options} value={value} onChange={setValue} />
        </Dialog>
      );
    }
    render(<ComboHarness />);
    const input = screen.getByRole("combobox", { name: "Fruit" });
    await user.keyboard("{ArrowDown}");
    expect(input).toHaveAttribute("aria-expanded", "true");
    await user.keyboard("{Escape}");
    expect(input).toHaveAttribute("aria-expanded", "false");
    expect(onOpenChange).not.toHaveBeenCalled();
    expect(dialog()).toBeInTheDocument();
    await user.keyboard("{Escape}");
    expect(onOpenChange).toHaveBeenCalledTimes(1);
    expect(onOpenChange).toHaveBeenCalledWith(false);
  });

  it("keeps Tab inside the inner dialog when it is rendered among the outer dialog's children", async () => {
    const user = userEvent.setup();
    render(<NestedHarness onOuterChange={() => {}} onInnerChange={() => {}} />);
    await user.click(screen.getByRole("button", { name: "Open inner" }));
    expect(screen.getByRole("button", { name: "Inner action" })).toHaveFocus();
    await user.keyboard("{Tab}");
    expect(screen.getByRole("button", { name: "Inner action" })).toHaveFocus();
    await user.keyboard("{Shift>}{Tab}{/Shift}");
    expect(screen.getByRole("button", { name: "Inner action" })).toHaveFocus();
  });

  it("closes only the inner dialog on Escape", async () => {
    const user = userEvent.setup();
    const onOuterChange = vi.fn();
    const onInnerChange = vi.fn();
    render(<NestedHarness onOuterChange={onOuterChange} onInnerChange={onInnerChange} />);
    await user.click(screen.getByRole("button", { name: "Open inner" }));
    await user.keyboard("{Escape}");
    expect(onInnerChange).toHaveBeenCalledTimes(1);
    expect(onInnerChange).toHaveBeenCalledWith(false);
    expect(onOuterChange).not.toHaveBeenCalled();
    expect(screen.queryByRole("dialog", { name: "Inner" })).not.toBeInTheDocument();
    expect(screen.getByRole("dialog", { name: "Outer" })).toBeInTheDocument();
  });

  it("traps focus only among tabbable elements inside Tabs", async () => {
    const user = userEvent.setup();
    render(
      <Dialog open onOpenChange={() => {}} title="Settings">
        <Tabs defaultValue="advanced">
          <TabList aria-label="Sections">
            <Tab value="general">General</Tab>
            <Tab value="advanced">Advanced</Tab>
          </TabList>
          <TabPanel value="general">
            <button>General action</button>
          </TabPanel>
          <TabPanel value="advanced">
            <button>Advanced action</button>
          </TabPanel>
        </Tabs>
      </Dialog>,
    );
    expect(screen.getByRole("tab", { name: "Advanced" })).toHaveFocus();
    await user.keyboard("{Shift>}{Tab}{/Shift}");
    expect(screen.getByRole("button", { name: "Advanced action" })).toHaveFocus();
    await user.keyboard("{Tab}");
    expect(screen.getByRole("tab", { name: "Advanced" })).toHaveFocus();
  });

  it("keeps focus inside when a press starts on the backdrop and ends inside the dialog", async () => {
    const user = userEvent.setup();
    const onOpenChange = vi.fn();
    function PressHarness() {
      const [open, setOpen] = useState(false);
      return (
        <>
          <button onClick={() => setOpen(true)}>Open</button>
          <Dialog
            open={open}
            onOpenChange={(next) => {
              onOpenChange(next);
              setOpen(next);
            }}
            title="Delete file"
            description="This cannot be undone."
          >
            <button>Confirm</button>
          </Dialog>
        </>
      );
    }
    render(<PressHarness />);
    await user.click(screen.getByRole("button", { name: "Open" }));
    await user.pointer([
      { keys: "[MouseLeft>]", target: backdrop() },
      { target: screen.getByText("This cannot be undone.") },
      { keys: "[/MouseLeft]" },
    ]);
    expect(screen.getByRole("button", { name: "Confirm" })).toHaveFocus();
    expect(onOpenChange).not.toHaveBeenCalled();
    await user.keyboard("{Escape}");
    expect(onOpenChange).toHaveBeenCalledWith(false);
  });

  it("keeps focus on a child that autoFocuses and restores focus to the trigger on close", async () => {
    const user = userEvent.setup();
    function AutoFocusHarness() {
      const [open, setOpen] = useState(false);
      return (
        <>
          <button onClick={() => setOpen(true)}>Open</button>
          <Dialog open={open} onOpenChange={setOpen} title="Rename">
            <input aria-label="Name" />
            <button autoFocus>Save</button>
          </Dialog>
        </>
      );
    }
    render(<AutoFocusHarness />);
    const trigger = screen.getByRole("button", { name: "Open" });
    await user.click(trigger);
    expect(screen.getByRole("button", { name: "Save" })).toHaveFocus();
    await user.keyboard("{Escape}");
    expect(trigger).toHaveFocus();
  });
});

describe("Dialog tab stops", () => {
  it("does not treat a button inside display:none as a tab stop", async () => {
    const user = userEvent.setup();
    render(
      <Dialog open onOpenChange={() => {}} title="Notice">
        <button>Visible</button>
        <button style={{ display: "none" }}>Hidden</button>
      </Dialog>,
    );
    const visible = screen.getByRole("button", { name: "Visible" });
    expect(visible).toHaveFocus();
    await user.keyboard("{Shift>}{Tab}{/Shift}");
    expect(visible).toHaveFocus();
    await user.keyboard("{Tab}");
    expect(visible).toHaveFocus();
  });

  it("counts a radio group as one tab stop when there is no button before it", async () => {
    const user = userEvent.setup();
    render(
      <Dialog open onOpenChange={() => {}} title="Size">
        <input type="radio" name="size" aria-label="Small" defaultChecked />
        <input type="radio" name="size" aria-label="Medium" />
      </Dialog>,
    );
    const small = screen.getByRole("radio", { name: "Small" });
    expect(small).toHaveFocus();
    await user.keyboard("{Tab}");
    expect(small).toHaveFocus();
  });

  it("counts a radio group as one tab stop when a button comes before it", async () => {
    const user = userEvent.setup();
    render(
      <Dialog open onOpenChange={() => {}} title="Size">
        <button>Before</button>
        <input type="radio" name="size" aria-label="Small" defaultChecked />
        <input type="radio" name="size" aria-label="Medium" />
      </Dialog>,
    );
    const before = screen.getByRole("button", { name: "Before" });
    const small = screen.getByRole("radio", { name: "Small" });
    expect(before).toHaveFocus();
    await user.keyboard("{Tab}");
    expect(small).toHaveFocus();
    await user.keyboard("{Tab}");
    expect(before).toHaveFocus();
  });

  it("does not treat a disabled button with tabIndex 0 as the last tab stop", async () => {
    const user = userEvent.setup();
    render(
      <Dialog open onOpenChange={() => {}} title="Confirm">
        <button>Save</button>
        <button disabled tabIndex={0}>
          Discard
        </button>
      </Dialog>,
    );
    const save = screen.getByRole("button", { name: "Save" });
    expect(save).toHaveFocus();
    await user.keyboard("{Tab}");
    expect(save).toHaveFocus();
    await user.keyboard("{Shift>}{Tab}{/Shift}");
    expect(save).toHaveFocus();
  });

  it("makes the summary of a details element the tab stop", async () => {
    const user = userEvent.setup();
    render(
      <Dialog open onOpenChange={() => {}} title="Help">
        <details>
          <summary>More</summary>
          <p>Extra text</p>
        </details>
      </Dialog>,
    );
    const summary = screen.getByText("More");
    expect(summary).toHaveFocus();
    await user.keyboard("{Tab}");
    expect(summary).toHaveFocus();
  });

  it("keeps Tab moving to a contenteditable element instead of cycling back", async () => {
    const user = userEvent.setup();
    render(
      <Dialog open onOpenChange={() => {}} title="Notes">
        <button>x</button>
        <div contentEditable="true" aria-label="Notes body" />
      </Dialog>,
    );
    await user.keyboard("{Tab}");
    expect(screen.getByLabelText("Notes body")).toHaveFocus();
  });

  it("includes iframe and video[controls] in the tab order", async () => {
    const user = userEvent.setup();
    render(
      <Dialog open onOpenChange={() => {}} title="Player">
        <button>x</button>
        <iframe title="f" />
        <video controls />
        <button>y</button>
      </Dialog>,
    );
    const x = screen.getByRole("button", { name: "x" });
    const frame = screen.getByTitle("f");
    const video = document.querySelector("video") as HTMLVideoElement;
    const y = screen.getByRole("button", { name: "y" });
    // jsdom cannot focus a video without tabindex, so assert the trap asks for it instead.
    const focusVideo = vi.spyOn(video, "focus");
    const focusY = vi.spyOn(y, "focus");
    expect(x).toHaveFocus();
    await user.keyboard("{Tab}");
    expect(frame).toHaveFocus();
    await user.keyboard("{Tab}");
    expect(focusVideo).toHaveBeenCalled();
    expect(focusY).not.toHaveBeenCalled();
  });

  it("moves Tab from a non-stop element to the next stop in document order", async () => {
    const user = userEvent.setup();
    render(
      <Dialog open onOpenChange={() => {}} title="Sections">
        <button>x</button>
        <h3 tabIndex={-1}>head</h3>
        <button>y</button>
      </Dialog>,
    );
    const heading = screen.getByRole("heading", { name: "head" });
    heading.focus();
    await user.keyboard("{Tab}");
    expect(screen.getByRole("button", { name: "y" })).toHaveFocus();
  });

  it("moves Shift+Tab from a non-stop element to the previous stop in document order", async () => {
    const user = userEvent.setup();
    render(
      <Dialog open onOpenChange={() => {}} title="Sections">
        <button>x</button>
        <h3 tabIndex={-1}>head</h3>
        <button>y</button>
      </Dialog>,
    );
    screen.getByRole("heading", { name: "head" }).focus();
    await user.keyboard("{Shift>}{Tab}{/Shift}");
    expect(screen.getByRole("button", { name: "x" })).toHaveFocus();
  });
});

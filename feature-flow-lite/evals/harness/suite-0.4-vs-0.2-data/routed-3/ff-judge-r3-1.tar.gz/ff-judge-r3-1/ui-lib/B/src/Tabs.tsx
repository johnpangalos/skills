import {
  createContext,
  useContext,
  useId,
  useLayoutEffect,
  useRef,
  useState,
  type ComponentPropsWithoutRef,
  type KeyboardEvent,
  type RefObject,
} from "react";

export type TabsProps = Omit<ComponentPropsWithoutRef<"div">, "defaultValue"> & {
  /** Controlled selected value. When set, the parent must update it in `onValueChange`. */
  value?: string;
  /** Uncontrolled initial value. Falls back to the first enabled tab when missing or disabled. */
  defaultValue?: string;
  onValueChange?: (value: string) => void;
};

export type TabListProps = Omit<ComponentPropsWithoutRef<"div">, "role"> & {
  "aria-label": string;
};

export type TabProps = Omit<ComponentPropsWithoutRef<"button">, "role" | "type"> & {
  value: string;
  disabled?: boolean;
};

export type TabPanelProps = Omit<ComponentPropsWithoutRef<"div">, "role"> & {
  value: string;
};

type TabsContextValue = {
  baseId: string;
  /** The effective selection: the controlled/uncontrolled value if it is an enabled tab, else the first enabled tab. */
  selected: string | null;
  select: (value: string) => void;
  listRef: RefObject<HTMLDivElement | null>;
  refreshTabs: () => void;
};

const TabsContext = createContext<TabsContextValue | null>(null);

function useTabsContext(component: string): TabsContextValue {
  const context = useContext(TabsContext);
  if (context === null) {
    throw new Error(`<${component}> must be rendered inside <Tabs>.`);
  }
  return context;
}

/** Encodes a value into an id-safe string. Injective: "_" is always encoded. */
function slug(value: string): string {
  return value.replace(/[^A-Za-z0-9-]/g, (char) => `_${char.charCodeAt(0)}_`);
}

function tabId(baseId: string, value: string): string {
  return `${baseId}-tab-${slug(value)}`;
}

function panelId(baseId: string, value: string): string {
  return `${baseId}-panel-${slug(value)}`;
}

/** Enabled tabs in DOM order. */
function getEnabledTabs(list: HTMLElement | null): HTMLButtonElement[] {
  if (list === null) {
    return [];
  }
  return Array.from(list.querySelectorAll<HTMLButtonElement>('[role="tab"]')).filter(
    (tab) => !tab.disabled,
  );
}

/** Index of the tab that Home, End, ArrowLeft or ArrowRight moves to, or null for other keys. */
function getNextIndex(key: string, index: number, count: number): number | null {
  switch (key) {
    case "ArrowRight":
      return (index + 1) % count;
    case "ArrowLeft":
      return (index - 1 + count) % count;
    case "Home":
      return 0;
    case "End":
      return count - 1;
    default:
      return null;
  }
}

export function Tabs({ value: valueProp, defaultValue, onValueChange, ...rest }: TabsProps) {
  const baseId = useId();
  const listRef = useRef<HTMLDivElement>(null);
  const [internalValue, setInternalValue] = useState<string | null>(defaultValue ?? null);
  const [enabledValues, setEnabledValues] = useState<string[]>([]);

  const current = valueProp ?? internalValue;
  const selected =
    current !== null && enabledValues.includes(current) ? current : (enabledValues[0] ?? null);

  const select = (next: string) => {
    if (next === selected) {
      return;
    }
    if (valueProp === undefined) {
      setInternalValue(next);
    }
    onValueChange?.(next);
  };

  // Re-reads the tab order and enabled state from the DOM; the state only changes when the list differs.
  const refreshTabs = () => {
    const next = getEnabledTabs(listRef.current).map((tab) => tab.dataset.value ?? "");
    setEnabledValues((prev) => (JSON.stringify(prev) === JSON.stringify(next) ? prev : next));
  };

  return (
    <TabsContext.Provider value={{ baseId, selected, select, listRef, refreshTabs }}>
      <div {...rest} />
    </TabsContext.Provider>
  );
}

export function TabList({ onKeyDown, ...rest }: TabListProps) {
  const { listRef, select, refreshTabs } = useTabsContext("TabList");

  useLayoutEffect(() => {
    refreshTabs();
  });

  function handleKeyDown(event: KeyboardEvent<HTMLDivElement>) {
    onKeyDown?.(event);
    const tabs = getEnabledTabs(listRef.current);
    const index = tabs.indexOf(event.target as HTMLButtonElement);
    if (index === -1) {
      return;
    }
    const nextIndex = getNextIndex(event.key, index, tabs.length);
    if (nextIndex === null) {
      return;
    }
    event.preventDefault();
    const next = tabs[nextIndex];
    next.focus();
    select(next.dataset.value ?? "");
  }

  return (
    <div
      {...rest}
      ref={listRef}
      role="tablist"
      onKeyDown={handleKeyDown}
    />
  );
}

export function Tab({ value, disabled = false, onClick, ...rest }: TabProps) {
  const { baseId, selected, select, refreshTabs } = useTabsContext("Tab");
  const isSelected = value === selected;

  useLayoutEffect(() => {
    refreshTabs();
  });

  return (
    <button
      {...rest}
      type="button"
      role="tab"
      id={tabId(baseId, value)}
      data-value={value}
      aria-selected={isSelected}
      aria-controls={panelId(baseId, value)}
      tabIndex={isSelected ? 0 : -1}
      disabled={disabled}
      onClick={(event) => {
        onClick?.(event);
        select(value);
      }}
    />
  );
}

export function TabPanel({ value, ...rest }: TabPanelProps) {
  const { baseId, selected } = useTabsContext("TabPanel");

  return (
    <div
      {...rest}
      role="tabpanel"
      id={panelId(baseId, value)}
      aria-labelledby={tabId(baseId, value)}
      tabIndex={0}
      hidden={value !== selected}
    />
  );
}

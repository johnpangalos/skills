import {
  createContext,
  useCallback,
  useContext,
  useId,
  useLayoutEffect,
  useRef,
  useState,
  type ButtonHTMLAttributes,
  type FocusEvent,
  type HTMLAttributes,
  type KeyboardEvent,
  type MouseEvent,
  type ReactNode,
} from "react";

interface TabsContextValue {
  baseId: string;
  selected: string | null;
  select: (value: string) => void;
  register: (value: string, disabled: boolean) => void;
  unregister: (value: string) => void;
  // Set by a mouse press on a tab and consumed by the focus that press causes; keyboard navigation clears it.
  pointerFocus: { current: boolean };
}

const TabsContext = createContext<TabsContextValue | null>(null);

function useTabsContext(component: string): TabsContextValue {
  const context = useContext(TabsContext);
  if (!context) {
    throw new Error(`${component} must be used inside <Tabs>`);
  }
  return context;
}

function tabId(baseId: string, value: string): string {
  return `${baseId}-tab-${encodeURIComponent(value)}`;
}

function panelId(baseId: string, value: string): string {
  return `${baseId}-panel-${encodeURIComponent(value)}`;
}

function targetTab(key: string, tabs: HTMLButtonElement[], index: number): HTMLButtonElement | undefined {
  switch (key) {
    case "ArrowRight":
      return tabs[(index + 1) % tabs.length];
    case "ArrowLeft":
      return tabs[(index - 1 + tabs.length) % tabs.length];
    case "Home":
      return tabs[0];
    case "End":
      return tabs[tabs.length - 1];
    default:
      return undefined;
  }
}

export interface TabsProps extends Omit<HTMLAttributes<HTMLDivElement>, "defaultValue"> {
  /** Initially selected tab value when uncontrolled. */
  defaultValue?: string;
  /** Selected tab value when controlled. */
  value?: string;
  /** Called with the new value whenever the user changes the selected tab. */
  onValueChange?: (value: string) => void;
  children: ReactNode;
}

export function Tabs({ defaultValue, value, onValueChange, children, ...rest }: TabsProps) {
  const baseId = useId();
  const [uncontrolled, setUncontrolled] = useState(defaultValue);
  const [tabs, setTabs] = useState<ReadonlyMap<string, boolean>>(() => new Map());
  const pointerFocus = useRef(false);

  const requested = value ?? uncontrolled;
  const enabled = [...tabs].filter(([, disabled]) => !disabled).map(([tabValue]) => tabValue);
  const selected = requested !== undefined && enabled.includes(requested) ? requested : (enabled[0] ?? null);

  const register = useCallback((tabValue: string, disabled: boolean) => {
    setTabs((previous) => (previous.get(tabValue) === disabled ? previous : new Map(previous).set(tabValue, disabled)));
  }, []);

  const unregister = useCallback((tabValue: string) => {
    setTabs((previous) => {
      const next = new Map(previous);
      next.delete(tabValue);
      return next;
    });
  }, []);

  function select(next: string) {
    if (next === selected) {
      return;
    }
    if (value === undefined) {
      setUncontrolled(next);
    }
    onValueChange?.(next);
  }

  const context: TabsContextValue = { baseId, selected, select, register, unregister, pointerFocus };

  return (
    <TabsContext.Provider value={context}>
      <div {...rest}>{children}</div>
    </TabsContext.Provider>
  );
}

export interface TabListProps extends HTMLAttributes<HTMLDivElement> {
  "aria-label": string;
  children: ReactNode;
}

export function TabList({ children, onKeyDown, ...rest }: TabListProps) {
  const { pointerFocus } = useTabsContext("TabList");
  const ref = useRef<HTMLDivElement>(null);

  function handleKeyDown(event: KeyboardEvent<HTMLDivElement>) {
    onKeyDown?.(event);
    const tabs = Array.from(ref.current?.querySelectorAll<HTMLButtonElement>('[role="tab"]:not(:disabled)') ?? []);
    const next = targetTab(event.key, tabs, tabs.indexOf(event.target as HTMLButtonElement));
    if (!next) {
      return;
    }
    event.preventDefault();
    pointerFocus.current = false;
    next.focus();
  }

  return (
    <div {...rest} ref={ref} role="tablist" aria-orientation="horizontal" onKeyDown={handleKeyDown}>
      {children}
    </div>
  );
}

export interface TabProps extends Omit<ButtonHTMLAttributes<HTMLButtonElement>, "value"> {
  value: string;
  disabled?: boolean;
}

export function Tab({ value, disabled = false, onClick, onFocus, onMouseDown, ...rest }: TabProps) {
  const { baseId, selected, select, register, unregister, pointerFocus } = useTabsContext("Tab");

  useLayoutEffect(() => {
    register(value, disabled);
  }, [register, value, disabled]);

  useLayoutEffect(() => () => {
    unregister(value);
  }, [unregister, value]);

  const isSelected = value === selected;

  // A mouse press focuses the tab before its click; that focus must not select, the click does.
  function handleMouseDown(event: MouseEvent<HTMLButtonElement>) {
    onMouseDown?.(event);
    pointerFocus.current = true;
  }

  // Every click selects, even on a tab that already has focus.
  function handleClick(event: MouseEvent<HTMLButtonElement>) {
    onClick?.(event);
    pointerFocus.current = false;
    select(value);
  }

  // Selection follows keyboard focus: arrow keys move focus, and focus selects.
  function handleFocus(event: FocusEvent<HTMLButtonElement>) {
    onFocus?.(event);
    if (!pointerFocus.current) {
      select(value);
    }
    pointerFocus.current = false;
  }

  return (
    <button
      {...rest}
      type="button"
      role="tab"
      id={tabId(baseId, value)}
      aria-controls={panelId(baseId, value)}
      aria-selected={isSelected}
      tabIndex={isSelected ? 0 : -1}
      disabled={disabled}
      onMouseDown={handleMouseDown}
      onClick={handleClick}
      onFocus={handleFocus}
    />
  );
}

export interface TabPanelProps extends HTMLAttributes<HTMLDivElement> {
  value: string;
  children?: ReactNode;
}

export function TabPanel({ value, children, ...rest }: TabPanelProps) {
  const { baseId, selected } = useTabsContext("TabPanel");

  return (
    <div
      {...rest}
      role="tabpanel"
      id={panelId(baseId, value)}
      aria-labelledby={tabId(baseId, value)}
      tabIndex={0}
      hidden={value !== selected}
    >
      {children}
    </div>
  );
}

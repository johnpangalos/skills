import { act, render, screen, waitFor } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { useState, type ReactNode } from "react";
import { Dialog } from "./Dialog";
import { Tab, TabList, TabPanel, Tabs } from "./Tabs";

function Page({ children, onOpenChange, description }: { children?: ReactNode; onOpenChange?: (open: boolean) => void; description?: string }) {
  const [open, setOpen] = useState(false);
  return (
    <>
      <button onClick={() => setOpen(true)}>Open</button>
      <Dialog
        open={open}
        onOpenChange={(next) => {
          onOpenChange?.(next);
          setOpen(next);
        }}
        title="Settings"
        description={description}
      >
        {children ?? <button>Save</button>}
      </Dialog>
    </>
  );
}

function backdrop(): HTMLElement {
  const element = document.querySelector<HTMLElement>("[data-backdrop]");
  if (!element) {
    throw new Error("backdrop not rendered");
  }
  return element;
}

describe("Dialog", () => {
  it("renders nothing when closed", () => {
    render(
      <Dialog open={false} onOpenChange={() => {}} title="Hidden">
        <button>Inside</button>
      </Dialog>,
    );
    expect(screen.queryByRole("dialog")).not.toBeInTheDocument();
    expect(document.querySelector("[data-backdrop]")).toBeNull();
  });

  it("renders a labelled modal dialog and backdrop in a portal", () => {
    const { container } = render(
      <Dialog open onOpenChange={() => {}} title="Confirm delete">
        <button>Delete</button>
      </Dialog>,
    );
    const dialog = screen.getByRole("dialog", { name: "Confirm delete" });
    expect(dialog).toHaveAttribute("aria-modal", "true");
    expect(container).not.toContainElement(dialog);
    expect(dialog.parentElement).toBe(document.body);
    expect(backdrop()).toBeInTheDocument();
    expect(container).not.toContainElement(backdrop());
  });

  it("omits aria-describedby without a description and links it when present", () => {
    const { unmount } = render(
      <Dialog open onOpenChange={() => {}} title="Plain">
        <button>OK</button>
      </Dialog>,
    );
    expect(screen.getByRole("dialog")).not.toHaveAttribute("aria-describedby");
    unmount();

    render(
      <Dialog open onOpenChange={() => {}} title="Described" description="This cannot be undone.">
        <button>OK</button>
      </Dialog>,
    );
    const dialog = screen.getByRole("dialog", { name: "Described" });
    expect(dialog).toHaveAccessibleDescription("This cannot be undone.");
    expect(dialog.getAttribute("aria-describedby")).toBe(screen.getByText("This cannot be undone.").id);
  });

  it("moves focus to the first focusable element on open", async () => {
    render(
      <Dialog open onOpenChange={() => {}} title="Form">
        <input aria-label="Name" />
        <button>Save</button>
      </Dialog>,
    );
    await waitFor(() => expect(screen.getByRole("textbox", { name: "Name" })).toHaveFocus());
  });

  it("focuses the dialog container when it has no focusable children", async () => {
    render(
      <Dialog open onOpenChange={() => {}} title="Notice">
        <p>Just text</p>
      </Dialog>,
    );
    await waitFor(() => expect(screen.getByRole("dialog")).toHaveFocus());
  });

  it("wraps Tab from last to first and Shift+Tab from first to last", async () => {
    const user = userEvent.setup();
    render(
      <Dialog open onOpenChange={() => {}} title="Two buttons">
        <button>First</button>
        <button>Last</button>
      </Dialog>,
    );
    await waitFor(() => expect(screen.getByRole("button", { name: "First" })).toHaveFocus());
    await user.tab();
    expect(screen.getByRole("button", { name: "Last" })).toHaveFocus();
    await user.tab();
    expect(screen.getByRole("button", { name: "First" })).toHaveFocus();
    await user.tab({ shift: true });
    expect(screen.getByRole("button", { name: "Last" })).toHaveFocus();
  });

  it("keeps focus on the dialog when Tab is pressed with no focusable children", async () => {
    const user = userEvent.setup();
    render(
      <Dialog open onOpenChange={() => {}} title="Notice">
        <p>Just text</p>
      </Dialog>,
    );
    await waitFor(() => expect(screen.getByRole("dialog")).toHaveFocus());
    await user.tab();
    expect(screen.getByRole("dialog")).toHaveFocus();
    await user.tab({ shift: true });
    expect(screen.getByRole("dialog")).toHaveFocus();
  });

  it("excludes disabled controls and tabindex=-1 elements from the tab cycle", async () => {
    const user = userEvent.setup();
    render(
      <Dialog open onOpenChange={() => {}} title="Nested">
        <button>First</button>
        <button disabled>Disabled</button>
        <div tabIndex={-1}>
          <button tabIndex={-1}>Hidden</button>
        </div>
        <button>Last</button>
      </Dialog>,
    );
    await waitFor(() => expect(screen.getByRole("button", { name: "First" })).toHaveFocus());
    await user.tab();
    expect(screen.getByRole("button", { name: "Last" })).toHaveFocus();
    await user.tab();
    expect(screen.getByRole("button", { name: "First" })).toHaveFocus();
  });

  it("calls onOpenChange(false) on Escape", async () => {
    const user = userEvent.setup();
    const onOpenChange = vi.fn();
    render(
      <Dialog open onOpenChange={onOpenChange} title="Esc">
        <button>OK</button>
      </Dialog>,
    );
    await waitFor(() => expect(screen.getByRole("button", { name: "OK" })).toHaveFocus());
    await user.keyboard("{Escape}");
    expect(onOpenChange).toHaveBeenCalledTimes(1);
    expect(onOpenChange).toHaveBeenCalledWith(false);
  });

  it("calls onOpenChange(false) on Escape while focus is in an input", async () => {
    const user = userEvent.setup();
    const onOpenChange = vi.fn();
    render(
      <Dialog open onOpenChange={onOpenChange} title="Rename">
        <input aria-label="Title" />
      </Dialog>,
    );
    await user.click(screen.getByRole("textbox", { name: "Title" }));
    await user.keyboard("{Escape}");
    expect(onOpenChange).toHaveBeenCalledWith(false);
  });

  it("closes on a click on the backdrop", async () => {
    const user = userEvent.setup();
    const onOpenChange = vi.fn();
    render(
      <Dialog open onOpenChange={onOpenChange} title="Backdrop">
        <button>OK</button>
      </Dialog>,
    );
    await user.click(backdrop());
    expect(onOpenChange).toHaveBeenCalledTimes(1);
    expect(onOpenChange).toHaveBeenCalledWith(false);
  });

  it("does not close on a click inside the content", async () => {
    const user = userEvent.setup();
    const onOpenChange = vi.fn();
    render(
      <Dialog open onOpenChange={onOpenChange} title="Inside">
        <button>OK</button>
      </Dialog>,
    );
    await user.click(screen.getByRole("button", { name: "OK" }));
    await user.click(screen.getByRole("dialog"));
    expect(onOpenChange).not.toHaveBeenCalled();
  });

  it("does not close when a press starts inside the content and ends on the backdrop", async () => {
    const user = userEvent.setup();
    const onOpenChange = vi.fn();
    render(
      <Dialog open onOpenChange={onOpenChange} title="Drag">
        <button>OK</button>
      </Dialog>,
    );
    await user.pointer([
      { keys: "[MouseLeft>]", target: screen.getByRole("button", { name: "OK" }) },
      { target: backdrop() },
      { keys: "[/MouseLeft]", target: backdrop() },
    ]);
    expect(onOpenChange).not.toHaveBeenCalled();
  });

  it("returns focus to the opener when closed with Escape", async () => {
    const user = userEvent.setup();
    render(<Page />);
    await user.click(screen.getByRole("button", { name: "Open" }));
    await waitFor(() => expect(screen.getByRole("button", { name: "Save" })).toHaveFocus());
    await user.keyboard("{Escape}");
    expect(screen.queryByRole("dialog")).not.toBeInTheDocument();
    expect(screen.getByRole("button", { name: "Open" })).toHaveFocus();
  });

  it("returns focus to the opener when unmounted while open", async () => {
    function Host({ show }: { show: boolean }) {
      return (
        <>
          <button>Opener</button>
          {show ? (
            <Dialog open onOpenChange={() => {}} title="Gone">
              <button>Inside</button>
            </Dialog>
          ) : null}
        </>
      );
    }
    const { rerender } = render(<Host show={false} />);
    act(() => screen.getByRole("button", { name: "Opener" }).focus());
    rerender(<Host show />);
    await waitFor(() => expect(screen.getByRole("button", { name: "Inside" })).toHaveFocus());
    rerender(<Host show={false} />);
    expect(screen.getByRole("button", { name: "Opener" })).toHaveFocus();
  });

  it("returns focus to the opener on Escape when a child with autoFocus is shown", async () => {
    const user = userEvent.setup();
    render(
      <Page>
        <input autoFocus aria-label="Name" />
      </Page>,
    );
    const opener = screen.getByRole("button", { name: "Open" });
    await user.click(opener);
    expect(screen.getByRole("textbox", { name: "Name" })).toHaveFocus();
    await user.keyboard("{Escape}");
    expect(opener).toHaveFocus();
  });

  it("keeps Tab inside the dialog when focus is on a tabindex=-1 element between controls", async () => {
    const user = userEvent.setup();
    render(
      <Dialog open onOpenChange={() => {}} title="Between">
        <button>First</button>
        <div tabIndex={-1}>Middle</div>
        <button>Last</button>
      </Dialog>,
    );
    const middle = screen.getByText("Middle");
    middle.focus();
    await user.tab();
    expect(screen.getByRole("button", { name: "Last" })).toHaveFocus();
    middle.focus();
    await user.tab({ shift: true });
    expect(screen.getByRole("button", { name: "First" })).toHaveFocus();
  });

  it("skips focusable elements inside hidden ancestors and display:none", async () => {
    const user = userEvent.setup();
    render(
      <Dialog open onOpenChange={() => {}} title="Hidden content">
        <button>First</button>
        <div hidden>
          <button>Hidden</button>
        </div>
        <div style={{ display: "none" }}>
          <button>Styled</button>
        </div>
        <button>Last</button>
      </Dialog>,
    );
    await waitFor(() => expect(screen.getByRole("button", { name: "First" })).toHaveFocus());
    await user.tab();
    expect(screen.getByRole("button", { name: "Last" })).toHaveFocus();
    await user.tab();
    expect(screen.getByRole("button", { name: "First" })).toHaveFocus();
  });

  it("keeps focus inside the dialog when a backdrop press is refused by the parent", async () => {
    const user = userEvent.setup();
    const onOpenChange = vi.fn();
    render(
      <Dialog open onOpenChange={onOpenChange} title="Stay">
        <button>Save</button>
      </Dialog>,
    );
    const save = screen.getByRole("button", { name: "Save" });
    await waitFor(() => expect(save).toHaveFocus());
    await user.click(backdrop());
    expect(onOpenChange).toHaveBeenCalledWith(false);
    expect(save).toHaveFocus();
  });

  it("applies backdropProps to the backdrop", () => {
    render(
      <Dialog open onOpenChange={() => {}} title="Styled" backdropProps={{ className: "scrim" }}>
        <button>OK</button>
      </Dialog>,
    );
    expect(backdrop()).toHaveClass("scrim");
    expect(backdrop()).toHaveAttribute("data-backdrop");
  });

  it("moves focus to the selected tab when Tabs is inside the dialog", async () => {
    render(
      <Dialog open onOpenChange={() => {}} title="Pages">
        <Tabs defaultValue="two">
          <TabList aria-label="Pages">
            <Tab value="one">One</Tab>
            <Tab value="two">Two</Tab>
          </TabList>
          <TabPanel value="one">Panel one</TabPanel>
          <TabPanel value="two">Panel two</TabPanel>
        </Tabs>
      </Dialog>,
    );
    await waitFor(() => expect(screen.getByRole("tab", { name: "Two" })).toHaveFocus());
  });

  it("keeps Tab inside an inner dialog nested in an open dialog", async () => {
    const user = userEvent.setup();
    render(
      <Dialog open onOpenChange={() => {}} title="Outer">
        <button>Outer button</button>
        <Dialog open onOpenChange={() => {}} title="Inner">
          <button>Inner one</button>
          <button>Inner two</button>
        </Dialog>
      </Dialog>,
    );
    // Let both dialogs' deferred initial focus run before choosing the focused control.
    await new Promise((resolve) => requestAnimationFrame(resolve));
    screen.getByRole("button", { name: "Inner one" }).focus();
    await user.tab();
    expect(screen.getByRole("button", { name: "Inner two" })).toHaveFocus();
    expect(screen.getByRole("button", { name: "Outer button" })).not.toHaveFocus();
  });

  it("gives instances on one page distinct ids", () => {
    render(
      <>
        <Dialog open onOpenChange={() => {}} title="One">
          <button>A</button>
        </Dialog>
        <Dialog open onOpenChange={() => {}} title="Two">
          <button>B</button>
        </Dialog>
      </>,
    );
    const [first, second] = screen.getAllByRole("dialog");
    expect(first.getAttribute("aria-labelledby")).not.toBe(second.getAttribute("aria-labelledby"));
  });
});

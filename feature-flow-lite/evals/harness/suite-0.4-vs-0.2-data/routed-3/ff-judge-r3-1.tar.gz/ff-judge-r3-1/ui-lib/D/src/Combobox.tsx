import {
  useEffect,
  useId,
  useState,
  type ChangeEvent,
  type FocusEvent,
  type InputHTMLAttributes,
  type KeyboardEvent,
  type MouseEvent,
} from "react";

export interface ComboboxOption {
  value: string;
  label: string;
  disabled?: boolean;
}

export interface ComboboxProps extends Omit<InputHTMLAttributes<HTMLInputElement>, "value" | "onChange"> {
  label: string;
  options: ComboboxOption[];
  /** Value of the selected option, or null for no selection. */
  value: string | null;
  onChange: (value: string | null) => void;
  placeholder?: string;
}

export function Combobox({
  label,
  options,
  value,
  onChange,
  placeholder,
  onKeyDown,
  onBlur,
  ...rest
}: ComboboxProps) {
  const baseId = useId();
  // Text the user has typed or chosen; null means "show the selected option's label".
  const [text, setText] = useState<string | null>(null);
  // Text used for filtering; only set while typing, so reopening shows every option.
  const [filter, setFilter] = useState("");
  const [open, setOpen] = useState(false);
  const [activeValue, setActiveValue] = useState<string | null>(null);

  const selectedLabel = options.find((option) => option.value === value)?.label ?? "";
  const visible = options.filter((option) => option.label.toLowerCase().includes(filter.toLowerCase()));
  const enabled = visible.filter((option) => !option.disabled);
  const active = enabled.find((option) => option.value === activeValue) ?? null;

  // A value change from outside replaces whatever text was typed.
  useEffect(() => {
    setText(null);
  }, [value]);

  const labelId = `${baseId}-label`;
  const inputId = `${baseId}-input`;
  const listboxId = `${baseId}-listbox`;

  function optionId(optionValue: string): string {
    return `${baseId}-option-${encodeURIComponent(optionValue)}`;
  }

  function close() {
    setOpen(false);
    setFilter("");
    setActiveValue(null);
  }

  // The input shows the selected label again, so a parent that ignores onChange keeps the old text.
  function choose(option: ComboboxOption) {
    onChange(option.value);
    setText(null);
    close();
  }

  function move(step: 1 | -1) {
    setOpen(true);
    if (enabled.length === 0) {
      setActiveValue(null);
      return;
    }
    const index = enabled.findIndex((option) => option === active);
    const next =
      index === -1
        ? (step === 1 ? 0 : enabled.length - 1)
        : (index + step + enabled.length) % enabled.length;
    setActiveValue(enabled[next].value);
  }

  function handleChange(event: ChangeEvent<HTMLInputElement>) {
    setText(event.target.value);
    setFilter(event.target.value);
    setOpen(true);
    setActiveValue(null);
  }

  function handleKeyDown(event: KeyboardEvent<HTMLInputElement>) {
    onKeyDown?.(event);
    switch (event.key) {
      case "ArrowDown":
        event.preventDefault();
        move(1);
        break;
      case "ArrowUp":
        event.preventDefault();
        move(-1);
        break;
      case "Enter":
        if (active) {
          event.preventDefault();
          choose(active);
        } else if (text === "" && value !== null) {
          // Enter after clearing the input clears the selection.
          onChange(null);
          setText(null);
          close();
        }
        break;
      case "Escape":
        if (open) {
          event.preventDefault();
          event.stopPropagation();
          setText(null);
          close();
        }
        break;
    }
  }

  function handleBlur(event: FocusEvent<HTMLInputElement>) {
    onBlur?.(event);
    // Blurring after clearing the input clears the selection.
    if (text === "" && value !== null) {
      onChange(null);
    }
    setText(null);
    close();
  }

  function handleOptionClick(option: ComboboxOption) {
    if (!option.disabled) {
      choose(option);
    }
  }

  return (
    <>
      <label id={labelId} htmlFor={inputId}>
        {label}
      </label>
      <input
        {...rest}
        id={inputId}
        type="text"
        role="combobox"
        autoComplete="off"
        aria-autocomplete="list"
        aria-expanded={open}
        aria-controls={listboxId}
        aria-activedescendant={active ? optionId(active.value) : undefined}
        placeholder={placeholder}
        value={text ?? selectedLabel}
        onChange={handleChange}
        onKeyDown={handleKeyDown}
        onBlur={handleBlur}
      />
      {/* Keep focus in the input when an option is pressed, so blur does not close the popup first. */}
      <ul
        id={listboxId}
        role="listbox"
        aria-labelledby={labelId}
        hidden={!open}
        onMouseDown={(event: MouseEvent<HTMLUListElement>) => event.preventDefault()}
      >
        {visible.map((option) => (
          <li
            key={option.value}
            id={optionId(option.value)}
            role="option"
            aria-selected={option.value === value}
            aria-disabled={option.disabled || undefined}
            data-active={option === active || undefined}
            onClick={() => handleOptionClick(option)}
          >
            {option.label}
          </li>
        ))}
        {visible.length === 0 ? <li role="presentation">No results</li> : null}
      </ul>
    </>
  );
}

import {
  useId,
  useState,
  type ChangeEvent,
  type ComponentPropsWithoutRef,
  type FocusEvent,
  type KeyboardEvent,
} from "react";

export type ComboboxOption = {
  value: string;
  label: string;
  disabled?: boolean;
};

export type ComboboxProps = Omit<ComponentPropsWithoutRef<"input">, "value" | "onChange" | "role" | "label"> & {
  label: string;
  options: ComboboxOption[];
  value: string | null;
  onChange: (value: string | null) => void;
};

// Steps through the options in list order to the next (1) or previous (-1) enabled one, wrapping at either end.
// The current option may be disabled. With no current option, 1 picks the first enabled and -1 the last.
// Returns null when every option is disabled.
function stepActive(options: ComboboxOption[], current: string | null, step: 1 | -1): string | null {
  if (options.every((option) => option.disabled)) return null;
  const count = options.length;
  const found = options.findIndex((option) => option.value === current);
  let index = found !== -1 ? found : step === 1 ? -1 : count;
  do {
    index = (index + step + count) % count;
  } while (options[index].disabled);
  return options[index].value;
}

export function Combobox({
  label,
  options,
  value,
  onChange,
  onKeyDown: onConsumerKeyDown,
  onBlur: onConsumerBlur,
  ...rest
}: ComboboxProps) {
  const baseId = useId();
  const labelId = `${baseId}-label`;
  const inputId = `${baseId}-input`;
  const listboxId = `${baseId}-listbox`;

  // query is null while the input shows the selected label; it is set only while the user is typing.
  const [query, setQuery] = useState<string | null>(null);
  const [isOpen, setIsOpen] = useState(false);
  const [activeValue, setActiveValue] = useState<string | null>(null);
  const [previousValue, setPreviousValue] = useState(value);

  // A value changed by the parent replaces any typed text with the new label.
  if (value !== previousValue) {
    setPreviousValue(value);
    setQuery(null);
  }

  const selectedLabel = options.find((option) => option.value === value)?.label ?? "";
  const needle = (query ?? "").toLowerCase();
  const visible = options.filter((option) => option.label.toLowerCase().includes(needle));
  // A disabled option is never active, even if it was active before it became disabled.
  const active = visible.find((option) => !option.disabled && option.value === activeValue);
  const optionDomId = (option: ComboboxOption) => `${baseId}-option-${options.indexOf(option)}`;

  const close = () => {
    setIsOpen(false);
    setQuery(null);
    setActiveValue(null);
  };

  const choose = (option: ComboboxOption) => {
    if (option.disabled) return;
    onChange(option.value);
    close();
  };

  const onInputChange = (event: ChangeEvent<HTMLInputElement>) => {
    setQuery(event.target.value);
    setActiveValue(null);
    setIsOpen(true);
  };

  const onKeyDown = (event: KeyboardEvent<HTMLInputElement>) => {
    onConsumerKeyDown?.(event);
    if (event.defaultPrevented) return;
    if (event.key === "ArrowDown" || event.key === "ArrowUp") {
      event.preventDefault();
      setIsOpen(true);
      setActiveValue(stepActive(visible, activeValue, event.key === "ArrowDown" ? 1 : -1));
    } else if (event.key === "Enter" && isOpen) {
      // Enter never submits a surrounding form while the popup is open.
      event.preventDefault();
      if (active) choose(active);
    } else if (event.key === "Escape" && isOpen) {
      event.preventDefault();
      close();
    }
  };

  // Clearing the text and leaving the field clears the value; any other blur restores the selected label.
  const onBlur = (event: FocusEvent<HTMLInputElement>) => {
    onConsumerBlur?.(event);
    if (query === "" && value !== null) onChange(null);
    close();
  };

  return (
    <>
      <label id={labelId} htmlFor={inputId}>
        {label}
      </label>
      <input
        {...rest}
        id={inputId}
        role="combobox"
        autoComplete="off"
        aria-autocomplete="list"
        aria-expanded={isOpen}
        aria-controls={listboxId}
        aria-activedescendant={active ? optionDomId(active) : undefined}
        value={query ?? selectedLabel}
        onChange={onInputChange}
        onKeyDown={onKeyDown}
        onBlur={onBlur}
      />
      <ul
        id={listboxId}
        role="listbox"
        aria-labelledby={labelId}
        hidden={!isOpen}
        onMouseDown={(event) => event.preventDefault()}
      >
        {isOpen &&
          visible.map((option) => (
            <li
              key={option.value}
              id={optionDomId(option)}
              role="option"
              aria-selected={option.value === value}
              aria-disabled={option.disabled || undefined}
              data-active={option === active || undefined}
              onClick={() => choose(option)}
            >
              {option.label}
            </li>
          ))}
      </ul>
      {isOpen && visible.length === 0 && <p role="status">No results</p>}
    </>
  );
}

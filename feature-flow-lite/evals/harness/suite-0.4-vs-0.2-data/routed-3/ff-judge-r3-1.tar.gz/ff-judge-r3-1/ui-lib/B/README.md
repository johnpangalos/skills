# @acme/ui

Accessible React components: Tabs, Dialog and Combobox. Each follows its WAI-ARIA Authoring
Practices pattern, takes no CSS, and passes extra props (including `className`) to its main element.

Run `pnpm test` for the tests and `pnpm typecheck` for the type check.

```tsx
import { Combobox, Dialog, Tab, TabList, TabPanel, Tabs } from "@acme/ui";

<Tabs defaultValue="profile">
  <TabList aria-label="Settings">
    <Tab value="profile">Profile</Tab>
    <Tab value="billing">Billing</Tab>
  </TabList>
  <TabPanel value="profile">Profile form</TabPanel>
  <TabPanel value="billing">Billing form</TabPanel>
</Tabs>;

<Dialog open={open} onOpenChange={setOpen} title="Delete project" description="This cannot be undone.">
  <button type="button" onClick={() => setOpen(false)}>Cancel</button>
</Dialog>;

<Combobox
  label="Fruit"
  options={[{ value: "apple", label: "Apple" }, { value: "pear", label: "Pear", disabled: true }]}
  value={fruit}
  onChange={setFruit}
  placeholder="Search fruit"
/>;
```

## Tabs

Automatic activation: moving focus with the arrow keys selects the tab. Tab order and
wrap-around come from the DOM order of the tabs. The selection is the `value` prop when given
(controlled), otherwise internal state seeded by `defaultValue` (uncontrolled). If the selected
value is missing or disabled, the first enabled tab is selected. Re-selecting the selected tab
does not call `onValueChange`.

| Name | Type | Default | Description |
| --- | --- | --- | --- |
| `value` | `string` (Tabs) | — | Controlled selected value. The parent must update it in `onValueChange`. |
| `defaultValue` | `string` (Tabs) | first enabled tab | Initial value when uncontrolled. |
| `onValueChange` | `(value: string) => void` (Tabs) | — | Called when the user selects a tab, in both modes. |
| `aria-label` | `string` (TabList) | required | Accessible name for the tablist. |
| `value` | `string` (Tab, TabPanel) | required | Identifies the tab and its panel. |
| `disabled` | `boolean` (Tab) | `false` | Disables the tab: it cannot be clicked or focused by the arrow keys. |
| `className` | `string` | — | Applied to the Tabs wrapper, TabList, Tab, or TabPanel element. |

Using `Tab`, `TabList` or `TabPanel` outside `<Tabs>` throws.

| Key | Action |
| --- | --- |
| `ArrowRight` / `ArrowLeft` | Next / previous enabled tab, wrapping at both ends. Selects it. |
| `Home` / `End` | First / last enabled tab. Selects it. |
| `Tab` | Moves from the tablist to the selected panel. |

## Dialog

Modal dialog rendered into `document.body` through a portal, with a backdrop. Focus moves to
the first focusable element on open (or to the dialog itself if there is none) and returns to
the previously focused element on close. Tab and Shift+Tab are trapped inside. Disabled
controls, `tabindex="-1"` elements, and elements that are not rendered are skipped. An element is
not rendered when it or an ancestor up to the dialog has the `hidden` attribute, is `inert`, or has
`display: none`, or when its own computed `visibility` is `hidden`. Visibility is inherited, so a
child with `visibility: visible` under a hidden parent is still focusable. The dialog never
closes itself; it only calls `onOpenChange(false)`. Body scroll is not locked.

| Name | Type | Default | Description |
| --- | --- | --- | --- |
| `open` | `boolean` | required | Whether the dialog is shown. Nothing is rendered when `false`. |
| `onOpenChange` | `(open: boolean) => void` | required | Called with `false` on Escape or a backdrop click. |
| `title` | `ReactNode` | required | Rendered as an `h2` and used as the accessible name. |
| `description` | `ReactNode` | — | Rendered as a paragraph and referenced by `aria-describedby`. Omitted when `undefined`, `null` or `false`. |
| `className` | `string` | — | Applied to the dialog element. |

| Key | Action |
| --- | --- |
| `Escape` | Calls `onOpenChange(false)`. |
| `Tab` / `Shift+Tab` | Moves focus forward / backward, wrapping inside the dialog. |

A click on the backdrop calls `onOpenChange(false)`. A click inside the dialog, or a drag that
starts inside and ends on the backdrop, does not.

## Combobox

Text input with a listbox popup (list autocomplete). Typing or clicking the input opens the
listbox and filters options by a case-insensitive substring match on the label. The input shows
the selected option's label when not editing. Choosing an option calls `onChange(value)`.
Clearing the text does not call `onChange(null)`: leaving the input or pressing Escape restores
the selected label. A `value` that matches no option shows an empty input. When the parent
changes `value`, any typed text is discarded and the input shows the new option's label.

When nothing matches, a "No results" message is shown beside the listbox rather than inside it.
An active option that is removed from the visible list is cleared, so Enter does not choose it.

Arrow navigation wraps at both ends and skips disabled options. Escape while the listbox is open
closes it and stops the event from reaching an enclosing Dialog. Escape while it is closed is not
handled, so an enclosing Dialog can close.

| Name | Type | Default | Description |
| --- | --- | --- | --- |
| `label` | `string` | required | Visible label, associated with the input. Also names the listbox. |
| `options` | `ComboboxOption[]` | required | Options with `value`, `label` and optional `disabled`. |
| `value` | `string \| null` | required | Selected option value, or `null` for no selection. |
| `onChange` | `(value: string \| null) => void` | required | Called when the user chooses an enabled option. Never called for clearing. |
| `placeholder` | `string` | — | Forwarded to the input. |
| `className` | `string` | — | Applied to the input. |

| Key | Action |
| --- | --- |
| `ArrowDown` | Opens the listbox if closed; otherwise moves the active option forward (wrapping). |
| `ArrowUp` | Moves the active option backward (wrapping) while open. |
| `Enter` | While open: chooses the active enabled option, if any, and never submits the form. While closed: native behaviour. |
| `Escape` | While open: closes without calling `onChange` and restores the selected label. |

Focus stays in the input. The active option is exposed through `aria-activedescendant`, and a
`data-active` attribute is set on it for styling. Clicking an enabled option chooses it. Leaving
the input closes the listbox and restores the selected label without calling `onChange`.

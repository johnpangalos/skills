import { useState } from "react";
import { render, screen } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { Tab, TabList, TabPanel, Tabs } from "./Tabs";

function BasicTabs(props: { defaultValue?: string; disabledB?: boolean; onValueChange?: (v: string) => void }) {
  return (
    <Tabs defaultValue={props.defaultValue} onValueChange={props.onValueChange}>
      <TabList aria-label="Sections">
        <Tab value="a">Alpha</Tab>
        <Tab value="b" disabled={props.disabledB}>
          Beta
        </Tab>
        <Tab value="c">Gamma</Tab>
      </TabList>
      <TabPanel value="a">Alpha panel</TabPanel>
      <TabPanel value="b">Beta panel</TabPanel>
      <TabPanel value="c">Gamma panel</TabPanel>
    </Tabs>
  );
}

function ControlledTabs(props: { onValueChange: (v: string) => void; value: string }) {
  return (
    <Tabs value={props.value} onValueChange={props.onValueChange}>
      <TabList aria-label="Sections">
        <Tab value="a">Alpha</Tab>
        <Tab value="b">Beta</Tab>
        <Tab value="c">Gamma</Tab>
      </TabList>
      <TabPanel value="a">Alpha panel</TabPanel>
      <TabPanel value="b">Beta panel</TabPanel>
      <TabPanel value="c">Gamma panel</TabPanel>
    </Tabs>
  );
}

describe("Tabs markup", () => {
  it("renders a tablist with the given label and tabs wired to their panels", () => {
    render(<BasicTabs defaultValue="a" />);
    const list = screen.getByRole("tablist", { name: "Sections" });
    expect(list).toBeInTheDocument();
    const tab = screen.getByRole("tab", { name: "Alpha" });
    expect(tab.tagName).toBe("BUTTON");
    expect(tab).toHaveAttribute("type", "button");
    expect(tab).toHaveAttribute("aria-selected", "true");
    const panel = screen.getByRole("tabpanel", { name: "Alpha" });
    expect(tab).toHaveAttribute("aria-controls", panel.id);
    expect(panel).toHaveAttribute("aria-labelledby", tab.id);
    expect(panel).toHaveAttribute("tabindex", "0");
    expect(panel).toBeVisible();
  });

  it("hides non-selected panels but keeps them in the DOM so aria-controls resolves", () => {
    render(<BasicTabs defaultValue="a" />);
    const gamma = screen.getByRole("tab", { name: "Gamma" });
    const controlled = document.getElementById(gamma.getAttribute("aria-controls")!);
    expect(controlled).not.toBeNull();
    expect(controlled).toHaveAttribute("hidden");
    expect(controlled).toHaveTextContent("Gamma panel");
  });

  it("gives two instances distinct ids", () => {
    render(
      <>
        <BasicTabs defaultValue="a" />
        <BasicTabs defaultValue="a" />
      </>,
    );
    const tabs = screen.getAllByRole("tab", { name: "Alpha" });
    expect(tabs[0].id).not.toBe(tabs[1].id);
  });

  it("forwards className and native props to the wrapper and list", () => {
    render(
      <Tabs className="wrap" data-testid="root">
        <TabList aria-label="Sections" className="list" data-testid="list">
          <Tab value="a">Alpha</Tab>
        </TabList>
      </Tabs>,
    );
    expect(screen.getByTestId("root")).toHaveClass("wrap");
    expect(screen.getByTestId("list")).toHaveClass("list");
  });

  it("throws a clear error when Tab, TabList or TabPanel is used outside Tabs", () => {
    const spy = vi.spyOn(console, "error").mockImplementation(() => {});
    expect(() => render(<Tab value="a">Alpha</Tab>)).toThrow("<Tab> must be rendered inside <Tabs>.");
    expect(() => render(<TabList aria-label="x" />)).toThrow("<TabList> must be rendered inside <Tabs>.");
    expect(() => render(<TabPanel value="a">x</TabPanel>)).toThrow(
      "<TabPanel> must be rendered inside <Tabs>.",
    );
    spy.mockRestore();
  });
});

describe("Tabs selection", () => {
  it("selects the first enabled tab when defaultValue is omitted", () => {
    render(<BasicTabs disabledB={false} />);
    expect(screen.getByRole("tab", { name: "Alpha" })).toHaveAttribute("aria-selected", "true");
  });

  it("selects the first non-disabled tab when the first tab is disabled", () => {
    render(
      <Tabs>
        <TabList aria-label="x">
          <Tab value="a" disabled>
            Alpha
          </Tab>
          <Tab value="b">Beta</Tab>
        </TabList>
      </Tabs>,
    );
    expect(screen.getByRole("tab", { name: "Beta" })).toHaveAttribute("aria-selected", "true");
    expect(screen.getByRole("tab", { name: "Beta" })).toHaveAttribute("tabindex", "0");
  });

  it("falls back to the first enabled tab when defaultValue names a disabled tab", () => {
    render(<BasicTabs defaultValue="b" disabledB />);
    expect(screen.getByRole("tab", { name: "Beta" })).toHaveAttribute("aria-selected", "false");
    expect(screen.getByRole("tab", { name: "Alpha" })).toHaveAttribute("aria-selected", "true");
    const tabbable = screen.getAllByRole("tab").filter((t) => t.tabIndex === 0);
    expect(tabbable).toHaveLength(1);
    expect(tabbable[0]).toHaveTextContent("Alpha");
  });

  it("falls back to the first enabled tab when defaultValue names no tab", () => {
    render(<BasicTabs defaultValue="zzz" />);
    expect(screen.getByRole("tab", { name: "Alpha" })).toHaveAttribute("aria-selected", "true");
    expect(screen.getAllByRole("tab").filter((t) => t.tabIndex === 0)).toHaveLength(1);
  });

  it("switches panels on click and calls onValueChange in uncontrolled mode", async () => {
    const user = userEvent.setup();
    const onValueChange = vi.fn();
    render(<BasicTabs defaultValue="a" onValueChange={onValueChange} />);
    await user.click(screen.getByRole("tab", { name: "Gamma" }));
    expect(onValueChange).toHaveBeenCalledWith("c");
    expect(screen.getByRole("tab", { name: "Gamma" })).toHaveAttribute("aria-selected", "true");
    expect(screen.getByRole("tabpanel", { name: "Gamma" })).toBeVisible();
    const alphaPanel = document.getElementById(screen.getByRole("tab", { name: "Alpha" }).getAttribute("aria-controls")!);
    expect(alphaPanel).toHaveAttribute("hidden");
  });

  it("does not call onValueChange when re-selecting the selected tab", async () => {
    const user = userEvent.setup();
    const onValueChange = vi.fn();
    render(<BasicTabs defaultValue="a" onValueChange={onValueChange} />);
    await user.click(screen.getByRole("tab", { name: "Alpha" }));
    expect(onValueChange).not.toHaveBeenCalled();
  });

  it("in controlled mode changes selection only when the parent updates value", async () => {
    const user = userEvent.setup();
    const onValueChange = vi.fn();
    function Parent() {
      const [value, setValue] = useState("a");
      return (
        <ControlledTabs
          value={value}
          onValueChange={(next) => {
            onValueChange(next);
            setValue(next);
          }}
        />
      );
    }
    render(<Parent />);
    await user.click(screen.getByRole("tab", { name: "Beta" }));
    expect(onValueChange).toHaveBeenCalledWith("b");
    expect(screen.getByRole("tab", { name: "Beta" })).toHaveAttribute("aria-selected", "true");
  });

  it("keeps aria-selected unchanged when a controlled parent ignores onValueChange", async () => {
    const user = userEvent.setup();
    const onValueChange = vi.fn();
    render(<ControlledTabs value="a" onValueChange={onValueChange} />);
    await user.click(screen.getByRole("tab", { name: "Beta" }));
    expect(onValueChange).toHaveBeenCalledWith("b");
    expect(screen.getByRole("tab", { name: "Alpha" })).toHaveAttribute("aria-selected", "true");
    expect(screen.getByRole("tab", { name: "Beta" })).toHaveAttribute("aria-selected", "false");
  });

  it("uses value over defaultValue when both are given", () => {
    render(
      <Tabs value="b" defaultValue="a">
        <TabList aria-label="x">
          <Tab value="a">Alpha</Tab>
          <Tab value="b">Beta</Tab>
        </TabList>
      </Tabs>,
    );
    expect(screen.getByRole("tab", { name: "Beta" })).toHaveAttribute("aria-selected", "true");
  });
});

describe("Tabs keyboard", () => {
  it("uses a roving tabindex with only the selected tab tabbable", () => {
    render(<BasicTabs defaultValue="b" />);
    expect(screen.getByRole("tab", { name: "Alpha" })).toHaveAttribute("tabindex", "-1");
    expect(screen.getByRole("tab", { name: "Beta" })).toHaveAttribute("tabindex", "0");
    expect(screen.getByRole("tab", { name: "Gamma" })).toHaveAttribute("tabindex", "-1");
  });

  it("moves from the tablist to the selected panel with Tab", async () => {
    const user = userEvent.setup();
    render(<BasicTabs defaultValue="b" />);
    await user.tab();
    expect(screen.getByRole("tab", { name: "Beta" })).toHaveFocus();
    await user.tab();
    expect(screen.getByRole("tabpanel", { name: "Beta" })).toHaveFocus();
  });

  it("moves to the next and previous tab with arrows and selects it", async () => {
    const user = userEvent.setup();
    const onValueChange = vi.fn();
    render(<BasicTabs defaultValue="a" onValueChange={onValueChange} />);
    screen.getByRole("tab", { name: "Alpha" }).focus();
    await user.keyboard("{ArrowRight}");
    expect(screen.getByRole("tab", { name: "Beta" })).toHaveFocus();
    expect(screen.getByRole("tab", { name: "Beta" })).toHaveAttribute("aria-selected", "true");
    expect(onValueChange).toHaveBeenLastCalledWith("b");
    await user.keyboard("{ArrowLeft}");
    expect(screen.getByRole("tab", { name: "Alpha" })).toHaveFocus();
  });

  it("skips disabled tabs and wraps at both ends", async () => {
    const user = userEvent.setup();
    render(<BasicTabs defaultValue="a" disabledB />);
    screen.getByRole("tab", { name: "Alpha" }).focus();
    await user.keyboard("{ArrowRight}");
    expect(screen.getByRole("tab", { name: "Gamma" })).toHaveFocus();
    await user.keyboard("{ArrowRight}");
    expect(screen.getByRole("tab", { name: "Alpha" })).toHaveFocus();
    await user.keyboard("{ArrowLeft}");
    expect(screen.getByRole("tab", { name: "Gamma" })).toHaveFocus();
  });

  it("moves to the first and last enabled tab with Home and End", async () => {
    const user = userEvent.setup();
    render(<BasicTabs defaultValue="a" disabledB />);
    screen.getByRole("tab", { name: "Alpha" }).focus();
    await user.keyboard("{End}");
    expect(screen.getByRole("tab", { name: "Gamma" })).toHaveFocus();
    await user.keyboard("{Home}");
    expect(screen.getByRole("tab", { name: "Alpha" })).toHaveFocus();
  });

  it("skips a disabled first tab for Home and a disabled last tab for End", async () => {
    const user = userEvent.setup();
    render(
      <Tabs defaultValue="b">
        <TabList aria-label="x">
          <Tab value="a" disabled>
            Alpha
          </Tab>
          <Tab value="b">Beta</Tab>
          <Tab value="c">Gamma</Tab>
          <Tab value="d" disabled>
            Delta
          </Tab>
        </TabList>
      </Tabs>,
    );
    screen.getByRole("tab", { name: "Beta" }).focus();
    await user.keyboard("{End}");
    expect(screen.getByRole("tab", { name: "Gamma" })).toHaveFocus();
    await user.keyboard("{Home}");
    expect(screen.getByRole("tab", { name: "Beta" })).toHaveFocus();
  });

  it("stays on the only enabled tab when all others are disabled", async () => {
    const user = userEvent.setup();
    const onValueChange = vi.fn();
    render(
      <Tabs onValueChange={onValueChange}>
        <TabList aria-label="x">
          <Tab value="a" disabled>
            Alpha
          </Tab>
          <Tab value="b">Beta</Tab>
          <Tab value="c" disabled>
            Gamma
          </Tab>
        </TabList>
      </Tabs>,
    );
    screen.getByRole("tab", { name: "Beta" }).focus();
    await user.keyboard("{ArrowRight}{ArrowLeft}{Home}{End}");
    expect(screen.getByRole("tab", { name: "Beta" })).toHaveFocus();
    expect(onValueChange).not.toHaveBeenCalled();
  });

  it("handles a single tab without changing selection", async () => {
    const user = userEvent.setup();
    const onValueChange = vi.fn();
    render(
      <Tabs onValueChange={onValueChange}>
        <TabList aria-label="x">
          <Tab value="only">Only</Tab>
        </TabList>
      </Tabs>,
    );
    screen.getByRole("tab", { name: "Only" }).focus();
    await user.keyboard("{ArrowRight}");
    expect(screen.getByRole("tab", { name: "Only" })).toHaveFocus();
    expect(onValueChange).not.toHaveBeenCalled();
  });

  it("orders navigation by DOM order when tabs are reordered", async () => {
    const user = userEvent.setup();
    function Reorderable({ reversed }: { reversed: boolean }) {
      const items = [
        <Tab key="a" value="a">
          Alpha
        </Tab>,
        <Tab key="b" value="b">
          Beta
        </Tab>,
        <Tab key="c" value="c">
          Gamma
        </Tab>,
      ];
      return (
        <Tabs defaultValue="a">
          <TabList aria-label="x">{reversed ? items.reverse() : items}</TabList>
        </Tabs>
      );
    }
    const { rerender } = render(<Reorderable reversed={false} />);
    rerender(<Reorderable reversed />);
    // DOM order is now Gamma, Beta, Alpha.
    screen.getByRole("tab", { name: "Alpha" }).focus();
    await user.keyboard("{ArrowLeft}");
    expect(screen.getByRole("tab", { name: "Beta" })).toHaveFocus();
    await user.keyboard("{ArrowLeft}");
    expect(screen.getByRole("tab", { name: "Gamma" })).toHaveFocus();
    await user.keyboard("{ArrowRight}");
    expect(screen.getByRole("tab", { name: "Beta" })).toHaveFocus();
  });

  it("ignores keys other than arrows, Home and End", async () => {
    const user = userEvent.setup();
    const onValueChange = vi.fn();
    render(<BasicTabs defaultValue="a" onValueChange={onValueChange} />);
    screen.getByRole("tab", { name: "Alpha" }).focus();
    await user.keyboard("{Enter}x{ArrowDown}");
    expect(screen.getByRole("tab", { name: "Alpha" })).toHaveFocus();
    expect(onValueChange).not.toHaveBeenCalled();
  });
});

describe("Tabs disabled", () => {
  it("marks disabled tabs and ignores clicks on them", async () => {
    const user = userEvent.setup();
    const onValueChange = vi.fn();
    render(<BasicTabs defaultValue="a" disabledB onValueChange={onValueChange} />);
    const beta = screen.getByRole("tab", { name: "Beta" });
    expect(beta).toBeDisabled();
    await user.click(beta);
    expect(beta).toHaveAttribute("aria-selected", "false");
    expect(onValueChange).not.toHaveBeenCalled();
  });
});

import { fireEvent, render, screen } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { describe, expect, it, vi } from "vitest";
import { Tab, TabList, TabPanel, Tabs, type TabsProps } from "./Tabs";

type ExampleProps = TabsProps & { disabled?: string[]; withExtra?: boolean };

function Example({ disabled = [], withExtra = false, ...props }: ExampleProps) {
  return (
    <Tabs {...props}>
      <TabList aria-label="Settings">
        <Tab value="one" disabled={disabled.includes("one")}>
          One
        </Tab>
        {withExtra && <Tab value="extra">Extra</Tab>}
        <Tab value="two" disabled={disabled.includes("two")}>
          Two
        </Tab>
        <Tab value="three" disabled={disabled.includes("three")}>
          Three
        </Tab>
      </TabList>
      <TabPanel value="one">Panel one</TabPanel>
      {withExtra && <TabPanel value="extra">Panel extra</TabPanel>}
      <TabPanel value="two">Panel two</TabPanel>
      <TabPanel value="three">Panel three</TabPanel>
    </Tabs>
  );
}

const tab = (name: string) => screen.getByRole("tab", { name });

describe("Tabs ARIA", () => {
  it("wires tablist, tabs and panels together", () => {
    render(<Example defaultValue="two" />);
    const tablist = screen.getByRole("tablist", { name: "Settings" });
    expect(tablist).toBeInTheDocument();

    const two = tab("Two");
    expect(two.tagName).toBe("BUTTON");
    expect(two).toHaveAttribute("type", "button");
    expect(two).toHaveAttribute("aria-selected", "true");

    const panel = screen.getByRole("tabpanel", { name: "Two" });
    expect(two).toHaveAttribute("aria-controls", panel.id);
    expect(panel).toHaveAttribute("aria-labelledby", two.id);
    expect(panel).toHaveAttribute("tabindex", "0");
  });

  it("hides panels that are not selected", () => {
    render(<Example defaultValue="two" />);
    expect(screen.getByText("Panel two")).toBeVisible();
    expect(screen.getByText("Panel one")).not.toBeVisible();
    expect(tab("One")).toHaveAttribute("aria-selected", "false");
  });

  it("gives unique ids to multiple instances on one page", () => {
    render(
      <>
        <Example defaultValue="one" />
        <Example defaultValue="one" />
      </>,
    );
    const ids = screen.getAllByRole("tab", { name: "One" }).map((element) => element.id);
    expect(new Set(ids).size).toBe(2);
  });

  it("throws when Tab is used outside Tabs", () => {
    const consoleError = vi.spyOn(console, "error").mockImplementation(() => {});
    try {
      expect(() => render(<Tab value="a">A</Tab>)).toThrow("Tab must be used inside <Tabs>");
    } finally {
      consoleError.mockRestore();
    }
  });
});

describe("Tabs selection", () => {
  it("selects the first enabled tab when no default is given", () => {
    render(<Example disabled={["one"]} />);
    expect(tab("Two")).toHaveAttribute("aria-selected", "true");
  });

  it("selects the first tab by default", () => {
    render(<Example />);
    expect(tab("One")).toHaveAttribute("aria-selected", "true");
  });

  it("uses value over defaultValue and updates via onValueChange in controlled mode", async () => {
    const user = userEvent.setup();
    const onValueChange = vi.fn();
    const { rerender } = render(<Example value="one" defaultValue="three" onValueChange={onValueChange} />);
    expect(tab("One")).toHaveAttribute("aria-selected", "true");

    await user.click(tab("Two"));
    expect(onValueChange).toHaveBeenCalledWith("two");
    expect(tab("One")).toHaveAttribute("aria-selected", "true");

    rerender(<Example value="two" onValueChange={onValueChange} />);
    expect(tab("Two")).toHaveAttribute("aria-selected", "true");
  });

  it("selects on click in uncontrolled mode and calls onValueChange", async () => {
    const user = userEvent.setup();
    const onValueChange = vi.fn();
    render(<Example onValueChange={onValueChange} />);
    await user.click(tab("Three"));
    expect(tab("Three")).toHaveAttribute("aria-selected", "true");
    expect(onValueChange).toHaveBeenCalledWith("three");
  });

  it("does not select a disabled tab on click", async () => {
    const user = userEvent.setup();
    const onValueChange = vi.fn();
    render(<Example disabled={["two"]} onValueChange={onValueChange} />);
    expect(tab("Two")).toHaveAttribute("aria-disabled", "true");
    await user.click(tab("Two"));
    expect(tab("Two")).toHaveAttribute("aria-selected", "false");
    expect(onValueChange).not.toHaveBeenCalled();
  });
});

describe("Tabs roving tabindex", () => {
  it("puts only the selected tab in the tab order", () => {
    render(<Example defaultValue="two" />);
    expect(tab("Two")).toHaveAttribute("tabindex", "0");
    expect(tab("One")).toHaveAttribute("tabindex", "-1");
    expect(tab("Three")).toHaveAttribute("tabindex", "-1");
  });

  it("makes the first enabled tab tabbable when the value matches no enabled tab", () => {
    render(<Example value="missing" disabled={["one"]} />);
    expect(tab("One")).toHaveAttribute("tabindex", "-1");
    expect(tab("Two")).toHaveAttribute("tabindex", "0");
  });
});

describe("Tabs keyboard", () => {
  it("moves focus and selection with ArrowRight and wraps at the end", async () => {
    const user = userEvent.setup();
    const onValueChange = vi.fn();
    render(<Example defaultValue="three" onValueChange={onValueChange} />);
    tab("Three").focus();
    await user.keyboard("{ArrowRight}");
    expect(tab("One")).toHaveFocus();
    expect(tab("One")).toHaveAttribute("aria-selected", "true");
    expect(onValueChange).toHaveBeenLastCalledWith("one");
  });

  it("moves with ArrowLeft and wraps at the start", async () => {
    const user = userEvent.setup();
    render(<Example />);
    tab("One").focus();
    await user.keyboard("{ArrowLeft}");
    expect(tab("Three")).toHaveFocus();
    expect(tab("Three")).toHaveAttribute("aria-selected", "true");
  });

  it("skips disabled tabs when moving with arrows", async () => {
    const user = userEvent.setup();
    render(<Example disabled={["two"]} />);
    tab("One").focus();
    await user.keyboard("{ArrowRight}");
    expect(tab("Three")).toHaveFocus();
    await user.keyboard("{ArrowLeft}");
    expect(tab("One")).toHaveFocus();
  });

  it("keeps focus in place when all other tabs are disabled", async () => {
    const user = userEvent.setup();
    const onValueChange = vi.fn();
    render(<Example disabled={["two", "three"]} onValueChange={onValueChange} />);
    tab("One").focus();
    await user.keyboard("{ArrowRight}");
    expect(tab("One")).toHaveFocus();
    expect(onValueChange).not.toHaveBeenCalled();
  });

  it("jumps to the first and last enabled tabs with Home and End", async () => {
    const user = userEvent.setup();
    render(<Example defaultValue="two" />);
    tab("Two").focus();
    await user.keyboard("{End}");
    expect(tab("Three")).toHaveFocus();
    expect(tab("Three")).toHaveAttribute("aria-selected", "true");
    await user.keyboard("{Home}");
    expect(tab("One")).toHaveFocus();
    expect(tab("One")).toHaveAttribute("aria-selected", "true");
  });

  it("skips a disabled last tab for End and a disabled first tab for Home", async () => {
    const user = userEvent.setup();
    const { rerender } = render(<Example disabled={["three"]} defaultValue="two" />);
    tab("Two").focus();
    await user.keyboard("{End}");
    expect(tab("Two")).toHaveFocus();

    rerender(<Example disabled={["one"]} defaultValue="two" />);
    tab("Two").focus();
    await user.keyboard("{Home}");
    expect(tab("Two")).toHaveFocus();
  });

  it("follows DOM order for tabs added later", async () => {
    const user = userEvent.setup();
    const { rerender } = render(<Example defaultValue="one" />);
    rerender(<Example defaultValue="one" withExtra />);
    tab("One").focus();
    await user.keyboard("{ArrowRight}");
    expect(tab("Extra")).toHaveFocus();
    await user.keyboard("{ArrowRight}");
    expect(tab("Two")).toHaveFocus();
  });

  it("prevents default only for handled keys", () => {
    render(<Example defaultValue="one" />);
    const one = tab("One");
    expect(fireEvent.keyDown(one, { key: "ArrowRight" })).toBe(false);
    expect(fireEvent.keyDown(one, { key: "End" })).toBe(false);
    expect(fireEvent.keyDown(one, { key: "Tab" })).toBe(true);
    expect(fireEvent.keyDown(one, { key: "a" })).toBe(true);
  });

  it.each([{ altKey: true }, { ctrlKey: true }, { metaKey: true }])(
    "ignores arrow, Home and End keys held with a modifier %o",
    async (modifier) => {
      render(<Example defaultValue="one" />);
      const one = tab("One");
      one.focus();
      for (const key of ["ArrowRight", "End", "Home"]) {
        expect(fireEvent.keyDown(one, { key, ...modifier })).toBe(true);
      }
      expect(one).toHaveFocus();
      expect(one).toHaveAttribute("aria-selected", "true");
    },
  );

  it("keeps the first enabled tab selected when a tab is inserted before it", () => {
    function Leading({ withLeading }: { withLeading: boolean }) {
      return (
        <Tabs>
          <TabList aria-label="Settings">
            {withLeading && <Tab value="z">Zed</Tab>}
            <Tab value="one">One</Tab>
            <Tab value="two">Two</Tab>
          </TabList>
        </Tabs>
      );
    }
    const { rerender } = render(<Leading withLeading={false} />);
    expect(tab("One")).toHaveAttribute("aria-selected", "true");
    rerender(<Leading withLeading />);
    expect(tab("One")).toHaveAttribute("aria-selected", "true");
    expect(tab("Zed")).toHaveAttribute("aria-selected", "false");
  });
});

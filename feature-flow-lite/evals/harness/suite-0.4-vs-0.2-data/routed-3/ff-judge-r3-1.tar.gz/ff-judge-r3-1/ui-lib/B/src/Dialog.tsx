import { useEffect, useId, useRef, type ComponentPropsWithoutRef, type ReactNode } from "react";
import { createPortal } from "react-dom";

export type DialogProps = Omit<ComponentPropsWithoutRef<"div">, "title" | "role"> & {
  open: boolean;
  /** Called with `false` on Escape or a backdrop click. The dialog never closes itself. */
  onOpenChange: (open: boolean) => void;
  title: ReactNode;
  description?: ReactNode;
};

const FOCUSABLE_SELECTOR = [
  "a[href]",
  "area[href]",
  "button",
  "input:not([type='hidden'])",
  "select",
  "textarea",
  "iframe",
  "[tabindex]",
  "[contenteditable='true']",
].join(",");

/**
 * True when the element or an ancestor up to the container is hidden, inert, or not rendered.
 * Visibility is inherited but can be overridden by a child, so only the element's own computed
 * visibility is checked; it already reflects inheritance.
 */
function isNotRendered(element: HTMLElement, container: HTMLElement): boolean {
  if (getComputedStyle(element).visibility === "hidden") {
    return true;
  }
  for (let node: HTMLElement | null = element; node !== null; node = node.parentElement) {
    const style = getComputedStyle(node);
    if (node.hidden || node.hasAttribute("inert") || style.display === "none") {
      return true;
    }
    if (node === container) {
      break;
    }
  }
  return false;
}

/** Focusable descendants in DOM order, excluding disabled, tabindex="-1" and non-rendered elements. */
function getFocusable(container: HTMLElement): HTMLElement[] {
  return Array.from(container.querySelectorAll<HTMLElement>(FOCUSABLE_SELECTOR)).filter(
    (element) =>
      !element.matches(":disabled") &&
      element.getAttribute("tabindex") !== "-1" &&
      !isNotRendered(element, container),
  );
}

/** Wraps Tab and Shift+Tab inside the dialog. */
function trapTab(event: KeyboardEvent, dialog: HTMLElement) {
  const focusable = getFocusable(dialog);
  if (focusable.length === 0) {
    event.preventDefault();
    dialog.focus();
    return;
  }
  const first = focusable[0];
  const last = focusable[focusable.length - 1];
  const active = document.activeElement;
  const outside = active === null || !dialog.contains(active);
  if (event.shiftKey && (outside || active === dialog || active === first)) {
    event.preventDefault();
    last.focus();
  } else if (!event.shiftKey && (outside || active === last)) {
    event.preventDefault();
    first.focus();
  }
}

export function Dialog({ open, onOpenChange, title, description, className, children, ...rest }: DialogProps) {
  const baseId = useId();
  const titleId = `${baseId}-title`;
  const descriptionId = `${baseId}-description`;
  const dialogRef = useRef<HTMLDivElement>(null);

  // Moves focus into the dialog on open and returns it to the opener on close or unmount.
  useEffect(() => {
    if (!open) {
      return;
    }
    const opener = document.activeElement;
    const dialog = dialogRef.current;
    if (dialog !== null) {
      (getFocusable(dialog)[0] ?? dialog).focus();
    }
    return () => {
      if (opener instanceof HTMLElement && opener.isConnected) {
        opener.focus();
      }
    };
  }, [open]);

  // Escape closes and Tab is trapped. A document listener also catches focus that has left the dialog.
  useEffect(() => {
    if (!open) {
      return;
    }
    function handleKeyDown(event: KeyboardEvent) {
      if (event.key === "Escape") {
        onOpenChange(false);
      } else if (event.key === "Tab" && dialogRef.current !== null) {
        trapTab(event, dialogRef.current);
      }
    }
    document.addEventListener("keydown", handleKeyDown);
    return () => document.removeEventListener("keydown", handleKeyDown);
  }, [open, onOpenChange]);

  if (!open) {
    return null;
  }

  const hasDescription = description !== undefined && description !== null && description !== false;

  return createPortal(
    <>
      <div data-backdrop="" onClick={() => onOpenChange(false)} />
      <div
        {...rest}
        ref={dialogRef}
        role="dialog"
        aria-modal="true"
        aria-labelledby={titleId}
        aria-describedby={hasDescription ? descriptionId : undefined}
        tabIndex={-1}
        className={className}
      >
        <h2 id={titleId}>{title}</h2>
        {hasDescription && <p id={descriptionId}>{description}</p>}
        {children}
      </div>
    </>,
    document.body,
  );
}

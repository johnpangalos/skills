import {
  useId,
  useState,
  type ChangeEvent,
  type ComponentPropsWithoutRef,
  type FocusEvent,
  type KeyboardEvent,
} from "react";

export type ComboboxOption = {
  value: string;
  label: string;
  disabled?: boolean;
};

export type ComboboxProps = Omit<
  ComponentPropsWithoutRef<"input">,
  "id" | "type" | "role" | "value" | "defaultValue" | "onChange"
> & {
  /** Visible label for the input; rendered as a <label> associated with it. */
  label: string;
  options: ComboboxOption[];
  /** The selected option's value, or null for no selection. */
  value: string | null;
  /** Called only when the user picks an enabled option. Clearing the text never calls it. */
  onChange: (value: string | null) => void;
};

/** Enabled option after the active one, wrapping at the end; the first one when none is active. */
function nextEnabledValue(enabled: ComboboxOption[], active: string | null): string | null {
  if (enabled.length === 0) {
    return null;
  }
  const index = enabled.findIndex((option) => option.value === active);
  return enabled[index === -1 ? 0 : (index + 1) % enabled.length].value;
}

/** Enabled option before the active one, wrapping at the start; the last one when none is active. */
function previousEnabledValue(enabled: ComboboxOption[], active: string | null): string | null {
  if (enabled.length === 0) {
    return null;
  }
  const index = enabled.findIndex((option) => option.value === active);
  return enabled[index === -1 ? enabled.length - 1 : (index - 1 + enabled.length) % enabled.length].value;
}

export function Combobox({
  label,
  options,
  value,
  onChange,
  placeholder,
  onKeyDown,
  onBlur,
  onClick,
  ...rest
}: ComboboxProps) {
  const baseId = useId();
  const inputId = `${baseId}-input`;
  const labelId = `${baseId}-label`;
  const listboxId = `${baseId}-listbox`;
  const optionId = (index: number) => `${baseId}-option-${index}`;

  const [open, setOpen] = useState(false);
  // Text typed by the user. Null means "not editing", so the input shows the selected label.
  const [draft, setDraft] = useState<string | null>(null);
  const [activeValue, setActiveValue] = useState<string | null>(null);

  const selectedLabel = options.find((option) => option.value === value)?.label ?? "";
  const text = draft ?? selectedLabel;
  const query = (draft ?? "").trim().toLowerCase();
  const visible = options.filter((option) => option.label.toLowerCase().includes(query));
  const enabled = visible.filter((option) => !option.disabled);
  const active = enabled.find((option) => option.value === activeValue) ?? null;

  // Render-time adjustments: a new parent value drops the typed text, and an active option that
  // is no longer enabled and visible is cleared so it cannot come back active or be chosen.
  const [previousValue, setPreviousValue] = useState(value);
  if (value !== previousValue) {
    setPreviousValue(value);
    setDraft(null);
    setActiveValue(null);
  }
  if (activeValue !== null && active === null) {
    setActiveValue(null);
  }

  function close() {
    setOpen(false);
    setDraft(null);
    setActiveValue(null);
  }

  function choose(option: ComboboxOption) {
    onChange(option.value);
    close();
  }

  function handleChange(event: ChangeEvent<HTMLInputElement>) {
    setDraft(event.target.value);
    setOpen(true);
    setActiveValue(null);
  }

  function handleBlur(event: FocusEvent<HTMLInputElement>) {
    onBlur?.(event);
    close();
  }

  function handleKeyDown(event: KeyboardEvent<HTMLInputElement>) {
    onKeyDown?.(event);
    switch (event.key) {
      case "ArrowDown":
        event.preventDefault();
        if (open) {
          setActiveValue(nextEnabledValue(enabled, active?.value ?? null));
        } else {
          setOpen(true);
        }
        return;
      case "ArrowUp":
        if (!open) {
          return;
        }
        event.preventDefault();
        setActiveValue(previousEnabledValue(enabled, active?.value ?? null));
        return;
      case "Enter":
        // While the listbox is open, Enter never submits the surrounding form.
        if (!open) {
          return;
        }
        event.preventDefault();
        if (active !== null) {
          choose(active);
        }
        return;
      case "Escape":
        // Only handled while open, so a surrounding Dialog can still close when the listbox is closed.
        if (!open) {
          return;
        }
        event.preventDefault();
        event.stopPropagation();
        close();
        return;
      default:
        return;
    }
  }

  return (
    <div>
      <label id={labelId} htmlFor={inputId}>
        {label}
      </label>
      <input
        {...rest}
        id={inputId}
        type="text"
        role="combobox"
        value={text}
        placeholder={placeholder}
        autoComplete="off"
        aria-autocomplete="list"
        aria-expanded={open}
        aria-controls={listboxId}
        aria-activedescendant={active === null ? undefined : optionId(options.indexOf(active))}
        onChange={handleChange}
        onBlur={handleBlur}
        onKeyDown={handleKeyDown}
        onClick={(event) => {
          onClick?.(event);
          setOpen(true);
        }}
      />
      {open && visible.length === 0 && <div role="status">No results</div>}
      <div id={listboxId} role="listbox" aria-labelledby={labelId} hidden={!open}>
        {open &&
          visible.map((option) => (
            <div
              key={option.value}
              id={optionId(options.indexOf(option))}
              role="option"
              aria-selected={option.value === value}
              aria-disabled={option.disabled ? true : undefined}
              data-active={option === active ? "" : undefined}
              // Keeps focus in the input so the blur handler does not close the listbox first.
              onMouseDown={(event) => event.preventDefault()}
              onClick={() => {
                if (!option.disabled) {
                  choose(option);
                }
              }}
            >
              {option.label}
            </div>
          ))}
      </div>
    </div>
  );
}

import {
  useEffect,
  useId,
  useRef,
  type HTMLAttributes,
  type KeyboardEvent,
  type MouseEvent,
  type ReactNode,
} from "react";
import { createPortal } from "react-dom";

const FOCUSABLE =
  'a[href]:not(:disabled), button:not(:disabled), input:not(:disabled):not([type="hidden"]), select:not(:disabled), textarea:not(:disabled), [tabindex]:not(:disabled)';

// True when the element and its ancestors up to the dialog are not hidden.
function isRendered(element: HTMLElement, dialog: HTMLElement): boolean {
  for (let node: HTMLElement | null = element; node && node !== dialog; node = node.parentElement) {
    if (node.hidden || getComputedStyle(node).display === "none") {
      return false;
    }
  }
  return true;
}

function focusableWithin(container: HTMLElement): HTMLElement[] {
  return Array.from(container.querySelectorAll<HTMLElement>(FOCUSABLE)).filter(
    (element) => element.tabIndex >= 0 && isRendered(element, container),
  );
}

// Always takes over Tab so focus cannot leave the dialog from any element.
// Stops propagation so an enclosing dialog does not also cycle focus.
function cycleFocus(event: KeyboardEvent<HTMLDivElement>, dialog: HTMLDivElement) {
  event.preventDefault();
  event.stopPropagation();
  const items = focusableWithin(dialog);
  if (items.length === 0) {
    dialog.focus();
    return;
  }
  const active = document.activeElement ?? dialog;
  const index = items.indexOf(active as HTMLElement);
  if (index !== -1) {
    items[(index + (event.shiftKey ? -1 : 1) + items.length) % items.length].focus();
    return;
  }
  // The active element is not in the list (e.g. tabIndex -1): use document order.
  if (event.shiftKey) {
    const before = items.filter((item) => item.compareDocumentPosition(active) & Node.DOCUMENT_POSITION_FOLLOWING);
    (before.pop() ?? items[items.length - 1]).focus();
  } else {
    const after = items.find((item) => active.compareDocumentPosition(item) & Node.DOCUMENT_POSITION_FOLLOWING);
    (after ?? items[0]).focus();
  }
}

export interface DialogProps extends Omit<HTMLAttributes<HTMLDivElement>, "title"> {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  title: ReactNode;
  description?: ReactNode;
  children?: ReactNode;
  /** Props for the backdrop element, e.g. className or style. `data-backdrop` is always set. */
  backdropProps?: HTMLAttributes<HTMLDivElement>;
}

export function Dialog({
  open,
  onOpenChange,
  title,
  description,
  children,
  backdropProps,
  onKeyDown,
  ...rest
}: DialogProps) {
  const titleId = useId();
  const descriptionId = useId();
  const dialogRef = useRef<HTMLDivElement>(null);
  const opener = useRef<HTMLElement | null>(null);
  const wasOpen = useRef(false);
  const pressedBackdrop = useRef(false);

  // Capture the opener during render: an autoFocus child moves focus before any effect runs.
  if (open && !wasOpen.current) {
    opener.current = document.activeElement as HTMLElement | null;
  }
  wasOpen.current = open;

  // Restore focus to the opener when the dialog closes or unmounts.
  useEffect(() => {
    if (!open) {
      return;
    }
    const previous = opener.current;
    return () => {
      if (previous?.isConnected) {
        previous.focus();
      }
    };
  }, [open]);

  // Deferred so children that register after mount (e.g. Tabs) are in place before we choose a target.
  useEffect(() => {
    if (!open) {
      return;
    }
    const frame = requestAnimationFrame(() => {
      const dialog = dialogRef.current;
      if (!dialog || dialog.contains(document.activeElement)) {
        return;
      }
      const [first] = focusableWithin(dialog);
      (first ?? dialog).focus();
    });
    return () => cancelAnimationFrame(frame);
  }, [open]);

  if (!open) {
    return null;
  }

  function handleKeyDown(event: KeyboardEvent<HTMLDivElement>) {
    onKeyDown?.(event);
    if (event.key === "Escape") {
      event.stopPropagation();
      onOpenChange(false);
    } else if (event.key === "Tab" && dialogRef.current) {
      cycleFocus(event, dialogRef.current);
    }
  }

  function handleBackdropMouseDown(event: MouseEvent<HTMLDivElement>) {
    backdropProps?.onMouseDown?.(event);
    // Keep focus where it is; otherwise a backdrop press moves focus to the body, outside the trap.
    event.preventDefault();
    pressedBackdrop.current = event.target === event.currentTarget;
  }

  // A click only closes when the press also started on the backdrop, so a drag
  // from inside the content that ends on the backdrop does not dismiss.
  function handleBackdropClick(event: MouseEvent<HTMLDivElement>) {
    backdropProps?.onClick?.(event);
    if (pressedBackdrop.current && event.target === event.currentTarget) {
      onOpenChange(false);
    }
    pressedBackdrop.current = false;
  }

  return createPortal(
    <>
      <div
        {...backdropProps}
        data-backdrop=""
        onMouseDown={handleBackdropMouseDown}
        onClick={handleBackdropClick}
      />
      <div
        {...rest}
        ref={dialogRef}
        role="dialog"
        aria-modal="true"
        aria-labelledby={titleId}
        aria-describedby={description ? descriptionId : undefined}
        tabIndex={-1}
        onKeyDown={handleKeyDown}
      >
        <h2 id={titleId}>{title}</h2>
        {description ? <p id={descriptionId}>{description}</p> : null}
        {children}
      </div>
    </>,
    document.body,
  );
}

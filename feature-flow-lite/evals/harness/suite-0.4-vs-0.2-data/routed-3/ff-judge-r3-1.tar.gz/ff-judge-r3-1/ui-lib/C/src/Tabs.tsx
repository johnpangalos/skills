import {
  createContext,
  useCallback,
  useContext,
  useId,
  useLayoutEffect,
  useMemo,
  useRef,
  useState,
  type ButtonHTMLAttributes,
  type HTMLAttributes,
  type KeyboardEvent,
  type MouseEvent,
} from "react";

type TabEntry = { value: string; disabled: boolean; element: HTMLElement };

type TabsContextValue = {
  baseId: string;
  activeValue: string | undefined;
  select: (value: string) => void;
  register: (entry: TabEntry) => () => void;
};

const TabsContext = createContext<TabsContextValue | null>(null);

export interface TabsProps extends Omit<HTMLAttributes<HTMLDivElement>, "defaultValue"> {
  defaultValue?: string;
  value?: string;
  onValueChange?: (value: string) => void;
}

export interface TabListProps extends HTMLAttributes<HTMLDivElement> {
  "aria-label": string;
}

export interface TabProps extends Omit<ButtonHTMLAttributes<HTMLButtonElement>, "value" | "disabled"> {
  value: string;
  disabled?: boolean;
}

export interface TabPanelProps extends HTMLAttributes<HTMLDivElement> {
  value: string;
}

const tabId = (baseId: string, value: string) => `${baseId}-tab-${encodeURIComponent(value)}`;
const panelId = (baseId: string, value: string) => `${baseId}-panel-${encodeURIComponent(value)}`;

function useTabsContext(component: string): TabsContextValue {
  const context = useContext(TabsContext);
  if (!context) throw new Error(`${component} must be used inside <Tabs>`);
  return context;
}

function sortByDocumentOrder(entries: TabEntry[]): TabEntry[] {
  return [...entries].sort((a, b) =>
    a.element.compareDocumentPosition(b.element) & Node.DOCUMENT_POSITION_FOLLOWING ? -1 : 1,
  );
}

function isEnabledTab(tab: HTMLElement): boolean {
  return tab.getAttribute("aria-disabled") !== "true";
}

function findEnabledFrom(tabs: HTMLElement[], current: number, step: 1 | -1): HTMLElement | undefined {
  for (let offset = 1; offset <= tabs.length; offset++) {
    const candidate = tabs[(current + step * offset + tabs.length) % tabs.length];
    if (isEnabledTab(candidate)) return candidate;
  }
  return undefined;
}

export function Tabs({ defaultValue, value, onValueChange, children, ...rest }: TabsProps) {
  const baseId = useId();
  const [internalValue, setInternalValue] = useState(defaultValue);
  const [entries, setEntries] = useState<TabEntry[]>([]);

  const enabledTabs = sortByDocumentOrder(entries).filter((entry) => !entry.disabled);
  const selectedValue = value ?? internalValue;
  // Until tabs have registered (first commit), use the selected value so it is focusable on first paint.
  const activeValue =
    entries.length === 0
      ? selectedValue
      : (enabledTabs.find((entry) => entry.value === selectedValue)?.value ?? enabledTabs.at(0)?.value);

  const select = useCallback(
    (next: string) => {
      if (next === activeValue) return;
      if (value === undefined) setInternalValue(next);
      onValueChange?.(next);
    },
    [activeValue, value, onValueChange],
  );

  const register = useCallback((entry: TabEntry) => {
    // The first enabled tab to register on mount becomes the default; later insertions leave it alone.
    setInternalValue((previous) => previous ?? (entry.disabled ? undefined : entry.value));
    setEntries((previous) => [...previous, entry]);
    return () => setEntries((previous) => previous.filter((item) => item !== entry));
  }, []);

  const context = useMemo(
    () => ({ baseId, activeValue, select, register }),
    [baseId, activeValue, select, register],
  );

  return (
    <TabsContext.Provider value={context}>
      <div {...rest}>{children}</div>
    </TabsContext.Provider>
  );
}

export function TabList({ onKeyDown, ...rest }: TabListProps) {
  const { select } = useTabsContext("TabList");

  const handleKeyDown = (event: KeyboardEvent<HTMLDivElement>) => {
    onKeyDown?.(event);
    const tabs = Array.from(event.currentTarget.querySelectorAll<HTMLElement>('[role="tab"]'));
    const current = tabs.indexOf(event.target as HTMLElement);
    if (current === -1) return;
    if (event.altKey || event.ctrlKey || event.metaKey) return;
    const enabled = tabs.filter(isEnabledTab);
    let target: HTMLElement | undefined;
    switch (event.key) {
      case "ArrowRight":
        target = findEnabledFrom(tabs, current, 1);
        break;
      case "ArrowLeft":
        target = findEnabledFrom(tabs, current, -1);
        break;
      case "Home":
        target = enabled.at(0);
        break;
      case "End":
        target = enabled.at(-1);
        break;
      default:
        return;
    }
    if (!target) return;
    event.preventDefault();
    target.focus();
    const value = target.dataset.value;
    if (value !== undefined) select(value);
  };

  return <div {...rest} role="tablist" onKeyDown={handleKeyDown} />;
}

export function Tab({ value, disabled = false, onClick, ...rest }: TabProps) {
  const { baseId, activeValue, select, register } = useTabsContext("Tab");
  const ref = useRef<HTMLButtonElement>(null);

  useLayoutEffect(() => {
    const element = ref.current;
    if (!element) return;
    return register({ value, disabled, element });
  }, [register, value, disabled]);

  const handleClick = (event: MouseEvent<HTMLButtonElement>) => {
    onClick?.(event);
    if (!disabled) select(value);
  };

  const selected = activeValue === value;

  return (
    <button
      {...rest}
      ref={ref}
      type="button"
      role="tab"
      id={tabId(baseId, value)}
      aria-selected={selected}
      aria-controls={panelId(baseId, value)}
      aria-disabled={disabled || undefined}
      tabIndex={selected ? 0 : -1}
      data-value={value}
      onClick={handleClick}
    />
  );
}

export function TabPanel({ value, ...rest }: TabPanelProps) {
  const { baseId, activeValue } = useTabsContext("TabPanel");

  return (
    <div
      {...rest}
      role="tabpanel"
      id={panelId(baseId, value)}
      aria-labelledby={tabId(baseId, value)}
      tabIndex={0}
      hidden={activeValue !== value}
    />
  );
}

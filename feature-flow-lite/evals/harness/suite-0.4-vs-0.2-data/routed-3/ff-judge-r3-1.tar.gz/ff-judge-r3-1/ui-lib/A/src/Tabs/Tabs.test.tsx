import { fireEvent, render, screen, within } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { useState } from "react";
import { Tab, TabList, TabPanel, Tabs, type TabsProps } from "./Tabs";

type HarnessProps = Partial<TabsProps> & { values: string[]; disabled?: string[] };

function Harness({ values, disabled = [], ...props }: HarnessProps) {
  return (
    <Tabs {...props}>
      <TabList aria-label="Sections">
        {values.map((value) => (
          <Tab key={value} value={value} disabled={disabled.includes(value)}>
            {value}
          </Tab>
        ))}
      </TabList>
      {values.map((value) => (
        <TabPanel key={value} value={value}>
          panel {value}
        </TabPanel>
      ))}
    </Tabs>
  );
}

function Controlled({ onValueChange }: { onValueChange: (value: string) => void }) {
  const [value, setValue] = useState("one");
  return (
    <Harness
      values={THREE}
      value={value}
      onValueChange={(next) => {
        onValueChange(next);
        setValue(next);
      }}
    />
  );
}

const THREE = ["one", "two", "three"];
const tab = (name: string) => screen.getByRole("tab", { name });
const panelOf = (element: HTMLElement) => document.getElementById(element.getAttribute("aria-controls") ?? "");

describe("Tabs", () => {
  it("selects the defaultValue tab and shows only its panel", () => {
    render(<Harness values={THREE} defaultValue="two" />);
    expect(tab("two")).toHaveAttribute("aria-selected", "true");
    expect(tab("one")).toHaveAttribute("aria-selected", "false");
    expect(screen.getByRole("tabpanel", { name: "two" })).toHaveTextContent("panel two");
    expect(screen.queryByRole("tabpanel", { name: "one" })).toBeNull();
  });

  it("links each tab to its panel with matching ids", () => {
    render(<Harness values={THREE} defaultValue="one" />);
    expect(panelOf(tab("one"))).toHaveAttribute("role", "tabpanel");
    expect(panelOf(tab("one"))).toHaveAttribute("aria-labelledby", tab("one").id);
    expect(panelOf(tab("one"))).toHaveAttribute("tabindex", "0");
  });

  it("selects the first enabled tab when no default or value is given", () => {
    render(<Harness values={THREE} disabled={["one"]} />);
    expect(tab("two")).toHaveAttribute("aria-selected", "true");
    expect(screen.getByRole("tabpanel", { name: "two" })).toBeVisible();
  });

  it("uses a roving tabindex so only the selected tab is in the tab order", () => {
    render(<Harness values={THREE} defaultValue="two" />);
    expect(tab("one")).toHaveAttribute("tabindex", "-1");
    expect(tab("two")).toHaveAttribute("tabindex", "0");
    expect(tab("three")).toHaveAttribute("tabindex", "-1");
  });

  it("moves Tab focus from the selected tab to its panel", async () => {
    const user = userEvent.setup();
    render(<Harness values={THREE} />);
    await user.tab();
    expect(tab("one")).toHaveFocus();
    await user.tab();
    expect(screen.getByRole("tabpanel", { name: "one" })).toHaveFocus();
  });

  it("selects a tab on click and calls onValueChange", async () => {
    const user = userEvent.setup();
    const onValueChange = vi.fn();
    render(<Harness values={THREE} defaultValue="one" onValueChange={onValueChange} />);
    await user.click(tab("three"));
    expect(onValueChange).toHaveBeenCalledWith("three");
    expect(onValueChange).toHaveBeenCalledTimes(1);
    expect(tab("three")).toHaveAttribute("aria-selected", "true");
  });

  it("does not change selection in controlled mode unless the parent updates value", async () => {
    const user = userEvent.setup();
    const onValueChange = vi.fn();
    render(<Harness values={THREE} value="one" onValueChange={onValueChange} />);
    await user.click(tab("two"));
    expect(onValueChange).toHaveBeenCalledWith("two");
    expect(tab("one")).toHaveAttribute("aria-selected", "true");
    expect(tab("two")).toHaveAttribute("aria-selected", "false");
  });

  it("moves selection in controlled mode when the parent updates value", async () => {
    const user = userEvent.setup();
    const onValueChange = vi.fn();
    render(<Controlled onValueChange={onValueChange} />);
    await user.click(tab("two"));
    expect(tab("two")).toHaveAttribute("aria-selected", "true");
    expect(onValueChange).toHaveBeenCalledWith("two");
  });

  it("moves focus and selection with ArrowRight and ArrowLeft, wrapping at the ends", async () => {
    const user = userEvent.setup();
    const onValueChange = vi.fn();
    render(<Harness values={THREE} defaultValue="one" onValueChange={onValueChange} />);
    tab("one").focus();
    await user.keyboard("{ArrowRight}");
    expect(tab("two")).toHaveFocus();
    expect(tab("two")).toHaveAttribute("aria-selected", "true");
    await user.keyboard("{ArrowLeft}{ArrowLeft}");
    expect(tab("three")).toHaveFocus();
    expect(tab("three")).toHaveAttribute("aria-selected", "true");
    await user.keyboard("{ArrowRight}");
    expect(tab("one")).toHaveFocus();
    expect(onValueChange.mock.calls).toEqual([["two"], ["one"], ["three"], ["one"]]);
  });

  it("jumps to the first and last enabled tab with Home and End", async () => {
    const user = userEvent.setup();
    render(<Harness values={THREE} defaultValue="two" />);
    tab("two").focus();
    await user.keyboard("{End}");
    expect(tab("three")).toHaveFocus();
    expect(tab("three")).toHaveAttribute("aria-selected", "true");
    await user.keyboard("{Home}");
    expect(tab("one")).toHaveFocus();
    expect(tab("one")).toHaveAttribute("aria-selected", "true");
  });

  it("skips disabled tabs when arrowing", async () => {
    const user = userEvent.setup();
    render(<Harness values={THREE} defaultValue="one" disabled={["two"]} />);
    tab("one").focus();
    await user.keyboard("{ArrowRight}");
    expect(tab("three")).toHaveFocus();
    await user.keyboard("{ArrowRight}");
    expect(tab("one")).toHaveFocus();
    await user.keyboard("{ArrowLeft}");
    expect(tab("three")).toHaveFocus();
  });

  it("leaves other keys alone and does not preventDefault them", () => {
    render(<Harness values={THREE} defaultValue="one" />);
    tab("one").focus();
    expect(fireEvent.keyDown(tab("one"), { key: "a" })).toBe(true);
    expect(fireEvent.keyDown(tab("one"), { key: "ArrowDown" })).toBe(true);
    expect(fireEvent.keyDown(tab("one"), { key: "Enter" })).toBe(true);
    expect(tab("one")).toHaveFocus();
    expect(tab("one")).toHaveAttribute("aria-selected", "true");
  });

  it("does not select a disabled tab on click", async () => {
    const user = userEvent.setup();
    const onValueChange = vi.fn();
    render(<Harness values={THREE} defaultValue="one" disabled={["two"]} onValueChange={onValueChange} />);
    await user.click(tab("two"));
    expect(onValueChange).not.toHaveBeenCalled();
    expect(tab("one")).toHaveAttribute("aria-selected", "true");
    expect(tab("two")).toHaveAttribute("aria-disabled", "true");
    expect(tab("two")).toBeDisabled();
  });

  it("keeps focus on the only enabled tab when arrowing, without looping", async () => {
    const user = userEvent.setup();
    render(<Harness values={THREE} disabled={["one", "three"]} />);
    tab("two").focus();
    await user.keyboard("{ArrowRight}{ArrowLeft}{Home}{End}");
    expect(tab("two")).toHaveFocus();
    expect(tab("two")).toHaveAttribute("aria-selected", "true");
  });

  it("renders no selection and does not crash when every tab is disabled", () => {
    render(<Harness values={THREE} disabled={THREE} />);
    expect(screen.getAllByRole("tab").every((element) => element.getAttribute("aria-selected") === "false")).toBe(true);
    expect(screen.queryByRole("tabpanel")).toBeNull();
    fireEvent.keyDown(tab("one"), { key: "ArrowRight" });
    fireEvent.keyDown(tab("one"), { key: "End" });
    expect(screen.getAllByRole("tab")).toHaveLength(3);
    expect(tab("one")).toHaveAttribute("aria-selected", "false");
  });

  it("follows DOM order as tabs are added and removed", async () => {
    const user = userEvent.setup();
    const { rerender } = render(<Harness values={["a", "c"]} />);
    rerender(<Harness values={["a", "b", "c"]} />);
    tab("a").focus();
    await user.keyboard("{ArrowRight}");
    expect(tab("b")).toHaveFocus();
    rerender(<Harness values={["a", "c"]} />);
    tab("a").focus();
    await user.keyboard("{ArrowRight}");
    expect(tab("c")).toHaveFocus();
  });

  it("falls back to the first enabled tab when the selected tab is removed", () => {
    const { rerender } = render(<Harness values={THREE} defaultValue="two" />);
    rerender(<Harness values={["one", "three"]} />);
    expect(tab("one")).toHaveAttribute("aria-selected", "true");
    expect(tab("one")).toHaveAttribute("tabindex", "0");
  });

  it("keeps ids unique and keyboard handling separate across two instances", async () => {
    const user = userEvent.setup();
    render(
      <>
        <Harness values={THREE} defaultValue="one" />
        <Harness values={THREE} defaultValue="one" />
      </>,
    );
    const [first, second] = screen.getAllByRole("tablist").map((list) => within(list).getAllByRole("tab"));
    const ids = [...first, ...second].map((element) => element.id);
    expect(new Set(ids).size).toBe(ids.length);
    first[0].focus();
    await user.keyboard("{ArrowRight}");
    expect(first[1]).toHaveFocus();
    expect(first[1]).toHaveAttribute("aria-selected", "true");
    expect(second[0]).toHaveAttribute("aria-selected", "true");
    expect(second[1]).toHaveAttribute("aria-selected", "false");
  });

  it("produces valid ids for values with spaces and special characters", async () => {
    const user = userEvent.setup();
    const values = ["new york", 'a"b', "x/y?z#"];
    render(<Harness values={values} defaultValue="new york" />);
    for (const value of values) {
      const element = tab(value);
      expect(element.id).not.toMatch(/\s/);
      expect(panelOf(element)).toHaveAttribute("aria-labelledby", element.id);
    }
    tab("new york").focus();
    await user.keyboard("{ArrowRight}");
    expect(screen.getByRole("tabpanel", { name: 'a"b' })).toBeVisible();
  });

  it("runs a consumer TabList onKeyDown before its own handling, and skips arrows it prevents", async () => {
    const user = userEvent.setup();
    const calls: string[] = [];
    render(
      <Tabs defaultValue="one">
        <TabList
          aria-label="Sections"
          onKeyDown={(event) => {
            calls.push(`${event.key}:${tab("one").getAttribute("aria-selected")}`);
            if (event.key === "End") event.preventDefault();
          }}
        >
          {THREE.map((value) => (
            <Tab key={value} value={value}>
              {value}
            </Tab>
          ))}
        </TabList>
      </Tabs>,
    );
    tab("one").focus();
    await user.keyboard("{ArrowRight}");
    expect(tab("two")).toHaveFocus();
    expect(tab("two")).toHaveAttribute("aria-selected", "true");
    await user.keyboard("{End}");
    expect(tab("two")).toHaveFocus();
    expect(tab("two")).toHaveAttribute("aria-selected", "true");
    expect(calls).toEqual(["ArrowRight:true", "End:false"]);
  });

  it("renders values with lone surrogates without throwing, with distinct ids", () => {
    render(<Harness values={["a\uD800", "b"]} defaultValue="a\uD800" />);
    expect(tab("a\uD800")).toHaveAttribute("aria-selected", "true");
    expect(panelOf(tab("a\uD800"))).toBeVisible();
    expect(tab("a\uD800").id).not.toBe(tab("b").id);
  });

  it("throws a clear error when Tab is rendered outside Tabs", () => {
    const consoleError = vi.spyOn(console, "error").mockImplementation(() => {});
    expect(() => render(<Tab value="x">x</Tab>)).toThrow("Tab must be used inside <Tabs>");
    consoleError.mockRestore();
  });
});

# @acme/ui

Accessible React 19 components in TypeScript. They follow the WAI-ARIA Authoring Practices patterns, ship no CSS, and take `className` and other HTML props for styling. Ids come from `useId`, so several instances can share a page.

## Install and use

Requires `react` and `react-dom` 19. There are no other runtime dependencies.

```tsx
import { Combobox, Dialog, Tab, TabList, TabPanel, Tabs } from "@acme/ui";

<Tabs defaultValue="profile">
  <TabList aria-label="Account">
    <Tab value="profile">Profile</Tab>
    <Tab value="billing">Billing</Tab>
    <Tab value="legacy" disabled>Legacy</Tab>
  </TabList>
  <TabPanel value="profile">Profile content</TabPanel>
  <TabPanel value="billing">Billing content</TabPanel>
</Tabs>

<Dialog open={open} onOpenChange={setOpen} title="Delete file" description="This cannot be undone.">
  <button onClick={confirm}>Delete</button>
</Dialog>

<Combobox
  label="Fruit"
  options={[{ value: "apple", label: "Apple" }, { value: "pear", label: "Pear", disabled: true }]}
  value={fruit}
  onChange={setFruit}
/>
```

Exports: `Tabs`, `TabList`, `Tab`, `TabPanel`, `Dialog`, `Combobox`, and the types `TabsProps`, `TabListProps`, `TabProps`, `TabPanelProps`, `DialogProps`, `ComboboxProps`, `ComboboxOption`.

## Tabs

Uncontrolled with `defaultValue`, or controlled with `value`. Without either, the first enabled tab is selected. In controlled mode the selection changes only when the parent updates `value`. `onValueChange` fires on a user change in both modes, but not when the tab is already selected.

| Component | Prop | Type | Notes |
| --- | --- | --- | --- |
| `Tabs` | `defaultValue` | `string` | Initial selection (uncontrolled) |
| `Tabs` | `value` | `string` | Selection (controlled) |
| `Tabs` | `onValueChange` | `(value: string) => void` | Called when the user selects a tab |
| `Tabs` | `...div props` | `HTMLDivElement` attributes | Passed to the wrapping `div` |
| `TabList` | `aria-label` | `string` (required) | Names the `tablist` |
| `TabList` | `...div props` | `HTMLDivElement` attributes | Passed to the `div role="tablist"` |
| `Tab` | `value` | `string` (required) | Identifies the tab and its panel |
| `Tab` | `disabled` | `boolean` | Skipped by keyboard, ignored by click |
| `Tab` | `...button props` | `ButtonHTMLAttributes` | Passed to the `button role="tab"` |
| `TabPanel` | `value` | `string` (required) | Panel for the tab with the same value |
| `TabPanel` | `...div props` | `HTMLDivElement` attributes | Passed to the `div role="tabpanel"` |

Panels are always rendered and `hidden` when not selected, so `aria-controls` always resolves. Tabs are read from the DOM, so tabs added or removed later keep the DOM order.

### Tabs keyboard

| Key | Action |
| --- | --- |
| `ArrowRight` | Focus and select the next enabled tab; wraps from last to first |
| `ArrowLeft` | Focus and select the previous enabled tab; wraps from first to last |
| `Home` | Focus and select the first enabled tab |
| `End` | Focus and select the last enabled tab |
| `Tab` | Leaves the tablist, moving to the selected tab's panel |

Other keys are not handled and are not `preventDefault`ed. Only the selected tab has `tabIndex=0`. In controlled mode, arrowing moves focus, but `aria-selected` only changes when the parent updates `value`.

A consumer `onKeyDown` on `TabList` runs first. If it calls `preventDefault`, the keys above are skipped.

## Dialog

Renders into `document.body` through a portal, and only while `open` is true. Focus moves to the first tabbable element on open, or to the dialog itself if there is none. Focus is trapped inside. On close or unmount, focus returns to the element that had it before opening, if that element is still in the document.

| Prop | Type | Notes |
| --- | --- | --- |
| `open` | `boolean` (required) | Renders only when true |
| `onOpenChange` | `(open: boolean) => void` (required) | Called with `false` on Escape or backdrop click |
| `title` | `ReactNode` (required) | Rendered in an `h2`; names the dialog |
| `description` | `ReactNode` | Optional; when set, referenced by `aria-describedby` |
| `overlayClassName` | `string` | Class for the backdrop wrapper, which you style as an overlay |
| `children` | `ReactNode` | Dialog body |
| `...div props` | `HTMLDivElement` attributes | Passed to the `div role="dialog"` |

A backdrop click dismisses only when the press started and ended on the backdrop.

Escape is handled by a `keydown` listener on `document`. It is skipped when a nested handler has called `preventDefault` on the event. A nested React handler that calls `stopPropagation` also prevents it, because the event stops before it reaches `document`.

### Dialog keyboard

| Key | Action |
| --- | --- |
| `Escape` | Calls `onOpenChange(false)` (unless the event was already `preventDefault`ed) |
| `Tab` | Moves to the next tabbable element; wraps from last to first |
| `Shift+Tab` | Moves to the previous tabbable element; wraps from first to last |

With no tabbable elements, `Tab` keeps focus on the dialog. Disabled elements, elements with a negative `tabindex`, and elements inside a `hidden` or `inert` ancestor are not tabbable. The dialog handles `Tab` itself, so focus never falls to the page from a non-tabbable element such as a `tabIndex={-1}` span.

## Combobox

A text input with `role="combobox"`, a visible `label`, and a `listbox` popup. The input shows the selected option's label when not typing. Typing opens the popup and filters options by case-insensitive substring of their label.

| Prop | Type | Notes |
| --- | --- | --- |
| `label` | `string` (required) | Visible label, associated with the input |
| `options` | `ComboboxOption[]` (required) | `{ value: string; label: string; disabled?: boolean }` |
| `value` | `string \| null` (required) | Selected option's value; `null` means none. Controlled |
| `onChange` | `(value: string \| null) => void` (required) | Called on selection, and with `null` when text is cleared and the input is left |
| `placeholder` | `string` | Passed to the input |
| `...input props` | `InputHTMLAttributes` | Passed to the input. `value`, `onChange`, `role`, and `label` are owned by the component. A consumer `onKeyDown` and `onBlur` are called first; if `onKeyDown` calls `preventDefault`, the component's key handling is skipped |

Behavior notes:
- Clearing the text and then leaving the field calls `onChange(null)`. Pressing Enter with empty text does nothing.
- Leaving the field with other text restores the selected label without calling `onChange`.
- A value that is not in `options` shows an empty input.
- Filter text is matched literally, so regex characters are safe.
- When nothing matches (or `options` is empty), the popup shows "No results" in a `role="status"` element, so it is announced. It is not an `option`.
- Disabled options are never active or chosen. If the active option becomes disabled, Enter does nothing.

### Combobox keyboard

| Key | Action |
| --- | --- |
| `ArrowDown` | Opens the popup if closed (and activates the first enabled option); otherwise moves to the next enabled option after the active one in list order (the active one may be disabled), wrapping at the end |
| `ArrowUp` | Opens the popup if closed (and activates the last enabled option); otherwise moves to the previous enabled option before the active one, wrapping at the start |
| `Enter` | With an active option: selects it, closes the popup, and shows its label. With the popup open and no active option: does nothing and does not submit a form |
| `Escape` | With the popup open: closes it, restores the selected label, and calls nothing. Otherwise passes through |

Click selects an enabled option. Clicking a disabled option does nothing. Pressing an option does not move focus out of the input. Typing resets the active option. Blur closes the popup.

## Development

```sh
pnpm install
pnpm test        # run the Vitest suite (jsdom + Testing Library)
pnpm typecheck   # tsc --noEmit with strict mode
pnpm vitest run src/Tabs   # run one component's tests
```

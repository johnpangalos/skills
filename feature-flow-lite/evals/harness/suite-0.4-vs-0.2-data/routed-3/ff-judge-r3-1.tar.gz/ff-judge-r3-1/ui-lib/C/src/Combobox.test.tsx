import { render, screen } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { useState } from "react";
import { describe, expect, it, vi } from "vitest";
import { Combobox, type ComboboxOption } from "./Combobox";

const fruits: ComboboxOption[] = [
  { value: "apple", label: "Apple" },
  { value: "banana", label: "Banana", disabled: true },
  { value: "blueberry", label: "Blueberry" },
  { value: "cherry", label: "Cherry" },
];

function Harness({
  initial = null,
  options = fruits,
  onChange = () => {},
}: {
  initial?: string | null;
  options?: ComboboxOption[];
  onChange?: (value: string | null) => void;
}) {
  const [value, setValue] = useState<string | null>(initial);
  return (
    <Combobox
      autoFocus
      label="Fruit"
      options={options}
      placeholder="Pick a fruit"
      value={value}
      onChange={(next) => {
        onChange(next);
        setValue(next);
      }}
    />
  );
}

const input = () => screen.getByRole("combobox", { name: "Fruit" });
const option = (label: string) => screen.getByRole("option", { name: label });
const listbox = () => screen.getByRole("listbox");

describe("Combobox ARIA", () => {
  it("links the label to the input and wires the listbox", async () => {
    const user = userEvent.setup();
    render(<Harness initial="cherry" />);
    const element = input();
    expect(element).toHaveAttribute("aria-expanded", "false");
    expect(element).toHaveAttribute("aria-autocomplete", "list");
    expect(element).toHaveAttribute("placeholder", "Pick a fruit");
    expect(document.getElementById(element.getAttribute("aria-controls") ?? "")).toHaveAttribute("role", "listbox");

    await user.keyboard("{ArrowDown}");
    expect(element).toHaveAttribute("aria-expanded", "true");
    expect(listbox()).toHaveAccessibleName("Fruit");
    expect(option("Cherry")).toHaveAttribute("aria-selected", "true");
    expect(option("Apple")).toHaveAttribute("aria-selected", "false");
    expect(option("Banana")).toHaveAttribute("aria-disabled", "true");
    expect(option("Apple")).not.toHaveAttribute("aria-disabled");
  });

  it("does not render the listbox while closed", () => {
    render(<Harness />);
    expect(screen.queryByRole("listbox")).not.toBeInTheDocument();
  });
});

describe("Combobox filtering", () => {
  it("opens on typing and filters case-insensitively", async () => {
    const user = userEvent.setup();
    render(<Harness />);
    await user.type(input(), "BLUE");
    expect(input()).toHaveAttribute("aria-expanded", "true");
    expect(screen.getAllByRole("option")).toHaveLength(1);
    expect(option("Blueberry")).toBeInTheDocument();
  });

  it.each(["(", ".", "a.p", "*", "+"])("treats %s literally", async (query) => {
    const user = userEvent.setup();
    render(<Harness />);
    await user.type(input(), query);
    expect(screen.queryAllByRole("option")).toHaveLength(0);
    expect(screen.getByText("No results")).toBeInTheDocument();
  });

  it("trims the query before matching", async () => {
    const user = userEvent.setup();
    render(<Harness />);
    await user.type(input(), "  app  ");
    expect(screen.getAllByRole("option")).toHaveLength(1);
    expect(option("Apple")).toBeInTheDocument();
  });

  it("shows all options for a whitespace-only query", async () => {
    const user = userEvent.setup();
    render(<Harness />);
    await user.type(input(), "   ");
    expect(screen.getAllByRole("option")).toHaveLength(fruits.length);
  });

  it("shows the selected label when not editing and all options when opened with ArrowDown", async () => {
    const user = userEvent.setup();
    render(<Harness initial="cherry" />);
    expect(input()).toHaveValue("Cherry");
    await user.keyboard("{ArrowDown}");
    expect(screen.getAllByRole("option")).toHaveLength(fruits.length);
  });

  it("shows all options when the text is cleared", async () => {
    const user = userEvent.setup();
    render(<Harness initial="cherry" />);
    await user.clear(input());
    expect(screen.getAllByRole("option")).toHaveLength(fruits.length);
  });
});

describe("Combobox keyboard", () => {
  it("opens with ArrowDown and moves the active option, skipping disabled ones", async () => {
    const user = userEvent.setup();
    render(<Harness />);
    await user.keyboard("{ArrowDown}");
    expect(input()).toHaveAttribute("aria-expanded", "true");
    expect(input()).not.toHaveAttribute("aria-activedescendant");

    await user.keyboard("{ArrowDown}");
    expect(input()).toHaveAttribute("aria-activedescendant", option("Apple").id);
    expect(option("Apple")).toHaveAttribute("data-active", "true");

    await user.keyboard("{ArrowDown}");
    expect(input()).toHaveAttribute("aria-activedescendant", option("Blueberry").id);
    expect(option("Apple")).not.toHaveAttribute("data-active");
    expect(input()).toHaveFocus();
  });

  it("wraps at both ends with ArrowUp and ArrowDown", async () => {
    const user = userEvent.setup();
    render(<Harness />);
    await user.keyboard("{ArrowDown}{ArrowUp}");
    expect(input()).toHaveAttribute("aria-activedescendant", option("Cherry").id);
    await user.keyboard("{ArrowDown}");
    expect(input()).toHaveAttribute("aria-activedescendant", option("Apple").id);
  });

  it("selects the active option on Enter and closes", async () => {
    const user = userEvent.setup();
    const onChange = vi.fn();
    render(<Harness onChange={onChange} />);
    await user.keyboard("{ArrowDown}{ArrowDown}{Enter}");
    expect(onChange).toHaveBeenCalledWith("apple");
    expect(onChange).toHaveBeenCalledTimes(1);
    expect(screen.queryByRole("listbox")).not.toBeInTheDocument();
    expect(input()).toHaveValue("Apple");
    expect(input()).toHaveFocus();
  });

  it("selects on click of an enabled option", async () => {
    const user = userEvent.setup();
    const onChange = vi.fn();
    render(<Harness onChange={onChange} />);
    await user.type(input(), "blue");
    await user.click(option("Blueberry"));
    expect(onChange).toHaveBeenCalledWith("blueberry");
    expect(input()).toHaveValue("Blueberry");
    expect(screen.queryByRole("listbox")).not.toBeInTheDocument();
  });

  it("does nothing when a disabled option is clicked", async () => {
    const user = userEvent.setup();
    const onChange = vi.fn();
    render(<Harness onChange={onChange} />);
    await user.keyboard("{ArrowDown}");
    await user.click(option("Banana"));
    expect(onChange).not.toHaveBeenCalled();
    expect(input()).toHaveAttribute("aria-expanded", "true");
  });

  it("does not select on Enter when no option is active", async () => {
    const user = userEvent.setup();
    const onChange = vi.fn();
    render(<Harness onChange={onChange} />);
    await user.type(input(), "ap");
    await user.keyboard("{Enter}");
    expect(onChange).not.toHaveBeenCalled();
    expect(input()).toHaveValue("ap");
  });

  it("closes on Escape without selecting and reverts the text", async () => {
    const user = userEvent.setup();
    const onChange = vi.fn();
    render(<Harness initial="cherry" onChange={onChange} />);
    await user.type(input(), "xyz");
    await user.keyboard("{ArrowDown}{Escape}");
    expect(onChange).not.toHaveBeenCalled();
    expect(screen.queryByRole("listbox")).not.toBeInTheDocument();
    expect(input()).toHaveValue("Cherry");
    expect(input()).not.toHaveAttribute("aria-activedescendant");
  });

  it("closes on blur without selecting and reverts the text", async () => {
    const user = userEvent.setup();
    const onChange = vi.fn();
    render(<Harness initial="cherry" onChange={onChange} />);
    await user.type(input(), "ap");
    await user.tab();
    expect(onChange).not.toHaveBeenCalled();
    expect(input()).toHaveValue("Cherry");
    expect(input()).toHaveAttribute("aria-expanded", "false");
  });

  it("shows No results without options and ignores Enter", async () => {
    const user = userEvent.setup();
    const onChange = vi.fn();
    render(<Harness onChange={onChange} />);
    await user.type(input(), "zzz");
    expect(screen.getByText("No results")).toBeInTheDocument();
    expect(screen.queryByRole("option")).not.toBeInTheDocument();
    await user.keyboard("{Enter}");
    expect(onChange).not.toHaveBeenCalled();
  });
});

describe("Combobox controlled value", () => {
  it("does not change the displayed label until the parent updates value", async () => {
    const user = userEvent.setup();
    const onChange = vi.fn();
    const { rerender } = render(
      <Combobox autoFocus label="Fruit" options={fruits} value="cherry" onChange={onChange} />,
    );
    await user.keyboard("{ArrowDown}{ArrowDown}{Enter}");
    expect(onChange).toHaveBeenCalledWith("apple");
    expect(input()).toHaveValue("Cherry");

    rerender(<Combobox label="Fruit" options={fruits} value="apple" onChange={onChange} />);
    expect(input()).toHaveValue("Apple");
  });

  it("shows an empty input for a null value", () => {
    render(<Harness />);
    expect(input()).toHaveValue("");
  });

  it("shows an empty input when the value is not among the options", () => {
    render(<Combobox label="Fruit" options={fruits} value="kiwi" onChange={() => {}} />);
    expect(input()).toHaveValue("");
  });

  it("calls onChange(null) when the cleared text is confirmed with Enter", async () => {
    const user = userEvent.setup();
    const onChange = vi.fn();
    render(<Harness initial="cherry" onChange={onChange} />);
    await user.clear(input());
    await user.keyboard("{Enter}");
    expect(onChange).toHaveBeenCalledWith(null);
    expect(onChange).toHaveBeenCalledTimes(1);
    expect(screen.queryByRole("listbox")).not.toBeInTheDocument();
  });

  it("calls onChange(null) when the cleared text is blurred", async () => {
    const user = userEvent.setup();
    const onChange = vi.fn();
    render(<Harness initial="cherry" onChange={onChange} />);
    await user.clear(input());
    await user.tab();
    expect(onChange).toHaveBeenCalledWith(null);
  });

  it("does not call onChange(null) for cleared text when the value is already null", async () => {
    const user = userEvent.setup();
    const onChange = vi.fn();
    render(<Harness onChange={onChange} />);
    await user.type(input(), "a");
    await user.clear(input());
    await user.keyboard("{Enter}");
    await user.type(input(), "a");
    await user.clear(input());
    await user.tab();
    expect(onChange).not.toHaveBeenCalled();
  });

  it("does not call onChange when clearing is cancelled with Escape", async () => {
    const user = userEvent.setup();
    const onChange = vi.fn();
    render(<Harness initial="cherry" onChange={onChange} />);
    await user.clear(input());
    await user.keyboard("{Escape}");
    expect(onChange).not.toHaveBeenCalled();
    expect(input()).toHaveValue("Cherry");
  });
});

describe("Combobox hostile options", () => {
  it("keeps no active option and ignores Enter when every option is disabled", async () => {
    const user = userEvent.setup();
    const onChange = vi.fn();
    render(
      <Harness
        options={[{ value: "x", label: "X", disabled: true }]}
        onChange={onChange}
      />,
    );
    await user.keyboard("{ArrowDown}{ArrowDown}");
    expect(input()).not.toHaveAttribute("aria-activedescendant");
    await user.keyboard("{Enter}");
    expect(onChange).not.toHaveBeenCalled();
  });

  it("keeps the active option when it is still present after options change", async () => {
    const user = userEvent.setup();
    const { rerender } = render(
      <Combobox autoFocus label="Fruit" options={fruits} value={null} onChange={() => {}} />,
    );
    await user.keyboard("{ArrowDown}{ArrowDown}");
    const appleId = option("Apple").id;
    rerender(
      <Combobox
        label="Fruit"
        options={[{ value: "kiwi", label: "Kiwi" }, ...fruits]}
        value={null}
        onChange={() => {}}
      />,
    );
    expect(input()).toHaveAttribute("aria-activedescendant", appleId);
  });

  it("resets the active option when it disappears from the options", async () => {
    const user = userEvent.setup();
    const { rerender } = render(
      <Combobox autoFocus label="Fruit" options={fruits} value={null} onChange={() => {}} />,
    );
    await user.keyboard("{ArrowDown}{ArrowDown}");
    expect(input()).toHaveAttribute("aria-activedescendant");
    rerender(
      <Combobox
        label="Fruit"
        options={fruits.filter((item) => item.value !== "apple")}
        value={null}
        onChange={() => {}}
      />,
    );
    expect(input()).not.toHaveAttribute("aria-activedescendant");
  });
});

import {
  createContext,
  useContext,
  useId,
  useLayoutEffect,
  useRef,
  useState,
  type ComponentPropsWithoutRef,
  type KeyboardEvent,
} from "react";

type TabsContextValue = {
  baseId: string;
  selected: string | undefined;
  select: (value: string) => void;
  adoptSelection: (value: string) => void;
};

const TabsContext = createContext<TabsContextValue | null>(null);

function useTabsContext(component: string): TabsContextValue {
  const context = useContext(TabsContext);
  if (!context) throw new Error(`${component} must be used inside <Tabs>`);
  return context;
}

// Each UTF-16 code unit becomes hex, joined by "-". Unlike encodeURIComponent it never throws on lone surrogates,
// it is injective (the "-" separator never appears inside a hex group), and the result is always id-safe.
const encodeValue = (value: string) =>
  Array.from({ length: value.length }, (_, index) => value.charCodeAt(index).toString(16)).join("-");
const tabId = (baseId: string, value: string) => `${baseId}-tab-${encodeValue(value)}`;
const panelId = (baseId: string, value: string) => `${baseId}-panel-${encodeValue(value)}`;

// Tabs are read from the DOM so the order always matches what is rendered, even as tabs come and go.
function ownTabs(list: HTMLElement): HTMLButtonElement[] {
  return Array.from(list.querySelectorAll<HTMLButtonElement>('[role="tab"]')).filter(
    (tab) => tab.closest('[role="tablist"]') === list,
  );
}

function nextTab(tabs: HTMLButtonElement[], index: number, key: string): HTMLButtonElement {
  switch (key) {
    case "ArrowRight":
      return tabs[(index + 1) % tabs.length];
    case "ArrowLeft":
      return tabs[(index - 1 + tabs.length) % tabs.length];
    case "Home":
      return tabs[0];
    default:
      return tabs[tabs.length - 1];
  }
}

export type TabsProps = Omit<ComponentPropsWithoutRef<"div">, "defaultValue"> & {
  defaultValue?: string;
  value?: string;
  onValueChange?: (value: string) => void;
};

export function Tabs({ defaultValue, value, onValueChange, children, ...rest }: TabsProps) {
  const baseId = useId();
  const [uncontrolled, setUncontrolled] = useState(defaultValue);
  const isControlled = value !== undefined;
  const selected = isControlled ? value : uncontrolled;

  const select = (next: string) => {
    if (next === selected) return;
    if (!isControlled) setUncontrolled(next);
    onValueChange?.(next);
  };

  // Used only to pick a starting tab when none was requested; it never notifies onValueChange.
  const adoptSelection = (next: string) => {
    if (!isControlled) setUncontrolled(next);
  };

  return (
    <TabsContext.Provider value={{ baseId, selected, select, adoptSelection }}>
      <div {...rest}>{children}</div>
    </TabsContext.Provider>
  );
}

export type TabListProps = ComponentPropsWithoutRef<"div"> & {
  "aria-label": string;
};

export function TabList({ children, onKeyDown: onConsumerKeyDown, ...rest }: TabListProps) {
  const { selected, select, adoptSelection } = useTabsContext("TabList");
  const listRef = useRef<HTMLDivElement>(null);

  // Runs after every render: if nothing (or a disabled tab) is selected, fall back to the first enabled tab.
  useLayoutEffect(() => {
    const list = listRef.current;
    if (!list) return;
    const tabs = ownTabs(list);
    const current = tabs.find((tab) => tab.dataset.value === selected);
    if (current && !current.disabled) return;
    const first = tabs.find((tab) => !tab.disabled);
    if (first) adoptSelection(first.dataset.value ?? "");
  });

  const onKeyDown = (event: KeyboardEvent<HTMLDivElement>) => {
    onConsumerKeyDown?.(event);
    if (event.defaultPrevented) return;
    const list = listRef.current;
    const keys = ["ArrowLeft", "ArrowRight", "Home", "End"];
    if (!list || !keys.includes(event.key)) return;
    const enabled = ownTabs(list).filter((tab) => !tab.disabled);
    const index = enabled.indexOf(event.target as HTMLButtonElement);
    if (index === -1) return;
    event.preventDefault();
    const target = nextTab(enabled, index, event.key);
    target.focus();
    select(target.dataset.value ?? "");
  };

  return (
    <div {...rest} role="tablist" ref={listRef} onKeyDown={onKeyDown}>
      {children}
    </div>
  );
}

export type TabProps = Omit<ComponentPropsWithoutRef<"button">, "value"> & {
  value: string;
  disabled?: boolean;
};

export function Tab({ value, disabled = false, onClick, ...rest }: TabProps) {
  const { baseId, selected, select } = useTabsContext("Tab");
  const isSelected = selected === value;

  return (
    <button
      type="button"
      {...rest}
      role="tab"
      id={tabId(baseId, value)}
      data-value={value}
      aria-selected={isSelected}
      aria-controls={panelId(baseId, value)}
      aria-disabled={disabled || undefined}
      disabled={disabled}
      tabIndex={isSelected ? 0 : -1}
      onClick={(event) => {
        onClick?.(event);
        select(value);
      }}
    />
  );
}

export type TabPanelProps = ComponentPropsWithoutRef<"div"> & {
  value: string;
};

export function TabPanel({ value, ...rest }: TabPanelProps) {
  const { baseId, selected } = useTabsContext("TabPanel");

  return (
    <div
      {...rest}
      role="tabpanel"
      id={panelId(baseId, value)}
      aria-labelledby={tabId(baseId, value)}
      tabIndex={0}
      hidden={selected !== value}
    />
  );
}

# @acme/ui

Accessible React components. Style-agnostic (no CSS shipped), no runtime dependencies beyond the `react` and `react-dom` peers.

```tsx
import { Tabs, TabList, Tab, TabPanel, Dialog, Combobox } from "@acme/ui";
```

## Tabs

Follows the [WAI-ARIA tabs pattern](https://www.w3.org/WAI/ARIA/apg/patterns/tabs/). Works uncontrolled (`defaultValue`) or controlled (`value` + `onValueChange`).

### Props

| Component | Prop | Type | Description |
| --- | --- | --- | --- |
| `Tabs` | `defaultValue` | `string` | Initially selected tab (uncontrolled). Defaults to the first enabled tab. |
| `Tabs` | `value` | `string` | Selected tab (controlled). Wins over `defaultValue`. |
| `Tabs` | `onValueChange` | `(value: string) => void` | Called when the user selects a tab. |
| `Tabs` | `...div props` | `HTMLAttributes<HTMLDivElement>` | Passed to the wrapping `div`. |
| `TabList` | `aria-label` | `string` (required) | Accessible name of the `tablist`. |
| `TabList` | `...div props` | `HTMLAttributes<HTMLDivElement>` | Passed to the `div` with `role="tablist"`. |
| `Tab` | `value` | `string` (required) | Identifies the tab and links it to its panel. |
| `Tab` | `disabled` | `boolean` | Skipped by keyboard navigation; cannot be selected by click. Rendered with `aria-disabled="true"`. |
| `Tab` | `...button props` | `ButtonHTMLAttributes<HTMLButtonElement>` | Passed to the `<button type="button" role="tab">`. |
| `TabPanel` | `value` | `string` (required) | The tab this panel belongs to. Hidden unless selected. |
| `TabPanel` | `...div props` | `HTMLAttributes<HTMLDivElement>` | Passed to the `div` with `role="tabpanel"`. |

### Keyboard

| Key | Behavior |
| --- | --- |
| `ArrowRight` / `ArrowLeft` | Move focus to the next / previous enabled tab, wrapping at the ends, and select it. |
| `Home` / `End` | Move focus to the first / last enabled tab and select it. |
| `Tab` | Leaves the tablist (only the selected tab is in the tab order). |

Tab order follows DOM order, including tabs added later. Disabled tabs are skipped. If the selected value matches no enabled tab, the first enabled tab becomes the tab stop.

## Dialog

A modal rendered into `document.body` through a portal. Follows the [WAI-ARIA dialog (modal) pattern](https://www.w3.org/WAI/ARIA/apg/patterns/dialogs/modal-dialog/).

### Props

| Prop | Type | Description |
| --- | --- | --- |
| `open` | `boolean` (required) | Renders the dialog and backdrop when `true`; renders nothing when `false`. |
| `onOpenChange` | `(open: boolean) => void` (required) | Called with `false` on Escape or a backdrop click. |
| `title` | `string` (required) | Rendered as an `h2` and used as the accessible name. |
| `description` | `string` | Rendered as a `p` and used as the accessible description. Omitted when not given. |
| `children` | `ReactNode` | Dialog body. |
| `...div props` | `HTMLAttributes<HTMLDivElement>` (without `title`) | Passed to the `role="dialog"` element. |

### Keyboard and pointer

| Input | Behavior |
| --- | --- |
| Open | Focus moves to the first focusable element inside the dialog, or to the dialog itself if there is none. |
| `Tab` / `Shift+Tab` | Focus is trapped: `Tab` from the last focusable element wraps to the first, and `Shift+Tab` from the first wraps to the last. |
| `Escape` | Calls `onOpenChange(false)`, unless a focused child already handled the key (for example, an open Combobox list closes first). In nested dialogs, only the innermost one closes. |
| Backdrop click | Calls `onOpenChange(false)` only when the press and the click both start and end on the backdrop. A drag that starts inside the dialog does not close it. |
| Close or unmount | Focus returns to the element that was focused before opening, if it is still in the document. |

## Combobox

A text input with a listbox popup. Follows the [WAI-ARIA combobox pattern (list autocomplete)](https://www.w3.org/WAI/ARIA/apg/patterns/combobox/). Controlled: the parent owns `value`.

### Props

| Prop | Type | Description |
| --- | --- | --- |
| `label` | `string` (required) | Visible label, linked to the input. |
| `options` | `ComboboxOption[]` (required) | `{ value: string; label: string; disabled?: boolean }`. |
| `value` | `string \| null` (required) | Selected option value, or `null` for no selection. Values not in `options` show an empty input. |
| `onChange` | `(value: string \| null) => void` (required) | Called with the chosen option's value, or `null` when the cleared text is confirmed. |
| `placeholder` | `string` | Passed to the input. |
| `...input props` | `InputHTMLAttributes<HTMLInputElement>` (without `value`, `defaultValue`, `onChange`, `type`, `role`) | Passed to the `input`. |

### Behavior

- Typing opens the listbox and filters options by label: case-insensitive substring match on the trimmed query. Regex characters are matched literally. A whitespace-only query shows all options.
- With no text being edited, the input shows the selected option's label.
- Matching nothing shows a "No results" message; Enter does nothing.

### Keyboard

| Key | Behavior |
| --- | --- |
| `ArrowDown` | Opens the listbox if closed. Otherwise moves the active option to the next enabled option, wrapping at the end. |
| `ArrowUp` | Opens the listbox if closed. Otherwise moves the active option to the previous enabled option, wrapping at the start. |
| `Enter` | With an active option: selects it, closes the listbox. With cleared text: calls `onChange(null)` (if a value was set) and closes. Otherwise does nothing. |
| `Escape` | Closes the listbox without selecting and reverts the text to the selected label. |
| Blur | Closes the listbox without selecting and reverts the text. Clearing the text first calls `onChange(null)` (if a value was set). |

Disabled options are skipped by arrow keys and ignore clicks. The active option is exposed through `aria-activedescendant` and marked with `data-active="true"`. The input keeps focus throughout. Clicking an enabled option selects it.

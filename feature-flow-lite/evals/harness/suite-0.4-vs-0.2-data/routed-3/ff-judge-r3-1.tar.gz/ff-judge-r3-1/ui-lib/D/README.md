# @acme/ui

Accessible React components. Typed, style-agnostic (no CSS shipped, no class names applied by default), no runtime dependencies beyond React.

Components: `Tabs`, `TabList`, `Tab`, `TabPanel`, `Dialog`, `Combobox`. All are exported from `src/index.ts` along with their prop types.

## Scripts

- `pnpm test`: run the Vitest suite (jsdom, Testing Library).
- `pnpm typecheck`: run `tsc --noEmit`.

## Usage

```tsx
import { useState } from "react";
import { Combobox, Dialog, Tab, TabList, TabPanel, Tabs, type ComboboxOption } from "@acme/ui";

const fruits: ComboboxOption[] = [
  { value: "apple", label: "Apple" },
  { value: "banana", label: "Banana" },
  { value: "cherry", label: "Cherry", disabled: true },
];

export function Example() {
  const [open, setOpen] = useState(false);
  const [fruit, setFruit] = useState<string | null>(null);

  return (
    <>
      <Tabs defaultValue="details">
        <TabList aria-label="Item">
          <Tab value="details">Details</Tab>
          <Tab value="history">History</Tab>
        </TabList>
        <TabPanel value="details">
          <Combobox label="Fruit" options={fruits} value={fruit} onChange={setFruit} placeholder="Type to search" />
          <button onClick={() => setOpen(true)}>Delete</button>
        </TabPanel>
        <TabPanel value="history">No history yet.</TabPanel>
      </Tabs>

      <Dialog open={open} onOpenChange={setOpen} title="Delete item" description="This cannot be undone.">
        <button onClick={() => setOpen(false)}>Cancel</button>
      </Dialog>
    </>
  );
}
```

## Tabs

Compound set: `Tabs` wraps a `TabList` (the tab strip) and one `TabPanel` per tab.

### Tabs

Renders a `div`. Forwards other `div` attributes (for example `className`).

| Prop            | Type                       | Required | Default                                  |
| --------------- | -------------------------- | -------- | ---------------------------------------- |
| `defaultValue`  | `string`                   | No       | First enabled tab                        |
| `value`         | `string`                   | No       | Uncontrolled (uses `defaultValue`)       |
| `onValueChange` | `(value: string) => void`  | No       | None                                     |
| `children`      | `ReactNode`                | Yes      | None                                     |

Controlled when `value` is given: selection only changes when the parent updates `value`. Uncontrolled otherwise. If the requested value is missing or disabled, the first enabled tab is selected instead. `onValueChange` fires on every user selection change, in both modes, but not when the already-selected tab is chosen again.

### TabList

Renders `role="tablist"` with `aria-orientation="horizontal"`. Forwards other `div` attributes.

| Prop         | Type        | Required | Default |
| ------------ | ----------- | -------- | ------- |
| `aria-label` | `string`    | Yes      | None    |
| `children`   | `ReactNode` | Yes      | None    |

### Tab

Renders a `button` with `role="tab"`. Forwards other button attributes.

| Prop       | Type      | Required | Default |
| ---------- | --------- | -------- | ------- |
| `value`    | `string`  | Yes      | None    |
| `disabled` | `boolean` | No       | `false` |

A disabled tab cannot be clicked, focused, or selected by keyboard. Only the selected tab has `tabIndex={0}`; the others have `-1`.

### TabPanel

Renders `role="tabpanel"` with `tabIndex={0}`, labelled by its tab. Non-selected panels are rendered with the `hidden` attribute.

| Prop       | Type        | Required | Default |
| ---------- | ----------- | -------- | ------- |
| `value`    | `string`    | Yes      | None    |
| `children` | `ReactNode` | No       | None    |

### Tabs keyboard behavior

| Key                 | Action                                                              |
| ------------------- | ------------------------------------------------------------------- |
| `ArrowRight`        | Focus the next enabled tab (wraps from last to first)               |
| `ArrowLeft`         | Focus the previous enabled tab (wraps from first to last)           |
| `Home`              | Focus the first enabled tab                                         |
| `End`               | Focus the last enabled tab                                          |
| `Tab` / `Shift+Tab` | Leave the tab list (only the selected tab is in the tab order)      |

Selection follows focus: moving focus with an arrow or Home/End also selects that tab. `ArrowUp` and `ArrowDown` are not handled. The handled keys call `preventDefault`.

## Dialog

Renders a backdrop and a `role="dialog"` element with `aria-modal="true"` into `document.body` through a portal. Renders nothing while `open` is false. Forwards other `div` attributes to the dialog element.

| Prop            | Type                       | Required | Default |
| --------------- | -------------------------- | -------- | ------- |
| `open`          | `boolean`                  | Yes      | None    |
| `onOpenChange`  | `(open: boolean) => void`  | Yes      | None    |
| `title`         | `ReactNode`                | Yes      | None    |
| `description`   | `ReactNode`                | No       | None    |
| `children`      | `ReactNode`                | No       | None    |
| `backdropProps` | `HTMLAttributes<HTMLDivElement>` | No | None    |

The dialog is labelled by the title element and described by the description element. `aria-describedby` is omitted when there is no description.

The backdrop is a sibling `div` with `data-backdrop=""`, so it can be styled with `[data-backdrop]` selectors. `backdropProps` is spread onto it (for example `backdropProps={{ className: "scrim" }}` or a `style`); its `onMouseDown` and `onClick` handlers run before the dialog's own.

On open, focus moves to the first focusable element inside the dialog, or to the dialog itself when there is none. Focus returns to the element that had it before opening when the dialog closes or unmounts, if that element is still in the document. Focusable elements that are disabled or have `tabIndex={-1}` are skipped.

### Dialog keyboard and pointer behavior

| Input                       | Action                                                                  |
| --------------------------- | ----------------------------------------------------------------------- |
| `Tab`                       | Move to the next focusable element; wraps from last to first            |
| `Shift+Tab`                 | Move to the previous focusable element; wraps from first to last        |
| `Escape`                    | Call `onOpenChange(false)`                                              |
| Click on the backdrop       | Call `onOpenChange(false)` (the press must also start on the backdrop)  |
| Click or drag inside content | Does not close                                                         |

## Combobox

A text input with `role="combobox"` and a listbox popup. The `label` is rendered as a visible `<label>` and names both the input and the listbox. Forwards other `input` attributes (for example `className`, `name`, `disabled`) to the input.

| Prop          | Type                                 | Required | Default |
| ------------- | ------------------------------------ | -------- | ------- |
| `label`       | `string`                             | Yes      | None    |
| `options`     | `ComboboxOption[]`                   | Yes      | None    |
| `value`       | `string \| null`                     | Yes      | None    |
| `onChange`    | `(value: string \| null) => void`    | Yes      | None    |
| `placeholder` | `string`                             | No       | None    |

`ComboboxOption` is `{ value: string; label: string; disabled?: boolean }`.

Controlled only: the input text always follows the selected option's label from `value`. After a choice, Enter, or blur, the text shows `value`'s label, so a parent that ignores `onChange` keeps the old text. Clearing the text to empty and then pressing Enter or blurring calls `onChange(null)` once, but only when `value` is not already `null`.

Filtering is a case-insensitive substring match on `label`. Typed text is treated literally (regex characters are not special). Opening the popup without typing shows all options. When nothing matches, the popup shows "No results" and no `aria-activedescendant` is set.

### Combobox keyboard and pointer behavior

| Input                 | Action                                                                                           |
| --------------------- | ------------------------------------------------------------------------------------------------ |
| Typing                | Opens the popup and filters options; clears the active option                                    |
| `ArrowDown`           | Opens the popup if closed; moves the active option to the next enabled option (wraps)            |
| `ArrowUp`             | Opens the popup if closed; moves the active option to the previous enabled option (wraps)        |
| `Enter`               | Selects the active option and closes; with no active option, clears the selection (`onChange(null)`) if the text was cleared, otherwise does nothing |
| `Escape`              | Closes without selecting and reverts the text to the selected label (or empty); no-op when closed |
| Click an enabled option | Selects it, sets the input text to its label, and closes                                       |
| Click a disabled option | Does nothing                                                                                   |
| Blur (focus leaves)   | Closes and reverts the text to the selected label (or empty); calls `onChange(null)` if the text was cleared and `value` was not `null`, otherwise does not select |

Focus stays in the input while navigating; the active option is exposed through `aria-activedescendant`. Disabled options are skipped by the arrow keys. `Escape` while the popup is open calls `stopPropagation`, so an enclosing `Dialog` stays open.

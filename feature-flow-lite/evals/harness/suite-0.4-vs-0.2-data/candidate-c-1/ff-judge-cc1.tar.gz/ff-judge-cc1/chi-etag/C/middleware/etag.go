package middleware

import (
	"bufio"
	"bytes"
	"crypto/sha256"
	"encoding/hex"
	"errors"
	"maps"
	"net"
	"net/http"
	"strings"
)

// ETag buffers the response to GET and HEAD requests. When the handler responds 200 without an
// ETag header of its own, it sets a strong ETag made from a SHA-256 digest of the body. If the
// request's If-None-Match matches the response's ETag, it answers 304 Not Modified with no body.
//
// Other methods, and responses with a final status other than 200, pass through unchanged. While
// a 200 is buffered, Flush sends nothing, so ETag is not suited to streaming handlers. NoCache
// strips If-None-Match from requests, so don't combine it with ETag on the same route. If the
// handler hijacks the connection after writing, the buffered response is sent as-is, without an
// ETag or a 304.
func ETag(next http.Handler) http.Handler {
	fn := func(w http.ResponseWriter, r *http.Request) {
		if r.Method != http.MethodGet && r.Method != http.MethodHead {
			next.ServeHTTP(w, r)
			return
		}
		ew := &etagResponseWriter{
			ResponseWriter: w,
			head:           r.Method == http.MethodHead,
			ifNoneMatch:    r.Header.Values("If-None-Match"),
		}
		next.ServeHTTP(ew, r)
		ew.finish()
	}
	return http.HandlerFunc(fn)
}

type etagResponseWriter struct {
	http.ResponseWriter

	head        bool
	ifNoneMatch []string

	wroteHeader bool
	// passthrough is set once a final status other than 200 has been sent, or once the response
	// has been committed as-is for a hijack.
	passthrough bool
	// header is the snapshot of the headers taken when a 200 is committed.
	header http.Header
	body   bytes.Buffer
}

func (ew *etagResponseWriter) WriteHeader(code int) {
	// Informational responses are sent at once and are not final. 101 is final in net/http.
	if code >= 100 && code < 200 && code != http.StatusSwitchingProtocols {
		ew.ResponseWriter.WriteHeader(code)
		return
	}
	if ew.wroteHeader {
		if ew.passthrough {
			ew.ResponseWriter.WriteHeader(code) // net/http ignores the superfluous call.
		}
		return
	}
	ew.wroteHeader = true
	if code != http.StatusOK {
		ew.passthrough = true
		ew.ResponseWriter.WriteHeader(code)
		return
	}
	ew.header = ew.Header().Clone()
}

func (ew *etagResponseWriter) Write(p []byte) (int, error) {
	if !ew.wroteHeader {
		ew.WriteHeader(http.StatusOK)
	}
	if ew.passthrough {
		return ew.ResponseWriter.Write(p)
	}
	return ew.body.Write(p)
}

func (ew *etagResponseWriter) Flush() {
	if !ew.wroteHeader {
		ew.WriteHeader(http.StatusOK)
	}
	if !ew.passthrough {
		return
	}
	if f, ok := ew.ResponseWriter.(http.Flusher); ok {
		f.Flush()
	}
}

func (ew *etagResponseWriter) Hijack() (net.Conn, *bufio.ReadWriter, error) {
	hj, ok := ew.ResponseWriter.(http.Hijacker)
	if !ok {
		return nil, nil, errors.New("chi/middleware: http.Hijacker is unavailable on the writer")
	}
	if ew.wroteHeader && !ew.passthrough {
		// The handler may write more raw bytes to the connection, so a hash of this body would be
		// a validator for the wrong representation. The buffered 200 is therefore sent as-is,
		// without an ETag or a 304.
		h := ew.ResponseWriter.Header()
		clear(h)
		maps.Copy(h, ew.header)
		ew.ResponseWriter.WriteHeader(http.StatusOK)
		ew.ResponseWriter.Write(ew.body.Bytes())
		// Hijack would drop the buffered body, so write and flush it here before handing over.
		if f, ok := ew.ResponseWriter.(http.Flusher); ok {
			f.Flush()
		}
		ew.passthrough = true
	}
	conn, rw, err := hj.Hijack()
	if err == nil {
		// The connection now belongs to the handler, so finish has nothing left to send.
		ew.wroteHeader, ew.passthrough = true, true
	}
	return conn, rw, err
}

func (ew *etagResponseWriter) Push(target string, opts *http.PushOptions) error {
	if ps, ok := ew.ResponseWriter.(http.Pusher); ok {
		return ps.Push(target, opts)
	}
	return errors.New("chi/middleware: http.Pusher is unavailable on the writer")
}

func (ew *etagResponseWriter) Unwrap() http.ResponseWriter {
	return ew.ResponseWriter
}

// finish sends the buffered 200 response, or a 304 when If-None-Match matches its ETag.
func (ew *etagResponseWriter) finish() {
	if !ew.wroteHeader {
		ew.WriteHeader(http.StatusOK)
	}
	if ew.passthrough {
		return
	}

	// Restore the headers as they were when the 200 was committed.
	h := ew.ResponseWriter.Header()
	clear(h)
	maps.Copy(h, ew.header)

	if h.Get("ETag") == "" && (!ew.head || ew.body.Len() > 0) {
		h.Set("ETag", etagForBody(ew.body.Bytes()))
	}
	for _, line := range ew.ifNoneMatch {
		if etagListMatches(line, h.Get("ETag")) {
			writeNotModified(ew.ResponseWriter)
			return
		}
	}

	ew.ResponseWriter.WriteHeader(http.StatusOK)
	ew.ResponseWriter.Write(ew.body.Bytes())
}

func etagForBody(body []byte) string {
	sum := sha256.Sum256(body)
	return `"` + hex.EncodeToString(sum[:]) + `"`
}

// writeNotModified mirrors net/http's writeNotModified.
func writeNotModified(w http.ResponseWriter) {
	h := w.Header()
	h.Del("Content-Type")
	h.Del("Content-Length")
	h.Del("Content-Encoding")
	if h.Get("ETag") != "" {
		h.Del("Last-Modified")
	}
	w.WriteHeader(http.StatusNotModified)
}

// etagListMatches reports whether one If-None-Match line matches etag using the weak comparison
// of RFC 9110 §13.1.2. Malformed members are skipped up to the next comma.
func etagListMatches(list, etag string) bool {
	want, tagRest, ok := cutEntityTag(etag)
	ok = ok && tagRest == ""
	for {
		list = strings.TrimLeft(list, " \t,")
		if list == "" {
			return false
		}
		star := list[0] == '*'
		tag, rest, valid := cutEntityTag(list)
		if star {
			rest, valid = list[1:], true
		}
		rest = strings.TrimLeft(rest, " \t")
		if valid && (rest == "" || rest[0] == ',') {
			if star || (ok && tag == want) {
				return true
			}
			list = rest
			continue
		}
		// A malformed member is skipped up to its comma. Junk after a valid tag starts at rest.
		if valid {
			list = rest
		}
		i := strings.IndexByte(list, ',')
		if i < 0 {
			return false
		}
		list = list[i:]
	}
}

// cutEntityTag splits a weak or strong entity-tag off the front of s. The opaque tag may contain
// commas, so it is read up to its closing quote rather than split on commas.
func cutEntityTag(s string) (opaque, rest string, ok bool) {
	s = strings.TrimPrefix(s, "W/")
	if s == "" || s[0] != '"' {
		return "", "", false
	}
	for i := 1; i < len(s); i++ {
		switch c := s[i]; {
		case c == '"':
			return s[1:i], s[i+1:], true
		case c <= ' ' || c == 0x7f:
			// etagc is %x21 / %x23-7E / obs-text, so controls and space are not allowed.
			return "", "", false
		}
	}
	return "", "", false
}

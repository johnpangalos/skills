package middleware

import (
	"bufio"
	"bytes"
	"crypto/sha256"
	"encoding/hex"
	"errors"
	"net"
	"net/http"
	"net/textproto"
	"strconv"
	"strings"
)

// ETag adds a validator to GET and HEAD responses and answers 304 Not Modified
// when the request's If-None-Match matches it.
//
// For GET and HEAD requests the whole response body is buffered in memory until
// the handler returns, so ETag is not for streaming or server-sent event
// endpoints. A 200 response is buffered; any other status is passed through as
// soon as the handler sets it.
//
// If the handler sets no ETag on a 200 response, ETag adds a strong one: the
// hex SHA-256 of the body in double quotes. A HEAD response with no body gets
// no generated ETag.
//
// If an If-None-Match member weak-matches the response's ETag (RFC 9110 section
// 8.8.3.2), or If-None-Match is "*", the response becomes 304 Not Modified with
// an empty body. The 304 keeps the ETag and the other headers, and drops
// Content-Type, Content-Length, Content-Encoding and, when an ETag is present,
// Last-Modified.
//
// Other methods are passed through unchanged.
//
// ETag works with Compress in either order. When Compress wraps ETag, a generated
// validator gets the coding as a suffix (for example "<hex>-gzip"), so the
// identity and encoded responses never share a strong ETag.
func ETag(next http.Handler) http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		if r.Method != http.MethodGet && r.Method != http.MethodHead {
			next.ServeHTTP(w, r)
			return
		}
		ew := &etagResponseWriter{ResponseWriter: w}
		next.ServeHTTP(ew, r)
		ew.finish(r)
	})
}

type etagResponseWriter struct {
	http.ResponseWriter

	status   int          // status the handler chose; 0 until it chooses one
	passthru bool         // the response has been sent; writes go straight through
	hijacked bool         // the connection was taken over; writes are dropped
	body     bytes.Buffer // body of a 200 response, held until finish
	length   int64        // Content-Length the handler declared with its status, or -1
	declared []string     // Content-Length header as the handler had it with its status, or nil
	written  int64        // bytes the handler has written, refused ones included
}

func (w *etagResponseWriter) WriteHeader(code int) {
	if w.hijacked {
		return
	}
	if code >= 100 && code <= 199 && code != http.StatusSwitchingProtocols {
		// Informational responses go out now and do not fix the final status.
		w.ResponseWriter.WriteHeader(code)
		return
	}
	if w.status != 0 {
		// The first status wins. A repeat reaches net/http once the response is passed through.
		if w.passthru {
			w.ResponseWriter.WriteHeader(code)
		}
		return
	}
	w.status = code
	w.length = -1
	w.declared = w.Header()["Content-Length"]
	if n, err := strconv.ParseInt(w.Header().Get("Content-Length"), 10, 64); err == nil && n >= 0 {
		w.length = n
	}
	if code != http.StatusOK {
		w.commit()
	}
}

func (w *etagResponseWriter) Write(p []byte) (int, error) {
	if w.hijacked {
		return 0, http.ErrHijacked
	}
	if w.status == 0 {
		w.WriteHeader(http.StatusOK)
	}
	if w.passthru {
		return w.ResponseWriter.Write(p)
	}
	if len(p) == 0 {
		return 0, nil
	}
	// As in net/http, a write that goes past the declared Content-Length is refused, and later writes are too.
	w.written += int64(len(p))
	if w.length >= 0 && w.written > w.length {
		return 0, http.ErrContentLength
	}
	return w.body.Write(p)
}

func (w *etagResponseWriter) Flush() {
	if w.hijacked {
		return
	}
	if w.status == 0 {
		// As in net/http, a flush before any status means 200, so a later WriteHeader is superfluous.
		w.WriteHeader(http.StatusOK)
	}
	// A buffered response sends nothing until the handler returns.
	if !w.passthru {
		return
	}
	if f, ok := w.ResponseWriter.(http.Flusher); ok {
		f.Flush()
	}
}

func (w *etagResponseWriter) Hijack() (net.Conn, *bufio.ReadWriter, error) {
	hj, ok := w.ResponseWriter.(http.Hijacker)
	if !ok {
		return nil, nil, errors.New("chi/middleware: http.Hijacker is unavailable on the writer")
	}
	if w.status == http.StatusOK && !w.passthru {
		// What was written before the takeover is sent, as it would be without the middleware.
		w.commit()
	}
	w.hijacked = true
	return hj.Hijack()
}

func (w *etagResponseWriter) Push(target string, opts *http.PushOptions) error {
	if ps, ok := w.ResponseWriter.(http.Pusher); ok {
		return ps.Push(target, opts)
	}
	return errors.New("chi/middleware: http.Pusher is unavailable on the writer")
}

func (w *etagResponseWriter) Unwrap() http.ResponseWriter {
	return w.ResponseWriter
}

// commit sends w.status and the buffered body, then passes later writes straight through.
// A body is written without an explicit WriteHeader, so it implies 200 as it would unwrapped.
// Only a 200 response has a body here.
func (w *etagResponseWriter) commit() {
	w.passthru = true
	if w.status == http.StatusOK {
		// net/http takes the headers at WriteHeader, so a Content-Length set after it must not be sent.
		if w.declared == nil {
			w.Header().Del("Content-Length")
		} else {
			w.Header()["Content-Length"] = w.declared
		}
	}
	if w.body.Len() == 0 {
		w.ResponseWriter.WriteHeader(w.status)
		return
	}
	w.ResponseWriter.Write(w.body.Bytes())
}

// finish sends a buffered 200 response once the handler has returned normally.
// A panic skips it, so the recovering middleware's response is the only one sent.
func (w *etagResponseWriter) finish(r *http.Request) {
	if w.hijacked || w.passthru {
		return
	}
	if w.status == 0 {
		w.WriteHeader(http.StatusOK)
	}
	h := w.Header()
	if h.Get("ETag") == "" && (r.Method == http.MethodGet || w.body.Len() > 0) {
		sum := sha256.Sum256(w.body.Bytes())
		tag := hex.EncodeToString(sum[:])
		if coding := pendingCoding(w.ResponseWriter); coding != "" {
			// Compress encodes this body on the way out, so the identity and encoded variants need different validators.
			tag += "-" + coding
		}
		h.Set("ETag", `"`+tag+`"`)
	}
	if !etagNoneMatch(r, h.Get("ETag")) {
		w.commit()
		return
	}
	h.Del("Content-Type")
	h.Del("Content-Length")
	h.Del("Content-Encoding")
	if h.Get("ETag") != "" {
		h.Del("Last-Modified")
	}
	w.body.Reset()
	w.status = http.StatusNotModified
	w.commit()
}

// pendingCoding returns the coding that a Compress middleware wrapping w will apply to the body,
// or "" if it will not. It walks the Unwrap chain to find the Compress writer.
func pendingCoding(w http.ResponseWriter) string {
	for {
		if cw, ok := w.(*compressResponseWriter); ok {
			if cw.encoding == "" || !cw.isCompressible() || cw.Header().Get("Content-Encoding") != "" {
				return ""
			}
			return cw.encoding
		}
		u, ok := w.(interface{ Unwrap() http.ResponseWriter })
		if !ok {
			return ""
		}
		w = u.Unwrap()
	}
}

// etagNoneMatch reports whether any If-None-Match line matches etag. Each line is parsed on its own,
// so a malformed member cannot join with the next line.
func etagNoneMatch(r *http.Request, etag string) bool {
	for _, line := range r.Header.Values("If-None-Match") {
		if etagListMatch(line, etag) {
			return true
		}
	}
	return false
}

// etagListMatch reports whether an If-None-Match list matches etag. A list of just "*" matches any
// response. Inside a list "*" is skipped, and a malformed member ends the list.
func etagListMatch(list, etag string) bool {
	if textproto.TrimString(list) == "*" {
		return true
	}
	buf := list
	for {
		buf = textproto.TrimString(buf)
		if buf == "" {
			return false
		}
		if buf[0] == ',' || buf[0] == '*' {
			buf = buf[1:]
			continue
		}
		member, remain := scanETag(buf)
		if member == "" {
			return false
		}
		if strings.TrimPrefix(member, "W/") == strings.TrimPrefix(etag, "W/") {
			return true
		}
		buf = remain
	}
}

// scanETag returns the entity tag at the start of s and the text after it,
// or "", "" if s does not start with a valid one. It follows net/http's scanETag.
func scanETag(s string) (etag string, remain string) {
	start := 0
	if strings.HasPrefix(s, "W/") {
		start = 2
	}
	if len(s[start:]) < 2 || s[start] != '"' {
		return "", ""
	}
	// ETag is either W/"text" or "text".
	for i := start + 1; i < len(s); i++ {
		c := s[i]
		switch {
		// Character values allowed in ETags.
		case c == 0x21 || c >= 0x23 && c <= 0x7E || c >= 0x80:
		case c == '"':
			return s[:i+1], s[i+1:]
		default:
			return "", ""
		}
	}
	return "", ""
}

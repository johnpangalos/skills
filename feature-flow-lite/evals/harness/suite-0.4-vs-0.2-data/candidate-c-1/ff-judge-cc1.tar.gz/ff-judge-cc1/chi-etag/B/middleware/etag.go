package middleware

import (
	"bufio"
	"bytes"
	"crypto/sha256"
	"encoding/hex"
	"errors"
	"maps"
	"net"
	"net/http"
	"net/textproto"
	"strings"
)

// ETag is a middleware that adds a strong ETag, computed from the full body,
// to GET and HEAD responses with a 200 status that don't set their own ETag.
// If the request's If-None-Match matches the response's ETag (computed or set
// by the handler), the response is replaced with 304 Not Modified.
//
// GET and HEAD responses with a 200 status are buffered until the handler
// returns, so the ETag covers the bytes actually sent. While buffering, Flush
// is a no-op and sends nothing to the client. Once a non-200 status is written,
// the response streams through unchanged and Flush is forwarded. Other methods
// pass through untouched.
//
// Register ETag before (outside of) Compress so the ETag is computed over the
// bytes actually sent, after compression.
func ETag(next http.Handler) http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		if r.Method != http.MethodGet && r.Method != http.MethodHead {
			next.ServeHTTP(w, r)
			return
		}
		ew := &etagResponseWriter{
			ResponseWriter: w,
			method:         r.Method,
			ifNoneMatch:    strings.Join(r.Header.Values("If-None-Match"), ", "),
		}
		next.ServeHTTP(ew, r)
		ew.finish()
	})
}

type etagResponseWriter struct {
	http.ResponseWriter

	method      string
	ifNoneMatch string
	// header is the copy of the headers taken when the 200 status is
	// committed. Headers set after that are dropped, as net/http drops them.
	header      http.Header
	buf         bytes.Buffer
	wroteHeader bool
	passthrough bool
}

func (ew *etagResponseWriter) WriteHeader(code int) {
	// Informational responses go out now and are not the final status.
	if code >= 100 && code <= 199 && code != http.StatusSwitchingProtocols {
		ew.ResponseWriter.WriteHeader(code)
		return
	}
	if ew.wroteHeader {
		return
	}
	ew.wroteHeader = true
	if code != http.StatusOK {
		ew.passthrough = true
		ew.ResponseWriter.WriteHeader(code)
		return
	}
	ew.header = ew.Header().Clone()
}

func (ew *etagResponseWriter) Write(p []byte) (int, error) {
	if !ew.wroteHeader {
		ew.WriteHeader(http.StatusOK)
	}
	if ew.passthrough {
		return ew.ResponseWriter.Write(p)
	}
	return ew.buf.Write(p)
}

func (ew *etagResponseWriter) Flush() {
	if !ew.wroteHeader {
		ew.WriteHeader(http.StatusOK)
	}
	if !ew.passthrough {
		return
	}
	if f, ok := ew.ResponseWriter.(http.Flusher); ok {
		f.Flush()
	}
}

func (ew *etagResponseWriter) Hijack() (net.Conn, *bufio.ReadWriter, error) {
	hj, ok := ew.ResponseWriter.(http.Hijacker)
	if !ok {
		return nil, nil, errors.New("chi/middleware: http.Hijacker is unavailable on the writer")
	}
	// A buffered 200 goes to the underlying writer first, so the client gets
	// the status and headers before the handler's raw bytes, as a plain server
	// sends them.
	if ew.wroteHeader && !ew.passthrough {
		ew.restoreHeader()
		ew.ResponseWriter.WriteHeader(http.StatusOK)
		ew.ResponseWriter.Write(ew.buf.Bytes())
	}
	// The handler owns the connection now, so nothing may be buffered out.
	ew.passthrough = true
	return hj.Hijack()
}

func (ew *etagResponseWriter) Push(target string, opts *http.PushOptions) error {
	if ps, ok := ew.ResponseWriter.(http.Pusher); ok {
		return ps.Push(target, opts)
	}
	return errors.New("chi/middleware: http.Pusher is unavailable on the writer")
}

func (ew *etagResponseWriter) Unwrap() http.ResponseWriter {
	return ew.ResponseWriter
}

// finish sends the buffered response. It is not deferred, so a panicking
// handler writes nothing.
func (ew *etagResponseWriter) finish() {
	if ew.passthrough {
		return
	}
	if !ew.wroteHeader {
		ew.WriteHeader(http.StatusOK)
	}

	trailers := ew.trailerValues()
	h := ew.restoreHeader()
	body := ew.buf.Bytes()
	if h.Get("ETag") == "" && (ew.method == http.MethodGet || len(body) > 0) {
		sum := sha256.Sum256(body)
		h.Set("ETag", `"`+hex.EncodeToString(sum[:])+`"`)
	}

	if ifNoneMatchMatches(ew.ifNoneMatch, h.Get("ETag")) {
		h.Del("Content-Type")
		h.Del("Content-Length")
		h.Del("Content-Encoding")
		ew.ResponseWriter.WriteHeader(http.StatusNotModified)
		return
	}
	ew.ResponseWriter.WriteHeader(http.StatusOK)
	ew.ResponseWriter.Write(body)
	// net/http reads trailer values when the handler returns. Copying them in
	// after the header block is committed keeps them out of the headers, as a
	// plain handler does.
	maps.Copy(ew.ResponseWriter.Header(), trailers)
}

// restoreHeader replaces the live headers with the copy taken when the 200
// status was committed, so headers set later are dropped as net/http drops them.
func (ew *etagResponseWriter) restoreHeader() http.Header {
	h := ew.ResponseWriter.Header()
	clear(h)
	maps.Copy(h, ew.header)
	return h
}

// trailerValues returns the live values of the trailers the handler declared in
// the Trailer header, and of the keys written with http.TrailerPrefix.
func (ew *etagResponseWriter) trailerValues() http.Header {
	live := ew.ResponseWriter.Header()
	trailers := make(http.Header)
	for _, v := range ew.header.Values("Trailer") {
		for _, k := range strings.Split(v, ",") {
			k = textproto.CanonicalMIMEHeaderKey(strings.TrimSpace(k))
			if vv, ok := live[k]; ok {
				trailers[k] = vv
			}
		}
	}
	for k, vv := range live {
		if strings.HasPrefix(k, http.TrailerPrefix) {
			trailers[k] = vv
		}
	}
	return trailers
}

// ifNoneMatchMatches reports whether the If-None-Match list matches etag under
// weak comparison (RFC 9110 13.1.2). It follows the scan rules of net/http's
// checkIfNoneMatch: a malformed member ends the scan with no match.
func ifNoneMatchMatches(list, etag string) bool {
	for {
		list = strings.Trim(list, " \t")
		switch {
		case list == "":
			return false
		case list[0] == ',':
			list = list[1:]
		case list[0] == '*':
			return true
		default:
			tag, rest := scanETag(list)
			if tag == "" {
				return false
			}
			if strings.TrimPrefix(tag, "W/") == strings.TrimPrefix(etag, "W/") {
				return true
			}
			list = rest
		}
	}
}

// scanETag splits the entity-tag at the start of s from the text after it.
// It returns an empty tag if s does not start with a valid one.
func scanETag(s string) (tag, rest string) {
	start := 0
	if strings.HasPrefix(s, "W/") {
		start = 2
	}
	if len(s) < start+2 || s[start] != '"' {
		return "", ""
	}
	for i := start + 1; i < len(s); i++ {
		c := s[i]
		switch {
		case c == 0x21 || c >= 0x23 && c <= 0x7E || c >= 0x80:
		case c == '"':
			return s[:i+1], s[i+1:]
		default:
			return "", ""
		}
	}
	return "", ""
}

/*
 * Copyright 2026 Adobe. All rights reserved.
 * This file is licensed to you under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License. You may obtain a copy
 * of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software distributed under
 * the License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR REPRESENTATIONS
 * OF ANY KIND, either express or implied. See the License for the specific language
 * governing permissions and limitations under the License.
 */

import {act, createShadowRoot, waitFor} from '@react-spectrum/test-utils-internal';
import {ariaHideOutside} from '../src';
import {enableShadowDOM} from '@react-stately/flags';

// This file runs with shadow DOM support enabled. enableShadowDOM() cannot be undone, so the
// shadow DOM behavior lives in its own file, where the flag only applies to these tests.
describe('ariaHideOutside with shadow DOM', function () {
  let container;

  let createElement = (tag, parent) => {
    let element = document.createElement(tag);
    parent.appendChild(element);
    return element;
  };

  beforeAll(() => {
    enableShadowDOM();
  });

  beforeEach(() => {
    container = document.createElement('div');
    document.body.appendChild(container);
  });

  afterEach(() => {
    container.remove();
  });

  it('should hide siblings in every enclosing shadow root and keep the hosts on the path visible', function () {
    let outer = createShadowRoot(container);
    let outerSibling = createElement('button', outer.shadowRoot);
    let middle = createElement('div', outer.shadowRoot);
    let inner = createShadowRoot(middle);
    let innerSibling = createElement('input', inner.shadowRoot);
    let target = createElement('input', inner.shadowRoot);
    let lightSibling = createElement('button', container);

    let revert = ariaHideOutside([target]);

    expect(lightSibling).toHaveAttribute('aria-hidden', 'true');
    expect(outerSibling).toHaveAttribute('aria-hidden', 'true');
    expect(innerSibling).toHaveAttribute('aria-hidden', 'true');
    expect(container).not.toHaveAttribute('aria-hidden');
    expect(outer.shadowHost).not.toHaveAttribute('aria-hidden');
    expect(middle).not.toHaveAttribute('aria-hidden');
    expect(inner.shadowHost).not.toHaveAttribute('aria-hidden');
    expect(target).not.toHaveAttribute('aria-hidden');

    revert();
  });

  it('should hide siblings when the target is a direct child of a shadow root', function () {
    let {shadowRoot} = createShadowRoot(container);
    let sibling = createElement('button', shadowRoot);
    let target = createElement('input', shadowRoot);

    let revert = ariaHideOutside([target]);

    expect(sibling).toHaveAttribute('aria-hidden', 'true');
    expect(target).not.toHaveAttribute('aria-hidden');

    revert();
  });

  it('should hide light DOM children of a host that are not slotted targets', function () {
    let host = createElement('div', container);
    let shadowRoot = host.attachShadow({mode: 'open'});
    let slot = createElement('slot', shadowRoot);
    let shadowSibling = createElement('span', shadowRoot);
    let lightSibling = createElement('button', host);
    let target = createElement('input', host);

    let revert = ariaHideOutside([target]);

    expect(shadowSibling).toHaveAttribute('aria-hidden', 'true');
    expect(lightSibling).toHaveAttribute('aria-hidden', 'true');
    expect(host).not.toHaveAttribute('aria-hidden');
    expect(slot).not.toHaveAttribute('aria-hidden');
    expect(target).not.toHaveAttribute('aria-hidden');

    revert();
  });

  it('should keep targets in different shadow roots visible with their host paths', function () {
    let a = createShadowRoot(container);
    let input = createElement('input', a.shadowRoot);
    let aSibling = createElement('button', a.shadowRoot);
    let b = createShadowRoot(container);
    let popover = createElement('div', b.shadowRoot);
    let bSibling = createElement('button', b.shadowRoot);
    let lightSibling = createElement('button', container);

    let revert = ariaHideOutside([input, popover]);

    expect(input).not.toHaveAttribute('aria-hidden');
    expect(popover).not.toHaveAttribute('aria-hidden');
    expect(a.shadowHost).not.toHaveAttribute('aria-hidden');
    expect(b.shadowHost).not.toHaveAttribute('aria-hidden');
    expect(container).not.toHaveAttribute('aria-hidden');
    expect(aSibling).toHaveAttribute('aria-hidden', 'true');
    expect(bSibling).toHaveAttribute('aria-hidden', 'true');
    expect(lightSibling).toHaveAttribute('aria-hidden', 'true');

    revert();
  });

  it('should hide content added to a shadow root after the call, including deep subtrees', async function () {
    let {shadowRoot} = createShadowRoot(container);
    let target = createElement('input', shadowRoot);

    let revert = ariaHideOutside([target]);

    let added = createElement('button', shadowRoot);
    let wrapper = document.createElement('div');
    let deep = createElement('span', wrapper);
    shadowRoot.appendChild(wrapper);

    await waitFor(() => expect(added).toHaveAttribute('aria-hidden', 'true'));
    expect(wrapper).toHaveAttribute('aria-hidden', 'true');
    expect(deep).not.toHaveAttribute('aria-hidden');
    expect(target).not.toHaveAttribute('aria-hidden');

    revert();
  });

  it('should keep live announcers and top layer elements in shadow roots visible', async function () {
    let {shadowRoot} = createShadowRoot(container);
    let existingAnnouncer = createElement('div', shadowRoot);
    existingAnnouncer.dataset.liveAnnouncer = 'true';
    let target = createElement('input', shadowRoot);

    let revert = ariaHideOutside([target]);

    let announcer = createElement('div', shadowRoot);
    announcer.dataset.liveAnnouncer = 'true';
    let topLayer = createElement('div', shadowRoot);
    topLayer.dataset.reactAriaTopLayer = 'true';
    let added = createElement('button', shadowRoot);

    await waitFor(() => expect(added).toHaveAttribute('aria-hidden', 'true'));
    expect(existingAnnouncer).not.toHaveAttribute('aria-hidden');
    expect(announcer).not.toHaveAttribute('aria-hidden');
    expect(topLayer).not.toHaveAttribute('aria-hidden');

    revert();
  });

  it('should keep content added inside a target visible', async function () {
    let {shadowRoot} = createShadowRoot(container);
    let target = createElement('div', shadowRoot);
    let sibling = createElement('button', shadowRoot);

    let revert = ariaHideOutside([target]);

    let child = createElement('span', target);
    await act(async () => {});

    expect(child).not.toHaveAttribute('aria-hidden');
    expect(sibling).toHaveAttribute('aria-hidden', 'true');

    revert();
  });

  it('should hide a shadow root host attached later inside a newly added element', async function () {
    let {shadowRoot} = createShadowRoot(container);
    let target = createElement('input', shadowRoot);

    let revert = ariaHideOutside([target]);

    let newHost = document.createElement('div');
    newHost.attachShadow({mode: 'open'}).appendChild(document.createElement('button'));
    shadowRoot.appendChild(newHost);

    await waitFor(() => expect(newHost).toHaveAttribute('aria-hidden', 'true'));

    revert();
  });

  it('should restore everything and stop observing shadow roots on cleanup', async function () {
    let {shadowRoot} = createShadowRoot(container);
    let sibling = createElement('button', shadowRoot);
    let target = createElement('input', shadowRoot);

    let revert = ariaHideOutside([target]);
    revert();

    expect(sibling).not.toHaveAttribute('aria-hidden');
    expect(target).not.toHaveAttribute('aria-hidden');

    let added = createElement('button', shadowRoot);
    await act(async () => {});
    expect(added).not.toHaveAttribute('aria-hidden');
  });

  it('should pause outer shadow root observers during a nested call and resume them on restore', async function () {
    let {shadowRoot} = createShadowRoot(container);
    let target = createElement('input', shadowRoot);
    let lightTarget = createElement('button', container);

    let revertOuter = ariaHideOutside([target]);
    let revertInner = ariaHideOutside([lightTarget]);

    let whileNested = createElement('button', shadowRoot);
    await act(async () => {});
    expect(whileNested).not.toHaveAttribute('aria-hidden');

    revertInner();

    let afterNested = createElement('button', shadowRoot);
    await waitFor(() => expect(afterNested).toHaveAttribute('aria-hidden', 'true'));

    revertOuter();
  });

  it('should not hide anything above a root that is inside a shadow root', async function () {
    let outer = createShadowRoot(container);
    let outerSibling = createElement('button', outer.shadowRoot);
    let root = createElement('div', outer.shadowRoot);
    let target = createElement('input', root);
    let innerSibling = createElement('button', root);

    let revert = ariaHideOutside([target], root);

    expect(innerSibling).toHaveAttribute('aria-hidden', 'true');
    expect(outerSibling).not.toHaveAttribute('aria-hidden');
    expect(outer.shadowHost).not.toHaveAttribute('aria-hidden');
    expect(container).not.toHaveAttribute('aria-hidden');

    let added = createElement('button', outer.shadowRoot);
    await act(async () => {});
    expect(added).not.toHaveAttribute('aria-hidden');

    revert();
  });

  it('should not walk or observe shadow roots of targets outside root', async function () {
    let root = createElement('div', container);
    let rootSibling = createElement('button', root);
    let {shadowHost, shadowRoot} = createShadowRoot(container);
    let shadowSibling = createElement('button', shadowRoot);
    let target = createElement('input', shadowHost);

    let revert = ariaHideOutside([target], root);

    expect(root).toHaveAttribute('aria-hidden', 'true');
    expect(rootSibling).not.toHaveAttribute('aria-hidden');
    expect(shadowSibling).not.toHaveAttribute('aria-hidden');
    expect(shadowHost).not.toHaveAttribute('aria-hidden');
    expect(target).not.toHaveAttribute('aria-hidden');

    let added = createElement('button', shadowRoot);
    await act(async () => {});
    expect(added).not.toHaveAttribute('aria-hidden');

    revert();
  });

  it('should keep live announcers in shadow roots that do not enclose a target visible', async function () {
    let target = createElement('input', container);
    let {shadowHost, shadowRoot} = createShadowRoot(container);
    let announcer = createElement('div', shadowRoot);
    announcer.dataset.liveAnnouncer = 'true';
    let sibling = createElement('button', shadowRoot);

    let revert = ariaHideOutside([target]);

    expect(announcer).not.toHaveAttribute('aria-hidden');
    expect(shadowHost).not.toHaveAttribute('aria-hidden');
    expect(sibling).toHaveAttribute('aria-hidden', 'true');
    expect(target).not.toHaveAttribute('aria-hidden');

    let lateAnnouncer = createElement('div', shadowRoot);
    lateAnnouncer.dataset.reactAriaTopLayer = 'true';
    let lateSibling = createElement('button', shadowRoot);
    await waitFor(() => expect(lateSibling).toHaveAttribute('aria-hidden', 'true'));
    expect(lateAnnouncer).not.toHaveAttribute('aria-hidden');

    revert();
  });

  it('should walk nested shadow roots that contain live announcers', function () {
    let target = createElement('input', container);
    let outer = createShadowRoot(container);
    let outerSibling = createElement('button', outer.shadowRoot);
    let middle = createElement('div', outer.shadowRoot);
    let inner = createShadowRoot(middle);
    let announcer = createElement('div', inner.shadowRoot);
    announcer.dataset.liveAnnouncer = 'true';
    let innerSibling = createElement('button', inner.shadowRoot);

    let revert = ariaHideOutside([target]);

    expect(outerSibling).toHaveAttribute('aria-hidden', 'true');
    expect(outer.shadowHost).not.toHaveAttribute('aria-hidden');
    expect(middle).not.toHaveAttribute('aria-hidden');
    expect(inner.shadowHost).not.toHaveAttribute('aria-hidden');
    expect(innerSibling).toHaveAttribute('aria-hidden', 'true');
    expect(announcer).not.toHaveAttribute('aria-hidden');

    revert();
  });

  it('should not hide shadow siblings of a host inside a target, including live announcers', function () {
    let dialog = createElement('div', container);
    let outside = createElement('button', container);
    let inside = createElement('button', dialog);
    let host = createElement('div', dialog);
    let shadowRoot = host.attachShadow({mode: 'open'});
    let announcer = createElement('div', shadowRoot);
    announcer.dataset.liveAnnouncer = 'true';
    let btn = createElement('button', shadowRoot);

    let revert = ariaHideOutside([dialog]);

    expect(outside).toHaveAttribute('aria-hidden', 'true');
    expect(inside).not.toHaveAttribute('aria-hidden');
    expect(host).not.toHaveAttribute('aria-hidden');
    expect(announcer).not.toHaveAttribute('aria-hidden');
    expect(btn).not.toHaveAttribute('aria-hidden');

    revert();
  });

  it('should not hide shadow siblings of a target when the target is inside a shadow root within a target', function () {
    let dialog = createElement('div', container);
    let outside = createElement('button', container);
    let {shadowRoot} = createShadowRoot(dialog);
    let sibling = createElement('button', shadowRoot);
    let inner = createElement('input', shadowRoot);

    let revert = ariaHideOutside([dialog, inner]);

    expect(outside).toHaveAttribute('aria-hidden', 'true');
    expect(sibling).not.toHaveAttribute('aria-hidden');
    expect(inner).not.toHaveAttribute('aria-hidden');

    revert();
  });
});

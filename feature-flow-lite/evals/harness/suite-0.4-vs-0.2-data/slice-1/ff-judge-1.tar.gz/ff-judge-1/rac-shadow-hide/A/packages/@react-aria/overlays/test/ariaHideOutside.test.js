/*
 * Copyright 2020 Adobe. All rights reserved.
 * This file is licensed to you under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License. You may obtain a copy
 * of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software distributed under
 * the License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR REPRESENTATIONS
 * OF ANY KIND, either express or implied. See the License for the specific language
 * governing permissions and limitations under the License.
 */

import {act, createShadowRoot, render, waitFor} from '@react-spectrum/test-utils-internal';
import {ariaHideOutside} from '../src';
import {enableShadowDOM} from '@react-stately/flags';
import React, {useRef, useState} from 'react';

describe('ariaHideOutside', function () {
  it('should hide everything except the provided element [button]', function () {
    let {getByRole, getAllByRole} = render(
      <>
        <input type="checkbox" />
        <button>Button</button>
        <input type="checkbox" />
      </>
    );

    let checkboxes = getAllByRole('checkbox');
    let button = getByRole('button');

    let revert = ariaHideOutside([button]);

    expect(checkboxes[0]).toHaveAttribute('aria-hidden', 'true');
    expect(checkboxes[1]).toHaveAttribute('aria-hidden', 'true');
    expect(button).not.toHaveAttribute('aria-hidden');

    expect(() => getAllByRole('checkbox')).toThrow();
    expect(() => getByRole('button')).not.toThrow();

    revert();

    expect(checkboxes[0]).not.toHaveAttribute('aria-hidden');
    expect(checkboxes[1]).not.toHaveAttribute('aria-hidden');
    expect(button).not.toHaveAttribute('aria-hidden');

    expect(() => getAllByRole('checkbox')).not.toThrow();
    expect(() => getByRole('button')).not.toThrow();
  });

  it('should hide everything except multiple elements', function () {
    let {getByRole, getAllByRole, queryByRole, queryAllByRole} = render(
      <>
        <input type="checkbox" />
        <button>Button</button>
        <input type="checkbox" />
      </>
    );

    let checkboxes = getAllByRole('checkbox');
    let button = getByRole('button');

    let revert = ariaHideOutside(checkboxes);

    expect(checkboxes[0]).not.toHaveAttribute('aria-hidden', 'true');
    expect(checkboxes[1]).not.toHaveAttribute('aria-hidden', 'true');
    expect(button).toHaveAttribute('aria-hidden');

    expect(queryAllByRole('checkbox')).not.toBeNull();
    expect(queryByRole('button')).toBeNull();

    revert();

    expect(checkboxes[0]).not.toHaveAttribute('aria-hidden');
    expect(checkboxes[1]).not.toHaveAttribute('aria-hidden');
    expect(button).not.toHaveAttribute('aria-hidden');

    expect(() => getAllByRole('checkbox')).not.toThrow();
    expect(() => getByRole('button')).not.toThrow();
  });

  it('should not traverse into an already hidden container', function () {
    let {getByRole, getAllByRole} = render(
      <>
        <div>
          <input type="checkbox" />
        </div>
        <button>Button</button>
        <input type="checkbox" />
      </>
    );

    let checkboxes = getAllByRole('checkbox');
    let button = getByRole('button');

    let revert = ariaHideOutside([button]);

    expect(checkboxes[0].parentElement).toHaveAttribute('aria-hidden', 'true');
    expect(checkboxes[1]).toHaveAttribute('aria-hidden', 'true');
    expect(button).not.toHaveAttribute('aria-hidden');

    expect(() => getAllByRole('checkbox')).toThrow();
    expect(() => getByRole('button')).not.toThrow();

    revert();

    expect(checkboxes[0].parentElement).not.toHaveAttribute('aria-hidden');
    expect(checkboxes[1]).not.toHaveAttribute('aria-hidden');
    expect(button).not.toHaveAttribute('aria-hidden');

    expect(() => getAllByRole('checkbox')).not.toThrow();
    expect(() => getByRole('button')).not.toThrow();
  });

  it('should not overwrite an existing aria-hidden prop', function () {
    let {getByRole, getAllByRole} = render(
      <>
        <input type="checkbox" aria-hidden="true" />
        <button>Button</button>
        <input type="checkbox" />
      </>
    );

    let checkboxes = getAllByRole('checkbox');
    let button = getByRole('button');

    let revert = ariaHideOutside([button]);

    expect(checkboxes).toHaveLength(1);
    expect(checkboxes[0]).toHaveAttribute('aria-hidden', 'true');
    expect(button).not.toHaveAttribute('aria-hidden');

    expect(() => getAllByRole('checkbox')).toThrow();
    expect(() => getByRole('button')).not.toThrow();

    revert();

    checkboxes = getAllByRole('checkbox');
    expect(checkboxes).toHaveLength(1);
    expect(checkboxes[0]).not.toHaveAttribute('aria-hidden');
    expect(button).not.toHaveAttribute('aria-hidden');

    expect(() => getAllByRole('checkbox')).not.toThrow();
    expect(() => getByRole('button')).not.toThrow();
  });

  it('should handle when a new element is added outside while active', async function () {
    let Test = props => (
      <>
        {props.show && <input type="checkbox" />}
        <button>Button</button>
        {props.show && <input type="checkbox" />}
      </>
    );

    let {getByRole, getAllByRole, rerender} = render(<Test />);

    let button = getByRole('button');
    expect(() => getAllByRole('checkbox')).toThrow();

    let revert = ariaHideOutside([button]);

    rerender(<Test show />);

    // MutationObserver is async
    await waitFor(() => expect(() => getAllByRole('checkbox')).toThrow());
    expect(() => getByRole('button')).not.toThrow();

    revert();

    expect(getAllByRole('checkbox')).toHaveLength(2);
  });

  it('should handle when a new element is added to an already hidden container', async function () {
    let Test = props => (
      <>
        <div data-testid="test">
          {props.show && <input type="checkbox" />}
        </div>
        <button>Button</button>
        {props.show && <input type="checkbox" />}
      </>
    );

    let {getByRole, getAllByRole, getByTestId, rerender} = render(<Test />);

    let button = getByRole('button');
    let test = getByTestId('test');
    expect(() => getAllByRole('checkbox')).toThrow();

    let revert = ariaHideOutside([button]);

    expect(test).toHaveAttribute('aria-hidden');

    rerender(<Test show />);

    // MutationObserver is async
    await waitFor(() => expect(() => getAllByRole('checkbox')).toThrow());
    expect(() => getByRole('button')).not.toThrow();

    let checkboxes = getAllByRole('checkbox', {hidden: true});
    expect(test).toHaveAttribute('aria-hidden');
    expect(checkboxes[0]).not.toHaveAttribute('aria-hidden');
    expect(checkboxes[1]).toHaveAttribute('aria-hidden', 'true');

    revert();

    expect(getAllByRole('checkbox')).toHaveLength(2);
  });

  it('should handle when a new element is added along with a top layer element', async function () {
    let Test = props => (
      <>
        <button>Button</button>
        {props.show && <div>
          <div role="alert" data-react-aria-top-layer="true">Top layer</div>
          <input type="checkbox" />
        </div>}
      </>
    );

    let {getByRole, queryByRole, getAllByRole, rerender} = render(<Test />);

    let button = getByRole('button');
    expect(queryByRole('checkbox')).toBeNull();

    let revert = ariaHideOutside([button]);

    rerender(<Test show />);

    // MutationObserver is async
    await waitFor(() => queryByRole('checkbox') == null);
    expect(queryByRole('button')).not.toBeNull();
    expect(getByRole('alert')).toHaveTextContent('Top layer');

    revert();

    expect(getAllByRole('checkbox')).toHaveLength(1);
  });

  it('should handle when a new element is added inside a target element', async function () {
    let Test = props => (
      <>
        <input type="checkbox" />
        <div data-testid="test">
          <button>Button</button>
          {props.show && <input type="radio" />}
        </div>
        <input type="checkbox" />
      </>
    );

    let {queryByRole, getByRole, getAllByRole, getByTestId, rerender} = render(<Test />);

    let test = getByTestId('test');
    let revert = ariaHideOutside([test]);

    expect(() => getAllByRole('checkbox')).toThrow();
    expect(queryByRole('radio')).toBeNull();
    expect(queryByRole('button')).not.toBeNull();
    expect(() => getByTestId('test')).not.toThrow();

    rerender(<Test show />);

    // Wait for mutation observer tick
    await Promise.resolve();
    expect(() => getAllByRole('checkbox')).toThrow();
    expect(() => getByRole('radio')).not.toThrow();
    expect(() => getByRole('button')).not.toThrow();
    expect(() => getByTestId('test')).not.toThrow();

    revert();

    expect(() => getAllByRole('checkbox')).not.toThrow();
    expect(() => getByRole('radio')).not.toThrow();
    expect(() => getByRole('button')).not.toThrow();
    expect(() => getByTestId('test')).not.toThrow();
  });

  it('should handle when a new element is added and then reparented', async function () {

    let Test = () => {
      const ref = useRef(null);
      const mutate = () => {
        let parent = document.createElement('ul');
        let child = document.createElement('li');
        ref.current.append(parent);
        parent.appendChild(child);
        parent.remove(); // this results in a mutation record for a disconnected ul with a connected li (through the new ul parent) in `addedNodes`
        let newParent = document.createElement('ul');
        newParent.appendChild(child);
        ref.current.append(newParent);
      };

      return (
        <>
          <div data-testid="test" ref={ref}>
            <button onClick={mutate}>Mutate</button>
          </div>
        </>
      );
    };

    let {queryByRole, getAllByRole, getByTestId} = render(<Test />);

    ariaHideOutside([getByTestId('test')]);

    queryByRole('button').click();
    await Promise.resolve(); // Wait for mutation observer tick

    expect(getAllByRole('listitem')).toHaveLength(1);
  });

  it('should handle when a new element is added and then reparented to a hidden container', async function () {

    let Test = () => {
      const ref = useRef(null);
      const mutate = () => {
        let parent = document.createElement('ul');
        let child = document.createElement('li');
        ref.current.append(parent);
        parent.appendChild(child);
        parent.remove(); // this results in a mutation record for a disconnected ul with a connected li (through the new ul parent) in `addedNodes`
        let newParent = document.createElement('ul');
        newParent.appendChild(child);
        ref.current.append(newParent);
      };

      return (
        <>
          <div data-testid="test">
            <button onClick={mutate}>Mutate</button>
          </div>
          <div data-testid="sibling" ref={ref} />
        </>
      );
    };

    let {queryByRole, queryAllByRole, getByTestId} = render(<Test />);

    ariaHideOutside([getByTestId('test')]);

    queryByRole('button').click();
    await Promise.resolve(); // Wait for mutation observer tick

    expect(queryAllByRole('listitem')).toHaveLength(0);
  });


  it('work when called multiple times', function () {
    let {getByRole, getAllByRole} = render(
      <>
        <input type="checkbox" />
        <input type="radio" />
        <button>Button</button>
        <input type="radio" />
        <input type="checkbox" />
      </>
    );

    let radios = getAllByRole('radio');
    let button = getByRole('button');

    let revert1 = ariaHideOutside([button, ...radios]);

    expect(() => getAllByRole('checkbox')).toThrow();
    expect(() => getAllByRole('radio')).not.toThrow();
    expect(() => getByRole('button')).not.toThrow();

    let revert2 = ariaHideOutside([button]);

    expect(() => getAllByRole('checkbox')).toThrow();
    expect(() => getAllByRole('radio')).toThrow();
    expect(() => getByRole('button')).not.toThrow();

    revert2();

    expect(() => getAllByRole('checkbox')).toThrow();
    expect(() => getAllByRole('radio')).not.toThrow();
    expect(() => getByRole('button')).not.toThrow();

    revert1();

    expect(() => getAllByRole('checkbox')).not.toThrow();
    expect(() => getAllByRole('radio')).not.toThrow();
    expect(() => getByRole('button')).not.toThrow();
  });

  it('work when called multiple times and restored out of order', function () {
    let {getByRole, getAllByRole} = render(
      <>
        <input type="checkbox" />
        <input type="radio" />
        <button>Button</button>
        <input type="radio" />
        <input type="checkbox" />
      </>
    );

    let radios = getAllByRole('radio');
    let button = getByRole('button');

    let revert1 = ariaHideOutside([button, ...radios]);

    expect(() => getAllByRole('checkbox')).toThrow();
    expect(() => getAllByRole('radio')).not.toThrow();
    expect(() => getByRole('button')).not.toThrow();

    let revert2 = ariaHideOutside([button]);

    expect(() => getAllByRole('checkbox')).toThrow();
    expect(() => getAllByRole('radio')).toThrow();
    expect(() => getByRole('button')).not.toThrow();

    revert1();

    expect(() => getAllByRole('checkbox')).toThrow();
    expect(() => getAllByRole('radio')).toThrow();
    expect(() => getByRole('button')).not.toThrow();

    revert2();

    expect(() => getAllByRole('checkbox')).not.toThrow();
    expect(() => getAllByRole('radio')).not.toThrow();
    expect(() => getByRole('button')).not.toThrow();
  });

  it('should hide everything except the provided element [row]', function () {
    let {getAllByRole, getByTestId} = render(
      <div role="grid">
        <div role="row">
          <div role="gridcell">
            <span data-testid="test-span">
              Cell 1
            </span></div>
        </div>
        <div role="row">
          <div role="gridcell">Cell 2</div>
        </div>
      </div>
    );

    let cells = getAllByRole('gridcell');
    let rows = getAllByRole('row');
    let span = getByTestId('test-span');

    let revert = ariaHideOutside([rows[1]]);

    // Applies aria-hidden to the row and cell despite recursive nature of aria-hidden
    // for https://bugs.webkit.org/show_bug.cgi?id=222623
    expect(rows[0]).toHaveAttribute('aria-hidden', 'true');
    expect(cells[0]).toHaveAttribute('aria-hidden', 'true');
    expect(span).not.toHaveAttribute('aria-hidden');
    expect(rows[1]).not.toHaveAttribute('aria-hidden', 'true');
    expect(cells[1]).not.toHaveAttribute('aria-hidden', 'true');

    revert();

    expect(rows[0]).not.toHaveAttribute('aria-hidden', 'true');
    expect(cells[0]).not.toHaveAttribute('aria-hidden', 'true');
    expect(rows[1]).not.toHaveAttribute('aria-hidden', 'true');
    expect(cells[1]).not.toHaveAttribute('aria-hidden', 'true');
    expect(span).not.toHaveAttribute('aria-hidden');
  });

  it('should unhide after item reorder', async function () {
    function Item(props) {
      return (
        <div role="presentation">
          <div data-testid={props.testid} role="row">
            <div role="gridcell" />
          </div>
        </div>
      );
    }

    function Test() {
      let [count, setCount] = useState(0);
      let items = ['row1', 'row2', 'row3', 'row4', 'row5'];
      if (count === 1) {
        items = ['row2', 'row1', 'row3', 'row4', 'row5'];
      } else if (count === 2) {
        items = ['row2', 'row3', 'row1', 'row4', 'row5'];
      }

      return (
        <>
          <button onClick={() => setCount((old) => old + 1)}>press</button>
          {items.map((item) => <Item testid={item} key={item} />)}
        </>

      );
    }

    let {getByRole, getByTestId} = render(
      <Test />
    );

    let button = getByRole('button');
    let row = getByTestId('row1');
    let revert = ariaHideOutside([button]);

    act(() => button.click());
    await Promise.resolve();
    act(() => button.click());
    await Promise.resolve();
    revert();
    expect(row.parentElement).not.toHaveAttribute('aria-hidden', 'true');
  });
});

describe('ariaHideOutside with Shadow DOM', function () {
  let hosts = [];
  let createHost = (attachTo) => {
    let host = createShadowRoot(attachTo);
    hosts.push(host);
    return host;
  };
  let createCheckbox = () => {
    let checkbox = document.createElement('input');
    checkbox.type = 'checkbox';
    return checkbox;
  };

  beforeAll(() => {
    enableShadowDOM();
  });

  afterEach(() => {
    for (let host of hosts.reverse()) {
      host.cleanup();
    }
    hosts = [];
  });

  it('hides light DOM siblings of the host and siblings of the target in the shadow root', function () {
    let lightCheckbox = createCheckbox();
    document.body.appendChild(lightCheckbox);
    let {shadowHost, shadowRoot} = createHost();
    shadowRoot.innerHTML = '<input type="checkbox" id="before"><button>Target</button><input type="checkbox" id="after">';
    let button = shadowRoot.querySelector('button');

    let revert = ariaHideOutside([button]);

    expect(lightCheckbox).toHaveAttribute('aria-hidden', 'true');
    expect(shadowHost).not.toHaveAttribute('aria-hidden');
    expect(shadowRoot.querySelector('#before')).toHaveAttribute('aria-hidden', 'true');
    expect(shadowRoot.querySelector('#after')).toHaveAttribute('aria-hidden', 'true');
    expect(button).not.toHaveAttribute('aria-hidden');

    revert();

    expect(lightCheckbox).not.toHaveAttribute('aria-hidden');
    expect(shadowRoot.querySelector('#before')).not.toHaveAttribute('aria-hidden');
    expect(shadowRoot.querySelector('#after')).not.toHaveAttribute('aria-hidden');
    lightCheckbox.remove();
  });

  it('hides siblings at every level when the target is two shadow roots deep', function () {
    let outer = createHost();
    outer.shadowRoot.innerHTML = '<div id="wrap"></div><input type="checkbox" id="outerSibling">';
    let inner = createHost(outer.shadowRoot.querySelector('#wrap'));
    inner.shadowRoot.innerHTML = '<input type="checkbox" id="innerSibling"><button>Target</button>';
    let button = inner.shadowRoot.querySelector('button');

    let revert = ariaHideOutside([button]);

    expect(outer.shadowRoot.querySelector('#outerSibling')).toHaveAttribute('aria-hidden', 'true');
    expect(inner.shadowRoot.querySelector('#innerSibling')).toHaveAttribute('aria-hidden', 'true');
    expect(outer.shadowRoot.querySelector('#wrap')).not.toHaveAttribute('aria-hidden');
    expect(inner.shadowHost).not.toHaveAttribute('aria-hidden');
    expect(button).not.toHaveAttribute('aria-hidden');

    revert();

    expect(outer.shadowRoot.querySelector('#outerSibling')).not.toHaveAttribute('aria-hidden');
    expect(inner.shadowRoot.querySelector('#innerSibling')).not.toHaveAttribute('aria-hidden');
  });

  it('hides light DOM children of a host next to its shadow content, and sibling hosts without targets', function () {
    let host = createHost();
    host.shadowRoot.innerHTML = '<button>Target</button>';
    let slotted = createCheckbox();
    host.shadowHost.appendChild(slotted);
    let other = createHost();
    other.shadowRoot.innerHTML = '<input type="checkbox">';
    let button = host.shadowRoot.querySelector('button');

    let revert = ariaHideOutside([button]);

    expect(slotted).toHaveAttribute('aria-hidden', 'true');
    expect(host.shadowHost).not.toHaveAttribute('aria-hidden');
    expect(other.shadowHost).toHaveAttribute('aria-hidden', 'true');
    expect(button).not.toHaveAttribute('aria-hidden');

    revert();

    expect(slotted).not.toHaveAttribute('aria-hidden');
    expect(other.shadowHost).not.toHaveAttribute('aria-hidden');
  });

  it('hides content added to the target shadow root after the call', async function () {
    let {shadowRoot} = createHost();
    shadowRoot.innerHTML = '<div id="deep"></div><button>Target</button>';
    let button = shadowRoot.querySelector('button');
    let deep = shadowRoot.querySelector('#deep');

    let revert = ariaHideOutside([button]);

    let direct = createCheckbox();
    shadowRoot.appendChild(direct);
    let nested = createCheckbox();
    deep.appendChild(nested);

    await waitFor(() => expect(direct).toHaveAttribute('aria-hidden', 'true'));
    expect(nested.closest('[aria-hidden="true"]')).toBe(deep);
    revert();
  });

  it('keeps live announcers and top layer elements visible when added to a shadow root', async function () {
    let {shadowRoot} = createHost();
    shadowRoot.innerHTML = '<div data-live-announcer="true" id="existing"></div><button>Target</button>';
    let button = shadowRoot.querySelector('button');

    let revert = ariaHideOutside([button]);

    let announcer = document.createElement('div');
    announcer.dataset.liveAnnouncer = 'true';
    let topLayer = document.createElement('div');
    topLayer.dataset.reactAriaTopLayer = 'true';
    shadowRoot.appendChild(announcer);
    shadowRoot.appendChild(topLayer);

    let checkbox = createCheckbox();
    shadowRoot.appendChild(checkbox);

    await waitFor(() => expect(checkbox).toHaveAttribute('aria-hidden', 'true'));
    expect(shadowRoot.querySelector('#existing')).not.toHaveAttribute('aria-hidden');
    expect(announcer).not.toHaveAttribute('aria-hidden');
    expect(topLayer).not.toHaveAttribute('aria-hidden');
    revert();
  });

  it('does not hide content added inside a target in the shadow root', async function () {
    let {shadowRoot} = createHost();
    shadowRoot.innerHTML = '<div id="target"><button>Target</button></div><input type="checkbox" id="sibling">';
    let target = shadowRoot.querySelector('#target');

    let revert = ariaHideOutside([target]);

    let inside = document.createElement('input');
    inside.type = 'radio';
    target.appendChild(inside);
    let sibling = shadowRoot.querySelector('#sibling');

    await waitFor(() => expect(sibling).toHaveAttribute('aria-hidden', 'true'));
    expect(inside).not.toHaveAttribute('aria-hidden');
    expect(inside.closest('[aria-hidden="true"]')).toBeNull();
    revert();
  });

  it('keeps targets in different shadow roots and the light DOM visible and watches both roots', async function () {
    let lightButton = document.createElement('button');
    document.body.appendChild(lightButton);
    let input = createHost();
    input.shadowRoot.innerHTML = '<input type="checkbox" id="input"><input type="checkbox" id="inputSibling">';
    let popover = createHost();
    popover.shadowRoot.innerHTML = '<div id="popover"></div>';
    let outside = createHost();
    outside.shadowRoot.innerHTML = '<input type="checkbox" id="outside">';
    let shadowInput = input.shadowRoot.querySelector('#input');
    let popoverEl = popover.shadowRoot.querySelector('#popover');

    let revert = ariaHideOutside([lightButton, shadowInput, popoverEl]);

    expect(lightButton).not.toHaveAttribute('aria-hidden');
    expect(shadowInput).not.toHaveAttribute('aria-hidden');
    expect(popoverEl).not.toHaveAttribute('aria-hidden');
    expect(input.shadowHost).not.toHaveAttribute('aria-hidden');
    expect(popover.shadowHost).not.toHaveAttribute('aria-hidden');
    expect(input.shadowRoot.querySelector('#inputSibling')).toHaveAttribute('aria-hidden', 'true');
    expect(outside.shadowHost).toHaveAttribute('aria-hidden', 'true');

    let added = createCheckbox();
    input.shadowRoot.appendChild(added);
    let addedPopover = createCheckbox();
    popover.shadowRoot.appendChild(addedPopover);

    await waitFor(() => expect(added).toHaveAttribute('aria-hidden', 'true'));
    expect(addedPopover).toHaveAttribute('aria-hidden', 'true');
    expect(popoverEl).not.toHaveAttribute('aria-hidden');
    revert();
    lightButton.remove();
  });

  it('restores hidden shadow content and stops observing shadow roots after revert', async function () {
    let {shadowRoot} = createHost();
    shadowRoot.innerHTML = '<input type="checkbox" id="pre" aria-hidden="true"><input type="checkbox" id="sibling"><button>Target</button>';
    let button = shadowRoot.querySelector('button');
    let pre = shadowRoot.querySelector('#pre');
    let sibling = shadowRoot.querySelector('#sibling');

    let revert = ariaHideOutside([button]);
    expect(sibling).toHaveAttribute('aria-hidden', 'true');
    revert();

    expect(pre).toHaveAttribute('aria-hidden', 'true');
    expect(sibling).not.toHaveAttribute('aria-hidden');

    let added = createCheckbox();
    shadowRoot.appendChild(added);
    await Promise.resolve();
    expect(added).not.toHaveAttribute('aria-hidden');
  });

  it('re-observes outer shadow roots when a nested call is reverted', async function () {
    let {shadowRoot} = createHost();
    shadowRoot.innerHTML = '<input type="checkbox" id="sibling"><button>Target</button>';
    let button = shadowRoot.querySelector('button');
    let lightButton = document.createElement('button');
    document.body.appendChild(lightButton);

    let outerRevert = ariaHideOutside([button]);
    let innerRevert = ariaHideOutside([lightButton]);
    innerRevert();

    let added = createCheckbox();
    shadowRoot.appendChild(added);

    await waitFor(() => expect(added).toHaveAttribute('aria-hidden', 'true'));
    expect(button).not.toHaveAttribute('aria-hidden');
    outerRevert();
    lightButton.remove();
  });

  it('ref counts overlapping calls on shadow content', function () {
    let {shadowRoot} = createHost();
    shadowRoot.innerHTML = '<input type="checkbox" id="sibling"><button id="a">A</button><button id="b">B</button>';
    let a = shadowRoot.querySelector('#a');
    let b = shadowRoot.querySelector('#b');
    let sibling = shadowRoot.querySelector('#sibling');

    let revert1 = ariaHideOutside([a, b]);
    let revert2 = ariaHideOutside([a]);
    expect(sibling).toHaveAttribute('aria-hidden', 'true');
    expect(b).toHaveAttribute('aria-hidden', 'true');

    // b is still hidden by revert2, which only targets a.
    revert1();
    expect(sibling).toHaveAttribute('aria-hidden', 'true');
    expect(b).toHaveAttribute('aria-hidden', 'true');
    expect(a).not.toHaveAttribute('aria-hidden');

    revert2();
    expect(sibling).not.toHaveAttribute('aria-hidden');
    expect(b).not.toHaveAttribute('aria-hidden');
  });

  it('does not throw for a light DOM target slotted into a shadow root, and hides the wrapper content but not the slot', function () {
    let lightSibling = createCheckbox();
    document.body.appendChild(lightSibling);
    let {shadowHost, shadowRoot} = createHost();
    shadowRoot.innerHTML = '<div class="wrap"><span>deco</span><slot></slot></div>';
    let target = createCheckbox();
    let second = createCheckbox();
    shadowHost.appendChild(target);
    shadowHost.appendChild(second);
    let wrap = shadowRoot.querySelector('.wrap');
    let slot = shadowRoot.querySelector('slot');
    let deco = shadowRoot.querySelector('span');

    let revert = ariaHideOutside([target]);

    expect(target).not.toHaveAttribute('aria-hidden');
    expect(shadowHost).not.toHaveAttribute('aria-hidden');
    expect(wrap).not.toHaveAttribute('aria-hidden');
    expect(slot).not.toHaveAttribute('aria-hidden');
    expect(deco).toHaveAttribute('aria-hidden', 'true');
    expect(second).toHaveAttribute('aria-hidden', 'true');
    expect(lightSibling).toHaveAttribute('aria-hidden', 'true');

    revert();

    expect(target).not.toHaveAttribute('aria-hidden');
    expect(wrap).not.toHaveAttribute('aria-hidden');
    expect(deco).not.toHaveAttribute('aria-hidden');
    expect(second).not.toHaveAttribute('aria-hidden');
    expect(lightSibling).not.toHaveAttribute('aria-hidden');
    lightSibling.remove();
  });

  it('hides content appended to the shadow root of a host with a slotted target', async function () {
    let {shadowHost, shadowRoot} = createHost();
    shadowRoot.innerHTML = '<div class="wrap"><span>deco</span><slot></slot></div>';
    let target = createCheckbox();
    shadowHost.appendChild(target);

    let revert = ariaHideOutside([target]);

    let added = createCheckbox();
    shadowRoot.appendChild(added);

    await waitFor(() => expect(added).toHaveAttribute('aria-hidden', 'true'));
    expect(target).not.toHaveAttribute('aria-hidden');
    expect(shadowRoot.querySelector('.wrap')).not.toHaveAttribute('aria-hidden');
    revert();
  });

  it('keeps a target slotted through nested shadow roots visible and hides siblings at each level', function () {
    let outer = createHost();
    outer.shadowRoot.innerHTML = '<div id="wrap"><slot></slot></div><input type="checkbox" id="outerSibling">';
    let inner = createHost(outer.shadowHost);
    inner.shadowRoot.innerHTML = '<input type="checkbox" id="innerSibling"><button>Target</button>';
    let button = inner.shadowRoot.querySelector('button');

    let revert = ariaHideOutside([button]);

    expect(outer.shadowRoot.querySelector('#outerSibling')).toHaveAttribute('aria-hidden', 'true');
    expect(inner.shadowRoot.querySelector('#innerSibling')).toHaveAttribute('aria-hidden', 'true');
    expect(outer.shadowRoot.querySelector('#wrap')).not.toHaveAttribute('aria-hidden');
    expect(outer.shadowRoot.querySelector('slot')).not.toHaveAttribute('aria-hidden');
    expect(outer.shadowHost).not.toHaveAttribute('aria-hidden');
    expect(inner.shadowHost).not.toHaveAttribute('aria-hidden');
    expect(button).not.toHaveAttribute('aria-hidden');

    revert();

    expect(outer.shadowRoot.querySelector('#outerSibling')).not.toHaveAttribute('aria-hidden');
    expect(inner.shadowRoot.querySelector('#innerSibling')).not.toHaveAttribute('aria-hidden');
  });

  describe('closed shadow roots', function () {
    // createShadowRoot only attaches open roots, so closed roots are attached here and cleaned up with the others.
    let createClosedHost = (attachTo = document.body) => {
      let shadowHost = document.createElement('div');
      attachTo.appendChild(shadowHost);
      let shadowRoot = shadowHost.attachShadow({mode: 'closed'});
      hosts.push({shadowHost, shadowRoot, cleanup: () => shadowHost.remove()});
      return {shadowHost, shadowRoot};
    };

    it('hides siblings of a target in a closed shadow root, including content added later, and restores on revert', async function () {
      let {shadowHost, shadowRoot} = createClosedHost();
      shadowRoot.innerHTML = '<input class="t"><p class="x">x</p>';
      let target = shadowRoot.querySelector('.t');
      let sibling = shadowRoot.querySelector('.x');

      let revert = ariaHideOutside([target]);

      expect(sibling).toHaveAttribute('aria-hidden', 'true');
      expect(shadowHost).not.toHaveAttribute('aria-hidden');
      expect(target).not.toHaveAttribute('aria-hidden');

      let added = createCheckbox();
      shadowRoot.appendChild(added);
      await waitFor(() => expect(added).toHaveAttribute('aria-hidden', 'true'));

      revert();
      expect(sibling).not.toHaveAttribute('aria-hidden');
      expect(added).not.toHaveAttribute('aria-hidden');

      let afterRevert = createCheckbox();
      shadowRoot.appendChild(afterRevert);
      await Promise.resolve();
      expect(afterRevert).not.toHaveAttribute('aria-hidden');
    });

    it('hides siblings at every level when a closed shadow root is nested inside an open one', async function () {
      let outer = createHost();
      outer.shadowRoot.innerHTML = '<div id="wrap"></div><input type="checkbox" id="outerSibling">';
      let {shadowRoot} = createClosedHost(outer.shadowRoot.querySelector('#wrap'));
      shadowRoot.innerHTML = '<input type="checkbox" id="innerSibling"><button>Target</button>';
      let button = shadowRoot.querySelector('button');

      let revert = ariaHideOutside([button]);

      expect(outer.shadowRoot.querySelector('#outerSibling')).toHaveAttribute('aria-hidden', 'true');
      expect(shadowRoot.querySelector('#innerSibling')).toHaveAttribute('aria-hidden', 'true');
      expect(outer.shadowRoot.querySelector('#wrap')).not.toHaveAttribute('aria-hidden');
      expect(outer.shadowHost).not.toHaveAttribute('aria-hidden');
      expect(button).not.toHaveAttribute('aria-hidden');

      let added = createCheckbox();
      outer.shadowRoot.appendChild(added);
      await waitFor(() => expect(added).toHaveAttribute('aria-hidden', 'true'));

      revert();
      expect(outer.shadowRoot.querySelector('#outerSibling')).not.toHaveAttribute('aria-hidden');
      expect(shadowRoot.querySelector('#innerSibling')).not.toHaveAttribute('aria-hidden');
    });
  });
});

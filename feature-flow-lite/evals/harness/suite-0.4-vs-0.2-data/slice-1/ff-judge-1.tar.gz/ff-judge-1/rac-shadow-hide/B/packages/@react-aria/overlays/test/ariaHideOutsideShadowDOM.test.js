/*
 * Copyright 2026 Adobe. All rights reserved.
 * This file is licensed to you under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License. You may obtain a copy
 * of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software distributed under
 * the License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR REPRESENTATIONS
 * OF ANY KIND, either express or implied. See the License for the specific language
 * governing permissions and limitations under the License.
 */

// Kept in its own file because enableShadowDOM() cannot be reset, and the flag is module state.
import {ariaHideOutside, keepVisible} from '../src/ariaHideOutside';
import {enableShadowDOM} from '@react-stately/flags';

enableShadowDOM();

// Appends a host to parent with a shadow root containing html.
function attachShadow(parent, html) {
  let host = document.createElement('div');
  parent.appendChild(host);
  let shadowRoot = host.attachShadow({mode: 'open'});
  shadowRoot.innerHTML = html;
  return {host, shadowRoot};
}

// Lets queued MutationObserver callbacks run.
let flush = () => new Promise(resolve => setTimeout(resolve, 0));

describe('ariaHideOutside with shadow DOM enabled', function () {
  let revert;

  afterEach(() => {
    if (revert) {
      revert();
      revert = null;
    }
    document.body.innerHTML = '';
  });

  it('hides light DOM and shadow root siblings but not the host path', function () {
    let light = document.createElement('button');
    document.body.appendChild(light);
    let {host, shadowRoot} = attachShadow(document.body, '<input id="sibling"><button id="target"></button>');
    let sibling = shadowRoot.querySelector('#sibling');
    let target = shadowRoot.querySelector('#target');

    revert = ariaHideOutside([target]);

    expect(light).toHaveAttribute('aria-hidden', 'true');
    expect(sibling).toHaveAttribute('aria-hidden', 'true');
    expect(target).not.toHaveAttribute('aria-hidden');
    expect(host).not.toHaveAttribute('aria-hidden');
    expect(document.body).not.toHaveAttribute('aria-hidden');

    revert();
    revert = null;

    expect(light).not.toHaveAttribute('aria-hidden');
    expect(sibling).not.toHaveAttribute('aria-hidden');
  });

  it('hides siblings in every enclosing shadow root of a nested target', function () {
    let outer = attachShadow(document.body, '<button id="outerSibling"></button><div id="innerHost"></div>');
    let innerHost = outer.shadowRoot.querySelector('#innerHost');
    let inner = attachShadow(innerHost, '<button id="innerSibling"></button><button id="target"></button>');
    let outerSibling = outer.shadowRoot.querySelector('#outerSibling');
    let innerSibling = inner.shadowRoot.querySelector('#innerSibling');
    let target = inner.shadowRoot.querySelector('#target');

    revert = ariaHideOutside([target]);

    expect(outerSibling).toHaveAttribute('aria-hidden', 'true');
    expect(innerSibling).toHaveAttribute('aria-hidden', 'true');
    expect(innerHost).not.toHaveAttribute('aria-hidden');
    expect(outer.host).not.toHaveAttribute('aria-hidden');
    expect(target).not.toHaveAttribute('aria-hidden');
  });

  it('hides a sibling shadow host without descending into its shadow root', function () {
    let {shadowRoot} = attachShadow(document.body, '<div id="otherHost"></div><button id="target"></button>');
    let otherHost = shadowRoot.querySelector('#otherHost');
    let unrelated = document.createElement('span');
    otherHost.attachShadow({mode: 'open'}).appendChild(unrelated);
    let target = shadowRoot.querySelector('#target');

    revert = ariaHideOutside([target]);

    expect(otherHost).toHaveAttribute('aria-hidden', 'true');
    expect(unrelated).not.toHaveAttribute('aria-hidden');
  });

  it('keeps a target that is itself a shadow host and its shadow content visible', function () {
    let light = document.createElement('button');
    document.body.appendChild(light);
    let {host, shadowRoot} = attachShadow(document.body, '<button id="content"></button>');
    let content = shadowRoot.querySelector('#content');

    revert = ariaHideOutside([host]);

    expect(light).toHaveAttribute('aria-hidden', 'true');
    expect(host).not.toHaveAttribute('aria-hidden');
    expect(content).not.toHaveAttribute('aria-hidden');
  });

  it('keeps targets in different shadow roots visible and hides everything else', function () {
    let a = attachShadow(document.body, '<input id="input"><button id="aOther"></button>');
    let b = attachShadow(document.body, '<div id="popover"></div><button id="bOther"></button>');
    let input = a.shadowRoot.querySelector('#input');
    let popover = b.shadowRoot.querySelector('#popover');

    revert = ariaHideOutside([input, popover]);

    expect(input).not.toHaveAttribute('aria-hidden');
    expect(popover).not.toHaveAttribute('aria-hidden');
    expect(a.host).not.toHaveAttribute('aria-hidden');
    expect(b.host).not.toHaveAttribute('aria-hidden');
    expect(a.shadowRoot.querySelector('#aOther')).toHaveAttribute('aria-hidden', 'true');
    expect(b.shadowRoot.querySelector('#bOther')).toHaveAttribute('aria-hidden', 'true');
  });

  it('hides elements added later to a target shadow root or an enclosing one', async function () {
    let outer = attachShadow(document.body, '<div id="innerHost"></div>');
    let inner = attachShadow(outer.shadowRoot.querySelector('#innerHost'), '<button id="target"></button>');
    let target = inner.shadowRoot.querySelector('#target');
    revert = ariaHideOutside([target]);

    let outerAdded = document.createElement('button');
    let innerAdded = document.createElement('button');
    outer.shadowRoot.appendChild(outerAdded);
    inner.shadowRoot.appendChild(innerAdded);
    await flush();

    expect(outerAdded).toHaveAttribute('aria-hidden', 'true');
    expect(innerAdded).toHaveAttribute('aria-hidden', 'true');
    expect(target).not.toHaveAttribute('aria-hidden');
  });

  it('keeps additions inside a target visible', async function () {
    let {shadowRoot} = attachShadow(document.body, '<div id="container"><button id="target"></button></div>');
    let target = shadowRoot.querySelector('#target');
    revert = ariaHideOutside([target]);

    let added = document.createElement('span');
    target.appendChild(added);
    await flush();

    expect(added).not.toHaveAttribute('aria-hidden');
  });

  it('keeps live announcers and top layer elements visible when added later', async function () {
    let {shadowRoot} = attachShadow(document.body, '<button id="target"></button>');
    let target = shadowRoot.querySelector('#target');
    revert = ariaHideOutside([target]);

    let announcer = document.createElement('div');
    announcer.dataset.liveAnnouncer = 'true';
    let topLayer = document.createElement('div');
    topLayer.dataset.reactAriaTopLayer = 'true';
    shadowRoot.appendChild(announcer);
    shadowRoot.appendChild(topLayer);
    await flush();

    expect(announcer).not.toHaveAttribute('aria-hidden');
    expect(topLayer).not.toHaveAttribute('aria-hidden');
  });

  it('keeps an existing live announcer sibling inside the target shadow root visible', function () {
    let {shadowRoot} = attachShadow(document.body, '<div data-live-announcer="true"></div><button id="target"></button>');
    let announcer = shadowRoot.querySelector('[data-live-announcer]');
    let target = shadowRoot.querySelector('#target');

    revert = ariaHideOutside([target]);

    expect(announcer).not.toHaveAttribute('aria-hidden');
  });

  it('does not double count elements added inside an already hidden shadow sibling', async function () {
    let {shadowRoot} = attachShadow(document.body, '<div id="sibling"></div><button id="target"></button>');
    let sibling = shadowRoot.querySelector('#sibling');
    let target = shadowRoot.querySelector('#target');
    revert = ariaHideOutside([target]);

    let child = document.createElement('button');
    sibling.appendChild(child);
    await flush();

    expect(sibling).toHaveAttribute('aria-hidden', 'true');
    expect(child).not.toHaveAttribute('aria-hidden');
  });

  it('restores nested calls in order and leaves pre-hidden elements hidden', async function () {
    let {shadowRoot} = attachShadow(document.body, '<input id="sibling"><button id="target"></button>');
    let sibling = shadowRoot.querySelector('#sibling');
    let target = shadowRoot.querySelector('#target');
    sibling.setAttribute('aria-hidden', 'true');

    let revert1 = ariaHideOutside([target]);
    let revert2 = ariaHideOutside([target]);
    revert2();

    // The outer call is still active, so the observer it owns must still watch the target's shadow root.
    let duringOuter = document.createElement('button');
    shadowRoot.appendChild(duringOuter);
    await flush();

    expect(duringOuter).toHaveAttribute('aria-hidden', 'true');

    revert1();

    expect(sibling).toHaveAttribute('aria-hidden', 'true');

    let added = document.createElement('button');
    shadowRoot.appendChild(added);
    await flush();

    expect(added).not.toHaveAttribute('aria-hidden');
  });

  it('keeps keepVisible working for an element in a shadow root', async function () {
    let {shadowRoot} = attachShadow(document.body, '<button id="target"></button>');
    let target = shadowRoot.querySelector('#target');
    revert = ariaHideOutside([target]);

    let added = document.createElement('button');
    shadowRoot.appendChild(added);
    let release = keepVisible(added);
    await flush();

    expect(added).not.toHaveAttribute('aria-hidden');
    release();
  });

  it('does not hide siblings of a target inside the shadow root of another target host', function () {
    let {host, shadowRoot} = attachShadow(document.body, '<button id="sibling"></button><button id="target"></button>');
    let sibling = shadowRoot.querySelector('#sibling');
    let target = shadowRoot.querySelector('#target');

    revert = ariaHideOutside([host, target]);

    expect(host).not.toHaveAttribute('aria-hidden');
    expect(sibling).not.toHaveAttribute('aria-hidden');
    expect(target).not.toHaveAttribute('aria-hidden');
  });

  it('does not hide content in the shadow root of a host inside a target, but hides light DOM siblings', function () {
    let light = document.createElement('button');
    document.body.appendChild(light);
    let item = document.createElement('div');
    document.body.appendChild(item);
    let {host, shadowRoot} = attachShadow(item, '<button id="sibling"></button><button id="target"></button>');
    let sibling = shadowRoot.querySelector('#sibling');
    let target = shadowRoot.querySelector('#target');

    revert = ariaHideOutside([item, target]);

    expect(light).toHaveAttribute('aria-hidden', 'true');
    expect(item).not.toHaveAttribute('aria-hidden');
    expect(host).not.toHaveAttribute('aria-hidden');
    expect(sibling).not.toHaveAttribute('aria-hidden');
  });

  it('keeps live announcers and top layer elements in a sibling host shadow root visible at call time', function () {
    let {shadowRoot} = attachShadow(document.body, '<button id="target"></button>');
    let target = shadowRoot.querySelector('#target');
    let other = attachShadow(document.body, '<div data-live-announcer="true"></div><button id="sibling"></button>');
    let announcer = other.shadowRoot.querySelector('[data-live-announcer]');
    let sibling = other.shadowRoot.querySelector('#sibling');

    revert = ariaHideOutside([target]);

    expect(other.host).not.toHaveAttribute('aria-hidden');
    expect(announcer).not.toHaveAttribute('aria-hidden');
    expect(sibling).toHaveAttribute('aria-hidden', 'true');
  });

  it('keeps a top layer element in a nested shadow root visible along its host path', function () {
    let {shadowRoot} = attachShadow(document.body, '<button id="target"></button>');
    let target = shadowRoot.querySelector('#target');
    let outer = attachShadow(document.body, '<div id="innerHost"></div><button id="outerSibling"></button>');
    let inner = attachShadow(outer.shadowRoot.querySelector('#innerHost'), '<div data-react-aria-top-layer="true"></div><button id="innerSibling"></button>');
    let topLayer = inner.shadowRoot.querySelector('[data-react-aria-top-layer]');

    revert = ariaHideOutside([target]);

    expect(outer.host).not.toHaveAttribute('aria-hidden');
    expect(outer.shadowRoot.querySelector('#innerHost')).not.toHaveAttribute('aria-hidden');
    expect(inner.host).not.toHaveAttribute('aria-hidden');
    expect(topLayer).not.toHaveAttribute('aria-hidden');
    expect(outer.shadowRoot.querySelector('#outerSibling')).toHaveAttribute('aria-hidden', 'true');
    expect(inner.shadowRoot.querySelector('#innerSibling')).toHaveAttribute('aria-hidden', 'true');
  });

  it('keeps live announcers in a sibling host shadow root visible when the host is added later', async function () {
    let {shadowRoot} = attachShadow(document.body, '<button id="target"></button>');
    let target = shadowRoot.querySelector('#target');
    revert = ariaHideOutside([target]);

    let other = attachShadow(document.body, '<div data-live-announcer="true"></div><button id="sibling"></button>');
    await flush();

    expect(other.host).not.toHaveAttribute('aria-hidden');
    expect(other.shadowRoot.querySelector('[data-live-announcer]')).not.toHaveAttribute('aria-hidden');
    expect(other.shadowRoot.querySelector('#sibling')).toHaveAttribute('aria-hidden', 'true');
  });

  it('does not hide siblings outside a root option that is inside a shadow root', function () {
    let {shadowRoot} = attachShadow(document.body, '<div id="root"><button id="target"></button></div><button id="outside"></button>');
    let root = shadowRoot.querySelector('#root');
    let target = shadowRoot.querySelector('#target');
    let light = document.createElement('button');
    document.body.appendChild(light);

    revert = ariaHideOutside([target], {root});

    expect(shadowRoot.querySelector('#outside')).not.toHaveAttribute('aria-hidden');
    expect(light).not.toHaveAttribute('aria-hidden');
    expect(root).not.toHaveAttribute('aria-hidden');
    expect(target).not.toHaveAttribute('aria-hidden');
  });

  it('hides shadow root siblings inside a root option that contains the host', function () {
    let container = document.createElement('div');
    document.body.appendChild(container);
    let {host, shadowRoot} = attachShadow(container, '<button id="sibling"></button><button id="target"></button>');
    let sibling = shadowRoot.querySelector('#sibling');
    let target = shadowRoot.querySelector('#target');
    let outside = document.createElement('button');
    document.body.appendChild(outside);

    revert = ariaHideOutside([target], {root: container});

    expect(host).not.toHaveAttribute('aria-hidden');
    expect(sibling).toHaveAttribute('aria-hidden', 'true');
    expect(outside).not.toHaveAttribute('aria-hidden');
  });
});

/*
 * Copyright 2020 Adobe. All rights reserved.
 * This file is licensed to you under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License. You may obtain a copy
 * of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software distributed under
 * the License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR REPRESENTATIONS
 * OF ANY KIND, either express or implied. See the License for the specific language
 * governing permissions and limitations under the License.
 */

import {act, createShadowRoot, render, waitFor} from '@react-spectrum/test-utils-internal';
import {ariaHideOutside} from '../src';
import {enableShadowDOM} from '@react-stately/flags';
import React, {useRef, useState} from 'react';

describe('ariaHideOutside', function () {
  it('should hide everything except the provided element [button]', function () {
    let {getByRole, getAllByRole} = render(
      <>
        <input type="checkbox" />
        <button>Button</button>
        <input type="checkbox" />
      </>
    );

    let checkboxes = getAllByRole('checkbox');
    let button = getByRole('button');

    let revert = ariaHideOutside([button]);

    expect(checkboxes[0]).toHaveAttribute('aria-hidden', 'true');
    expect(checkboxes[1]).toHaveAttribute('aria-hidden', 'true');
    expect(button).not.toHaveAttribute('aria-hidden');

    expect(() => getAllByRole('checkbox')).toThrow();
    expect(() => getByRole('button')).not.toThrow();

    revert();

    expect(checkboxes[0]).not.toHaveAttribute('aria-hidden');
    expect(checkboxes[1]).not.toHaveAttribute('aria-hidden');
    expect(button).not.toHaveAttribute('aria-hidden');

    expect(() => getAllByRole('checkbox')).not.toThrow();
    expect(() => getByRole('button')).not.toThrow();
  });

  it('should hide everything except multiple elements', function () {
    let {getByRole, getAllByRole, queryByRole, queryAllByRole} = render(
      <>
        <input type="checkbox" />
        <button>Button</button>
        <input type="checkbox" />
      </>
    );

    let checkboxes = getAllByRole('checkbox');
    let button = getByRole('button');

    let revert = ariaHideOutside(checkboxes);

    expect(checkboxes[0]).not.toHaveAttribute('aria-hidden', 'true');
    expect(checkboxes[1]).not.toHaveAttribute('aria-hidden', 'true');
    expect(button).toHaveAttribute('aria-hidden');

    expect(queryAllByRole('checkbox')).not.toBeNull();
    expect(queryByRole('button')).toBeNull();

    revert();

    expect(checkboxes[0]).not.toHaveAttribute('aria-hidden');
    expect(checkboxes[1]).not.toHaveAttribute('aria-hidden');
    expect(button).not.toHaveAttribute('aria-hidden');

    expect(() => getAllByRole('checkbox')).not.toThrow();
    expect(() => getByRole('button')).not.toThrow();
  });

  it('should not traverse into an already hidden container', function () {
    let {getByRole, getAllByRole} = render(
      <>
        <div>
          <input type="checkbox" />
        </div>
        <button>Button</button>
        <input type="checkbox" />
      </>
    );

    let checkboxes = getAllByRole('checkbox');
    let button = getByRole('button');

    let revert = ariaHideOutside([button]);

    expect(checkboxes[0].parentElement).toHaveAttribute('aria-hidden', 'true');
    expect(checkboxes[1]).toHaveAttribute('aria-hidden', 'true');
    expect(button).not.toHaveAttribute('aria-hidden');

    expect(() => getAllByRole('checkbox')).toThrow();
    expect(() => getByRole('button')).not.toThrow();

    revert();

    expect(checkboxes[0].parentElement).not.toHaveAttribute('aria-hidden');
    expect(checkboxes[1]).not.toHaveAttribute('aria-hidden');
    expect(button).not.toHaveAttribute('aria-hidden');

    expect(() => getAllByRole('checkbox')).not.toThrow();
    expect(() => getByRole('button')).not.toThrow();
  });

  it('should not overwrite an existing aria-hidden prop', function () {
    let {getByRole, getAllByRole} = render(
      <>
        <input type="checkbox" aria-hidden="true" />
        <button>Button</button>
        <input type="checkbox" />
      </>
    );

    let checkboxes = getAllByRole('checkbox');
    let button = getByRole('button');

    let revert = ariaHideOutside([button]);

    expect(checkboxes).toHaveLength(1);
    expect(checkboxes[0]).toHaveAttribute('aria-hidden', 'true');
    expect(button).not.toHaveAttribute('aria-hidden');

    expect(() => getAllByRole('checkbox')).toThrow();
    expect(() => getByRole('button')).not.toThrow();

    revert();

    checkboxes = getAllByRole('checkbox');
    expect(checkboxes).toHaveLength(1);
    expect(checkboxes[0]).not.toHaveAttribute('aria-hidden');
    expect(button).not.toHaveAttribute('aria-hidden');

    expect(() => getAllByRole('checkbox')).not.toThrow();
    expect(() => getByRole('button')).not.toThrow();
  });

  it('should handle when a new element is added outside while active', async function () {
    let Test = props => (
      <>
        {props.show && <input type="checkbox" />}
        <button>Button</button>
        {props.show && <input type="checkbox" />}
      </>
    );

    let {getByRole, getAllByRole, rerender} = render(<Test />);

    let button = getByRole('button');
    expect(() => getAllByRole('checkbox')).toThrow();

    let revert = ariaHideOutside([button]);

    rerender(<Test show />);

    // MutationObserver is async
    await waitFor(() => expect(() => getAllByRole('checkbox')).toThrow());
    expect(() => getByRole('button')).not.toThrow();

    revert();

    expect(getAllByRole('checkbox')).toHaveLength(2);
  });

  it('should handle when a new element is added to an already hidden container', async function () {
    let Test = props => (
      <>
        <div data-testid="test">
          {props.show && <input type="checkbox" />}
        </div>
        <button>Button</button>
        {props.show && <input type="checkbox" />}
      </>
    );

    let {getByRole, getAllByRole, getByTestId, rerender} = render(<Test />);

    let button = getByRole('button');
    let test = getByTestId('test');
    expect(() => getAllByRole('checkbox')).toThrow();

    let revert = ariaHideOutside([button]);

    expect(test).toHaveAttribute('aria-hidden');

    rerender(<Test show />);

    // MutationObserver is async
    await waitFor(() => expect(() => getAllByRole('checkbox')).toThrow());
    expect(() => getByRole('button')).not.toThrow();

    let checkboxes = getAllByRole('checkbox', {hidden: true});
    expect(test).toHaveAttribute('aria-hidden');
    expect(checkboxes[0]).not.toHaveAttribute('aria-hidden');
    expect(checkboxes[1]).toHaveAttribute('aria-hidden', 'true');

    revert();

    expect(getAllByRole('checkbox')).toHaveLength(2);
  });

  it('should handle when a new element is added along with a top layer element', async function () {
    let Test = props => (
      <>
        <button>Button</button>
        {props.show && <div>
          <div role="alert" data-react-aria-top-layer="true">Top layer</div>
          <input type="checkbox" />
        </div>}
      </>
    );

    let {getByRole, queryByRole, getAllByRole, rerender} = render(<Test />);

    let button = getByRole('button');
    expect(queryByRole('checkbox')).toBeNull();

    let revert = ariaHideOutside([button]);

    rerender(<Test show />);

    // MutationObserver is async
    await waitFor(() => queryByRole('checkbox') == null);
    expect(queryByRole('button')).not.toBeNull();
    expect(getByRole('alert')).toHaveTextContent('Top layer');

    revert();

    expect(getAllByRole('checkbox')).toHaveLength(1);
  });

  it('should handle when a new element is added inside a target element', async function () {
    let Test = props => (
      <>
        <input type="checkbox" />
        <div data-testid="test">
          <button>Button</button>
          {props.show && <input type="radio" />}
        </div>
        <input type="checkbox" />
      </>
    );

    let {queryByRole, getByRole, getAllByRole, getByTestId, rerender} = render(<Test />);

    let test = getByTestId('test');
    let revert = ariaHideOutside([test]);

    expect(() => getAllByRole('checkbox')).toThrow();
    expect(queryByRole('radio')).toBeNull();
    expect(queryByRole('button')).not.toBeNull();
    expect(() => getByTestId('test')).not.toThrow();

    rerender(<Test show />);

    // Wait for mutation observer tick
    await Promise.resolve();
    expect(() => getAllByRole('checkbox')).toThrow();
    expect(() => getByRole('radio')).not.toThrow();
    expect(() => getByRole('button')).not.toThrow();
    expect(() => getByTestId('test')).not.toThrow();

    revert();

    expect(() => getAllByRole('checkbox')).not.toThrow();
    expect(() => getByRole('radio')).not.toThrow();
    expect(() => getByRole('button')).not.toThrow();
    expect(() => getByTestId('test')).not.toThrow();
  });

  it('should handle when a new element is added and then reparented', async function () {

    let Test = () => {
      const ref = useRef(null);
      const mutate = () => {
        let parent = document.createElement('ul');
        let child = document.createElement('li');
        ref.current.append(parent);
        parent.appendChild(child);
        parent.remove(); // this results in a mutation record for a disconnected ul with a connected li (through the new ul parent) in `addedNodes`
        let newParent = document.createElement('ul');
        newParent.appendChild(child);
        ref.current.append(newParent);
      };

      return (
        <>
          <div data-testid="test" ref={ref}>
            <button onClick={mutate}>Mutate</button>
          </div>
        </>
      );
    };

    let {queryByRole, getAllByRole, getByTestId} = render(<Test />);

    ariaHideOutside([getByTestId('test')]);

    queryByRole('button').click();
    await Promise.resolve(); // Wait for mutation observer tick

    expect(getAllByRole('listitem')).toHaveLength(1);
  });

  it('should handle when a new element is added and then reparented to a hidden container', async function () {

    let Test = () => {
      const ref = useRef(null);
      const mutate = () => {
        let parent = document.createElement('ul');
        let child = document.createElement('li');
        ref.current.append(parent);
        parent.appendChild(child);
        parent.remove(); // this results in a mutation record for a disconnected ul with a connected li (through the new ul parent) in `addedNodes`
        let newParent = document.createElement('ul');
        newParent.appendChild(child);
        ref.current.append(newParent);
      };

      return (
        <>
          <div data-testid="test">
            <button onClick={mutate}>Mutate</button>
          </div>
          <div data-testid="sibling" ref={ref} />
        </>
      );
    };

    let {queryByRole, queryAllByRole, getByTestId} = render(<Test />);

    ariaHideOutside([getByTestId('test')]);

    queryByRole('button').click();
    await Promise.resolve(); // Wait for mutation observer tick

    expect(queryAllByRole('listitem')).toHaveLength(0);
  });


  it('work when called multiple times', function () {
    let {getByRole, getAllByRole} = render(
      <>
        <input type="checkbox" />
        <input type="radio" />
        <button>Button</button>
        <input type="radio" />
        <input type="checkbox" />
      </>
    );

    let radios = getAllByRole('radio');
    let button = getByRole('button');

    let revert1 = ariaHideOutside([button, ...radios]);

    expect(() => getAllByRole('checkbox')).toThrow();
    expect(() => getAllByRole('radio')).not.toThrow();
    expect(() => getByRole('button')).not.toThrow();

    let revert2 = ariaHideOutside([button]);

    expect(() => getAllByRole('checkbox')).toThrow();
    expect(() => getAllByRole('radio')).toThrow();
    expect(() => getByRole('button')).not.toThrow();

    revert2();

    expect(() => getAllByRole('checkbox')).toThrow();
    expect(() => getAllByRole('radio')).not.toThrow();
    expect(() => getByRole('button')).not.toThrow();

    revert1();

    expect(() => getAllByRole('checkbox')).not.toThrow();
    expect(() => getAllByRole('radio')).not.toThrow();
    expect(() => getByRole('button')).not.toThrow();
  });

  it('work when called multiple times and restored out of order', function () {
    let {getByRole, getAllByRole} = render(
      <>
        <input type="checkbox" />
        <input type="radio" />
        <button>Button</button>
        <input type="radio" />
        <input type="checkbox" />
      </>
    );

    let radios = getAllByRole('radio');
    let button = getByRole('button');

    let revert1 = ariaHideOutside([button, ...radios]);

    expect(() => getAllByRole('checkbox')).toThrow();
    expect(() => getAllByRole('radio')).not.toThrow();
    expect(() => getByRole('button')).not.toThrow();

    let revert2 = ariaHideOutside([button]);

    expect(() => getAllByRole('checkbox')).toThrow();
    expect(() => getAllByRole('radio')).toThrow();
    expect(() => getByRole('button')).not.toThrow();

    revert1();

    expect(() => getAllByRole('checkbox')).toThrow();
    expect(() => getAllByRole('radio')).toThrow();
    expect(() => getByRole('button')).not.toThrow();

    revert2();

    expect(() => getAllByRole('checkbox')).not.toThrow();
    expect(() => getAllByRole('radio')).not.toThrow();
    expect(() => getByRole('button')).not.toThrow();
  });

  it('should hide everything except the provided element [row]', function () {
    let {getAllByRole, getByTestId} = render(
      <div role="grid">
        <div role="row">
          <div role="gridcell">
            <span data-testid="test-span">
              Cell 1
            </span></div>
        </div>
        <div role="row">
          <div role="gridcell">Cell 2</div>
        </div>
      </div>
    );

    let cells = getAllByRole('gridcell');
    let rows = getAllByRole('row');
    let span = getByTestId('test-span');

    let revert = ariaHideOutside([rows[1]]);

    // Applies aria-hidden to the row and cell despite recursive nature of aria-hidden
    // for https://bugs.webkit.org/show_bug.cgi?id=222623
    expect(rows[0]).toHaveAttribute('aria-hidden', 'true');
    expect(cells[0]).toHaveAttribute('aria-hidden', 'true');
    expect(span).not.toHaveAttribute('aria-hidden');
    expect(rows[1]).not.toHaveAttribute('aria-hidden', 'true');
    expect(cells[1]).not.toHaveAttribute('aria-hidden', 'true');

    revert();

    expect(rows[0]).not.toHaveAttribute('aria-hidden', 'true');
    expect(cells[0]).not.toHaveAttribute('aria-hidden', 'true');
    expect(rows[1]).not.toHaveAttribute('aria-hidden', 'true');
    expect(cells[1]).not.toHaveAttribute('aria-hidden', 'true');
    expect(span).not.toHaveAttribute('aria-hidden');
  });

  it('should unhide after item reorder', async function () {
    function Item(props) {
      return (
        <div role="presentation">
          <div data-testid={props.testid} role="row">
            <div role="gridcell" />
          </div>
        </div>
      );
    }

    function Test() {
      let [count, setCount] = useState(0);
      let items = ['row1', 'row2', 'row3', 'row4', 'row5'];
      if (count === 1) {
        items = ['row2', 'row1', 'row3', 'row4', 'row5'];
      } else if (count === 2) {
        items = ['row2', 'row3', 'row1', 'row4', 'row5'];
      }

      return (
        <>
          <button onClick={() => setCount((old) => old + 1)}>press</button>
          {items.map((item) => <Item testid={item} key={item} />)}
        </>

      );
    }

    let {getByRole, getByTestId} = render(
      <Test />
    );

    let button = getByRole('button');
    let row = getByTestId('row1');
    let revert = ariaHideOutside([button]);

    act(() => button.click());
    await Promise.resolve();
    act(() => button.click());
    await Promise.resolve();
    revert();
    expect(row.parentElement).not.toHaveAttribute('aria-hidden', 'true');
  });

  it('should not hide shadow root siblings of a target when shadow DOM is off', function () {
    let {shadowRoot, cleanup} = createShadowRoot();
    shadowRoot.innerHTML = '<input type="checkbox" id="sibling" /><button id="target">Button</button>';
    let sibling = shadowRoot.querySelector('#sibling');
    let target = shadowRoot.querySelector('#target');

    let revert = ariaHideOutside([target]);

    expect(sibling).not.toHaveAttribute('aria-hidden');

    revert();
    cleanup();
  });
});

// enableShadowDOM() cannot be undone, so this describe must stay last in the file.
describe('ariaHideOutside with Shadow DOM', function () {
  let container;

  beforeAll(() => {
    enableShadowDOM();
  });

  beforeEach(() => {
    container = document.createElement('div');
    document.body.appendChild(container);
  });

  afterEach(() => {
    // Removing the container also removes any shadow hosts created inside it.
    container.remove();
  });

  it('should hide siblings of the target and of each host on the path', function () {
    let outer = createShadowRoot(container);
    container.insertAdjacentHTML('afterbegin', '<input type="checkbox" id="light-before" />');
    container.insertAdjacentHTML('beforeend', '<input type="checkbox" id="light-after" />');
    outer.shadowRoot.innerHTML = '<input type="checkbox" id="outer-before" /><div id="slot"></div><input type="checkbox" id="outer-after" />';
    let inner = createShadowRoot(outer.shadowRoot.querySelector('#slot'));
    inner.shadowRoot.innerHTML = '<input type="checkbox" id="inner-before" /><button id="target">Button</button><input type="checkbox" id="inner-after" />';
    inner.shadowHost.insertAdjacentHTML('beforeend', '<input type="checkbox" id="host-child" />');
    let target = inner.shadowRoot.querySelector('#target');

    let revert = ariaHideOutside([target]);

    for (let element of [
      container.querySelector('#light-before'),
      container.querySelector('#light-after'),
      outer.shadowRoot.querySelector('#outer-before'),
      outer.shadowRoot.querySelector('#outer-after'),
      inner.shadowRoot.querySelector('#inner-before'),
      inner.shadowRoot.querySelector('#inner-after'),
      inner.shadowHost.querySelector('#host-child')
    ]) {
      expect(element).toHaveAttribute('aria-hidden', 'true');
    }
    for (let element of [target, inner.shadowHost, outer.shadowRoot.querySelector('#slot'), outer.shadowHost]) {
      expect(element).not.toHaveAttribute('aria-hidden');
    }

    revert();
  });

  it('should hide siblings at every level of three nested shadow roots', function () {
    let level1 = createShadowRoot(container);
    level1.shadowRoot.innerHTML = '<input type="checkbox" id="l1-sibling" /><div id="l1-slot"></div>';
    let level2 = createShadowRoot(level1.shadowRoot.querySelector('#l1-slot'));
    level2.shadowRoot.innerHTML = '<input type="checkbox" id="l2-sibling" /><div id="l2-slot"></div>';
    let level3 = createShadowRoot(level2.shadowRoot.querySelector('#l2-slot'));
    level3.shadowRoot.innerHTML = '<input type="checkbox" id="l3-sibling" /><button id="target">Button</button>';
    let target = level3.shadowRoot.querySelector('#target');

    let revert = ariaHideOutside([target]);

    expect(level1.shadowRoot.querySelector('#l1-sibling')).toHaveAttribute('aria-hidden', 'true');
    expect(level2.shadowRoot.querySelector('#l2-sibling')).toHaveAttribute('aria-hidden', 'true');
    expect(level3.shadowRoot.querySelector('#l3-sibling')).toHaveAttribute('aria-hidden', 'true');
    expect(target).not.toHaveAttribute('aria-hidden');
    expect(level3.shadowHost).not.toHaveAttribute('aria-hidden');
    expect(level2.shadowHost).not.toHaveAttribute('aria-hidden');
    expect(level1.shadowHost).not.toHaveAttribute('aria-hidden');

    revert();
  });

  it('should hide content added later to the target shadow root but not inside the target', async function () {
    let {shadowRoot} = createShadowRoot(container);
    shadowRoot.innerHTML = '<div id="wrap"><button id="target">Button</button></div>';
    let target = shadowRoot.querySelector('#target');
    let revert = ariaHideOutside([target]);

    let direct = document.createElement('input');
    direct.type = 'checkbox';
    shadowRoot.appendChild(direct);
    let inWrap = document.createElement('input');
    inWrap.type = 'radio';
    shadowRoot.querySelector('#wrap').appendChild(inWrap);
    let inTarget = document.createElement('span');
    target.appendChild(inTarget);

    // MutationObserver is async
    await waitFor(() => expect(direct).toHaveAttribute('aria-hidden', 'true'));
    expect(inWrap).toHaveAttribute('aria-hidden', 'true');
    expect(inTarget).not.toHaveAttribute('aria-hidden');
    expect(target).not.toHaveAttribute('aria-hidden');

    revert();
  });

  it('should hide content added later to an enclosing shadow root', async function () {
    let outer = createShadowRoot(container);
    outer.shadowRoot.innerHTML = '<div id="slot"></div>';
    let inner = createShadowRoot(outer.shadowRoot.querySelector('#slot'));
    inner.shadowRoot.innerHTML = '<button id="target">Button</button>';
    let revert = ariaHideOutside([inner.shadowRoot.querySelector('#target')]);

    let added = document.createElement('input');
    added.type = 'checkbox';
    outer.shadowRoot.appendChild(added);

    // MutationObserver is async
    await waitFor(() => expect(added).toHaveAttribute('aria-hidden', 'true'));
    expect(inner.shadowHost).not.toHaveAttribute('aria-hidden');

    revert();
  });

  it('should keep live announcer and top layer elements in shadow roots visible', async function () {
    let {shadowRoot} = createShadowRoot(container);
    shadowRoot.innerHTML = '<div data-live-announcer="true" id="announcer"></div><div data-react-aria-top-layer="true" id="toast"></div><button id="target">Button</button>';
    let revert = ariaHideOutside([shadowRoot.querySelector('#target')]);

    let laterAnnouncer = document.createElement('div');
    laterAnnouncer.dataset.liveAnnouncer = 'true';
    let laterToast = document.createElement('div');
    laterToast.dataset.reactAriaTopLayer = 'true';
    let checkbox = document.createElement('input');
    checkbox.type = 'checkbox';
    shadowRoot.append(laterAnnouncer, laterToast, checkbox);

    // MutationObserver is async
    await waitFor(() => expect(checkbox).toHaveAttribute('aria-hidden', 'true'));
    expect(shadowRoot.querySelector('#announcer')).not.toHaveAttribute('aria-hidden');
    expect(shadowRoot.querySelector('#toast')).not.toHaveAttribute('aria-hidden');
    expect(laterAnnouncer).not.toHaveAttribute('aria-hidden');
    expect(laterToast).not.toHaveAttribute('aria-hidden');

    revert();
  });

  it('should keep targets in different shadow roots and in the light DOM visible', async function () {
    let a = createShadowRoot(container);
    let b = createShadowRoot(container);
    container.insertAdjacentHTML('beforeend', '<input type="checkbox" id="light" /><div role="dialog" id="light-popover">Popover</div><button id="light-other">Button</button>');
    a.shadowRoot.innerHTML = '<input type="checkbox" id="a-input" /><button id="a-other">Button</button>';
    b.shadowRoot.innerHTML = '<div role="dialog" id="b-popover">Popover</div><button id="b-other">Button</button>';
    let input = a.shadowRoot.querySelector('#a-input');
    let popover = b.shadowRoot.querySelector('#b-popover');
    let lightPopover = container.querySelector('#light-popover');

    let revert = ariaHideOutside([input, popover, lightPopover]);

    expect(a.shadowRoot.querySelector('#a-other')).toHaveAttribute('aria-hidden', 'true');
    expect(b.shadowRoot.querySelector('#b-other')).toHaveAttribute('aria-hidden', 'true');
    expect(container.querySelector('#light')).toHaveAttribute('aria-hidden', 'true');
    expect(container.querySelector('#light-other')).toHaveAttribute('aria-hidden', 'true');
    for (let element of [input, popover, lightPopover, a.shadowHost, b.shadowHost]) {
      expect(element).not.toHaveAttribute('aria-hidden');
    }

    let addedA = document.createElement('input');
    addedA.type = 'checkbox';
    let addedB = document.createElement('input');
    addedB.type = 'checkbox';
    a.shadowRoot.appendChild(addedA);
    b.shadowRoot.appendChild(addedB);

    // MutationObserver is async
    await waitFor(() => expect(addedA).toHaveAttribute('aria-hidden', 'true'));
    expect(addedB).toHaveAttribute('aria-hidden', 'true');

    revert();
  });

  it('should restore hidden elements and stop observing shadow roots on revert', async function () {
    let {shadowRoot} = createShadowRoot(container);
    shadowRoot.innerHTML = '<button id="pre" aria-hidden="true">Pre</button><div id="box"></div><button id="target">Button</button>';
    let target = shadowRoot.querySelector('#target');
    let box = shadowRoot.querySelector('#box');
    let revert = ariaHideOutside([target]);

    // Added inside an already hidden container, so it is not hidden again.
    let inBox = document.createElement('input');
    inBox.type = 'checkbox';
    box.appendChild(inBox);
    await Promise.resolve(); // Wait for mutation observer tick
    expect(box).toHaveAttribute('aria-hidden', 'true');
    expect(inBox).not.toHaveAttribute('aria-hidden');

    revert();

    expect(target).not.toHaveAttribute('aria-hidden');
    expect(box).not.toHaveAttribute('aria-hidden');
    expect(inBox).not.toHaveAttribute('aria-hidden');
    expect(shadowRoot.querySelector('#pre')).toHaveAttribute('aria-hidden', 'true');

    let later = document.createElement('input');
    later.type = 'checkbox';
    shadowRoot.appendChild(later);
    let lightLater = document.createElement('input');
    lightLater.type = 'checkbox';
    container.appendChild(lightLater);
    await Promise.resolve(); // Wait for mutation observer tick
    expect(later).not.toHaveAttribute('aria-hidden');
    expect(lightLater).not.toHaveAttribute('aria-hidden');
  });

  it('should resume the outer observer for shadow roots when nested calls are restored in order', async function () {
    let {shadowRoot} = createShadowRoot(container);
    shadowRoot.innerHTML = '<button id="a">A</button><button id="b">B</button><div id="c"></div>';
    let a = shadowRoot.querySelector('#a');
    let b = shadowRoot.querySelector('#b');
    let c = shadowRoot.querySelector('#c');

    let revertOuter = ariaHideOutside([a]);
    let revertInner = ariaHideOutside([b]);
    revertInner();

    expect(a).not.toHaveAttribute('aria-hidden');
    expect(b).toHaveAttribute('aria-hidden', 'true');
    expect(c).toHaveAttribute('aria-hidden', 'true');

    let added = document.createElement('input');
    added.type = 'checkbox';
    shadowRoot.appendChild(added);

    // MutationObserver is async
    await waitFor(() => expect(added).toHaveAttribute('aria-hidden', 'true'));

    revertOuter();

    expect(a).not.toHaveAttribute('aria-hidden');
    expect(b).not.toHaveAttribute('aria-hidden');
    expect(c).not.toHaveAttribute('aria-hidden');
    expect(added).not.toHaveAttribute('aria-hidden');
  });

  it('should restore nested calls out of order and leave nothing hidden', async function () {
    let {shadowRoot} = createShadowRoot(container);
    shadowRoot.innerHTML = '<button id="a">A</button><button id="b">B</button><div id="c"></div>';
    let a = shadowRoot.querySelector('#a');
    let b = shadowRoot.querySelector('#b');
    let c = shadowRoot.querySelector('#c');

    let revertOuter = ariaHideOutside([a]);
    let revertInner = ariaHideOutside([b]);
    revertOuter();

    expect(a).toHaveAttribute('aria-hidden', 'true');
    expect(b).not.toHaveAttribute('aria-hidden');
    expect(c).toHaveAttribute('aria-hidden', 'true');

    let added = document.createElement('input');
    added.type = 'checkbox';
    shadowRoot.appendChild(added);

    // MutationObserver is async
    await waitFor(() => expect(added).toHaveAttribute('aria-hidden', 'true'));

    revertInner();

    expect(a).not.toHaveAttribute('aria-hidden');
    expect(b).not.toHaveAttribute('aria-hidden');
    expect(c).not.toHaveAttribute('aria-hidden');
    expect(added).not.toHaveAttribute('aria-hidden');
  });

  it('should not walk or observe shadow roots whose host is outside root', async function () {
    let scope = document.createElement('div');
    container.appendChild(scope);
    let inside = createShadowRoot(scope);
    inside.shadowRoot.innerHTML = '<input type="checkbox" id="inside-sibling" /><button id="target">Button</button>';
    let outside = createShadowRoot(container);
    outside.shadowRoot.innerHTML = '<input type="checkbox" id="outside-sibling" />';

    let revert = ariaHideOutside([inside.shadowRoot.querySelector('#target')], scope);

    expect(inside.shadowRoot.querySelector('#inside-sibling')).toHaveAttribute('aria-hidden', 'true');
    expect(outside.shadowRoot.querySelector('#outside-sibling')).not.toHaveAttribute('aria-hidden');

    let added = document.createElement('input');
    added.type = 'checkbox';
    outside.shadowRoot.appendChild(added);
    await Promise.resolve(); // Wait for mutation observer tick
    expect(added).not.toHaveAttribute('aria-hidden');

    revert();
  });
});

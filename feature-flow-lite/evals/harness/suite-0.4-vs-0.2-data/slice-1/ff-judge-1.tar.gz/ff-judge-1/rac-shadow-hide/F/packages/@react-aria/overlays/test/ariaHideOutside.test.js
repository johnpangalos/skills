/*
 * Copyright 2020 Adobe. All rights reserved.
 * This file is licensed to you under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License. You may obtain a copy
 * of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software distributed under
 * the License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR REPRESENTATIONS
 * OF ANY KIND, either express or implied. See the License for the specific language
 * governing permissions and limitations under the License.
 */

import {act, render, waitFor} from '@react-spectrum/test-utils-internal';
import {ariaHideOutside} from '../src';
import React, {useRef, useState} from 'react';
import {shadowDOM} from '@react-stately/flags';

jest.mock('@react-stately/flags', () => {
  let actual = jest.requireActual('@react-stately/flags');
  return {...actual, shadowDOM: jest.fn(actual.shadowDOM)};
});

describe('ariaHideOutside', function () {
  it('should hide everything except the provided element [button]', function () {
    let {getByRole, getAllByRole} = render(
      <>
        <input type="checkbox" />
        <button>Button</button>
        <input type="checkbox" />
      </>
    );

    let checkboxes = getAllByRole('checkbox');
    let button = getByRole('button');

    let revert = ariaHideOutside([button]);

    expect(checkboxes[0]).toHaveAttribute('aria-hidden', 'true');
    expect(checkboxes[1]).toHaveAttribute('aria-hidden', 'true');
    expect(button).not.toHaveAttribute('aria-hidden');

    expect(() => getAllByRole('checkbox')).toThrow();
    expect(() => getByRole('button')).not.toThrow();

    revert();

    expect(checkboxes[0]).not.toHaveAttribute('aria-hidden');
    expect(checkboxes[1]).not.toHaveAttribute('aria-hidden');
    expect(button).not.toHaveAttribute('aria-hidden');

    expect(() => getAllByRole('checkbox')).not.toThrow();
    expect(() => getByRole('button')).not.toThrow();
  });

  it('should hide everything except multiple elements', function () {
    let {getByRole, getAllByRole, queryByRole, queryAllByRole} = render(
      <>
        <input type="checkbox" />
        <button>Button</button>
        <input type="checkbox" />
      </>
    );

    let checkboxes = getAllByRole('checkbox');
    let button = getByRole('button');

    let revert = ariaHideOutside(checkboxes);

    expect(checkboxes[0]).not.toHaveAttribute('aria-hidden', 'true');
    expect(checkboxes[1]).not.toHaveAttribute('aria-hidden', 'true');
    expect(button).toHaveAttribute('aria-hidden');

    expect(queryAllByRole('checkbox')).not.toBeNull();
    expect(queryByRole('button')).toBeNull();

    revert();

    expect(checkboxes[0]).not.toHaveAttribute('aria-hidden');
    expect(checkboxes[1]).not.toHaveAttribute('aria-hidden');
    expect(button).not.toHaveAttribute('aria-hidden');

    expect(() => getAllByRole('checkbox')).not.toThrow();
    expect(() => getByRole('button')).not.toThrow();
  });

  it('should not traverse into an already hidden container', function () {
    let {getByRole, getAllByRole} = render(
      <>
        <div>
          <input type="checkbox" />
        </div>
        <button>Button</button>
        <input type="checkbox" />
      </>
    );

    let checkboxes = getAllByRole('checkbox');
    let button = getByRole('button');

    let revert = ariaHideOutside([button]);

    expect(checkboxes[0].parentElement).toHaveAttribute('aria-hidden', 'true');
    expect(checkboxes[1]).toHaveAttribute('aria-hidden', 'true');
    expect(button).not.toHaveAttribute('aria-hidden');

    expect(() => getAllByRole('checkbox')).toThrow();
    expect(() => getByRole('button')).not.toThrow();

    revert();

    expect(checkboxes[0].parentElement).not.toHaveAttribute('aria-hidden');
    expect(checkboxes[1]).not.toHaveAttribute('aria-hidden');
    expect(button).not.toHaveAttribute('aria-hidden');

    expect(() => getAllByRole('checkbox')).not.toThrow();
    expect(() => getByRole('button')).not.toThrow();
  });

  it('should not overwrite an existing aria-hidden prop', function () {
    let {getByRole, getAllByRole} = render(
      <>
        <input type="checkbox" aria-hidden="true" />
        <button>Button</button>
        <input type="checkbox" />
      </>
    );

    let checkboxes = getAllByRole('checkbox');
    let button = getByRole('button');

    let revert = ariaHideOutside([button]);

    expect(checkboxes).toHaveLength(1);
    expect(checkboxes[0]).toHaveAttribute('aria-hidden', 'true');
    expect(button).not.toHaveAttribute('aria-hidden');

    expect(() => getAllByRole('checkbox')).toThrow();
    expect(() => getByRole('button')).not.toThrow();

    revert();

    checkboxes = getAllByRole('checkbox');
    expect(checkboxes).toHaveLength(1);
    expect(checkboxes[0]).not.toHaveAttribute('aria-hidden');
    expect(button).not.toHaveAttribute('aria-hidden');

    expect(() => getAllByRole('checkbox')).not.toThrow();
    expect(() => getByRole('button')).not.toThrow();
  });

  it('should handle when a new element is added outside while active', async function () {
    let Test = props => (
      <>
        {props.show && <input type="checkbox" />}
        <button>Button</button>
        {props.show && <input type="checkbox" />}
      </>
    );

    let {getByRole, getAllByRole, rerender} = render(<Test />);

    let button = getByRole('button');
    expect(() => getAllByRole('checkbox')).toThrow();

    let revert = ariaHideOutside([button]);

    rerender(<Test show />);

    // MutationObserver is async
    await waitFor(() => expect(() => getAllByRole('checkbox')).toThrow());
    expect(() => getByRole('button')).not.toThrow();

    revert();

    expect(getAllByRole('checkbox')).toHaveLength(2);
  });

  it('should handle when a new element is added to an already hidden container', async function () {
    let Test = props => (
      <>
        <div data-testid="test">
          {props.show && <input type="checkbox" />}
        </div>
        <button>Button</button>
        {props.show && <input type="checkbox" />}
      </>
    );

    let {getByRole, getAllByRole, getByTestId, rerender} = render(<Test />);

    let button = getByRole('button');
    let test = getByTestId('test');
    expect(() => getAllByRole('checkbox')).toThrow();

    let revert = ariaHideOutside([button]);

    expect(test).toHaveAttribute('aria-hidden');

    rerender(<Test show />);

    // MutationObserver is async
    await waitFor(() => expect(() => getAllByRole('checkbox')).toThrow());
    expect(() => getByRole('button')).not.toThrow();

    let checkboxes = getAllByRole('checkbox', {hidden: true});
    expect(test).toHaveAttribute('aria-hidden');
    expect(checkboxes[0]).not.toHaveAttribute('aria-hidden');
    expect(checkboxes[1]).toHaveAttribute('aria-hidden', 'true');

    revert();

    expect(getAllByRole('checkbox')).toHaveLength(2);
  });

  it('should handle when a new element is added along with a top layer element', async function () {
    let Test = props => (
      <>
        <button>Button</button>
        {props.show && <div>
          <div role="alert" data-react-aria-top-layer="true">Top layer</div>
          <input type="checkbox" />
        </div>}
      </>
    );

    let {getByRole, queryByRole, getAllByRole, rerender} = render(<Test />);

    let button = getByRole('button');
    expect(queryByRole('checkbox')).toBeNull();

    let revert = ariaHideOutside([button]);

    rerender(<Test show />);

    // MutationObserver is async
    await waitFor(() => queryByRole('checkbox') == null);
    expect(queryByRole('button')).not.toBeNull();
    expect(getByRole('alert')).toHaveTextContent('Top layer');

    revert();

    expect(getAllByRole('checkbox')).toHaveLength(1);
  });

  it('should handle when a new element is added inside a target element', async function () {
    let Test = props => (
      <>
        <input type="checkbox" />
        <div data-testid="test">
          <button>Button</button>
          {props.show && <input type="radio" />}
        </div>
        <input type="checkbox" />
      </>
    );

    let {queryByRole, getByRole, getAllByRole, getByTestId, rerender} = render(<Test />);

    let test = getByTestId('test');
    let revert = ariaHideOutside([test]);

    expect(() => getAllByRole('checkbox')).toThrow();
    expect(queryByRole('radio')).toBeNull();
    expect(queryByRole('button')).not.toBeNull();
    expect(() => getByTestId('test')).not.toThrow();

    rerender(<Test show />);

    // Wait for mutation observer tick
    await Promise.resolve();
    expect(() => getAllByRole('checkbox')).toThrow();
    expect(() => getByRole('radio')).not.toThrow();
    expect(() => getByRole('button')).not.toThrow();
    expect(() => getByTestId('test')).not.toThrow();

    revert();

    expect(() => getAllByRole('checkbox')).not.toThrow();
    expect(() => getByRole('radio')).not.toThrow();
    expect(() => getByRole('button')).not.toThrow();
    expect(() => getByTestId('test')).not.toThrow();
  });

  it('should handle when a new element is added and then reparented', async function () {

    let Test = () => {
      const ref = useRef(null);
      const mutate = () => {
        let parent = document.createElement('ul');
        let child = document.createElement('li');
        ref.current.append(parent);
        parent.appendChild(child);
        parent.remove(); // this results in a mutation record for a disconnected ul with a connected li (through the new ul parent) in `addedNodes`
        let newParent = document.createElement('ul');
        newParent.appendChild(child);
        ref.current.append(newParent);
      };

      return (
        <>
          <div data-testid="test" ref={ref}>
            <button onClick={mutate}>Mutate</button>
          </div>
        </>
      );
    };

    let {queryByRole, getAllByRole, getByTestId} = render(<Test />);

    ariaHideOutside([getByTestId('test')]);

    queryByRole('button').click();
    await Promise.resolve(); // Wait for mutation observer tick

    expect(getAllByRole('listitem')).toHaveLength(1);
  });

  it('should handle when a new element is added and then reparented to a hidden container', async function () {

    let Test = () => {
      const ref = useRef(null);
      const mutate = () => {
        let parent = document.createElement('ul');
        let child = document.createElement('li');
        ref.current.append(parent);
        parent.appendChild(child);
        parent.remove(); // this results in a mutation record for a disconnected ul with a connected li (through the new ul parent) in `addedNodes`
        let newParent = document.createElement('ul');
        newParent.appendChild(child);
        ref.current.append(newParent);
      };

      return (
        <>
          <div data-testid="test">
            <button onClick={mutate}>Mutate</button>
          </div>
          <div data-testid="sibling" ref={ref} />
        </>
      );
    };

    let {queryByRole, queryAllByRole, getByTestId} = render(<Test />);

    ariaHideOutside([getByTestId('test')]);

    queryByRole('button').click();
    await Promise.resolve(); // Wait for mutation observer tick

    expect(queryAllByRole('listitem')).toHaveLength(0);
  });


  it('work when called multiple times', function () {
    let {getByRole, getAllByRole} = render(
      <>
        <input type="checkbox" />
        <input type="radio" />
        <button>Button</button>
        <input type="radio" />
        <input type="checkbox" />
      </>
    );

    let radios = getAllByRole('radio');
    let button = getByRole('button');

    let revert1 = ariaHideOutside([button, ...radios]);

    expect(() => getAllByRole('checkbox')).toThrow();
    expect(() => getAllByRole('radio')).not.toThrow();
    expect(() => getByRole('button')).not.toThrow();

    let revert2 = ariaHideOutside([button]);

    expect(() => getAllByRole('checkbox')).toThrow();
    expect(() => getAllByRole('radio')).toThrow();
    expect(() => getByRole('button')).not.toThrow();

    revert2();

    expect(() => getAllByRole('checkbox')).toThrow();
    expect(() => getAllByRole('radio')).not.toThrow();
    expect(() => getByRole('button')).not.toThrow();

    revert1();

    expect(() => getAllByRole('checkbox')).not.toThrow();
    expect(() => getAllByRole('radio')).not.toThrow();
    expect(() => getByRole('button')).not.toThrow();
  });

  it('work when called multiple times and restored out of order', function () {
    let {getByRole, getAllByRole} = render(
      <>
        <input type="checkbox" />
        <input type="radio" />
        <button>Button</button>
        <input type="radio" />
        <input type="checkbox" />
      </>
    );

    let radios = getAllByRole('radio');
    let button = getByRole('button');

    let revert1 = ariaHideOutside([button, ...radios]);

    expect(() => getAllByRole('checkbox')).toThrow();
    expect(() => getAllByRole('radio')).not.toThrow();
    expect(() => getByRole('button')).not.toThrow();

    let revert2 = ariaHideOutside([button]);

    expect(() => getAllByRole('checkbox')).toThrow();
    expect(() => getAllByRole('radio')).toThrow();
    expect(() => getByRole('button')).not.toThrow();

    revert1();

    expect(() => getAllByRole('checkbox')).toThrow();
    expect(() => getAllByRole('radio')).toThrow();
    expect(() => getByRole('button')).not.toThrow();

    revert2();

    expect(() => getAllByRole('checkbox')).not.toThrow();
    expect(() => getAllByRole('radio')).not.toThrow();
    expect(() => getByRole('button')).not.toThrow();
  });

  it('should hide everything except the provided element [row]', function () {
    let {getAllByRole, getByTestId} = render(
      <div role="grid">
        <div role="row">
          <div role="gridcell">
            <span data-testid="test-span">
              Cell 1
            </span></div>
        </div>
        <div role="row">
          <div role="gridcell">Cell 2</div>
        </div>
      </div>
    );

    let cells = getAllByRole('gridcell');
    let rows = getAllByRole('row');
    let span = getByTestId('test-span');

    let revert = ariaHideOutside([rows[1]]);

    // Applies aria-hidden to the row and cell despite recursive nature of aria-hidden
    // for https://bugs.webkit.org/show_bug.cgi?id=222623
    expect(rows[0]).toHaveAttribute('aria-hidden', 'true');
    expect(cells[0]).toHaveAttribute('aria-hidden', 'true');
    expect(span).not.toHaveAttribute('aria-hidden');
    expect(rows[1]).not.toHaveAttribute('aria-hidden', 'true');
    expect(cells[1]).not.toHaveAttribute('aria-hidden', 'true');

    revert();

    expect(rows[0]).not.toHaveAttribute('aria-hidden', 'true');
    expect(cells[0]).not.toHaveAttribute('aria-hidden', 'true');
    expect(rows[1]).not.toHaveAttribute('aria-hidden', 'true');
    expect(cells[1]).not.toHaveAttribute('aria-hidden', 'true');
    expect(span).not.toHaveAttribute('aria-hidden');
  });

  it('should unhide after item reorder', async function () {
    function Item(props) {
      return (
        <div role="presentation">
          <div data-testid={props.testid} role="row">
            <div role="gridcell" />
          </div>
        </div>
      );
    }

    function Test() {
      let [count, setCount] = useState(0);
      let items = ['row1', 'row2', 'row3', 'row4', 'row5'];
      if (count === 1) {
        items = ['row2', 'row1', 'row3', 'row4', 'row5'];
      } else if (count === 2) {
        items = ['row2', 'row3', 'row1', 'row4', 'row5'];
      }

      return (
        <>
          <button onClick={() => setCount((old) => old + 1)}>press</button>
          {items.map((item) => <Item testid={item} key={item} />)}
        </>

      );
    }

    let {getByRole, getByTestId} = render(
      <Test />
    );

    let button = getByRole('button');
    let row = getByTestId('row1');
    let revert = ariaHideOutside([button]);

    act(() => button.click());
    await Promise.resolve();
    act(() => button.click());
    await Promise.resolve();
    revert();
    expect(row.parentElement).not.toHaveAttribute('aria-hidden', 'true');
  });
});

describe('ariaHideOutside with shadow DOM', function () {
  let container;

  let createHost = (parent) => {
    let host = document.createElement('div');
    parent.appendChild(host);
    return {host, shadowRoot: host.attachShadow({mode: 'open'})};
  };

  let createElement = (parent, tagName, attributes = {}) => {
    let element = document.createElement(tagName);
    for (let [name, value] of Object.entries(attributes)) {
      element.setAttribute(name, value);
    }
    parent.appendChild(element);
    return element;
  };

  beforeEach(function () {
    shadowDOM.mockReturnValue(true);
    container = document.createElement('div');
    document.body.appendChild(container);
  });

  afterEach(function () {
    shadowDOM.mockReturnValue(false);
    container.remove();
  });

  it('should hide siblings in the target shadow root and keep the host visible', function () {
    let lightSibling = createElement(container, 'button');
    let {host, shadowRoot} = createHost(container);
    let input = createElement(shadowRoot, 'input');
    let shadowSibling = createElement(shadowRoot, 'button');

    let revert = ariaHideOutside([input]);

    expect(lightSibling).toHaveAttribute('aria-hidden', 'true');
    expect(host).not.toHaveAttribute('aria-hidden');
    expect(shadowSibling).toHaveAttribute('aria-hidden', 'true');
    expect(input).not.toHaveAttribute('aria-hidden');

    revert();

    expect(lightSibling).not.toHaveAttribute('aria-hidden');
    expect(shadowSibling).not.toHaveAttribute('aria-hidden');
  });

  it('should hide siblings at every level of nested shadow roots', function () {
    let {host: outerHost, shadowRoot: outerRoot} = createHost(container);
    let outerSibling = createElement(outerRoot, 'button');
    let {host: innerHost, shadowRoot: innerRoot} = createHost(outerRoot);
    let innerSibling = createElement(innerRoot, 'button');
    let {host: deepHost, shadowRoot: deepRoot} = createHost(innerRoot);
    let input = createElement(deepRoot, 'input');
    let deepSibling = createElement(deepRoot, 'button');
    let lightSibling = createElement(container, 'button');

    let revert = ariaHideOutside([input]);

    expect(lightSibling).toHaveAttribute('aria-hidden', 'true');
    expect(outerSibling).toHaveAttribute('aria-hidden', 'true');
    expect(innerSibling).toHaveAttribute('aria-hidden', 'true');
    expect(deepSibling).toHaveAttribute('aria-hidden', 'true');
    expect(outerHost).not.toHaveAttribute('aria-hidden');
    expect(innerHost).not.toHaveAttribute('aria-hidden');
    expect(deepHost).not.toHaveAttribute('aria-hidden');
    expect(input).not.toHaveAttribute('aria-hidden');

    revert();

    expect(outerSibling).not.toHaveAttribute('aria-hidden');
    expect(innerSibling).not.toHaveAttribute('aria-hidden');
    expect(deepSibling).not.toHaveAttribute('aria-hidden');
    expect(lightSibling).not.toHaveAttribute('aria-hidden');
  });

  it('should keep a target that is the direct child of a shadow root visible', function () {
    let {shadowRoot} = createHost(container);
    let input = createElement(shadowRoot, 'input');
    let sibling = createElement(shadowRoot, 'button');

    let revert = ariaHideOutside([input]);

    expect(input).not.toHaveAttribute('aria-hidden');
    expect(sibling).toHaveAttribute('aria-hidden', 'true');

    revert();

    expect(sibling).not.toHaveAttribute('aria-hidden');
  });

  it('should hide a sibling shadow host as a whole', function () {
    let {shadowRoot} = createHost(container);
    let input = createElement(shadowRoot, 'input');
    let {host: siblingHost, shadowRoot: siblingRoot} = createHost(shadowRoot);
    let siblingButton = createElement(siblingRoot, 'button');

    let revert = ariaHideOutside([input]);

    expect(siblingHost).toHaveAttribute('aria-hidden', 'true');
    expect(input).not.toHaveAttribute('aria-hidden');

    revert();

    expect(siblingHost).not.toHaveAttribute('aria-hidden');
    expect(siblingButton).not.toHaveAttribute('aria-hidden');
  });

  it('should leave an element that is already aria-hidden alone', function () {
    let {shadowRoot} = createHost(container);
    let input = createElement(shadowRoot, 'input');
    let alreadyHidden = createElement(shadowRoot, 'button', {'aria-hidden': 'true'});

    let revert = ariaHideOutside([input]);

    expect(alreadyHidden).toHaveAttribute('aria-hidden', 'true');

    revert();

    expect(alreadyHidden).toHaveAttribute('aria-hidden', 'true');
  });

  it('should keep live announcers and top layer elements in shadow roots visible', async function () {
    let {shadowRoot} = createHost(container);
    let input = createElement(shadowRoot, 'input');
    let announcer = createElement(shadowRoot, 'div', {'data-live-announcer': 'true'});
    let alert = createElement(shadowRoot, 'div', {role: 'alert'});

    let revert = ariaHideOutside([input]);

    expect(announcer).not.toHaveAttribute('aria-hidden');
    expect(alert).toHaveAttribute('aria-hidden', 'true');

    let addedAnnouncer = createElement(shadowRoot, 'div', {'data-live-announcer': 'true'});
    let addedTopLayer = createElement(shadowRoot, 'div', {'data-react-aria-top-layer': 'true'});
    let addedAlert = createElement(shadowRoot, 'div', {role: 'alert'});
    await Promise.resolve();

    expect(addedAnnouncer).not.toHaveAttribute('aria-hidden');
    expect(addedTopLayer).not.toHaveAttribute('aria-hidden');
    expect(addedAlert).toHaveAttribute('aria-hidden', 'true');

    revert();
  });

  it('should hide elements added later to the target shadow root and enclosing shadow roots', async function () {
    let {shadowRoot: outerRoot} = createHost(container);
    let {shadowRoot: innerRoot} = createHost(outerRoot);
    let input = createElement(innerRoot, 'input');

    let revert = ariaHideOutside([input]);

    let innerAdded = createElement(innerRoot, 'button');
    let outerAdded = createElement(outerRoot, 'button');
    await Promise.resolve();

    expect(innerAdded).toHaveAttribute('aria-hidden', 'true');
    expect(outerAdded).toHaveAttribute('aria-hidden', 'true');
    expect(input).not.toHaveAttribute('aria-hidden');

    revert();

    expect(innerAdded).not.toHaveAttribute('aria-hidden');
    expect(outerAdded).not.toHaveAttribute('aria-hidden');
  });

  it('should not hide elements added inside a target in a shadow root', async function () {
    let {shadowRoot} = createHost(container);
    let target = createElement(shadowRoot, 'div');

    let revert = ariaHideOutside([target]);

    let child = createElement(target, 'input');
    await Promise.resolve();

    expect(target).not.toHaveAttribute('aria-hidden');
    expect(child).not.toHaveAttribute('aria-hidden');

    revert();
  });

  it('should hide a shadow host added later as a whole', async function () {
    let {shadowRoot} = createHost(container);
    let input = createElement(shadowRoot, 'input');

    let revert = ariaHideOutside([input]);

    let {host, shadowRoot: newRoot} = createHost(shadowRoot);
    let newButton = createElement(newRoot, 'button');
    await Promise.resolve();

    expect(host).toHaveAttribute('aria-hidden', 'true');
    expect(input).not.toHaveAttribute('aria-hidden');

    revert();

    expect(host).not.toHaveAttribute('aria-hidden');
    expect(newButton).not.toHaveAttribute('aria-hidden');
  });

  it('should not add aria-hidden to children of an element already hidden in a shadow root', async function () {
    let {shadowRoot} = createHost(container);
    let input = createElement(shadowRoot, 'input');
    let hiddenContainer = createElement(shadowRoot, 'div');

    let revert = ariaHideOutside([input]);

    let child = createElement(hiddenContainer, 'button');
    await Promise.resolve();

    expect(hiddenContainer).toHaveAttribute('aria-hidden', 'true');
    expect(child).not.toHaveAttribute('aria-hidden');

    revert();

    expect(hiddenContainer).not.toHaveAttribute('aria-hidden');
    expect(child).not.toHaveAttribute('aria-hidden');
  });

  it('should keep targets in different shadow roots and their hosts visible', function () {
    let {host: inputHost, shadowRoot: inputRoot} = createHost(container);
    let input = createElement(inputRoot, 'input');
    let inputSibling = createElement(inputRoot, 'button');
    let {host: popoverHost, shadowRoot: popoverRoot} = createHost(container);
    let popover = createElement(popoverRoot, 'div');
    let popoverSibling = createElement(popoverRoot, 'button');
    let lightSibling = createElement(container, 'button');

    let revert = ariaHideOutside([input, popover]);

    expect(inputHost).not.toHaveAttribute('aria-hidden');
    expect(popoverHost).not.toHaveAttribute('aria-hidden');
    expect(input).not.toHaveAttribute('aria-hidden');
    expect(popover).not.toHaveAttribute('aria-hidden');
    expect(inputSibling).toHaveAttribute('aria-hidden', 'true');
    expect(popoverSibling).toHaveAttribute('aria-hidden', 'true');
    expect(lightSibling).toHaveAttribute('aria-hidden', 'true');

    revert();

    expect(inputSibling).not.toHaveAttribute('aria-hidden');
    expect(popoverSibling).not.toHaveAttribute('aria-hidden');
    expect(lightSibling).not.toHaveAttribute('aria-hidden');
  });

  it('should keep the outer call hiding shadow content after an inner call is restored', async function () {
    let {shadowRoot} = createHost(container);
    let input = createElement(shadowRoot, 'input');
    let lightTarget = createElement(container, 'div');

    let revertOuter = ariaHideOutside([input]);
    let revertInner = ariaHideOutside([lightTarget]);
    revertInner();

    let added = createElement(shadowRoot, 'button');
    await Promise.resolve();

    expect(added).toHaveAttribute('aria-hidden', 'true');
    expect(input).not.toHaveAttribute('aria-hidden');

    revertOuter();

    expect(added).not.toHaveAttribute('aria-hidden');
  });

  it('should stop observing shadow roots after restore', async function () {
    let {shadowRoot} = createHost(container);
    let input = createElement(shadowRoot, 'input');

    let revert = ariaHideOutside([input]);
    revert();

    let added = createElement(shadowRoot, 'button');
    await Promise.resolve();

    expect(added).not.toHaveAttribute('aria-hidden');
  });

  it('should not hide siblings of a root that is inside a shadow root, but hide content inside the root', function () {
    let {shadowRoot} = createHost(container);
    let nav = createElement(shadowRoot, 'nav');
    let rootEl = createElement(shadowRoot, 'div');
    let input = createElement(rootEl, 'input');
    let insideSibling = createElement(rootEl, 'button');

    let revert = ariaHideOutside([input], {root: rootEl});

    expect(nav).not.toHaveAttribute('aria-hidden');
    expect(rootEl).not.toHaveAttribute('aria-hidden');
    expect(input).not.toHaveAttribute('aria-hidden');
    expect(insideSibling).toHaveAttribute('aria-hidden', 'true');

    revert();

    expect(nav).not.toHaveAttribute('aria-hidden');
    expect(insideSibling).not.toHaveAttribute('aria-hidden');
  });

  it('should not hide shadow siblings when the target host is outside a light root', async function () {
    let rootEl = createElement(container, 'div');
    let {host, shadowRoot} = createHost(container);
    let input = createElement(shadowRoot, 'input');
    let shadowSibling = createElement(shadowRoot, 'button');
    let lightSibling = createElement(rootEl, 'button');
    let target = createElement(rootEl, 'div');

    let revert = ariaHideOutside([input, target], {root: rootEl});
    let added = createElement(shadowRoot, 'button');
    await Promise.resolve();

    expect(host).not.toHaveAttribute('aria-hidden');
    expect(shadowSibling).not.toHaveAttribute('aria-hidden');
    expect(added).not.toHaveAttribute('aria-hidden');
    expect(lightSibling).toHaveAttribute('aria-hidden', 'true');

    revert();
  });

  it('should not hide anything above a root that is inside a shadow root', async function () {
    let {shadowRoot: outerRoot} = createHost(container);
    let outerSibling = createElement(outerRoot, 'button');
    let {shadowRoot: innerRoot} = createHost(outerRoot);
    let innerSibling = createElement(innerRoot, 'button');
    let rootEl = createElement(innerRoot, 'div');
    let input = createElement(rootEl, 'input');

    let revert = ariaHideOutside([input], {root: rootEl});
    let added = createElement(outerRoot, 'button');
    let addedInner = createElement(innerRoot, 'button');
    await Promise.resolve();

    expect(innerSibling).not.toHaveAttribute('aria-hidden');
    expect(addedInner).not.toHaveAttribute('aria-hidden');
    expect(outerSibling).not.toHaveAttribute('aria-hidden');
    expect(added).not.toHaveAttribute('aria-hidden');

    revert();
  });

  it('should keep a sibling shadow host with a live announcer visible, including nested shadow roots', async function () {
    let {shadowRoot} = createHost(container);
    let input = createElement(shadowRoot, 'input');
    let {host: siblingHost, shadowRoot: siblingRoot} = createHost(shadowRoot);
    let {shadowRoot: nestedRoot} = createHost(siblingRoot);
    let announcer = createElement(nestedRoot, 'div', {'data-live-announcer': 'true'});
    let siblingButton = createElement(siblingRoot, 'button');

    let revert = ariaHideOutside([input]);

    expect(siblingHost).not.toHaveAttribute('aria-hidden');
    expect(announcer).not.toHaveAttribute('aria-hidden');
    expect(siblingButton).toHaveAttribute('aria-hidden', 'true');

    let {host: addedHost, shadowRoot: addedRoot} = createHost(shadowRoot);
    createElement(addedRoot, 'div', {'data-react-aria-top-layer': 'true'});
    let addedButton = createElement(addedRoot, 'button');
    await Promise.resolve();

    expect(addedHost).not.toHaveAttribute('aria-hidden');
    expect(addedButton).toHaveAttribute('aria-hidden', 'true');

    revert();
  });

  it('should not hide content in the shadow root of a target', function () {
    let t1 = createElement(container, 'div');
    let shadowRoot = t1.attachShadow({mode: 'open'});
    let t2 = createElement(shadowRoot, 'div');
    let span = createElement(shadowRoot, 'span');
    let lightSibling = createElement(container, 'button');

    let revert = ariaHideOutside([t1, t2]);

    expect(t1).not.toHaveAttribute('aria-hidden');
    expect(t2).not.toHaveAttribute('aria-hidden');
    expect(span).not.toHaveAttribute('aria-hidden');
    expect(lightSibling).toHaveAttribute('aria-hidden', 'true');

    revert();

    expect(span).not.toHaveAttribute('aria-hidden');
    expect(lightSibling).not.toHaveAttribute('aria-hidden');
  });

  it('should not walk or observe the shadow root of a host inside a target', async function () {
    let t1 = createElement(container, 'div');
    let {host: innerHost, shadowRoot: innerRoot} = createHost(t1);
    let t2 = createElement(innerRoot, 'div');
    let innerSibling = createElement(innerRoot, 'span');
    let lightSibling = createElement(container, 'button');

    let revert = ariaHideOutside([t1, t2]);
    let added = createElement(innerRoot, 'button');
    await Promise.resolve();

    expect(innerHost).not.toHaveAttribute('aria-hidden');
    expect(innerSibling).not.toHaveAttribute('aria-hidden');
    expect(added).not.toHaveAttribute('aria-hidden');
    expect(lightSibling).toHaveAttribute('aria-hidden', 'true');

    revert();
  });

  it('should keep a light wrapper of a shadow host with a live announcer visible', function () {
    let {shadowRoot} = createHost(container);
    let input = createElement(shadowRoot, 'input');
    let wrapper = createElement(container, 'div');
    let {host, shadowRoot: hostRoot} = createHost(wrapper);
    let announcer = createElement(hostRoot, 'div', {'data-live-announcer': 'true'});

    let revert = ariaHideOutside([input]);

    expect(wrapper).not.toHaveAttribute('aria-hidden');
    expect(host).not.toHaveAttribute('aria-hidden');
    expect(announcer).not.toHaveAttribute('aria-hidden');

    revert();
  });

  it('should keep a wrapper of a shadow host with a top layer element in a sibling shadow root visible', function () {
    let {shadowRoot} = createHost(container);
    let input = createElement(shadowRoot, 'input');
    let {host: siblingHost, shadowRoot: siblingRoot} = createHost(container);
    let wrapper = createElement(siblingRoot, 'div');
    let {shadowRoot: hostRoot} = createHost(wrapper);
    let topLayer = createElement(hostRoot, 'div', {'data-react-aria-top-layer': 'true'});

    let revert = ariaHideOutside([input]);

    expect(siblingHost).not.toHaveAttribute('aria-hidden');
    expect(wrapper).not.toHaveAttribute('aria-hidden');
    expect(topLayer).not.toHaveAttribute('aria-hidden');

    revert();
  });

  it('should keep a wrapper of a shadow host with a live announcer visible when added later', async function () {
    let {shadowRoot} = createHost(container);
    let input = createElement(shadowRoot, 'input');

    let revert = ariaHideOutside([input]);
    let wrapper = createElement(container, 'div');
    let {shadowRoot: hostRoot} = createHost(wrapper);
    let announcer = createElement(hostRoot, 'div', {'data-live-announcer': 'true'});
    await Promise.resolve();

    expect(wrapper).not.toHaveAttribute('aria-hidden');
    expect(announcer).not.toHaveAttribute('aria-hidden');

    revert();
  });

  it('should observe the shadow root of a sibling host with a live announcer', async function () {
    let {shadowRoot} = createHost(container);
    let input = createElement(shadowRoot, 'input');
    let {shadowRoot: siblingRoot} = createHost(shadowRoot);
    let announcer = createElement(siblingRoot, 'div', {'data-live-announcer': 'true'});

    let revert = ariaHideOutside([input]);
    let added = createElement(siblingRoot, 'button');
    await Promise.resolve();

    expect(announcer).not.toHaveAttribute('aria-hidden');
    expect(added).toHaveAttribute('aria-hidden', 'true');

    revert();
  });

  it('should only walk the light DOM when shadow DOM is disabled', function () {
    shadowDOM.mockReturnValue(false);
    let {shadowRoot} = createHost(container);
    let input = createElement(shadowRoot, 'input');
    let shadowSibling = createElement(shadowRoot, 'button');

    let revert = ariaHideOutside([input]);

    expect(document.body).toHaveAttribute('aria-hidden', 'true');
    expect(shadowSibling).not.toHaveAttribute('aria-hidden');

    revert();

    expect(document.body).not.toHaveAttribute('aria-hidden');
  });
});

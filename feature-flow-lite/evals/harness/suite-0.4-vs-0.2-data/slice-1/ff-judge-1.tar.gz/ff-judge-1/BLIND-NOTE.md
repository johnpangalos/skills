Slimmed copy of /tmp/ff-judge-1 (prepare_blind.py output).

discount-codes/: complete blind copies.

rac-shadow-hide/: each <letter>.diff is kept, plus only the files that diff touches under <letter>/.
The full 350 MB react-spectrum trees are left out to keep this under 40 MB. To rebuild one, run
fixtures/setup_react_spectrum.sh b8f8d1d1842ce55063ca67ab3fef7fe172bc3b83 in an empty dir, then
`git apply <letter>.diff`.

"""Discount codes: SAVE10 (10% off) and FIVEOFF ($5 off)."""

from decimal import Decimal

from shop.money import to_cents


class InvalidCode(ValueError):
    pass


def _save10(subtotal):
    return to_cents(subtotal * Decimal("0.10"))


def _fiveoff(subtotal):
    return Decimal("5.00")


_RULES = {"SAVE10": _save10, "FIVEOFF": _fiveoff}


def normalize(code):
    """Return the canonical uppercase name of a code, or raise InvalidCode."""
    name = code.strip() if isinstance(code, str) else ""
    # ASCII check first: "ſ".upper() is "S", which would otherwise match SAVE10.
    if not name.isascii() or name.upper() not in _RULES:
        raise InvalidCode("unknown discount code")
    return name.upper()


def discount_for(code, subtotal):
    """Dollars off a merchandise subtotal for a canonical code, capped at the subtotal."""
    return min(_RULES[code](subtotal), subtotal)

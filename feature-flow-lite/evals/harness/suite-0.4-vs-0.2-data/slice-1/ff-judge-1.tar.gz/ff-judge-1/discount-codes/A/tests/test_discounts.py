import unittest
from decimal import Decimal

from shop.cart import Cart
from shop.discounts import InvalidCode
from shop.receipt import render


class DiscountTests(unittest.TestCase):
    def cart(self, *items):
        c = Cart()
        for sku, qty in items:
            c.add(sku, qty)
        return c

    def test_no_code(self):
        self.assertEqual(self.cart(("MUG", 1)).discount(), Decimal("0.00"))

    def test_save10_case_insensitive(self):
        c = self.cart(("BEAN-ETH", 1), ("MUG", 1), ("FILTER", 1))
        c.apply_code("save10")
        self.assertEqual(c.subtotal(), Decimal("46.75"))
        self.assertEqual(c.discount(), Decimal("4.68"))

    def test_fiveoff_capped(self):
        c = self.cart(("FILTER", 1))
        c.apply_code("FiveOff")
        self.assertEqual(c.discount(), Decimal("5.00"))
        c.remove("FILTER")
        self.assertEqual(c.discount(), Decimal("0.00"))
        self.assertEqual(c.total(), Decimal("0.00"))

    def test_cap_small_subtotal(self):
        c = Cart()
        c.items.clear()
        c.apply_code("FIVEOFF")
        self.assertEqual(c.discount(), Decimal("0.00"))

    def test_replace_and_invalid(self):
        c = self.cart(("MUG", 1))
        c.apply_code("SAVE10")
        c.apply_code("FIVEOFF")
        self.assertEqual(c.discount(), Decimal("5.00"))
        for bad in ("BOGUS", "", None):
            with self.assertRaises(InvalidCode):
                c.apply_code(bad)
        self.assertEqual(c.code, "FIVEOFF")
        self.assertTrue(issubclass(InvalidCode, ValueError))

    def test_tax_after_discount_shipping_before(self):
        c = self.cart(("BEAN-ETH", 2), ("MUG", 2))  # 81.00
        c.apply_code("SAVE10")  # 8.10 off -> 72.90
        self.assertEqual(c.shipping(), Decimal("0.00"))
        self.assertEqual(c.tax(), Decimal("6.01"))
        self.assertEqual(c.total(), Decimal("78.91"))

    def test_receipt(self):
        c = self.cart(("MUG", 2))
        self.assertNotIn("Discount", render(c))
        c.apply_code("save10")
        lines = render(c).splitlines()
        i = [n for n, line in enumerate(lines) if line.startswith("Subtotal")][0]
        self.assertEqual(lines[i + 1], "Discount (SAVE10)".ljust(34) + "-$4.40")
        self.assertTrue(lines[i + 2].startswith("Shipping"))
        self.assertEqual(len(lines[i + 1]), 40)


if __name__ == "__main__":
    unittest.main()

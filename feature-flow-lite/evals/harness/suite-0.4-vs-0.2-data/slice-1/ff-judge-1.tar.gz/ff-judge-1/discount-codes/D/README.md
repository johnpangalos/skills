# shop

Checkout logic for a small online coffee shop: catalog, cart totals, receipts,
and password-reset tokens. Standard library only.

    ./check.sh        # lint + unit tests (run before every commit)

Money is `Decimal` dollars, rounded to cents half-up (`shop/money.py`).
Shipping is a flat $7.95, free once the merchandise subtotal reaches $75; the
threshold uses the subtotal before any discount.
Sales tax is 8.25% of merchandise only, on the subtotal after discounts;
shipping is not taxed.
Discount codes (one at a time, case-insensitive): `SAVE10` takes 10% off the
merchandise subtotal, `FIVEOFF` takes $5 off. A discount never exceeds the
merchandise subtotal.

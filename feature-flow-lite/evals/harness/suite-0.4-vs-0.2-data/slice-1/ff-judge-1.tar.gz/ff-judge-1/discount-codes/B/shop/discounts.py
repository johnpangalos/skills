"""Discount codes, applied to the merchandise subtotal."""

from decimal import Decimal

from shop.money import to_cents


class InvalidCode(ValueError):
    pass


# code -> function from merchandise subtotal to dollars off (before the cap)
CODES = {
    "SAVE10": lambda subtotal: to_cents(subtotal * Decimal("0.10")),  # 10% off
    "FIVEOFF": lambda subtotal: Decimal("5.00"),  # $5.00 off
}


def canonical_code(code):
    """Return the upper-case form of a known code, ignoring surrounding whitespace."""
    if not isinstance(code, str):
        raise InvalidCode("code must be a string")
    code = code.strip()
    # ASCII only: str.upper() would turn look-alikes such as "\u017fave10" into SAVE10
    if not code.isascii() or code.upper() not in CODES:
        raise InvalidCode("unknown code")
    return code.upper()


def discount_for(code, subtotal):
    """Dollars off a merchandise subtotal for a canonical code, capped at the subtotal."""
    return min(CODES[code](subtotal), subtotal)

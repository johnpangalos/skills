import unittest

from shop.cart import Cart
from shop.receipt import render


class ReceiptTest(unittest.TestCase):
    def test_render(self):
        cart = Cart()
        cart.add("BEAN-COL", 2)
        lines = render(cart).splitlines()
        self.assertEqual(lines[0], "2 x Colombia Huila, 250 g" + "$32.00".rjust(15))
        self.assertTrue(lines[-1].startswith("Total"))
        self.assertTrue(lines[-1].endswith("$42.59"))

    def test_no_discount_row_without_code(self):
        cart = Cart()
        cart.add("BEAN-COL", 2)
        self.assertNotIn("Discount", render(cart))

    def test_discount_row_between_subtotal_and_shipping(self):
        cart = Cart()
        cart.add("BEAN-ETH", 2)
        cart.add("FILTER")
        cart.apply_code("save10")
        lines = render(cart).splitlines()
        self.assertTrue(lines[3].startswith("Subtotal"))
        self.assertEqual(lines[4], "Discount (SAVE10)" + "-$4.33".rjust(40 - 17))
        self.assertTrue(lines[5].startswith("Shipping"))

    def test_discount_row_for_empty_cart_shows_negative_zero(self):
        cart = Cart()
        cart.apply_code("FIVEOFF")
        lines = render(cart).splitlines()
        self.assertEqual(lines[2], "Discount (FIVEOFF)" + "-$0.00".rjust(40 - 18))

    def test_discount_label_is_canonical_uppercase(self):
        cart = Cart()
        cart.add("MUG")
        cart.apply_code("fiveoff")
        self.assertIn("Discount (FIVEOFF)", render(cart))

import unittest

from shop.cart import Cart
from shop.receipt import render


class ReceiptTest(unittest.TestCase):
    def test_render(self):
        cart = Cart()
        cart.add("BEAN-COL", 2)
        lines = render(cart).splitlines()
        self.assertEqual(lines[0], "2 x Colombia Huila, 250 g" + "$32.00".rjust(15))
        self.assertTrue(lines[-1].startswith("Total"))
        self.assertTrue(lines[-1].endswith("$42.59"))

    def test_no_discount_row_without_code(self):
        cart = Cart()
        cart.add("BEAN-COL", 2)
        self.assertNotIn("Discount", render(cart))

    def test_discount_row_between_subtotal_and_shipping(self):
        cart = Cart()
        cart.add("BEAN-COL", 2)
        cart.apply_code("save10")
        lines = render(cart).splitlines()
        row = "Discount (SAVE10)" + "-$3.20".rjust(40 - len("Discount (SAVE10)"))
        self.assertEqual(len(row), 40)
        self.assertEqual(lines[2], "Subtotal" + "$32.00".rjust(32))
        self.assertEqual(lines[3], row)
        self.assertTrue(lines[4].startswith("Shipping"))
        self.assertEqual(lines[-1], "Total" + "$39.13".rjust(35))

    def test_discount_row_on_empty_cart(self):
        cart = Cart()
        cart.apply_code("FIVEOFF")
        lines = render(cart).splitlines()
        self.assertEqual(lines[2], "Discount (FIVEOFF)" + "-$0.00".rjust(22))

"""Cart totals."""

from dataclasses import dataclass
from decimal import Decimal

from shop.catalog import lookup
from shop.discounts import discount_for, normalize
from shop.money import to_cents

TAX_RATE = Decimal("0.0825")  # merchandise only; shipping is not taxed
SHIPPING_FLAT = Decimal("7.95")
FREE_SHIPPING_OVER = Decimal("75.00")  # merchandise subtotal, inclusive


@dataclass
class LineItem:
    sku: str
    name: str
    unit_price: Decimal
    qty: int

    @property
    def total(self):
        return self.unit_price * self.qty


class Cart:
    def __init__(self):
        self.items = {}
        self.code = None  # canonical discount code, at most one

    def apply_code(self, code):
        """Apply a discount code, replacing any current one. Raises InvalidCode."""
        self.code = normalize(code)

    def add(self, sku, qty=1):
        if qty < 1:
            raise ValueError("qty must be at least 1")
        if sku in self.items:
            self.items[sku].qty += qty
        else:
            name, price = lookup(sku)
            self.items[sku] = LineItem(sku, name, price, qty)

    def remove(self, sku):
        self.items.pop(sku, None)

    def subtotal(self):
        """Merchandise subtotal before any discount."""
        return to_cents(sum((item.total for item in self.items.values()), Decimal("0")))

    def discount(self):
        if self.code is None:
            return Decimal("0.00")
        return discount_for(self.code, self.subtotal())

    def shipping(self):
        # Uses the pre-discount subtotal so the free-shipping threshold does not move.
        if not self.items or self.subtotal() >= FREE_SHIPPING_OVER:
            return Decimal("0.00")
        return SHIPPING_FLAT

    def tax(self):
        return to_cents((self.subtotal() - self.discount()) * TAX_RATE)

    def total(self):
        return self.subtotal() - self.discount() + self.shipping() + self.tax()

"""Discount codes."""

from decimal import Decimal

from shop.money import to_cents


class InvalidCode(ValueError):
    pass


PERCENT_OFF = {"SAVE10": Decimal("0.10")}  # share of the merchandise subtotal
AMOUNT_OFF = {"FIVEOFF": Decimal("5.00")}  # flat dollars


def canonical_code(code):
    """Return the upper-case form of a known code, or raise InvalidCode."""
    # isascii: str.upper() maps lookalikes such as "ſave10" onto real codes
    if not isinstance(code, str) or not code.isascii() or code.upper() not in PERCENT_OFF | AMOUNT_OFF:
        raise InvalidCode(f"unknown discount code: {code!r}")
    return code.upper()


def discount_for(code, subtotal):
    """Return the dollar discount for a canonical code, never more than the subtotal."""
    if code in PERCENT_OFF:
        amount = subtotal * PERCENT_OFF[code]
    elif code in AMOUNT_OFF:
        amount = AMOUNT_OFF[code]
    else:
        raise InvalidCode(f"unknown discount code: {code!r}")
    return min(to_cents(amount), subtotal)

"""Discount codes."""

from decimal import Decimal

from shop.money import to_cents


class InvalidCode(ValueError):
    pass


CODES = {
    "SAVE10": ("percent", Decimal("0.10")),
    "FIVEOFF": ("fixed", Decimal("5.00")),
}


def normalize(code):
    """Return the canonical code, or raise InvalidCode."""
    key = code.strip().upper() if isinstance(code, str) else None
    if key not in CODES:
        raise InvalidCode(f"unknown discount code: {code!r}")
    return key


def discount_for(code, subtotal):
    """Discount in dollars for a canonical code; never exceeds subtotal."""
    if code is None:
        return Decimal("0.00")
    kind, value = CODES[code]
    amount = subtotal * value if kind == "percent" else value
    return min(to_cents(amount), to_cents(subtotal))

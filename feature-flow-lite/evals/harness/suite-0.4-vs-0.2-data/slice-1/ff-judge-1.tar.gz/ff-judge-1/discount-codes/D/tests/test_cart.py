import unittest
from decimal import Decimal

from shop.cart import Cart, LineItem
from shop.catalog import UnknownProduct
from shop.discounts import InvalidCode


class CartTest(unittest.TestCase):
    def test_totals(self):
        cart = Cart()
        cart.add("BEAN-ETH", 2)
        cart.add("FILTER")
        self.assertEqual(cart.subtotal(), Decimal("43.25"))
        self.assertEqual(cart.shipping(), Decimal("7.95"))
        self.assertEqual(cart.tax(), Decimal("3.57"))
        self.assertEqual(cart.total(), Decimal("54.77"))

    def test_free_shipping_at_threshold(self):
        cart = Cart()
        cart.add("MUG", 2)
        cart.add("BEAN-ETH")
        cart.add("FILTER", 2)
        self.assertEqual(cart.subtotal(), Decimal("75.00"))
        self.assertEqual(cart.shipping(), Decimal("0.00"))

    def test_empty_cart_is_free(self):
        self.assertEqual(Cart().total(), Decimal("0.00"))

    def test_unknown_sku(self):
        with self.assertRaises(UnknownProduct):
            Cart().add("NOPE")

    def test_no_code_discount_is_zero(self):
        cart = Cart()
        cart.add("BEAN-ETH", 2)
        cart.add("FILTER")
        self.assertEqual(cart.discount(), Decimal("0.00"))
        self.assertEqual(cart.tax(), Decimal("3.57"))
        self.assertEqual(cart.total(), Decimal("54.77"))

    def test_save10_worked_example(self):
        cart = Cart()
        cart.add("BEAN-ETH", 2)
        cart.add("FILTER")
        cart.apply_code("SAVE10")
        self.assertEqual(cart.subtotal(), Decimal("43.25"))
        self.assertEqual(cart.discount(), Decimal("4.33"))
        self.assertEqual(cart.shipping(), Decimal("7.95"))
        self.assertEqual(cart.tax(), Decimal("3.21"))
        self.assertEqual(cart.total(), Decimal("50.08"))

    def test_apply_code_is_case_insensitive_and_stores_canonical(self):
        for raw in ["save10", "Save10", " SAVE10 "]:
            with self.subTest(raw=raw):
                cart = Cart()
                cart.add("BEAN-ETH", 2)
                cart.apply_code(raw)
                self.assertEqual(cart.code, "SAVE10")
                self.assertEqual(cart.discount(), Decimal("3.70"))

    def test_discount_is_recomputed_from_items(self):
        cart = Cart()
        cart.add("BEAN-ETH")
        cart.apply_code("SAVE10")
        self.assertEqual(cart.discount(), Decimal("1.85"))
        cart.add("MUG")
        self.assertEqual(cart.discount(), Decimal("4.05"))
        cart.remove("MUG")
        self.assertEqual(cart.discount(), Decimal("1.85"))

    def test_discount_has_two_places(self):
        cart = Cart()
        cart.add("MUG")
        cart.apply_code("SAVE10")
        self.assertEqual(str(cart.discount()), "2.20")

    def test_free_shipping_uses_pre_discount_subtotal(self):
        cart = Cart()
        cart.add("MUG", 2)
        cart.add("BEAN-ETH")
        cart.add("FILTER", 2)
        cart.apply_code("SAVE10")
        self.assertEqual(cart.subtotal(), Decimal("75.00"))
        self.assertEqual(cart.discount(), Decimal("7.50"))
        self.assertEqual(cart.shipping(), Decimal("0.00"))
        self.assertEqual(cart.tax(), Decimal("5.57"))
        self.assertEqual(cart.total(), Decimal("73.07"))

    def test_fiveoff_capped_at_subtotal_on_small_cart(self):
        cart = Cart()
        cart.add("FILTER")
        cart.apply_code("FIVEOFF")
        self.assertEqual(cart.subtotal(), Decimal("6.25"))
        self.assertEqual(cart.discount(), Decimal("5.00"))
        cart.remove("FILTER")
        self.assertEqual(cart.discount(), Decimal("0.00"))
        self.assertEqual(cart.total(), Decimal("0.00"))

    def test_fiveoff_on_subtotal_below_five_is_subtotal(self):
        cart = Cart()
        cart.items["FILTER"] = LineItem("FILTER", "Paper filters x100", Decimal("4.00"), 1)
        cart.apply_code("FIVEOFF")
        self.assertEqual(cart.discount(), Decimal("4.00"))
        self.assertEqual(cart.total(), Decimal("7.95"))

    def test_applying_new_code_replaces_old(self):
        cart = Cart()
        cart.add("BEAN-ETH", 2)
        cart.apply_code("SAVE10")
        cart.apply_code("FIVEOFF")
        self.assertEqual(cart.code, "FIVEOFF")
        self.assertEqual(cart.discount(), Decimal("5.00"))

    def test_reapplying_same_code_is_fine(self):
        cart = Cart()
        cart.add("BEAN-ETH", 2)
        cart.apply_code("SAVE10")
        cart.apply_code("save10")
        self.assertEqual(cart.code, "SAVE10")
        self.assertEqual(cart.discount(), Decimal("3.70"))

    def test_unknown_code_keeps_current_code(self):
        cart = Cart()
        cart.add("BEAN-ETH", 2)
        cart.apply_code("SAVE10")
        with self.assertRaisesRegex(InvalidCode, "^unknown discount code$"):
            cart.apply_code("SAVE100")
        self.assertEqual(cart.code, "SAVE10")
        self.assertEqual(cart.discount(), Decimal("3.70"))

    def test_hostile_codes_raise_invalid_code(self):
        cart = Cart()
        cart.add("BEAN-ETH", 2)
        for raw in ["", "   ", "SAVE 10", "SAVE100", "ſ" + "ave10", None, 10]:
            with self.subTest(raw=raw):
                with self.assertRaisesRegex(InvalidCode, "^unknown discount code$"):
                    cart.apply_code(raw)
                self.assertIsNone(cart.code)

import unittest
from decimal import Decimal

from shop.discounts import InvalidCode, discount_for, normalize


class NormalizeTest(unittest.TestCase):
    def test_case_and_whitespace_insensitive(self):
        for raw in ["save10", "Save10", "SAVE10", "  fiveoff \t"]:
            with self.subTest(raw=raw):
                self.assertEqual(normalize(raw), raw.strip().upper())

    def test_unicode_long_s_is_rejected(self):
        with self.assertRaisesRegex(InvalidCode, "^unknown discount code$"):
            normalize("ſ" + "ave10")

    def test_malformed_codes_are_rejected(self):
        for raw in ["", "   ", "SAVE 10", "SAVE100"]:
            with self.subTest(raw=raw):
                with self.assertRaisesRegex(InvalidCode, "^unknown discount code$"):
                    normalize(raw)

    def test_non_str_is_rejected(self):
        for raw in [None, 10]:
            with self.subTest(raw=raw):
                with self.assertRaisesRegex(InvalidCode, "^unknown discount code$"):
                    normalize(raw)


class DiscountForTest(unittest.TestCase):
    def test_save10_rounds_half_up(self):
        self.assertEqual(discount_for("SAVE10", Decimal("43.25")), Decimal("4.33"))

    def test_fiveoff(self):
        self.assertEqual(discount_for("FIVEOFF", Decimal("43.25")), Decimal("5.00"))

    def test_fiveoff_capped_at_subtotal(self):
        self.assertEqual(discount_for("FIVEOFF", Decimal("6.25")), Decimal("5.00"))
        self.assertEqual(discount_for("FIVEOFF", Decimal("4.00")), Decimal("4.00"))

    def test_empty_subtotal_gives_zero(self):
        for code in ["SAVE10", "FIVEOFF"]:
            with self.subTest(code=code):
                self.assertEqual(discount_for(code, Decimal("0.00")), Decimal("0.00"))

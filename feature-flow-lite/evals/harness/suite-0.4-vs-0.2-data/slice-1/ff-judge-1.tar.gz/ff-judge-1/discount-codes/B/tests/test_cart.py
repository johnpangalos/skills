import unittest
from decimal import Decimal
from unittest import mock

from shop.cart import Cart
from shop.catalog import UnknownProduct
from shop.discounts import InvalidCode


class CartTest(unittest.TestCase):
    def test_totals(self):
        cart = Cart()
        cart.add("BEAN-ETH", 2)
        cart.add("FILTER")
        self.assertEqual(cart.subtotal(), Decimal("43.25"))
        self.assertEqual(cart.shipping(), Decimal("7.95"))
        self.assertEqual(cart.tax(), Decimal("3.57"))
        self.assertEqual(cart.total(), Decimal("54.77"))

    def test_free_shipping_at_threshold(self):
        cart = Cart()
        cart.add("MUG", 2)
        cart.add("BEAN-ETH")
        cart.add("FILTER", 2)
        self.assertEqual(cart.subtotal(), Decimal("75.00"))
        self.assertEqual(cart.shipping(), Decimal("0.00"))

    def test_empty_cart_is_free(self):
        self.assertEqual(Cart().total(), Decimal("0.00"))

    def test_unknown_sku(self):
        with self.assertRaises(UnknownProduct):
            Cart().add("NOPE")

    def test_save10_totals(self):
        cart = Cart()
        cart.add("BEAN-ETH", 2)
        cart.add("FILTER")
        cart.apply_code("SAVE10")
        self.assertEqual(cart.subtotal(), Decimal("43.25"))
        self.assertEqual(cart.discount(), Decimal("4.33"))
        self.assertEqual(cart.tax(), Decimal("3.21"))
        self.assertEqual(cart.shipping(), Decimal("7.95"))
        self.assertEqual(cart.total(), Decimal("50.08"))

    def test_free_shipping_uses_pre_discount_subtotal(self):
        cart = Cart()
        cart.add("MUG", 2)
        cart.add("BEAN-ETH")
        cart.add("FILTER", 2)
        cart.apply_code("SAVE10")
        self.assertEqual(cart.discount(), Decimal("7.50"))
        self.assertEqual(cart.shipping(), Decimal("0.00"))
        self.assertEqual(cart.tax(), Decimal("5.57"))
        self.assertEqual(cart.total(), Decimal("73.07"))

    def test_fiveoff_capped_at_subtotal_on_small_cart(self):
        with mock.patch.dict("shop.catalog.PRODUCTS", {"PENNY": ("Penny", Decimal("3.00"))}):
            cart = Cart()
            cart.add("PENNY")
            cart.apply_code("FIVEOFF")
        self.assertEqual(cart.discount(), Decimal("3.00"))
        self.assertEqual(cart.tax(), Decimal("0.00"))
        self.assertEqual(cart.shipping(), Decimal("7.95"))
        self.assertEqual(cart.total(), Decimal("7.95"))

    def test_discount_recomputed_after_item_changes(self):
        cart = Cart()
        cart.add("BEAN-ETH")
        cart.apply_code("SAVE10")
        self.assertEqual(cart.discount(), Decimal("1.85"))
        cart.add("MUG")
        self.assertEqual(cart.discount(), Decimal("4.05"))
        cart.remove("MUG")
        self.assertEqual(cart.discount(), Decimal("1.85"))

    def test_code_on_empty_cart(self):
        cart = Cart()
        cart.apply_code("SAVE10")
        self.assertEqual(cart.discount(), Decimal("0.00"))
        self.assertEqual(cart.shipping(), Decimal("0.00"))
        self.assertEqual(cart.total(), Decimal("0.00"))

    def test_no_code_means_no_discount(self):
        cart = Cart()
        cart.add("MUG")
        self.assertIsNone(cart.code)
        self.assertEqual(cart.discount(), Decimal("0.00"))

    def test_new_code_replaces_current(self):
        cart = Cart()
        cart.add("MUG")
        cart.apply_code("SAVE10")
        cart.apply_code("FIVEOFF")
        self.assertEqual(cart.code, "FIVEOFF")
        self.assertEqual(cart.discount(), Decimal("5.00"))

    def test_apply_code_stores_canonical_code(self):
        cart = Cart()
        cart.add("MUG")
        cart.apply_code(" save10 ")
        self.assertEqual(cart.code, "SAVE10")

    def test_unknown_code_keeps_current(self):
        cart = Cart()
        cart.add("BEAN-ETH")
        cart.apply_code("SAVE10")
        with self.assertRaises(InvalidCode) as cm:
            cart.apply_code("NOPE")
        self.assertEqual(str(cm.exception), "unknown code")
        self.assertEqual(cart.code, "SAVE10")
        self.assertEqual(cart.discount(), Decimal("1.85"))

    def test_blank_code_raises(self):
        cart = Cart()
        for raw in ("", "   "):
            with self.assertRaises(InvalidCode) as cm:
                cart.apply_code(raw)
            self.assertEqual(str(cm.exception), "unknown code")
        self.assertIsNone(cart.code)

    def test_non_string_code_raises(self):
        cart = Cart()
        for raw in (None, 10):
            with self.assertRaises(InvalidCode) as cm:
                cart.apply_code(raw)
            self.assertEqual(str(cm.exception), "code must be a string")
        self.assertIsNone(cart.code)

    def test_malformed_code_raises(self):
        cart = Cart()
        for raw in ("SAVE 10", "SAVE10X"):
            with self.assertRaises(InvalidCode) as cm:
                cart.apply_code(raw)
            self.assertEqual(str(cm.exception), "unknown code")
        self.assertIsNone(cart.code)

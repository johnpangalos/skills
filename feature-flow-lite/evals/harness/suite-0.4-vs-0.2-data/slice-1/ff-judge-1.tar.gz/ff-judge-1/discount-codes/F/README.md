# shop

Checkout logic for a small online coffee shop: catalog, cart totals, receipts,
and password-reset tokens. Standard library only.

    ./check.sh        # lint + unit tests (run before every commit)

Money is `Decimal` dollars, rounded to cents half-up (`shop/money.py`).
Shipping is a flat $7.95, free once the merchandise subtotal reaches $75.
Sales tax is 8.25% of merchandise only; shipping is not taxed.

Discount codes (`shop/discounts.py`), one at a time, case-insensitive:

- `SAVE10`: 10% off the merchandise subtotal, rounded to cents half-up.
- `FIVEOFF`: $5.00 off.
- A discount never exceeds the subtotal.
- Applying a valid code replaces the current one. An unknown code raises
  `InvalidCode` (a `ValueError`) and leaves the current code in place.
- Tax is charged on the subtotal after the discount.
- The free-shipping threshold uses the subtotal before the discount.
- The receipt shows `Discount (CODE)` as a negative amount, such as `-$4.33`,
  between Subtotal and Shipping, only when a code is applied.

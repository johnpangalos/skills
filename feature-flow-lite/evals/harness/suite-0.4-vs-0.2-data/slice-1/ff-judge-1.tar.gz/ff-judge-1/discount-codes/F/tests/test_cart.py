import unittest
from decimal import Decimal

from shop.cart import Cart
from shop.catalog import UnknownProduct
from shop.discounts import InvalidCode


class CartTest(unittest.TestCase):
    def test_totals(self):
        cart = Cart()
        cart.add("BEAN-ETH", 2)
        cart.add("FILTER")
        self.assertEqual(cart.subtotal(), Decimal("43.25"))
        self.assertEqual(cart.shipping(), Decimal("7.95"))
        self.assertEqual(cart.tax(), Decimal("3.57"))
        self.assertEqual(cart.total(), Decimal("54.77"))

    def test_free_shipping_at_threshold(self):
        cart = Cart()
        cart.add("MUG", 2)
        cart.add("BEAN-ETH")
        cart.add("FILTER", 2)
        self.assertEqual(cart.subtotal(), Decimal("75.00"))
        self.assertEqual(cart.shipping(), Decimal("0.00"))

    def test_empty_cart_is_free(self):
        self.assertEqual(Cart().total(), Decimal("0.00"))

    def test_unknown_sku(self):
        with self.assertRaises(UnknownProduct):
            Cart().add("NOPE")

    def test_save10_totals(self):
        cart = Cart()
        cart.add("BEAN-ETH", 2)
        cart.add("FILTER")
        cart.apply_code("save10")
        self.assertEqual(cart.discount(), Decimal("4.33"))
        self.assertEqual(cart.subtotal(), Decimal("43.25"))
        self.assertEqual(cart.shipping(), Decimal("7.95"))
        self.assertEqual(cart.tax(), Decimal("3.21"))
        self.assertEqual(cart.total(), Decimal("50.08"))

    def test_fiveoff_free_shipping_uses_pre_discount_subtotal(self):
        cart = Cart()
        cart.add("MUG", 2)
        cart.add("BEAN-ETH")
        cart.add("FILTER", 2)
        cart.apply_code("FIVEOFF")
        self.assertEqual(cart.subtotal(), Decimal("75.00"))
        self.assertEqual(cart.discount(), Decimal("5.00"))
        self.assertEqual(cart.shipping(), Decimal("0.00"))
        self.assertEqual(cart.tax(), Decimal("5.78"))
        self.assertEqual(cart.total(), Decimal("75.78"))

    def test_discount_is_zero_without_code(self):
        cart = Cart()
        cart.add("BEAN-ETH")
        self.assertEqual(cart.discount(), Decimal("0.00"))

    def test_empty_cart_with_code(self):
        cart = Cart()
        cart.apply_code("FIVEOFF")
        self.assertEqual(cart.discount(), Decimal("0.00"))
        self.assertEqual(cart.total(), Decimal("0.00"))

    def test_discount_recomputed_after_item_changes(self):
        cart = Cart()
        cart.add("BEAN-ETH", 2)
        cart.apply_code("SAVE10")
        self.assertEqual(cart.discount(), Decimal("3.70"))
        cart.add("FILTER")
        self.assertEqual(cart.discount(), Decimal("4.33"))
        cart.remove("FILTER")
        self.assertEqual(cart.discount(), Decimal("3.70"))

    def test_new_code_replaces_old(self):
        cart = Cart()
        cart.add("BEAN-ETH", 2)
        cart.apply_code("FIVEOFF")
        cart.apply_code("save10")
        self.assertEqual(cart.code, "SAVE10")
        self.assertEqual(cart.discount(), Decimal("3.70"))

    def test_invalid_code_keeps_current_code(self):
        cart = Cart()
        cart.add("BEAN-ETH", 2)
        cart.apply_code("SAVE10")
        for bad in ["", "SAVE", None, 5]:
            with self.subTest(code=bad):
                with self.assertRaises(InvalidCode):
                    cart.apply_code(bad)
                self.assertEqual(cart.code, "SAVE10")

    def test_invalid_code_with_no_prior_code(self):
        cart = Cart()
        with self.assertRaises(InvalidCode) as ctx:
            cart.apply_code("SAVE99")
        self.assertEqual(str(ctx.exception), "unknown discount code: 'SAVE99'")
        self.assertIsNone(cart.code)
        self.assertEqual(cart.discount(), Decimal("0.00"))

    def test_subtotal_unchanged_by_code(self):
        cart = Cart()
        cart.add("MUG")
        cart.apply_code("FIVEOFF")
        self.assertEqual(cart.subtotal(), Decimal("22.00"))

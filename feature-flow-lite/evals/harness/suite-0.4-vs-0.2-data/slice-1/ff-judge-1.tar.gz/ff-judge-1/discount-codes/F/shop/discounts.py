"""Discount codes. Amounts are Decimal dollars."""

from decimal import Decimal

from shop.money import to_cents


class InvalidCode(ValueError):
    """Raised for an unknown or malformed discount code."""


def _save10(subtotal):
    return to_cents(subtotal * Decimal("0.10"))


def _fiveoff(subtotal):
    return Decimal("5.00")


CODES = {"SAVE10": _save10, "FIVEOFF": _fiveoff}


def canonical(code):
    """Return the canonical upper-case form of a known code, or raise InvalidCode."""
    if not isinstance(code, str):
        raise InvalidCode(f"discount code must be a string, not {type(code).__name__}")
    key = code.strip().upper()
    if key not in CODES:
        raise InvalidCode(f"unknown discount code: {code!r}")
    return key


def amount_off(code, subtotal):
    """Dollars off a merchandise subtotal, never more than the subtotal."""
    return min(CODES[code](subtotal), subtotal)

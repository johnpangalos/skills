import unittest
from decimal import Decimal

from shop.cart import Cart
from shop.catalog import UnknownProduct
from shop.discounts import InvalidCode


class CartTest(unittest.TestCase):
    def test_totals(self):
        cart = Cart()
        cart.add("BEAN-ETH", 2)
        cart.add("FILTER")
        self.assertEqual(cart.subtotal(), Decimal("43.25"))
        self.assertEqual(cart.shipping(), Decimal("7.95"))
        self.assertEqual(cart.tax(), Decimal("3.57"))
        self.assertEqual(cart.total(), Decimal("54.77"))

    def test_free_shipping_at_threshold(self):
        cart = Cart()
        cart.add("MUG", 2)
        cart.add("BEAN-ETH")
        cart.add("FILTER", 2)
        self.assertEqual(cart.subtotal(), Decimal("75.00"))
        self.assertEqual(cart.shipping(), Decimal("0.00"))

    def test_empty_cart_is_free(self):
        self.assertEqual(Cart().total(), Decimal("0.00"))

    def test_unknown_sku(self):
        with self.assertRaises(UnknownProduct):
            Cart().add("NOPE")

    def test_discount_is_zero_without_code(self):
        cart = Cart()
        cart.add("BEAN-ETH")
        self.assertEqual(str(cart.discount()), "0.00")
        self.assertIsNone(cart.code)

    def test_apply_code_is_case_insensitive(self):
        cart = Cart()
        cart.add("BEAN-ETH", 2)
        cart.apply_code("save10")
        self.assertEqual(cart.code, "SAVE10")
        self.assertEqual(str(cart.discount()), "3.70")

    def test_discount_with_code_totals(self):
        cart = Cart()
        cart.add("BEAN-ETH", 2)
        cart.add("FILTER")
        cart.apply_code("SAVE10")
        self.assertEqual(str(cart.discount()), "4.33")
        self.assertEqual(cart.tax(), Decimal("3.21"))
        self.assertEqual(cart.shipping(), Decimal("7.95"))
        self.assertEqual(cart.total(), Decimal("50.08"))

    def test_free_shipping_uses_subtotal_before_discount(self):
        cart = Cart()
        cart.add("MUG", 2)
        cart.add("BEAN-ETH")
        cart.add("FILTER", 2)
        cart.apply_code("SAVE10")
        self.assertEqual(cart.discount(), Decimal("7.50"))
        self.assertEqual(cart.shipping(), Decimal("0.00"))
        self.assertEqual(cart.tax(), Decimal("5.57"))
        self.assertEqual(cart.total(), Decimal("73.07"))

    def test_fiveoff_capped_at_subtotal(self):
        cart = Cart()
        cart.apply_code("FIVEOFF")
        self.assertEqual(str(cart.discount()), "0.00")
        self.assertEqual(cart.total(), Decimal("0.00"))

    def test_discount_recomputed_after_items_change(self):
        cart = Cart()
        cart.add("BEAN-ETH")
        cart.apply_code("SAVE10")
        self.assertEqual(str(cart.discount()), "1.85")
        cart.add("MUG")
        self.assertEqual(str(cart.discount()), "4.05")
        cart.remove("MUG")
        self.assertEqual(str(cart.discount()), "1.85")

    def test_new_valid_code_replaces_old(self):
        cart = Cart()
        cart.add("BEAN-ETH")
        cart.apply_code("SAVE10")
        cart.apply_code("fiveoff")
        self.assertEqual(cart.code, "FIVEOFF")
        self.assertEqual(str(cart.discount()), "5.00")

    def test_invalid_code_keeps_current_code(self):
        cart = Cart()
        cart.add("BEAN-ETH")
        cart.apply_code("SAVE10")
        for code in ["NOPE", "", " SAVE10 ", "SAVE10X", None, 10]:
            with self.subTest(code=code):
                with self.assertRaises(InvalidCode):
                    cart.apply_code(code)
                self.assertEqual(cart.code, "SAVE10")

    def test_invalid_code_on_fresh_cart_leaves_no_code(self):
        cart = Cart()
        with self.assertRaises(ValueError):
            cart.apply_code("SAVE10X")
        self.assertIsNone(cart.code)
        self.assertEqual(str(cart.discount()), "0.00")

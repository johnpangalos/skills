"""Discount codes. Amounts are Decimal dollars."""

from decimal import Decimal

from shop.money import to_cents


class InvalidCode(ValueError):
    pass


def _save10(subtotal):
    return to_cents(subtotal * Decimal("0.10"))


def _fiveoff(subtotal):
    return Decimal("5.00")


_RULES = {"SAVE10": _save10, "FIVEOFF": _fiveoff}


def normalise(code):
    """Return the upper-case form of a known code, or raise InvalidCode."""
    if not isinstance(code, str) or not code.isascii():
        raise InvalidCode(f"unknown discount code: {code!r}")
    key = code.upper()
    if key not in _RULES:
        raise InvalidCode(f"unknown discount code: {code!r}")
    return key


def amount(code, subtotal):
    """Discount in dollars for a normalised code; never more than subtotal."""
    return min(_RULES[code](subtotal), subtotal)

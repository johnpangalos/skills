import unittest
from decimal import Decimal

from shop import discounts
from shop.discounts import InvalidCode


class DiscountsTest(unittest.TestCase):
    def test_invalid_code_is_value_error(self):
        self.assertTrue(issubclass(InvalidCode, ValueError))

    def test_normalise_is_case_insensitive(self):
        self.assertEqual(discounts.normalise("save10"), "SAVE10")
        self.assertEqual(discounts.normalise("Save10"), "SAVE10")
        self.assertEqual(discounts.normalise("fiveoff"), "FIVEOFF")

    def test_normalise_rejects_unknown_codes(self):
        for code in ["", " SAVE10 ", "SAVE10X", "NOPE", "SAVE 10"]:
            with self.subTest(code=code):
                with self.assertRaises(InvalidCode) as ctx:
                    discounts.normalise(code)
                self.assertEqual(str(ctx.exception), f"unknown discount code: {code!r}")

    def test_normalise_rejects_non_strings(self):
        for code in [None, 10, b"SAVE10", ["SAVE10"]]:
            with self.subTest(code=code):
                with self.assertRaises(InvalidCode):
                    discounts.normalise(code)

    def test_normalise_rejects_non_ascii_lookalikes(self):
        # "ſ" (long s) upper-cases to "S", so it must not sneak past the check
        with self.assertRaises(InvalidCode):
            discounts.normalise("ſAVE10")

    def test_save10_rounds_half_up(self):
        self.assertEqual(discounts.amount("SAVE10", Decimal("43.25")), Decimal("4.33"))
        self.assertEqual(discounts.amount("SAVE10", Decimal("0.05")), Decimal("0.01"))

    def test_fiveoff_is_flat(self):
        self.assertEqual(discounts.amount("FIVEOFF", Decimal("43.25")), Decimal("5.00"))

    def test_discount_never_exceeds_subtotal(self):
        self.assertEqual(discounts.amount("FIVEOFF", Decimal("3.00")), Decimal("3.00"))
        self.assertEqual(discounts.amount("FIVEOFF", Decimal("0.00")), Decimal("0.00"))
        self.assertEqual(discounts.amount("SAVE10", Decimal("0.00")), Decimal("0.00"))

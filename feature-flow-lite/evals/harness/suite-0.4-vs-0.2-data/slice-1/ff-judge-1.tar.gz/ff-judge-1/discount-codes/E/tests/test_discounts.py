import unittest
from decimal import Decimal

from shop.cart import Cart
from shop.discounts import InvalidCode, canonical_code, discount_for


class DiscountForTest(unittest.TestCase):
    def test_save10_rounds_half_up(self):
        self.assertEqual(discount_for("SAVE10", Decimal("43.25")), Decimal("4.33"))

    def test_fiveoff_flat(self):
        self.assertEqual(discount_for("FIVEOFF", Decimal("20.00")), Decimal("5.00"))

    def test_capped_at_subtotal(self):
        self.assertEqual(discount_for("FIVEOFF", Decimal("3.50")), Decimal("3.50"))

    def test_empty_subtotal_is_zero(self):
        self.assertEqual(discount_for("FIVEOFF", Decimal("0.00")), Decimal("0.00"))
        self.assertEqual(discount_for("SAVE10", Decimal("0.00")), Decimal("0.00"))

    def test_unknown_code(self):
        with self.assertRaises(InvalidCode) as cm:
            discount_for("NOPE", Decimal("10.00"))
        self.assertEqual(str(cm.exception), "unknown discount code: 'NOPE'")


class CanonicalCodeTest(unittest.TestCase):
    def test_case_insensitive(self):
        for code in ("save10", "Save10", "SAVE10"):
            self.assertEqual(canonical_code(code), "SAVE10")

    def test_whitespace_not_stripped(self):
        with self.assertRaises(InvalidCode) as cm:
            canonical_code(" SAVE10")
        self.assertEqual(str(cm.exception), "unknown discount code: ' SAVE10'")

    def test_unicode_lookalikes_rejected(self):
        for code in ("ſave10", "fıveoff", "ﬁveoff"):
            with self.assertRaises(InvalidCode):
                canonical_code(code)

    def test_empty_string(self):
        with self.assertRaises(InvalidCode) as cm:
            canonical_code("")
        self.assertEqual(str(cm.exception), "unknown discount code: ''")

    def test_none(self):
        with self.assertRaises(InvalidCode) as cm:
            canonical_code(None)
        self.assertEqual(str(cm.exception), "unknown discount code: None")

    def test_non_string(self):
        with self.assertRaises(InvalidCode) as cm:
            canonical_code(10)
        self.assertEqual(str(cm.exception), "unknown discount code: 10")


class CartDiscountTest(unittest.TestCase):
    def test_no_code_no_discount(self):
        cart = Cart()
        cart.add("BEAN-ETH")
        self.assertIsNone(cart.code)
        self.assertEqual(cart.discount(), Decimal("0.00"))

    def test_apply_code_is_case_insensitive(self):
        cart = Cart()
        cart.add("BEAN-ETH")
        cart.apply_code("save10")
        self.assertEqual(cart.code, "SAVE10")

    def test_invalid_code_raises_and_keeps_first(self):
        cart = Cart()
        cart.add("BEAN-ETH", 2)
        cart.apply_code("SAVE10")
        with self.assertRaises(InvalidCode) as cm:
            cart.apply_code("NOPE")
        self.assertEqual(str(cm.exception), "unknown discount code: 'NOPE'")
        self.assertEqual(cart.code, "SAVE10")
        self.assertEqual(cart.discount(), Decimal("3.70"))

    def test_invalid_input_raises_invalid_code(self):
        for bad in ("", None, 10, " SAVE10"):
            cart = Cart()
            with self.assertRaises(InvalidCode):
                cart.apply_code(bad)
            self.assertIsNone(cart.code)

    def test_new_code_replaces_old(self):
        cart = Cart()
        cart.add("BEAN-ETH", 2)
        cart.add("FILTER")
        cart.apply_code("SAVE10")
        cart.apply_code("FIVEOFF")
        self.assertEqual(cart.code, "FIVEOFF")
        self.assertEqual(cart.discount(), Decimal("5.00"))

    def test_same_code_twice_is_noop(self):
        cart = Cart()
        cart.add("BEAN-ETH", 2)
        cart.add("FILTER")
        cart.apply_code("SAVE10")
        cart.apply_code("save10")
        self.assertEqual(cart.code, "SAVE10")
        self.assertEqual(cart.discount(), Decimal("4.33"))

    def test_discount_follows_subtotal(self):
        cart = Cart()
        cart.add("BEAN-ETH")
        cart.apply_code("FIVEOFF")
        cart.remove("BEAN-ETH")
        self.assertEqual(cart.discount(), Decimal("0.00"))
        self.assertEqual(cart.total(), Decimal("0.00"))

    def test_empty_cart_with_code(self):
        cart = Cart()
        cart.apply_code("FIVEOFF")
        self.assertEqual(cart.discount(), Decimal("0.00"))
        self.assertEqual(cart.total(), Decimal("0.00"))

    def test_tax_after_discount_worked_example(self):
        cart = Cart()
        cart.add("BEAN-ETH", 2)
        cart.add("FILTER")
        cart.apply_code("SAVE10")
        self.assertEqual(cart.subtotal(), Decimal("43.25"))
        self.assertEqual(cart.discount(), Decimal("4.33"))
        self.assertEqual(cart.shipping(), Decimal("7.95"))
        self.assertEqual(cart.tax(), Decimal("3.21"))
        self.assertEqual(cart.total(), Decimal("50.08"))

    def test_shipping_uses_pre_discount_subtotal(self):
        cart = Cart()
        cart.add("MUG", 2)
        cart.add("BEAN-ETH")
        cart.add("FILTER", 2)
        cart.apply_code("FIVEOFF")
        self.assertEqual(cart.subtotal(), Decimal("75.00"))
        self.assertEqual(cart.shipping(), Decimal("0.00"))
        self.assertEqual(cart.tax(), Decimal("5.78"))
        self.assertEqual(cart.total(), Decimal("75.78"))

    def test_just_under_threshold_still_pays_shipping(self):
        cart = Cart()
        cart.add("BEAN-ETH")
        cart.add("BEAN-COL", 2)
        cart.add("MUG")
        cart.apply_code("SAVE10")
        self.assertEqual(cart.subtotal(), Decimal("72.50"))
        self.assertEqual(cart.shipping(), Decimal("7.95"))

import unittest
from decimal import Decimal

from shop.discounts import InvalidCode, amount_off, canonical


class CanonicalTest(unittest.TestCase):
    def test_case_and_whitespace_normalized(self):
        self.assertEqual(canonical("save10"), "SAVE10")
        self.assertEqual(canonical("Save10"), "SAVE10")
        self.assertEqual(canonical(" save10 "), "SAVE10")
        self.assertEqual(canonical("fiveoff"), "FIVEOFF")

    def test_unknown_code(self):
        with self.assertRaises(InvalidCode) as ctx:
            canonical("SAVE99")
        self.assertEqual(str(ctx.exception), "unknown discount code: 'SAVE99'")

    def test_invalid_code_is_value_error(self):
        with self.assertRaises(ValueError):
            canonical("nope")

    def test_empty_and_partial_codes_rejected(self):
        for bad in ["", "   ", "SAVE", "SAVE10X"]:
            with self.subTest(code=bad):
                with self.assertRaises(InvalidCode):
                    canonical(bad)

    def test_non_string_rejected(self):
        for bad in [None, 10, b"SAVE10", ["SAVE10"]]:
            with self.subTest(code=bad):
                with self.assertRaises(InvalidCode) as ctx:
                    canonical(bad)
                self.assertIn("must be a string", str(ctx.exception))


class AmountOffTest(unittest.TestCase):
    def test_save10_is_ten_percent_half_up(self):
        self.assertEqual(amount_off("SAVE10", Decimal("43.25")), Decimal("4.33"))

    def test_save10_exact(self):
        self.assertEqual(amount_off("SAVE10", Decimal("40.00")), Decimal("4.00"))

    def test_fiveoff_flat(self):
        self.assertEqual(amount_off("FIVEOFF", Decimal("20.00")), Decimal("5.00"))

    def test_never_exceeds_subtotal(self):
        self.assertEqual(amount_off("FIVEOFF", Decimal("3.00")), Decimal("3.00"))

    def test_empty_subtotal_gives_zero(self):
        self.assertEqual(amount_off("FIVEOFF", Decimal("0.00")), Decimal("0.00"))
        self.assertEqual(amount_off("SAVE10", Decimal("0.00")), Decimal("0.00"))

import unittest
from decimal import Decimal

from shop.discounts import InvalidCode, canonical_code, discount_for


class DiscountTest(unittest.TestCase):
    def test_save10_rounds_half_up(self):
        self.assertEqual(discount_for("SAVE10", Decimal("43.25")), Decimal("4.33"))

    def test_fiveoff_is_flat(self):
        self.assertEqual(discount_for("FIVEOFF", Decimal("20.00")), Decimal("5.00"))

    def test_fiveoff_capped_at_subtotal(self):
        self.assertEqual(discount_for("FIVEOFF", Decimal("3.00")), Decimal("3.00"))

    def test_empty_subtotal_gets_nothing(self):
        for code in ("SAVE10", "FIVEOFF"):
            self.assertEqual(discount_for(code, Decimal("0.00")), Decimal("0.00"))

    def test_canonical_code_ignores_case_and_whitespace(self):
        for raw in ("save10", "Save10", "SAVE10", "  SAVE10\n"):
            self.assertEqual(canonical_code(raw), "SAVE10")

    def test_unicode_look_alikes_rejected(self):
        for raw in ("\u017fave10", "\ufb01veoff", "F\u0131VEOFF", "\uff33\uff21\uff36\uff25\uff11\uff10"):
            with self.assertRaises(InvalidCode):
                canonical_code(raw)

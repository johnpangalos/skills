"""Money helpers. Amounts are Decimal dollars."""

from decimal import ROUND_HALF_UP, Decimal

CENT = Decimal("0.01")


def to_cents(amount):
    """Round to whole cents, half-up."""
    return Decimal(amount).quantize(CENT, rounding=ROUND_HALF_UP)


def format_money(amount):
    """Format as dollars, e.g. $1,234.50 or -$4.33."""
    value = to_cents(amount)
    sign = "-" if value.is_signed() else ""
    return f"{sign}${abs(value):,.2f}"

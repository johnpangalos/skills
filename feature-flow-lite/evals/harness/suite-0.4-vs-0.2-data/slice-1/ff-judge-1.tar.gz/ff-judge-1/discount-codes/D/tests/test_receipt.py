import unittest

from shop.cart import Cart
from shop.receipt import render


class ReceiptTest(unittest.TestCase):
    def test_render(self):
        cart = Cart()
        cart.add("BEAN-COL", 2)
        lines = render(cart).splitlines()
        self.assertEqual(lines[0], "2 x Colombia Huila, 250 g" + "$32.00".rjust(15))
        self.assertTrue(lines[-1].startswith("Total"))
        self.assertTrue(lines[-1].endswith("$42.59"))

    def test_render_without_code_has_no_discount_row(self):
        cart = Cart()
        cart.add("BEAN-ETH", 2)
        cart.add("FILTER")
        self.assertNotIn("Discount", render(cart))

    def test_render_with_code(self):
        cart = Cart()
        cart.add("BEAN-ETH", 2)
        cart.add("FILTER")
        cart.apply_code("save10")
        lines = render(cart).splitlines()
        self.assertEqual(lines[3], "Subtotal" + "$43.25".rjust(32))
        self.assertEqual(lines[4], "Discount (SAVE10)" + "-$4.33".rjust(23))
        self.assertEqual(lines[5], "Shipping" + "$7.95".rjust(32))
        self.assertEqual(lines[7], "Total" + "$50.08".rjust(35))

    def test_render_fiveoff(self):
        cart = Cart()
        cart.add("FILTER")
        cart.apply_code("FIVEOFF")
        lines = render(cart).splitlines()
        self.assertEqual(lines[3], "Discount (FIVEOFF)" + "-$5.00".rjust(22))

    def test_render_large_discount_has_comma(self):
        cart = Cart()
        cart.add("MUG", 500)
        cart.apply_code("SAVE10")
        lines = render(cart).splitlines()
        self.assertEqual(lines[3], "Discount (SAVE10)" + "-$1,100.00".rjust(23))

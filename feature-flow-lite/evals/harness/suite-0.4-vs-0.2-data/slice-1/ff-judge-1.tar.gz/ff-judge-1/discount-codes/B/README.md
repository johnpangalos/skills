# shop

Checkout logic for a small online coffee shop: catalog, cart totals, receipts,
and password-reset tokens. Standard library only.

    ./check.sh        # lint + unit tests (run before every commit)

Money is `Decimal` dollars, rounded to cents half-up (`shop/money.py`).
Shipping is a flat $7.95, free once the merchandise subtotal reaches $75.
Sales tax is 8.25% of merchandise only; shipping is not taxed.

Discount codes (`shop/discounts.py`) are entered with `Cart.apply_code`, are
case-insensitive, and ignore surrounding whitespace. Only one code applies at a
time; applying a new code replaces the old one. Codes:

- `SAVE10`: 10% off the merchandise subtotal, rounded half-up to cents.
- `FIVEOFF`: $5.00 off the merchandise subtotal.

A discount is capped at the merchandise subtotal, so it never makes a total
negative. Tax is charged on the subtotal after the discount. The free-shipping
threshold ($75) is checked against the subtotal before the discount. Receipts
show the discount as a `Discount (CODE)` row between Subtotal and Shipping.

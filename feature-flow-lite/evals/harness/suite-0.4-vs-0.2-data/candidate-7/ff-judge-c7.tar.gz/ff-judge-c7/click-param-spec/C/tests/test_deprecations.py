import importlib.metadata
import subprocess
import sys
import types
import warnings
from abc import ABCMeta

import pytest

import click
import click.core
import click.parser
import click.shell_completion
import click.utils


@pytest.mark.parametrize(
    ("module", "name", "target"),
    [
        # Stream helpers, re-exported from both `click` and `click.utils`.
        (click, "get_binary_stream", click.utils._get_binary_stream),
        (click, "get_text_stream", click.utils._get_text_stream),
        (click.utils, "get_binary_stream", click.utils._get_binary_stream),
        (click.utils, "get_text_stream", click.utils._get_text_stream),
        # Command-class aliases, re-exported from `click` and `click.core`.
        (click, "BaseCommand", click.core._BaseCommand),
        (click, "MultiCommand", click.core._MultiCommand),
        (click.core, "BaseCommand", click.core._BaseCommand),
        (click.core, "MultiCommand", click.core._MultiCommand),
        # Old parser API (moved to `optparse`); `OptionParser` is also
        # re-exported from the top-level `click` namespace.
        (click, "OptionParser", click.parser._OptionParser),
        (click.parser, "OptionParser", click.parser._OptionParser),
        (click.parser, "Argument", click.parser._Argument),
        (click.parser, "Option", click.parser._Option),
        (click.parser, "split_opt", click.parser._split_opt),
        (click.parser, "normalize_opt", click.parser._normalize_opt),
        (click.parser, "ParsingState", click.parser._ParsingState),
        (click.parser, "split_arg_string", click.shell_completion.split_arg_string),
        # Deprecated `click.utils` utilities.
        (click.utils, "LazyFile", click.utils._LazyFile),
        (click.utils, "KeepOpenFile", click.utils._KeepOpenFile),
        (click.utils, "make_default_short_help", click.utils._make_default_short_help),
        (click.utils, "PacifyFlushWrapper", click.utils._PacifyFlushWrapper),
        (click.utils, "safecall", click.utils._safecall),
        # Version metadata attribute.
        (click, "__version__", importlib.metadata.version("click")),
    ],
    ids=lambda v: getattr(v, "__name__", v),
)
def test_attr_deprecated(module, name, target):
    with pytest.warns(DeprecationWarning, match=name):
        value = getattr(module, name)

    assert value == target


@pytest.mark.parametrize(
    "module",
    [click, click.core, click.parser, click.utils],
    ids=lambda m: m.__name__,
)
def test_unknown_attribute_raises(module):
    with pytest.raises(AttributeError, match="no_such_attribute"):
        _ = module.no_such_attribute


def test_context_protected_args_deprecated():
    ctx = click.Context(click.Command("cli"))

    with pytest.warns(DeprecationWarning, match="protected_args"):
        assert ctx.protected_args == []


def test_isolated_filesystem_deprecated(runner):
    with pytest.warns(DeprecationWarning, match="isolated_filesystem"):
        with runner.isolated_filesystem():
            pass


@pytest.mark.parametrize(
    ("make_param", "match"),
    [
        pytest.param(
            lambda: click.Argument(["0foo"]),
            "not a valid Python identifier",
            id="argument-leading-digit",
        ),
        pytest.param(
            lambda: click.Argument(["foo.bar"]),
            "not a valid Python identifier",
            id="argument-dot",
        ),
        pytest.param(
            lambda: click.Argument(["foo bar"]),
            "not a valid Python identifier",
            id="argument-space",
        ),
        pytest.param(
            lambda: click.Argument([""]),
            "not a valid Python identifier",
            id="argument-empty-decl",
        ),
        pytest.param(
            lambda: click.Argument(["0foo"], expose_value=False),
            "not a valid Python identifier",
            id="argument-unexposed",
        ),
        pytest.param(
            lambda: click.Argument([], expose_value=False),
            "not a valid Python identifier",
            id="argument-no-decl",
        ),
        pytest.param(
            lambda: click.Option(["--0foo"], expose_value=False),
            "not a valid Python identifier",
            id="option-unexposed",
        ),
        pytest.param(
            lambda: click.Option([], expose_value=False),
            "not a valid Python identifier",
            id="option-no-decl",
        ),
        # A keyword is an identifier too, so this rule alone reports it.
        pytest.param(
            lambda: click.Option(["--from"]),
            "is a Python keyword",
            id="option-from",
        ),
        pytest.param(
            lambda: click.Option(["--import"]),
            "is a Python keyword",
            id="option-import",
        ),
        pytest.param(
            lambda: click.Argument(["class"]),
            "is a Python keyword",
            id="argument-class",
        ),
    ],
)
def test_unusable_name_deprecated(make_param, match):
    """A name Click 9.0 refuses reports which of its two rules it broke."""
    with pytest.warns(DeprecationWarning, match=match):
        make_param()


@pytest.mark.parametrize(
    "make_param",
    [
        pytest.param(lambda: click.Argument(["foo-bar"]), id="argument-hyphen"),
        pytest.param(lambda: click.Argument(["Foo_Bar"]), id="argument-case"),
        pytest.param(lambda: click.Option(["--foo-bar"]), id="option-hyphen"),
        pytest.param(
            lambda: click.Option(["--0foo", "zero_foo"]), id="option-explicit-name"
        ),
        # Soft keywords are contextual and name a parameter fine.
        pytest.param(lambda: click.Option(["--match"]), id="soft-keyword-match"),
        pytest.param(lambda: click.Argument(["type"]), id="soft-keyword-type"),
        # These lower case out of the keyword set.
        pytest.param(lambda: click.Option(["--True"]), id="true"),
        pytest.param(lambda: click.Option(["--None"]), id="none"),
    ],
)
def test_usable_name_not_deprecated(recwarn, make_param):
    """A name a callback can declare keeps working, and says nothing."""
    make_param()
    assert [w for w in recwarn if issubclass(w.category, DeprecationWarning)] == []


@pytest.mark.parametrize(
    "make_param",
    [
        pytest.param(lambda: click.Option(["--from"]), id="keyword"),
        pytest.param(lambda: click.Argument(["0foo"]), id="non-identifier"),
    ],
)
def test_unusable_name_names_the_release_that_refuses_it(make_param):
    """Both refusals name the release that turns the warning into an error."""
    match = r"will raise a TypeError in Click 9\.0"
    with pytest.warns(DeprecationWarning, match=match):
        make_param()


@pytest.mark.parametrize(
    ("decl", "expect"),
    [
        pytest.param("Foo_Bar", "foo_bar", id="mixed-case"),
        pytest.param("X_Y", "x_y", id="upper-case"),
        pytest.param("ΟΔΟΣ", "οδος", id="final-sigma"),
        pytest.param("\N{KELVIN SIGN}", "k", id="kelvin-sign"),
    ],
)
def test_unnormalized_explicit_name_deprecated(decl, expect):
    """Click 9.0 lower cases an explicit name like any other declaration."""
    with pytest.warns(DeprecationWarning, match="lower cases an explicit name"):
        param = click.Option(["--x", decl])

    assert param.name == decl
    assert decl.lower() == expect


@pytest.mark.parametrize(
    "decls",
    [
        pytest.param(["--x", "foo_bar"], id="already-lower"),
        pytest.param(["--x", "_from"], id="leading-underscore"),
        pytest.param(["--Foo-Bar"], id="derived-not-explicit"),
        pytest.param(["--x", "café"], id="lower-case-non-ascii"),
    ],
)
def test_normalized_explicit_name_not_deprecated(recwarn, decls):
    """A name already spelled the way 9.0 spells it says nothing."""
    click.Option(decls)
    assert [w for w in recwarn if issubclass(w.category, DeprecationWarning)] == []


def test_unnormalized_name_on_a_refused_option_is_silent():
    """An option that cannot be built at all warns about nothing."""
    with pytest.raises(TypeError, match="No options defined"):
        with warnings.catch_warnings():
            warnings.simplefilter("error", DeprecationWarning)
            click.Option(["Foo_Bar"])


def test_deprecated_required_option_names_its_spec():
    with pytest.raises(ValueError) as excinfo:
        click.Option(["-f", "--foo"], required=True, deprecated=True)

    assert str(excinfo.value) == (
        "The option '--foo' is deprecated and still required. A deprecated"
        " option cannot be required."
    )


@pytest.mark.parametrize(
    ("make_param", "expected"),
    [
        pytest.param(lambda: click.Option(["-t", "--times"]), "--times", id="option"),
        pytest.param(lambda: click.Argument(["filename"]), "FILENAME", id="argument"),
        pytest.param(
            lambda: click.Argument(["x"], metavar="SRC"), "SRC", id="argument-metavar"
        ),
    ],
)
def test_human_readable_name_deprecated(make_param, expected):
    """The old property still answers with the spec, and warns once at the caller."""
    param = make_param()

    with pytest.warns(DeprecationWarning) as record:
        value = param.human_readable_name

    assert value == expected
    assert len(record) == 1
    assert str(record[0].message) == (
        "'human_readable_name' is deprecated and will be removed in Click 9.0."
        " Use 'spec' instead."
    )
    assert record[0].filename == __file__


@pytest.mark.parametrize("base", [click.Parameter, click.Option, click.Argument])
def test_subclass_overriding_human_readable_name_warns_at_definition(base):
    with pytest.warns(DeprecationWarning) as record:
        cls = type("MyParam", (base,), {"human_readable_name": property(lambda s: "x")})

    assert len(record) == 1
    assert str(record[0].message) == (
        "MyParam overrides 'human_readable_name', which is deprecated and will be"
        " removed in Click 9.0. Override 'spec' instead."
    )
    assert record[0].filename == __file__
    assert cls.__name__ == "MyParam"


def _deprecation_warnings(make):
    with warnings.catch_warnings(record=True) as caught:
        warnings.simplefilter("always")
        make()

    return [w for w in caught if issubclass(w.category, DeprecationWarning)]


def test_subclass_not_overriding_human_readable_name_is_silent():
    class Quiet(click.Option):
        pass

    assert _deprecation_warnings(lambda: type("Quieter", (Quiet,), {})) == []


def test_subclass_of_overriding_subclass_does_not_warn_again():
    with pytest.warns(DeprecationWarning):

        class Parent(click.Argument):
            @property
            def human_readable_name(self):
                return "x"

    assert _deprecation_warnings(lambda: type("Child", (Parent,), {})) == []


def test_importing_click_is_silent():
    result = subprocess.run(
        [sys.executable, "-W", "error::DeprecationWarning", "-c", "import click"],
        capture_output=True,
        text=True,
    )

    assert result.returncode == 0, result.stderr
    assert result.stderr == ""


def test_click_never_reads_human_readable_name(runner):
    """Click reads ``spec``, so none of its own paths trips the deprecation."""

    @click.command()
    @click.argument("filename")
    @click.option("--old", deprecated=True, is_flag=True)
    @click.option("-t", "--times", type=click.Choice(["1", "2"]), required=True)
    def cli(filename, old, times):
        click.echo(f"{filename} {times}")

    cases = [
        (["index.txt", "-t", "1"], 0),
        (["index.txt", "-t", "1", "--old"], 0),
        (["index.txt"], 2),
        (["index.txt", "-t", "1", "--nope"], 2),
        (["index.txt", "-t", "nope"], 2),
        (["--help"], 0),
    ]

    ctx = click.Context(cli)

    with warnings.catch_warnings():
        warnings.simplefilter("error", DeprecationWarning)

        for args, exit_code in cases:
            result = runner.invoke(cli, args)
            assert result.exit_code == exit_code, result.output
            assert result.exception is None or isinstance(result.exception, SystemExit)

        for param in cli.params:
            assert param.shell_complete(ctx, "-") is not None

        cli.to_info_dict(ctx)


class _Meta(ABCMeta):
    def __new__(mcls, name, bases, namespace, **kwargs):
        return super().__new__(mcls, name, bases, namespace, **kwargs)


class _Meta2(_Meta):
    def __new__(mcls, name, bases, namespace, **kwargs):
        return super().__new__(mcls, name, bases, namespace, **kwargs)


class _DelFirstArgMeta(ABCMeta):
    def __new__(mcls, name, bases, namespace):
        del mcls
        return ABCMeta.__new__(ABCMeta, name, bases, namespace)


class _VarArgsMeta(ABCMeta):
    def __new__(*args, **kwargs):
        return ABCMeta.__new__(*args, **kwargs)


class _UserBase(click.Option):
    def __init_subclass__(cls, **kwargs):
        super().__init_subclass__(**kwargs)


def _body(namespace):
    namespace["human_readable_name"] = property(lambda s: "x")


def _marked_line(marker):
    """Number of the one line in this file that ends with ``marker``."""
    with open(__file__, encoding="utf-8") as f:
        lines = [n for n, text in enumerate(f, 1) if text.rstrip().endswith(marker)]

    assert len(lines) == 1, lines
    return lines[0]


@pytest.mark.parametrize("metaclass", [_Meta, _Meta2])
def test_metaclass_overriding_human_readable_name_warns_at_class_statement(metaclass):
    with pytest.warns(DeprecationWarning) as record:

        class Sub(click.Parameter, metaclass=metaclass):  # line: metaclass
            human_readable_name = property(lambda s: "x")

    assert len(record) == 1
    assert record[0].filename == __file__
    assert record[0].lineno == _marked_line("# line: metaclass")


def test_metaclass_deleting_first_argument_warns_at_class_statement():
    with pytest.warns(DeprecationWarning) as record:

        class Sub(click.Parameter, metaclass=_DelFirstArgMeta):  # line: del-arg
            human_readable_name = property(lambda s: "x")

    assert len(record) == 1
    assert record[0].filename == __file__
    assert record[0].lineno == _marked_line("# line: del-arg")


def test_metaclass_with_varargs_new_warns_at_class_statement():
    with pytest.warns(DeprecationWarning) as record:

        class Sub(click.Parameter, metaclass=_VarArgsMeta):  # line: varargs
            human_readable_name = property(lambda s: "x")

    assert len(record) == 1
    assert record[0].filename == __file__
    assert record[0].lineno == _marked_line("# line: varargs")


def test_user_base_calling_super_init_subclass_warns_at_class_statement():
    with pytest.warns(DeprecationWarning) as record:

        class Sub(_UserBase):  # line: user-base
            human_readable_name = property(lambda s: "x")

    assert len(record) == 1
    assert record[0].filename == __file__
    assert record[0].lineno == _marked_line("# line: user-base")


def test_types_new_class_overriding_human_readable_name_warns_at_call():
    with pytest.warns(DeprecationWarning) as record:
        types.new_class("Sub", (click.Option,), exec_body=_body)  # line: new-class

    assert len(record) == 1
    assert record[0].filename == __file__
    assert record[0].lineno == _marked_line("# line: new-class")


def test_class_statement_overriding_human_readable_name_warns_at_class_statement():
    with pytest.warns(DeprecationWarning) as record:

        class Sub(click.Option):  # line: class-stmt
            human_readable_name = property(lambda s: "x")

    assert record[0].filename == __file__
    assert record[0].lineno == _marked_line("# line: class-stmt")


def test_type_call_overriding_human_readable_name_warns_at_type_call():
    attrs = {"human_readable_name": property(lambda s: "x")}

    with pytest.warns(DeprecationWarning) as record:
        type("Sub", (click.Option,), attrs)  # line: type-call

    assert record[0].filename == __file__
    assert record[0].lineno == _marked_line("# line: type-call")

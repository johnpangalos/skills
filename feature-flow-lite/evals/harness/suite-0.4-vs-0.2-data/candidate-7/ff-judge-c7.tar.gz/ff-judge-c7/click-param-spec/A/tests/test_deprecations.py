import abc
import importlib.metadata
import subprocess
import sys
import warnings

import pytest

import click
import click.core
import click.parser
import click.shell_completion
import click.utils


@pytest.mark.parametrize(
    ("module", "name", "target"),
    [
        # Stream helpers, re-exported from both `click` and `click.utils`.
        (click, "get_binary_stream", click.utils._get_binary_stream),
        (click, "get_text_stream", click.utils._get_text_stream),
        (click.utils, "get_binary_stream", click.utils._get_binary_stream),
        (click.utils, "get_text_stream", click.utils._get_text_stream),
        # Command-class aliases, re-exported from `click` and `click.core`.
        (click, "BaseCommand", click.core._BaseCommand),
        (click, "MultiCommand", click.core._MultiCommand),
        (click.core, "BaseCommand", click.core._BaseCommand),
        (click.core, "MultiCommand", click.core._MultiCommand),
        # Old parser API (moved to `optparse`); `OptionParser` is also
        # re-exported from the top-level `click` namespace.
        (click, "OptionParser", click.parser._OptionParser),
        (click.parser, "OptionParser", click.parser._OptionParser),
        (click.parser, "Argument", click.parser._Argument),
        (click.parser, "Option", click.parser._Option),
        (click.parser, "split_opt", click.parser._split_opt),
        (click.parser, "normalize_opt", click.parser._normalize_opt),
        (click.parser, "ParsingState", click.parser._ParsingState),
        (click.parser, "split_arg_string", click.shell_completion.split_arg_string),
        # Deprecated `click.utils` utilities.
        (click.utils, "LazyFile", click.utils._LazyFile),
        (click.utils, "KeepOpenFile", click.utils._KeepOpenFile),
        (click.utils, "make_default_short_help", click.utils._make_default_short_help),
        (click.utils, "PacifyFlushWrapper", click.utils._PacifyFlushWrapper),
        (click.utils, "safecall", click.utils._safecall),
        # Version metadata attribute.
        (click, "__version__", importlib.metadata.version("click")),
    ],
    ids=lambda v: getattr(v, "__name__", v),
)
def test_attr_deprecated(module, name, target):
    with pytest.warns(DeprecationWarning, match=name):
        value = getattr(module, name)

    assert value == target


@pytest.mark.parametrize(
    "module",
    [click, click.core, click.parser, click.utils],
    ids=lambda m: m.__name__,
)
def test_unknown_attribute_raises(module):
    with pytest.raises(AttributeError, match="no_such_attribute"):
        _ = module.no_such_attribute


def test_context_protected_args_deprecated():
    ctx = click.Context(click.Command("cli"))

    with pytest.warns(DeprecationWarning, match="protected_args"):
        assert ctx.protected_args == []


def test_isolated_filesystem_deprecated(runner):
    with pytest.warns(DeprecationWarning, match="isolated_filesystem"):
        with runner.isolated_filesystem():
            pass


@pytest.mark.parametrize(
    ("make_param", "match"),
    [
        pytest.param(
            lambda: click.Argument(["0foo"]),
            "not a valid Python identifier",
            id="argument-leading-digit",
        ),
        pytest.param(
            lambda: click.Argument(["foo.bar"]),
            "not a valid Python identifier",
            id="argument-dot",
        ),
        pytest.param(
            lambda: click.Argument(["foo bar"]),
            "not a valid Python identifier",
            id="argument-space",
        ),
        pytest.param(
            lambda: click.Argument([""]),
            "not a valid Python identifier",
            id="argument-empty-decl",
        ),
        pytest.param(
            lambda: click.Argument(["0foo"], expose_value=False),
            "not a valid Python identifier",
            id="argument-unexposed",
        ),
        pytest.param(
            lambda: click.Argument([], expose_value=False),
            "not a valid Python identifier",
            id="argument-no-decl",
        ),
        pytest.param(
            lambda: click.Option(["--0foo"], expose_value=False),
            "not a valid Python identifier",
            id="option-unexposed",
        ),
        pytest.param(
            lambda: click.Option([], expose_value=False),
            "not a valid Python identifier",
            id="option-no-decl",
        ),
        # A keyword is an identifier too, so this rule alone reports it.
        pytest.param(
            lambda: click.Option(["--from"]),
            "is a Python keyword",
            id="option-from",
        ),
        pytest.param(
            lambda: click.Option(["--import"]),
            "is a Python keyword",
            id="option-import",
        ),
        pytest.param(
            lambda: click.Argument(["class"]),
            "is a Python keyword",
            id="argument-class",
        ),
    ],
)
def test_unusable_name_deprecated(make_param, match):
    """A name Click 9.0 refuses reports which of its two rules it broke."""
    with pytest.warns(DeprecationWarning, match=match):
        make_param()


@pytest.mark.parametrize(
    "make_param",
    [
        pytest.param(lambda: click.Argument(["foo-bar"]), id="argument-hyphen"),
        pytest.param(lambda: click.Argument(["Foo_Bar"]), id="argument-case"),
        pytest.param(lambda: click.Option(["--foo-bar"]), id="option-hyphen"),
        pytest.param(
            lambda: click.Option(["--0foo", "zero_foo"]), id="option-explicit-name"
        ),
        # Soft keywords are contextual and name a parameter fine.
        pytest.param(lambda: click.Option(["--match"]), id="soft-keyword-match"),
        pytest.param(lambda: click.Argument(["type"]), id="soft-keyword-type"),
        # These lower case out of the keyword set.
        pytest.param(lambda: click.Option(["--True"]), id="true"),
        pytest.param(lambda: click.Option(["--None"]), id="none"),
    ],
)
def test_usable_name_not_deprecated(recwarn, make_param):
    """A name a callback can declare keeps working, and says nothing."""
    make_param()
    assert [w for w in recwarn if issubclass(w.category, DeprecationWarning)] == []


@pytest.mark.parametrize(
    "make_param",
    [
        pytest.param(lambda: click.Option(["--from"]), id="keyword"),
        pytest.param(lambda: click.Argument(["0foo"]), id="non-identifier"),
    ],
)
def test_unusable_name_names_the_release_that_refuses_it(make_param):
    """Both refusals name the release that turns the warning into an error."""
    match = r"will raise a TypeError in Click 9\.0"
    with pytest.warns(DeprecationWarning, match=match):
        make_param()


@pytest.mark.parametrize(
    ("decl", "expect"),
    [
        pytest.param("Foo_Bar", "foo_bar", id="mixed-case"),
        pytest.param("X_Y", "x_y", id="upper-case"),
        pytest.param("ΟΔΟΣ", "οδος", id="final-sigma"),
        pytest.param("\N{KELVIN SIGN}", "k", id="kelvin-sign"),
    ],
)
def test_unnormalized_explicit_name_deprecated(decl, expect):
    """Click 9.0 lower cases an explicit name like any other declaration."""
    with pytest.warns(DeprecationWarning, match="lower cases an explicit name"):
        param = click.Option(["--x", decl])

    assert param.name == decl
    assert decl.lower() == expect


@pytest.mark.parametrize(
    "decls",
    [
        pytest.param(["--x", "foo_bar"], id="already-lower"),
        pytest.param(["--x", "_from"], id="leading-underscore"),
        pytest.param(["--Foo-Bar"], id="derived-not-explicit"),
        pytest.param(["--x", "café"], id="lower-case-non-ascii"),
    ],
)
def test_normalized_explicit_name_not_deprecated(recwarn, decls):
    """A name already spelled the way 9.0 spells it says nothing."""
    click.Option(decls)
    assert [w for w in recwarn if issubclass(w.category, DeprecationWarning)] == []


def test_unnormalized_name_on_a_refused_option_is_silent():
    """An option that cannot be built at all warns about nothing."""
    with pytest.raises(TypeError, match="No options defined"):
        with warnings.catch_warnings():
            warnings.simplefilter("error", DeprecationWarning)
            click.Option(["Foo_Bar"])


@pytest.mark.parametrize(
    ("make_param", "expected"),
    [
        pytest.param(lambda: click.Option(["-t", "--times"]), "--times", id="option"),
        pytest.param(
            lambda: click.Argument(["filename"], metavar="SRC"), "SRC", id="argument"
        ),
    ],
)
def test_human_readable_name_access_warns_and_returns_spec(make_param, expected):
    """Reading the old name warns once, names spec as the replacement, and returns
    spec. The warning points at the caller's line.
    """
    param = make_param()

    with pytest.warns(DeprecationWarning) as record:
        value = param.human_readable_name

    warns = [w for w in record if issubclass(w.category, DeprecationWarning)]
    assert value == expected == param.spec
    assert len(warns) == 1
    assert str(warns[0].message) == (
        "'human_readable_name' is deprecated and will be removed in Click 9.0."
        " Use 'spec' instead."
    )
    assert warns[0].filename == __file__


@pytest.mark.parametrize(
    "base",
    [
        pytest.param(click.Parameter, id="parameter"),
        pytest.param(click.Option, id="option"),
        pytest.param(click.Argument, id="argument"),
    ],
)
def test_subclass_defining_human_readable_name_warns_at_definition(base):
    """Defining the old name in a subclass warns at the class statement, naming the
    class and telling the author to override spec.
    """
    with pytest.warns(DeprecationWarning) as record:

        class MyParam(base):
            @property
            def human_readable_name(self) -> str:
                return "legacy"

    warns = [w for w in record if issubclass(w.category, DeprecationWarning)]
    assert len(warns) == 1
    assert str(warns[0].message) == (
        "MyParam defines 'human_readable_name', which is deprecated and will be"
        " removed in Click 9.0. Override 'spec' instead."
    )
    assert warns[0].filename == __file__


def test_human_readable_name_is_a_property_on_parameter():
    """The old name stays a real attribute, so tools and super() can find it."""
    assert hasattr(click.Parameter, "human_readable_name")
    assert isinstance(click.Parameter.__dict__["human_readable_name"], property)


def test_subclass_overriding_human_readable_name_calls_super():
    """An override that calls super() keeps working: the definition warns once, and
    the super() access warns and returns spec.
    """
    line = sys._getframe().f_lineno + 3
    with pytest.warns(DeprecationWarning) as record:

        class Prefixed(click.Option):
            @property
            def human_readable_name(self) -> str:
                return "X-" + super().human_readable_name

    definitions = [w for w in record if issubclass(w.category, DeprecationWarning)]
    assert len(definitions) == 1
    assert definitions[0].filename == __file__
    assert definitions[0].lineno == line

    option = Prefixed(["--times"])

    with pytest.warns(DeprecationWarning, match="'human_readable_name'") as access:
        value = option.human_readable_name

    assert value == "X-" + option.spec == "X---times"
    assert access[0].filename == __file__


def test_subclass_with_own_metaclass_warns_at_its_class_statement():
    class Meta(abc.ABCMeta):
        pass

    line = sys._getframe().f_lineno + 3
    with pytest.warns(DeprecationWarning) as record:

        class MetaParam(click.Option, metaclass=Meta):
            @property
            def human_readable_name(self) -> str:
                return "legacy"

    definitions = [w for w in record if issubclass(w.category, DeprecationWarning)]
    assert len(definitions) == 1
    assert definitions[0].filename == __file__
    assert definitions[0].lineno == line


def test_subclass_with_metaclass_defining_new_warns_at_its_class_statement():
    class Meta(abc.ABCMeta):
        def __new__(mcls, *args, **kwargs):
            return super().__new__(mcls, *args, **kwargs)

    line = sys._getframe().f_lineno + 3
    with pytest.warns(DeprecationWarning) as record:

        class MetaParam(click.Option, metaclass=Meta):
            human_readable_name = property(lambda self: "x")

    definitions = [w for w in record if issubclass(w.category, DeprecationWarning)]
    assert len(definitions) == 1
    assert definitions[0].filename == __file__
    assert definitions[0].lineno == line


def test_subclass_created_by_type_warns_at_the_type_call():
    line = sys._getframe().f_lineno + 2
    with pytest.warns(DeprecationWarning) as record:
        type(
            "Dynamic", (click.Option,), {"human_readable_name": property(lambda s: "x")}
        )

    definitions = [w for w in record if issubclass(w.category, DeprecationWarning)]
    assert len(definitions) == 1
    assert definitions[0].filename == __file__
    assert definitions[0].lineno == line


def test_subclass_of_a_defining_subclass_does_not_warn_again():
    with pytest.warns(DeprecationWarning):

        class Legacy(click.Option):
            @property
            def human_readable_name(self) -> str:
                return "legacy"

    with warnings.catch_warnings(record=True) as record:
        warnings.simplefilter("always")

        class Child(Legacy):
            pass

    assert [w for w in record if issubclass(w.category, DeprecationWarning)] == []


def test_subclass_overriding_spec_is_silent_and_drives_messages(runner):
    with warnings.catch_warnings(record=True) as record:
        warnings.simplefilter("always")

        class Custom(click.Option):
            @property
            def spec(self) -> str:
                return "--custom"

    assert [w for w in record if issubclass(w.category, DeprecationWarning)] == []

    option = Custom(["--my-option"], is_flag=True, deprecated=True)
    cli = click.Command("cli", params=[option], callback=lambda **kwargs: None)
    result = runner.invoke(cli, ["--my-option"])
    assert result.exit_code == 0
    assert result.output == (
        "DeprecationWarning: The option '--custom' is deprecated.\n"
    )

    with pytest.raises(ValueError, match="The option '--custom' is deprecated"):
        Custom(["--my-option"], required=True, deprecated=True)


def test_click_messages_ignore_a_subclass_human_readable_name(runner):
    with pytest.warns(DeprecationWarning):

        class Legacy(click.Option):
            @property
            def human_readable_name(self) -> str:
                return "BOGUS"

    option = Legacy(["--old"], is_flag=True, deprecated=True)
    cli = click.Command("cli", params=[option], callback=lambda **kwargs: None)
    result = runner.invoke(cli, ["--old"])
    assert result.output == "DeprecationWarning: The option '--old' is deprecated.\n"


def test_import_click_emits_no_warning():
    result = subprocess.run(
        [sys.executable, "-W", "error", "-c", "import click"],
        capture_output=True,
        text=True,
        check=False,
    )
    assert result.returncode == 0, result.stderr


@click.command("cli")
@click.option("--count", type=click.INT)
@click.option("--old", is_flag=True, deprecated=True)
@click.option("-m", "--my-option", is_flag=True, deprecated=True)
@click.argument("filename")
@click.argument("legacy", required=False, deprecated=True)
@click.argument("number", type=click.INT, required=False)
def _every_message_cli(count, old, my_option, filename, legacy, number):
    click.echo(filename)


@pytest.mark.parametrize(
    ("args", "exit_code", "expect"),
    [
        pytest.param(
            ["--old", "a.txt"],
            0,
            "DeprecationWarning: The option '--old' is deprecated.\na.txt\n",
            id="deprecated-option",
        ),
        pytest.param(
            ["-m", "a.txt"],
            0,
            "DeprecationWarning: The option '--my-option' is deprecated.\na.txt\n",
            id="deprecated-option-with-short",
        ),
        pytest.param(
            ["a.txt", "1"],
            0,
            "DeprecationWarning: The argument 'LEGACY' is deprecated.\na.txt\n",
            id="deprecated-argument",
        ),
        pytest.param(
            [],
            2,
            "Error: Missing argument 'FILENAME'.\n",
            id="missing-argument",
        ),
        pytest.param(
            ["--count", "x", "a.txt"],
            2,
            "Error: Invalid value for '--count': 'x' is not a valid integer.\n",
            id="bad-option-value",
        ),
        pytest.param(
            ["a.txt", "1", "x"],
            2,
            "DeprecationWarning: The argument 'LEGACY' is deprecated.\n"
            "Usage: cli [OPTIONS] FILENAME [LEGACY!] [NUMBER]\n"
            "Try 'cli --help' for help.\n\n"
            "Error: Invalid value for '[NUMBER]': 'x' is not a valid integer.\n",
            id="bad-argument-value",
        ),
    ],
)
def test_click_messages_never_read_human_readable_name(runner, args, exit_code, expect):
    """Every message path runs with DeprecationWarning as an error: any read of the
    old name would raise instead of printing the message.
    """
    with warnings.catch_warnings():
        warnings.simplefilter("error", DeprecationWarning)
        result = runner.invoke(_every_message_cli, args)

    assert result.exit_code == exit_code
    assert result.output.endswith(expect)


def test_click_help_and_completion_never_read_human_readable_name(runner):
    ctx = click.Context(_every_message_cli)

    with warnings.catch_warnings():
        warnings.simplefilter("error", DeprecationWarning)
        result = runner.invoke(_every_message_cli, ["--help"])
        completions = [
            item.value for item in _every_message_cli.shell_complete(ctx, "--")
        ]

    assert result.exit_code == 0
    assert "  -m, --my-option  (DEPRECATED)" in result.output
    assert "--my-option" in completions


def test_required_deprecated_construction_raises_value_error_not_warning():
    with warnings.catch_warnings():
        warnings.simplefilter("error", DeprecationWarning)

        with pytest.raises(ValueError, match="is deprecated and still required"):
            click.Argument(["filename"], required=True, deprecated=True)

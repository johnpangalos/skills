import random
import unittest
from decimal import Decimal

from shop import discounts
from shop.cart import Cart
from shop.catalog import PRODUCTS
from shop.discounts import InvalidCode, canonical_code, discount_for


class CodeTableTest(unittest.TestCase):
    def test_module_docstring(self):
        self.assertTrue(discounts.__doc__)

    def test_invalid_code_is_value_error(self):
        self.assertTrue(issubclass(InvalidCode, ValueError))

    def test_table_has_both_codes(self):
        self.assertIn("SAVE10", discounts.CODES)
        self.assertIn("FIVEOFF", discounts.CODES)


class CanonicalCodeTest(unittest.TestCase):
    def test_case_insensitive(self):
        self.assertEqual(canonical_code("save10"), "SAVE10")
        self.assertEqual(canonical_code("SaVe10"), "SAVE10")

    def test_strips_whitespace(self):
        self.assertEqual(canonical_code(" save10 "), "SAVE10")

    def test_hostile_inputs_raise_invalid_code(self):
        # "ſave10" is a Latin long s: str.upper() turns it into "SAVE10".
        for bad in ["", "   ", None, 10, 10.0, "SAVE 10", "SAVE10X", "ſave10"]:
            with self.subTest(code=bad), self.assertRaises(InvalidCode):
                canonical_code(bad)

    def test_error_message_names_the_code(self):
        with self.assertRaises(InvalidCode) as ctx:
            canonical_code("BOGUS")
        self.assertEqual(str(ctx.exception), "unknown discount code: 'BOGUS'")


class DiscountAmountTest(unittest.TestCase):
    def test_save10_rounds_half_up(self):
        self.assertEqual(discount_for("SAVE10", Decimal("43.25")), Decimal("4.33"))

    def test_save10_sub_cent_rounds_up(self):
        self.assertEqual(discount_for("SAVE10", Decimal("0.05")), Decimal("0.01"))

    def test_fiveoff_capped_at_subtotal(self):
        self.assertEqual(discount_for("FIVEOFF", Decimal("3.00")), Decimal("3.00"))

    def test_fiveoff_flat(self):
        self.assertEqual(discount_for("FIVEOFF", Decimal("6.25")), Decimal("5.00"))

    def test_fiveoff_exactly_subtotal(self):
        self.assertEqual(discount_for("FIVEOFF", Decimal("5.00")), Decimal("5.00"))

    def test_empty_subtotal_is_zero_for_any_code(self):
        for code in discounts.CODES:
            with self.subTest(code=code):
                self.assertEqual(discount_for(code, Decimal("0.00")), Decimal("0.00"))

    def test_negative_subtotal_is_never_negative(self):
        self.assertEqual(discount_for("FIVEOFF", Decimal("-1.00")), Decimal("0.00"))


class PropertyTest(unittest.TestCase):
    def test_generated_carts_reconcile(self):
        rng = random.Random(20261117)
        skus = sorted(PRODUCTS)
        codes = [None, "SAVE10", "FIVEOFF", "save10", " fiveoff "]
        for n in range(1000):
            cart = Cart()
            for sku in rng.sample(skus, rng.randint(0, len(skus))):
                cart.add(sku, rng.randint(1, 5))
            code = rng.choice(codes)
            if code is not None:
                cart.apply_code(code)
            subtotal = cart.subtotal()
            discount = cart.discount()
            reconciled = subtotal - discount + cart.shipping() + cart.tax() == cart.total()
            ok = (
                Decimal("0") <= discount <= subtotal
                and discount.as_tuple().exponent == -2
                and reconciled
            )
            if not ok:
                items = {sku: item.qty for sku, item in cart.items.items()}
                self.fail(
                    f"case {n}: items={items} code={code!r} "
                    f"subtotal={subtotal} discount={discount} total={cart.total()}"
                )

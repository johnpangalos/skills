"""Plain-text receipts."""

from shop.money import format_money

WIDTH = 40


def _line(label, value):
    return label + value.rjust(WIDTH - len(label))


def _row(label, amount):
    return _line(label, format_money(amount))


def _discount_row(cart):
    """Discount line, shown as a minus amount unless it is zero."""
    amount = cart.discount()
    sign = "-" if amount > 0 else ""
    return _line(f"Discount ({cart.code})", sign + format_money(amount))


def render(cart):
    """Render a cart as a fixed-width receipt."""
    lines = []
    for item in cart.items.values():
        lines.append(_row(f"{item.qty} x {item.name}", item.total))
    lines.append("-" * WIDTH)
    lines.append(_row("Subtotal", cart.subtotal()))
    if cart.code is not None:
        lines.append(_discount_row(cart))
    lines.append(_row("Shipping", cart.shipping()))
    lines.append(_row("Tax", cart.tax()))
    lines.append(_row("Total", cart.total()))
    return "\n".join(lines)

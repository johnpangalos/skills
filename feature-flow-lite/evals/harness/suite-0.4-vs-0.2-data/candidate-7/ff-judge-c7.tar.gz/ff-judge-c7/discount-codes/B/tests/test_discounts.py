import random
import unittest
from decimal import Decimal

from shop.discounts import CODES, InvalidCode, canonical_code, discount_amount

HOSTILE_CODES = ["", "   ", "SAVE 10", "SAVE100", None, 10, "ſave10", "ﬁveoff", "fıveoff"]


class CanonicalCodeTest(unittest.TestCase):
    def test_invalid_code_is_a_value_error(self):
        self.assertTrue(issubclass(InvalidCode, ValueError))

    def test_case_and_surrounding_whitespace_are_ignored(self):
        for raw in ["SAVE10", "save10", "Save10", " save10 ", "\tFIVEOFF\n"]:
            with self.subTest(raw=raw):
                self.assertIn(canonical_code(raw), CODES)
        self.assertEqual(canonical_code("save10"), "SAVE10")
        self.assertEqual(canonical_code(" fiveoff "), "FIVEOFF")

    def test_hostile_codes_raise_invalid_code(self):
        for raw in HOSTILE_CODES:
            with self.subTest(raw=raw):
                with self.assertRaises(InvalidCode) as ctx:
                    canonical_code(raw)
                self.assertEqual(str(ctx.exception), f"unknown discount code: {raw!r}")


class DiscountAmountTest(unittest.TestCase):
    def test_save10_is_ten_percent_half_up(self):
        self.assertEqual(discount_amount("SAVE10", Decimal("43.25")), Decimal("4.33"))
        self.assertEqual(discount_amount("SAVE10", Decimal("6.25")), Decimal("0.63"))

    def test_fiveoff_is_five_dollars(self):
        self.assertEqual(discount_amount("FIVEOFF", Decimal("43.25")), Decimal("5.00"))

    def test_fiveoff_is_capped_at_subtotal(self):
        self.assertEqual(discount_amount("FIVEOFF", Decimal("3.00")), Decimal("3.00"))

    def test_empty_subtotal_gives_zero(self):
        for code in CODES:
            with self.subTest(code=code):
                self.assertEqual(str(discount_amount(code, Decimal("0.00"))), "0.00")

    def test_result_has_two_places(self):
        self.assertEqual(str(discount_amount("FIVEOFF", Decimal("3"))), "3.00")
        self.assertEqual(str(discount_amount("SAVE10", Decimal("10"))), "1.00")

    def test_unknown_code(self):
        with self.assertRaises(InvalidCode) as ctx:
            discount_amount("NOPE", Decimal("10.00"))
        self.assertEqual(str(ctx.exception), "unknown discount code: 'NOPE'")

    def test_random_subtotals_stay_within_bounds(self):
        rng = random.Random(20261117)
        for i in range(1000):
            # alternate sub-$5 subtotals (including $0.00) with ordinary ones
            cents = rng.randrange(0, 500) if i % 2 else rng.randrange(0, 200_001)
            subtotal = Decimal(cents).scaleb(-2)
            for code in CODES:
                off = discount_amount(code, subtotal)
                self.assertTrue(Decimal("0") <= off <= subtotal, (code, subtotal, off))
                self.assertEqual(off.as_tuple().exponent, -2, (code, subtotal, off))

"""Discount codes: validation and the discount each code gives."""

from decimal import Decimal

from shop.money import to_cents


class InvalidCode(ValueError):
    pass


def _save10(subtotal):
    return to_cents(subtotal * Decimal("0.10"))


def _fiveoff(subtotal):
    return Decimal("5.00")


CODES = {
    "SAVE10": _save10,  # 10% off the merchandise subtotal
    "FIVEOFF": _fiveoff,  # $5.00 off, capped at the subtotal
}


def normalize_code(code):
    """Return the canonical uppercase name for user input, or raise InvalidCode."""
    if not isinstance(code, str):
        raise InvalidCode(f"unknown code: {code!r}")
    text = code.strip()
    if not text.isascii():
        raise InvalidCode(f"unknown code: {code!r}")
    text = text.upper()
    if text not in CODES:
        raise InvalidCode(f"unknown code: {code!r}")
    return text


def discount_for(code, subtotal):
    """Return the discount in dollars for a canonical code on a merchandise subtotal."""
    return max(Decimal("0.00"), to_cents(min(CODES[code](subtotal), subtotal)))

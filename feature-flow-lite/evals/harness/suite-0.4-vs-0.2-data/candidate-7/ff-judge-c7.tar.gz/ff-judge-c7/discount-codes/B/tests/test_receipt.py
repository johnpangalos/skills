import unittest

from shop.cart import Cart
from shop.receipt import render


class ReceiptTest(unittest.TestCase):
    def test_render(self):
        cart = Cart()
        cart.add("BEAN-COL", 2)
        lines = render(cart).splitlines()
        self.assertEqual(lines[0], "2 x Colombia Huila, 250 g" + "$32.00".rjust(15))
        self.assertTrue(lines[-1].startswith("Total"))
        self.assertTrue(lines[-1].endswith("$42.59"))


class DiscountReceiptTest(unittest.TestCase):
    def test_no_code_receipt_is_unchanged(self):
        cart = Cart()
        cart.add("BEAN-ETH", 2)
        cart.add("FILTER")
        self.assertEqual(
            render(cart),
            "2 x Ethiopia Guji, 250 g          $37.00\n"
            "1 x Paper filters x100             $6.25\n"
            "----------------------------------------\n"
            "Subtotal                          $43.25\n"
            "Shipping                           $7.95\n"
            "Tax                                $3.57\n"
            "Total                             $54.77",
        )

    def test_discount_row_sits_between_subtotal_and_shipping(self):
        cart = Cart()
        cart.add("BEAN-ETH", 2)
        cart.add("FILTER")
        cart.apply_code("save10")
        lines = render(cart).splitlines()
        self.assertEqual(lines[3], "Subtotal" + "$43.25".rjust(32))
        self.assertEqual(lines[4], "Discount (SAVE10)" + "-$4.33".rjust(23))
        self.assertEqual(lines[5], "Shipping" + "$7.95".rjust(32))
        self.assertEqual(len(lines[4]), 40)

    def test_discount_row_is_forty_wide(self):
        cart = Cart()
        cart.add("BEAN-COL", 2)
        cart.apply_code("FIVEOFF")
        lines = render(cart).splitlines()
        self.assertEqual(lines[3], "Discount (FIVEOFF)" + "-$5.00".rjust(22))
        self.assertEqual({len(line) for line in lines[2:]}, {40})

    def test_zero_discount_is_not_negative(self):
        cart = Cart()
        cart.apply_code("FIVEOFF")
        text = render(cart)
        self.assertIn("Discount (FIVEOFF)" + "$0.00".rjust(22), text.splitlines())
        self.assertNotIn("-$", text)
        self.assertNotIn("$-", text)

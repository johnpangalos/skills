import unittest

from shop.cart import Cart
from shop.receipt import render


class ReceiptTest(unittest.TestCase):
    def test_render(self):
        cart = Cart()
        cart.add("BEAN-COL", 2)
        lines = render(cart).splitlines()
        self.assertEqual(lines[0], "2 x Colombia Huila, 250 g" + "$32.00".rjust(15))
        self.assertTrue(lines[-1].startswith("Total"))
        self.assertTrue(lines[-1].endswith("$42.59"))

    def test_no_code_has_no_discount_row(self):
        cart = Cart()
        cart.add("BEAN-COL", 2)
        self.assertNotIn("Discount", render(cart))

    def test_discount_row_sits_between_subtotal_and_shipping(self):
        cart = Cart()
        cart.add("BEAN-ETH", 2)
        cart.add("FILTER")
        cart.apply_code("save10")
        lines = render(cart).splitlines()
        label = "Discount (SAVE10)"
        self.assertEqual(lines[3], "Subtotal" + "$43.25".rjust(32))
        self.assertEqual(lines[4], label + "-$4.33".rjust(40 - len(label)))
        self.assertEqual(len(lines[4]), 40)
        self.assertTrue(lines[5].startswith("Shipping"))

    def test_zero_discount_has_no_negative_sign(self):
        cart = Cart()
        cart.apply_code("FIVEOFF")
        text = render(cart)
        label = "Discount (FIVEOFF)"
        self.assertEqual(text.splitlines()[2], label + "$0.00".rjust(40 - len(label)))
        self.assertNotIn("-$0.00", text)

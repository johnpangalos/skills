import random
import unittest
from decimal import Decimal

from shop.cart import TAX_RATE, Cart, LineItem
from shop.catalog import PRODUCTS, UnknownProduct
from shop.discounts import InvalidCode
from shop.money import to_cents


class CartTest(unittest.TestCase):
    def test_totals(self):
        cart = Cart()
        cart.add("BEAN-ETH", 2)
        cart.add("FILTER")
        self.assertEqual(cart.subtotal(), Decimal("43.25"))
        self.assertEqual(cart.shipping(), Decimal("7.95"))
        self.assertEqual(cart.tax(), Decimal("3.57"))
        self.assertEqual(cart.total(), Decimal("54.77"))

    def test_free_shipping_at_threshold(self):
        cart = Cart()
        cart.add("MUG", 2)
        cart.add("BEAN-ETH")
        cart.add("FILTER", 2)
        self.assertEqual(cart.subtotal(), Decimal("75.00"))
        self.assertEqual(cart.shipping(), Decimal("0.00"))

    def test_empty_cart_is_free(self):
        self.assertEqual(Cart().total(), Decimal("0.00"))

    def test_unknown_sku(self):
        with self.assertRaises(UnknownProduct):
            Cart().add("NOPE")


def _example_cart():
    cart = Cart()
    cart.add("BEAN-ETH", 2)
    cart.add("FILTER")
    return cart


class CartDiscountTest(unittest.TestCase):
    def test_no_code_by_default(self):
        cart = Cart()
        self.assertIsNone(cart.code)
        self.assertEqual(cart.discount(), Decimal("0.00"))

    def test_apply_stores_canonical_code(self):
        cart = Cart()
        cart.apply_code("save10")
        self.assertEqual(cart.code, "SAVE10")

    def test_apply_strips_whitespace(self):
        cart = Cart()
        cart.apply_code(" save10 ")
        self.assertEqual(cart.code, "SAVE10")

    def test_hostile_codes_raise_invalid_code_and_leave_cart_alone(self):
        hostile = (None, 10, b"SAVE10", "", "   ", "ſave10", "ＳＡＶＥ１０", "SAVE 10", "SAVE10X")
        for bad in hostile:
            with self.subTest(bad=bad):
                cart = Cart()
                with self.assertRaises(InvalidCode):
                    cart.apply_code(bad)
                self.assertIsNone(cart.code)

    def test_new_valid_code_replaces_old(self):
        cart = _example_cart()
        cart.apply_code("SAVE10")
        cart.apply_code("fiveoff")
        self.assertEqual(cart.code, "FIVEOFF")
        self.assertEqual(cart.discount(), Decimal("5.00"))

    def test_unknown_code_keeps_current_code(self):
        cart = _example_cart()
        cart.apply_code("SAVE10")
        with self.assertRaises(InvalidCode):
            cart.apply_code("NOPE")
        self.assertEqual(cart.code, "SAVE10")
        self.assertEqual(cart.discount(), Decimal("4.33"))

    def test_discount_is_recomputed_from_current_subtotal(self):
        cart = _example_cart()
        cart.apply_code("SAVE10")
        self.assertEqual(cart.discount(), Decimal("4.33"))
        cart.add("MUG")
        self.assertEqual(cart.discount(), Decimal("6.53"))
        cart.remove("MUG")
        self.assertEqual(cart.discount(), Decimal("4.33"))

    def test_totals_with_save10(self):
        cart = _example_cart()
        cart.apply_code("SAVE10")
        self.assertEqual(cart.subtotal(), Decimal("43.25"))
        self.assertEqual(cart.discount(), Decimal("4.33"))
        self.assertEqual(cart.shipping(), Decimal("7.95"))
        self.assertEqual(cart.tax(), Decimal("3.21"))
        self.assertEqual(cart.total(), Decimal("50.08"))

    def test_fiveoff_on_filter_only(self):
        cart = Cart()
        cart.add("FILTER")
        cart.apply_code("FIVEOFF")
        self.assertEqual(cart.discount(), Decimal("5.00"))
        self.assertEqual(cart.tax(), Decimal("0.10"))
        self.assertEqual(cart.total(), Decimal("9.30"))

    def test_discount_equal_to_subtotal_has_no_tax(self):
        cart = Cart()
        cart.items["SAMPLE"] = LineItem("SAMPLE", "Sample", Decimal("5.00"), 1)
        cart.apply_code("FIVEOFF")
        self.assertEqual(cart.discount(), Decimal("5.00"))
        self.assertEqual(cart.tax(), Decimal("0.00"))
        self.assertEqual(cart.total(), cart.shipping())
        self.assertEqual(cart.total(), Decimal("7.95"))

    def test_free_shipping_uses_pre_discount_subtotal(self):
        cart = Cart()
        cart.add("MUG", 2)
        cart.add("BEAN-ETH")
        cart.add("FILTER", 2)
        cart.apply_code("FIVEOFF")
        self.assertEqual(cart.subtotal(), Decimal("75.00"))
        self.assertEqual(cart.shipping(), Decimal("0.00"))
        self.assertEqual(cart.tax(), Decimal("5.78"))
        self.assertEqual(cart.total(), Decimal("75.78"))

    def test_empty_cart_with_code(self):
        cart = Cart()
        cart.apply_code("FIVEOFF")
        self.assertEqual(cart.discount(), Decimal("0.00"))
        self.assertEqual(cart.shipping(), Decimal("0.00"))
        self.assertEqual(cart.total(), Decimal("0.00"))

    def test_random_carts_keep_invariants(self):
        rng = random.Random(20261117)
        skus = sorted(PRODUCTS)
        codes = [None, "SAVE10", "fiveoff", " Save10 ", "NOPE"]
        for _ in range(1000):
            cart = Cart()
            for _ in range(rng.randint(0, 6)):
                cart.add(rng.choice(skus), rng.randint(1, 9))
            code = rng.choice(codes)
            if code is not None:
                try:
                    cart.apply_code(code)
                except InvalidCode:
                    pass
            subtotal = cart.subtotal()
            discount = cart.discount()
            self.assertGreaterEqual(discount, Decimal("0"))
            self.assertLessEqual(discount, subtotal)
            self.assertEqual(discount, to_cents(discount))
            self.assertEqual(discount.as_tuple().exponent, -2)
            self.assertEqual(cart.tax(), to_cents((subtotal - discount) * TAX_RATE))
            self.assertEqual(cart.total(), subtotal - discount + cart.shipping() + cart.tax())
            self.assertGreaterEqual(cart.total(), cart.shipping())

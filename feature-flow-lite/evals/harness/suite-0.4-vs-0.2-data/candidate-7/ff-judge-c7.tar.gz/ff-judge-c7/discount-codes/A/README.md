# shop

Checkout logic for a small online coffee shop: catalog, cart totals, receipts,
and password-reset tokens. Standard library only.

    ./check.sh        # lint + unit tests (run before every commit)

Money is `Decimal` dollars, rounded to cents half-up (`shop/money.py`).
Shipping is a flat $7.95, free once the merchandise subtotal reaches $75.
The $75 threshold uses the pre-discount subtotal.
Sales tax is 8.25% of merchandise only, computed after any discount; shipping
is not taxed.

Discount codes (`shop/discounts.py`, case-insensitive, surrounding spaces
ignored; one code per cart, applying a new one replaces the old):

- `SAVE10`: 10% off the merchandise subtotal, rounded to cents half-up.
- `FIVEOFF`: $5.00 off, capped at the subtotal.

The discount is never negative and never more than the subtotal. A cart at or
above $75 before the discount ships free, even if the discount takes it below
$75.

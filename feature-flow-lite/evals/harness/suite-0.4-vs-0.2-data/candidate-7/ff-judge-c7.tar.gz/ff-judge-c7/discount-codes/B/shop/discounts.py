"""Discount codes."""

from decimal import Decimal

from shop.money import to_cents

SAVE10_RATE = Decimal("0.10")  # of the merchandise subtotal
FIVEOFF_AMOUNT = Decimal("5.00")
CODES = ("SAVE10", "FIVEOFF")


class InvalidCode(ValueError):
    pass


def canonical_code(code):
    """Return the upper-case form of a known code, ignoring case and spaces."""
    if isinstance(code, str):
        normalized = code.strip()
        # ASCII only: str.upper() folds lookalikes such as "ſ" and "ﬁ" onto codes.
        if normalized.isascii() and normalized.upper() in CODES:
            return normalized.upper()
    raise InvalidCode(f"unknown discount code: {code!r}")


def discount_amount(code, subtotal):
    """Return dollars off a pre-discount subtotal, never more than the subtotal."""
    if code == "SAVE10":
        off = to_cents(subtotal * SAVE10_RATE)
    elif code == "FIVEOFF":
        off = FIVEOFF_AMOUNT
    else:
        raise InvalidCode(f"unknown discount code: {code!r}")
    return to_cents(max(Decimal("0"), min(off, subtotal)))

import unittest
from decimal import Decimal

from shop.cart import Cart, LineItem
from shop.catalog import UnknownProduct
from shop.discounts import InvalidCode


class CartTest(unittest.TestCase):
    def test_totals(self):
        cart = Cart()
        cart.add("BEAN-ETH", 2)
        cart.add("FILTER")
        self.assertEqual(cart.subtotal(), Decimal("43.25"))
        self.assertEqual(cart.shipping(), Decimal("7.95"))
        self.assertEqual(cart.tax(), Decimal("3.57"))
        self.assertEqual(cart.total(), Decimal("54.77"))

    def test_free_shipping_at_threshold(self):
        cart = Cart()
        cart.add("MUG", 2)
        cart.add("BEAN-ETH")
        cart.add("FILTER", 2)
        self.assertEqual(cart.subtotal(), Decimal("75.00"))
        self.assertEqual(cart.shipping(), Decimal("0.00"))

    def test_empty_cart_is_free(self):
        self.assertEqual(Cart().total(), Decimal("0.00"))

    def test_unknown_sku(self):
        with self.assertRaises(UnknownProduct):
            Cart().add("NOPE")

    def test_no_code_means_no_discount(self):
        cart = Cart()
        cart.add("BEAN-ETH", 2)
        self.assertIsNone(cart.code)
        self.assertEqual(cart.discount(), Decimal("0.00"))

    def test_discount_totals(self):
        cart = Cart()
        cart.add("BEAN-ETH", 2)
        cart.add("FILTER")
        cart.apply_code("SAVE10")
        self.assertEqual(cart.discount(), Decimal("4.33"))
        self.assertEqual(cart.shipping(), Decimal("7.95"))
        self.assertEqual(cart.tax(), Decimal("3.21"))
        self.assertEqual(cart.total(), Decimal("50.08"))

    def test_shipping_uses_pre_discount_subtotal(self):
        cart = Cart()
        cart.add("MUG", 2)
        cart.add("BEAN-ETH")
        cart.add("FILTER", 2)
        cart.apply_code("SAVE10")
        self.assertEqual(cart.shipping(), Decimal("0.00"))
        self.assertEqual(cart.discount(), Decimal("7.50"))
        self.assertEqual(cart.tax(), Decimal("5.57"))
        self.assertEqual(cart.total(), Decimal("73.07"))

    def test_fiveoff_on_threshold_cart(self):
        cart = Cart()
        cart.add("MUG", 2)
        cart.add("BEAN-ETH")
        cart.add("FILTER", 2)
        cart.apply_code("FIVEOFF")
        self.assertEqual(cart.shipping(), Decimal("0.00"))
        self.assertEqual(cart.discount(), Decimal("5.00"))
        self.assertEqual(cart.tax(), Decimal("5.78"))
        self.assertEqual(cart.total(), Decimal("75.78"))

    def test_subtotal_exactly_fiveoff_is_taxed_zero(self):
        cart = Cart()
        cart.items["TEST"] = LineItem("TEST", "Test item", Decimal("5.00"), 1)
        cart.apply_code("FIVEOFF")
        self.assertEqual(cart.discount(), Decimal("5.00"))
        self.assertEqual(cart.tax(), Decimal("0.00"))

    def test_subtotal_below_fiveoff_is_capped(self):
        cart = Cart()
        cart.items["TEST"] = LineItem("TEST", "Test item", Decimal("3.00"), 1)
        cart.apply_code("FIVEOFF")
        self.assertEqual(cart.discount(), Decimal("3.00"))
        self.assertEqual(cart.tax(), Decimal("0.00"))

    def test_empty_cart_with_code_is_zero(self):
        for code in ["SAVE10", "FIVEOFF"]:
            with self.subTest(code=code):
                cart = Cart()
                cart.apply_code(code)
                self.assertEqual(cart.discount(), Decimal("0.00"))
                self.assertEqual(cart.tax(), Decimal("0.00"))
                self.assertEqual(cart.total(), Decimal("0.00"))

    def test_apply_code_stores_canonical_code(self):
        cart = Cart()
        cart.apply_code("save10")
        self.assertEqual(cart.code, "SAVE10")

    def test_apply_code_strips_whitespace(self):
        cart = Cart()
        cart.apply_code(" save10 ")
        self.assertEqual(cart.code, "SAVE10")

    def test_hostile_codes_raise_and_leave_cart_unchanged(self):
        cart = Cart()
        for bad in ["", "   ", None, 10, "SAVE 10", "SAVE10X", "ſave10"]:
            with self.subTest(code=bad), self.assertRaises(InvalidCode):
                cart.apply_code(bad)
        self.assertIsNone(cart.code)

    def test_applying_a_code_replaces_the_current_one(self):
        cart = Cart()
        cart.add("BEAN-ETH", 2)
        cart.add("FILTER")
        cart.apply_code("SAVE10")
        cart.apply_code("FIVEOFF")
        self.assertEqual(cart.code, "FIVEOFF")
        self.assertEqual(cart.discount(), Decimal("5.00"))

    def test_unknown_code_keeps_current_code(self):
        cart = Cart()
        cart.add("BEAN-ETH", 2)
        cart.add("FILTER")
        cart.apply_code("SAVE10")
        with self.assertRaises(InvalidCode):
            cart.apply_code("BOGUS")
        self.assertEqual(cart.code, "SAVE10")
        self.assertEqual(cart.discount(), Decimal("4.33"))

    def test_discount_follows_items(self):
        cart = Cart()
        cart.apply_code("SAVE10")
        self.assertEqual(cart.discount(), Decimal("0.00"))
        cart.add("BEAN-ETH", 2)
        cart.add("FILTER")
        self.assertEqual(cart.discount(), Decimal("4.33"))
        cart.remove("FILTER")
        self.assertEqual(cart.discount(), Decimal("3.70"))
        cart.remove("BEAN-ETH")
        self.assertEqual(cart.discount(), Decimal("0.00"))

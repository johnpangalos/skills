"""Discount codes: percent or flat amounts off the merchandise subtotal."""

from decimal import Decimal

from shop.money import to_cents


class InvalidCode(ValueError):
    pass


# code -> (kind, value): "percent" is a fraction of the subtotal, "flat" is dollars
CODES = {
    "SAVE10": ("percent", Decimal("0.10")),
    "FIVEOFF": ("flat", Decimal("5.00")),
}


def canonical_code(code):
    """Return the upper-case table key for a user-entered code, or raise InvalidCode."""
    stripped = code.strip() if isinstance(code, str) else ""
    key = stripped.upper()
    if not stripped.isascii() or key not in CODES:
        raise InvalidCode(f"unknown discount code: {code!r}")
    return key


def discount_for(code, subtotal):
    """Return the discount in dollars for a canonical code, never more than the subtotal."""
    kind, value = CODES[code]
    if kind == "percent":
        amount = to_cents(subtotal * value)
    else:
        amount = value
    return max(Decimal("0.00"), min(amount, subtotal))

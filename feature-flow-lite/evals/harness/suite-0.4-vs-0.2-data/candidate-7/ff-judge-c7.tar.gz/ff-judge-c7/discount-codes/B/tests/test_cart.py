import random
import unittest
from decimal import Decimal

from shop.cart import TAX_RATE, Cart
from shop.catalog import PRODUCTS, UnknownProduct
from shop.discounts import InvalidCode
from shop.money import to_cents

HOSTILE_CODES = ["", "   ", "SAVE 10", "SAVE100", None, 10, "ſave10", "ﬁveoff", "fıveoff"]


class CartTest(unittest.TestCase):
    def test_totals(self):
        cart = Cart()
        cart.add("BEAN-ETH", 2)
        cart.add("FILTER")
        self.assertEqual(cart.subtotal(), Decimal("43.25"))
        self.assertEqual(cart.shipping(), Decimal("7.95"))
        self.assertEqual(cart.tax(), Decimal("3.57"))
        self.assertEqual(cart.total(), Decimal("54.77"))

    def test_free_shipping_at_threshold(self):
        cart = Cart()
        cart.add("MUG", 2)
        cart.add("BEAN-ETH")
        cart.add("FILTER", 2)
        self.assertEqual(cart.subtotal(), Decimal("75.00"))
        self.assertEqual(cart.shipping(), Decimal("0.00"))

    def test_empty_cart_is_free(self):
        self.assertEqual(Cart().total(), Decimal("0.00"))

    def test_unknown_sku(self):
        with self.assertRaises(UnknownProduct):
            Cart().add("NOPE")


class DiscountCodeTest(unittest.TestCase):
    def test_no_code_by_default(self):
        cart = Cart()
        self.assertIsNone(cart.code)
        self.assertEqual(cart.discount(), Decimal("0.00"))

    def test_apply_code_is_case_and_whitespace_insensitive(self):
        for raw in ["SAVE10", "save10", "Save10", " save10 "]:
            with self.subTest(raw=raw):
                cart = Cart()
                cart.apply_code(raw)
                self.assertEqual(cart.code, "SAVE10")

    def test_one_code_at_a_time(self):
        cart = Cart()
        cart.add("BEAN-ETH", 2)
        cart.add("FILTER")
        cart.apply_code("save10")
        cart.apply_code("fiveoff")
        self.assertEqual(cart.code, "FIVEOFF")
        self.assertEqual(cart.discount(), Decimal("5.00"))

    def test_unknown_code_keeps_current_code(self):
        cart = Cart()
        cart.apply_code("SAVE10")
        with self.assertRaises(InvalidCode) as ctx:
            cart.apply_code("NOPE")
        self.assertEqual(str(ctx.exception), "unknown discount code: 'NOPE'")
        self.assertEqual(cart.code, "SAVE10")

    def test_unknown_code_keeps_no_code(self):
        cart = Cart()
        with self.assertRaises(InvalidCode):
            cart.apply_code("NOPE")
        self.assertIsNone(cart.code)

    def test_hostile_codes_leave_state_unchanged(self):
        for raw in HOSTILE_CODES:
            for before in [None, "FIVEOFF"]:
                with self.subTest(raw=raw, before=before):
                    cart = Cart()
                    if before:
                        cart.apply_code(before)
                    with self.assertRaises(InvalidCode) as ctx:
                        cart.apply_code(raw)
                    self.assertEqual(str(ctx.exception), f"unknown discount code: {raw!r}")
                    self.assertEqual(cart.code, before)

    def test_save10_discount(self):
        cart = Cart()
        cart.add("BEAN-ETH", 2)
        cart.add("FILTER")
        cart.apply_code("SAVE10")
        self.assertEqual(cart.discount(), Decimal("4.33"))

    def test_discount_follows_current_subtotal(self):
        cart = Cart()
        cart.add("FILTER")
        cart.apply_code("SAVE10")
        self.assertEqual(cart.discount(), Decimal("0.63"))
        cart.add("BEAN-ETH")
        self.assertEqual(cart.discount(), Decimal("2.48"))
        cart.remove("BEAN-ETH")
        self.assertEqual(cart.discount(), Decimal("0.63"))

    def test_empty_cart_with_fiveoff_is_zero(self):
        cart = Cart()
        cart.apply_code("FIVEOFF")
        self.assertEqual(cart.discount(), Decimal("0.00"))
        self.assertEqual(cart.total(), Decimal("0.00"))

    def test_worked_example(self):
        cart = Cart()
        cart.add("BEAN-ETH", 2)
        cart.add("FILTER")
        cart.apply_code("SAVE10")
        self.assertEqual(cart.discount(), Decimal("4.33"))
        self.assertEqual(cart.shipping(), Decimal("7.95"))
        self.assertEqual(cart.tax(), Decimal("3.21"))
        self.assertEqual(cart.total(), Decimal("50.08"))

    def test_tax_is_on_discounted_subtotal(self):
        cart = Cart()
        cart.add("BEAN-ETH", 2)
        cart.add("FILTER")
        cart.apply_code("FIVEOFF")
        self.assertEqual(cart.tax(), Decimal("3.16"))

    def test_total_never_below_shipping(self):
        cart = Cart()
        cart.add("FILTER")
        cart.apply_code("FIVEOFF")
        self.assertEqual(cart.discount(), Decimal("5.00"))
        self.assertEqual(cart.tax(), Decimal("0.10"))
        self.assertEqual(cart.total(), Decimal("9.30"))
        self.assertGreaterEqual(cart.total(), cart.shipping())

    def test_free_shipping_uses_pre_discount_subtotal(self):
        cart = Cart()
        cart.add("MUG", 2)
        cart.add("BEAN-ETH")
        cart.add("FILTER", 2)
        cart.apply_code("FIVEOFF")
        self.assertEqual(cart.subtotal(), Decimal("75.00"))
        self.assertEqual(cart.shipping(), Decimal("0.00"))
        self.assertEqual(cart.total(), Decimal("75.78"))

    def test_just_under_threshold_still_pays_shipping(self):
        cart = Cart()
        cart.add("MUG", 2)
        cart.add("BEAN-COL")
        cart.add("FILTER", 2)
        self.assertEqual(cart.subtotal(), Decimal("72.50"))
        cart.apply_code("FIVEOFF")
        self.assertEqual(cart.shipping(), Decimal("7.95"))

    def test_random_carts_keep_totals_consistent(self):
        rng = random.Random(20261117)
        skus = sorted(PRODUCTS)
        codes = [None, "SAVE10", "FIVEOFF"]
        for _ in range(1000):
            cart = Cart()
            for sku in rng.sample(skus, rng.randrange(0, len(skus) + 1)):
                cart.add(sku, rng.randrange(1, 4))
            code = rng.choice(codes)
            if code:
                cart.apply_code(rng.choice([code, code.lower(), f" {code} "]))
            subtotal, discount = cart.subtotal(), cart.discount()
            self.assertTrue(Decimal("0") <= discount <= subtotal, (subtotal, discount))
            self.assertEqual(discount.as_tuple().exponent, -2)
            tax = to_cents((subtotal - discount) * TAX_RATE)
            self.assertEqual(cart.tax(), tax)
            self.assertEqual(cart.total(), subtotal - discount + cart.shipping() + tax)
            self.assertGreaterEqual(cart.total(), cart.shipping())

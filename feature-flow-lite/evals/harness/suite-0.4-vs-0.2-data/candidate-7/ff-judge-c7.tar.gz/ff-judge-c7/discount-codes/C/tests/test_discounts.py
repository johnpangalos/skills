import unittest
from decimal import Decimal

import shop.discounts as discounts
from shop.discounts import InvalidCode, discount_for, normalize_code


class DiscountTableTest(unittest.TestCase):
    def test_module_has_docstring_and_invalid_code_is_value_error(self):
        self.assertTrue(discounts.__doc__)
        self.assertTrue(issubclass(InvalidCode, ValueError))

    def test_save10_is_ten_percent_half_up(self):
        self.assertEqual(discount_for("SAVE10", Decimal("43.25")), Decimal("4.33"))

    def test_fiveoff_is_five_dollars(self):
        self.assertEqual(discount_for("FIVEOFF", Decimal("75.00")), Decimal("5.00"))

    def test_fiveoff_capped_at_subtotal(self):
        self.assertEqual(discount_for("FIVEOFF", Decimal("3.00")), Decimal("3.00"))

    def test_fiveoff_on_empty_cart_is_zero(self):
        self.assertEqual(discount_for("FIVEOFF", Decimal("0.00")), Decimal("0.00"))

    def test_save10_sub_unit_half_up(self):
        self.assertEqual(discount_for("SAVE10", Decimal("0.05")), Decimal("0.01"))

    def test_save10_sub_unit_rounds_down(self):
        self.assertEqual(discount_for("SAVE10", Decimal("0.04")), Decimal("0.00"))

    def test_result_is_quantized_to_cents(self):
        result = discount_for("SAVE10", Decimal("43.250"))
        self.assertEqual(str(result), "4.33")
        self.assertEqual(result.as_tuple().exponent, -2)

    def test_negative_subtotal_gives_zero_not_negative(self):
        self.assertEqual(str(discount_for("FIVEOFF", Decimal("-3.00"))), "0.00")
        self.assertEqual(str(discount_for("SAVE10", Decimal("-40.00"))), "0.00")

    def test_negative_zero_subtotal_gives_plain_zero(self):
        self.assertEqual(str(discount_for("FIVEOFF", Decimal("-0.00"))), "0.00")


class NormalizeCodeTest(unittest.TestCase):
    def test_case_insensitive(self):
        for text in ("save10", "Save10", "SAVE10"):
            with self.subTest(text=text):
                self.assertEqual(normalize_code(text), "SAVE10")

    def test_surrounding_ascii_whitespace_is_stripped(self):
        self.assertEqual(normalize_code(" save10 "), "SAVE10")
        self.assertEqual(normalize_code("\tfiveoff\n"), "FIVEOFF")

    def test_unicode_whitespace_is_stripped(self):
        for text in ("\xa0SAVE10", "SAVE10\xa0", "　SAVE10", "SAVE10　"):
            with self.subTest(text=text):
                self.assertEqual(normalize_code(text), "SAVE10")

    def test_non_str_raises_invalid_code(self):
        for bad in (None, 10, b"SAVE10", ["SAVE10"]):
            with self.subTest(bad=bad):
                with self.assertRaises(InvalidCode):
                    normalize_code(bad)

    def test_empty_and_blank_raise_invalid_code(self):
        for bad in ("", "   ", "\xa0"):
            with self.subTest(bad=bad):
                with self.assertRaises(InvalidCode):
                    normalize_code(bad)

    def test_non_ascii_lookalikes_raise_invalid_code(self):
        for bad in ("ſave10", "ＳＡＶＥ１０", "ＳＡＶＥ10", "\xa0ſave10"):
            with self.subTest(bad=bad):
                with self.assertRaises(InvalidCode):
                    normalize_code(bad)

    def test_inner_space_and_extra_characters_raise_invalid_code(self):
        for bad in ("SAVE 10", "SAVE10X", "NOPE"):
            with self.subTest(bad=bad):
                with self.assertRaises(InvalidCode):
                    normalize_code(bad)

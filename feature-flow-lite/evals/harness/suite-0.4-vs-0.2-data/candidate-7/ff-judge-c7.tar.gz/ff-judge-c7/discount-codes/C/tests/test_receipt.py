import unittest

from shop.cart import Cart
from shop.receipt import render


class ReceiptTest(unittest.TestCase):
    def test_render(self):
        cart = Cart()
        cart.add("BEAN-COL", 2)
        lines = render(cart).splitlines()
        self.assertEqual(lines[0], "2 x Colombia Huila, 250 g" + "$32.00".rjust(15))
        self.assertTrue(lines[-1].startswith("Total"))
        self.assertTrue(lines[-1].endswith("$42.59"))


def _line(label, value):
    return label + value.rjust(40 - len(label))


def _example_cart():
    cart = Cart()
    cart.add("BEAN-ETH", 2)
    cart.add("FILTER")
    return cart


class ReceiptDiscountTest(unittest.TestCase):
    def test_no_code_receipt_is_unchanged(self):
        expected = (
            "2 x Ethiopia Guji, 250 g          $37.00\n"
            "1 x Paper filters x100             $6.25\n"
            "----------------------------------------\n"
            "Subtotal                          $43.25\n"
            "Shipping                           $7.95\n"
            "Tax                                $3.57\n"
            "Total                             $54.77"
        )
        self.assertEqual(render(_example_cart()), expected)

    def test_discount_row_sits_between_subtotal_and_shipping(self):
        cart = _example_cart()
        cart.apply_code("SAVE10")
        expected = "\n".join([
            "2 x Ethiopia Guji, 250 g          $37.00",
            "1 x Paper filters x100             $6.25",
            "----------------------------------------",
            _line("Subtotal", "$43.25"),
            _line("Discount (SAVE10)", "-$4.33"),
            _line("Shipping", "$7.95"),
            _line("Tax", "$3.21"),
            _line("Total", "$50.08"),
        ])
        self.assertEqual(render(cart), expected)

    def test_zero_discount_on_empty_cart_is_plain_zero(self):
        cart = Cart()
        cart.apply_code("FIVEOFF")
        text = render(cart)
        self.assertIn(_line("Discount (FIVEOFF)", "$0.00"), text.splitlines())
        self.assertNotIn("-$0.00", text)
        self.assertNotIn("$-0.00", text)


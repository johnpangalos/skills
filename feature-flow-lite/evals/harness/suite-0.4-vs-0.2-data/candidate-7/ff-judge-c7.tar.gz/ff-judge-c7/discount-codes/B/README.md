# shop

Checkout logic for a small online coffee shop: catalog, cart totals, receipts,
and password-reset tokens. Standard library only.

    ./check.sh        # lint + unit tests (run before every commit)

Money is `Decimal` dollars, rounded to cents half-up (`shop/money.py`).
Shipping is a flat $7.95, free once the merchandise subtotal reaches $75.
Sales tax is 8.25% of merchandise only; shipping is not taxed.

Discount codes (case-insensitive, surrounding whitespace ignored): `SAVE10` takes
10% off the merchandise subtotal (rounded half-up to cents), and `FIVEOFF`
takes $5.00 off, never more than the subtotal. Only one code applies at a time;
applying a new code replaces the old one. Tax is charged on the discounted
subtotal. The free-shipping threshold is checked against the subtotal before
the discount, so a $75.00 cart with `FIVEOFF` still ships free.

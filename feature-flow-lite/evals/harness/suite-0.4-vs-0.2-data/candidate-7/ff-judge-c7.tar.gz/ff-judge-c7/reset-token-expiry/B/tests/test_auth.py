import threading
import time
import unittest
from unittest import mock

from shop.auth import (
    InvalidToken,
    TokenExpired,
    TokenUsed,
    issue_reset_token,
    redeem_reset_token,
)


class _SlowRecord(dict):
    # Sleeps on the "used" read, so that without _LOCK every thread sees
    # used=False before any thread writes used=True (the GIL alone hides this).
    def __getitem__(self, key):
        value = super().__getitem__(key)
        if key == "used":
            time.sleep(0.01)
        return value


class _SlowTokenStore(dict):
    def __setitem__(self, key, value):
        super().__setitem__(key, _SlowRecord(value))


class ResetTokenTest(unittest.TestCase):
    def test_round_trip(self):
        token = issue_reset_token("ada")
        self.assertEqual(redeem_reset_token(token), "ada")

    def test_unknown_token(self):
        with self.assertRaises(InvalidToken) as ctx:
            redeem_reset_token("not-a-token")
        self.assertIs(type(ctx.exception), InvalidToken)

    def test_now_zero_is_honoured(self):
        # time.time() is far from 0; if now=0 were replaced by it, the token
        # would look issued in the future and redeem at 1801 would succeed.
        with mock.patch("shop.auth.time.time", return_value=10**9):
            token = issue_reset_token("ada", now=0)
            with self.assertRaises(TokenExpired):
                redeem_reset_token(token, now=1801)

    def test_float_timestamps(self):
        token = issue_reset_token("ada", now=0.5)
        self.assertEqual(redeem_reset_token(token, now=1800.5), "ada")

    def test_exactly_1800_seconds_still_valid(self):
        token = issue_reset_token("ada", now=0)
        self.assertEqual(redeem_reset_token(token, now=1800), "ada")

    def test_1800_001_seconds_expired(self):
        token = issue_reset_token("ada", now=0)
        with self.assertRaises(TokenExpired):
            redeem_reset_token(token, now=1800.001)

    def test_expiry_after_1800_seconds_with_integer_clock(self):
        token = issue_reset_token("ada", now=0)
        with self.assertRaises(TokenExpired):
            redeem_reset_token(token, now=1801)

    def test_redeem_before_issue_clock_skew_succeeds(self):
        token = issue_reset_token("ada", now=5000)
        self.assertEqual(redeem_reset_token(token, now=4000), "ada")

    def test_redeem_before_issue_by_more_than_window_succeeds(self):
        token = issue_reset_token("ada", now=5000)
        self.assertEqual(redeem_reset_token(token, now=0), "ada")

    def test_nan_issue_time_fails_closed(self):
        token = issue_reset_token("ada", now=float("nan"))
        with self.assertRaises(TokenExpired):
            redeem_reset_token(token, now=1)

    def test_nan_redeem_time_fails_closed(self):
        token = issue_reset_token("ada", now=0)
        with self.assertRaises(TokenExpired):
            redeem_reset_token(token, now=float("nan"))

    def test_default_now_reads_time_at_call_time(self):
        with mock.patch("shop.auth.time.time", return_value=1000.0):
            token = issue_reset_token("ada")
        with mock.patch("shop.auth.time.time", return_value=1000.0 + 1801):
            with self.assertRaises(TokenExpired):
                redeem_reset_token(token)

    def test_default_now_within_window(self):
        with mock.patch("shop.auth.time.time", return_value=1000.0):
            token = issue_reset_token("ada")
        with mock.patch("shop.auth.time.time", return_value=1000.0 + 60):
            self.assertEqual(redeem_reset_token(token), "ada")

    def test_single_use(self):
        token = issue_reset_token("ada", now=0)
        self.assertEqual(redeem_reset_token(token, now=1), "ada")
        with self.assertRaises(TokenUsed):
            redeem_reset_token(token, now=2)

    def test_used_token_after_window_is_used_not_expired(self):
        token = issue_reset_token("ada", now=0)
        redeem_reset_token(token, now=100)
        with self.assertRaises(TokenUsed) as ctx:
            redeem_reset_token(token, now=5000)
        self.assertIs(type(ctx.exception), TokenUsed)

    def test_expired_redeem_does_not_consume_token(self):
        token = issue_reset_token("ada", now=0)
        with self.assertRaises(TokenExpired):
            redeem_reset_token(token, now=1801)
        with self.assertRaises(TokenExpired) as ctx:
            redeem_reset_token(token, now=1802)
        self.assertIs(type(ctx.exception), TokenExpired)

    def test_two_tokens_for_same_user_are_independent(self):
        first = issue_reset_token("ada", now=0)
        second = issue_reset_token("ada", now=0)
        self.assertNotEqual(first, second)
        self.assertEqual(redeem_reset_token(first, now=1), "ada")
        self.assertEqual(redeem_reset_token(second, now=1), "ada")

    def test_token_exceptions_are_invalid_token_subclasses(self):
        self.assertTrue(issubclass(TokenExpired, InvalidToken))
        self.assertTrue(issubclass(TokenUsed, InvalidToken))

    def test_non_string_token_is_plain_invalid_token(self):
        for bad in ([], None, {}, 42):
            with self.subTest(bad=bad):
                with self.assertRaises(InvalidToken) as ctx:
                    redeem_reset_token(bad)
                self.assertIs(type(ctx.exception), InvalidToken)

    def test_concurrent_redeem_succeeds_exactly_once(self):
        threads_n = 8
        rounds = 3
        with mock.patch("shop.auth._TOKENS", _SlowTokenStore()):
            for _ in range(rounds):
                token = issue_reset_token("ada", now=0)
                barrier = threading.Barrier(threads_n)
                outcomes = []
                outcomes_lock = threading.Lock()

                def attempt():
                    barrier.wait()
                    try:
                        result = redeem_reset_token(token, now=1)
                    except TokenUsed:
                        result = "used"
                    with outcomes_lock:
                        outcomes.append(result)

                workers = [threading.Thread(target=attempt) for _ in range(threads_n)]
                for worker in workers:
                    worker.start()
                for worker in workers:
                    worker.join()

                self.assertEqual(outcomes.count("ada"), 1)
                self.assertEqual(outcomes.count("used"), threads_n - 1)

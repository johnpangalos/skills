import threading
import time
import unittest
from unittest import mock

from shop.auth import (
    InvalidToken,
    TokenExpired,
    TokenUsed,
    issue_reset_token,
    redeem_reset_token,
)


class ResetTokenTest(unittest.TestCase):
    def test_round_trip(self):
        token = issue_reset_token("ada")
        self.assertEqual(redeem_reset_token(token), "ada")

    def test_unknown_token(self):
        with self.assertRaises(InvalidToken):
            redeem_reset_token("not-a-token")

    def test_explicit_zero_now_on_redeem_is_honored(self):
        token = issue_reset_token("ada", now=1000)
        # now=0 is clock skew (before issue), so it is not expired; if 0 were
        # replaced by time.time() the token would read as expired.
        self.assertEqual(redeem_reset_token(token, now=0), "ada")

    def test_none_now_uses_clock_at_call_time(self):
        with mock.patch("shop.auth.time.time", return_value=1000.0):
            token = issue_reset_token("ada")
        with mock.patch("shop.auth.time.time", return_value=1000.0 + 1801):
            with self.assertRaises(TokenExpired):
                redeem_reset_token(token)

    def test_float_timestamps(self):
        token = issue_reset_token("ada", now=1000.25)
        self.assertEqual(redeem_reset_token(token, now=1000.25 + 1800), "ada")


class ExpiryTest(unittest.TestCase):
    def test_exactly_at_ttl_succeeds(self):
        token = issue_reset_token("ada", now=1000)
        self.assertEqual(redeem_reset_token(token, now=1000 + 1800), "ada")

    def test_just_past_ttl_expires(self):
        token = issue_reset_token("ada", now=1000)
        with self.assertRaises(TokenExpired):
            redeem_reset_token(token, now=1000 + 1800.001)

    def test_issued_at_zero_redeemed_at_1801_expires(self):
        token = issue_reset_token("ada", now=0)
        with self.assertRaises(TokenExpired):
            redeem_reset_token(token, now=1801)

    def test_clock_skew_before_issue_is_not_expired(self):
        token = issue_reset_token("ada", now=1000)
        self.assertEqual(redeem_reset_token(token, now=900), "ada")


class SingleUseTest(unittest.TestCase):
    def test_later_redemptions_are_used(self):
        token = issue_reset_token("ada", now=1000)
        self.assertEqual(redeem_reset_token(token, now=1000), "ada")
        with self.assertRaises(TokenUsed):
            redeem_reset_token(token, now=1000)
        with self.assertRaises(TokenUsed):
            redeem_reset_token(token, now=1001)

    def test_used_token_after_expiry_reports_used(self):
        token = issue_reset_token("ada", now=1000)
        redeem_reset_token(token, now=1000)
        with self.assertRaises(TokenUsed):
            redeem_reset_token(token, now=1000 + 5000)

    def test_expired_redemption_does_not_consume_token(self):
        token = issue_reset_token("ada", now=1000)
        for now in (1000 + 1801, 1000 + 2000, 1000 + 9999):
            with self.assertRaises(TokenExpired):
                redeem_reset_token(token, now=now)

    def test_two_tokens_for_same_user_are_independent(self):
        first = issue_reset_token("ada", now=1000)
        second = issue_reset_token("ada", now=1000)
        self.assertNotEqual(first, second)
        self.assertEqual(redeem_reset_token(first, now=1000), "ada")
        self.assertEqual(redeem_reset_token(second, now=1000), "ada")
        with self.assertRaises(TokenUsed):
            redeem_reset_token(first, now=1000)


class ExceptionTypeTest(unittest.TestCase):
    def test_expired_and_used_subclass_invalid_token(self):
        self.assertTrue(issubclass(TokenExpired, InvalidToken))
        self.assertTrue(issubclass(TokenUsed, InvalidToken))

    def test_unknown_token_is_plain_invalid_token(self):
        with self.assertRaises(InvalidToken) as cm:
            redeem_reset_token("not-a-token", now=1000)
        self.assertIs(type(cm.exception), InvalidToken)

    def test_empty_and_none_are_invalid_token(self):
        for bad in ("", None):
            with self.subTest(token=bad):
                with self.assertRaises(InvalidToken) as cm:
                    redeem_reset_token(bad, now=1000)
                self.assertIs(type(cm.exception), InvalidToken)


class SlowRecord(dict):
    # Reading "used" is the check in redeem_reset_token; sleeping there widens
    # the window before the write, so without the lock several threads pass it.
    def __getitem__(self, key):
        value = super().__getitem__(key)
        if key == "used":
            time.sleep(0.0015)
        return value


class SlowDict(dict):
    def __setitem__(self, key, record):
        super().__setitem__(key, SlowRecord(record))


class ConcurrentRedeemTest(unittest.TestCase):
    THREADS = 8
    ROUNDS = 25

    def test_exactly_one_winner_per_token_every_round(self):
        with mock.patch("shop.auth._TOKENS", SlowDict()):
            for round_no in range(self.ROUNDS):
                token = issue_reset_token("ada", now=1000)
                barrier = threading.Barrier(self.THREADS)
                outcomes = []

                def attempt():
                    barrier.wait()
                    try:
                        outcomes.append(redeem_reset_token(token, now=1000))
                    except TokenUsed:
                        outcomes.append("used")

                threads = [threading.Thread(target=attempt) for _ in range(self.THREADS)]
                for thread in threads:
                    thread.start()
                for thread in threads:
                    thread.join()

                wins = [o for o in outcomes if o == "ada"]
                losses = [o for o in outcomes if o == "used"]
                self.assertEqual(len(wins), 1, f"round {round_no}")
                self.assertEqual(len(losses), self.THREADS - 1, f"round {round_no}")

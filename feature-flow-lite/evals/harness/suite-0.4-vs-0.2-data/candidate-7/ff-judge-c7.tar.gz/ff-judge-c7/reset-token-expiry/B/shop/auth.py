"""Password-reset tokens (in-memory store)."""

import secrets
import threading
import time

RESET_WINDOW = 1800  # seconds after issue during which a token can be redeemed

_TOKENS = {}  # token -> {"username": str, "issued": float, "used": bool}
_LOCK = threading.Lock()  # held across lookup and marking a token used


class InvalidToken(Exception):
    pass


class TokenExpired(InvalidToken):
    pass


class TokenUsed(InvalidToken):
    pass


def issue_reset_token(username, now=None):
    """Create a reset token for username, issued at now (Unix seconds)."""
    if now is None:
        now = time.time()
    token = secrets.token_urlsafe(16)
    _TOKENS[token] = {"username": username, "issued": now, "used": False}
    return token


def redeem_reset_token(token, now=None):
    """Return the username a token was issued for and mark the token used."""
    if now is None:
        now = time.time()
    if not isinstance(token, str):
        raise InvalidToken("unknown token")
    with _LOCK:
        record = _TOKENS.get(token)
        if record is None:
            raise InvalidToken("unknown token")
        if record["used"]:
            raise TokenUsed("token already used")
        if not now - record["issued"] <= RESET_WINDOW:  # NaN fails closed
            raise TokenExpired("token expired")
        record["used"] = True
        return record["username"]

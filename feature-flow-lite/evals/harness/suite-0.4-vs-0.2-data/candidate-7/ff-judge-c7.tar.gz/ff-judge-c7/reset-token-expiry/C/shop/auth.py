"""Password-reset tokens (in-memory store)."""

import math
import secrets
import threading
import time

TTL_SECONDS = 1800

_TOKENS = {}  # token -> (username, issued_at, used)
_LOCK = threading.Lock()


class InvalidToken(Exception):
    pass


class TokenExpired(InvalidToken):
    pass


class TokenUsed(InvalidToken):
    pass


def _as_timestamp(now):
    """Return now as a float.

    Raises TypeError unless now is an int or float (bool excluded), and
    ValueError if it is NaN, infinite or too large for a float.
    """
    if isinstance(now, bool) or not isinstance(now, (int, float)):
        raise TypeError("now must be an int or float timestamp")
    try:
        value = float(now)
    except OverflowError:
        raise ValueError("now must be a finite timestamp") from None
    if not math.isfinite(value):
        raise ValueError("now must be a finite timestamp")
    return value


def issue_reset_token(username, now=None):
    """Create a reset token for username.

    now is a Unix timestamp in seconds; None means time.time(). The token
    expires 30 minutes (1800 seconds) after now and is single-use. A
    non-numeric now raises TypeError; a non-finite or out-of-range one
    raises ValueError.
    """
    if now is None:
        now = time.time()
    now = _as_timestamp(now)
    token = secrets.token_urlsafe(16)
    with _LOCK:
        _TOKENS[token] = (username, now, False)
    return token


def redeem_reset_token(token, now=None):
    """Return the username a token was issued for.

    now is a Unix timestamp in seconds; None means time.time(). A token
    expires 30 minutes (1800 seconds) after issue (TokenExpired) and can be
    redeemed only once (TokenUsed). A non-numeric now raises TypeError; a
    non-finite or out-of-range one raises ValueError. Neither consumes the token.
    """
    if now is None:
        now = time.time()
    now = _as_timestamp(now)
    with _LOCK:
        record = _TOKENS.get(token)
        if record is None:
            raise InvalidToken("unknown token")
        username, issued_at, used = record
        if used:
            raise TokenUsed("token already used")
        if now - issued_at > TTL_SECONDS:
            raise TokenExpired("token expired")
        _TOKENS[token] = (username, issued_at, True)
        return username

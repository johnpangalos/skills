"""Password-reset tokens (in-memory store)."""

import secrets
import threading
import time

RESET_TOKEN_TTL = 1800  # seconds a reset token stays valid after issue
_TOKENS = {}  # token -> {"username", "issued_at", "used"}
_LOCK = threading.Lock()  # guards the check-and-mark in redeem_reset_token


class InvalidToken(Exception):
    pass


class TokenExpired(InvalidToken):
    pass


class TokenUsed(InvalidToken):
    pass


def issue_reset_token(username, now=None):
    """Create a reset token for username; now is a Unix timestamp."""
    if now is None:
        now = time.time()
    token = secrets.token_urlsafe(16)
    _TOKENS[token] = {"username": username, "issued_at": now, "used": False}
    return token


def redeem_reset_token(token, now=None):
    """Return the username a token was issued for, consuming the token."""
    if now is None:
        now = time.time()
    with _LOCK:
        record = _TOKENS.get(token)
        if record is None:
            raise InvalidToken("unknown token")
        if record["used"]:
            raise TokenUsed("token already used")
        if now > record["issued_at"] + RESET_TOKEN_TTL:
            raise TokenExpired("token expired")
        record["used"] = True
        return record["username"]

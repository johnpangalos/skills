import threading
import unittest
from decimal import Decimal

from shop.cart import Cart
from shop.orders import Refund, RefundError, place_order, refund

MUG_TOTAL = Decimal("31.77")  # one mug: 22.00 + 7.95 shipping + 1.82 tax


def mug_cart():
    cart = Cart()
    cart.add("MUG")
    return cart


class OrdersTest(unittest.TestCase):
    def test_place_order_snapshots_total(self):
        cart = mug_cart()
        order = place_order(cart)
        self.assertEqual(order.total, MUG_TOTAL)
        cart.add("FILTER")
        self.assertEqual(order.total, MUG_TOTAL)

    def test_order_ids_are_unique(self):
        cart = mug_cart()
        self.assertNotEqual(place_order(cart).id, place_order(cart).id)

    def test_empty_cart_raises(self):
        with self.assertRaises(ValueError) as ctx:
            place_order(Cart())
        self.assertEqual(str(ctx.exception), "cannot place an order for an empty cart")

    def test_cart_with_all_items_removed_is_empty(self):
        cart = mug_cart()
        cart.remove("MUG")
        with self.assertRaises(ValueError) as ctx:
            place_order(cart)
        self.assertEqual(str(ctx.exception), "cannot place an order for an empty cart")

    def test_place_order_does_not_mutate_cart(self):
        cart = mug_cart()
        cart.add("FILTER", 2)
        before = dict(cart.items)
        place_order(cart)
        self.assertEqual(cart.items, before)
        self.assertEqual(cart.items["FILTER"].qty, 2)

    def test_nothing_refunded_yet(self):
        order = place_order(mug_cart())
        self.assertEqual(order.refunded(), Decimal("0.00"))
        self.assertEqual(order.refundable(), MUG_TOTAL)
        self.assertEqual(order.refunds, ())

    def test_refund_records_order_amount_and_key(self):
        order = place_order(mug_cart())
        record = refund(order, Decimal("5"), "k1")
        self.assertIsInstance(record, Refund)
        self.assertEqual(record.order_id, order.id)
        self.assertEqual(record.amount, Decimal("5"))
        self.assertEqual(record.key, "k1")

    def test_partial_refund_reduces_refundable(self):
        order = place_order(mug_cart())
        refund(order, Decimal("10.00"), "k1")
        self.assertEqual(order.refunded(), Decimal("10.00"))
        self.assertEqual(order.refundable(), Decimal("21.77"))
        self.assertEqual(len(order.refunds), 1)

    def test_refunds_are_read_only(self):
        order = place_order(mug_cart())
        refund(order, Decimal("1.00"), "k1")
        self.assertIsInstance(order.refunds, tuple)
        with self.assertRaises(AttributeError):
            order.refunds.append(Refund(order.id, Decimal("1.00"), "sneaky"))
        with self.assertRaises(AttributeError):
            order.refunds = ()
        self.assertEqual(order.refunded(), Decimal("1.00"))

    def test_rejects_invalid_amounts(self):
        cases = [
            (5, "amount must be a Decimal"),
            (5.0, "amount must be a Decimal"),
            (True, "amount must be a Decimal"),
            ("5", "amount must be a Decimal"),
            (None, "amount must be a Decimal"),
            (Decimal("0"), "amount must be positive"),
            (Decimal("-0"), "amount must be positive"),
            (Decimal("-1"), "amount must be positive"),
            (Decimal("1.001"), "amount must be whole cents"),
            (Decimal("NaN"), "amount must be finite"),
            (Decimal("sNaN"), "amount must be finite"),
            (Decimal("Infinity"), "amount must be finite"),
        ]
        order = place_order(mug_cart())
        for amount, message in cases:
            with self.subTest(amount=amount):
                with self.assertRaises(RefundError) as ctx:
                    refund(order, amount, "bad")
                self.assertEqual(str(ctx.exception), message)
        self.assertEqual(order.refunds, ())

    def test_accepts_whole_cent_amounts_with_any_exponent(self):
        order = place_order(mug_cart())
        self.assertEqual(refund(order, Decimal("1.10"), "a").amount, Decimal("1.10"))
        self.assertEqual(refund(order, Decimal("1E+1"), "b").amount, Decimal("1E+1"))
        self.assertEqual(order.refunded(), Decimal("11.10"))

    def test_full_total_succeeds(self):
        order = place_order(mug_cart())
        refund(order, MUG_TOTAL, "full")
        self.assertEqual(order.refundable(), Decimal("0.00"))

    def test_exceeding_total_by_a_cent_fails_and_changes_nothing(self):
        order = place_order(mug_cart())
        with self.assertRaises(RefundError) as ctx:
            refund(order, MUG_TOTAL + Decimal("0.01"), "over")
        self.assertEqual(str(ctx.exception), "refund exceeds refundable balance")
        self.assertEqual(order.refunded(), Decimal("0.00"))
        self.assertEqual(order.refunds, ())
        # key was not recorded, so it can be reused with a valid amount
        self.assertEqual(refund(order, MUG_TOTAL, "over").amount, MUG_TOTAL)

    def test_partial_refunds_cannot_exceed_total(self):
        order = place_order(mug_cart())
        refund(order, Decimal("10.00"), "a")
        refund(order, Decimal("21.77"), "b")
        self.assertEqual(order.refundable(), Decimal("0.00"))
        with self.assertRaises(RefundError) as ctx:
            refund(order, Decimal("0.01"), "c")
        self.assertEqual(str(ctx.exception), "refund exceeds refundable balance")
        self.assertEqual(order.refunded(), MUG_TOTAL)
        self.assertEqual(len(order.refunds), 2)

    def test_same_key_and_amount_returns_original_refund(self):
        order = place_order(mug_cart())
        first = refund(order, Decimal("5"), "k")
        second = refund(order, Decimal("5.00"), "k")
        self.assertIs(first, second)
        self.assertEqual(order.refunded(), Decimal("5"))
        self.assertEqual(len(order.refunds), 1)

    def test_same_key_with_different_amount_fails(self):
        order = place_order(mug_cart())
        refund(order, Decimal("5"), "k")
        with self.assertRaises(RefundError) as ctx:
            refund(order, Decimal("6"), "k")
        self.assertEqual(str(ctx.exception), "key reused with a different amount")
        self.assertEqual(order.refunded(), Decimal("5"))

    def test_key_is_scoped_to_its_order(self):
        first = place_order(mug_cart())
        second = place_order(mug_cart())
        a = refund(first, Decimal("5"), "k")
        b = refund(second, Decimal("5"), "k")
        self.assertIsNot(a, b)
        self.assertEqual(b.order_id, second.id)
        self.assertEqual(second.refunded(), Decimal("5"))

    def test_replay_after_full_refund_returns_original(self):
        order = place_order(mug_cart())
        original = refund(order, MUG_TOTAL, "k")
        self.assertIs(refund(order, MUG_TOTAL, "k"), original)
        self.assertEqual(order.refundable(), Decimal("0.00"))

    def test_replay_with_invalid_amount_fails(self):
        order = place_order(mug_cart())
        refund(order, Decimal("5"), "k")
        with self.assertRaises(RefundError) as ctx:
            refund(order, Decimal("NaN"), "k")
        self.assertEqual(str(ctx.exception), "amount must be finite")
        self.assertEqual(order.refunded(), Decimal("5"))

    def test_unhashable_key_fails(self):
        order = place_order(mug_cart())
        with self.assertRaises(RefundError) as ctx:
            refund(order, Decimal("5"), [])
        self.assertEqual(str(ctx.exception), "key must be hashable")
        self.assertEqual(order.refunds, ())

    def test_amounts_beyond_decimal_context_fail(self):
        order = place_order(mug_cart())
        for amount in [Decimal("1E+30"), Decimal("123456789012345678901234567890.00")]:
            with self.subTest(amount=amount):
                with self.assertRaises(RefundError) as ctx:
                    refund(order, amount, "huge")
                self.assertEqual(str(ctx.exception), "amount is out of range")
        self.assertEqual(order.refunds, ())

    def test_decimal_subclass_cannot_bypass_cap(self):
        class Sneaky(Decimal):
            def __gt__(self, other):
                return False

            def __le__(self, other):
                return False

        order = place_order(mug_cart())
        with self.assertRaises(RefundError) as ctx:
            refund(order, Sneaky("100.00"), "sneaky")
        self.assertEqual(str(ctx.exception), "refund exceeds refundable balance")
        self.assertEqual(order.refunds, ())
        record = refund(order, Sneaky(MUG_TOTAL), "ok")
        self.assertIs(type(record.amount), Decimal)
        self.assertEqual(record.amount, MUG_TOTAL)

    def test_total_is_read_only(self):
        order = place_order(mug_cart())
        with self.assertRaises(AttributeError):
            order.total = Decimal("1000.00")
        self.assertEqual(order.total, MUG_TOTAL)

    def test_concurrent_refunds_cannot_exceed_total(self):
        order = place_order(mug_cart())
        workers = 10
        barrier = threading.Barrier(workers)
        outcomes = []

        def attempt(n):
            barrier.wait()
            try:
                refund(order, MUG_TOTAL, f"k{n}")
                outcomes.append("ok")
            except RefundError:
                outcomes.append("rejected")

        threads = [threading.Thread(target=attempt, args=(n,)) for n in range(workers)]
        for t in threads:
            t.start()
        for t in threads:
            t.join()
        self.assertEqual(outcomes.count("ok"), 1)
        self.assertEqual(order.refunded(), MUG_TOTAL)
        self.assertEqual(len(order.refunds), 1)

"""Orders placed from a cart, with idempotent partial refunds (in-memory store)."""

import itertools
import threading
from dataclasses import dataclass
from decimal import Decimal, InvalidOperation

from shop.money import CENT

_ORDER_IDS = itertools.count(1)


class RefundError(ValueError):
    pass


@dataclass(frozen=True)
class Refund:
    order_id: int
    amount: Decimal
    key: str


class Order:
    def __init__(self, total):
        self.id = next(_ORDER_IDS)
        self.total = total
        self._refunds = {}  # key -> Refund
        self._lock = threading.Lock()

    def refunded(self):
        with self._lock:
            return self._refunded()

    def _refunded(self):
        return sum((r.amount for r in self._refunds.values()), Decimal("0.00"))

    def refundable(self):
        return self.total - self.refunded()


def place_order(cart):
    """Create an order priced at the cart's current total."""
    if not cart.items:
        raise ValueError("cannot place an order for an empty cart")
    return Order(cart.total())


def _check_amount(amount):
    """Raise RefundError unless amount is a positive whole number of cents."""
    if not isinstance(amount, Decimal) or not amount.is_finite():
        raise RefundError("refund amount must be a finite Decimal")
    try:
        valid = amount > 0 and amount == amount.quantize(CENT)
    except InvalidOperation:
        valid = False
    if not valid:
        raise RefundError("refund amount must be a positive whole number of cents")


def refund(order, amount, key):
    """Refund amount from order. Repeating a key with the same amount returns the original refund."""
    _check_amount(amount)
    with order._lock:
        existing = order._refunds.get(key)
        if existing is not None:
            if existing.amount == amount:
                return existing
            raise RefundError("key already used for a different amount")
        if amount > order.total - order._refunded():
            raise RefundError("refund exceeds refundable amount")
        result = Refund(order.id, amount, key)
        order._refunds[key] = result
    return result

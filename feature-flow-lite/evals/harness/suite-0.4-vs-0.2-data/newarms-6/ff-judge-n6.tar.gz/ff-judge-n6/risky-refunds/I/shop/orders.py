"""Orders placed from a cart, with idempotent partial refunds."""

import uuid
from dataclasses import dataclass, field
from decimal import Decimal, InvalidOperation

from shop.money import CENT


class RefundError(ValueError):
    pass


@dataclass(frozen=True)
class Refund:
    order_id: str
    amount: Decimal
    key: str


@dataclass
class Order:
    id: str
    total: Decimal
    _refunds: dict = field(default_factory=dict, init=False, repr=False)  # key -> Refund

    def refunded(self):
        return sum((r.amount for r in self._refunds.values()), Decimal("0.00"))

    def refundable(self):
        return self.total - self.refunded()


def place_order(cart):
    """Create an Order holding the cart's total at this moment."""
    if not cart.items:
        raise ValueError("cannot place an order from an empty cart")
    return Order(id=uuid.uuid4().hex, total=cart.total())


def _check_amount(amount):
    """Return amount as a plain Decimal; raise RefundError unless it is a
    positive, finite, whole-cent Decimal."""
    message = "amount must be a positive, finite Decimal in whole cents"
    if not isinstance(amount, Decimal):
        raise RefundError(message)
    amount = Decimal(amount)  # drop any subclass behaviour before comparing
    if not amount.is_finite() or amount <= 0:
        raise RefundError(message)
    try:
        whole_cents = amount == amount.quantize(CENT)
    except InvalidOperation:
        raise RefundError(message) from None
    if not whole_cents:
        raise RefundError(message)
    return amount


def refund(order, amount, key):
    """Refund amount from order. Repeating a key returns the original Refund."""
    amount = _check_amount(amount)
    previous = order._refunds.get(key)
    if previous is not None:
        if previous.amount != amount:
            raise RefundError("key already used for a different amount")
        return previous
    if amount > order.refundable():
        raise RefundError("refund exceeds refundable amount")
    new = Refund(order.id, amount, key)
    order._refunds[key] = new
    return new

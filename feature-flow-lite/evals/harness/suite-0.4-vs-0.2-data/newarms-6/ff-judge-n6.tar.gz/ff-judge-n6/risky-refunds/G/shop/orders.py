"""Orders and idempotent partial refunds."""

import threading
import uuid
from collections.abc import Hashable
from dataclasses import dataclass, field
from decimal import DefaultContext, Decimal, InvalidOperation, localcontext

from shop.money import to_cents

ZERO = Decimal("0.00")
BAD_AMOUNT = "amount must be a positive whole-cent Decimal"


class RefundError(ValueError):
    pass


@dataclass(frozen=True)
class Refund:
    order_id: str
    amount: Decimal
    key: Hashable


@dataclass
class Order:
    id: str
    total: Decimal
    _refunds: dict = field(default_factory=dict, init=False, repr=False, compare=False)
    _lock: threading.RLock = field(
        default_factory=threading.RLock, init=False, repr=False, compare=False
    )

    def refunded(self):
        with self._lock, localcontext(DefaultContext):
            return sum((r.amount for r in self._refunds.values()), ZERO)

    def refundable(self):
        with localcontext(DefaultContext):
            return self.total - self.refunded()


def place_order(cart):
    """Freeze the cart's current total into a new order."""
    if not cart.items:
        raise ValueError("cart is empty")
    with localcontext(DefaultContext):
        total = cart.total()
    return Order(id=uuid.uuid4().hex, total=total)


def refund(order, amount, key):
    """Refund amount from order. Reusing a key returns its original Refund."""
    with localcontext(DefaultContext):
        if not isinstance(amount, Decimal):
            raise RefundError(BAD_AMOUNT)
        try:
            # plain Decimal copy: a subclass could override comparisons
            amount = Decimal(amount)
            valid = amount.is_finite() and amount > 0 and to_cents(amount) == amount
        except (InvalidOperation, TypeError):  # too many digits, or a fake Decimal
            valid = False
        if not valid:
            raise RefundError(BAD_AMOUNT)
        try:
            hash(key)
        except TypeError:
            raise RefundError("key must be hashable") from None
        if key != key:  # NaN never matches itself, so it could never be reused
            raise RefundError("key must equal itself")
        with order._lock:
            previous = order._refunds.get(key)
            if previous is not None:
                if previous.amount != amount:
                    raise RefundError("key already used with a different amount")
                return previous
            if order.refunded() + amount > order.total:
                raise RefundError("refund exceeds refundable amount")
            new = Refund(order.id, amount, key)
            order._refunds[key] = new
            return new

"""Orders and idempotent partial refunds."""

import itertools
import threading
from dataclasses import dataclass, field
from decimal import Context, Decimal, DivisionByZero, InvalidOperation, Overflow, localcontext

from shop.money import to_cents

# All money arithmetic runs under this fixed context, never the caller's.
_MONEY = Context(prec=28, traps=[InvalidOperation, DivisionByZero, Overflow])

_ORDER_IDS = itertools.count(1)


class RefundError(ValueError):
    pass


@dataclass(frozen=True)
class Refund:
    order_id: int
    amount: Decimal
    key: str


@dataclass(frozen=True)
class Order:
    id: int
    total: Decimal
    _refunds: dict = field(default_factory=dict, init=False, repr=False, compare=False)
    _lock: threading.Lock = field(default_factory=threading.Lock, init=False, repr=False, compare=False)

    def refunded(self):
        """Sum of the refunds recorded so far."""
        with localcontext(_MONEY):
            return sum((r.amount for r in list(self._refunds.values())), Decimal("0.00"))

    def refundable(self):
        """Amount still open for refund."""
        with localcontext(_MONEY):
            return self.total - self.refunded()


def place_order(cart):
    """Snapshot the cart's total into a new Order."""
    if not cart.items:
        raise ValueError("cannot place an order for an empty cart")
    with localcontext(_MONEY):
        total = cart.total()  # before taking an id, so a failure consumes none
    return Order(next(_ORDER_IDS), total)


def refund(order, amount, key):
    """Refund amount from order; a repeated key returns its original Refund."""
    amount = _check_amount(amount)
    if not isinstance(key, str) or not key:
        raise RefundError("key must be a non-empty str")
    with order._lock, localcontext(_MONEY):
        previous = order._refunds.get(key)
        if previous is not None:
            if previous.amount != amount:
                raise RefundError("key already used for a different amount")
            return previous
        if amount > order.refundable():
            raise RefundError("refund exceeds refundable amount")
        record = Refund(order.id, to_cents(amount), key)
        order._refunds[key] = record
        return record


def _check_amount(amount):
    """Return a plain Decimal copy of amount, or reject it; never rounds."""
    if not isinstance(amount, Decimal):
        raise RefundError("amount must be a finite positive Decimal")
    try:
        amount = Decimal(amount)  # plain copy: a subclass cannot override its checks
    except (TypeError, ValueError):  # a fake can pass isinstance and still fail the copy
        raise RefundError("amount must be a finite positive Decimal") from None
    if not amount.is_finite() or amount <= 0:
        raise RefundError("amount must be a finite positive Decimal")
    if not _is_whole_cents(amount):
        raise RefundError("amount must be whole cents")
    return amount


def _is_whole_cents(amount):
    """Exact check for no digits below the cent place; never rounds."""
    _, digits, exponent = amount.as_tuple()
    extra = -exponent - 2  # digits past the cent place
    return extra <= 0 or not any(digits[-extra:])

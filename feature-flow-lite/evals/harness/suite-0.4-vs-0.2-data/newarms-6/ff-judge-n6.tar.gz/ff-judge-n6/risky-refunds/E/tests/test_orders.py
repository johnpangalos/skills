import dataclasses
import threading
import unittest
from decimal import Decimal, Inexact, Rounded, localcontext

from shop.cart import Cart
from shop.orders import RefundError, place_order, refund

AMOUNT_MSG = "amount must be a finite positive Decimal"
CENTS_MSG = "amount must be whole cents"
EXCEEDS_MSG = "refund exceeds refundable amount"
KEY_MSG = "key must be a non-empty str"
REUSED_MSG = "key already used for a different amount"


def _cart():
    cart = Cart()
    cart.add("BEAN-ETH", 2)
    cart.add("FILTER")
    return cart  # total 54.77


class PlaceOrderTest(unittest.TestCase):
    def test_total_matches_cart(self):
        order = place_order(_cart())
        self.assertEqual(order.total, Decimal("54.77"))
        self.assertIsInstance(order.total, Decimal)

    def test_ids_are_unique(self):
        cart = _cart()
        first = place_order(cart)
        second = place_order(cart)
        self.assertNotEqual(first.id, second.id)

    def test_total_is_snapshot(self):
        cart = _cart()
        order = place_order(cart)
        cart.add("MUG")
        cart.remove("BEAN-ETH")
        self.assertEqual(order.total, Decimal("54.77"))

    def test_large_quantity(self):
        cart = Cart()
        cart.add("MUG", 10**9)
        order = place_order(cart)
        self.assertEqual(order.total, cart.total())
        self.assertEqual(order.total, Decimal("23815000000.00"))

    def test_empty_cart_raises(self):
        with self.assertRaises(ValueError) as cm:
            place_order(Cart())
        self.assertEqual(str(cm.exception), "cannot place an order for an empty cart")

    def test_cart_with_all_items_removed_raises(self):
        cart = _cart()
        cart.remove("BEAN-ETH")
        cart.remove("FILTER")
        with self.assertRaises(ValueError) as cm:
            place_order(cart)
        self.assertEqual(str(cm.exception), "cannot place an order for an empty cart")


class RefundAccountingTest(unittest.TestCase):
    def test_nothing_refunded_yet(self):
        order = place_order(_cart())
        self.assertEqual(order.refunded(), Decimal("0"))
        self.assertEqual(order.refunded(), Decimal("0.00"))
        self.assertEqual(order.refundable(), Decimal("54.77"))

    def test_partial_refunds_accumulate(self):
        order = place_order(_cart())
        refund(order, Decimal("20.00"), "a")
        refund(order, Decimal("30"), "b")
        self.assertEqual(order.refunded(), Decimal("50.00"))
        self.assertEqual(order.refundable(), Decimal("4.77"))

    def test_refund_exactly_refundable(self):
        order = place_order(_cart())
        refund(order, order.refundable(), "all")
        self.assertEqual(order.refundable(), Decimal("0.00"))
        with self.assertRaises(RefundError) as cm:
            refund(order, Decimal("0.01"), "more")
        self.assertEqual(str(cm.exception), EXCEEDS_MSG)
        self.assertEqual(order.refunded(), Decimal("54.77"))

    def test_refund_over_total_changes_nothing(self):
        order = place_order(_cart())
        with self.assertRaises(RefundError) as cm:
            refund(order, Decimal("54.78"), "big")
        self.assertEqual(str(cm.exception), EXCEEDS_MSG)
        self.assertEqual(order.refunded(), Decimal("0.00"))
        # key was not consumed by the failed refund
        record = refund(order, Decimal("5"), "big")
        self.assertEqual(record.amount, Decimal("5.00"))


class RefundRecordTest(unittest.TestCase):
    def test_record_fields(self):
        order = place_order(_cart())
        record = refund(order, Decimal("5"), "k1")
        self.assertEqual(record.order_id, order.id)
        self.assertEqual(record.amount, Decimal("5.00"))
        self.assertIsInstance(record.amount, Decimal)
        self.assertEqual(record.key, "k1")

    def test_record_is_frozen(self):
        record = refund(place_order(_cart()), Decimal("5"), "k1")
        with self.assertRaises(dataclasses.FrozenInstanceError):
            record.amount = Decimal("999")


class RefundAmountTest(unittest.TestCase):
    def test_whole_cent_forms_accepted(self):
        order = place_order(_cart())
        self.assertEqual(refund(order, Decimal("1.000"), "a").amount, Decimal("1.00"))
        self.assertEqual(refund(order, Decimal("0.01"), "b").amount, Decimal("0.01"))
        self.assertEqual(refund(order, Decimal("1E+1"), "c").amount, Decimal("10.00"))
        self.assertEqual(order.refunded(), Decimal("11.01"))

    def test_invalid_amounts_change_nothing(self):
        bad = [
            (5, AMOUNT_MSG),
            (5.0, AMOUNT_MSG),
            ("5.00", AMOUNT_MSG),
            (True, AMOUNT_MSG),
            (None, AMOUNT_MSG),
            (Decimal("0"), AMOUNT_MSG),
            (Decimal("-0.01"), AMOUNT_MSG),
            (Decimal("-0"), AMOUNT_MSG),
            (Decimal("NaN"), AMOUNT_MSG),
            (Decimal("sNaN"), AMOUNT_MSG),
            (Decimal("Infinity"), AMOUNT_MSG),
            (Decimal("-Infinity"), AMOUNT_MSG),
            (Decimal("0.001"), CENTS_MSG),
            (Decimal("1.005"), CENTS_MSG),
            (Decimal("1E+30"), EXCEEDS_MSG),
            (Decimal("12345678901234567890123456789.01"), EXCEEDS_MSG),
        ]
        for amount, message in bad:
            with self.subTest(amount=amount):
                order = place_order(_cart())
                with self.assertRaises(RefundError) as cm:
                    refund(order, amount, "k")
                self.assertEqual(str(cm.exception), message)
                self.assertEqual(order.refunded(), Decimal("0.00"))
                self.assertEqual(order.refundable(), Decimal("54.77"))

    def test_invalid_amount_on_used_key_changes_nothing(self):
        order = place_order(_cart())
        first = refund(order, Decimal("5"), "k")
        with self.assertRaises(RefundError) as cm:
            refund(order, Decimal("0.001"), "k")
        self.assertEqual(str(cm.exception), CENTS_MSG)
        self.assertIs(refund(order, Decimal("5.00"), "k"), first)
        self.assertEqual(order.refunded(), Decimal("5.00"))


class IdempotencyTest(unittest.TestCase):
    def test_retry_returns_same_object(self):
        order = place_order(_cart())
        first = refund(order, Decimal("5"), "k")
        again = refund(order, Decimal("5.00"), "k")
        self.assertIs(again, first)
        self.assertEqual(order.refunded(), Decimal("5.00"))

    def test_retry_after_fully_refunded(self):
        order = place_order(_cart())
        first = refund(order, order.refundable(), "all")
        again = refund(order, Decimal("54.77"), "all")
        self.assertIs(again, first)
        self.assertEqual(order.refunded(), Decimal("54.77"))

    def test_same_key_different_amount(self):
        order = place_order(_cart())
        refund(order, Decimal("5"), "k")
        with self.assertRaises(RefundError) as cm:
            refund(order, Decimal("6"), "k")
        self.assertEqual(str(cm.exception), REUSED_MSG)
        self.assertEqual(order.refunded(), Decimal("5.00"))

    def test_key_on_other_order_is_independent(self):
        cart = _cart()
        first_order = place_order(cart)
        second_order = place_order(cart)
        a = refund(first_order, Decimal("5"), "k")
        b = refund(second_order, Decimal("5"), "k")
        self.assertIsNot(a, b)
        self.assertEqual(b.order_id, second_order.id)
        self.assertEqual(first_order.refunded(), Decimal("5.00"))
        self.assertEqual(second_order.refunded(), Decimal("5.00"))

    def test_invalid_keys_rejected(self):
        order = place_order(_cart())
        for key in [None, "", 1, ["k"], b"k"]:
            with self.subTest(key=key):
                with self.assertRaises(RefundError) as cm:
                    refund(order, Decimal("5"), key)
                self.assertEqual(str(cm.exception), KEY_MSG)
                self.assertEqual(order.refunded(), Decimal("0.00"))


def _mug_cart():
    cart = Cart()
    cart.add("MUG", 2)
    return cart  # total 55.58


class EmptyCartIdTest(unittest.TestCase):
    def test_failed_placement_creates_no_order(self):
        before = place_order(_cart())
        with self.assertRaises(ValueError) as cm:
            place_order(Cart())
        self.assertEqual(str(cm.exception), "cannot place an order for an empty cart")
        after = place_order(_cart())
        self.assertEqual(after.id, before.id + 1)


class LowPrecisionTest(unittest.TestCase):
    # Refund and order arithmetic runs under orders._MONEY, whatever the caller's precision.
    def test_refunds_are_exact_under_low_precision(self):
        order = place_order(_mug_cart())
        with localcontext(prec=3):
            for i, amount in enumerate(["8.03", "8.78", "8.41", "9.78", "9.08", "9.61", "1.33"]):
                refund(order, Decimal(amount), f"r{i}")
            with self.assertRaises(RefundError) as cm:
                refund(order, Decimal("0.58"), "over")
            self.assertEqual(str(cm.exception), EXCEEDS_MSG)
            self.assertEqual(order.refunded(), Decimal("55.02"))
            self.assertEqual(order.refundable(), Decimal("0.56"))

    def test_cents_amount_with_four_digits_accepted(self):
        order = place_order(_mug_cart())
        with localcontext(prec=3):
            record = refund(order, Decimal("31.77"), "k")
        self.assertEqual(record.amount, Decimal("31.77"))

    def test_full_total_refund_leaves_nothing_refundable(self):
        order = place_order(_mug_cart())
        with localcontext(prec=3):
            refund(order, order.total, "all")
            self.assertEqual(order.refundable(), Decimal("0"))
        self.assertEqual(order.refunded(), Decimal("55.58"))


class DecimalSubclassTest(unittest.TestCase):
    class Liar(Decimal):
        def as_tuple(self):
            return Decimal.as_tuple(Decimal("1.00"))

    def test_subclass_cannot_fake_whole_cents(self):
        order = place_order(_mug_cart())
        with self.assertRaises(RefundError) as cm:
            refund(order, self.Liar("1.005"), "k")
        self.assertEqual(str(cm.exception), CENTS_MSG)
        self.assertEqual(order.refunded(), Decimal("0.00"))

    def test_subclass_amount_stored_as_plain_decimal(self):
        order = place_order(_mug_cart())
        record = refund(order, self.Liar("1.00"), "k")
        self.assertIs(type(record.amount), Decimal)
        self.assertEqual(record.amount, Decimal("1.00"))


class ConcurrencyTest(unittest.TestCase):
    def _run(self, count, target):
        barrier = threading.Barrier(count)
        results = []

        def attempt(i):
            barrier.wait()
            results.append(target(i))

        threads = [threading.Thread(target=attempt, args=(i,)) for i in range(count)]
        for thread in threads:
            thread.start()
        for thread in threads:
            thread.join()
        return results

    def test_concurrent_refunds_cannot_exceed_total(self):
        order = place_order(_cart())  # 54.77 refundable

        def attempt(i):
            try:
                refund(order, Decimal("5.00"), f"k{i}")
                return True
            except RefundError:
                return False

        results = self._run(20, attempt)
        self.assertEqual(results.count(True), 10)  # 10 x 5.00 = 50.00; an 11th would exceed
        self.assertEqual(order.refunded(), Decimal("50.00"))

    def test_concurrent_retries_record_one_refund(self):
        order = place_order(_cart())
        results = self._run(10, lambda i: refund(order, Decimal("5.00"), "same"))
        self.assertTrue(all(r is results[0] for r in results))
        self.assertEqual(order.refunded(), Decimal("5.00"))


class FakeDecimalTest(unittest.TestCase):
    class Fake:
        __class__ = property(lambda self: Decimal)

    def test_fake_decimal_rejected_with_nothing_recorded(self):
        order = place_order(_mug_cart())
        with self.assertRaises(RefundError) as cm:
            refund(order, self.Fake(), "k")
        self.assertEqual(str(cm.exception), AMOUNT_MSG)
        self.assertEqual(order.refunded(), Decimal("0.00"))
        self.assertEqual(order.refundable(), Decimal("55.58"))

    def test_fake_decimal_does_not_consume_key(self):
        order = place_order(_mug_cart())
        with self.assertRaises(RefundError):
            refund(order, self.Fake(), "k")
        self.assertEqual(refund(order, Decimal("5"), "k").amount, Decimal("5.00"))


class PlaceOrderContextTest(unittest.TestCase):
    def test_total_ignores_caller_precision(self):
        self.assertEqual(place_order(_mug_cart()).total, Decimal("55.58"))
        with localcontext(prec=3):
            order = place_order(_mug_cart())
        self.assertIsInstance(order.total, Decimal)
        self.assertEqual(order.total, Decimal("55.58"))

    def test_total_ignores_caller_traps(self):
        with localcontext(traps=[Inexact, Rounded]):
            order = place_order(_mug_cart())
        self.assertEqual(order.total, Decimal("55.58"))


def _boom():
    raise RuntimeError("total failed")


class PlaceOrderIdTest(unittest.TestCase):
    def test_failed_total_does_not_consume_id(self):
        before = place_order(_cart())
        broken = _cart()
        broken.total = _boom
        with self.assertRaises(RuntimeError) as cm:
            place_order(broken)
        self.assertEqual(str(cm.exception), "total failed")
        after = place_order(_cart())
        self.assertEqual(after.id, before.id + 1)

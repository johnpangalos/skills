import sys
import threading
import time
import unittest
from dataclasses import FrozenInstanceError
from decimal import Context, Decimal, localcontext

from shop import orders
from shop.cart import Cart
from shop.orders import RefundError, place_order, refund

TOTAL = Decimal("54.77")  # BEAN-ETH x2 + FILTER, as in test_cart
NOT_DECIMAL = [5, 5.0, "5.00", True, None]
NOT_POSITIVE = [Decimal("0"), Decimal("-0"), Decimal("-1.00"), Decimal("-Infinity"),
                Decimal("NaN"), Decimal("sNaN"), Decimal("Infinity")]
NOT_WHOLE_CENTS = [Decimal("0.001"), Decimal("1.005")]
LOW_PRECISION = [3, 4]


def _cart(*skus):
    cart = Cart()
    for sku in skus:
        cart.add(sku)
    return cart


def _order():
    return place_order(_cart("BEAN-ETH", "BEAN-ETH", "FILTER"))


def _order_of(total):
    return orders.Order(id="order", total=Decimal(total))


class PlaceOrderTest(unittest.TestCase):
    def test_total_is_cart_total_as_decimal(self):
        cart = _cart("BEAN-ETH", "BEAN-ETH", "FILTER")
        order = place_order(cart)
        self.assertIsInstance(order.total, Decimal)
        self.assertEqual(order.total, cart.total())
        self.assertEqual(order.total, TOTAL)

    def test_total_survives_adding_items(self):
        cart = _cart("FILTER")
        total = cart.total()
        order = place_order(cart)
        cart.add("MUG")
        self.assertEqual(order.total, total)

    def test_total_survives_removing_all_items(self):
        cart = _cart("BEAN-ETH", "FILTER")
        total = cart.total()
        order = place_order(cart)
        cart.remove("BEAN-ETH")
        cart.remove("FILTER")
        self.assertEqual(order.total, total)

    def test_ids_are_unique(self):
        cart = _cart("FILTER")
        self.assertEqual(len({place_order(cart).id for _ in range(50)}), 50)

    def test_empty_cart_raises(self):
        with self.assertRaises(ValueError) as cm:
            place_order(Cart())
        self.assertIs(type(cm.exception), ValueError)
        self.assertEqual(str(cm.exception), "cannot place an order for an empty cart")


class RefundTest(unittest.TestCase):
    def assertUntouched(self, order, key):
        """No refund was recorded, and the key can still be used for a valid amount."""
        self.assertEqual(order.refunded(), Decimal("0.00"))
        refund(order, Decimal("1.00"), key)

    def test_refund_records_fields(self):
        order = _order()
        issued = refund(order, Decimal("5.00"), "k1")
        self.assertIsInstance(issued, orders.Refund)
        self.assertEqual(issued.order_id, order.id)
        self.assertEqual(issued.amount, Decimal("5.00"))
        self.assertEqual(issued.key, "k1")
        self.assertEqual(order.refunded(), Decimal("5.00"))
        self.assertEqual(order.refundable(), TOTAL - Decimal("5.00"))

    def test_refund_is_frozen(self):
        issued = refund(_order(), Decimal("5.00"), "k1")
        with self.assertRaises(FrozenInstanceError):
            issued.amount = Decimal("1.00")

    def test_refunded_starts_at_decimal_zero(self):
        order = _order()
        self.assertIs(type(order.refunded()), Decimal)
        self.assertEqual(order.refunded(), Decimal("0.00"))
        self.assertEqual(order.refundable(), TOTAL)

    def test_partial_refunds_sum(self):
        order = _order()
        refund(order, Decimal("10.00"), "k1")
        refund(order, Decimal("5.00"), "k2")
        self.assertEqual(order.refunded(), Decimal("15.00"))
        self.assertEqual(order.refundable(), TOTAL - Decimal("15.00"))

    def test_error_is_value_error(self):
        self.assertTrue(issubclass(RefundError, ValueError))

    def test_whole_cent_forms_accepted(self):
        for amount in [Decimal("1.100"), Decimal("1E+1")]:
            with self.subTest(amount=amount):
                order = _order()
                refund(order, amount, "k")
                self.assertEqual(order.refunded(), amount)

    def test_non_decimal_amount_rejected(self):
        for amount in NOT_DECIMAL:
            with self.subTest(amount=amount):
                order = _order()
                with self.assertRaises(RefundError) as cm:
                    refund(order, amount, "k")
                self.assertEqual(str(cm.exception), "amount must be a Decimal")
                self.assertUntouched(order, "k")

    def test_non_finite_or_non_positive_amount_rejected(self):
        for amount in NOT_POSITIVE:
            with self.subTest(amount=amount):
                order = _order()
                with self.assertRaises(RefundError) as cm:
                    refund(order, amount, "k")
                self.assertEqual(str(cm.exception), "amount must be finite and positive")
                self.assertUntouched(order, "k")

    def test_sub_cent_or_unrepresentable_amount_rejected(self):
        for amount in NOT_WHOLE_CENTS:
            with self.subTest(amount=amount):
                order = _order()
                with self.assertRaises(RefundError) as cm:
                    refund(order, amount, "k")
                self.assertEqual(str(cm.exception), "amount must be a whole number of cents")
                self.assertUntouched(order, "k")

    def test_amount_beyond_total_reports_exceeds(self):
        for amount in [Decimal("1E+40"), Decimal("1E+999999999")]:
            with self.subTest(amount=amount):
                order = _order()
                with self.assertRaises(RefundError) as cm:
                    refund(order, amount, "k")
                self.assertEqual(str(cm.exception), "refund exceeds refundable amount")
                self.assertEqual(order.refunded(), Decimal("0.00"))
                refund(order, Decimal("1.00"), "k")

    def test_exact_remaining_succeeds(self):
        order = _order()
        refund(order, TOTAL, "k")
        self.assertEqual(order.refundable(), Decimal("0.00"))
        self.assertEqual(order.refunded(), TOTAL)

    def test_one_cent_over_remaining_fails(self):
        order = _order()
        with self.assertRaises(RefundError) as cm:
            refund(order, TOTAL + Decimal("0.01"), "over")
        self.assertEqual(str(cm.exception), "refund exceeds refundable amount")
        refund(order, TOTAL - Decimal("0.01"), "a")
        with self.assertRaises(RefundError) as cm:
            refund(order, Decimal("0.02"), "b")
        self.assertEqual(str(cm.exception), "refund exceeds refundable amount")
        self.assertEqual(order.refunded(), TOTAL - Decimal("0.01"))
        refund(order, Decimal("0.01"), "b")
        self.assertEqual(order.refundable(), Decimal("0.00"))

    def test_new_key_after_full_refund_fails(self):
        order = _order()
        refund(order, TOTAL, "a")
        with self.assertRaises(RefundError) as cm:
            refund(order, Decimal("0.01"), "b")
        self.assertEqual(str(cm.exception), "refund exceeds refundable amount")
        self.assertEqual(order.refunded(), TOTAL)


class IdempotencyTest(unittest.TestCase):
    def test_same_key_same_amount_returns_same_refund(self):
        order = _order()
        first = refund(order, Decimal("5.00"), "k")
        second = refund(order, Decimal("5.00"), "k")
        self.assertIs(first, second)
        self.assertEqual(order.refunded(), Decimal("5.00"))

    def test_equal_decimal_amount_matches(self):
        order = _order()
        first = refund(order, Decimal("5"), "k")
        second = refund(order, Decimal("5.00"), "k")
        self.assertIs(first, second)
        self.assertEqual(order.refunded(), Decimal("5.00"))

    def test_replay_after_full_refund_returns_original(self):
        order = _order()
        first = refund(order, TOTAL, "k")
        second = refund(order, TOTAL, "k")
        self.assertIs(first, second)
        self.assertEqual(order.refunded(), TOTAL)

    def test_same_key_different_amount_rejected(self):
        order = _order()
        refund(order, Decimal("5.00"), "k")
        with self.assertRaises(RefundError) as cm:
            refund(order, Decimal("6.00"), "k")
        self.assertEqual(str(cm.exception), "key already used for a different amount")
        self.assertEqual(order.refunded(), Decimal("5.00"))

    def test_same_key_invalid_amount_rejected(self):
        order = _order()
        refund(order, Decimal("5.00"), "k")
        with self.assertRaises(RefundError) as cm:
            refund(order, 5.0, "k")
        self.assertEqual(str(cm.exception), "amount must be a Decimal")
        self.assertEqual(order.refunded(), Decimal("5.00"))

    def test_cap_failure_does_not_consume_key(self):
        order = _order()
        with self.assertRaises(RefundError) as cm:
            refund(order, TOTAL + Decimal("0.01"), "x")
        self.assertEqual(str(cm.exception), "refund exceeds refundable amount")
        issued = refund(order, Decimal("1.00"), "x")
        self.assertEqual(issued.amount, Decimal("1.00"))
        self.assertEqual(order.refunded(), Decimal("1.00"))

    def test_key_is_scoped_to_order(self):
        first_order = _order()
        second_order = _order()
        first = refund(first_order, Decimal("5"), "k")
        second = refund(second_order, Decimal("5"), "k")
        self.assertIsNot(first, second)
        self.assertEqual(second.order_id, second_order.id)
        self.assertEqual(second_order.refunded(), Decimal("5.00"))


class LowPrecisionTest(unittest.TestCase):
    def test_refunded_and_refundable_are_exact(self):
        for prec in LOW_PRECISION:
            with self.subTest(prec=prec):
                order = _order_of("1240.00")
                refund(order, Decimal("1234.04"), "a")
                with localcontext(Context(prec=prec)):
                    self.assertEqual(order.refunded(), Decimal("1234.04"))
                    self.assertEqual(order.refundable(), Decimal("5.96"))
                    with self.assertRaises(RefundError) as cm:
                        refund(order, Decimal("5.97"), "b")
                self.assertEqual(str(cm.exception), "refund exceeds refundable amount")
                self.assertEqual(order.refunded(), Decimal("1234.04"))

    def test_replay_returns_original(self):
        for prec in LOW_PRECISION:
            with self.subTest(prec=prec):
                order = _order_of("1240.00")
                first = refund(order, Decimal("1234.04"), "a")
                with localcontext(Context(prec=prec)):
                    second = refund(order, Decimal("1234.04"), "a")
                self.assertIs(first, second)
                self.assertEqual(order.refunded(), Decimal("1234.04"))

    def test_validation_matches_default(self):
        cases = [
            (NOT_DECIMAL, "amount must be a Decimal"),
            (NOT_POSITIVE, "amount must be finite and positive"),
            (NOT_WHOLE_CENTS, "amount must be a whole number of cents"),
            ([Decimal("1E+40"), Decimal("1E+999999999")], "refund exceeds refundable amount"),
        ]
        for prec in LOW_PRECISION:
            for amounts, message in cases:
                for amount in amounts:
                    with self.subTest(prec=prec, amount=amount):
                        order = _order()
                        with localcontext(Context(prec=prec)):
                            with self.assertRaises(RefundError) as cm:
                                refund(order, amount, "k")
                            self.assertEqual(str(cm.exception), message)
                        self.assertEqual(order.refunded(), Decimal("0.00"))
                        refund(order, Decimal("1.00"), "k")

    def test_refundable_is_exact_under_low_precision(self):
        for prec in LOW_PRECISION:
            with self.subTest(prec=prec):
                order = _order_of("1240.00")
                refund(order, Decimal("0.01"), "a")
                with localcontext(Context(prec=prec)):
                    self.assertEqual(order.refundable(), Decimal("1239.99"))
                    self.assertEqual(order.refunded(), Decimal("0.01"))

    def test_six_digit_refund_recorded_under_low_precision(self):
        for prec in LOW_PRECISION:
            with self.subTest(prec=prec):
                order = _order_of("1240.00")
                with localcontext(Context(prec=prec)):
                    issued = refund(order, Decimal("1234.04"), "a")
                self.assertEqual(issued.amount, Decimal("1234.04"))
                self.assertEqual(order.refunded(), Decimal("1234.04"))

    def test_huge_exponent_rejected_quickly(self):
        for prec in [28] + LOW_PRECISION:
            order = _order()
            with self.subTest(prec=prec), localcontext(Context(prec=prec)):
                start = time.perf_counter()
                with self.assertRaises(RefundError) as cm:
                    refund(order, Decimal("1E+999999999"), "k")
                self.assertLess(time.perf_counter() - start, 5.0)
                self.assertEqual(str(cm.exception), "refund exceeds refundable amount")
                self.assertEqual(order.refunded(), Decimal("0.00"))
                refund(order, Decimal("1.00"), "k")


class ConcurrencyTest(unittest.TestCase):
    def test_concurrent_refunds_never_exceed_total(self):
        order = _order_of("1.00")
        outcomes = []
        errors = []
        readings = []
        start = threading.Barrier(21)
        done = threading.Event()

        def refund_once(i):
            start.wait()
            try:
                refund(order, Decimal("0.10"), f"k{i}")
                outcomes.append("ok")
            except RefundError:
                outcomes.append("refused")
            except Exception as exc:
                errors.append(exc)

        def read_until_done():
            start.wait()
            while not done.is_set():
                try:
                    readings.append(order.refunded())
                except Exception as exc:
                    errors.append(exc)
                    return

        original = sys.getswitchinterval()
        sys.setswitchinterval(1e-6)
        try:
            workers = [threading.Thread(target=refund_once, args=(i,)) for i in range(20)]
            reader = threading.Thread(target=read_until_done)
            for thread in workers + [reader]:
                thread.start()
            for thread in workers:
                thread.join()
            done.set()
            reader.join()
        finally:
            sys.setswitchinterval(original)
        self.assertEqual(errors, [])
        self.assertEqual(outcomes.count("ok"), 10)
        self.assertEqual(outcomes.count("refused"), 10)
        self.assertEqual(order.refunded(), Decimal("1.00"))
        self.assertTrue(all(value <= order.total for value in readings))

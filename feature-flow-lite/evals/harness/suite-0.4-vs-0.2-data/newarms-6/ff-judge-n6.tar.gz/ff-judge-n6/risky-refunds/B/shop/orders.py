"""Orders and idempotent, capped partial refunds (in-memory store)."""

import itertools
import threading
from dataclasses import dataclass, field
from decimal import MAX_EMAX, MAX_PREC, MIN_EMIN, Context, Decimal, localcontext

from shop.money import CENT

_ORDER_IDS = itertools.count(1)
_REFUND_LOCK = threading.Lock()  # makes the key lookup, cap check and append atomic
_CENT_EXPONENT = CENT.as_tuple().exponent
_EXACT = Context(prec=MAX_PREC, Emax=MAX_EMAX, Emin=MIN_EMIN)


class RefundError(ValueError):
    pass


@dataclass
class Order:
    id: int
    total: Decimal
    refunds: list = field(default_factory=list)

    def refunded(self):
        with localcontext(_EXACT):
            return sum((record.amount for record in self.refunds), Decimal("0.00"))

    def refundable(self):
        with localcontext(_EXACT):
            return self.total - self.refunded()


@dataclass(frozen=True)
class Refund:
    order_id: int
    amount: Decimal
    key: str


def place_order(cart):
    """Snapshot the cart total into a new order."""
    if not cart.items:
        raise ValueError("cannot place an order from an empty cart")
    return Order(next(_ORDER_IDS), cart.total())


def refund(order, amount, key):
    """Refund amount against order. Replaying a key returns its original Refund."""
    _check_amount(amount)
    with _REFUND_LOCK:
        previous = next((record for record in order.refunds if record.key == key), None)
        if previous is not None:
            if previous.amount != amount:
                raise RefundError("key already used for a different amount")
            return previous
        if amount > order.refundable():
            raise RefundError("refund exceeds refundable amount")
        # Whole cents and no more than the total, so quantizing exactly can't round or raise.
        record = Refund(order.id, amount.quantize(CENT, context=_EXACT), key)
        order.refunds.append(record)
        return record


def _check_amount(amount):
    if not isinstance(amount, Decimal):
        raise RefundError("amount must be a Decimal")
    if not amount.is_finite():
        raise RefundError("amount must be finite")
    if amount <= 0:
        raise RefundError("amount must be greater than zero")
    if not _is_whole_cents(amount):
        raise RefundError("amount must be whole cents")


def _is_whole_cents(amount):
    """True when a finite positive Decimal has no fractional cents. Never rounds or raises."""
    _, digits, exponent = amount.as_tuple()
    if exponent >= _CENT_EXPONENT:
        return True
    # Digits past the cent position must be zero; trailing zeros such as the
    # last one in Decimal("1.230") are fine.
    first_past_cent = len(digits) + exponent - _CENT_EXPONENT
    return not any(digits[max(first_past_cent, 0):])

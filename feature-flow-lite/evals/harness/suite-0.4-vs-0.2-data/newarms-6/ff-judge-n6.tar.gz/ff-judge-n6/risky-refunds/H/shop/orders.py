"""Orders placed from a cart, with idempotent partial refunds (in-memory store)."""

import threading
from dataclasses import dataclass, field
from decimal import MAX_PREC, Context, Decimal, InvalidOperation, localcontext
from uuid import uuid4

from shop.money import CENT

# Money sums and differences are exact, whatever precision the caller has set.
_EXACT = Context(prec=MAX_PREC)

# Serializes the lookup, cap check and record in refund() across threads.
_REFUND_LOCK = threading.Lock()


class RefundError(ValueError):
    pass


@dataclass(frozen=True)
class Refund:
    order_id: str
    amount: Decimal
    key: str


@dataclass
class Order:
    id: str
    total: Decimal
    refunds: dict = field(default_factory=dict)  # key -> Refund

    def refunded(self):
        with localcontext(_EXACT):
            # Snapshot: a refund may be recorded by another thread while this sums.
            return sum((r.amount for r in list(self.refunds.values())), Decimal("0.00"))

    def refundable(self):
        with localcontext(_EXACT):
            return self.total - self.refunded()


def place_order(cart):
    """Snapshot the cart's total into a new Order."""
    if not cart.items:
        raise ValueError("cannot place an order for an empty cart")
    return Order(id=uuid4().hex, total=cart.total())


def refund(order, amount, key):
    """Refund amount from order. Repeating a key with the same amount returns the original Refund."""
    if not isinstance(amount, Decimal):
        raise RefundError("amount must be a Decimal")
    if not amount.is_finite() or amount <= 0:
        raise RefundError("amount must be finite and positive")
    with _REFUND_LOCK:
        previous = order.refunds.get(key)
        if previous is not None:
            if previous.amount != amount:
                raise RefundError("key already used for a different amount")
            return previous
        if amount > order.refundable():
            raise RefundError("refund exceeds refundable amount")
        try:
            cents = amount.quantize(CENT, context=_EXACT)
        except InvalidOperation:
            raise RefundError("amount must be a whole number of cents") from None
        if cents != amount:
            raise RefundError("amount must be a whole number of cents")
        issued = Refund(order.id, cents, key)
        order.refunds[key] = issued
        return issued

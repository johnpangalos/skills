"""Orders placed from carts, with idempotent partial refunds capped at the total."""

import threading
import uuid
from dataclasses import dataclass
from decimal import ROUND_HALF_UP, Context, Decimal, InvalidOperation, localcontext

from shop.money import to_cents

EXACT = Context(prec=28, rounding=ROUND_HALF_UP)  # refund math ignores the caller's context


class RefundError(ValueError):
    pass


@dataclass(frozen=True)
class Refund:
    order_id: str
    amount: Decimal
    key: object  # any hashable; compared with ==, so 1 and True are the same key


class Order:
    def __init__(self, total):
        self._id = uuid.uuid4().hex
        self._total = total
        self._refunds = {}  # key -> Refund
        self._lock = threading.RLock()  # reentrant: refund() calls refundable()

    @property
    def id(self):
        return self._id

    @property
    def total(self):
        return self._total

    @property
    def refunds(self):
        with self._lock:
            return tuple(self._refunds.values())

    def refunded(self):
        with self._lock, localcontext(EXACT):
            return sum((r.amount for r in self._refunds.values()), Decimal("0.00"))

    def refundable(self):
        with localcontext(EXACT):
            return self._total - self.refunded()


def place_order(cart):
    """Freeze the cart's current total into a new Order."""
    if not cart.items:
        raise ValueError("cannot place an order from an empty cart")
    return Order(cart.total())


def _whole_cents(amount):
    """Return amount as cents, or raise RefundError if it is not a positive whole-cent Decimal."""
    try:
        if not isinstance(amount, Decimal):
            raise TypeError
        amount = Decimal(amount)  # plain Decimal, so subclass overrides cannot affect the checks
    except TypeError:
        raise RefundError(f"invalid refund amount: {amount!r}") from None
    with localcontext(EXACT):
        if not amount.is_finite() or amount <= 0:
            raise RefundError(f"invalid refund amount: {amount!r}")
        try:
            cents = to_cents(amount)
        except InvalidOperation:
            raise RefundError(f"refund amount out of range: {amount!r}") from None
        if cents != amount:
            raise RefundError(f"refund amount is not whole cents: {amount!r}")
    return cents


def refund(order, amount, key):
    """Refund amount from order. A replayed key returns its original Refund."""
    cents = _whole_cents(amount)
    try:
        hash(key)
    except TypeError:
        raise RefundError(f"refund key must be hashable: {key!r}") from None
    with order._lock, localcontext(EXACT):
        existing = order._refunds.get(key)
        if existing is not None:
            if existing.amount != cents:
                raise RefundError(f"key {key!r} was already used for a different amount")
            return existing
        if cents > order.refundable():
            raise RefundError("refund exceeds the order's refundable balance")
        record = Refund(order.id, cents, key)
        order._refunds[key] = record
        return record

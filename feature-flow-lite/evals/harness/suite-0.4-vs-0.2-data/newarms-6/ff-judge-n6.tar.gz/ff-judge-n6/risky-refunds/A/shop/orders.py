"""Orders and idempotent, partial refunds."""

import uuid
from dataclasses import dataclass
from decimal import Decimal

from shop.money import CENT


class RefundError(ValueError):
    pass


@dataclass(frozen=True)
class Refund:
    order_id: str
    amount: Decimal
    key: str


class Order:
    def __init__(self, total):
        self.id = uuid.uuid4().hex
        self.total = total
        self._refunds = {}  # key -> Refund

    def refunded(self):
        return sum((r.amount for r in self._refunds.values()), Decimal("0.00"))

    def refundable(self):
        return self.total - self.refunded()


def place_order(cart):
    """Freeze a cart's current total into a new Order."""
    if not cart.items:
        raise ValueError("cannot place an order for an empty cart")
    return Order(cart.total())


def _is_whole_cents(amount):
    """True if a finite, positive Decimal has no fractional cents. Never raises."""
    exponent = amount.as_tuple().exponent
    if exponent >= -2:
        return True
    dropped = -2 - exponent  # digits below the cent place
    return not any(amount.as_tuple().digits[-dropped:])


def refund(order, amount, key):
    """Refund part of an order. A repeated key with the same amount returns the first Refund."""
    if not isinstance(amount, Decimal) or not amount.is_finite():
        raise RefundError("amount must be a finite Decimal")
    if amount <= 0:
        raise RefundError("amount must be positive")
    if not _is_whole_cents(amount):
        raise RefundError("amount must be whole cents")
    previous = order._refunds.get(key)
    if previous is not None:
        if previous.amount != amount:
            raise RefundError("key already used with a different amount")
        return previous
    if amount > order.refundable():
        raise RefundError("refund exceeds refundable amount")
    record = Refund(order.id, amount.quantize(CENT), key)
    order._refunds[key] = record
    return record

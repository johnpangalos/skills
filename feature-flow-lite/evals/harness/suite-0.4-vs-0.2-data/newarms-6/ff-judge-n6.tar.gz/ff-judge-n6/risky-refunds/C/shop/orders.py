"""Orders placed from a cart, with idempotent partial refunds."""

import uuid
from dataclasses import dataclass, field
from decimal import Decimal

from shop.money import CENT, to_cents


class RefundError(ValueError):
    pass


@dataclass(frozen=True)
class Refund:
    order_id: str
    amount: Decimal
    key: str


@dataclass
class Order:
    id: str
    total: Decimal
    refunds: list = field(default_factory=list)
    refunds_by_key: dict = field(default_factory=dict)

    def refunded(self):
        """Sum of the refunds issued against this order."""
        return sum((r.amount for r in self.refunds), Decimal("0.00"))

    def refundable(self):
        """Part of the total not yet refunded."""
        return self.total - self.refunded()


def place_order(cart):
    """Create an Order at the cart's current total."""
    if not cart.items:
        raise ValueError("cannot place an order for an empty cart")
    return Order(id=uuid.uuid4().hex, total=cart.total())


def refund(order, amount, key):
    """Refund amount from order; a repeated key returns the original Refund."""
    if not isinstance(amount, Decimal) or not amount.is_finite() or amount <= 0:
        raise RefundError("amount must be a finite Decimal above zero")
    prior = order.refunds_by_key.get(key)
    if prior is not None:
        if prior.amount != amount:
            raise RefundError("key was already used for a different amount")
        return prior
    if amount > order.refundable():
        raise RefundError("amount exceeds refundable balance")
    # Checked after the balance so a huge amount is rejected before quantize sees it.
    if amount != amount.quantize(CENT):
        raise RefundError("amount must be a whole number of cents")
    issued = Refund(order.id, to_cents(amount), key)
    order.refunds.append(issued)
    order.refunds_by_key[key] = issued
    return issued

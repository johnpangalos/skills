import dataclasses
import pathlib
import unittest
from decimal import Decimal

import shop.orders as orders
from shop.cart import Cart
from shop.orders import Refund, RefundError, place_order, refund

TOTAL = Decimal("48.00")  # 2 x BEAN-ETH: 37.00 + 7.95 shipping + 3.05 tax
README = pathlib.Path(__file__).resolve().parent.parent / "README.md"

# (hostile amount, exact error message)
NOT_DECIMAL_MSG = "amount must be a finite Decimal"
INVALID = [
    (5, NOT_DECIMAL_MSG),
    (5.0, NOT_DECIMAL_MSG),
    ("5.00", NOT_DECIMAL_MSG),
    (True, NOT_DECIMAL_MSG),
    (None, NOT_DECIMAL_MSG),
    (Decimal("NaN"), NOT_DECIMAL_MSG),
    (Decimal("sNaN"), NOT_DECIMAL_MSG),
    (Decimal("Infinity"), NOT_DECIMAL_MSG),
    (Decimal("-Infinity"), NOT_DECIMAL_MSG),
    (Decimal("0"), "amount must be positive"),
    (Decimal("-0"), "amount must be positive"),
    (Decimal("-1.00"), "amount must be positive"),
    (Decimal("0.001"), "amount must be whole cents"),
    (Decimal("1.005"), "amount must be whole cents"),
]


def _cart():
    cart = Cart()
    cart.add("BEAN-ETH", 2)
    return cart


def _order():
    return place_order(_cart())


class ModuleTest(unittest.TestCase):
    def test_one_line_docstring(self):
        self.assertTrue(orders.__doc__)
        self.assertNotIn("\n", orders.__doc__.strip())

    def test_refund_error_is_value_error(self):
        self.assertTrue(issubclass(RefundError, ValueError))

    def test_readme_names_orders_and_refunds(self):
        opening = README.read_text().split("\n\n")[1]  # [0] is the "# shop" heading
        self.assertIn("orders", opening)
        self.assertIn("refunds", opening)


class PlaceOrderTest(unittest.TestCase):
    def test_total_is_cart_total(self):
        self.assertEqual(_order().total, TOTAL)

    def test_total_frozen_when_cart_changes_after_placing(self):
        cart = _cart()
        order = place_order(cart)
        cart.add("MUG")
        self.assertEqual(order.total, TOTAL)
        self.assertNotEqual(cart.total(), TOTAL)

    def test_ids_are_unique(self):
        cart = _cart()
        ids = {place_order(cart).id for _ in range(1000)}
        self.assertEqual(len(ids), 1000)

    def test_empty_cart_raises(self):
        with self.assertRaises(ValueError) as cm:
            place_order(Cart())
        self.assertEqual(str(cm.exception), "cannot place an order for an empty cart")

    def test_cart_with_only_removed_item_raises(self):
        cart = _cart()
        cart.remove("BEAN-ETH")
        with self.assertRaises(ValueError) as cm:
            place_order(cart)
        self.assertEqual(str(cm.exception), "cannot place an order for an empty cart")


class RefundedTest(unittest.TestCase):
    def test_new_order_has_nothing_refunded(self):
        order = _order()
        self.assertEqual(str(order.refunded()), "0.00")
        self.assertEqual(str(order.refundable()), "48.00")

    def test_refundable_tracks_refunds_in_cents(self):
        order = _order()
        refund(order, Decimal("10.00"), "a")
        self.assertEqual(str(order.refunded()), "10.00")
        self.assertEqual(str(order.refundable()), "38.00")


class RefundValidationTest(unittest.TestCase):
    def test_invalid_amounts_raise_and_change_nothing(self):
        order = _order()
        for amount, message in INVALID + [(Decimal("1E+40"), "refund exceeds refundable amount")]:
            with self.subTest(amount=repr(amount)):
                with self.assertRaises(RefundError) as cm:
                    refund(order, amount, "k")
                self.assertEqual(str(cm.exception), message)
                self.assertEqual(str(order.refunded()), "0.00")
        # the key was never recorded, so a valid retry with it succeeds
        self.assertEqual(refund(order, TOTAL, "k").amount, TOTAL)

    def test_whole_cents_with_trailing_zeros_accepted(self):
        order = _order()
        self.assertEqual(refund(order, Decimal("1.500"), "a").amount, Decimal("1.50"))
        self.assertEqual(refund(order, Decimal("1.5"), "b").amount, Decimal("1.50"))
        self.assertEqual(str(order.refunded()), "3.00")


class RefundLimitTest(unittest.TestCase):
    def test_total_plus_one_cent_rejected(self):
        order = _order()
        with self.assertRaises(RefundError) as cm:
            refund(order, Decimal("48.01"), "k")
        self.assertEqual(str(cm.exception), "refund exceeds refundable amount")
        self.assertEqual(str(order.refunded()), "0.00")

    def test_partials_can_repeat_and_overshoot_is_rejected_without_recording_key(self):
        order = _order()
        refund(order, Decimal("40.00"), "a")
        with self.assertRaises(RefundError) as cm:
            refund(order, Decimal("8.01"), "b")
        self.assertEqual(str(cm.exception), "refund exceeds refundable amount")
        self.assertEqual(str(order.refunded()), "40.00")
        self.assertEqual(str(order.refundable()), "8.00")
        retry = refund(order, Decimal("8.00"), "b")
        self.assertEqual(retry.key, "b")
        self.assertEqual(str(order.refunded()), "48.00")

    def test_exact_remaining_succeeds_and_leaves_nothing(self):
        order = _order()
        refund(order, Decimal("30.00"), "a")
        refund(order, Decimal("18.00"), "b")
        self.assertEqual(str(order.refundable()), "0.00")

    def test_new_key_after_full_refund_rejected(self):
        order = _order()
        refund(order, TOTAL, "a")
        with self.assertRaises(RefundError) as cm:
            refund(order, Decimal("0.01"), "b")
        self.assertEqual(str(cm.exception), "refund exceeds refundable amount")
        self.assertEqual(str(order.refunded()), "48.00")


class IdempotencyTest(unittest.TestCase):
    def test_replay_returns_same_object_and_changes_nothing(self):
        order = _order()
        first = refund(order, Decimal("10.00"), "k")
        second = refund(order, Decimal("10.00"), "k")
        self.assertIs(second, first)
        self.assertEqual(str(order.refunded()), "10.00")

    def test_replay_compares_numerically(self):
        order = _order()
        first = refund(order, Decimal("5.5"), "k")
        self.assertIs(refund(order, Decimal("5.50"), "k"), first)
        self.assertEqual(str(order.refunded()), "5.50")

    def test_replay_after_order_fully_refunded(self):
        order = _order()
        first = refund(order, TOTAL, "k")
        self.assertIs(refund(order, TOTAL, "k"), first)
        self.assertEqual(str(order.refunded()), "48.00")

    def test_same_key_on_other_order_is_independent(self):
        cart = _cart()
        first_order = place_order(cart)
        second_order = place_order(cart)
        first = refund(first_order, Decimal("5.00"), "k")
        second = refund(second_order, Decimal("5.00"), "k")
        self.assertIsNot(second, first)
        self.assertEqual(second.order_id, second_order.id)
        self.assertEqual(str(second_order.refunded()), "5.00")

    def test_same_key_different_amount_raises(self):
        order = _order()
        refund(order, Decimal("10.00"), "k")
        with self.assertRaises(RefundError) as cm:
            refund(order, Decimal("11.00"), "k")
        self.assertEqual(str(cm.exception), "key already used with a different amount")
        self.assertEqual(str(order.refunded()), "10.00")

    def test_same_key_invalid_amount_raises(self):
        order = _order()
        refund(order, Decimal("10.00"), "k")
        for amount, message in INVALID:
            with self.subTest(amount=repr(amount)):
                with self.assertRaises(RefundError) as cm:
                    refund(order, amount, "k")
                self.assertEqual(str(cm.exception), message)
        self.assertEqual(str(order.refunded()), "10.00")


class RefundRecordTest(unittest.TestCase):
    def test_fields(self):
        order = _order()
        record = refund(order, Decimal("10.00"), "k")
        self.assertIsInstance(record, Refund)
        self.assertEqual(record.order_id, order.id)
        self.assertEqual(record.amount, Decimal("10.00"))
        self.assertEqual(record.key, "k")

    def test_immutable(self):
        record = refund(_order(), Decimal("10.00"), "k")
        with self.assertRaises(dataclasses.FrozenInstanceError):
            record.amount = Decimal("1.00")

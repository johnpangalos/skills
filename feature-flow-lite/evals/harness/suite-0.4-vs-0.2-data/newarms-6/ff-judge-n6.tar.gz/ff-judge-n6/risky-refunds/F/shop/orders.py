"""Orders and idempotent, capped partial refunds (in-memory)."""

import threading
import uuid
from dataclasses import dataclass
from decimal import Decimal, InvalidOperation

from shop.money import to_cents

_refund_lock = threading.Lock()  # guards replay lookup, cap check and write


class RefundError(ValueError):
    pass


@dataclass(frozen=True)
class Refund:
    order_id: str
    amount: Decimal
    key: object


class Order:
    def __init__(self, total):
        self.id = uuid.uuid4().hex
        self._total = total
        self._refunds = {}  # key -> Refund, in the order they were made

    @property
    def total(self):
        return self._total

    @property
    def refunds(self):
        return tuple(self._refunds.values())

    def refunded(self):
        """Sum of this order's refunds."""
        return sum((r.amount for r in self._refunds.values()), Decimal("0.00"))

    def refundable(self):
        """Amount still open to refund."""
        return self.total - self.refunded()


def place_order(cart):
    """Create an Order from a non-empty cart, snapshotting its total."""
    if not cart.items:
        raise ValueError("cannot place an order for an empty cart")
    return Order(cart.total())


def _require_amount(amount):
    """Return amount as a plain Decimal, or raise RefundError unless it is a positive, finite, whole-cent value."""
    if not isinstance(amount, Decimal):
        raise RefundError("amount must be a Decimal")
    amount = Decimal(amount)  # drop subclass overrides of comparisons
    if not amount.is_finite():
        raise RefundError("amount must be finite")
    if amount <= 0:
        raise RefundError("amount must be positive")
    try:
        whole_cents = amount == to_cents(amount)
    except InvalidOperation:  # too many digits for the decimal context
        raise RefundError("amount is out of range") from None
    if not whole_cents:
        raise RefundError("amount must be whole cents")
    return amount


def _require_hashable(key):
    """Raise RefundError unless key can be used as a dict key."""
    try:
        hash(key)
    except TypeError:
        raise RefundError("key must be hashable") from None


def refund(order, amount, key):
    """Refund part of an order; a repeated key returns its original Refund."""
    amount = _require_amount(amount)
    _require_hashable(key)
    with _refund_lock:
        previous = order._refunds.get(key)
        if previous is not None:
            if previous.amount != amount:
                raise RefundError("key reused with a different amount")
            return previous
        if amount > order.refundable():
            raise RefundError("refund exceeds refundable balance")
        record = Refund(order.id, amount, key)
        order._refunds[key] = record
        return record

import { describe, expect, it } from "vitest";
import { idSegment } from "./ids";

describe("idSegment", () => {
  it("produces only letters, digits and hyphens for hostile values", () => {
    for (const value of ["my tab", "a/b (c)", 'quote"s', "ȁ", "<x>", "a\nb"]) {
      expect(idSegment(value)).toMatch(/^[A-Za-z0-9_-]+$/);
    }
  });

  it("keeps values that look like escapes distinct from the values they escape", () => {
    const values = ["a b", "a_20", "a_20_", "a(", "a_28_", "a 1", "a_20_1", "a_", "_"];
    expect(new Set(values.map(idSegment)).size).toBe(values.length);
  });

  it("is injective over generated strings", () => {
    // Deterministic pseudo-random strings built from characters that collide when escaped.
    const alphabet = ["a", "b", " ", "_", "-", "(", "1", "2", "0", "ȁ"];
    let seed = 42;
    const next = () => {
      seed = (seed * 1103515245 + 12345) & 0x7fffffff;
      return seed;
    };
    const seen = new Map<string, string>();
    for (let sample = 0; sample < 3000; sample++) {
      const length = next() % 7;
      let value = "";
      for (let index = 0; index < length; index++) value += alphabet[next() % alphabet.length];
      const segment = idSegment(value);
      const previous = seen.get(segment);
      expect(previous === undefined || previous === value).toBe(true);
      seen.set(segment, value);
    }
  });
});

import { fireEvent, render, screen, within } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { describe, expect, it, vi } from "vitest";
import { renderToStaticMarkup } from "react-dom/server";
import { Tab, TabList, TabPanel, Tabs, type TabsProps } from "./Tabs";

const THREE = ["one", "two", "three"];

// One Tab and one TabPanel per value; the tab and panel text is the value.
function tabsOf(values: string[], props: TabsProps = {}, disabled: string[] = []) {
  return (
    <Tabs {...props}>
      <TabList aria-label="Sections">
        {values.map((value) => (
          <Tab key={value} value={value} disabled={disabled.includes(value)}>
            {value}
          </Tab>
        ))}
      </TabList>
      {values.map((value) => (
        <TabPanel key={value} value={value}>
          {`panel ${value}`}
        </TabPanel>
      ))}
    </Tabs>
  );
}

const tab = (name: string) => screen.getByRole("tab", { name });

describe("Tabs structure and ARIA (T1)", () => {
  it("gives TabList role tablist with the aria-label", () => {
    render(tabsOf(THREE));
    expect(screen.getByRole("tablist", { name: "Sections" })).toBeInTheDocument();
  });

  it("accepts aria-labelledby on TabList", () => {
    render(
      <>
        <h2 id="sections-heading">Sections</h2>
        <Tabs>
          <TabList aria-labelledby="sections-heading">
            <Tab value="a">A</Tab>
          </TabList>
          <TabPanel value="a">panel a</TabPanel>
        </Tabs>
      </>,
    );
    expect(screen.getByRole("tablist", { name: "Sections" })).toBeInTheDocument();
  });

  it("renders each Tab as a button with role tab and aria-selected", () => {
    render(tabsOf(THREE, { defaultValue: "two" }, ["three"]));
    const tabs = screen.getAllByRole("tab");
    expect(tabs).toHaveLength(3);
    for (const element of tabs) {
      expect(element.tagName).toBe("BUTTON");
      expect(element).toHaveAttribute("type", "button");
    }
    expect(tab("two")).toHaveAttribute("aria-selected", "true");
    expect(tab("one")).toHaveAttribute("aria-selected", "false");
  });

  it("links a Tab to its panel and the panel back to the Tab", () => {
    render(tabsOf(THREE));
    const panel = screen.getByRole("tabpanel", { name: "one" });
    expect(tab("one")).toHaveAttribute("aria-controls", panel.id);
    expect(panel).toHaveAttribute("aria-labelledby", tab("one").id);
    expect(panel).toHaveAttribute("tabindex", "0");
  });

  it("renders unselected panels with the hidden attribute", () => {
    render(tabsOf(THREE));
    const two = document.getElementById(tab("two").getAttribute("aria-controls") ?? "missing");
    expect(two).toHaveAttribute("aria-labelledby", tab("two").id);
    expect(two).toHaveAttribute("hidden");
    expect(two).not.toBeVisible();
  });

  it("omits aria-controls when a Tab has no matching TabPanel", () => {
    render(
      <Tabs defaultValue="ghost">
        <TabList aria-label="Sections">
          <Tab value="ghost">Ghost</Tab>
        </TabList>
      </Tabs>,
    );
    expect(tab("Ghost")).not.toHaveAttribute("aria-controls");
  });

  it("omits aria-labelledby when a TabPanel has no matching Tab", () => {
    render(
      <Tabs>
        <TabList aria-label="Sections">
          <Tab value="a">A</Tab>
        </TabList>
        <TabPanel value="b">panel b</TabPanel>
      </Tabs>,
    );
    expect(screen.getByRole("tabpanel", { hidden: true })).not.toHaveAttribute("aria-labelledby");
  });

  it("builds whitespace-free ids for values with spaces and special characters", () => {
    const values = ["my tab", "a/b (c)", "a_20", "a b", 'quote"s'];
    render(
      <Tabs defaultValue="my tab">
        <TabList aria-label="Sections">
          {values.map((value) => (
            <Tab key={value} value={value}>
              {value}
            </Tab>
          ))}
        </TabList>
        {values.map((value) => (
          <TabPanel key={value} value={value}>
            {`panel ${value}`}
          </TabPanel>
        ))}
      </Tabs>,
    );
    const ids: string[] = [];
    for (const value of values) {
      const element = tab(value);
      expect(element.id).not.toMatch(/\s/);
      const panel = document.getElementById(element.getAttribute("aria-controls") ?? "missing");
      expect(panel).toHaveAttribute("role", "tabpanel");
      expect(panel).toHaveAttribute("aria-labelledby", element.id);
      ids.push(element.id, panel!.id);
    }
    expect(new Set(ids).size).toBe(ids.length);
  });

  it("keeps ids unique and references inside each instance when two are on one page", () => {
    const Simple = () => (
      <Tabs defaultValue="a">
        <TabList aria-label="Sections">
          <Tab value="a">A</Tab>
          <Tab value="b">B</Tab>
        </TabList>
        <TabPanel value="a">panel a</TabPanel>
        <TabPanel value="b">panel b</TabPanel>
      </Tabs>
    );
    render(
      <>
        <Simple />
        <Simple />
      </>,
    );
    const ids = Array.from(document.querySelectorAll("[id]"), (element) => element.id);
    expect(new Set(ids).size).toBe(ids.length);
    for (const list of screen.getAllByRole("tablist")) {
      const root = list.parentElement!;
      const a = within(root).getByRole("tab", { name: "A" });
      expect(within(root).getByRole("tabpanel")).toBe(
        document.getElementById(a.getAttribute("aria-controls")!),
      );
    }
  });

  it("forwards className, style and data attributes to the root, list, tab and panel", () => {
    render(
      <Tabs className="root-class" data-kind="root">
        <TabList aria-label="Sections" className="list-class" data-kind="list">
          <Tab value="a" className="tab-class" data-kind="tab" style={{ color: "red" }}>
            A
          </Tab>
        </TabList>
        <TabPanel value="a" className="panel-class" data-kind="panel">
          panel a
        </TabPanel>
      </Tabs>,
    );
    const list = screen.getByRole("tablist");
    expect(list.parentElement).toHaveClass("root-class");
    expect(list.parentElement).toHaveAttribute("data-kind", "root");
    expect(list).toHaveClass("list-class");
    expect(list).toHaveAttribute("data-kind", "list");
    expect(tab("A")).toHaveClass("tab-class");
    expect(tab("A")).toHaveAttribute("data-kind", "tab");
    expect(tab("A").style.color).toBe("red");
    expect(screen.getByRole("tabpanel")).toHaveClass("panel-class");
    expect(screen.getByRole("tabpanel")).toHaveAttribute("data-kind", "panel");
  });
});

describe("Tabs selection (T2)", () => {
  it("selects the defaultValue tab when uncontrolled", () => {
    render(tabsOf(THREE, { defaultValue: "two" }));
    expect(tab("two")).toHaveAttribute("aria-selected", "true");
    expect(tab("one")).toHaveAttribute("aria-selected", "false");
  });

  it("selects the first enabled tab when there is no defaultValue", () => {
    render(tabsOf(THREE, {}, ["one"]));
    expect(tab("two")).toHaveAttribute("aria-selected", "true");
    expect(tab("one")).toHaveAttribute("aria-selected", "false");
  });

  it("calls onValueChange and updates selection when a tab is clicked (uncontrolled)", async () => {
    const user = userEvent.setup();
    const onValueChange = vi.fn();
    render(tabsOf(THREE, { onValueChange }));
    await user.click(tab("three"));
    expect(onValueChange).toHaveBeenCalledTimes(1);
    expect(onValueChange).toHaveBeenCalledWith("three");
    expect(tab("three")).toHaveAttribute("aria-selected", "true");
  });

  it("follows the value prop when controlled", () => {
    const { rerender } = render(tabsOf(THREE, { value: "one" }));
    expect(tab("one")).toHaveAttribute("aria-selected", "true");
    rerender(tabsOf(THREE, { value: "three" }));
    expect(tab("three")).toHaveAttribute("aria-selected", "true");
    expect(tab("one")).toHaveAttribute("aria-selected", "false");
  });

  it("keeps the controlled selection when the parent does not update value", async () => {
    const user = userEvent.setup();
    const onValueChange = vi.fn();
    render(tabsOf(THREE, { value: "one", onValueChange }));
    await user.click(tab("two"));
    expect(onValueChange).toHaveBeenCalledWith("two");
    expect(tab("one")).toHaveAttribute("aria-selected", "true");
    expect(tab("two")).toHaveAttribute("aria-selected", "false");
  });

  it("falls back to the first enabled tab when defaultValue names a disabled tab", () => {
    render(tabsOf(THREE, { defaultValue: "two" }, ["two"]));
    expect(tab("one")).toHaveAttribute("aria-selected", "true");
    expect(tab("one")).toHaveAttribute("tabindex", "0");
    expect(tab("two")).toHaveAttribute("tabindex", "-1");
  });

  it("falls back to the first enabled tab when defaultValue names no tab", () => {
    render(tabsOf(THREE, { defaultValue: "missing" }));
    expect(tab("one")).toHaveAttribute("aria-selected", "true");
    expect(tab("one")).toHaveAttribute("tabindex", "0");
  });

  it("renders without throwing when every tab is disabled", () => {
    expect(() => render(tabsOf(THREE, { defaultValue: "two" }, THREE))).not.toThrow();
    for (const element of screen.getAllByRole("tab")) {
      expect(element).toHaveAttribute("tabindex", "-1");
      expect(element).toHaveAttribute("aria-selected", "false");
    }
  });
});

describe("Tabs roving tabindex (T3)", () => {
  it("gives tabIndex 0 only to the selected tab", () => {
    render(tabsOf(THREE, { defaultValue: "two" }));
    expect(tab("one")).toHaveAttribute("tabindex", "-1");
    expect(tab("two")).toHaveAttribute("tabindex", "0");
    expect(tab("three")).toHaveAttribute("tabindex", "-1");
  });

  it("moves Tab from the selected tab to the selected panel", async () => {
    const user = userEvent.setup();
    render(tabsOf(THREE));
    await user.tab();
    expect(tab("one")).toHaveFocus();
    await user.tab();
    expect(screen.getByRole("tabpanel", { name: "one" })).toHaveFocus();
  });
});

describe("Tabs keyboard (T4)", () => {
  it("ArrowRight moves focus to the next tab and selects it", async () => {
    const user = userEvent.setup();
    const onValueChange = vi.fn();
    render(tabsOf(THREE, { onValueChange }));
    await user.click(tab("one"));
    await user.keyboard("{ArrowRight}");
    expect(tab("two")).toHaveFocus();
    expect(tab("two")).toHaveAttribute("aria-selected", "true");
    expect(onValueChange).toHaveBeenLastCalledWith("two");
  });

  it("ArrowLeft from the first tab wraps to the last", async () => {
    const user = userEvent.setup();
    render(tabsOf(THREE));
    await user.click(tab("one"));
    await user.keyboard("{ArrowLeft}");
    expect(tab("three")).toHaveFocus();
  });

  it("ArrowRight from the last tab wraps to the first", async () => {
    const user = userEvent.setup();
    render(tabsOf(THREE));
    await user.click(tab("three"));
    await user.keyboard("{ArrowRight}");
    expect(tab("one")).toHaveFocus();
  });

  it("ArrowRight skips a disabled tab", async () => {
    const user = userEvent.setup();
    render(tabsOf(THREE, {}, ["two"]));
    await user.click(tab("one"));
    await user.keyboard("{ArrowRight}");
    expect(tab("three")).toHaveFocus();
  });

  it("ArrowLeft skips a disabled tab", async () => {
    const user = userEvent.setup();
    render(tabsOf(THREE, {}, ["two"]));
    await user.click(tab("three"));
    await user.keyboard("{ArrowLeft}");
    expect(tab("one")).toHaveFocus();
  });

  it("Home and End move to the first and last tabs", async () => {
    const user = userEvent.setup();
    render(tabsOf(THREE));
    await user.click(tab("two"));
    await user.keyboard("{End}");
    expect(tab("three")).toHaveFocus();
    await user.keyboard("{Home}");
    expect(tab("one")).toHaveFocus();
  });

  it("Home and End skip disabled end tabs", async () => {
    const user = userEvent.setup();
    render(tabsOf(THREE, {}, ["one"]));
    await user.click(tab("two"));
    await user.keyboard("{Home}");
    expect(tab("two")).toHaveFocus();
    await user.keyboard("{End}");
    expect(tab("three")).toHaveFocus();
  });

  it("prevents arrow keys but not other keys", () => {
    render(tabsOf(THREE));
    expect(fireEvent.keyDown(tab("one"), { key: "a" })).toBe(true);
    expect(fireEvent.keyDown(tab("one"), { key: "Tab" })).toBe(true);
    expect(fireEvent.keyDown(tab("one"), { key: "ArrowRight" })).toBe(false);
  });

  it("selects an enabled tab on click and ignores a disabled tab", async () => {
    const user = userEvent.setup();
    const onValueChange = vi.fn();
    render(tabsOf(THREE, { onValueChange }, ["two"]));
    expect(tab("two")).toHaveAttribute("aria-disabled", "true");
    await user.click(tab("two"));
    expect(onValueChange).not.toHaveBeenCalled();
    expect(tab("two")).toHaveAttribute("aria-selected", "false");
    await user.click(tab("three"));
    expect(onValueChange).toHaveBeenCalledWith("three");
    expect(tab("three")).toHaveAttribute("aria-selected", "true");
  });

  it("keeps focus on the only enabled tab when arrows are pressed", async () => {
    const user = userEvent.setup();
    const onValueChange = vi.fn();
    render(tabsOf(THREE, { onValueChange }, ["two", "three"]));
    await user.click(tab("one"));
    await user.keyboard("{ArrowRight}{ArrowLeft}{End}{Home}");
    expect(tab("one")).toHaveFocus();
    expect(onValueChange).not.toHaveBeenCalled();
  });

  it("wraps past disabled tabs at both ends", async () => {
    const user = userEvent.setup();
    render(
      <Tabs defaultValue="b">
        <TabList aria-label="Sections">
          <Tab value="a" disabled>
            a
          </Tab>
          <Tab value="b">b</Tab>
          <Tab value="c">c</Tab>
          <Tab value="d" disabled>
            d
          </Tab>
        </TabList>
      </Tabs>,
    );
    await user.click(tab("b"));
    await user.keyboard("{ArrowLeft}");
    expect(tab("c")).toHaveFocus();
    await user.keyboard("{ArrowRight}");
    expect(tab("b")).toHaveFocus();
  });

  it("follows DOM order for tabs added after mount", async () => {
    const user = userEvent.setup();
    const { rerender } = render(tabsOf(["one", "three"]));
    await user.click(tab("one"));
    rerender(tabsOf(THREE));
    await user.keyboard("{ArrowRight}");
    expect(tab("two")).toHaveFocus();
  });
});

describe("Tabs controlled keyboard (T5)", () => {
  it("still calls onValueChange with the next value while the parent keeps the old value", async () => {
    const user = userEvent.setup();
    const onValueChange = vi.fn();
    render(tabsOf(THREE, { value: "one", onValueChange }));
    await user.click(tab("one"));
    await user.keyboard("{ArrowRight}");
    expect(onValueChange).toHaveBeenLastCalledWith("two");
    expect(tab("two")).toHaveFocus();
    expect(tab("one")).toHaveAttribute("aria-selected", "true");
    expect(tab("two")).toHaveAttribute("aria-selected", "false");
  });
});

describe("Nested Tabs", () => {
  it("keeps inner arrow keys inside the inner tablist", async () => {
    const user = userEvent.setup();
    const onOuter = vi.fn();
    const onInner = vi.fn();
    render(
      <Tabs defaultValue="a" onValueChange={onOuter}>
        <TabList aria-label="outer">
          <Tab value="a">Outer A</Tab>
          <Tab value="b">Outer B</Tab>
        </TabList>
        <TabPanel value="a">
          <Tabs defaultValue="x" onValueChange={onInner}>
            <TabList aria-label="inner">
              <Tab value="x">Inner X</Tab>
              <Tab value="y">Inner Y</Tab>
            </TabList>
            <TabPanel value="x">panel x</TabPanel>
            <TabPanel value="y">panel y</TabPanel>
          </Tabs>
        </TabPanel>
        <TabPanel value="b">panel b</TabPanel>
      </Tabs>,
    );
    await user.click(tab("Inner X"));
    await user.keyboard("{ArrowRight}");
    expect(tab("Inner Y")).toHaveFocus();
    expect(tab("Inner Y")).toHaveAttribute("aria-selected", "true");
    expect(tab("Outer A")).toHaveAttribute("aria-selected", "true");
    expect(onOuter).not.toHaveBeenCalled();
    expect(onInner).toHaveBeenCalledWith("y");

    await user.click(tab("Outer A"));
    await user.keyboard("{ArrowRight}");
    expect(tab("Outer B")).toHaveFocus();
    expect(tab("Outer B")).toHaveAttribute("aria-selected", "true");
    expect(onOuter).toHaveBeenCalledWith("b");
    expect(onInner).toHaveBeenCalledTimes(1);
  });
});

describe("Tabs fallback order and first render (T2 and T4 regressions)", () => {
  it("selects the first enabled tab in DOM order when a tab is inserted before the fallback", () => {
    const { rerender } = render(tabsOf(["b"]));
    expect(tab("b")).toHaveAttribute("aria-selected", "true");
    rerender(tabsOf(["a", "b"]));
    expect(tab("a")).toHaveAttribute("aria-selected", "true");
    expect(tab("a")).toHaveAttribute("tabindex", "0");
    expect(tab("b")).toHaveAttribute("aria-selected", "false");
    expect(tab("b")).toHaveAttribute("tabindex", "-1");
  });

  it("keeps a tab the user selected when a tab is inserted before it", async () => {
    const user = userEvent.setup();
    const { rerender } = render(tabsOf(["b", "c"]));
    await user.click(tab("c"));
    rerender(tabsOf(["a", "b", "c"]));
    expect(tab("c")).toHaveAttribute("aria-selected", "true");
    expect(tab("a")).toHaveAttribute("aria-selected", "false");
  });

  it("selects the first enabled tab in DOM order after tabs are reordered without mounting", () => {
    const { rerender } = render(tabsOf(["a", "b"]));
    expect(tab("a")).toHaveAttribute("aria-selected", "true");
    rerender(tabsOf(["b", "a"]));
    expect(tab("b")).toHaveAttribute("aria-selected", "true");
    expect(tab("a")).toHaveAttribute("aria-selected", "false");
  });

  it("selects the first enabled tab in DOM order after the fallback tab is removed", () => {
    const { rerender } = render(tabsOf(["a", "b", "c"]));
    expect(tab("a")).toHaveAttribute("aria-selected", "true");
    rerender(tabsOf(["b", "c"]));
    expect(tab("b")).toHaveAttribute("aria-selected", "true");
    expect(tab("b")).toHaveAttribute("tabindex", "0");
  });

  it("marks the requested tab selected in the first render, before effects run", () => {
    const html = renderToStaticMarkup(tabsOf(THREE, { defaultValue: "two" }));
    const container = document.createElement("div");
    container.innerHTML = html;
    const selected = container.querySelector('[role="tab"][aria-selected="true"]');
    expect(selected?.textContent).toBe("two");
    expect(selected).toHaveAttribute("tabindex", "0");
  });
});

const FOCUSABLE_SELECTOR = [
  "a[href]",
  "button",
  "input",
  "select",
  "textarea",
  "iframe",
  "summary",
  '[contenteditable]:not([contenteditable="false" i])',
  "[tabindex]",
].join(",");

/**
 * Elements inside `container` that Tab can reach, in DOM order. Uses attributes only
 * (disabled, negative tabindex, hidden and inert ancestors), never layout, so it works in jsdom.
 */
export function getTabbableElements(container: HTMLElement): HTMLElement[] {
  return Array.from(container.querySelectorAll<HTMLElement>(FOCUSABLE_SELECTOR)).filter(isTabbable);
}

function isTabbable(element: HTMLElement): boolean {
  if (element.matches(":disabled, input[type=hidden]")) return false;
  const tabIndex = element.getAttribute("tabindex");
  if (tabIndex !== null && Number(tabIndex) < 0) return false;
  return element.closest("[hidden], [inert]") === null;
}

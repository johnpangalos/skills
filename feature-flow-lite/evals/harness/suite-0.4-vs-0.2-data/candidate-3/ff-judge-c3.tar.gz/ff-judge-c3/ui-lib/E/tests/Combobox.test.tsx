import { useState } from "react";
import { fireEvent, render, screen } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { describe, expect, it, vi } from "vitest";
import { Combobox, Dialog } from "../src/index";
import type { ComboboxOption } from "../src/index";

const fruits: ComboboxOption[] = [
  { value: "apple", label: "Apple" },
  { value: "apricot", label: "Apricot" },
  { value: "banana", label: "Banana", disabled: true },
  { value: "blueberry", label: "Blueberry" },
  { value: "pear", label: "Pear (green)" },
];

// A parent that owns the value, the way a real form would.
function Fruit({
  initial = null,
  options = fruits,
  onChange = () => {},
}: {
  initial?: string | null;
  options?: ComboboxOption[];
  onChange?: (value: string | null) => void;
}) {
  const [value, setValue] = useState<string | null>(initial);
  return (
    <Combobox
      label="Fruit"
      options={options}
      value={value}
      onChange={(next) => {
        onChange(next);
        setValue(next);
      }}
      placeholder="Pick a fruit"
    />
  );
}

const input = () => screen.getByRole("combobox", { name: "Fruit" });
const optionNames = () => screen.queryAllByRole("option").map((o) => o.textContent);
const option = (name: string) => screen.getByRole("option", { name });

describe("Combobox", () => {
  describe("markup (C1)", () => {
    it("associates the label with an input role=combobox that has the placeholder and autocomplete=list", () => {
      render(<Fruit />);
      const field = input();
      expect(field.tagName).toBe("INPUT");
      expect(field).toHaveAttribute("aria-autocomplete", "list");
      expect(field).toHaveAttribute("aria-expanded", "false");
      expect(field).toHaveAttribute("placeholder", "Pick a fruit");
      expect(field).not.toHaveAttribute("aria-controls");
    });

    it("renders a role=listbox with role=option children, aria-selected, and aria-disabled", async () => {
      const user = userEvent.setup();
      render(<Fruit initial="apple" />);
      input().focus();
      await user.keyboard("{ArrowDown}");
      const listbox = screen.getByRole("listbox", { name: "Fruit" });
      expect(input()).toHaveAttribute("aria-controls", listbox.id);
      expect(input()).toHaveAttribute("aria-expanded", "true");
      expect(option("Apple")).toHaveAttribute("aria-selected", "true");
      expect(option("Apricot")).toHaveAttribute("aria-selected", "false");
      expect(option("Banana")).toHaveAttribute("aria-disabled", "true");
      const ids = screen.getAllByRole("option").map((o) => o.id);
      expect(new Set(ids).size).toBe(ids.length);
    });
  });

  describe("filtering (C2)", () => {
    it("typing opens the listbox and shows only options whose label contains the text, case-insensitively", async () => {
      const user = userEvent.setup();
      render(<Fruit />);
      await user.type(input(), "AP");
      expect(screen.getByRole("listbox")).toBeInTheDocument();
      expect(optionNames()).toEqual(["Apple", "Apricot"]);
    });

    it("whitespace-only or empty text shows all options", async () => {
      const user = userEvent.setup();
      render(<Fruit />);
      await user.type(input(), "   ");
      expect(optionNames()).toHaveLength(fruits.length);
      fireEvent.change(input(), { target: { value: "" } });
      expect(optionNames()).toHaveLength(fruits.length);
    });

    it("matches regex metacharacters literally and does not throw", () => {
      render(<Fruit />);
      fireEvent.change(input(), { target: { value: "(" } });
      expect(optionNames()).toEqual(["Pear (green)"]);
      for (const query of [".*", "[", "\\", "a++"]) {
        fireEvent.change(input(), { target: { value: query } });
        expect(screen.getByRole("status")).toHaveTextContent("No results");
      }
    });

    it("property: for generated queries the shown options are exactly the case-insensitive substring matches", () => {
      render(<Fruit />);
      const alphabet = "aApPrR (.*[]\\^$|?+{}e";
      let seed = 42;
      const next = () => {
        seed = (seed * 1103515245 + 12345) & 0x7fffffff;
        return seed;
      };
      let previous = "";
      for (let i = 0; i < 300; i++) {
        const length = next() % 5;
        let query = "";
        for (let j = 0; j < length; j++) query += alphabet[next() % alphabet.length];
        if (query === previous) continue;
        previous = query;
        fireEvent.change(input(), { target: { value: query } });
        const needle = query.trim().toLowerCase();
        const expected = fruits.filter((o) => o.label.toLowerCase().includes(needle)).map((o) => o.label);
        expect(optionNames()).toEqual(expected.length ? expected : []);
        if (!expected.length) expect(screen.getByRole("status")).toHaveTextContent("No results");
      }
    });
  });

  describe("keyboard (C3)", () => {
    it("ArrowDown opens the listbox when it is closed and keeps DOM focus on the input", async () => {
      const user = userEvent.setup();
      render(<Fruit />);
      input().focus();
      await user.keyboard("{ArrowDown}");
      expect(input()).toHaveAttribute("aria-expanded", "true");
      expect(input()).toHaveFocus();
      expect(input()).not.toHaveAttribute("aria-activedescendant");
    });

    it("ArrowDown and ArrowUp move the active option, skipping disabled ones and wrapping", async () => {
      const user = userEvent.setup();
      render(<Fruit />);
      input().focus();
      await user.keyboard("{ArrowDown}{ArrowDown}");
      expect(input()).toHaveAttribute("aria-activedescendant", option("Apple").id);
      expect(option("Apple")).toHaveAttribute("data-active", "true");
      await user.keyboard("{ArrowDown}");
      expect(input()).toHaveAttribute("aria-activedescendant", option("Apricot").id);
      await user.keyboard("{ArrowDown}");
      expect(input()).toHaveAttribute("aria-activedescendant", option("Blueberry").id);
      await user.keyboard("{ArrowDown}{ArrowDown}");
      expect(input()).toHaveAttribute("aria-activedescendant", option("Apple").id);
      await user.keyboard("{ArrowUp}");
      expect(input()).toHaveAttribute("aria-activedescendant", option("Pear (green)").id);
      expect(input()).toHaveFocus();
    });
  });

  describe("selection (C4)", () => {
    it("Enter commits the active option, sets the text to its label, and closes the listbox", async () => {
      const user = userEvent.setup();
      const onChange = vi.fn();
      render(<Fruit onChange={onChange} />);
      input().focus();
      await user.keyboard("{ArrowDown}{ArrowDown}{ArrowDown}{Enter}");
      expect(onChange).toHaveBeenCalledTimes(1);
      expect(onChange).toHaveBeenCalledWith("apricot");
      expect(input()).toHaveValue("Apricot");
      expect(input()).toHaveAttribute("aria-expanded", "false");
    });

    it("Enter with no active option does nothing", async () => {
      const user = userEvent.setup();
      const onChange = vi.fn();
      render(<Fruit onChange={onChange} />);
      input().focus();
      await user.keyboard("{ArrowDown}{Enter}");
      expect(onChange).not.toHaveBeenCalled();
    });

    it("clicking an enabled option selects it and keeps focus on the input", async () => {
      const user = userEvent.setup();
      const onChange = vi.fn();
      render(<Fruit onChange={onChange} />);
      await user.type(input(), "blue");
      await user.click(option("Blueberry"));
      expect(onChange).toHaveBeenCalledWith("blueberry");
      expect(input()).toHaveValue("Blueberry");
      expect(input()).toHaveFocus();
    });

    it("clicking a disabled option does nothing", async () => {
      const user = userEvent.setup();
      const onChange = vi.fn();
      render(<Fruit onChange={onChange} />);
      await user.type(input(), "ban");
      await user.click(option("Banana"));
      expect(onChange).not.toHaveBeenCalled();
    });
  });

  describe("dismissal (C5)", () => {
    it("Escape closes without calling onChange and reverts the text to the selected label", async () => {
      const user = userEvent.setup();
      const onChange = vi.fn();
      render(<Fruit initial="apple" onChange={onChange} />);
      await user.clear(input());
      await user.type(input(), "ban");
      await user.keyboard("{Escape}");
      expect(onChange).not.toHaveBeenCalled();
      expect(input()).toHaveAttribute("aria-expanded", "false");
      expect(input()).toHaveValue("Apple");
    });

    it("Escape reverts to empty text when the value is null", async () => {
      const user = userEvent.setup();
      render(<Fruit />);
      await user.type(input(), "ban");
      await user.keyboard("{Escape}");
      expect(input()).toHaveValue("");
    });

    it("blur closes the listbox, reverts the text, and does not change the value", async () => {
      const user = userEvent.setup();
      const onChange = vi.fn();
      render(<Fruit initial="apple" onChange={onChange} />);
      await user.clear(input());
      await user.type(input(), "ban");
      await user.tab();
      expect(input()).toHaveAttribute("aria-expanded", "false");
      expect(input()).toHaveValue("Apple");
      expect(onChange).not.toHaveBeenCalled();
    });
  });

  describe("no results (C6)", () => {
    it("shows a No results status, drops aria-activedescendant, and Enter does nothing", async () => {
      const user = userEvent.setup();
      const onChange = vi.fn();
      render(<Fruit onChange={onChange} />);
      await user.type(input(), "zzz");
      expect(screen.getByRole("status")).toHaveTextContent("No results");
      expect(screen.queryByRole("listbox")).toBeNull();
      expect(input()).not.toHaveAttribute("aria-activedescendant");
      await user.keyboard("{Enter}");
      expect(onChange).not.toHaveBeenCalled();
    });
  });

  describe("controlled value (C7)", () => {
    it("shows the label of the option whose value matches, and follows the value prop", () => {
      const { rerender } = render(<Combobox label="Fruit" options={fruits} value="apple" onChange={() => {}} />);
      expect(input()).toHaveValue("Apple");
      rerender(<Combobox label="Fruit" options={fruits} value="blueberry" onChange={() => {}} />);
      expect(input()).toHaveValue("Blueberry");
    });

    it("typing and blurring do not change the value, and clearing the text does not clear it", async () => {
      const user = userEvent.setup();
      const onChange = vi.fn();
      render(<Combobox label="Fruit" options={fruits} value="apple" onChange={onChange} />);
      await user.clear(input());
      await user.type(input(), "ri");
      await user.tab();
      expect(onChange).not.toHaveBeenCalled();
      expect(input()).toHaveValue("Apple");
    });

    it("a parent setting value to null empties the input", () => {
      const { rerender } = render(<Combobox label="Fruit" options={fruits} value="apple" onChange={() => {}} />);
      rerender(<Combobox label="Fruit" options={fruits} value={null} onChange={() => {}} />);
      expect(input()).toHaveValue("");
    });

    it("a value that matches no option shows empty text without throwing", () => {
      render(<Combobox label="Fruit" options={fruits} value="kiwi" onChange={() => {}} />);
      expect(input()).toHaveValue("");
    });
  });

  describe("active item in a changing list (C8, triggered)", () => {
    it("keeps the same option active when an item is prepended, and Enter commits it", async () => {
      const user = userEvent.setup();
      const onChange = vi.fn();
      const { rerender } = render(<Combobox label="Fruit" options={fruits} value={null} onChange={onChange} />);
      input().focus();
      await user.keyboard("{ArrowDown}{ArrowDown}{ArrowDown}");
      expect(option("Apricot")).toHaveAttribute("data-active", "true");
      rerender(<Combobox label="Fruit" options={[{ value: "kiwi", label: "Kiwi" }, ...fruits]} value={null} onChange={onChange} />);
      expect(input()).toHaveAttribute("aria-activedescendant", option("Apricot").id);
      expect(option("Apricot")).toHaveAttribute("data-active", "true");
      await user.keyboard("{Enter}");
      expect(onChange).toHaveBeenCalledWith("apricot");
    });

    it("keeps the active option while filtering still shows it, and Enter commits it", async () => {
      const user = userEvent.setup();
      const onChange = vi.fn();
      render(<Fruit onChange={onChange} />);
      input().focus();
      await user.keyboard("{ArrowDown}{ArrowDown}{ArrowDown}");
      await user.type(input(), "ric");
      expect(optionNames()).toEqual(["Apricot"]);
      expect(input()).toHaveAttribute("aria-activedescendant", option("Apricot").id);
      await user.keyboard("{Enter}");
      expect(onChange).toHaveBeenCalledWith("apricot");
    });

    it("clears the active option when it is removed from the list, and Enter does nothing", async () => {
      const user = userEvent.setup();
      const onChange = vi.fn();
      const { rerender } = render(<Combobox label="Fruit" options={fruits} value={null} onChange={onChange} />);
      input().focus();
      await user.keyboard("{ArrowDown}{ArrowDown}{ArrowDown}");
      rerender(<Combobox label="Fruit" options={fruits.filter((o) => o.value !== "apricot")} value={null} onChange={onChange} />);
      expect(input()).not.toHaveAttribute("aria-activedescendant");
      await user.keyboard("{Enter}");
      expect(onChange).not.toHaveBeenCalled();
    });

    it("commits the clicked option when labels are duplicated, with unique ids", async () => {
      const user = userEvent.setup();
      const onChange = vi.fn();
      render(
        <Combobox
          label="Fruit"
          options={[
            { value: "a1", label: "Same" },
            { value: "a2", label: "Same" },
          ]}
          value={null}
          onChange={onChange}
        />,
      );
      await user.type(input(), "same");
      const [first, second] = screen.getAllByRole("option");
      expect(first.id).not.toBe(second.id);
      await user.click(second);
      expect(onChange).toHaveBeenCalledWith("a2");
    });

    it("sets no active option when every option is disabled", async () => {
      const user = userEvent.setup();
      const onChange = vi.fn();
      render(
        <Combobox
          label="Fruit"
          options={[{ value: "x", label: "X", disabled: true }]}
          value={null}
          onChange={onChange}
        />,
      );
      input().focus();
      await user.keyboard("{ArrowDown}{ArrowDown}{Enter}");
      expect(input()).not.toHaveAttribute("aria-activedescendant");
      expect(onChange).not.toHaveBeenCalled();
    });

    it("shows No results for an empty options array", async () => {
      const user = userEvent.setup();
      render(<Combobox label="Fruit" options={[]} value={null} onChange={() => {}} />);
      input().focus();
      await user.keyboard("{ArrowDown}");
      expect(screen.getByRole("status")).toHaveTextContent("No results");
    });

    it("gives ids that are valid for option values containing spaces and special characters", async () => {
      const user = userEvent.setup();
      const onChange = vi.fn();
      const value = 'x y "z"/[1]';
      render(<Combobox label="Fruit" options={[{ value, label: "Weird" }]} value={null} onChange={onChange} />);
      input().focus();
      await user.keyboard("{ArrowDown}{ArrowDown}");
      expect(option("Weird").id).not.toMatch(/\s/);
      expect(input()).toHaveAttribute("aria-activedescendant", option("Weird").id);
      await user.keyboard("{Enter}");
      expect(onChange).toHaveBeenCalledWith(value);
    });
  });

  describe("ids and props (G2, G3)", () => {
    it("gives two comboboxes on one page unique ids", async () => {
      const user = userEvent.setup();
      render(
        <>
          <Fruit />
          <Fruit />
        </>,
      );
      const [first, second] = screen.getAllByRole("combobox");
      await user.type(first, "a");
      await user.type(second, "a");
      const ids = Array.from(document.querySelectorAll("[id]")).map((el) => el.id);
      expect(ids.length).toBeGreaterThan(0);
      expect(new Set(ids).size).toBe(ids.length);
    });

    it("forwards className to the wrapper that contains the input", () => {
      const { container } = render(
        <Combobox label="Fruit" options={fruits} value={null} onChange={() => {}} className="fruit-box" />,
      );
      expect(container.querySelector(".fruit-box")).toContainElement(input());
    });
  });

  describe("clearing (C9)", () => {
    it("Enter after clearing the text calls onChange(null) once and leaves the input empty", async () => {
      const user = userEvent.setup();
      const onChange = vi.fn();
      render(<Fruit initial="apple" onChange={onChange} />);
      await user.clear(input());
      await user.keyboard("{Enter}");
      expect(onChange).toHaveBeenCalledTimes(1);
      expect(onChange).toHaveBeenCalledWith(null);
      expect(input()).toHaveValue("");
    });

    it("blurring after clearing the text calls onChange(null) once and leaves the input empty", async () => {
      const user = userEvent.setup();
      const onChange = vi.fn();
      render(<Fruit initial="apple" onChange={onChange} />);
      await user.clear(input());
      await user.tab();
      expect(onChange).toHaveBeenCalledTimes(1);
      expect(onChange).toHaveBeenCalledWith(null);
      expect(input()).toHaveValue("");
    });

    it("treats whitespace-only text as cleared", async () => {
      const user = userEvent.setup();
      const onChange = vi.fn();
      render(<Fruit initial="apple" onChange={onChange} />);
      await user.clear(input());
      await user.type(input(), "   ");
      await user.keyboard("{Enter}");
      expect(onChange).toHaveBeenCalledTimes(1);
      expect(onChange).toHaveBeenCalledWith(null);
    });

    it("Escape after clearing the text reverts to the selected label without calling onChange", async () => {
      const user = userEvent.setup();
      const onChange = vi.fn();
      render(<Fruit initial="apple" onChange={onChange} />);
      await user.clear(input());
      await user.keyboard("{Escape}");
      expect(onChange).not.toHaveBeenCalled();
      expect(input()).toHaveValue("Apple");
    });

    it("Enter and blur on empty text do not call onChange when nothing is selected", async () => {
      const user = userEvent.setup();
      const onChange = vi.fn();
      render(<Fruit onChange={onChange} />);
      await user.type(input(), "a");
      await user.clear(input());
      await user.keyboard("{Enter}");
      await user.tab();
      expect(onChange).not.toHaveBeenCalled();
      expect(input()).toHaveValue("");
    });
  });

  describe("inside a form (keyboard, item 5)", () => {
    function Form({ onSubmit }: { onSubmit: () => void }) {
      return (
        <form
          onSubmit={(event) => {
            event.preventDefault();
            onSubmit();
          }}
        >
          <Fruit />
          <button type="submit">Go</button>
        </form>
      );
    }

    it("Enter while the listbox is open with no active option does not submit the form", async () => {
      const user = userEvent.setup();
      const onSubmit = vi.fn();
      render(<Form onSubmit={onSubmit} />);
      input().focus();
      await user.keyboard("{ArrowDown}{Enter}");
      expect(onSubmit).not.toHaveBeenCalled();
    });

    it("Enter while editing text with no matches does not submit the form", async () => {
      const user = userEvent.setup();
      const onSubmit = vi.fn();
      render(<Form onSubmit={onSubmit} />);
      await user.type(input(), "zzz{Enter}");
      expect(onSubmit).not.toHaveBeenCalled();
    });

    it("Enter with the listbox closed and the text not being edited submits the form", async () => {
      const user = userEvent.setup();
      const onSubmit = vi.fn();
      render(<Form onSubmit={onSubmit} />);
      input().focus();
      await user.keyboard("{Escape}{Enter}");
      expect(onSubmit).toHaveBeenCalledTimes(1);
    });
  });

  describe("controlled value changes while editing (C7)", () => {
    const cherries: ComboboxOption[] = [
      { value: "cherry", label: "Cherry" },
      { value: "banana", label: "Banana" },
    ];

    it("drops the typed text and closes the list when the parent changes value", async () => {
      const user = userEvent.setup();
      const onChange = vi.fn();
      const { rerender } = render(<Combobox label="Fruit" options={cherries} value={null} onChange={onChange} />);
      await user.type(input(), "ch");
      expect(option("Cherry")).toBeInTheDocument();
      rerender(<Combobox label="Fruit" options={cherries} value="banana" onChange={onChange} />);
      expect(input()).toHaveValue("Banana");
      expect(input()).toHaveAttribute("aria-expanded", "false");
      expect(screen.queryByRole("listbox")).toBeNull();
      expect(onChange).not.toHaveBeenCalled();
    });

    it("still updates the input and closes the list when an option is committed through the parent", async () => {
      const user = userEvent.setup();
      render(<Fruit />);
      await user.type(input(), "ap");
      await user.click(option("Apricot"));
      expect(input()).toHaveValue("Apricot");
      expect(screen.queryByRole("listbox")).toBeNull();
    });
  });

  describe("Escape on No results (README)", () => {
    it("closes the No results message and does not pass Escape on to an enclosing Dialog", async () => {
      const user = userEvent.setup();
      const onOpenChange = vi.fn();
      render(
        <Dialog open onOpenChange={onOpenChange} title="Find fruit">
          <Fruit />
        </Dialog>,
      );
      await user.type(input(), "zzz");
      expect(screen.getByRole("status")).toHaveTextContent("No results");
      await user.keyboard("{Escape}");
      expect(screen.queryByRole("status")).toBeNull();
      expect(onOpenChange).not.toHaveBeenCalled();
      expect(input()).toBeInTheDocument();
    });
  });
});

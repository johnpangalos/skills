/**
 * True while the keydown belongs to an IME composition. Safari sends keyCode 229 for the Enter
 * that confirms a composition, with isComposing unset, so both signals are checked.
 */
export function isComposing(event: KeyboardEvent): boolean {
  return event.isComposing || event.keyCode === 229;
}

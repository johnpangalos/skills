import { render, screen } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { useState, type KeyboardEvent } from "react";
import { Dialog } from "../Dialog/Dialog";
import { Combobox, type ComboboxOption, type ComboboxProps } from "./Combobox";

const fruits: ComboboxOption[] = [
  { value: "apple", label: "Apple" },
  { value: "apricot", label: "Apricot" },
  { value: "banana", label: "Banana", disabled: true },
  { value: "blueberry", label: "Blueberry" },
  { value: "cherry", label: "Cherry" },
];

// Parent that accepts every change, the way a normal controlled field is used.
function Stateful({
  options = fruits,
  initial = null,
  onChange,
  label = "Fruit",
}: {
  options?: ComboboxOption[];
  initial?: string | null;
  onChange: (value: string | null) => void;
  label?: string;
}) {
  const [value, setValue] = useState<string | null>(initial);
  return (
    <Combobox
      label={label}
      placeholder="Search fruit"
      options={options}
      value={value}
      onChange={(next) => {
        onChange(next);
        setValue(next);
      }}
    />
  );
}

// Parent that never changes value, so the displayed selection is whatever it is given.
function Fixed({
  value,
  onChange = vi.fn(),
  options = fruits,
  label = "Fruit",
  onKeyDown,
  onBlur,
}: {
  value: string | null;
  onChange?: (value: string | null) => void;
  options?: ComboboxOption[];
  label?: string;
  onKeyDown?: ComboboxProps["onKeyDown"];
  onBlur?: ComboboxProps["onBlur"];
}) {
  return (
    <Combobox
      label={label}
      placeholder="Search fruit"
      options={options}
      value={value}
      onChange={onChange}
      onKeyDown={onKeyDown}
      onBlur={onBlur}
    />
  );
}

function box(name = "Fruit"): HTMLElement {
  return screen.getByRole("combobox", { name });
}

function optionLabels(): (string | null)[] {
  return screen.queryAllByRole("option").map((option) => option.textContent);
}

function activeLabel(input: HTMLElement): string | null {
  const id = input.getAttribute("aria-activedescendant");
  return id ? document.getElementById(id)?.textContent ?? null : null;
}

describe("Combobox structure (C1)", () => {
  it("C1: a label is associated with a combobox input with ARIA state", () => {
    render(<Fixed value={null} />);
    const input = box();
    expect(input.tagName).toBe("INPUT");
    expect(input).toHaveAttribute("aria-autocomplete", "list");
    expect(input).toHaveAttribute("aria-expanded", "false");
    expect(input).toHaveAttribute("placeholder", "Search fruit");
    const listbox = document.getElementById(input.getAttribute("aria-controls") ?? "");
    expect(listbox).toHaveAttribute("role", "listbox");
    expect(listbox).toHaveAttribute("hidden");
  });

  it("C1: options have role, unique ids, aria-selected by value, and aria-disabled when disabled", async () => {
    const user = userEvent.setup();
    render(<Fixed value="apricot" />);
    await user.click(box());
    await user.keyboard("{ArrowDown}");
    expect(box()).toHaveAttribute("aria-expanded", "true");
    expect(screen.getByRole("listbox")).not.toHaveAttribute("hidden");
    const options = screen.getAllByRole("option");
    expect(options).toHaveLength(5);
    expect(new Set(options.map((option) => option.id)).size).toBe(5);
    expect(screen.getByRole("option", { name: "Apricot" })).toHaveAttribute("aria-selected", "true");
    expect(screen.getByRole("option", { name: "Apple" })).toHaveAttribute("aria-selected", "false");
    expect(screen.getByRole("option", { name: "Banana" })).toHaveAttribute("aria-disabled", "true");
    expect(screen.getByRole("option", { name: "Apple" })).not.toHaveAttribute("aria-disabled");
  });
});

describe("Combobox input and filtering (C2)", () => {
  it("C2: shows the selected label, and nothing when value is null", () => {
    const { rerender } = render(<Fixed value="apple" />);
    expect(box()).toHaveValue("Apple");
    rerender(<Fixed value={null} />);
    expect(box()).toHaveValue("");
  });

  it("C2: typing opens the popup and filters by case-insensitive substring", async () => {
    const user = userEvent.setup();
    render(<Fixed value={null} />);
    await user.type(box(), "AP");
    expect(box()).toHaveAttribute("aria-expanded", "true");
    expect(optionLabels()).toEqual(["Apple", "Apricot"]);
  });

  it("C2: the query is literal, so regex metacharacters match only themselves", async () => {
    const user = userEvent.setup();
    const options: ComboboxOption[] = [...fruits, { value: "cpp", label: "C++" }, { value: "fig", label: "Fig (a)" }];
    render(<Fixed value={null} options={options} />);
    await user.type(box(), "c++");
    expect(optionLabels()).toEqual(["C++"]);
    await user.clear(box());
    await user.type(box(), "(a");
    expect(optionLabels()).toEqual(["Fig (a)"]);
    await user.clear(box());
    await user.type(box(), ".");
    expect(optionLabels()).toEqual([]);
    await user.clear(box());
    await user.type(box(), "*");
    expect(optionLabels()).toEqual([]);
  });

  it("C2: an empty query shows all options", async () => {
    const user = userEvent.setup();
    render(<Fixed value={null} />);
    await user.type(box(), "ap");
    expect(optionLabels()).toHaveLength(2);
    await user.clear(box());
    expect(optionLabels()).toEqual(["Apple", "Apricot", "Banana", "Blueberry", "Cherry"]);
  });

  it("C2: property: every generated query matches exactly the labels containing it, case-insensitively", async () => {
    const user = userEvent.setup();
    render(<Fixed value={null} />);
    const input = box();
    await user.click(input);
    await user.keyboard("{ArrowDown}");
    // Exhaustive over all strings of length 1 and 2 from a small alphabet of metacharacters and letters.
    const alphabet = ["a", "P", ".", "+", "*", "("];
    const queries = [...alphabet];
    for (const first of alphabet) for (const second of alphabet) queries.push(first + second);
    for (const query of queries) {
      await user.clear(input);
      await user.type(input, query);
      const expected = fruits
        .filter((option) => option.label.toLowerCase().includes(query.toLowerCase()))
        .map((option) => option.label);
      expect(optionLabels(), `query ${JSON.stringify(query)}`).toEqual(expected);
    }
  });
});

describe("Combobox no results (C3)", () => {
  it("C3: shows a No results status and no aria-activedescendant when nothing matches", async () => {
    const user = userEvent.setup();
    render(<Fixed value={null} />);
    await user.type(box(), "zzz");
    expect(screen.getByRole("status")).toHaveTextContent("No results");
    expect(box()).not.toHaveAttribute("aria-activedescendant");
  });
});

describe("Combobox keyboard (C4)", () => {
  it("C4: ArrowDown opens a closed popup and moves to the first enabled option", async () => {
    const user = userEvent.setup();
    render(<Fixed value={null} />);
    await user.click(box());
    await user.keyboard("{ArrowDown}");
    expect(box()).toHaveAttribute("aria-expanded", "true");
    expect(activeLabel(box())).toBe("Apple");
  });

  it("C4: ArrowDown and ArrowUp skip disabled options, wrap, and keep focus on the input", async () => {
    const user = userEvent.setup();
    render(<Stateful onChange={vi.fn()} />);
    await user.click(box());
    await user.keyboard("{ArrowDown}");
    expect(activeLabel(box())).toBe("Apple");
    await user.keyboard("{ArrowDown}");
    expect(activeLabel(box())).toBe("Apricot");
    await user.keyboard("{ArrowDown}");
    expect(activeLabel(box())).toBe("Blueberry");
    await user.keyboard("{ArrowUp}");
    expect(activeLabel(box())).toBe("Apricot");
    await user.keyboard("{ArrowUp}{ArrowUp}");
    expect(activeLabel(box())).toBe("Cherry");
    expect(screen.getByRole("option", { name: "Cherry" })).toHaveAttribute("data-active");
    expect(box()).toHaveFocus();
  });

  it("C4: Alt+ArrowDown opens the popup without moving the active option", async () => {
    const user = userEvent.setup();
    render(<Fixed value={null} />);
    await user.click(box());
    await user.keyboard("{Alt>}{ArrowDown}{/Alt}");
    expect(box()).toHaveAttribute("aria-expanded", "true");
    expect(box()).not.toHaveAttribute("aria-activedescendant");
  });
});

describe("Combobox selection (C5)", () => {
  it("C5: Enter commits the active option, closes the popup and shows its label", async () => {
    const user = userEvent.setup();
    const onChange = vi.fn();
    render(<Stateful onChange={onChange} />);
    await user.type(box(), "ap");
    await user.keyboard("{ArrowDown}{ArrowDown}");
    await user.keyboard("{Enter}");
    expect(onChange).toHaveBeenCalledTimes(1);
    expect(onChange).toHaveBeenCalledWith("apricot");
    expect(box()).toHaveAttribute("aria-expanded", "false");
    expect(box()).toHaveValue("Apricot");
  });

  it("C5: Enter with no active option does nothing", async () => {
    const user = userEvent.setup();
    const onChange = vi.fn();
    render(<Stateful onChange={onChange} />);
    await user.type(box(), "ap");
    await user.keyboard("{Enter}");
    expect(onChange).not.toHaveBeenCalled();
  });

  it("C5: clicking an enabled option selects it", async () => {
    const user = userEvent.setup();
    const onChange = vi.fn();
    render(<Stateful onChange={onChange} />);
    await user.type(box(), "ch");
    await user.click(screen.getByRole("option", { name: "Cherry" }));
    expect(onChange).toHaveBeenCalledWith("cherry");
    expect(box()).toHaveAttribute("aria-expanded", "false");
    expect(box()).toHaveValue("Cherry");
  });

  it("C5: clicking a disabled option does nothing and keeps the popup open", async () => {
    const user = userEvent.setup();
    const onChange = vi.fn();
    render(<Stateful onChange={onChange} />);
    await user.type(box(), "ban");
    await user.click(screen.getByRole("option", { name: "Banana" }));
    expect(onChange).not.toHaveBeenCalled();
    expect(box()).toHaveAttribute("aria-expanded", "true");
  });
});

describe("Combobox escape and blur (C6, C8)", () => {
  it("C6: Escape closes the popup without onChange and restores the selected label", async () => {
    const user = userEvent.setup();
    const onChange = vi.fn();
    render(<Stateful initial="apple" onChange={onChange} />);
    await user.clear(box());
    await user.type(box(), "ch");
    await user.keyboard("{Escape}");
    expect(box()).toHaveAttribute("aria-expanded", "false");
    expect(box()).toHaveValue("Apple");
    expect(onChange).not.toHaveBeenCalled();
  });

  it("C6: Escape while closed restores the label and does not clear the selection", async () => {
    const user = userEvent.setup();
    const onChange = vi.fn();
    render(<Stateful initial="apple" onChange={onChange} />);
    await user.click(box());
    await user.keyboard("{Escape}");
    expect(box()).toHaveValue("Apple");
    expect(onChange).not.toHaveBeenCalled();
  });

  it("C8: blur closes the popup and restores the selected label without onChange", async () => {
    const user = userEvent.setup();
    const onChange = vi.fn();
    render(<Stateful initial="apple" onChange={onChange} />);
    await user.clear(box());
    await user.type(box(), "ch");
    await user.tab();
    expect(box()).toHaveAttribute("aria-expanded", "false");
    expect(box()).toHaveValue("Apple");
    expect(onChange).not.toHaveBeenCalled();
  });
});

describe("Combobox controlled value (C9)", () => {
  it("C9: changing the value prop updates the input text", () => {
    const { rerender } = render(<Fixed value="apple" />);
    rerender(<Fixed value="cherry" />);
    expect(box()).toHaveValue("Cherry");
  });

  it("C9: clearing the text and blurring reports null exactly once", async () => {
    const user = userEvent.setup();
    const onChange = vi.fn();
    render(<Stateful initial="apple" onChange={onChange} />);
    await user.clear(box());
    await user.tab();
    expect(onChange).toHaveBeenCalledTimes(1);
    expect(onChange).toHaveBeenCalledWith(null);
  });

  it("C9: clearing the text and pressing Enter reports null exactly once", async () => {
    const user = userEvent.setup();
    const onChange = vi.fn();
    render(<Stateful initial="apple" onChange={onChange} />);
    await user.clear(box());
    await user.keyboard("{Enter}");
    expect(onChange).toHaveBeenCalledTimes(1);
    expect(onChange).toHaveBeenCalledWith(null);
  });

  it("C9: clearing an empty selection does not report anything", async () => {
    const user = userEvent.setup();
    const onChange = vi.fn();
    render(<Stateful initial={null} onChange={onChange} />);
    await user.type(box(), "x");
    await user.clear(box());
    await user.tab();
    expect(onChange).not.toHaveBeenCalled();
  });

  it("C9: the component does not change the displayed selection without the parent", async () => {
    const user = userEvent.setup();
    const onChange = vi.fn();
    render(<Fixed value="apple" onChange={onChange} />);
    await user.click(box());
    await user.keyboard("{ArrowDown}{ArrowDown}{ArrowDown}{ArrowDown}{Enter}");
    expect(onChange).toHaveBeenCalledWith("cherry");
    expect(box()).toHaveValue("Apple");
  });
});

describe("Combobox active item in a changing list (triggered)", () => {
  it("prepending an item keeps the same item active, and Enter commits it", async () => {
    const user = userEvent.setup();
    const onChange = vi.fn();
    const { rerender } = render(<Stateful onChange={onChange} />);
    await user.click(box());
    await user.keyboard("{ArrowDown}{ArrowDown}");
    expect(activeLabel(box())).toBe("Apricot");
    rerender(<Stateful onChange={onChange} options={[{ value: "avocado", label: "Avocado" }, ...fruits]} />);
    expect(activeLabel(box())).toBe("Apricot");
    await user.keyboard("{Enter}");
    expect(onChange).toHaveBeenCalledWith("apricot");
  });

  it("removing the active item clears the active option, and Enter does not commit it", async () => {
    const user = userEvent.setup();
    const onChange = vi.fn();
    const { rerender } = render(<Stateful onChange={onChange} />);
    await user.click(box());
    await user.keyboard("{ArrowDown}{ArrowDown}");
    rerender(<Stateful onChange={onChange} options={fruits.filter((option) => option.value !== "apricot")} />);
    expect(box()).not.toHaveAttribute("aria-activedescendant");
    await user.keyboard("{Enter}");
    expect(onChange).not.toHaveBeenCalled();
  });

  it("clearing the selection reports null in the change event", async () => {
    const user = userEvent.setup();
    const onChange = vi.fn();
    render(<Stateful initial="apple" onChange={onChange} />);
    await user.clear(box());
    await user.keyboard("{Enter}");
    expect(onChange).toHaveBeenLastCalledWith(null);
  });
});

describe("Combobox hostile inputs (C10)", () => {
  it("C10: active option stays active when the filter still shows it", async () => {
    const user = userEvent.setup();
    render(<Stateful onChange={vi.fn()} />);
    await user.click(box());
    await user.keyboard("{ArrowDown}{ArrowDown}");
    expect(activeLabel(box())).toBe("Apricot");
    await user.type(box(), "p");
    expect(activeLabel(box())).toBe("Apricot");
  });

  it("C10: filter that removes the active option then Enter does not commit it", async () => {
    const user = userEvent.setup();
    const onChange = vi.fn();
    render(<Stateful onChange={onChange} />);
    await user.click(box());
    await user.keyboard("{ArrowDown}");
    expect(activeLabel(box())).toBe("Apple");
    await user.type(box(), "c");
    expect(box()).not.toHaveAttribute("aria-activedescendant");
    await user.keyboard("{Enter}");
    expect(onChange).not.toHaveBeenCalled();
  });

  it("C10: with every option disabled, ArrowDown sets no active option and Enter commits nothing", async () => {
    const user = userEvent.setup();
    const onChange = vi.fn();
    render(
      <Stateful
        onChange={onChange}
        options={[
          { value: "a", label: "Alpha", disabled: true },
          { value: "b", label: "Beta", disabled: true },
        ]}
      />,
    );
    await user.click(box());
    await user.keyboard("{ArrowDown}{Enter}");
    expect(box()).toHaveAttribute("aria-expanded", "true");
    expect(box()).not.toHaveAttribute("aria-activedescendant");
    expect(onChange).not.toHaveBeenCalled();
  });

  it("C10: duplicate labels with different values commit the clicked value", async () => {
    const user = userEvent.setup();
    const onChange = vi.fn();
    const options: ComboboxOption[] = [
      { value: "a1", label: "Same" },
      { value: "a2", label: "Same" },
    ];
    render(<Stateful onChange={onChange} options={options} />);
    await user.click(box());
    await user.keyboard("{ArrowDown}");
    await user.click(screen.getAllByRole("option")[1]);
    expect(onChange).toHaveBeenCalledWith("a2");
    expect(box()).toHaveValue("Same");
  });

  it("C10: duplicate labels mark only the option whose value is selected", async () => {
    const user = userEvent.setup();
    const options: ComboboxOption[] = [
      { value: "a1", label: "Same" },
      { value: "a2", label: "Same" },
    ];
    render(<Fixed value="a2" options={options} />);
    await user.click(box());
    await user.keyboard("{ArrowDown}");
    const [first, second] = screen.getAllByRole("option");
    expect(first).toHaveAttribute("aria-selected", "false");
    expect(second).toHaveAttribute("aria-selected", "true");
  });

  it("C10: a value that matches no option shows an empty input without crashing", () => {
    render(<Fixed value="ghost" />);
    expect(box()).toHaveValue("");
  });

  it("C10: two comboboxes on one page have distinct ids and do not interfere", async () => {
    const user = userEvent.setup();
    render(
      <>
        <Fixed value={null} label="Fruit" />
        <Fixed value={null} label="Other" />
      </>,
    );
    const first = box("Fruit");
    const second = box("Other");
    expect(first.id).not.toBe(second.id);
    expect(first.getAttribute("aria-controls")).not.toBe(second.getAttribute("aria-controls"));
    await user.type(first, "ap");
    expect(first).toHaveAttribute("aria-expanded", "true");
    expect(second).toHaveAttribute("aria-expanded", "false");
    const secondListbox = document.getElementById(second.getAttribute("aria-controls") ?? "");
    expect(secondListbox).toHaveAttribute("hidden");
  });
});

describe("Combobox nested in a dialog (composition)", () => {
  it("Escape closes an open popup inside a dialog but not the dialog; a second Escape closes the dialog", async () => {
    const user = userEvent.setup();
    const onOpenChange = vi.fn();
    render(
      <Dialog open onOpenChange={onOpenChange} title="Pick a fruit">
        <Fixed value={null} />
      </Dialog>,
    );
    await user.type(box(), "ap");
    expect(box()).toHaveAttribute("aria-expanded", "true");
    await user.keyboard("{Escape}");
    expect(box()).toHaveAttribute("aria-expanded", "false");
    expect(onOpenChange).not.toHaveBeenCalled();
    await user.keyboard("{Escape}");
    expect(onOpenChange).toHaveBeenCalledWith(false);
  });
});

describe("Combobox user handlers run first (review fix 2)", () => {
  it("a user onKeyDown is called, and ArrowDown still moves the active option", async () => {
    const user = userEvent.setup();
    const onKeyDown = vi.fn();
    render(<Fixed value={null} onKeyDown={onKeyDown} />);
    await user.click(box());
    await user.keyboard("{ArrowDown}");
    expect(onKeyDown).toHaveBeenCalledTimes(1);
    expect(box()).toHaveAttribute("aria-expanded", "true");
    expect(activeLabel(box())).toBe("Apple");
  });

  it("preventDefault in a user onKeyDown skips the built-in ArrowDown handling", async () => {
    const user = userEvent.setup();
    const onKeyDown = vi.fn((event: KeyboardEvent<HTMLInputElement>) => {
      if (event.key === "ArrowDown") event.preventDefault();
    });
    render(<Fixed value={null} onKeyDown={onKeyDown} />);
    await user.click(box());
    await user.keyboard("{ArrowDown}");
    expect(onKeyDown).toHaveBeenCalledTimes(1);
    expect(box()).toHaveAttribute("aria-expanded", "false");
    expect(activeLabel(box())).toBeNull();
  });

  it("a user onBlur is called, and blur still closes the popup and reverts the text", async () => {
    const user = userEvent.setup();
    const onBlur = vi.fn();
    render(<Fixed value={null} onBlur={onBlur} />);
    await user.type(box(), "ch");
    await user.tab();
    expect(onBlur).toHaveBeenCalledTimes(1);
    expect(box()).toHaveAttribute("aria-expanded", "false");
    expect(box()).toHaveValue("");
  });
});

import {
  useId,
  useState,
  type ChangeEvent,
  type FocusEvent,
  type InputHTMLAttributes,
  type KeyboardEvent,
} from "react";

export interface ComboboxOption<T extends string = string> {
  value: T;
  label: string;
  disabled?: boolean;
}

export interface ComboboxProps<T extends string = string>
  extends Omit<InputHTMLAttributes<HTMLInputElement>, "value" | "defaultValue" | "onChange" | "role" | "type"> {
  /** Visible label, associated with the input. */
  label: string;
  options: ComboboxOption<T>[];
  /** Selected option value, or null for no selection. Controlled. */
  value: T | null;
  /** Called with the chosen value, or null when the selection is cleared. */
  onChange: (value: T | null) => void;
}

// Plain substring match: the query is never treated as a regular expression.
function matchesQuery(option: ComboboxOption, query: string): boolean {
  return option.label.toLowerCase().includes(query.toLowerCase());
}

export function Combobox<T extends string = string>({
  label,
  options,
  value,
  onChange,
  onKeyDown: onUserKeyDown,
  onBlur: onUserBlur,
  ...rest
}: ComboboxProps<T>) {
  const id = useId();
  const inputId = `${id}-input`;
  const listboxId = `${id}-listbox`;
  const optionId = (index: number) => `${id}-option-${index}`;

  // null while the user is not typing, so the input shows the selected label.
  const [text, setText] = useState<string | null>(null);
  const [open, setOpen] = useState(false);
  // Tracked by value, so the active option survives list changes that keep it visible.
  const [activeValue, setActiveValue] = useState<T | null>(null);
  const [previousValue, setPreviousValue] = useState(value);

  // A new value from the parent replaces whatever the user typed.
  if (value !== previousValue) {
    setPreviousValue(value);
    setText(null);
  }

  const query = text ?? "";
  const visible = options.filter((option) => matchesQuery(option, query));
  const enabled = visible.filter((option) => !option.disabled);
  const active = open ? (enabled.find((option) => option.value === activeValue) ?? null) : null;
  // The active option left the visible list, so it is no longer active.
  if (activeValue !== null && active === null) setActiveValue(null);

  const selectedOption = options.find((option) => option.value === value);
  const shownText = text ?? selectedOption?.label ?? "";

  function close() {
    setText(null);
    setOpen(false);
    setActiveValue(null);
  }

  function choose(option: ComboboxOption<T>) {
    onChange(option.value);
    close();
  }

  // Leaving the input: a cleared input clears the selection, anything else reverts to the label.
  function onBlur(event: FocusEvent<HTMLInputElement>) {
    onUserBlur?.(event);
    if (text === "" && value !== null) onChange(null);
    close();
  }

  function move(step: 1 | -1) {
    if (enabled.length === 0) return;
    const index = active ? enabled.indexOf(active) : -1;
    const count = enabled.length;
    const next = step === 1 ? (index + 1) % count : index <= 0 ? count - 1 : index - 1;
    setActiveValue(enabled[next].value);
  }

  function onKeyDown(event: KeyboardEvent<HTMLInputElement>) {
    onUserKeyDown?.(event);
    if (event.defaultPrevented) return;
    switch (event.key) {
      case "ArrowDown":
      case "ArrowUp":
        event.preventDefault();
        setOpen(true);
        if (!event.altKey) move(event.key === "ArrowDown" ? 1 : -1);
        break;
      case "Enter":
        if (active) {
          event.preventDefault();
          choose(active);
        } else if (text === "" && value !== null) {
          onChange(null);
          close();
        }
        break;
      case "Escape":
        // Closing the popup is this component's job, so the dialog around it must not also close.
        if (open) event.stopPropagation();
        close();
        break;
    }
  }

  function onInputChange(event: ChangeEvent<HTMLInputElement>) {
    setText(event.target.value);
    setOpen(true);
  }

  return (
    <>
      <label htmlFor={inputId}>{label}</label>
      <input
        {...rest}
        id={inputId}
        role="combobox"
        type="text"
        autoComplete="off"
        aria-autocomplete="list"
        aria-expanded={open}
        aria-controls={listboxId}
        aria-activedescendant={active ? optionId(options.indexOf(active)) : undefined}
        value={shownText}
        onChange={onInputChange}
        onKeyDown={onKeyDown}
        onBlur={onBlur}
      />
      <ul id={listboxId} role="listbox" hidden={!open}>
        {options.map((option, index) =>
          matchesQuery(option, query) ? (
            <li
              key={index}
              id={optionId(index)}
              role="option"
              aria-selected={option.value === value}
              aria-disabled={option.disabled || undefined}
              data-active={option === active ? "" : undefined}
              // Keeps focus in the input so the blur handler does not close the popup before the click.
              onMouseDown={(event) => event.preventDefault()}
              onClick={() => {
                if (!option.disabled) choose(option);
              }}
            >
              {option.label}
            </li>
          ) : null,
        )}
      </ul>
      {open && visible.length === 0 ? <div role="status">No results</div> : null}
    </>
  );
}

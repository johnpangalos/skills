import { fireEvent, render, screen } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { useState } from "react";
import { describe, expect, it, vi } from "vitest";
import { Dialog } from "../Dialog/Dialog";
import { Combobox, type ComboboxOption } from "./Combobox";

const OPTIONS: ComboboxOption[] = [
  { value: "apple", label: "Apple" },
  { value: "banana", label: "Banana" },
  { value: "cherry", label: "Cherry", disabled: true },
  { value: "date", label: "Date" },
];

function Controlled({
  options = OPTIONS,
  initial = null,
  onChange = () => {},
}: {
  options?: ComboboxOption[];
  initial?: string | null;
  onChange?: (value: string | null) => void;
}) {
  const [value, setValue] = useState<string | null>(initial);
  return (
    <Combobox
      label="Fruit"
      placeholder="Pick a fruit"
      options={options}
      value={value}
      onChange={(next) => {
        onChange(next);
        setValue(next);
      }}
    />
  );
}

const input = () => screen.getByRole("combobox", { name: "Fruit" }) as HTMLInputElement;
const optionNamed = (name: string) => screen.getByRole("option", { name });
const optionTexts = () => screen.queryAllByRole("option").map((option) => option.textContent);
const activeText = () => {
  const id = input().getAttribute("aria-activedescendant");
  return id ? document.getElementById(id)?.textContent : undefined;
};

describe("Combobox", () => {
  it("C1 the label is associated with a combobox input wired to its listbox", async () => {
    const user = userEvent.setup();
    render(<Controlled />);
    expect(input().tagName).toBe("INPUT");
    expect(input().getAttribute("aria-autocomplete")).toBe("list");
    expect(input().getAttribute("aria-expanded")).toBe("false");
    await user.click(input());
    await user.keyboard("{ArrowDown}");
    expect(input().getAttribute("aria-expanded")).toBe("true");
    const listbox = screen.getByRole("listbox");
    expect(input().getAttribute("aria-controls")).toBe(listbox.id);
  });

  it("C1 options are role option with unique ids, aria-selected for the value, and aria-disabled when disabled", async () => {
    const user = userEvent.setup();
    render(<Controlled initial="banana" />);
    await user.click(input());
    await user.keyboard("{ArrowDown}");
    const options = screen.getAllByRole("option");
    expect(options.map((option) => option.getAttribute("aria-selected"))).toEqual(["false", "true", "false", "false"]);
    expect(optionNamed("Cherry").getAttribute("aria-disabled")).toBe("true");
    expect(optionNamed("Apple").getAttribute("aria-disabled")).toBeNull();
    const ids = options.map((option) => option.id);
    expect(new Set(ids).size).toBe(ids.length);
  });

  it("C2 shows the selected label when closed, and empty text when value is null", () => {
    const { unmount } = render(<Controlled initial="banana" />);
    expect(input().value).toBe("Banana");
    unmount();
    render(<Controlled />);
    expect(input().value).toBe("");
  });

  it("C2 passes placeholder to the input", () => {
    render(<Controlled />);
    expect(input().getAttribute("placeholder")).toBe("Pick a fruit");
  });

  it("C2 typing opens the popup and filters options by case-insensitive substring", async () => {
    const user = userEvent.setup();
    render(<Controlled />);
    await user.type(input(), "AN");
    expect(input().getAttribute("aria-expanded")).toBe("true");
    expect(optionTexts()).toEqual(["Banana"]);
    await user.clear(input());
    await user.type(input(), "e");
    expect(optionTexts()).toEqual(["Apple", "Cherry", "Date"]);
  });

  it("C2 whitespace-only text shows all options", async () => {
    const user = userEvent.setup();
    render(<Controlled />);
    await user.type(input(), "   ");
    expect(optionTexts()).toEqual(["Apple", "Banana", "Cherry", "Date"]);
    await user.clear(input());
    await user.type(input(), "  an  ");
    expect(optionTexts()).toEqual(["Banana"]);
  });

  it("C3 ArrowDown opens the popup when closed and makes the first enabled option active", async () => {
    const user = userEvent.setup();
    render(<Controlled />);
    await user.click(input());
    expect(input().getAttribute("aria-activedescendant")).toBeNull();
    await user.keyboard("{ArrowDown}");
    expect(input().getAttribute("aria-expanded")).toBe("true");
    expect(activeText()).toBe("Apple");
  });

  it("C3 ArrowDown and ArrowUp move the active option, skipping disabled options", async () => {
    const user = userEvent.setup();
    render(<Controlled />);
    await user.click(input());
    await user.keyboard("{ArrowDown}{ArrowDown}");
    expect(activeText()).toBe("Banana");
    await user.keyboard("{ArrowDown}");
    expect(activeText()).toBe("Date");
    await user.keyboard("{ArrowUp}");
    expect(activeText()).toBe("Banana");
  });

  it("C3 movement wraps at both ends", async () => {
    const user = userEvent.setup();
    render(<Controlled />);
    await user.click(input());
    await user.keyboard("{ArrowUp}");
    expect(activeText()).toBe("Date");
    await user.keyboard("{ArrowDown}");
    expect(activeText()).toBe("Apple");
  });

  it("C3 ArrowUp opens the popup when closed and makes the last enabled option active", async () => {
    const user = userEvent.setup();
    render(<Controlled />);
    await user.click(input());
    await user.keyboard("{ArrowUp}");
    expect(input().getAttribute("aria-expanded")).toBe("true");
    expect(activeText()).toBe("Date");
  });

  it("C3 aria-activedescendant is the active option id, and absent when closed or nothing is active", async () => {
    const user = userEvent.setup();
    render(<Controlled />);
    await user.click(input());
    await user.keyboard("{ArrowDown}");
    expect(input().getAttribute("aria-activedescendant")).toBe(optionNamed("Apple").id);
    await user.keyboard("{Escape}");
    expect(input().getAttribute("aria-activedescendant")).toBeNull();
    await user.type(input(), "zzz");
    expect(input().getAttribute("aria-activedescendant")).toBeNull();
  });

  it("C4 Enter on the active option calls onChange with its value, closes, and shows its label", async () => {
    const user = userEvent.setup();
    const onChange = vi.fn();
    render(<Controlled onChange={onChange} />);
    await user.click(input());
    await user.keyboard("{ArrowDown}{ArrowDown}{Enter}");
    expect(onChange.mock.calls).toEqual([["banana"]]);
    expect(input().getAttribute("aria-expanded")).toBe("false");
    expect(input().value).toBe("Banana");
  });

  it("C4 Enter with no active option does nothing", async () => {
    const user = userEvent.setup();
    const onChange = vi.fn();
    render(<Controlled onChange={onChange} />);
    await user.type(input(), "zzz{Enter}");
    expect(onChange).not.toHaveBeenCalled();
  });

  it("C4 clicking an enabled option selects it and keeps focus in the input", async () => {
    const user = userEvent.setup();
    const onChange = vi.fn();
    render(<Controlled onChange={onChange} />);
    await user.type(input(), "an");
    await user.click(optionNamed("Banana"));
    expect(onChange.mock.calls).toEqual([["banana"]]);
    expect(document.activeElement).toBe(input());
    expect(input().value).toBe("Banana");
  });

  it("C4 clicking a disabled option does nothing", async () => {
    const user = userEvent.setup();
    const onChange = vi.fn();
    render(<Controlled onChange={onChange} />);
    await user.click(input());
    await user.keyboard("{ArrowDown}");
    await user.click(optionNamed("Cherry"));
    expect(onChange).not.toHaveBeenCalled();
  });

  it("C5 Escape closes without calling onChange and restores the selected label", async () => {
    const user = userEvent.setup();
    const onChange = vi.fn();
    render(<Controlled initial="banana" onChange={onChange} />);
    await user.clear(input());
    await user.type(input(), "ch");
    expect(optionTexts()).toEqual(["Cherry"]);
    await user.keyboard("{Escape}");
    expect(input().getAttribute("aria-expanded")).toBe("false");
    expect(input().value).toBe("Banana");
    expect(onChange).not.toHaveBeenCalled();
  });

  it("C5 Escape on a closed popup changes nothing", async () => {
    const user = userEvent.setup();
    const onChange = vi.fn();
    render(<Controlled initial="banana" onChange={onChange} />);
    await user.click(input());
    await user.keyboard("{Escape}");
    expect(onChange).not.toHaveBeenCalled();
    expect(input().value).toBe("Banana");
  });

  it("C5 Escape that closes the popup does not also close an enclosing dialog", async () => {
    const user = userEvent.setup();
    const onOpenChange = vi.fn();
    render(
      <Dialog open onOpenChange={onOpenChange} title="Pick">
        <Controlled />
      </Dialog>,
    );
    await user.type(input(), "a");
    expect(input().getAttribute("aria-expanded")).toBe("true");
    await user.keyboard("{Escape}");
    expect(input().getAttribute("aria-expanded")).toBe("false");
    expect(onOpenChange).not.toHaveBeenCalled();
    await user.keyboard("{Escape}");
    expect(onOpenChange.mock.calls).toEqual([[false]]);
  });

  it("C6 when nothing matches, shows No results and no options and no active descendant", async () => {
    const user = userEvent.setup();
    render(<Controlled />);
    await user.type(input(), "zzz");
    expect(screen.getByRole("status").textContent).toBe("No results");
    expect(screen.queryAllByRole("option")).toEqual([]);
    expect(input().getAttribute("aria-activedescendant")).toBeNull();
  });

  it("C6 hostile: an empty options array shows No results", async () => {
    const user = userEvent.setup();
    render(<Controlled options={[]} />);
    await user.click(input());
    await user.keyboard("{ArrowDown}");
    expect(screen.getByRole("status").textContent).toBe("No results");
  });

  it("C7 a prepended option keeps the same item active, and Enter commits that item", async () => {
    const user = userEvent.setup();
    const onChange = vi.fn();
    const { rerender } = render(<Controlled onChange={onChange} />);
    await user.click(input());
    await user.keyboard("{ArrowDown}{ArrowDown}");
    expect(activeText()).toBe("Banana");
    rerender(
      <Controlled
        onChange={onChange}
        options={[{ value: "avocado", label: "Avocado" }, ...OPTIONS]}
      />,
    );
    expect(activeText()).toBe("Banana");
    await user.keyboard("{Enter}");
    expect(onChange.mock.calls).toEqual([["banana"]]);
  });

  it("C7 filtering keeps the active item when it is still visible", async () => {
    const user = userEvent.setup();
    render(<Controlled />);
    await user.click(input());
    await user.keyboard("{ArrowDown}{ArrowDown}");
    expect(activeText()).toBe("Banana");
    await user.type(input(), "b");
    expect(activeText()).toBe("Banana");
  });

  it("C7 filtering that hides the active item resets to the first enabled visible option", async () => {
    const user = userEvent.setup();
    const onChange = vi.fn();
    render(<Controlled onChange={onChange} />);
    await user.click(input());
    await user.keyboard("{ArrowDown}");
    expect(activeText()).toBe("Apple");
    await user.type(input(), "an");
    expect(optionTexts()).toEqual(["Banana"]);
    expect(activeText()).toBe("Banana");
    await user.keyboard("{Enter}");
    expect(onChange.mock.calls).toEqual([["banana"]]);
  });

  it("C7 removing the active option resets to the first enabled visible option", async () => {
    const user = userEvent.setup();
    const onChange = vi.fn();
    const { rerender } = render(<Controlled onChange={onChange} />);
    await user.click(input());
    await user.keyboard("{ArrowDown}{ArrowDown}");
    expect(activeText()).toBe("Banana");
    rerender(
      <Controlled
        onChange={onChange}
        options={[{ value: "apple", label: "Apple" }, { value: "date", label: "Date" }]}
      />,
    );
    expect(activeText()).toBe("Apple");
    await user.keyboard("{Enter}");
    expect(onChange.mock.calls).toEqual([["apple"]]);
  });

  it("C8 clearing the text and blurring calls onChange(null) and leaves the input empty", async () => {
    const user = userEvent.setup();
    const onChange = vi.fn();
    render(<Controlled initial="banana" onChange={onChange} />);
    await user.clear(input());
    expect(onChange).not.toHaveBeenCalled();
    await user.tab();
    expect(onChange.mock.calls).toEqual([[null]]);
    expect(input().value).toBe("");
  });

  it("C8 clearing the text and pressing Enter with nothing active calls onChange(null)", async () => {
    const user = userEvent.setup();
    const onChange = vi.fn();
    render(<Controlled initial="banana" onChange={onChange} />);
    await user.clear(input());
    await user.keyboard("{Enter}");
    expect(onChange.mock.calls).toEqual([[null]]);
  });

  it("C8 blurring after typing reverts the input to the selected label", async () => {
    const user = userEvent.setup();
    const onChange = vi.fn();
    render(<Controlled initial="banana" onChange={onChange} />);
    await user.type(input(), "ch");
    await user.tab();
    expect(input().value).toBe("Banana");
    expect(input().getAttribute("aria-expanded")).toBe("false");
    expect(onChange).not.toHaveBeenCalled();
  });

  it("C8 when the parent changes value externally the input text follows", () => {
    const { rerender } = render(
      <Combobox label="Fruit" options={OPTIONS} value="banana" onChange={() => {}} />,
    );
    expect(input().value).toBe("Banana");
    rerender(<Combobox label="Fruit" options={OPTIONS} value="date" onChange={() => {}} />);
    expect(input().value).toBe("Date");
  });

  it("C8 controlled: when the parent ignores onChange, the input keeps the selected label", async () => {
    const user = userEvent.setup();
    const onChange = vi.fn();
    render(<Combobox label="Fruit" options={OPTIONS} value="banana" onChange={onChange} />);
    await user.click(input());
    await user.keyboard("{ArrowDown}{Enter}");
    expect(onChange.mock.calls).toEqual([["apple"]]);
    expect(input().value).toBe("Banana");
  });

  it("C9 duplicate labels filter and select by value", async () => {
    const user = userEvent.setup();
    const onChange = vi.fn();
    render(
      <Controlled
        onChange={onChange}
        options={[
          { value: "a1", label: "Same" },
          { value: "a2", label: "Same" },
        ]}
      />,
    );
    await user.type(input(), "same");
    expect(optionTexts()).toEqual(["Same", "Same"]);
    await user.keyboard("{ArrowDown}{Enter}");
    expect(onChange.mock.calls).toEqual([["a2"]]);
  });

  it("C9 labels with regex characters match literally", async () => {
    const user = userEvent.setup();
    render(
      <Controlled
        options={[
          { value: "cpp", label: "C++" },
          { value: "star", label: "a.*b" },
          { value: "paren", label: "(x)" },
          { value: "plain", label: "Plain" },
        ]}
      />,
    );
    await user.type(input(), "c++");
    expect(optionTexts()).toEqual(["C++"]);
    await user.clear(input());
    await user.type(input(), ".*");
    expect(optionTexts()).toEqual(["a.*b"]);
    await user.clear(input());
    await user.type(input(), "(");
    expect(optionTexts()).toEqual(["(x)"]);
  });

  it("C9 hostile: with all options disabled, ArrowDown leaves nothing active and Enter does nothing", async () => {
    const user = userEvent.setup();
    const onChange = vi.fn();
    render(
      <Controlled
        onChange={onChange}
        options={[
          { value: "x", label: "X", disabled: true },
          { value: "y", label: "Y", disabled: true },
        ]}
      />,
    );
    await user.click(input());
    await user.keyboard("{ArrowDown}");
    expect(input().getAttribute("aria-activedescendant")).toBeNull();
    await user.keyboard("{Enter}");
    expect(onChange).not.toHaveBeenCalled();
  });

  it("C9 hostile: a value that is not in options has no label, does not crash, and Enter does not clear it", async () => {
    const user = userEvent.setup();
    const onChange = vi.fn();
    render(<Combobox label="Fruit" options={OPTIONS} value="ghost" onChange={onChange} />);
    expect(input().value).toBe("");
    await user.click(input());
    await user.keyboard("{Enter}");
    expect(onChange).not.toHaveBeenCalled();
  });

  it("C9 hostile: option values with spaces produce unique ids with no spaces", async () => {
    const user = userEvent.setup();
    render(
      <Controlled
        options={[
          { value: "big apple", label: "Big apple" },
          { value: "big-apple", label: "Big apple 2" },
        ]}
      />,
    );
    await user.click(input());
    await user.keyboard("{ArrowDown}{ArrowDown}");
    const active = document.getElementById(input().getAttribute("aria-activedescendant") ?? "");
    expect(active?.textContent).toBe("Big apple 2");
    const ids = screen.getAllByRole("option").map((option) => option.id);
    expect(new Set(ids).size).toBe(2);
    expect(ids.every((id) => !/\s/.test(id))).toBe(true);
  });

  it("G2 passes className and native props through to the root element", () => {
    const { container } = render(
      <Combobox label="Fruit" options={OPTIONS} value={null} onChange={() => {}} className="cb" data-testid="cb" />,
    );
    expect(container.firstElementChild?.getAttribute("class")).toBe("cb");
    expect(container.firstElementChild?.getAttribute("data-testid")).toBe("cb");
  });

  it("G3 two comboboxes on one page have no duplicate ids and do not affect each other", async () => {
    const user = userEvent.setup();
    const onChange = vi.fn();
    render(
      <>
        <Controlled onChange={onChange} />
        <Controlled initial="date" />
      </>,
    );
    const [first, second] = screen.getAllByRole("combobox") as HTMLInputElement[];
    const ids = Array.from(document.querySelectorAll("[id]"), (element) => element.id);
    expect(new Set(ids).size).toBe(ids.length);
    await user.click(first);
    await user.keyboard("{ArrowDown}{Enter}");
    expect(onChange.mock.calls).toEqual([["apple"]]);
    expect(second.value).toBe("Date");
  });

  it("C4 hostile: keys pressed during IME composition are ignored, and Enter commits only after composition ends", async () => {
    // user-event cannot set isComposing on keyboard events, so these keydowns are dispatched directly.
    const user = userEvent.setup();
    const onChange = vi.fn();
    render(<Controlled onChange={onChange} />);
    await user.type(input(), "a");
    await user.keyboard("{ArrowDown}");
    expect(activeText()).toBe("Banana");
    fireEvent.keyDown(input(), { key: "Enter", isComposing: true });
    fireEvent.keyDown(input(), { key: "Escape", isComposing: true });
    expect(onChange).not.toHaveBeenCalled();
    expect(input().getAttribute("aria-expanded")).toBe("true");
    fireEvent.keyDown(input(), { key: "Enter" });
    expect(onChange.mock.calls).toEqual([["banana"]]);
  });

  it("IME: Escape during composition does not close an enclosing dialog", async () => {
    const user = userEvent.setup();
    const onOpenChange = vi.fn();
    render(
      <Dialog open onOpenChange={onOpenChange} title="Pick">
        <Controlled />
      </Dialog>,
    );
    await user.type(input(), "a");
    expect(input().getAttribute("aria-expanded")).toBe("true");
    fireEvent.keyDown(input(), { key: "Escape", isComposing: true });
    expect(onOpenChange).not.toHaveBeenCalled();
    expect(input().getAttribute("aria-expanded")).toBe("true");
  });

  it("IME: Enter with keyCode 229 (Safari composition confirm) does not commit the active option", async () => {
    const user = userEvent.setup();
    const onChange = vi.fn();
    render(<Controlled onChange={onChange} />);
    await user.type(input(), "a");
    await user.keyboard("{ArrowDown}");
    expect(activeText()).toBe("Banana");
    fireEvent.keyDown(input(), { key: "Enter", keyCode: 229 });
    expect(onChange).not.toHaveBeenCalled();
    expect(input().getAttribute("aria-expanded")).toBe("true");
  });
});

import { useState, type ReactNode } from "react";
import { fireEvent, render, screen } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { Combobox, Dialog, Tab, TabList, TabPanel, Tabs, type DialogProps } from "./index";

function Controlled({
  description,
  initiallyOpen = false,
  children,
}: {
  description?: string;
  initiallyOpen?: boolean;
  children?: ReactNode;
}) {
  const [open, setOpen] = useState(initiallyOpen);
  return (
    <>
      <button type="button" onClick={() => setOpen(true)}>
        Open
      </button>
      <Dialog open={open} onOpenChange={setOpen} title="Confirm" description={description}>
        {children ?? <button type="button">OK</button>}
      </Dialog>
    </>
  );
}

function Adder() {
  const [late, setLate] = useState(false);
  return (
    <>
      <button type="button" onClick={() => setLate(true)}>
        Add
      </button>
      {late && <button type="button">Late</button>}
    </>
  );
}

function Mountable({ mounted }: { mounted: boolean }) {
  return (
    <>
      <button type="button">Opener</button>
      {mounted && (
        <Dialog open onOpenChange={() => {}} title="Confirm">
          <button type="button">OK</button>
        </Dialog>
      )}
    </>
  );
}

function Host({ showOpener, open }: { showOpener: boolean; open: boolean }) {
  return (
    <>
      {showOpener && <button type="button">Opener</button>}
      <Dialog open={open} onOpenChange={() => {}} title="Confirm">
        <button type="button">OK</button>
      </Dialog>
    </>
  );
}

function Nested({ outerSpy, innerSpy }: { outerSpy: (open: boolean) => void; innerSpy: (open: boolean) => void }) {
  const [inner, setInner] = useState(false);
  return (
    <Dialog open onOpenChange={outerSpy} title="Outer">
      <button type="button" onClick={() => setInner(true)}>
        Open inner
      </button>
      <button type="button">Outer other</button>
      <Dialog
        open={inner}
        onOpenChange={(next) => {
          innerSpy(next);
          setInner(next);
        }}
        title="Inner"
      >
        <button type="button">Inner action</button>
        <button type="button">Inner close</button>
      </Dialog>
    </Dialog>
  );
}

function TabsDialog() {
  const [open, setOpen] = useState(false);
  return (
    <>
      <button type="button" onClick={() => setOpen(true)}>
        Open
      </button>
      <Dialog open={open} onOpenChange={setOpen} title="Settings">
        <Tabs defaultValue="a">
          <TabList aria-label="Sections">
            <Tab value="a">A</Tab>
            <Tab value="b">B</Tab>
          </TabList>
          <TabPanel value="a">Panel A</TabPanel>
          <TabPanel value="b">Panel B</TabPanel>
        </Tabs>
      </Dialog>
    </>
  );
}

function SectionTabs({ disableA = false }: { disableA?: boolean }) {
  return (
    <Tabs>
      <TabList aria-label="Sections">
        <Tab value="a" disabled={disableA}>
          A
        </Tab>
        <Tab value="b">B</Tab>
      </TabList>
      <TabPanel value="a">Panel A</TabPanel>
      <TabPanel value="b">Panel B</TabPanel>
    </Tabs>
  );
}

function TabsDialogNoDefault({ disableA = false }: { disableA?: boolean }) {
  const [open, setOpen] = useState(false);
  return (
    <>
      <button type="button" onClick={() => setOpen(true)}>
        Open
      </button>
      <Dialog open={open} onOpenChange={setOpen} title="Settings">
        <SectionTabs disableA={disableA} />
      </Dialog>
    </>
  );
}

function RemoveFocusedDialog({ onOpenChange }: { onOpenChange: (open: boolean) => void }) {
  const [removed, setRemoved] = useState(false);
  return (
    <Dialog open onOpenChange={onOpenChange} title="Confirm">
      {!removed && (
        <button type="button" onClick={() => setRemoved(true)}>
          Remove me
        </button>
      )}
      <button type="button">OK</button>
    </Dialog>
  );
}

function StackedDialogs({ outerSpy, innerSpy }: { outerSpy: (open: boolean) => void; innerSpy: (open: boolean) => void }) {
  const [inner, setInner] = useState(false);
  return (
    <Dialog open onOpenChange={outerSpy} title="Outer">
      <button type="button" onClick={() => setInner(true)}>
        Open inner
      </button>
      {inner && (
        <Dialog
          open
          onOpenChange={(next) => {
            innerSpy(next);
            setInner(next);
          }}
          title="Inner"
        >
          <button type="button">Inner action</button>
        </Dialog>
      )}
    </Dialog>
  );
}

function RemovingDialog() {
  const [removed, setRemoved] = useState(false);
  return (
    <>
      <button type="button">Outside</button>
      <Dialog open onOpenChange={() => {}} title="Confirm">
        <button type="button" disabled>
          Disabled
        </button>
        {!removed && (
          <button type="button" onClick={() => setRemoved(true)}>
            Remove me
          </button>
        )}
        <button type="button">OK</button>
        <button type="button">Last</button>
      </Dialog>
    </>
  );
}

const backdropOf = (dialog: HTMLElement) => dialog.parentElement as HTMLElement;

describe("Dialog", () => {
  it("D1 renders a labelled modal in a portal on a backdrop, with a description when given", async () => {
    const user = userEvent.setup();
    const { container } = render(<Controlled description="Are you sure?" />);
    await user.click(screen.getByRole("button", { name: "Open" }));

    const dialog = screen.getByRole("dialog", { name: "Confirm" });
    expect(dialog).toHaveAttribute("aria-modal", "true");
    expect(container.contains(dialog)).toBe(false);
    expect(document.querySelector("[data-backdrop]")).toContainElement(dialog);
    expect(dialog).toHaveAccessibleDescription("Are you sure?");
    expect(dialog.getAttribute("aria-describedby")).not.toBeNull();
  });

  it("D1 omits aria-describedby when there is no description, and renders nothing when closed", async () => {
    const user = userEvent.setup();
    render(<Controlled />);
    expect(screen.queryByRole("dialog")).toBeNull();
    expect(document.querySelector("[data-backdrop]")).toBeNull();

    await user.click(screen.getByRole("button", { name: "Open" }));
    expect(screen.getByRole("dialog")).not.toHaveAttribute("aria-describedby");
  });

  it("D2 moves focus to the first tabbable element on open", async () => {
    const user = userEvent.setup();
    render(
      <Controlled>
        <button type="button">First</button>
        <button type="button">Second</button>
      </Controlled>,
    );
    await user.click(screen.getByRole("button", { name: "Open" }));
    expect(screen.getByRole("button", { name: "First" })).toHaveFocus();
  });

  it("D2 focuses the dialog element itself when there is nothing tabbable", async () => {
    const user = userEvent.setup();
    render(
      <Controlled>
        <p>Just text</p>
      </Controlled>,
    );
    await user.click(screen.getByRole("button", { name: "Open" }));
    const dialog = screen.getByRole("dialog");
    expect(dialog).toHaveAttribute("tabindex", "-1");
    expect(dialog).toHaveFocus();
  });

  it("D2 leaves focus on an autoFocus child", async () => {
    const user = userEvent.setup();
    render(
      <Controlled>
        <button type="button">OK</button>
        <input aria-label="Name" autoFocus />
      </Controlled>,
    );
    await user.click(screen.getByRole("button", { name: "Open" }));
    expect(screen.getByRole("textbox", { name: "Name" })).toHaveFocus();
  });

  it("D2 with Tabs inside, opening from a button focuses the selected tab", async () => {
    const user = userEvent.setup();
    render(<TabsDialog />);
    await user.click(screen.getByRole("button", { name: "Open" }));
    expect(screen.getByRole("tab", { name: "A" })).toHaveFocus();
  });

  it("D3 after the focused element is removed, Tab moves focus to the first tabbable inside", async () => {
    const user = userEvent.setup();
    render(<RemovingDialog />);
    await user.click(screen.getByRole("button", { name: "Remove me" }));
    expect(document.body).toHaveFocus();
    await user.tab();
    expect(screen.getByRole("button", { name: "OK" })).toHaveFocus();
  });

  it("D3 after the focused element is removed, Shift+Tab moves focus to the last tabbable inside", async () => {
    const user = userEvent.setup();
    render(<RemovingDialog />);
    await user.click(screen.getByRole("button", { name: "Remove me" }));
    expect(document.body).toHaveFocus();
    await user.tab({ shift: true });
    expect(screen.getByRole("button", { name: "Last" })).toHaveFocus();
  });

  it("D3 Tab from the last tabbable wraps to the first, and Shift+Tab from the first wraps to the last", async () => {
    const user = userEvent.setup();
    render(
      <Controlled>
        <button type="button">A</button>
        <button type="button">B</button>
      </Controlled>,
    );
    await user.click(screen.getByRole("button", { name: "Open" }));
    expect(screen.getByRole("button", { name: "A" })).toHaveFocus();
    await user.tab();
    expect(screen.getByRole("button", { name: "B" })).toHaveFocus();
    await user.tab();
    expect(screen.getByRole("button", { name: "A" })).toHaveFocus();
    await user.keyboard("{Shift>}{Tab}{/Shift}");
    expect(screen.getByRole("button", { name: "B" })).toHaveFocus();
  });

  it("D3 with no tabbables, Tab and Shift+Tab keep focus on the dialog", async () => {
    const user = userEvent.setup();
    render(
      <Controlled>
        <p>Just text</p>
      </Controlled>,
    );
    await user.click(screen.getByRole("button", { name: "Open" }));
    const dialog = screen.getByRole("dialog");
    await user.tab();
    expect(dialog).toHaveFocus();
    await user.keyboard("{Shift>}{Tab}{/Shift}");
    expect(dialog).toHaveFocus();
  });

  it("D3 skips disabled, tabIndex=-1, hidden and inert content, both directions", async () => {
    const user = userEvent.setup();
    render(
      <Controlled>
        <button type="button" disabled>
          Off
        </button>
        <button type="button" tabIndex={-1}>
          Skip
        </button>
        <div hidden>
          <button type="button">Hidden</button>
        </div>
        <div inert>
          <button type="button">Inert</button>
        </div>
        <button type="button">Live</button>
        <button type="button">Also</button>
      </Controlled>,
    );
    await user.click(screen.getByRole("button", { name: "Open" }));
    expect(screen.getByRole("button", { name: "Live" })).toHaveFocus();
    await user.tab();
    expect(screen.getByRole("button", { name: "Also" })).toHaveFocus();
    await user.tab();
    expect(screen.getByRole("button", { name: "Live" })).toHaveFocus();
    await user.keyboard("{Shift>}{Tab}{/Shift}");
    expect(screen.getByRole("button", { name: "Also" })).toHaveFocus();
  });

  it("D3 includes elements added after the dialog opened", async () => {
    const user = userEvent.setup();
    render(
      <Controlled>
        <Adder />
      </Controlled>,
    );
    await user.click(screen.getByRole("button", { name: "Open" }));
    await user.click(screen.getByRole("button", { name: "Add" }));
    await user.tab();
    expect(screen.getByRole("button", { name: "Late" })).toHaveFocus();
    await user.tab();
    expect(screen.getByRole("button", { name: "Add" })).toHaveFocus();
  });

  it("D4 Escape and a backdrop click call onOpenChange(false); a click inside the dialog does not", async () => {
    const user = userEvent.setup();
    const onOpenChange = vi.fn();
    render(
      <Dialog open onOpenChange={onOpenChange} title="Confirm">
        <button type="button">OK</button>
      </Dialog>,
    );
    await user.click(screen.getByRole("button", { name: "OK" }));
    await user.click(screen.getByRole("dialog"));
    expect(onOpenChange).not.toHaveBeenCalled();

    await user.click(backdropOf(screen.getByRole("dialog")));
    expect(onOpenChange).toHaveBeenCalledTimes(1);
    expect(onOpenChange).toHaveBeenLastCalledWith(false);

    onOpenChange.mockClear();
    await user.keyboard("{Escape}");
    expect(onOpenChange).toHaveBeenCalledWith(false);
  });

  it("D4 controlled: a parent that keeps open=true keeps the dialog open", async () => {
    const user = userEvent.setup();
    const onOpenChange = vi.fn();
    render(
      <Dialog open onOpenChange={onOpenChange} title="Confirm">
        <button type="button">OK</button>
      </Dialog>,
    );
    await user.keyboard("{Escape}");
    await user.click(backdropOf(screen.getByRole("dialog")));
    expect(onOpenChange).toHaveBeenCalledTimes(2);
    expect(screen.getByRole("dialog")).toBeInTheDocument();
  });

  it("D4 hostile: a drag from inside the content to the backdrop does not close", async () => {
    const user = userEvent.setup();
    const onOpenChange = vi.fn();
    render(
      <Dialog open onOpenChange={onOpenChange} title="Confirm">
        <button type="button">OK</button>
      </Dialog>,
    );
    await user.pointer([
      { keys: "[MouseLeft>]", target: screen.getByRole("button", { name: "OK" }) },
      { target: backdropOf(screen.getByRole("dialog")) },
      { keys: "[/MouseLeft]", target: backdropOf(screen.getByRole("dialog")) },
    ]);
    expect(onOpenChange).not.toHaveBeenCalled();
  });

  it("D4 hostile: a press on the backdrop released inside the content does not close", async () => {
    const user = userEvent.setup();
    const onOpenChange = vi.fn();
    render(
      <Dialog open onOpenChange={onOpenChange} title="Confirm">
        <button type="button">OK</button>
      </Dialog>,
    );
    await user.pointer([
      { keys: "[MouseLeft>]", target: backdropOf(screen.getByRole("dialog")) },
      { target: screen.getByRole("button", { name: "OK" }) },
      { keys: "[/MouseLeft]", target: screen.getByRole("button", { name: "OK" }) },
    ]);
    expect(onOpenChange).not.toHaveBeenCalled();
  });

  it("D5 returns focus to the opener on close, even when a child uses autoFocus", async () => {
    const user = userEvent.setup();
    render(
      <Controlled>
        <input aria-label="Name" autoFocus />
      </Controlled>,
    );
    const opener = screen.getByRole("button", { name: "Open" });
    await user.click(opener);
    expect(screen.getByRole("textbox", { name: "Name" })).toHaveFocus();
    await user.keyboard("{Escape}");
    expect(opener).toHaveFocus();
  });

  it("D5 returns focus to the opener when the dialog unmounts while open", () => {
    const { rerender } = render(<Mountable mounted={false} />);
    const opener = screen.getByRole("button", { name: "Opener" });
    opener.focus();
    rerender(<Mountable mounted />);
    expect(screen.getByRole("button", { name: "OK" })).toHaveFocus();
    rerender(<Mountable mounted={false} />);
    expect(opener).toHaveFocus();
  });

  it("D5 hostile: an opener removed while open does not throw on close", () => {
    const { rerender } = render(<Host showOpener open={false} />);
    screen.getByRole("button", { name: "Opener" }).focus();
    rerender(<Host showOpener open />);
    expect(screen.getByRole("button", { name: "OK" })).toHaveFocus();
    rerender(<Host showOpener={false} open />);
    expect(() => rerender(<Host showOpener={false} open={false} />)).not.toThrow();
    expect(document.activeElement).toBe(document.body);
  });

  it("D5 hostile: open initially on mount moves focus in and returns it to body on unmount", () => {
    const { unmount } = render(
      <Dialog open onOpenChange={() => {}} title="Confirm">
        <button type="button">OK</button>
      </Dialog>,
    );
    expect(screen.getByRole("button", { name: "OK" })).toHaveFocus();
    unmount();
    expect(document.activeElement).toBe(document.body);
  });

  it("D6 Escape closes only the inner dialog, then the outer", async () => {
    const user = userEvent.setup();
    const outerSpy = vi.fn();
    const innerSpy = vi.fn();
    render(<Nested outerSpy={outerSpy} innerSpy={innerSpy} />);

    await user.click(screen.getByRole("button", { name: "Open inner" }));
    expect(screen.getByRole("button", { name: "Inner action" })).toHaveFocus();
    await user.keyboard("{Escape}");
    expect(innerSpy).toHaveBeenCalledTimes(1);
    expect(innerSpy).toHaveBeenCalledWith(false);
    expect(outerSpy).not.toHaveBeenCalled();
    expect(screen.queryByRole("dialog", { name: "Inner" })).toBeNull();

    await user.keyboard("{Escape}");
    expect(outerSpy).toHaveBeenCalledTimes(1);
    expect(outerSpy).toHaveBeenCalledWith(false);
  });

  it("D6 the outer trap does not steal focus from the inner dialog, and inner close returns focus to its opener", async () => {
    const user = userEvent.setup();
    render(<Nested outerSpy={() => {}} innerSpy={() => {}} />);

    await user.click(screen.getByRole("button", { name: "Open inner" }));
    await user.tab();
    expect(screen.getByRole("button", { name: "Inner close" })).toHaveFocus();
    await user.tab();
    expect(screen.getByRole("button", { name: "Inner action" })).toHaveFocus();

    await user.keyboard("{Escape}");
    expect(screen.getByRole("button", { name: "Open inner" })).toHaveFocus();
  });

  it("D6 a backdrop click on the inner dialog closes only the inner one, and clicks inside it do not close the outer", async () => {
    const user = userEvent.setup();
    const outerSpy = vi.fn();
    const innerSpy = vi.fn();
    render(<Nested outerSpy={outerSpy} innerSpy={innerSpy} />);

    await user.click(screen.getByRole("button", { name: "Open inner" }));
    await user.click(screen.getByRole("button", { name: "Inner action" }));
    expect(outerSpy).not.toHaveBeenCalled();
    expect(innerSpy).not.toHaveBeenCalled();

    await user.click(backdropOf(screen.getByRole("dialog", { name: "Inner" })));
    expect(innerSpy).toHaveBeenCalledTimes(1);
    expect(innerSpy).toHaveBeenCalledWith(false);
    expect(outerSpy).not.toHaveBeenCalled();
  });

  it("composition: Escape closes an open combobox popup inside a dialog but not the dialog", async () => {
    const user = userEvent.setup();
    const onOpenChange = vi.fn();
    render(
      <Dialog open onOpenChange={onOpenChange} title="Pick">
        <Combobox
          label="Fruit"
          options={[{ value: "apple", label: "Apple" }]}
          value={null}
          onChange={() => {}}
        />
      </Dialog>,
    );
    await user.type(screen.getByRole("combobox", { name: "Fruit" }), "a");
    await user.keyboard("{Escape}");
    expect(onOpenChange).not.toHaveBeenCalled();
    await user.keyboard("{Escape}");
    expect(onOpenChange).toHaveBeenCalledWith(false);
  });

  it("D2 with Tabs that have no defaultValue, opening from a button focuses the first tab", async () => {
    const user = userEvent.setup();
    render(<TabsDialogNoDefault />);
    await user.click(screen.getByRole("button", { name: "Open" }));
    expect(screen.getByRole("tab", { name: "A" })).toHaveFocus();
  });

  it("D2 with the first tab disabled and no defaultValue, focus goes to the first enabled tab", async () => {
    const user = userEvent.setup();
    render(<TabsDialogNoDefault disableA />);
    await user.click(screen.getByRole("button", { name: "Open" }));
    expect(screen.getByRole("tab", { name: "B" })).toHaveFocus();
  });

  it("D2 with Tabs and no defaultValue, a dialog open on mount focuses the first tab", () => {
    render(
      <Dialog open onOpenChange={() => {}} title="Settings">
        <SectionTabs />
      </Dialog>,
    );
    expect(screen.getByRole("tab", { name: "A" })).toHaveFocus();
  });

  it("D3 Tab and Shift+Tab from a non-tabbable element inside the dialog go to the neighbouring tabbable", async () => {
    const user = userEvent.setup();
    render(
      <Controlled initiallyOpen>
        <button type="button">One</button>
        <button type="button" disabled>
          Off
        </button>
        <div hidden>
          <button type="button">Hidden</button>
        </div>
        <div tabIndex={-1} data-testid="neg">
          neg
        </div>
        <button type="button">Two</button>
      </Controlled>,
    );
    await user.click(screen.getByTestId("neg"));
    await user.tab();
    expect(screen.getByRole("button", { name: "Two" })).toHaveFocus();

    await user.click(screen.getByTestId("neg"));
    await user.tab({ shift: true });
    expect(screen.getByRole("button", { name: "One" })).toHaveFocus();
  });

  it("D3 Tab from a non-tabbable element after the last tabbable wraps to the first", async () => {
    const user = userEvent.setup();
    render(
      <Controlled initiallyOpen>
        <button type="button">Only</button>
        <div tabIndex={-1} data-testid="neg">
          neg
        </div>
      </Controlled>,
    );
    await user.click(screen.getByTestId("neg"));
    await user.tab();
    expect(screen.getByRole("button", { name: "Only" })).toHaveFocus();
  });

  it("D4 Escape with focus on body after the focused button was removed still calls onOpenChange(false)", async () => {
    const user = userEvent.setup();
    const onOpenChange = vi.fn();
    render(<RemoveFocusedDialog onOpenChange={onOpenChange} />);
    await user.click(screen.getByRole("button", { name: "Remove me" }));
    expect(document.body).toHaveFocus();
    await user.keyboard("{Escape}");
    expect(onOpenChange).toHaveBeenCalledTimes(1);
    expect(onOpenChange).toHaveBeenCalledWith(false);
  });

  it("D4 one Escape with focus inside the dialog calls onOpenChange exactly once", async () => {
    const user = userEvent.setup();
    const onOpenChange = vi.fn();
    render(
      <Dialog open onOpenChange={onOpenChange} title="Confirm">
        <button type="button">OK</button>
      </Dialog>,
    );
    expect(screen.getByRole("button", { name: "OK" })).toHaveFocus();
    await user.keyboard("{Escape}");
    expect(onOpenChange).toHaveBeenCalledTimes(1);
    expect(onOpenChange).toHaveBeenCalledWith(false);
  });

  it("D6 an inner dialog opened from body: Escape closes only the inner, focus returns inside the outer, a second Escape closes the outer", async () => {
    const user = userEvent.setup();
    const outerSpy = vi.fn();
    const innerSpy = vi.fn();
    render(<StackedDialogs outerSpy={outerSpy} innerSpy={innerSpy} />);
    (document.activeElement as HTMLElement).blur();
    expect(document.body).toHaveFocus();
    fireEvent.click(screen.getByRole("button", { name: "Open inner" }));
    expect(screen.getByRole("button", { name: "Inner action" })).toHaveFocus();

    await user.keyboard("{Escape}");
    expect(innerSpy).toHaveBeenCalledTimes(1);
    expect(innerSpy).toHaveBeenCalledWith(false);
    expect(outerSpy).not.toHaveBeenCalled();
    expect(screen.getByRole("button", { name: "Open inner" })).toHaveFocus();

    await user.keyboard("{Escape}");
    expect(outerSpy).toHaveBeenCalledTimes(1);
    expect(outerSpy).toHaveBeenCalledWith(false);
    expect(innerSpy).toHaveBeenCalledTimes(1);
  });

  it("G3 forwards className to the dialog element, and G4 two dialogs have distinct ids", () => {
    const props: Omit<DialogProps, "title"> = { open: true, onOpenChange: () => {}, className: "modal" };
    render(
      <>
        <Dialog {...props} title="First" className="modal" data-testid="first">
          <button type="button">A</button>
        </Dialog>
        <Dialog {...props} title="Second">
          <button type="button">B</button>
        </Dialog>
      </>,
    );
    expect(screen.getByTestId("first")).toHaveClass("modal");
    const first = screen.getByRole("dialog", { name: "First" });
    const second = screen.getByRole("dialog", { name: "Second" });
    expect(first.getAttribute("aria-labelledby")).not.toBe(second.getAttribute("aria-labelledby"));
  });
});

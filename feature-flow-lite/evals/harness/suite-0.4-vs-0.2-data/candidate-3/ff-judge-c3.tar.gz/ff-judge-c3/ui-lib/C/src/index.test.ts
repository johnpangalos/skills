import { describe, expect, it } from "vitest";
import * as library from "./index";
import type {
  ComboboxOption,
  ComboboxProps,
  DialogProps,
  TabListProps,
  TabPanelProps,
  TabProps,
  TabsProps,
} from "./index";

describe("public exports (G1)", () => {
  it("exports the six components and nothing else at runtime", () => {
    expect(Object.keys(library).sort()).toEqual(["Combobox", "Dialog", "Tab", "TabList", "TabPanel", "Tabs"]);
  });

  it("exports every props type (checked at compile time by pnpm typecheck)", () => {
    type Exported = [TabsProps, TabListProps, TabProps, TabPanelProps, DialogProps, ComboboxProps, ComboboxOption];
    const exported: Exported | undefined = undefined;
    expect(exported).toBeUndefined();
  });
});

import {
  type ComponentPropsWithoutRef,
  type KeyboardEvent as ReactKeyboardEvent,
  useEffect,
  useId,
  useState,
} from "react";
import { findEnabledIndex } from "../utils/findEnabledIndex";
import { isComposing } from "../utils/isComposing";

export type ComboboxOption = {
  value: string;
  label: string;
  disabled?: boolean;
};

export type ComboboxProps = Omit<ComponentPropsWithoutRef<"div">, "onChange" | "defaultValue"> & {
  label: string;
  options: ComboboxOption[];
  value: string | null;
  onChange: (value: string | null) => void;
  placeholder?: string;
};

// Matching is a plain substring test on lowercased text, so user input is never treated as a RegExp.
function filterOptions(options: ComboboxOption[], query: string): ComboboxOption[] {
  const needle = query.trim().toLowerCase();
  return options.filter((option) => option.label.toLowerCase().includes(needle));
}

// Keeps the active option if it is still visible and enabled, otherwise falls back to the first enabled one.
function keepOrFirst(options: ComboboxOption[], activeValue: string | null): string | null {
  const kept = options.some((option) => option.value === activeValue && !option.disabled);
  return kept ? activeValue : (options.find((option) => !option.disabled)?.value ?? null);
}

// Option ids are derived from the value, encoded so they contain no spaces or collisions.
const optionIdFor = (baseId: string, value: string) => `${baseId}-option-${encodeURIComponent(value)}`;

export function Combobox({ label, options, value, onChange, placeholder, ...rest }: ComboboxProps) {
  const baseId = useId();
  const inputId = `${baseId}-input`;
  const labelId = `${baseId}-label`;
  const listboxId = `${baseId}-listbox`;

  const selectedLabel = options.find((option) => option.value === value)?.label ?? "";
  const [text, setText] = useState(selectedLabel);
  const [query, setQuery] = useState("");
  const [open, setOpen] = useState(false);
  const [activeValue, setActiveValue] = useState<string | null>(null);

  const visible = filterOptions(options, query);
  const activeOption = visible.find((option) => option.value === activeValue && !option.disabled) ?? null;

  // When the list changes under an active option that is gone, reset to the first enabled option.
  useEffect(() => {
    if (activeValue !== null && keepOrFirst(visible, activeValue) !== activeValue) {
      setActiveValue(keepOrFirst(visible, activeValue));
    }
  }, [activeValue, visible]);

  // The input shows the selected label whenever the parent changes the selection.
  useEffect(() => {
    setText(selectedLabel);
  }, [selectedLabel]);

  const closePopup = () => {
    setOpen(false);
    setQuery("");
    setActiveValue(null);
  };

  const selectOption = (option: ComboboxOption) => {
    onChange(option.value);
    closePopup();
    setText(selectedLabel);
  };

  // Clearing the text and then committing (blur or Enter with nothing active) reports null.
  const commitCleared = () => {
    if (text === "" && selectedLabel !== "") onChange(null);
  };

  const moveActive = (step: 1 | -1) => {
    const count = visible.length;
    const current = activeOption ? visible.indexOf(activeOption) : -1;
    // findEnabledIndex wraps the start index, so stepping past either end wraps around.
    const start = current < 0 ? (step === 1 ? 0 : count - 1) : current + step;
    const target = findEnabledIndex(
      visible.map((option) => !option.disabled),
      start,
      step,
    );
    setActiveValue(target < 0 ? null : visible[target].value);
  };

  const handleInput = (nextText: string) => {
    setText(nextText);
    setQuery(nextText);
    setOpen(true);
    const nextVisible = filterOptions(options, nextText);
    setActiveValue(nextText.trim() === "" ? null : keepOrFirst(nextVisible, activeValue));
  };

  const handleKeyDown = (event: ReactKeyboardEvent<HTMLInputElement>) => {
    // During IME composition, keys belong to the input method (Enter confirms the composition, not an option).
    if (isComposing(event.nativeEvent)) return;
    switch (event.key) {
      case "ArrowDown":
      case "ArrowUp":
        event.preventDefault();
        setOpen(true);
        moveActive(event.key === "ArrowDown" ? 1 : -1);
        return;
      case "Enter":
        if (open) event.preventDefault();
        if (open && activeOption) {
          selectOption(activeOption);
          return;
        }
        commitCleared();
        closePopup();
        setText(selectedLabel);
        return;
      case "Escape":
        if (!open) return;
        event.preventDefault();
        event.stopPropagation();
        closePopup();
        setText(selectedLabel);
        return;
      default:
        return;
    }
  };

  const handleBlur = () => {
    commitCleared();
    closePopup();
    setText(selectedLabel);
  };

  return (
    <div {...rest}>
      <label id={labelId} htmlFor={inputId}>
        {label}
      </label>
      <input
        id={inputId}
        role="combobox"
        type="text"
        autoComplete="off"
        aria-autocomplete="list"
        aria-expanded={open}
        aria-controls={listboxId}
        aria-activedescendant={open && activeOption ? optionIdFor(baseId, activeOption.value) : undefined}
        placeholder={placeholder}
        value={text}
        onChange={(event) => handleInput(event.target.value)}
        onKeyDown={handleKeyDown}
        onBlur={handleBlur}
      />
      <div id={listboxId} role="listbox" aria-labelledby={labelId} hidden={!open}>
        {open
          ? visible.map((option) => (
              <div
                key={option.value}
                id={optionIdFor(baseId, option.value)}
                role="option"
                aria-selected={option.value === value}
                aria-disabled={option.disabled ? "true" : undefined}
                onMouseDown={(event) => event.preventDefault()}
                onClick={() => {
                  if (!option.disabled) selectOption(option);
                }}
              >
                {option.label}
              </div>
            ))
          : null}
      </div>
      {open && visible.length === 0 ? <div role="status">No results</div> : null}
    </div>
  );
}

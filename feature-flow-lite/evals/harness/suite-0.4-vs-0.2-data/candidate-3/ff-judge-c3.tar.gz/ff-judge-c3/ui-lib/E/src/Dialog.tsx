import {
  useId,
  useLayoutEffect,
  useRef,
  useState,
  type KeyboardEvent,
  type MouseEvent,
  type ReactNode,
} from "react";
import { createPortal } from "react-dom";

export type DialogProps = {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  title: ReactNode;
  description?: ReactNode;
  className?: string;
  children?: ReactNode;
};

const FOCUSABLE = 'a[href], button, input, select, textarea, [tabindex], [contenteditable="true"]';

// Focusable descendants in DOM order, minus disabled, hidden, inert and tabIndex=-1 content.
function getFocusable(container: HTMLElement): HTMLElement[] {
  return Array.from(container.querySelectorAll<HTMLElement>(FOCUSABLE)).filter(
    (el) => el.tabIndex >= 0 && !el.hasAttribute("disabled") && !el.closest("[hidden], [inert]"),
  );
}

// Where Tab and Shift+Tab move within the trap; undefined when there is nothing to focus.
function nextInTrap(focusable: HTMLElement[], active: Element | null): HTMLElement | undefined {
  const index = focusable.indexOf(active as HTMLElement);
  return focusable[index === -1 || index === focusable.length - 1 ? 0 : index + 1];
}

function previousInTrap(focusable: HTMLElement[], active: Element | null): HTMLElement | undefined {
  const index = focusable.indexOf(active as HTMLElement);
  return focusable[index <= 0 ? focusable.length - 1 : index - 1];
}

export function Dialog({ open, ...props }: DialogProps) {
  if (!open) return null;
  return <DialogLayer {...props} />;
}

// Mounted only while open, so the state initializer below runs before any focus moves.
function DialogLayer({ onOpenChange, title, description, className, children }: Omit<DialogProps, "open">) {
  const baseId = useId();
  const titleId = `${baseId}-title`;
  const descriptionId = `${baseId}-description`;
  const dialogRef = useRef<HTMLDivElement>(null);
  const pressedBackdrop = useRef(false);
  const [returnFocusTo] = useState<Element | null>(() => document.activeElement);

  useLayoutEffect(() => {
    const dialog = dialogRef.current;
    if (dialog && !dialog.contains(document.activeElement)) {
      (getFocusable(dialog)[0] ?? dialog).focus();
    }
    return () => {
      if (returnFocusTo instanceof HTMLElement && returnFocusTo.isConnected && returnFocusTo !== document.body) {
        returnFocusTo.focus();
      }
    };
  }, [returnFocusTo]);

  // Stopping propagation keeps a nested dialog's keys away from the outer dialog.
  const onKeyDown = (event: KeyboardEvent<HTMLDivElement>) => {
    if (event.key === "Escape") {
      event.stopPropagation();
      onOpenChange(false);
    } else if (event.key === "Tab") {
      event.stopPropagation();
      event.preventDefault();
      const dialog = dialogRef.current;
      if (!dialog) return;
      const focusable = getFocusable(dialog);
      const target = event.shiftKey
        ? previousInTrap(focusable, document.activeElement)
        : nextInTrap(focusable, document.activeElement);
      (target ?? dialog).focus();
    }
  };

  // Close only when the press, the release and the click all land on the backdrop itself. The browser
  // sends a click to the common ancestor of press and release, so the release has to be checked too.
  const onBackdropMouseDown = (event: MouseEvent<HTMLDivElement>) => {
    pressedBackdrop.current = event.target === event.currentTarget;
  };

  const onBackdropMouseUp = (event: MouseEvent<HTMLDivElement>) => {
    if (event.target !== event.currentTarget) pressedBackdrop.current = false;
  };

  const onBackdropClick = (event: MouseEvent<HTMLDivElement>) => {
    const closes = pressedBackdrop.current && event.target === event.currentTarget;
    pressedBackdrop.current = false;
    if (closes) onOpenChange(false);
  };

  return createPortal(
    <div
      data-backdrop
      onMouseDown={onBackdropMouseDown}
      onMouseUp={onBackdropMouseUp}
      onClick={onBackdropClick}
    >
      <div
        ref={dialogRef}
        role="dialog"
        aria-modal="true"
        aria-labelledby={titleId}
        aria-describedby={description ? descriptionId : undefined}
        tabIndex={-1}
        className={className}
        onKeyDown={onKeyDown}
      >
        <h2 id={titleId}>{title}</h2>
        {description ? <p id={descriptionId}>{description}</p> : null}
        {children}
      </div>
    </div>,
    document.body,
  );
}

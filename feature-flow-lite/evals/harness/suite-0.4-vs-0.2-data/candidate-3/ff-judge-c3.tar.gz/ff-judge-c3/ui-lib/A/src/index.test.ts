import { describe, expect, it } from "vitest";
import * as library from "./index";
import type {
  ComboboxOption,
  ComboboxProps,
  DialogProps,
  TabListProps,
  TabPanelProps,
  TabProps,
  TabsProps,
} from "./index";

describe("index", () => {
  it("G1 exports every component", () => {
    expect(Object.keys(library).sort()).toEqual(["Combobox", "Dialog", "Tab", "TabList", "TabPanel", "Tabs"]);
    for (const name of ["Combobox", "Dialog", "Tab", "TabList", "TabPanel", "Tabs"] as const) {
      expect(typeof library[name]).toBe("function");
    }
  });

  it("G1 exports the prop types (checked by the compiler)", () => {
    const exported: [TabsProps, TabListProps, TabProps, TabPanelProps, DialogProps, ComboboxProps, ComboboxOption] | null =
      null;
    expect(exported).toBeNull();
  });
});

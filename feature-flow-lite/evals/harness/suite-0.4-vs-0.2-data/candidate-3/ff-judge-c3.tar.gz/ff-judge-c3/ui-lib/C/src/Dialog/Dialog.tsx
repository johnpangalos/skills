import { useEffect, useId, useRef, useState, type HTMLAttributes, type ReactNode } from "react";
import { createPortal } from "react-dom";

export type DialogProps = Omit<HTMLAttributes<HTMLDivElement>, "title"> & {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  title: ReactNode;
  description?: ReactNode;
};

// Open dialogs, innermost last. Only the innermost one handles Escape, Tab and focus leaving it.
const openDialogs: object[] = [];

const TABBABLE =
  'a[href], area[href], button, input:not([type="hidden"]), select, textarea, iframe, [contenteditable]:not([contenteditable="false"]), [tabindex]';

// Attribute-based only: jsdom has no layout, so no offsetParent or getClientRects checks.
function tabbableIn(root: HTMLElement): HTMLElement[] {
  return Array.from(root.querySelectorAll<HTMLElement>(TABBABLE)).filter(
    (element) =>
      element.tabIndex >= 0 &&
      !element.matches(":disabled") &&
      element.getAttribute("aria-disabled") !== "true" &&
      element.closest("[hidden], [inert]") === null,
  );
}

// document.activeElement stops at a shadow host; follow shadow roots to the focused element.
function focusedElement(): Element | null {
  let element = document.activeElement;
  while (element?.shadowRoot?.activeElement) element = element.shadowRoot.activeElement;
  return element;
}

function focusFirstIn(dialog: HTMLElement) {
  (tabbableIn(dialog)[0] ?? dialog).focus();
}

export function Dialog({ open, onOpenChange, title, description, children, ...rest }: DialogProps) {
  const titleId = useId();
  const descriptionId = useId();
  const dialogRef = useRef<HTMLDivElement>(null);
  const onOpenChangeRef = useRef(onOpenChange);
  const hasDescription = description !== undefined && description !== null;

  // Read during the render that opens the dialog, before any autoFocus child takes focus or
  // StrictMode re-runs refs. This is the element that had focus before the dialog opened.
  const [wasOpen, setWasOpen] = useState(false);
  const [opener, setOpener] = useState<Element | null>(null);
  if (open !== wasOpen) {
    setWasOpen(open);
    if (open) setOpener(focusedElement());
  }

  useEffect(() => {
    onOpenChangeRef.current = onOpenChange;
  });

  useEffect(() => {
    const dialog = dialogRef.current;
    if (!open || !dialog) return;

    const token = {};
    openDialogs.push(token);
    const isTop = () => openDialogs[openDialogs.length - 1] === token;

    if (!dialog.contains(document.activeElement)) focusFirstIn(dialog);

    const onKeyDown = (event: KeyboardEvent) => {
      if (!isTop()) return;
      if (event.key === "Escape") {
        onOpenChangeRef.current(false);
      } else if (event.key === "Tab") {
        // Wrap focus between the first and last tabbable elements.
        event.preventDefault();
        const items = tabbableIn(dialog);
        if (items.length === 0) {
          dialog.focus();
          return;
        }
        const index = items.indexOf(document.activeElement as HTMLElement);
        const last = items.length - 1;
        if (event.shiftKey) {
          items[index <= 0 ? last : index - 1].focus();
        } else {
          items[index === -1 || index === last ? 0 : index + 1].focus();
        }
      }
    };
    const onFocusIn = (event: FocusEvent) => {
      if (isTop() && !dialog.contains(event.target as Node)) focusFirstIn(dialog);
    };
    document.addEventListener("keydown", onKeyDown);
    document.addEventListener("focusin", onFocusIn);

    return () => {
      document.removeEventListener("keydown", onKeyDown);
      document.removeEventListener("focusin", onFocusIn);
      openDialogs.splice(openDialogs.indexOf(token), 1);
      if (opener instanceof HTMLElement && opener.isConnected) opener.focus();
    };
  }, [open, opener]);

  if (!open) return null;

  return createPortal(
    <>
      <div data-dialog-backdrop="" aria-hidden="true" onClick={() => onOpenChange(false)} />
      <div
        {...rest}
        ref={dialogRef}
        role="dialog"
        aria-modal="true"
        aria-labelledby={titleId}
        aria-describedby={hasDescription ? descriptionId : undefined}
        tabIndex={-1}
      >
        <h2 id={titleId}>{title}</h2>
        {hasDescription && <p id={descriptionId}>{description}</p>}
        {children}
      </div>
    </>,
    document.body,
  );
}

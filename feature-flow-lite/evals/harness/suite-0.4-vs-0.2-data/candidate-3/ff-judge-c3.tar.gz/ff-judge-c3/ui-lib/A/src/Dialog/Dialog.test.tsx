import { fireEvent, render, screen, waitFor } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { useState } from "react";
import { describe, expect, it, vi } from "vitest";
import { Tabs, TabList, Tab, TabPanel } from "../Tabs/Tabs";
import { Dialog } from "./Dialog";

function Harness({
  onClose,
  description,
  initialOpen = false,
  children,
}: {
  onClose?: (open: boolean) => void;
  description?: string;
  initialOpen?: boolean;
  children?: React.ReactNode;
}) {
  const [open, setOpen] = useState(initialOpen);
  return (
    <>
      <button onClick={() => setOpen(true)}>Open</button>
      <Dialog
        open={open}
        title="Confirm"
        description={description}
        onOpenChange={(next) => {
          onClose?.(next);
          setOpen(next);
        }}
      >
        {children ?? (
          <>
            <button>First</button>
            <button>Second</button>
          </>
        )}
      </Dialog>
    </>
  );
}

const dialogEl = () => screen.getByRole("dialog");
const backdropEl = () => document.querySelector("[data-backdrop]") as HTMLElement;

describe("Dialog", () => {
  it("D1 renders nothing when closed", () => {
    render(
      <Dialog open={false} onOpenChange={() => {}} title="Confirm">
        <button>Inside</button>
      </Dialog>,
    );
    expect(screen.queryByRole("dialog", { hidden: true })).toBeNull();
    expect(document.querySelector("[data-backdrop]")).toBeNull();
    expect(document.body.textContent).toBe("");
  });

  it("D1 when open renders a backdrop and a modal dialog labelled by its title, portaled into body", () => {
    const { container } = render(
      <Dialog open onOpenChange={() => {}} title="Confirm">
        <button>Inside</button>
      </Dialog>,
    );
    const dialog = dialogEl();
    expect(dialog.getAttribute("aria-modal")).toBe("true");
    expect(dialog.getAttribute("aria-labelledby")).toBe(screen.getByRole("heading", { name: "Confirm" }).id);
    expect(dialog.hasAttribute("aria-describedby")).toBe(false);
    expect(backdropEl()).not.toBeNull();
    expect(backdropEl().contains(dialog)).toBe(true);
    expect(backdropEl().parentElement).toBe(document.body);
    expect(container.contains(dialog)).toBe(false);
  });

  it("D1 aria-describedby points at the description only when one is given", () => {
    render(
      <Dialog open onOpenChange={() => {}} title="Confirm" description="Delete the file?">
        <button>Inside</button>
      </Dialog>,
    );
    const describedBy = dialogEl().getAttribute("aria-describedby");
    expect(describedBy).not.toBeNull();
    expect(document.getElementById(describedBy ?? "")?.textContent).toBe("Delete the file?");
  });

  it("D2 on open moves focus to the first tabbable element inside the dialog", async () => {
    const user = userEvent.setup();
    render(<Harness />);
    await user.click(screen.getByRole("button", { name: "Open" }));
    expect(document.activeElement).toBe(screen.getByRole("button", { name: "First" }));
  });

  it("D2 focuses the dialog container itself when nothing inside is tabbable", async () => {
    const user = userEvent.setup();
    render(
      <Harness>
        <p>Just text</p>
      </Harness>,
    );
    await user.click(screen.getByRole("button", { name: "Open" }));
    expect(document.activeElement).toBe(dialogEl());
    expect(dialogEl().getAttribute("tabindex")).toBe("-1");
  });

  it("D2 a child with autoFocus keeps focus", async () => {
    const user = userEvent.setup();
    render(
      <Harness>
        <button>First</button>
        <input aria-label="Name" autoFocus />
      </Harness>,
    );
    await user.click(screen.getByRole("button", { name: "Open" }));
    expect(document.activeElement).toBe(screen.getByRole("textbox", { name: "Name" }));
  });

  it("D3 Tab from the last tabbable element wraps to the first", async () => {
    const user = userEvent.setup();
    render(<Harness />);
    await user.click(screen.getByRole("button", { name: "Open" }));
    await user.tab();
    expect(document.activeElement).toBe(screen.getByRole("button", { name: "Second" }));
    await user.tab();
    expect(document.activeElement).toBe(screen.getByRole("button", { name: "First" }));
  });

  it("D3 Shift+Tab from the first tabbable element wraps to the last", async () => {
    const user = userEvent.setup();
    render(<Harness />);
    await user.click(screen.getByRole("button", { name: "Open" }));
    await user.tab({ shift: true });
    expect(document.activeElement).toBe(screen.getByRole("button", { name: "Second" }));
  });

  it("D3 with no tabbable children, Tab and Shift+Tab keep focus on the dialog", async () => {
    const user = userEvent.setup();
    render(
      <Harness>
        <p>Just text</p>
      </Harness>,
    );
    await user.click(screen.getByRole("button", { name: "Open" }));
    await user.tab();
    expect(document.activeElement).toBe(dialogEl());
    await user.tab({ shift: true });
    expect(document.activeElement).toBe(dialogEl());
  });

  it("D3 hostile: disabled, tabIndex=-1, hidden and inert content is never reached by Tab", async () => {
    const user = userEvent.setup();
    render(
      <Harness>
        <button>First</button>
        <button disabled>Disabled</button>
        <button tabIndex={-1}>Negative</button>
        <div hidden>
          <button>Hidden</button>
        </div>
        <div inert>
          <button>Inert</button>
        </div>
        <button>Last</button>
      </Harness>,
    );
    await user.click(screen.getByRole("button", { name: "Open" }));
    const seen: string[] = [];
    for (let i = 0; i < 4; i++) {
      await user.tab();
      seen.push(document.activeElement?.textContent ?? "");
    }
    expect(seen).toEqual(["Last", "First", "Last", "First"]);
  });

  it("D3 elements added after the dialog opened are part of the trap", async () => {
    const user = userEvent.setup();
    const { rerender } = render(
      <Dialog open onOpenChange={() => {}} title="Confirm">
        <button>First</button>
      </Dialog>,
    );
    rerender(
      <Dialog open onOpenChange={() => {}} title="Confirm">
        <button>First</button>
        <button>Late</button>
      </Dialog>,
    );
    await user.tab();
    expect(document.activeElement).toBe(screen.getByRole("button", { name: "Late" }));
    await user.tab();
    expect(document.activeElement).toBe(screen.getByRole("button", { name: "First" }));
  });

  it("D3 focus that escapes the dialog is pulled back inside", async () => {
    const user = userEvent.setup();
    render(
      <>
        <button>Outside</button>
        <Harness />
      </>,
    );
    await user.click(screen.getByRole("button", { name: "Open" }));
    await user.click(screen.getByRole("button", { name: "Outside" }));
    expect(dialogEl().contains(document.activeElement)).toBe(true);
    expect(document.activeElement).toBe(screen.getByRole("button", { name: "First" }));
  });

  it("D4 Escape calls onOpenChange(false)", async () => {
    const user = userEvent.setup();
    const onOpenChange = vi.fn();
    render(
      <Dialog open onOpenChange={onOpenChange} title="Confirm">
        <button>First</button>
      </Dialog>,
    );
    await user.keyboard("{Escape}");
    expect(onOpenChange.mock.calls).toEqual([[false]]);
  });

  it("D4 a click on the backdrop calls onOpenChange(false)", async () => {
    const user = userEvent.setup();
    const onOpenChange = vi.fn();
    render(
      <Dialog open onOpenChange={onOpenChange} title="Confirm">
        <button>First</button>
      </Dialog>,
    );
    await user.click(backdropEl());
    expect(onOpenChange.mock.calls).toEqual([[false]]);
  });

  it("D4 clicks inside the content never close the dialog", async () => {
    const user = userEvent.setup();
    const onOpenChange = vi.fn();
    render(
      <Dialog open onOpenChange={onOpenChange} title="Confirm" description="Body text">
        <button>First</button>
      </Dialog>,
    );
    await user.click(screen.getByRole("button", { name: "First" }));
    await user.click(screen.getByText("Body text"));
    await user.click(dialogEl());
    expect(onOpenChange).not.toHaveBeenCalled();
  });

  it("D4 hostile: a drag that starts inside the content and ends on the backdrop does not close", async () => {
    const user = userEvent.setup();
    const onOpenChange = vi.fn();
    render(
      <Dialog open onOpenChange={onOpenChange} title="Confirm">
        <button>First</button>
      </Dialog>,
    );
    await user.pointer([
      { keys: "[MouseLeft>]", target: screen.getByRole("button", { name: "First" }) },
      { target: backdropEl() },
      { keys: "[/MouseLeft]", target: backdropEl() },
    ]);
    expect(onOpenChange).not.toHaveBeenCalled();
  });

  it("D5 closing returns focus to the element that had it before opening", async () => {
    const user = userEvent.setup();
    render(<Harness />);
    const opener = screen.getByRole("button", { name: "Open" });
    await user.click(opener);
    expect(document.activeElement).toBe(screen.getByRole("button", { name: "First" }));
    await user.keyboard("{Escape}");
    expect(screen.queryByRole("dialog")).toBeNull();
    expect(document.activeElement).toBe(opener);
  });

  it("D5 unmounting an open dialog returns focus to the opener", async () => {
    const opener = document.createElement("button");
    document.body.appendChild(opener);
    opener.focus();
    const { rerender, unmount } = render(
      <Dialog open={false} onOpenChange={() => {}} title="Confirm">
        <button>First</button>
      </Dialog>,
    );
    rerender(
      <Dialog open onOpenChange={() => {}} title="Confirm">
        <button>First</button>
      </Dialog>,
    );
    await waitFor(() => expect(document.activeElement).toBe(screen.getByRole("button", { name: "First" })));
    unmount();
    expect(document.activeElement).toBe(opener);
    opener.remove();
  });

  it("D5 hostile: an opener removed from the DOM while open is not focused on close", () => {
    const opener = document.createElement("button");
    document.body.appendChild(opener);
    opener.focus();
    const { rerender } = render(
      <Dialog open onOpenChange={() => {}} title="Confirm">
        <button>First</button>
      </Dialog>,
    );
    opener.remove();
    rerender(
      <Dialog open={false} onOpenChange={() => {}} title="Confirm">
        <button>First</button>
      </Dialog>,
    );
    expect(document.activeElement).toBe(document.body);
  });

  it("D5 hostile: toggling open rapidly ends with focus back on the opener", async () => {
    const user = userEvent.setup();
    render(<Harness />);
    const opener = screen.getByRole("button", { name: "Open" });
    await user.click(opener);
    for (let i = 0; i < 3; i++) {
      await user.keyboard("{Escape}");
      await user.click(opener);
    }
    await user.keyboard("{Escape}");
    expect(screen.queryByRole("dialog")).toBeNull();
    expect(document.activeElement).toBe(opener);
  });

  it("D6 nested: Escape closes only the inner dialog and focus returns to the opener inside the outer one", async () => {
    const user = userEvent.setup();
    function Nested() {
      const [outer, setOuter] = useState(false);
      const [inner, setInner] = useState(false);
      return (
        <>
          <button onClick={() => setOuter(true)}>Open outer</button>
          <Dialog open={outer} onOpenChange={setOuter} title="Outer">
            <button onClick={() => setInner(true)}>Open inner</button>
            <button>Outer last</button>
            <Dialog open={inner} onOpenChange={setInner} title="Inner">
              <button>Inner action</button>
            </Dialog>
          </Dialog>
        </>
      );
    }
    render(<Nested />);
    await user.click(screen.getByRole("button", { name: "Open outer" }));
    await user.click(screen.getByRole("button", { name: "Open inner" }));
    expect(document.activeElement).toBe(screen.getByRole("button", { name: "Inner action" }));
    await user.keyboard("{Escape}");
    expect(screen.queryByRole("dialog", { name: "Inner" })).toBeNull();
    expect(screen.getByRole("dialog", { name: "Outer" })).not.toBeNull();
    expect(document.activeElement).toBe(screen.getByRole("button", { name: "Open inner" }));
  });

  it("D6 nested: the outer trap still works after the inner dialog closes", async () => {
    const user = userEvent.setup();
    function Nested() {
      const [outer, setOuter] = useState(false);
      const [inner, setInner] = useState(false);
      return (
        <>
          <button onClick={() => setOuter(true)}>Open outer</button>
          <Dialog open={outer} onOpenChange={setOuter} title="Outer">
            <button onClick={() => setInner(true)}>Open inner</button>
            <button>Outer last</button>
            <Dialog open={inner} onOpenChange={setInner} title="Inner">
              <button>Inner action</button>
            </Dialog>
          </Dialog>
        </>
      );
    }
    render(<Nested />);
    await user.click(screen.getByRole("button", { name: "Open outer" }));
    await user.click(screen.getByRole("button", { name: "Open inner" }));
    await user.keyboard("{Escape}");
    await user.tab();
    expect(document.activeElement).toBe(screen.getByRole("button", { name: "Outer last" }));
    await user.tab();
    expect(document.activeElement).toBe(screen.getByRole("button", { name: "Open inner" }));
  });

  it("D6 nested: an inner dialog's trap holds focus inside the inner dialog only", async () => {
    const user = userEvent.setup();
    render(
      <Harness initialOpen>
        <Dialog open onOpenChange={() => {}} title="Inner">
          <button>Inner action</button>
        </Dialog>
      </Harness>,
    );
    await user.tab();
    expect(document.activeElement).toBe(screen.getByRole("button", { name: "Inner action" }));
    await user.tab();
    expect(document.activeElement).toBe(screen.getByRole("button", { name: "Inner action" }));
  });

  it("D7 controlled: if the parent ignores onOpenChange(false) the dialog stays open", async () => {
    const user = userEvent.setup();
    const onOpenChange = vi.fn();
    render(
      <Dialog open onOpenChange={onOpenChange} title="Confirm">
        <button>First</button>
      </Dialog>,
    );
    await user.keyboard("{Escape}");
    await user.click(backdropEl());
    expect(onOpenChange.mock.calls).toEqual([[false], [false]]);
    expect(dialogEl()).not.toBeNull();
  });

  it("D7 hostile: Escape still closes a dialog with no focusable children", async () => {
    const user = userEvent.setup();
    const onOpenChange = vi.fn();
    render(
      <Dialog open onOpenChange={onOpenChange} title="Confirm">
        <p>Just text</p>
      </Dialog>,
    );
    await user.keyboard("{Escape}");
    expect(onOpenChange.mock.calls).toEqual([[false]]);
  });

  it("D7 hostile: an Escape whose default was already prevented by a child does not close the dialog", async () => {
    const user = userEvent.setup();
    const onOpenChange = vi.fn();
    render(
      <Dialog open onOpenChange={onOpenChange} title="Confirm">
        <button onKeyDown={(event) => event.preventDefault()}>First</button>
      </Dialog>,
    );
    await user.keyboard("{Escape}");
    expect(onOpenChange).not.toHaveBeenCalled();
  });

  it("TRIGGERED focus: closing returns focus to the opener even when a child uses autoFocus", async () => {
    const user = userEvent.setup();
    render(
      <Harness>
        <input aria-label="Name" autoFocus />
      </Harness>,
    );
    const opener = screen.getByRole("button", { name: "Open" });
    await user.click(opener);
    expect(document.activeElement).toBe(screen.getByRole("textbox", { name: "Name" }));
    await user.keyboard("{Escape}");
    expect(document.activeElement).toBe(opener);
  });

  it("TRIGGERED focus: Tab and Shift+Tab never reach a Tabs panel hidden by the component, or disabled, inert or tabIndex=-1 content", async () => {
    const user = userEvent.setup();
    render(
      <Harness>
        <Tabs defaultValue="one">
          <TabList aria-label="Inside">
            <Tab value="one">One</Tab>
            <Tab value="two">Two</Tab>
          </TabList>
          <TabPanel value="one">
            <button>Panel one action</button>
          </TabPanel>
          <TabPanel value="two">
            <button>Hidden action</button>
          </TabPanel>
        </Tabs>
        <button disabled>Disabled</button>
        <button tabIndex={-1}>Negative</button>
        <div inert>
          <button>Inert</button>
        </div>
        <button>Close</button>
      </Harness>,
    );
    await user.click(screen.getByRole("button", { name: "Open" }));
    expect(document.activeElement).toBe(screen.getByRole("tab", { name: "One" }));
    const seen: string[] = [];
    for (let i = 0; i < 8; i++) {
      await user.tab();
      seen.push(document.activeElement?.textContent ?? "");
    }
    expect(seen).not.toContain("Hidden action");
    expect(seen).not.toContain("Disabled");
    expect(seen).not.toContain("Negative");
    expect(seen).not.toContain("Inert");
    expect(seen).toContain("Panel one action");
    const backwards: string[] = [];
    for (let i = 0; i < 4; i++) {
      await user.tab({ shift: true });
      backwards.push(document.activeElement?.textContent ?? "");
    }
    expect(backwards).not.toContain("Hidden action");
    expect(backwards).not.toContain("Disabled");
    expect(backwards).not.toContain("Negative");
    expect(backwards).not.toContain("Inert");
    expect(backwards).toContain("Close");
  });

  it("TRIGGERED focus: a Tabs without defaultValue inside a dialog opens focus on its first enabled tab", async () => {
    const user = userEvent.setup();
    render(
      <Harness>
        <Tabs>
          <TabList aria-label="Inside">
            <Tab value="off" disabled>
              Off
            </Tab>
            <Tab value="one">One</Tab>
          </TabList>
          <TabPanel value="off">off panel</TabPanel>
          <TabPanel value="one">one panel</TabPanel>
        </Tabs>
      </Harness>,
    );
    await user.click(screen.getByRole("button", { name: "Open" }));
    expect(document.activeElement).toBe(screen.getByRole("tab", { name: "One" }));
  });

  it("TRIGGERED nesting: one Escape closes only the top dialog, and each dialog keeps its own trap", async () => {
    const user = userEvent.setup();
    const onOuter = vi.fn();
    const onInner = vi.fn();
    render(
      <Dialog open onOpenChange={onOuter} title="Outer">
        <button>Outer action</button>
        <Dialog open onOpenChange={onInner} title="Inner">
          <button>Inner action</button>
        </Dialog>
      </Dialog>,
    );
    await user.keyboard("{Escape}");
    expect(onInner.mock.calls).toEqual([[false]]);
    expect(onOuter).not.toHaveBeenCalled();
    await user.tab();
    expect(document.activeElement).toBe(screen.getByRole("button", { name: "Inner action" }));
  });

  it("G2 passes className and native props through to the dialog element", () => {
    render(
      <Dialog open onOpenChange={() => {}} title="Confirm" className="modal" data-testid="dialog">
        <button>First</button>
      </Dialog>,
    );
    expect(dialogEl().getAttribute("class")).toBe("modal");
    expect(dialogEl().getAttribute("data-testid")).toBe("dialog");
  });

  it("G3 two dialogs on one page have no duplicate ids", () => {
    render(
      <>
        <Dialog open onOpenChange={() => {}} title="A" description="a">
          <button>A</button>
        </Dialog>
        <Dialog open onOpenChange={() => {}} title="B" description="b">
          <button>B</button>
        </Dialog>
      </>,
    );
    const ids = Array.from(document.querySelectorAll("[id]"), (element) => element.id);
    expect(ids.length).toBe(4);
    expect(new Set(ids).size).toBe(ids.length);
  });

  it("D3 a hidden input last in the dialog does not stop Tab or Shift+Tab from wrapping", async () => {
    const user = userEvent.setup();
    render(
      <Dialog open onOpenChange={() => {}} title="Confirm">
        <button>first</button>
        <button>second</button>
        <input type="hidden" name="csrf" value="x" />
      </Dialog>,
    );
    await waitFor(() => expect(document.activeElement).toBe(screen.getByRole("button", { name: "first" })));
    await user.tab();
    expect(document.activeElement).toBe(screen.getByRole("button", { name: "second" }));
    await user.tab();
    expect(document.activeElement).toBe(screen.getByRole("button", { name: "first" }));
    await user.tab({ shift: true });
    expect(document.activeElement).toBe(screen.getByRole("button", { name: "second" }));
  });

  it("D3 a contenteditable=false element last in the dialog does not stop Tab or Shift+Tab from wrapping", async () => {
    const user = userEvent.setup();
    render(
      <Dialog open onOpenChange={() => {}} title="Confirm">
        <button>first</button>
        <button>second</button>
        <div contentEditable="false">static text</div>
      </Dialog>,
    );
    await user.tab();
    expect(document.activeElement).toBe(screen.getByRole("button", { name: "second" }));
    await user.tab();
    expect(document.activeElement).toBe(screen.getByRole("button", { name: "first" }));
    await user.tab({ shift: true });
    expect(document.activeElement).toBe(screen.getByRole("button", { name: "second" }));
  });

  it("D4 a press that starts on the backdrop and is released inside the content does not close", async () => {
    const user = userEvent.setup();
    const onOpenChange = vi.fn();
    render(
      <Dialog open onOpenChange={onOpenChange} title="Confirm">
        <button>First</button>
      </Dialog>,
    );
    const first = screen.getByRole("button", { name: "First" });
    await user.pointer([
      { keys: "[MouseLeft>]", target: backdropEl() },
      { target: first },
      { keys: "[/MouseLeft]", target: first },
    ]);
    expect(onOpenChange).not.toHaveBeenCalled();
    expect(dialogEl()).not.toBeNull();
  });

  it("IME: an Escape keydown during composition (isComposing or keyCode 229) does not close the dialog", () => {
    const onOpenChange = vi.fn();
    render(
      <Dialog open onOpenChange={onOpenChange} title="Confirm">
        <button>Inside</button>
      </Dialog>,
    );
    fireEvent.keyDown(dialogEl(), { key: "Escape", isComposing: true });
    fireEvent.keyDown(dialogEl(), { key: "Escape", keyCode: 229 });
    expect(onOpenChange).not.toHaveBeenCalled();
    fireEvent.keyDown(dialogEl(), { key: "Escape" });
    expect(onOpenChange.mock.calls).toEqual([[false]]);
  });

  it("D4 after a backdrop click, Enter on a content button or a click inside the content does not close again", async () => {
    const user = userEvent.setup();
    const onOpenChange = vi.fn();
    render(
      <Dialog open onOpenChange={onOpenChange} title="Confirm">
        <button>Save</button>
      </Dialog>,
    );
    await user.click(backdropEl());
    expect(onOpenChange).toHaveBeenCalledTimes(1);
    const save = screen.getByRole("button", { name: "Save" });
    save.focus();
    await user.keyboard("{Enter}");
    await user.click(save);
    expect(onOpenChange.mock.calls).toEqual([[false]]);
  });

  it("D3 hostile: a contentEditable=\"False\" paragraph last in the dialog does not stop Tab or Shift+Tab from wrapping", async () => {
    const user = userEvent.setup();
    // React's types only allow lowercase; the mixed case is the hostile input under test.
    const mixedCase = "False" as unknown as "false";
    render(
      <Dialog open onOpenChange={() => {}} title="Confirm">
        <button>first</button>
        <button>second</button>
        <p contentEditable={mixedCase}>static text</p>
      </Dialog>,
    );
    await user.tab();
    expect(document.activeElement).toBe(screen.getByRole("button", { name: "second" }));
    await user.tab();
    expect(document.activeElement).toBe(screen.getByRole("button", { name: "first" }));
    await user.tab({ shift: true });
    expect(document.activeElement).toBe(screen.getByRole("button", { name: "second" }));
  });

  it("D3 a contentEditable=\"false\" element with tabIndex=0 is reached by Tab", async () => {
    const user = userEvent.setup();
    render(
      <Dialog open onOpenChange={() => {}} title="Confirm">
        <button>first</button>
        <div contentEditable="false" tabIndex={0}>
          editor
        </div>
        <button>second</button>
      </Dialog>,
    );
    await user.tab();
    expect(document.activeElement).toBe(screen.getByText("editor"));
  });
});

import { useId, useLayoutEffect, useRef, type HTMLAttributes, type ReactNode } from "react";
import { createPortal } from "react-dom";

export interface DialogProps extends HTMLAttributes<HTMLDivElement> {
  /** Whether the dialog is shown. Controlled: the parent owns this state. */
  open: boolean;
  /** Called with false on Escape or a backdrop click. The parent must set `open` itself. */
  onOpenChange: (open: boolean) => void;
  /** Rendered as the heading and used as the accessible name. */
  title: string;
  /** Linked with aria-describedby when given. */
  description?: string;
  children?: ReactNode;
}

interface OpenDialog {
  element: HTMLElement;
  close: () => void;
}

// Open dialogs, outermost first. Only the top entry handles Escape and Tab.
const openDialogs: OpenDialog[] = [];

const TABBABLE = "a[href],button,input:not([type='hidden']),select,textarea,[tabindex],[contenteditable='true']";

// Computed at keypress time so elements added after opening are included.
function tabbables(root: HTMLElement): HTMLElement[] {
  return Array.from(root.querySelectorAll<HTMLElement>(TABBABLE)).filter(
    (element) =>
      !element.matches(":disabled") &&
      !element.matches("input[type='hidden']") &&
      element.tabIndex >= 0 &&
      element.closest("[hidden],[inert]") === null,
  );
}

function focusFirst(root: HTMLElement) {
  (tabbables(root)[0] ?? root).focus();
}

function cycleFocus(event: globalThis.KeyboardEvent, root: HTMLElement) {
  event.preventDefault();
  const items = tabbables(root);
  if (items.length === 0) {
    root.focus();
    return;
  }
  const index = items.indexOf(document.activeElement as HTMLElement);
  if (index === -1) {
    (event.shiftKey ? items[items.length - 1] : items[0]).focus();
    return;
  }
  const step = event.shiftKey ? -1 : 1;
  items[(index + step + items.length) % items.length].focus();
}

export function Dialog({
  open,
  onOpenChange,
  title,
  description,
  className,
  children,
  onMouseDown: onUserMouseDown,
  ...rest
}: DialogProps) {
  const titleId = useId();
  const descriptionId = useId();
  const dialogRef = useRef<HTMLDivElement>(null);
  const openerRef = useRef<{ element: Element | null } | null>(null);
  const pressedBackdrop = useRef(false);
  const onOpenChangeRef = useRef(onOpenChange);
  onOpenChangeRef.current = onOpenChange;

  // Captured during render, before autoFocus or the effect below can move focus into the dialog.
  if (open && openerRef.current === null) {
    openerRef.current = { element: document.activeElement };
  }

  useLayoutEffect(() => {
    const element = dialogRef.current;
    if (!open || element === null) return;

    const entry: OpenDialog = { element, close: () => onOpenChangeRef.current(false) };
    openDialogs.push(entry);
    const isTop = () => openDialogs[openDialogs.length - 1] === entry;

    if (!element.contains(document.activeElement)) focusFirst(element);

    const onKeyDown = (event: globalThis.KeyboardEvent) => {
      if (!isTop()) return;
      if (event.key === "Escape") {
        entry.close();
      } else if (event.key === "Tab") {
        cycleFocus(event, element);
      }
    };
    const onFocusIn = (event: globalThis.FocusEvent) => {
      if (isTop() && !element.contains(event.target as Node)) focusFirst(element);
    };
    document.addEventListener("keydown", onKeyDown);
    document.addEventListener("focusin", onFocusIn);

    return () => {
      document.removeEventListener("keydown", onKeyDown);
      document.removeEventListener("focusin", onFocusIn);
      openDialogs.splice(openDialogs.indexOf(entry), 1);
      const opener = openerRef.current?.element;
      openerRef.current = null;
      if (opener instanceof HTMLElement && opener.isConnected) opener.focus();
    };
  }, [open]);

  if (!open) return null;

  return createPortal(
    <>
      <div
        data-backdrop=""
        onMouseDown={(event) => {
          pressedBackdrop.current = event.target === event.currentTarget;
        }}
        onMouseUp={(event) => {
          if (pressedBackdrop.current && event.target === event.currentTarget) onOpenChange(false);
          pressedBackdrop.current = false;
        }}
      />
      <div
        {...rest}
        ref={dialogRef}
        role="dialog"
        aria-modal="true"
        aria-labelledby={titleId}
        aria-describedby={description ? descriptionId : undefined}
        tabIndex={-1}
        className={className}
        onMouseDown={(event) => {
          onUserMouseDown?.(event);
          pressedBackdrop.current = false;
        }}
      >
        <h2 id={titleId}>{title}</h2>
        {description ? <p id={descriptionId}>{description}</p> : null}
        {children}
      </div>
    </>,
    document.body,
  );
}

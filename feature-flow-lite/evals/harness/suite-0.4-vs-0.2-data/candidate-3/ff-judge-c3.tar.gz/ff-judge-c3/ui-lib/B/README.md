# @acme/ui

Accessible React 19 components: `Tabs`, `Dialog` and `Combobox`. They are typed, carry no styles, and forward `className` and other DOM props to their main element. Every generated id comes from `React.useId()`.

## Scripts

- `pnpm test` runs the Vitest suite (jsdom, Testing Library).
- `pnpm typecheck` runs `tsc --noEmit`.

## Tabs

Follows the WAI-ARIA tabs pattern.

```tsx
import { Tab, TabList, TabPanel, Tabs } from "@acme/ui";

<Tabs defaultValue="profile">
  <TabList aria-label="Account">
    <Tab value="profile">Profile</Tab>
    <Tab value="billing" disabled>Billing</Tab>
    <Tab value="security">Security</Tab>
  </TabList>
  <TabPanel value="profile">Profile settings</TabPanel>
  <TabPanel value="security">Security settings</TabPanel>
</Tabs>;
```

### Tabs props

| Name | Type | Required / default | Description |
| --- | --- | --- | --- |
| `defaultValue` | `string` | optional; first enabled tab | Initial selected tab (uncontrolled). |
| `value` | `string` | optional | Selected tab (controlled). The shown selection always equals this. |
| `onValueChange` | `(value: string) => void` | optional | Called when the user selects a different enabled tab. |
| `className` and DOM props | `ComponentPropsWithoutRef<"div">` | optional | Forwarded to the root `div`. |

### TabList props

| Name | Type | Required / default | Description |
| --- | --- | --- | --- |
| `aria-label` | `string` | required | Accessible name of the `tablist`. |
| `className` and DOM props | `ComponentPropsWithoutRef<"div">` | optional | Forwarded to the `tablist` element. |

### Tab props

| Name | Type | Required / default | Description |
| --- | --- | --- | --- |
| `value` | `string` | required | Identifies the tab and links it to its `TabPanel`. |
| `disabled` | `boolean` | optional; `false` | Sets `aria-disabled="true"`. The tab cannot be selected or reached by arrow keys. |
| `className` and DOM props | `ComponentPropsWithoutRef<"button">` | optional | Forwarded to the `button`. |

### TabPanel props

| Name | Type | Required / default | Description |
| --- | --- | --- | --- |
| `value` | `string` | required | The tab value this panel belongs to. Hidden unless selected. |
| `className` and DOM props | `ComponentPropsWithoutRef<"div">` | optional | Forwarded to the panel. |

### Tabs keyboard

| Key | Behavior |
| --- | --- |
| Tab / Shift+Tab | Moves between the selected tab and the selected panel. Only the selected tab is in the tab order. |
| ArrowRight / ArrowLeft | Moves to the next or previous enabled tab, wrapping. Selection follows focus. |
| Home / End | Moves to the first or last enabled tab. |

## Dialog

A modal rendered into `document.body` with a backdrop. It is labelled by `title` and described by `description`.

```tsx
import { useState } from "react";
import { Dialog } from "@acme/ui";

function DeleteButton() {
  const [open, setOpen] = useState(false);
  return (
    <>
      <button type="button" onClick={() => setOpen(true)}>Delete</button>
      <Dialog open={open} onOpenChange={setOpen} title="Delete project" description="This cannot be undone.">
        <button type="button" onClick={() => setOpen(false)}>Cancel</button>
        <button type="button">Delete</button>
      </Dialog>
    </>
  );
}
```

### Dialog props

| Name | Type | Required / default | Description |
| --- | --- | --- | --- |
| `open` | `boolean` | required | Whether the dialog is shown. Nothing renders when `false`. |
| `onOpenChange` | `(open: boolean) => void` | required | Called with `false` on Escape or a backdrop click. The parent decides whether to close. |
| `title` | `ReactNode` | required | Rendered as the `h2` that labels the dialog. |
| `description` | `ReactNode` | optional | Rendered as a `p` that describes the dialog. |
| `className` and DOM props | `ComponentPropsWithoutRef<"div">` | optional | Forwarded to the `role="dialog"` element. |

Focus moves to the first tabbable element on open (or to the dialog itself if there is none, unless a child uses `autoFocus`). On close, focus returns to the element that had it before opening. Nested dialogs are supported: Escape closes only the innermost one.

### Dialog keyboard

| Key | Behavior |
| --- | --- |
| Tab / Shift+Tab | Cycles focus within the dialog. Focus cannot leave it. |
| Escape | Calls `onOpenChange(false)` on the innermost dialog only. |

A backdrop click calls `onOpenChange(false)` only when the mouse goes down and comes up on the backdrop. A drag that starts inside the content does not close the dialog.

## Combobox

A text input with a listbox popup, following the WAI-ARIA combobox pattern. It is generic over the option value type `T`.

```tsx
import { useState } from "react";
import { Combobox, type ComboboxOption } from "@acme/ui";

const fruits: ComboboxOption[] = [
  { value: "apple", label: "Apple" },
  { value: "banana", label: "Banana" },
  { value: "cherry", label: "Cherry", disabled: true },
];

function FruitPicker() {
  const [value, setValue] = useState<string | null>(null);
  return <Combobox label="Fruit" options={fruits} value={value} onChange={setValue} placeholder="Type to search" />;
}
```

### Combobox props

| Name | Type | Required / default | Description |
| --- | --- | --- | --- |
| `label` | `string` | required | Accessible name of the input and the listbox. |
| `options` | `ComboboxOption<T>[]` | required | `{ value: T; label: string; disabled?: boolean }` items. |
| `value` | `T \| null` | required | Selected option value, or `null` for none. The input shows its label. |
| `onChange` | `(value: T \| null) => void` | required | Called with the option value on selection, or `null` when the text is cleared and the input loses focus or Enter is pressed. |
| `placeholder` | `string` | optional | Placeholder of the input. |
| `className` and DOM props | `ComponentPropsWithoutRef<"div">` | optional | Forwarded to the wrapper `div`. |

Typing filters options by case-insensitive substring match. When nothing matches, "No results" is shown.

### Combobox keyboard

| Key | Behavior |
| --- | --- |
| Typing | Opens the popup and filters the options. |
| ArrowDown / ArrowUp | Opens the popup if closed. Moves the active option, skipping disabled options and wrapping. |
| Enter | Selects the active option and closes the popup. With no active option and cleared text, sets `null`. |
| Escape | Closes the popup without selecting, and reverts the text. Does nothing when the popup is closed, so an enclosing dialog can handle it. |
| Blur | Closes the popup and reverts the text. A cleared input sets `null`. |

Clicking an enabled option selects it and keeps focus on the input. Clicking a disabled option does nothing.

import { fireEvent, render, screen, within } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { describe, expect, it, vi } from "vitest";
import { Tab, TabList, TabPanel, Tabs, type TabsProps } from "./Tabs";

function tabs(props: Partial<TabsProps> = {}) {
  return (
    <Tabs {...props}>
      <TabList aria-label="Settings">
        <Tab value="one">One</Tab>
        <Tab value="two">Two</Tab>
        <Tab value="three" disabled>
          Three
        </Tab>
        <Tab value="four">Four</Tab>
      </TabList>
      <TabPanel value="one">Panel one</TabPanel>
      <TabPanel value="two">Panel two</TabPanel>
      <TabPanel value="three">Panel three</TabPanel>
      <TabPanel value="four">Panel four</TabPanel>
    </Tabs>
  );
}

const tabNamed = (name: string) => screen.getByRole("tab", { name });
const selectedTabName = () =>
  screen.getAllByRole("tab").find((tab) => tab.getAttribute("aria-selected") === "true")?.textContent;

describe("Tabs", () => {
  it("T1 renders a labelled tablist whose tabs are buttons wired to their panels", () => {
    render(tabs({ defaultValue: "one" }));
    const list = screen.getByRole("tablist", { name: "Settings" });
    const tabList = within(list).getAllByRole("tab");
    expect(tabList.map((tab) => tab.tagName)).toEqual(["BUTTON", "BUTTON", "BUTTON", "BUTTON"]);
    expect(tabList.map((tab) => tab.getAttribute("type"))).toEqual(["button", "button", "button", "button"]);
    expect(tabList.map((tab) => tab.getAttribute("aria-selected"))).toEqual(["true", "false", "false", "false"]);
    const panel = screen.getByRole("tabpanel");
    expect(panel.textContent).toBe("Panel one");
    expect(tabList[0].getAttribute("aria-controls")).toBe(panel.id);
    expect(panel.getAttribute("aria-labelledby")).toBe(tabList[0].id);
    expect(panel.getAttribute("tabindex")).toBe("0");
  });

  it("T1 every tab's aria-controls points at the panel for its value", () => {
    render(tabs());
    for (const tab of screen.getAllByRole("tab")) {
      const panel = document.getElementById(tab.getAttribute("aria-controls") ?? "");
      expect(panel?.getAttribute("role")).toBe("tabpanel");
      expect(panel?.getAttribute("aria-labelledby")).toBe(tab.id);
    }
  });

  it("T1 unselected panels carry the hidden attribute, so they are not in the a11y tree", () => {
    render(tabs({ defaultValue: "two" }));
    const panels = screen.getAllByRole("tabpanel", { hidden: true });
    expect(panels.map((panel) => panel.hasAttribute("hidden"))).toEqual([true, false, true, true]);
    expect(screen.queryByRole("tabpanel")?.textContent).toBe("Panel two");
  });

  it("T2 uncontrolled: defaultValue selects the initial tab", () => {
    render(tabs({ defaultValue: "two" }));
    expect(tabNamed("Two").getAttribute("aria-selected")).toBe("true");
    expect(selectedTabName()).toBe("Two");
  });

  it("T2 uncontrolled: the first enabled tab is selected when defaultValue is omitted", () => {
    render(
      <Tabs>
        <TabList aria-label="Pick">
          <Tab value="a" disabled>
            A
          </Tab>
          <Tab value="b">B</Tab>
        </TabList>
        <TabPanel value="a">pa</TabPanel>
        <TabPanel value="b">pb</TabPanel>
      </Tabs>,
    );
    expect(tabNamed("B").getAttribute("aria-selected")).toBe("true");
    expect(tabNamed("A").getAttribute("aria-selected")).toBe("false");
  });

  it("T2 uncontrolled: onValueChange fires when a tab is clicked", async () => {
    const user = userEvent.setup();
    const onValueChange = vi.fn();
    render(tabs({ defaultValue: "one", onValueChange }));
    await user.click(tabNamed("Two"));
    expect(onValueChange).toHaveBeenCalledTimes(1);
    expect(onValueChange).toHaveBeenCalledWith("two");
    expect(selectedTabName()).toBe("Two");
  });

  it("T2 controlled: value wins over defaultValue, and a click changes the UI only when the parent updates value", async () => {
    const user = userEvent.setup();
    const onValueChange = vi.fn();
    const { rerender } = render(tabs({ value: "four", defaultValue: "one", onValueChange }));
    expect(selectedTabName()).toBe("Four");
    await user.click(tabNamed("Two"));
    expect(onValueChange).toHaveBeenCalledWith("two");
    expect(selectedTabName()).toBe("Four");
    rerender(tabs({ value: "two", onValueChange }));
    expect(selectedTabName()).toBe("Two");
  });

  it("T3 only the selected tab is in the tab order", () => {
    render(tabs({ defaultValue: "two" }));
    expect(screen.getAllByRole("tab").map((tab) => tab.getAttribute("tabindex"))).toEqual(["-1", "0", "-1", "-1"]);
  });

  it("T3 Tab from the tablist moves focus into the active panel", async () => {
    const user = userEvent.setup();
    render(tabs({ defaultValue: "two" }));
    await user.tab();
    expect(document.activeElement).toBe(tabNamed("Two"));
    await user.tab();
    expect(document.activeElement).toBe(screen.getByRole("tabpanel"));
    expect(screen.getByRole("tabpanel").textContent).toBe("Panel two");
  });

  it("T4 ArrowRight and ArrowLeft move focus and selection to the next and previous enabled tab", async () => {
    const user = userEvent.setup();
    render(tabs({ defaultValue: "one" }));
    await user.click(tabNamed("One"));
    await user.keyboard("{ArrowRight}");
    expect(document.activeElement).toBe(tabNamed("Two"));
    expect(tabNamed("Two").getAttribute("aria-selected")).toBe("true");
    await user.keyboard("{ArrowRight}");
    expect(document.activeElement).toBe(tabNamed("Four"));
    await user.keyboard("{ArrowLeft}");
    expect(document.activeElement).toBe(tabNamed("Two"));
  });

  it("T4 arrows wrap at both ends, and Home and End jump to the first and last enabled tab", async () => {
    const user = userEvent.setup();
    render(tabs({ defaultValue: "four" }));
    await user.click(tabNamed("Four"));
    await user.keyboard("{ArrowRight}");
    expect(document.activeElement).toBe(tabNamed("One"));
    await user.keyboard("{ArrowLeft}");
    expect(document.activeElement).toBe(tabNamed("Four"));
    await user.keyboard("{Home}");
    expect(document.activeElement).toBe(tabNamed("One"));
    await user.keyboard("{End}");
    expect(document.activeElement).toBe(tabNamed("Four"));
  });

  it("T4 selection follows focus: each key move calls onValueChange with the newly focused value", async () => {
    const user = userEvent.setup();
    const onValueChange = vi.fn();
    render(tabs({ defaultValue: "one", onValueChange }));
    await user.click(tabNamed("One"));
    expect(onValueChange).not.toHaveBeenCalled();
    await user.keyboard("{ArrowRight}{ArrowRight}");
    expect(onValueChange.mock.calls).toEqual([["two"], ["four"]]);
    expect(selectedTabName()).toBe("Four");
  });

  it("T4 a disabled tab is marked aria-disabled and cannot be selected by click", async () => {
    const user = userEvent.setup();
    const onValueChange = vi.fn();
    render(tabs({ defaultValue: "one", onValueChange }));
    const three = tabNamed("Three");
    expect(three.getAttribute("aria-disabled")).toBe("true");
    await user.click(three);
    expect(onValueChange).not.toHaveBeenCalled();
    expect(three.getAttribute("aria-selected")).toBe("false");
  });

  it("T5 arrow keys follow DOM order for a tab added after mount", async () => {
    const user = userEvent.setup();
    const { rerender } = render(
      <Tabs defaultValue="one">
        <TabList aria-label="Order">
          <Tab value="one">One</Tab>
          <Tab value="two">Two</Tab>
        </TabList>
      </Tabs>,
    );
    rerender(
      <Tabs defaultValue="one">
        <TabList aria-label="Order">
          <Tab value="one">One</Tab>
          <Tab value="new">New</Tab>
          <Tab value="two">Two</Tab>
        </TabList>
      </Tabs>,
    );
    await user.click(tabNamed("One"));
    await user.keyboard("{ArrowRight}");
    expect(document.activeElement).toBe(tabNamed("New"));
    expect(tabNamed("New").getAttribute("aria-selected")).toBe("true");
  });

  it("T5 keys other than the tab keys do nothing and are not prevented", async () => {
    const user = userEvent.setup();
    const onValueChange = vi.fn();
    render(tabs({ defaultValue: "one", onValueChange }));
    const one = tabNamed("One");
    await user.click(one);
    expect(fireEvent.keyDown(one, { key: "a" })).toBe(true);
    expect(fireEvent.keyDown(one, { key: "ArrowDown" })).toBe(true);
    expect(fireEvent.keyDown(one, { key: "Enter" })).toBe(true);
    expect(onValueChange).not.toHaveBeenCalled();
    expect(document.activeElement).toBe(one);
  });

  it("T5 hostile: with one enabled tab, arrow and Home/End keys keep focus and never call onValueChange", async () => {
    const user = userEvent.setup();
    const onValueChange = vi.fn();
    render(
      <Tabs defaultValue="one" onValueChange={onValueChange}>
        <TabList aria-label="Lonely">
          <Tab value="one">One</Tab>
          <Tab value="two" disabled>
            Two
          </Tab>
          <Tab value="three" disabled>
            Three
          </Tab>
        </TabList>
      </Tabs>,
    );
    await user.click(tabNamed("One"));
    await user.keyboard("{ArrowRight}{ArrowLeft}{End}{Home}");
    expect(document.activeElement).toBe(tabNamed("One"));
    expect(onValueChange).not.toHaveBeenCalled();
  });

  it("T5 hostile: a selected value that is a disabled tab keeps the first enabled tab in the tab order", () => {
    render(tabs({ defaultValue: "three" }));
    expect(tabNamed("Three").getAttribute("aria-selected")).toBe("true");
    expect(screen.getAllByRole("tab").map((tab) => tab.getAttribute("tabindex"))).toEqual(["0", "-1", "-1", "-1"]);
  });

  it("T5 hostile: removing the selected tab after mount moves the tab stop to the first enabled tab", () => {
    const { rerender } = render(tabs({ defaultValue: "two" }));
    rerender(
      <Tabs defaultValue="two">
        <TabList aria-label="Settings">
          <Tab value="one">One</Tab>
          <Tab value="four">Four</Tab>
        </TabList>
      </Tabs>,
    );
    expect(screen.getAllByRole("tab").map((tab) => tab.getAttribute("tabindex"))).toEqual(["0", "-1"]);
  });

  it("T5 hostile: a value with no matching tab does not crash and leaves the first enabled tab reachable", () => {
    render(tabs({ value: "nope" }));
    expect(screen.getAllByRole("tab").map((tab) => tab.getAttribute("aria-selected"))).toEqual([
      "false",
      "false",
      "false",
      "false",
    ]);
    expect(screen.getAllByRole("tab").map((tab) => tab.getAttribute("tabindex"))).toEqual(["0", "-1", "-1", "-1"]);
  });

  it("G3 two instances on one page have no duplicate ids", () => {
    render(
      <>
        {tabs({ defaultValue: "one" })}
        {tabs({ defaultValue: "two" })}
      </>,
    );
    const ids = Array.from(document.querySelectorAll("[id]"), (element) => element.id);
    expect(ids.length).toBeGreaterThan(0);
    expect(new Set(ids).size).toBe(ids.length);
  });

  it("G2 passes className and native props through to the root element", () => {
    const { container } = render(
      <Tabs className="tabs-root" data-testid="root">
        <TabList aria-label="Only">
          <Tab value="a">A</Tab>
        </TabList>
      </Tabs>,
    );
    const root = container.firstElementChild;
    expect(root?.getAttribute("class")).toBe("tabs-root");
    expect(root?.getAttribute("data-testid")).toBe("root");
  });
});

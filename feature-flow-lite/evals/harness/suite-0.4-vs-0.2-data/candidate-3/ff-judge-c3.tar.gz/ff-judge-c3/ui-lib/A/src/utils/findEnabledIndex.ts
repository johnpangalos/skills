/**
 * Returns the index of the first enabled entry found by walking from `start` in
 * the `step` direction, wrapping at both ends. `start` itself is checked first.
 * Returns -1 when no entry is enabled.
 */
export function findEnabledIndex(enabled: boolean[], start: number, step: 1 | -1): number {
  const count = enabled.length;
  for (let offset = 0; offset < count; offset++) {
    const index = (((start + offset * step) % count) + count) % count;
    if (enabled[index]) return index;
  }
  return -1;
}

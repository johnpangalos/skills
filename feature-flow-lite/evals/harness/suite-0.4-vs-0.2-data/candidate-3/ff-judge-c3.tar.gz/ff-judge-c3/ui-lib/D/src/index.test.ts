import * as library from "./index";
import type {
  ComboboxOption,
  ComboboxProps,
  DialogProps,
  TabListProps,
  TabPanelProps,
  TabProps,
  TabsProps,
} from "./index";

describe("package exports (G1)", () => {
  it("G1: exports every component from src/index.ts", () => {
    expect(Object.keys(library).sort()).toEqual(["Combobox", "Dialog", "Tab", "TabList", "TabPanel", "Tabs"]);
  });

  it("G1: exports the props types (the import above fails typecheck if one is missing)", () => {
    const exported: unknown[] = [
      {} as TabsProps,
      {} as TabListProps,
      {} as TabProps,
      {} as TabPanelProps,
      {} as DialogProps,
      {} as ComboboxProps,
      { value: "a", label: "A" } as ComboboxOption,
    ];
    expect(exported).toHaveLength(7);
  });
});

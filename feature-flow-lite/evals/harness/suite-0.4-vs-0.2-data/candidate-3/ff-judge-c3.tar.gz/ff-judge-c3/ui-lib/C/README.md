# @acme/ui

Accessible React 19 components: `Tabs`, `Dialog` and `Combobox`. No CSS is shipped and no runtime dependencies beyond `react` and `react-dom`. Every component forwards extra props (`className`, `style`, `data-*`) to its root element so you can style it.

## Running

```sh
pnpm install
pnpm test        # vitest run (jsdom)
pnpm typecheck   # tsc --noEmit
```

Import everything from `src/index.ts`:

```tsx
import { Tabs, TabList, Tab, TabPanel, Dialog, Combobox } from "./src";
```

Ids are generated with React `useId`, so several instances can share a page.

---

## Tabs

Follows the WAI-ARIA tabs pattern.

```tsx
<Tabs defaultValue="profile">
  <TabList aria-label="Account">
    <Tab value="profile">Profile</Tab>
    <Tab value="billing" disabled>Billing</Tab>
    <Tab value="security">Security</Tab>
  </TabList>
  <TabPanel value="profile">Profile form</TabPanel>
  <TabPanel value="billing">Billing details</TabPanel>
  <TabPanel value="security">Security settings</TabPanel>
</Tabs>
```

### Tabs

Root `div`. Provides selection state to its children.

| Prop | Type | Required | Default | Meaning |
| --- | --- | --- | --- | --- |
| `defaultValue` | `string` | no | first enabled tab | Initially selected tab (uncontrolled). |
| `value` | `string` | no | — | Selected tab (controlled). When set, the parent must update it in `onValueChange` for selection to change. |
| `onValueChange` | `(value: string) => void` | no | — | Called with the tab value when the user selects a different enabled tab. |

Plus all `HTMLAttributes<HTMLDivElement>`, forwarded to the root `div`.

If the requested value is missing or disabled, the first enabled tab is selected instead. "First" means first in DOM order, including tabs added, removed or reordered after mount. A user's explicit selection is kept while that tab stays enabled. Only the selected tab is in the tab order.

### TabList

Root element with `role="tablist"`.

| Prop | Type | Required | Default | Meaning |
| --- | --- | --- | --- | --- |
| `aria-label` | `string` | one of these two | — | Accessible name of the tab list. |
| `aria-labelledby` | `string` | one of these two | — | Id of the element that names the tab list. |

Plus all `HTMLAttributes<HTMLDivElement>`, forwarded to the `div`.

### Tab

A `<button type="button" role="tab">`.

| Prop | Type | Required | Default | Meaning |
| --- | --- | --- | --- | --- |
| `value` | `string` | yes | — | Identifies the tab and links it to the `TabPanel` with the same value. |
| `disabled` | `boolean` | no | `false` | Sets `aria-disabled="true"`. A disabled tab cannot be selected by click or keyboard. |

Plus all `ButtonHTMLAttributes<HTMLButtonElement>` except `value` and `disabled`, forwarded to the button. `aria-controls` is set only when a `TabPanel` with the same value is rendered.

### TabPanel

A `div` with `role="tabpanel"`, `tabIndex={0}`, and `aria-labelledby` pointing at its tab.

| Prop | Type | Required | Default | Meaning |
| --- | --- | --- | --- | --- |
| `value` | `string` | yes | — | The tab this panel belongs to. The panel is rendered with `hidden` unless its value is selected. |

Plus all `HTMLAttributes<HTMLDivElement>`, forwarded to the `div`.

### Tabs keyboard

Focus must be on a tab for these keys to apply.

| Key | Action |
| --- | --- |
| `ArrowRight` | Move focus to the next enabled tab, wrapping from the last to the first. Selects it. |
| `ArrowLeft` | Move focus to the previous enabled tab, wrapping from the first to the last. Selects it. |
| `Home` | Move focus to the first enabled tab. Selects it. |
| `End` | Move focus to the last enabled tab. Selects it. |
| `Tab` | Moves from the selected tab to its panel (the panel follows the tab list in the DOM). |

Selection follows focus. Arrow and Home/End keys are prevented from scrolling; other keys are not. In controlled mode, focus moves and `onValueChange` is called even if the parent keeps the old `value`.

---

## Dialog

A modal rendered into `document.body` through a portal. It renders a backdrop `div` (with `data-dialog-backdrop`) and the `role="dialog"` element.

```tsx
const [open, setOpen] = useState(false);

<button onClick={() => setOpen(true)}>Delete file</button>
<Dialog open={open} onOpenChange={setOpen} title="Delete file" description="This cannot be undone.">
  <button onClick={() => setOpen(false)}>Cancel</button>
  <button>Delete</button>
</Dialog>
```

| Prop | Type | Required | Default | Meaning |
| --- | --- | --- | --- | --- |
| `open` | `boolean` | yes | — | Whether the dialog is rendered. Nothing is rendered when `false`. |
| `onOpenChange` | `(open: boolean) => void` | yes | — | Called with `false` on Escape or a click on the backdrop. The dialog never closes itself; the parent must set `open` to `false`. |
| `title` | `ReactNode` | yes | — | Rendered in an `h2`; names the dialog via `aria-labelledby`. |
| `description` | `ReactNode` | no | — | Rendered in a `p`; describes the dialog via `aria-describedby`. The attribute is omitted when there is no description. |
| `children` | `ReactNode` | no | — | Dialog content. |

Plus all `HTMLAttributes<HTMLDivElement>` except `title`, forwarded to the `role="dialog"` element (which always has `aria-modal="true"`).

### Dialog behaviour

- **Opening:** focus moves to the first tabbable element in the dialog. If there is none, the dialog itself is focused. A child with `autoFocus` keeps its focus.
- **Trap:** Tab and Shift+Tab cycle within the dialog, wrapping at both ends. Disabled, `hidden`, `inert`, `tabIndex={-1}` and `aria-disabled="true"` elements are skipped, and the list is read at each key press. Focus that leaves the dialog is pulled back in.
- **Closing:** Escape and a click on the backdrop call `onOpenChange(false)`. A press that starts inside the content and ends on the backdrop does not close.
- **Nested dialogs:** only the innermost open dialog responds to Escape, Tab and focus changes.
- **Focus return:** when the dialog closes or unmounts, focus returns to the element that had focus before it opened (following shadow roots), if that element is still in the document.
- Tabbable detection looks only at the light DOM. It does not enter shadow roots.
- The dialog does not lock body scroll and does not change attributes on `document`, `html` or `body`.

### Dialog keyboard

| Key | Action |
| --- | --- |
| `Escape` | Calls `onOpenChange(false)` on the innermost open dialog. |
| `Tab` / `Shift+Tab` | Move to the next or previous tabbable element, wrapping at both ends. |

---

## Combobox

A text input with `role="combobox"` and a listbox popup, following the WAI-ARIA combobox pattern. Controlled: the parent owns `value`.

```tsx
const [fruit, setFruit] = useState<string | null>(null);

<Combobox
  label="Fruit"
  placeholder="Type to search"
  options={[
    { value: "apple", label: "Apple" },
    { value: "banana", label: "Banana", disabled: true },
  ]}
  value={fruit}
  onChange={setFruit}
/>
```

Generic: `Combobox<T extends string | number>`. Option values are used as React keys, so they must be unique.

| Prop | Type | Required | Default | Meaning |
| --- | --- | --- | --- | --- |
| `label` | `string` | yes | — | Visible label for the input. Also names the listbox. |
| `options` | `ComboboxOption<T>[]` | yes | — | Choices. Each is `{ value: T; label: string; disabled?: boolean }`. |
| `value` | `T \| null` | yes | — | Selected option value, or `null` for no selection. |
| `onChange` | `(value: T \| null) => void` | yes | — | Called with the option value on selection, or with `null` when the input is cleared while a value is selected. |
| `placeholder` | `string` | no | — | Passed to the input. |

Plus all `HTMLAttributes<HTMLDivElement>` except `onChange`, forwarded to the root `div`.

### Combobox behaviour

- Typing opens the list and filters options by a case-insensitive substring match on `label`. The text is matched literally.
- The listbox is rendered only while open. `aria-controls` and `aria-activedescendant` are set only when they point at a rendered element.
- The list shows "No results" (a `role="status"` element) when nothing matches.
- The input text follows `value` and `options` whenever the user is not typing, so a changed label or options that arrive later are shown. If the parent does not accept a selection, the text reverts to the label of the current `value` (empty for `null`).
- The active option is tracked by value. If typing filters it out, the first enabled visible option becomes active, or none if there is none.
- Clicking an enabled option selects it. Clicking a disabled option does nothing. The input keeps focus.
- Blurring the input closes the list and restores the selected option's label. Blurring does not select anything.
- Clearing the text while a value is selected calls `onChange(null)` once. If the parent accepts `null`, the input stays empty and the list stays open. If the parent keeps its value, the text reverts to that value's label.
- Clicking the input does not open the list. Typing or ArrowDown/ArrowUp does.

### Combobox keyboard

| Key | Action |
| --- | --- |
| Typing | Opens the list and filters it. |
| `ArrowDown` | Opens the list if closed and activates the selected option, or the first enabled option. If open, activates the next enabled option, wrapping. |
| `ArrowUp` | Opens the list if closed and activates the last enabled option. If open, activates the previous enabled option, wrapping. |
| `Enter` | If an option is active: selects it, sets the input text to its label, closes the list and prevents form submission. With no active option it does nothing. |
| `Escape` | If the list is open: closes it without selecting and restores the selected label. Stops propagation so an enclosing dialog stays open. If closed: does nothing. |

Arrow keys are prevented from moving the caret. Disabled options are skipped by the arrow keys.

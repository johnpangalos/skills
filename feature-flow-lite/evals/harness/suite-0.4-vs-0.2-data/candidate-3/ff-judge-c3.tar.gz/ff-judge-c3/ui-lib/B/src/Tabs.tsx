import {
  createContext,
  useContext,
  useId,
  useLayoutEffect,
  useRef,
  useState,
  type ComponentPropsWithoutRef,
  type Dispatch,
  type KeyboardEvent,
  type RefObject,
  type SetStateAction,
} from "react";

export type TabsProps = Omit<ComponentPropsWithoutRef<"div">, "defaultValue"> & {
  defaultValue?: string;
  value?: string;
  onValueChange?: (value: string) => void;
};

export type TabListProps = ComponentPropsWithoutRef<"div"> & {
  "aria-label": string;
};

export type TabProps = Omit<ComponentPropsWithoutRef<"button">, "value" | "disabled"> & {
  value: string;
  disabled?: boolean;
};

export type TabPanelProps = ComponentPropsWithoutRef<"div"> & {
  value: string;
};

type TabEntry = {
  value: string;
  disabled: boolean;
  ref: RefObject<HTMLButtonElement | null>;
};

type TabsContextValue = {
  baseId: string;
  explicitValue: string | undefined;
  selectedValue: string | null;
  stopValue: string | null;
  select: (value: string) => void;
  setEntries: Dispatch<SetStateAction<TabEntry[]>>;
};

const TabsContext = createContext<TabsContextValue | null>(null);

const NAVIGATION_KEYS = ["ArrowRight", "ArrowLeft", "Home", "End"];

function useTabsContext(component: string): TabsContextValue {
  const context = useContext(TabsContext);
  if (!context) {
    throw new Error(`${component} must be used inside <Tabs>`);
  }
  return context;
}

// Ids are the useId base plus the encoded value, so a tab and its panel always
// agree and values containing spaces still make valid id references.
function tabDomId(baseId: string, value: string): string {
  return `${baseId}-tab-${encodeURIComponent(value)}`;
}

function panelDomId(baseId: string, value: string): string {
  return `${baseId}-panel-${encodeURIComponent(value)}`;
}

function sortByDomOrder(entries: TabEntry[]): TabEntry[] {
  return entries
    .filter((entry) => entry.ref.current !== null)
    .sort((a, b) => {
      const order = a.ref.current!.compareDocumentPosition(b.ref.current!);
      return order & Node.DOCUMENT_POSITION_FOLLOWING ? -1 : 1;
    });
}

function tabsInList(list: HTMLElement): HTMLElement[] {
  return Array.from(list.querySelectorAll<HTMLElement>('[role="tab"]')).filter(
    (tab) => tab.closest('[role="tablist"]') === list,
  );
}

function isEnabled(tab: HTMLElement): boolean {
  return tab.getAttribute("aria-disabled") !== "true";
}

// Steps from `from` in DOM order, wrapping, and returns the first enabled tab.
// Bounded by the tab count, so an all-disabled list returns undefined.
function nextEnabledTab(tabs: HTMLElement[], from: HTMLElement, delta: 1 | -1): HTMLElement | undefined {
  const count = tabs.length;
  const start = tabs.indexOf(from);
  for (let step = 1; step <= count; step++) {
    const candidate = tabs[(((start + delta * step) % count) + count) % count];
    if (isEnabled(candidate)) {
      return candidate;
    }
  }
  return undefined;
}

function tabForKey(key: string, tabs: HTMLElement[], current: HTMLElement): HTMLElement | undefined {
  switch (key) {
    case "ArrowRight":
      return nextEnabledTab(tabs, current, 1);
    case "ArrowLeft":
      return nextEnabledTab(tabs, current, -1);
    case "Home":
      return tabs.filter(isEnabled)[0];
    case "End":
      return tabs.filter(isEnabled).at(-1);
    default:
      return undefined;
  }
}

export function Tabs({ defaultValue, value, onValueChange, children, ...rest }: TabsProps) {
  const baseId = useId();
  const [internalValue, setInternalValue] = useState<string | undefined>(defaultValue);
  const [entries, setEntries] = useState<TabEntry[]>([]);
  const isControlled = value !== undefined;
  const currentValue = isControlled ? value : internalValue;

  // With no value given, the first enabled tab is the selection. A value that
  // matches no enabled tab selects nothing, and the first enabled tab is the stop.
  const tabs = sortByDomOrder(entries);
  const firstEnabled = tabs.find((tab) => !tab.disabled)?.value ?? null;
  const selectedValue = currentValue ?? firstEnabled;
  const selectedIsEnabled = tabs.some((tab) => !tab.disabled && tab.value === selectedValue);
  const stopValue = selectedIsEnabled ? selectedValue : firstEnabled;

  const select = (next: string) => {
    if (next === selectedValue) {
      return;
    }
    if (!isControlled) {
      setInternalValue(next);
    }
    onValueChange?.(next);
  };

  return (
    <TabsContext.Provider
      value={{ baseId, explicitValue: currentValue, selectedValue, stopValue, select, setEntries }}
    >
      <div {...rest}>{children}</div>
    </TabsContext.Provider>
  );
}

export function TabList({ onKeyDown, children, ...rest }: TabListProps) {
  const { select } = useTabsContext("TabList");

  const handleKeyDown = (event: KeyboardEvent<HTMLDivElement>) => {
    onKeyDown?.(event);
    const tabs = tabsInList(event.currentTarget);
    const current = event.target as HTMLElement;
    // A nested Tabs inside this list bubbles its keys here; only this list's own tabs count.
    if (!tabs.includes(current) || !NAVIGATION_KEYS.includes(event.key)) {
      return;
    }
    event.preventDefault();
    const target = tabForKey(event.key, tabs, current);
    if (target) {
      target.focus();
      select(target.dataset.value!);
    }
  };

  return (
    <div {...rest} role="tablist" aria-orientation="horizontal" onKeyDown={handleKeyDown}>
      {children}
    </div>
  );
}

export function Tab({ value, disabled = false, onClick, ...rest }: TabProps) {
  const { baseId, explicitValue, selectedValue, stopValue, select, setEntries } = useTabsContext("Tab");
  const ref = useRef<HTMLButtonElement>(null);
  // Before the registry has filled in (stopValue is null), every enabled tab is a stop, so a
  // Dialog that focuses in its layout effect lands on the first one. A caller-selected tab is the
  // only stop when the caller names one. Once registered, the registry's stop is the only stop.
  const isStop =
    value === stopValue ||
    (stopValue === null && !disabled && (explicitValue === undefined || value === explicitValue));

  // The ref object is stable per tab, so it identifies this entry.
  useLayoutEffect(() => {
    setEntries((previous) => [...previous, { value, disabled, ref }]);
    return () => setEntries((previous) => previous.filter((entry) => entry.ref !== ref));
  }, [value, disabled, setEntries]);

  return (
    <button
      {...rest}
      ref={ref}
      type="button"
      role="tab"
      id={tabDomId(baseId, value)}
      data-value={value}
      aria-selected={value === selectedValue}
      aria-controls={panelDomId(baseId, value)}
      aria-disabled={disabled ? true : undefined}
      tabIndex={isStop ? 0 : -1}
      onClick={(event) => {
        onClick?.(event);
        if (!disabled) {
          select(value);
        }
      }}
    />
  );
}

export function TabPanel({ value, ...rest }: TabPanelProps) {
  const { baseId, selectedValue } = useTabsContext("TabPanel");
  return (
    <div
      {...rest}
      role="tabpanel"
      id={panelDomId(baseId, value)}
      aria-labelledby={tabDomId(baseId, value)}
      tabIndex={0}
      hidden={value !== selectedValue}
    />
  );
}

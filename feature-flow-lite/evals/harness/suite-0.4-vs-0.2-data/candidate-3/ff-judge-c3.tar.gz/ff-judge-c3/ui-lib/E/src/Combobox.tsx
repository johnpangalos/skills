import { useId, useRef, useState, type KeyboardEvent } from "react";

export type ComboboxOption = { value: string; label: string; disabled?: boolean };

export type ComboboxProps = {
  label: string;
  options: ComboboxOption[];
  value: string | null;
  onChange: (value: string | null) => void;
  placeholder?: string;
  className?: string;
};

type Entry = { option: ComboboxOption; index: number };

// Substring match on the trimmed, case-folded text; empty text matches everything.
function filterOptions(options: ComboboxOption[], text: string): Entry[] {
  const query = text.trim().toLowerCase();
  return options
    .map((option, index) => ({ option, index }))
    .filter(({ option }) => option.label.toLowerCase().includes(query));
}

// The enabled option after the active value, wrapping at the end; none active means the first.
function nextActive(enabled: ComboboxOption[], active: string | null): string | null {
  if (enabled.length === 0) return null;
  const index = enabled.findIndex((option) => option.value === active);
  return enabled[(index + 1) % enabled.length].value;
}

// The enabled option before the active value, wrapping at the start; none active means the last.
function previousActive(enabled: ComboboxOption[], active: string | null): string | null {
  if (enabled.length === 0) return null;
  const index = enabled.findIndex((option) => option.value === active);
  return enabled[index <= 0 ? enabled.length - 1 : index - 1].value;
}

export function Combobox({ label, options, value, onChange, placeholder, className }: ComboboxProps) {
  const baseId = useId();
  const labelId = `${baseId}-label`;
  const inputId = `${baseId}-input`;
  const listboxId = `${baseId}-listbox`;
  const optionId = (index: number) => `${baseId}-option-${index}`;
  const inputRef = useRef<HTMLInputElement>(null);

  // `editing` is the text the user typed; null means show the selected option's label.
  const [editing, setEditing] = useState<string | null>(null);
  const [open, setOpen] = useState(false);
  // Tracked by value, so the active option survives list changes while it is still shown.
  const [activeValue, setActiveValue] = useState<string | null>(null);

  const selected = options.find((option) => option.value === value);
  const text = editing ?? selected?.label ?? "";
  const visible = filterOptions(options, editing ?? "");
  const listOpen = open && visible.length > 0;
  const enabled = visible.map((entry) => entry.option).filter((option) => !option.disabled);
  const active = listOpen ? visible.find((entry) => entry.option.value === activeValue && !entry.option.disabled) : undefined;

  const close = () => {
    setOpen(false);
    setEditing(null);
    setActiveValue(null);
  };

  // A new `value` from the parent makes the typed text and the open list stale, so drop them during render.
  const [shownValue, setShownValue] = useState(value);
  if (value !== shownValue) {
    setShownValue(value);
    close();
  }

  // Emptying the text and then leaving it (Enter or blur) clears the selection. Escape never does.
  const isEmptied = editing !== null && editing.trim() === "";
  const clearIfEmptied = () => {
    if (isEmptied && value !== null) onChange(null);
  };

  const commit = (option: ComboboxOption) => {
    if (option.disabled) return;
    onChange(option.value);
    close();
    inputRef.current?.focus();
  };

  const onTextChange = (next: string) => {
    setEditing(next);
    setOpen(true);
    const stillShown = filterOptions(options, next).some((entry) => entry.option.value === activeValue);
    if (!stillShown) setActiveValue(null);
  };

  const onKeyDown = (event: KeyboardEvent<HTMLInputElement>) => {
    switch (event.key) {
      case "ArrowDown":
      case "ArrowUp":
        event.preventDefault();
        if (!listOpen) {
          setOpen(true);
          return;
        }
        setActiveValue(
          event.key === "ArrowDown" ? nextActive(enabled, activeValue) : previousActive(enabled, activeValue),
        );
        return;
      case "Enter":
        if (active) {
          event.preventDefault();
          commit(active.option);
          return;
        }
        // With the list open or the text being edited, Enter belongs to the combobox, not an enclosing form.
        if (listOpen || editing !== null) event.preventDefault();
        if (isEmptied) {
          clearIfEmptied();
          close();
        }
        return;
      case "Escape":
        // Closing the list is this key's job; keep an enclosing dialog open.
        if (open) event.stopPropagation();
        close();
        return;
    }
  };

  return (
    <div className={className}>
      <label id={labelId} htmlFor={inputId}>
        {label}
      </label>
      <input
        ref={inputRef}
        id={inputId}
        type="text"
        role="combobox"
        autoComplete="off"
        aria-autocomplete="list"
        aria-expanded={listOpen}
        aria-controls={listOpen ? listboxId : undefined}
        aria-activedescendant={active ? optionId(active.index) : undefined}
        placeholder={placeholder}
        value={text}
        onChange={(event) => onTextChange(event.target.value)}
        onKeyDown={onKeyDown}
        onBlur={() => {
          clearIfEmptied();
          close();
        }}
      />
      {listOpen ? (
        // Keep focus in the input when an option is pressed.
        <div role="listbox" id={listboxId} aria-labelledby={labelId} onMouseDown={(event) => event.preventDefault()}>
          {visible.map(({ option, index }) => (
            <div
              key={index}
              id={optionId(index)}
              role="option"
              aria-selected={option.value === value}
              aria-disabled={option.disabled || undefined}
              data-active={active?.index === index || undefined}
              onClick={() => commit(option)}
            >
              {option.label}
            </div>
          ))}
        </div>
      ) : null}
      {open && visible.length === 0 ? <div role="status">No results</div> : null}
    </div>
  );
}

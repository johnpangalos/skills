import {
  useId,
  useInsertionEffect,
  useLayoutEffect,
  useRef,
  type ComponentPropsWithoutRef,
  type KeyboardEvent,
  type MouseEvent,
  type ReactNode,
} from "react";
import { createPortal } from "react-dom";

export type DialogProps = Omit<ComponentPropsWithoutRef<"div">, "title"> & {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  title: ReactNode;
  description?: ReactNode;
};

const TABBABLE_SELECTOR =
  "a[href], area[href], button, input, select, textarea, iframe, summary, [tabindex], [contenteditable]";

function tabbablesIn(root: HTMLElement): HTMLElement[] {
  return Array.from(root.querySelectorAll<HTMLElement>(TABBABLE_SELECTOR)).filter(
    (element) => !element.matches(":disabled") && element.tabIndex >= 0 && !element.closest("[hidden], [inert]"),
  );
}

function focusFirstInside(dialog: HTMLElement) {
  if (dialog.contains(document.activeElement)) {
    return;
  }
  const [first] = tabbablesIn(dialog);
  (first ?? dialog).focus();
}

// Tab takes the next tabbable after the focus in DOM order, Shift+Tab the previous one, wrapping at the ends.
// This works from any element inside the dialog, including ones that are not tabbable themselves.
function trapTab(event: KeyboardEvent<HTMLElement>, dialog: HTMLElement) {
  const items = tabbablesIn(dialog);
  event.preventDefault();
  if (items.length === 0) {
    dialog.focus();
    return;
  }
  const active = document.activeElement ?? dialog;
  const before = items.filter((item) => active.compareDocumentPosition(item) & Node.DOCUMENT_POSITION_PRECEDING);
  const after = items.filter((item) => active.compareDocumentPosition(item) & Node.DOCUMENT_POSITION_FOLLOWING);
  const target = event.shiftKey ? (before.at(-1) ?? items.at(-1)) : (after[0] ?? items[0]);
  (target ?? dialog).focus();
}

// Open dialogs, outermost first. Only the top-most one traps focus.
const openDialogs: HTMLElement[] = [];

// Tab while focus is outside the dialog (its element was removed, say) starts again at the dialog's edge.
function pullTabIntoDialog(event: globalThis.KeyboardEvent, dialog: HTMLElement) {
  const items = tabbablesIn(dialog);
  const target = event.shiftKey ? items.at(-1) : items[0];
  event.preventDefault();
  (target ?? dialog).focus();
}

export function Dialog({ open, onOpenChange, title, description, onKeyDown, children, ...rest }: DialogProps) {
  const id = useId();
  const titleId = `${id}-title`;
  const descriptionId = `${id}-description`;
  const dialogRef = useRef<HTMLDivElement>(null);
  const openerRef = useRef<Element | null>(null);
  const pressedOnBackdropRef = useRef(false);
  // The document listener is attached once per open, so it reads the latest callback from here.
  const onOpenChangeRef = useRef(onOpenChange);

  // Insertion effects run before autoFocus children take focus during commit,
  // so this records the element that had focus before the dialog opened.
  useInsertionEffect(() => {
    if (open) {
      openerRef.current = document.activeElement;
    }
  }, [open]);

  useLayoutEffect(() => {
    onOpenChangeRef.current = onOpenChange;
  });

  useLayoutEffect(() => {
    if (!open) {
      return;
    }
    const dialog = dialogRef.current!;
    // Keys pressed inside the dialog are handled by its own onKeyDown. This handles focus that has
    // left it, such as when the focused element was removed and focus fell to body.
    const handleDocumentKeyDown = (event: globalThis.KeyboardEvent) => {
      if (openDialogs.at(-1) !== dialog || dialog.contains(document.activeElement)) {
        return;
      }
      if (event.key === "Tab") {
        pullTabIntoDialog(event, dialog);
      } else if (event.key === "Escape") {
        onOpenChangeRef.current(false);
      }
    };
    openDialogs.push(dialog);
    document.addEventListener("keydown", handleDocumentKeyDown);
    focusFirstInside(dialog);
    return () => {
      document.removeEventListener("keydown", handleDocumentKeyDown);
      openDialogs.splice(openDialogs.indexOf(dialog), 1);
      const opener = openerRef.current;
      if (opener instanceof HTMLElement && opener.isConnected && opener !== document.body) {
        opener.focus();
      } else if (openDialogs.length > 0) {
        // The opener is gone or is body, so focus goes back to the dialog that is still open.
        focusFirstInside(openDialogs.at(-1)!);
      }
    };
  }, [open]);

  if (!open) {
    return null;
  }

  // Escape and Tab stop here so a nested dialog's keys never reach its parent.
  const handleKeyDown = (event: KeyboardEvent<HTMLDivElement>) => {
    onKeyDown?.(event);
    if (event.key === "Escape") {
      event.stopPropagation();
      onOpenChange(false);
    } else if (event.key === "Tab") {
      event.stopPropagation();
      trapTab(event, event.currentTarget);
    }
  };

  // A backdrop close needs the press and the release both on this backdrop. The click event
  // lands on their common ancestor, so the release is checked on mouseup instead.
  const handleBackdropMouseDown = (event: MouseEvent<HTMLDivElement>) => {
    pressedOnBackdropRef.current = event.target === event.currentTarget;
    if (pressedOnBackdropRef.current) {
      event.preventDefault();
    }
  };

  const handleBackdropMouseUp = (event: MouseEvent<HTMLDivElement>) => {
    const closeRequested = pressedOnBackdropRef.current && event.target === event.currentTarget;
    pressedOnBackdropRef.current = false;
    if (closeRequested) {
      onOpenChange(false);
    }
  };

  return createPortal(
    <div data-backdrop="" onMouseDown={handleBackdropMouseDown} onMouseUp={handleBackdropMouseUp}>
      <div
        {...rest}
        ref={dialogRef}
        role="dialog"
        aria-modal="true"
        aria-labelledby={titleId}
        aria-describedby={description ? descriptionId : undefined}
        tabIndex={-1}
        onKeyDown={handleKeyDown}
      >
        <h2 id={titleId}>{title}</h2>
        {description ? <p id={descriptionId}>{description}</p> : null}
        {children}
      </div>
    </div>,
    document.body,
  );
}

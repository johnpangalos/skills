import {
  createContext,
  useContext,
  useId,
  useLayoutEffect,
  useReducer,
  useRef,
  useState,
  type ComponentPropsWithoutRef,
  type HTMLAttributes,
  type KeyboardEvent,
  type MouseEvent,
  type RefObject,
} from "react";

export type TabsProps = Omit<HTMLAttributes<HTMLDivElement>, "defaultValue"> & {
  defaultValue?: string;
  value?: string;
  onValueChange?: (value: string) => void;
};

export type TabListProps = HTMLAttributes<HTMLDivElement> & { "aria-label": string };

export type TabProps = Omit<ComponentPropsWithoutRef<"button">, "value" | "disabled"> & {
  value: string;
  disabled?: boolean;
};

export type TabPanelProps = HTMLAttributes<HTMLDivElement> & { value: string };

type TabsContextValue = {
  baseId: string;
  selected: string | null;
  // The one tab reachable with Tab: the selected tab if enabled, else the first enabled tab.
  tabStop: string | null;
  select: (value: string) => void;
  // Asks Tabs to re-render, so its layout effect re-reads the DOM after a tab mounts, unmounts or is disabled.
  notify: () => void;
  listRef: RefObject<HTMLDivElement | null>;
};

const TabsContext = createContext<TabsContextValue | null>(null);

function useTabsContext(): TabsContextValue {
  const context = useContext(TabsContext);
  if (!context) throw new Error("Tabs components must be rendered inside <Tabs>.");
  return context;
}

// Values are encoded so any string yields a valid, unique id.
const tabId = (baseId: string, value: string) => `${baseId}-tab-${encodeURIComponent(value)}`;
const panelId = (baseId: string, value: string) => `${baseId}-panel-${encodeURIComponent(value)}`;

// Enabled tabs in DOM order, so tabs added or removed after mount are handled.
function getEnabledTabs(list: HTMLElement | null): HTMLElement[] {
  if (!list) return [];
  return Array.from(list.querySelectorAll<HTMLElement>('[role="tab"]:not([aria-disabled="true"])'));
}

// The tab a navigation key moves focus to, or undefined for keys Tabs doesn't handle.
function pickTab(tabs: HTMLElement[], current: HTMLElement, key: string): HTMLElement | undefined {
  if (tabs.length === 0) return undefined;
  const index = tabs.indexOf(current);
  const at = (i: number) => tabs[(i + tabs.length) % tabs.length];
  switch (key) {
    case "ArrowRight":
      return at(index + 1);
    case "ArrowLeft":
      return at(index - 1);
    case "Home":
      return tabs[0];
    case "End":
      return tabs[tabs.length - 1];
    default:
      return undefined;
  }
}

export function Tabs({ defaultValue, value, onValueChange, className, children, ...rest }: TabsProps) {
  const baseId = useId();
  const listRef = useRef<HTMLDivElement>(null);
  const [internal, setInternal] = useState<string | null>(defaultValue ?? null);
  const [tabStop, setTabStop] = useState<string | null>(null);
  // A stable dispatch: each call re-renders Tabs once.
  const [, notify] = useReducer((count: number) => count + 1, 0);
  const controlled = value !== undefined;
  const selected = controlled ? value : internal;

  // Runs after every render. If the selected value names no enabled tab, the first enabled tab takes the
  // tab stop; uncontrolled selection moves there too, without calling onValueChange. Stops once stable.
  useLayoutEffect(() => {
    const values = getEnabledTabs(listRef.current).map((tab) => tab.dataset.value ?? "");
    const fallback = values[0] ?? null;
    const valid = selected !== null && values.includes(selected);
    if (!controlled && !valid && selected !== fallback) setInternal(fallback);
    const stop = valid ? selected : fallback;
    if (stop !== tabStop) setTabStop(stop);
  });

  const select = (next: string) => {
    if (next === selected) return;
    if (!controlled) setInternal(next);
    onValueChange?.(next);
  };

  return (
    <TabsContext.Provider value={{ baseId, selected, tabStop, select, notify, listRef }}>
      <div {...rest} className={className}>
        {children}
      </div>
    </TabsContext.Provider>
  );
}

export function TabList({ className, children, ...rest }: TabListProps) {
  const { listRef } = useTabsContext();
  return (
    <div {...rest} ref={listRef} role="tablist" className={className}>
      {children}
    </div>
  );
}

export function Tab({ value, disabled = false, className, onClick, onKeyDown, children, ...rest }: TabProps) {
  const { baseId, selected, tabStop, select, notify, listRef } = useTabsContext();
  const isSelected = selected === value;
  // Before Tabs has read the DOM, the selected enabled tab is the tab stop, so the first render is already reachable.
  const isTabStop = tabStop === null ? isSelected && !disabled : tabStop === value;

  useLayoutEffect(() => {
    notify();
    return notify;
  }, [disabled, notify]);

  // The consumer's handler runs first; if it calls preventDefault, the built-in handling is skipped.
  const handleClick = (event: MouseEvent<HTMLButtonElement>) => {
    onClick?.(event);
    if (!event.defaultPrevented && !disabled) select(value);
  };

  const handleKeyDown = (event: KeyboardEvent<HTMLButtonElement>) => {
    onKeyDown?.(event);
    if (event.defaultPrevented) return;
    const target = pickTab(getEnabledTabs(listRef.current), event.currentTarget, event.key);
    if (!target) return;
    event.preventDefault();
    target.focus();
    select(target.dataset.value ?? "");
  };

  return (
    <button
      {...rest}
      type="button"
      role="tab"
      id={tabId(baseId, value)}
      aria-selected={isSelected}
      aria-controls={panelId(baseId, value)}
      aria-disabled={disabled || undefined}
      tabIndex={isTabStop ? 0 : -1}
      data-value={value}
      className={className}
      onClick={handleClick}
      onKeyDown={handleKeyDown}
    >
      {children}
    </button>
  );
}

export function TabPanel({ value, className, children, ...rest }: TabPanelProps) {
  const { baseId, selected } = useTabsContext();
  return (
    <div
      {...rest}
      role="tabpanel"
      id={panelId(baseId, value)}
      aria-labelledby={tabId(baseId, value)}
      tabIndex={0}
      hidden={selected !== value}
      className={className}
    >
      {children}
    </div>
  );
}

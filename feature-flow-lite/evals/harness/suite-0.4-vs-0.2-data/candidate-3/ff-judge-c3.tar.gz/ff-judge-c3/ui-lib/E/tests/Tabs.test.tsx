import { StrictMode, useState } from "react";
import { render, screen, fireEvent } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { describe, expect, it, vi } from "vitest";
import * as library from "../src/index";
import { Tab, TabList, TabPanel, Tabs } from "../src/index";
import type { TabListProps, TabPanelProps, TabProps, TabsProps } from "../src/index";

// No @types/node in this project; declare only the Node API the README check uses.
declare const process: {
  cwd(): string;
  getBuiltinModule(id: "node:fs"): { readFileSync(path: string, encoding: "utf8"): string };
};

type ExampleProps = Omit<TabsProps, "children"> & { labels?: string[]; disabled?: string[] };

function Example({ labels = ["one", "two", "three"], disabled = [], ...props }: ExampleProps) {
  return (
    <Tabs {...props}>
      <TabList aria-label="Sections">
        {labels.map((label) => (
          <Tab key={label} value={label} disabled={disabled.includes(label)}>
            {label}
          </Tab>
        ))}
      </TabList>
      {labels.map((label) => (
        <TabPanel key={label} value={label}>
          <button type="button">{`${label} action`}</button>
        </TabPanel>
      ))}
    </Tabs>
  );
}

const tab = (name: string) => screen.getByRole("tab", { name });

describe("exports (G1)", () => {
  it("exports the components and their prop types from src/index", () => {
    expect(Object.keys(library).sort()).toEqual(["Combobox", "Dialog", "Tab", "TabList", "TabPanel", "Tabs"]);
    const types: [TabsProps?, TabListProps?, TabProps?, TabPanelProps?] = [];
    expect(types).toEqual([]);
  });
});

describe("README (G5)", () => {
  const readme = process.getBuiltinModule("node:fs").readFileSync(`${process.cwd()}/README.md`, "utf8");

  it("has a section per component with a usage example, props table and keyboard table", () => {
    for (const heading of ["## Tabs", "## Dialog", "## Combobox"]) {
      const section = readme.split(heading)[1]?.split(/\n## /)[0] ?? "";
      expect(section, heading).toContain("```tsx");
      expect(section, heading).toContain("| Prop |");
      expect(section, heading).toContain("| Key |");
    }
  });
});

describe("Tabs", () => {
  describe("structure (T1)", () => {
    it("renders role=tablist with the given aria-label", () => {
      render(<Example />);
      expect(screen.getByRole("tablist", { name: "Sections" })).toBeInTheDocument();
    });

    it("renders each Tab as a type=button role=tab with aria-selected and aria-controls", () => {
      render(<Example defaultValue="two" />);
      const two = tab("two");
      expect(two.tagName).toBe("BUTTON");
      expect(two).toHaveAttribute("type", "button");
      expect(two).toHaveAttribute("aria-selected", "true");
      expect(tab("one")).toHaveAttribute("aria-selected", "false");
      expect(two).toHaveAttribute("aria-controls", screen.getByRole("tabpanel", { name: "two" }).id);
    });

    it("renders the TabPanel with aria-labelledby, tabIndex 0, and shows only the selected panel", () => {
      render(<Example defaultValue="two" />);
      const panel = screen.getByRole("tabpanel");
      expect(panel).toHaveAttribute("aria-labelledby", tab("two").id);
      expect(panel).toHaveAttribute("tabindex", "0");
      expect(screen.getAllByRole("tabpanel")).toHaveLength(1);
    });

    it("keeps unselected panels out of the Tab order", async () => {
      const user = userEvent.setup();
      render(
        <>
          <Example defaultValue="two" />
          <button type="button">after</button>
        </>,
      );
      tab("two").focus();
      await user.tab();
      expect(screen.getByRole("tabpanel")).toHaveFocus();
      await user.tab();
      expect(screen.getByRole("button", { name: "two action" })).toHaveFocus();
      await user.tab();
      expect(screen.getByRole("button", { name: "after" })).toHaveFocus();
    });
  });

  describe("selection (T2)", () => {
    it("selects the first enabled tab when there is no defaultValue", () => {
      render(<Example />);
      expect(tab("one")).toHaveAttribute("aria-selected", "true");
    });

    it("selects defaultValue initially", () => {
      render(<Example defaultValue="three" />);
      expect(tab("three")).toHaveAttribute("aria-selected", "true");
    });

    it("selects a tab on click and calls onValueChange with its value", async () => {
      const user = userEvent.setup();
      const onValueChange = vi.fn();
      render(<Example onValueChange={onValueChange} />);
      await user.click(tab("two"));
      expect(tab("two")).toHaveAttribute("aria-selected", "true");
      expect(onValueChange).toHaveBeenCalledTimes(1);
      expect(onValueChange).toHaveBeenCalledWith("two");
    });
  });

  describe("controlled (T3)", () => {
    it("does not change selection on click, but reports it", async () => {
      const user = userEvent.setup();
      const onValueChange = vi.fn();
      render(<Example value="one" onValueChange={onValueChange} />);
      await user.click(tab("two"));
      expect(onValueChange).toHaveBeenCalledWith("two");
      expect(tab("one")).toHaveAttribute("aria-selected", "true");
      expect(tab("two")).toHaveAttribute("aria-selected", "false");
    });

    it("follows the value prop when the parent updates it", () => {
      const { rerender } = render(<Example value="one" />);
      rerender(<Example value="two" />);
      expect(tab("two")).toHaveAttribute("aria-selected", "true");
      expect(tab("one")).toHaveAttribute("aria-selected", "false");
    });

    it("moves focus on arrow keys without changing selection", async () => {
      const user = userEvent.setup();
      const onValueChange = vi.fn();
      render(<Example value="one" onValueChange={onValueChange} />);
      tab("one").focus();
      await user.keyboard("{ArrowRight}");
      expect(tab("two")).toHaveFocus();
      expect(onValueChange).toHaveBeenCalledWith("two");
      expect(tab("one")).toHaveAttribute("aria-selected", "true");
    });
  });

  describe("roving tabindex (T4)", () => {
    it("gives only the selected tab tabIndex 0", () => {
      render(<Example defaultValue="two" />);
      expect(tab("two")).toHaveAttribute("tabindex", "0");
      expect(tab("one")).toHaveAttribute("tabindex", "-1");
      expect(tab("three")).toHaveAttribute("tabindex", "-1");
    });

    it("lands Tab on the selected tab, and the next Tab on the selected panel", async () => {
      const user = userEvent.setup();
      render(<Example defaultValue="two" />);
      await user.tab();
      expect(tab("two")).toHaveFocus();
      await user.tab();
      expect(screen.getByRole("tabpanel")).toHaveFocus();
    });
  });

  describe("keyboard (T5)", () => {
    it("ArrowRight/ArrowLeft move focus and select the focused tab, wrapping at the ends", async () => {
      const user = userEvent.setup();
      const onValueChange = vi.fn();
      render(<Example onValueChange={onValueChange} />);
      tab("one").focus();
      await user.keyboard("{ArrowLeft}");
      expect(tab("three")).toHaveFocus();
      expect(tab("three")).toHaveAttribute("aria-selected", "true");
      await user.keyboard("{ArrowRight}");
      expect(tab("one")).toHaveFocus();
      await user.keyboard("{ArrowRight}");
      expect(tab("two")).toHaveFocus();
      expect(tab("two")).toHaveAttribute("aria-selected", "true");
      expect(onValueChange).toHaveBeenLastCalledWith("two");
    });

    it("Home and End move to the first and last tab", async () => {
      const user = userEvent.setup();
      render(<Example defaultValue="two" />);
      tab("two").focus();
      await user.keyboard("{End}");
      expect(tab("three")).toHaveFocus();
      await user.keyboard("{Home}");
      expect(tab("one")).toHaveFocus();
      expect(tab("one")).toHaveAttribute("aria-selected", "true");
    });

    it("ignores other keys and calls preventDefault only for handled keys", async () => {
      const user = userEvent.setup();
      const onValueChange = vi.fn();
      render(<Example onValueChange={onValueChange} />);
      tab("one").focus();
      await user.keyboard("a");
      expect(tab("one")).toHaveFocus();
      expect(onValueChange).not.toHaveBeenCalled();
      expect(fireEvent.keyDown(tab("one"), { key: "a" })).toBe(true);
      expect(fireEvent.keyDown(tab("one"), { key: "ArrowRight" })).toBe(false);
    });
  });

  describe("disabled tabs and edge cases (T6)", () => {
    it("marks disabled tabs with aria-disabled and ignores clicks on them", async () => {
      const user = userEvent.setup();
      const onValueChange = vi.fn();
      render(<Example disabled={["two"]} onValueChange={onValueChange} />);
      expect(tab("two")).toHaveAttribute("aria-disabled", "true");
      await user.click(tab("two"));
      expect(tab("two")).toHaveAttribute("aria-selected", "false");
      expect(onValueChange).not.toHaveBeenCalled();
    });

    it("arrow keys skip disabled tabs", async () => {
      const user = userEvent.setup();
      render(<Example disabled={["two"]} />);
      tab("one").focus();
      await user.keyboard("{ArrowRight}");
      expect(tab("three")).toHaveFocus();
    });

    it("arrows stay on the only enabled tab", async () => {
      const user = userEvent.setup();
      const onValueChange = vi.fn();
      render(<Example disabled={["one", "three"]} onValueChange={onValueChange} />);
      tab("two").focus();
      await user.keyboard("{ArrowRight}");
      expect(tab("two")).toHaveFocus();
      await user.keyboard("{ArrowLeft}");
      expect(tab("two")).toHaveFocus();
      expect(onValueChange).not.toHaveBeenCalled();
    });

    it("Home skips a disabled first tab", async () => {
      const user = userEvent.setup();
      render(<Example disabled={["one"]} defaultValue="three" />);
      tab("three").focus();
      await user.keyboard("{Home}");
      expect(tab("two")).toHaveFocus();
    });

    it("End skips a disabled last tab", async () => {
      const user = userEvent.setup();
      render(<Example disabled={["three"]} />);
      tab("one").focus();
      await user.keyboard("{End}");
      expect(tab("two")).toHaveFocus();
    });

    it("falls back to the first enabled tab when defaultValue is disabled", () => {
      render(<Example disabled={["one"]} defaultValue="one" />);
      expect(tab("two")).toHaveAttribute("aria-selected", "true");
    });

    it("falls back to the first enabled tab when defaultValue names no tab", () => {
      render(<Example defaultValue="missing" />);
      expect(tab("one")).toHaveAttribute("aria-selected", "true");
    });

    it("follows DOM order when tabs are added or removed after mount", async () => {
      const user = userEvent.setup();
      const { rerender } = render(<Example />);
      rerender(<Example labels={["zero", "one", "two", "three"]} />);
      tab("one").focus();
      await user.keyboard("{ArrowLeft}");
      expect(tab("zero")).toHaveFocus();
      rerender(<Example labels={["zero", "one", "two"]} />);
      tab("two").focus();
      await user.keyboard("{ArrowRight}");
      expect(tab("zero")).toHaveFocus();
    });

    it("throws a clear error when Tabs, TabList, Tab or TabPanel is used outside Tabs", () => {
      const spy = vi.spyOn(console, "error").mockImplementation(() => {});
      expect(() => render(<Tab value="x">x</Tab>)).toThrow("must be rendered inside <Tabs>");
      expect(() => render(<TabList aria-label="x" />)).toThrow("must be rendered inside <Tabs>");
      expect(() => render(<TabPanel value="x">x</TabPanel>)).toThrow("must be rendered inside <Tabs>");
      spy.mockRestore();
    });
  });

  describe("ids and props (G2, G3)", () => {
    it("gives two instances on one page unique ids that wire to their own elements", () => {
      render(
        <>
          <Example />
          <Example />
        </>,
      );
      const ids = Array.from(document.querySelectorAll("[id]")).map((el) => el.id);
      expect(ids.length).toBeGreaterThan(0);
      expect(new Set(ids).size).toBe(ids.length);
      for (const t of screen.getAllByRole("tab")) {
        const panel = document.getElementById(t.getAttribute("aria-controls") ?? "");
        expect(panel).not.toBeNull();
        expect(panel?.getAttribute("aria-labelledby")).toBe(t.id);
      }
    });

    it("forwards className and native props to the rendered elements", () => {
      const { container } = render(
        <Tabs className="root">
          <TabList aria-label="Sections" className="list">
            <Tab value="a" className="tab-btn" data-x="1">
              a
            </Tab>
          </TabList>
          <TabPanel value="a" className="panel">
            body
          </TabPanel>
        </Tabs>,
      );
      expect(container.firstElementChild).toHaveClass("root");
      expect(screen.getByRole("tablist")).toHaveClass("list");
      expect(screen.getByRole("tab")).toHaveClass("tab-btn");
      expect(screen.getByRole("tab")).toHaveAttribute("data-x", "1");
      expect(screen.getByRole("tabpanel")).toHaveClass("panel");
    });
  });

  describe("consumer handlers (T7)", () => {
    it("calls a consumer onClick as well as selecting the tab", async () => {
      const user = userEvent.setup();
      const onClick = vi.fn();
      render(
        <Tabs>
          <TabList aria-label="Sections">
            <Tab value="a">a</Tab>
            <Tab value="b" onClick={onClick}>
              b
            </Tab>
          </TabList>
          <TabPanel value="a">a body</TabPanel>
          <TabPanel value="b">b body</TabPanel>
        </Tabs>,
      );
      await user.click(tab("b"));
      expect(onClick).toHaveBeenCalledTimes(1);
      expect(tab("b")).toHaveAttribute("aria-selected", "true");
    });

    it("calls a consumer onKeyDown as well as moving focus", async () => {
      const user = userEvent.setup();
      const onKeyDown = vi.fn();
      render(
        <Tabs>
          <TabList aria-label="Sections">
            <Tab value="a" onKeyDown={onKeyDown}>
              a
            </Tab>
            <Tab value="b">b</Tab>
          </TabList>
          <TabPanel value="a">a body</TabPanel>
          <TabPanel value="b">b body</TabPanel>
        </Tabs>,
      );
      tab("a").focus();
      await user.keyboard("{ArrowRight}");
      expect(onKeyDown).toHaveBeenCalledTimes(1);
      expect(onKeyDown.mock.calls[0][0].key).toBe("ArrowRight");
      expect(tab("b")).toHaveFocus();
    });

    it("skips the built-in click when the consumer onClick calls preventDefault", async () => {
      const user = userEvent.setup();
      const onValueChange = vi.fn();
      render(
        <Tabs onValueChange={onValueChange}>
          <TabList aria-label="Sections">
            <Tab value="a">a</Tab>
            <Tab value="b" onClick={(event) => event.preventDefault()}>
              b
            </Tab>
          </TabList>
          <TabPanel value="a">a body</TabPanel>
          <TabPanel value="b">b body</TabPanel>
        </Tabs>,
      );
      await user.click(tab("b"));
      expect(tab("a")).toHaveAttribute("aria-selected", "true");
      expect(onValueChange).not.toHaveBeenCalled();
    });

    it("skips the built-in key handling when the consumer onKeyDown calls preventDefault", async () => {
      const user = userEvent.setup();
      const onValueChange = vi.fn();
      render(
        <Tabs onValueChange={onValueChange}>
          <TabList aria-label="Sections">
            <Tab value="a" onKeyDown={(event) => event.preventDefault()}>
              a
            </Tab>
            <Tab value="b">b</Tab>
          </TabList>
          <TabPanel value="a">a body</TabPanel>
          <TabPanel value="b">b body</TabPanel>
        </Tabs>,
      );
      tab("a").focus();
      await user.keyboard("{ArrowRight}");
      expect(tab("a")).toHaveFocus();
      expect(onValueChange).not.toHaveBeenCalled();
    });
  });

  describe("tab stop fallback (T4, T2)", () => {
    it("gives the first enabled tab the tab stop when a controlled value names no tab", async () => {
      const user = userEvent.setup();
      render(<Example value="missing" />);
      expect(tab("one")).toHaveAttribute("tabindex", "0");
      expect(tab("two")).toHaveAttribute("tabindex", "-1");
      await user.tab();
      expect(tab("one")).toHaveFocus();
    });

    it("gives the first enabled tab the tab stop when a controlled value names a disabled tab", async () => {
      const user = userEvent.setup();
      render(<Example value="one" disabled={["one"]} />);
      expect(tab("two")).toHaveAttribute("tabindex", "0");
      await user.tab();
      expect(tab("two")).toHaveFocus();
    });

    it("selects the first enabled tab when the selected tab is removed, without calling onValueChange", () => {
      const onValueChange = vi.fn();
      const { rerender } = render(<Example defaultValue="two" onValueChange={onValueChange} />);
      rerender(<Example labels={["one", "three"]} onValueChange={onValueChange} />);
      expect(tab("one")).toHaveAttribute("aria-selected", "true");
      expect(tab("one")).toHaveAttribute("tabindex", "0");
      expect(onValueChange).not.toHaveBeenCalled();
    });

    it("selects the first enabled tab when the selected tab becomes disabled, without calling onValueChange", () => {
      const onValueChange = vi.fn();
      const { rerender } = render(<Example defaultValue="two" onValueChange={onValueChange} />);
      rerender(<Example defaultValue="two" disabled={["two"]} onValueChange={onValueChange} />);
      expect(tab("one")).toHaveAttribute("aria-selected", "true");
      expect(tab("one")).toHaveAttribute("tabindex", "0");
      expect(tab("two")).toHaveAttribute("aria-selected", "false");
      expect(onValueChange).not.toHaveBeenCalled();
    });

    it("does not call onValueChange for the fallback on mount", () => {
      const onValueChange = vi.fn();
      render(<Example defaultValue="missing" onValueChange={onValueChange} />);
      expect(tab("one")).toHaveAttribute("aria-selected", "true");
      expect(onValueChange).not.toHaveBeenCalled();
    });

    it("recovers a selection and tab stop when tabs are removed and then added back", () => {
      const { rerender } = render(<Example defaultValue="two" />);
      rerender(<Example labels={[]} />);
      rerender(<Example labels={["solo"]} />);
      expect(tab("solo")).toHaveAttribute("aria-selected", "true");
      expect(tab("solo")).toHaveAttribute("tabindex", "0");
    });
  });

  describe("tab stop when tabs change below Tabs (T4, T6)", () => {
    // Owns the tabs and their disabled state, the way a parent inside the tablist would.
    function Owner() {
      const [items, setItems] = useState(["one", "two", "three"]);
      const [firstDisabled, setFirstDisabled] = useState(false);
      return (
        <>
          <button type="button" onClick={() => setItems((current) => current.slice(1))}>
            Remove first
          </button>
          <button type="button" onClick={() => setFirstDisabled(true)}>
            Disable first
          </button>
          {items.map((label, index) => (
            <Tab key={label} value={label} disabled={firstDisabled && index === 0}>
              {label}
            </Tab>
          ))}
        </>
      );
    }

    function Owned({ onValueChange }: { onValueChange?: (value: string) => void }) {
      return (
        <Tabs onValueChange={onValueChange}>
          <TabList aria-label="Sections">
            <Owner />
          </TabList>
          <TabPanel value="one">one body</TabPanel>
          <TabPanel value="two">two body</TabPanel>
          <TabPanel value="three">three body</TabPanel>
        </Tabs>
      );
    }

    const tabStops = () => screen.getAllByRole("tab").filter((el) => el.getAttribute("tabindex") === "0");

    it("selects the remaining first enabled tab, with tabIndex 0, when the selected tab is removed below Tabs", async () => {
      const user = userEvent.setup();
      const onValueChange = vi.fn();
      render(<Owned onValueChange={onValueChange} />);
      await user.click(screen.getByRole("button", { name: "Remove first" }));
      expect(screen.queryByRole("tab", { name: "one" })).toBeNull();
      expect(tab("two")).toHaveAttribute("aria-selected", "true");
      expect(tabStops().map((el) => el.textContent)).toEqual(["two"]);
      expect(onValueChange).not.toHaveBeenCalled();
    });

    it("does the same under StrictMode, with no extra onValueChange calls", async () => {
      const user = userEvent.setup();
      const onValueChange = vi.fn();
      render(
        <StrictMode>
          <Owned onValueChange={onValueChange} />
        </StrictMode>,
      );
      expect(tab("one")).toHaveAttribute("aria-selected", "true");
      await user.click(screen.getByRole("button", { name: "Remove first" }));
      expect(tab("two")).toHaveAttribute("aria-selected", "true");
      expect(tabStops().map((el) => el.textContent)).toEqual(["two"]);
      expect(onValueChange).not.toHaveBeenCalled();
    });

    it("moves the selection and tab stop when the selected tab becomes disabled below Tabs", async () => {
      const user = userEvent.setup();
      const onValueChange = vi.fn();
      render(<Owned onValueChange={onValueChange} />);
      await user.click(screen.getByRole("button", { name: "Disable first" }));
      expect(tab("one")).toHaveAttribute("aria-disabled", "true");
      expect(tab("two")).toHaveAttribute("aria-selected", "true");
      expect(tabStops().map((el) => el.textContent)).toEqual(["two"]);
      expect(onValueChange).not.toHaveBeenCalled();
    });

    it("keeps arrow keys working after tabs change below Tabs", async () => {
      const user = userEvent.setup();
      render(<Owned />);
      await user.click(screen.getByRole("button", { name: "Remove first" }));
      tab("two").focus();
      await user.keyboard("{ArrowRight}");
      expect(tab("three")).toHaveFocus();
      expect(tab("three")).toHaveAttribute("aria-selected", "true");
    });

    it("has exactly one tab stop after mount, with defaultValue and without", () => {
      const { unmount } = render(<Example defaultValue="two" />);
      expect(tabStops().map((el) => el.textContent)).toEqual(["two"]);
      unmount();
      render(<Example />);
      expect(tabStops().map((el) => el.textContent)).toEqual(["one"]);
    });
  });
});

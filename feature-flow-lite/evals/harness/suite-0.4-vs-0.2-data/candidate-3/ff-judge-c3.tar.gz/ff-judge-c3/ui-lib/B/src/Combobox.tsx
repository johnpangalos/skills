import {
  useId,
  useState,
  type ChangeEvent,
  type ComponentPropsWithoutRef,
  type KeyboardEvent,
} from "react";

export type ComboboxOption<T extends string | number = string> = {
  value: T;
  label: string;
  disabled?: boolean;
};

export type ComboboxProps<T extends string | number = string> = Omit<ComponentPropsWithoutRef<"div">, "onChange"> & {
  label: string;
  options: ComboboxOption<T>[];
  value: T | null;
  onChange: (value: T | null) => void;
  placeholder?: string;
};

// Literal, case-insensitive substring match. No regular expression is built from the query.
function filterOptions<T extends string | number>(options: ComboboxOption<T>[], query: string): ComboboxOption<T>[] {
  const needle = query.toLowerCase();
  return options.filter((option) => option.label.toLowerCase().includes(needle));
}

// Steps through the enabled items in `delta` direction with wrapping. Bounded by the
// item count, so a list with no enabled items returns undefined.
function stepEnabled<T extends string | number>(
  items: ComboboxOption<T>[],
  current: T | null,
  delta: 1 | -1,
): ComboboxOption<T> | undefined {
  const count = items.length;
  const currentIndex = items.findIndex((item) => item.value === current);
  const start = currentIndex === -1 ? (delta === 1 ? -1 : count) : currentIndex;
  for (let step = 1; step <= count; step++) {
    const candidate = items[(((start + delta * step) % count) + count) % count];
    if (!candidate.disabled) {
      return candidate;
    }
  }
  return undefined;
}

export function Combobox<T extends string | number = string>({
  label,
  options,
  value,
  onChange,
  placeholder,
  ...rest
}: ComboboxProps<T>) {
  const baseId = useId();
  const labelId = `${baseId}-label`;
  const inputId = `${baseId}-input`;
  const listboxId = `${baseId}-listbox`;
  const optionId = (index: number) => `${baseId}-option-${index}`;

  const [open, setOpen] = useState(false);
  // null means the input shows the selected option's label; a string is the user's typed text.
  const [text, setText] = useState<string | null>(null);
  const [activeValue, setActiveValue] = useState<T | null>(null);
  const [seenValue, setSeenValue] = useState(value);

  // A value changed from outside replaces whatever text was typed.
  if (seenValue !== value) {
    setSeenValue(value);
    setText(null);
  }

  const selected = options.find((option) => option.value === value);
  const shownText = text ?? selected?.label ?? "";
  const visible = filterOptions(options, text ?? "");
  const activeOption = open ? visible.find((option) => option.value === activeValue && !option.disabled) : undefined;

  const close = () => {
    setOpen(false);
    setText(null);
    setActiveValue(null);
  };

  const commit = (option: ComboboxOption<T>) => {
    onChange(option.value);
    close();
  };

  const clearIfEmptied = () => {
    if (text === "" && value !== null) {
      onChange(null);
    }
  };

  const handleChange = (event: ChangeEvent<HTMLInputElement>) => {
    const next = event.target.value;
    setText(next);
    setOpen(true);
    setActiveValue((current) => (filterOptions(options, next).some((o) => o.value === current) ? current : null));
  };

  const handleKeyDown = (event: KeyboardEvent<HTMLInputElement>) => {
    switch (event.key) {
      case "ArrowDown":
      case "ArrowUp": {
        event.preventDefault();
        const next = stepEnabled(visible, activeOption?.value ?? null, event.key === "ArrowDown" ? 1 : -1);
        setOpen(true);
        setActiveValue(next ? next.value : null);
        return;
      }
      case "Enter":
        if (activeOption) {
          event.preventDefault();
          commit(activeOption);
        } else if (text === "") {
          clearIfEmptied();
          close();
        }
        return;
      case "Escape":
        if (open) {
          event.stopPropagation();
          close();
        }
        return;
    }
  };

  const handleBlur = () => {
    clearIfEmptied();
    close();
  };

  return (
    <div {...rest}>
      <label id={labelId} htmlFor={inputId}>
        {label}
      </label>
      <input
        id={inputId}
        type="text"
        role="combobox"
        autoComplete="off"
        aria-autocomplete="list"
        aria-haspopup="listbox"
        aria-expanded={open}
        aria-controls={listboxId}
        aria-activedescendant={
          activeOption ? optionId(options.indexOf(activeOption)) : undefined
        }
        placeholder={placeholder}
        value={shownText}
        onChange={handleChange}
        onKeyDown={handleKeyDown}
        onBlur={handleBlur}
      />
      <div id={listboxId} role="listbox" aria-labelledby={labelId} hidden={!open}>
        {open &&
          visible.map((option) => {
            const index = options.indexOf(option);
            return (
              <div
                key={optionId(index)}
                id={optionId(index)}
                role="option"
                aria-selected={option.value === value}
                aria-disabled={option.disabled ? true : undefined}
                onMouseDown={(event) => event.preventDefault()}
                onClick={() => {
                  if (!option.disabled) {
                    commit(option);
                  }
                }}
              >
                {option.label}
              </div>
            );
          })}
      </div>
      {open && visible.length === 0 ? <div role="status">No results</div> : null}
    </div>
  );
}

import { useState } from "react";
import { fireEvent, render, screen } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { describe, expect, it, vi } from "vitest";
import { Combobox, type ComboboxOption } from "./Combobox";

const FRUITS: ComboboxOption[] = [
  { value: "apple", label: "Apple" },
  { value: "banana", label: "Banana", disabled: true },
  { value: "grape", label: "grape" },
  { value: "cherry", label: "Cherry" },
];

// Uncontrolled wrapper: keeps value in state and reports every change to onChange.
function Field({
  options = FRUITS,
  initial = null,
  onChange = () => {},
}: {
  options?: ComboboxOption[];
  initial?: string | null;
  onChange?: (value: string | null) => void;
}) {
  const [value, setValue] = useState<string | null>(initial);
  return (
    <>
      <Combobox
        label="Fruit"
        options={options}
        value={value}
        onChange={(next) => {
          onChange(next);
          setValue(next);
        }}
        placeholder="Pick a fruit"
      />
      <button>Outside</button>
    </>
  );
}

const input = () => screen.getByRole("combobox", { name: "Fruit" });
const option = (name: string) => screen.getByRole("option", { name });
const optionNames = () => screen.queryAllByRole("option").map((element) => element.textContent);

describe("Combobox structure (C1)", () => {
  it("labels the input and marks it as a list combobox", () => {
    render(<Field />);
    expect(input().tagName).toBe("INPUT");
    expect(input()).toHaveAttribute("aria-autocomplete", "list");
    expect(input()).toHaveAttribute("aria-expanded", "false");
  });

  it("renders no listbox and no aria-controls while collapsed", () => {
    render(<Field />);
    expect(screen.queryByRole("listbox")).toBeNull();
    expect(input()).not.toHaveAttribute("aria-controls");
  });

  it("renders a labelled listbox with option children when expanded", async () => {
    const user = userEvent.setup();
    render(<Field />);
    await user.type(input(), "a");
    expect(input()).toHaveAttribute("aria-expanded", "true");
    const listbox = screen.getByRole("listbox", { name: "Fruit" });
    expect(input()).toHaveAttribute("aria-controls", listbox.id);
    expect(listbox.tagName).toBe("UL");
    for (const element of screen.getAllByRole("option")) {
      expect(element.tagName).toBe("LI");
      expect(element).toHaveAttribute("id");
    }
    expect(option("Banana")).toHaveAttribute("aria-disabled", "true");
    expect(option("Apple")).not.toHaveAttribute("aria-disabled");
  });
});

describe("Combobox filtering (C2)", () => {
  it("opens on typing and filters by case-insensitive substring", async () => {
    const user = userEvent.setup();
    render(<Field />);
    await user.type(input(), "AP");
    expect(optionNames()).toEqual(["Apple", "grape"]);
  });

  it("shows all options when the input is empty", async () => {
    const user = userEvent.setup();
    render(<Field />);
    await user.type(input(), "ap");
    await user.clear(input());
    expect(optionNames()).toEqual(["Apple", "Banana", "grape", "Cherry"]);
  });

  it("does not call onChange while typing", async () => {
    const user = userEvent.setup();
    const onChange = vi.fn();
    render(<Field onChange={onChange} />);
    await user.type(input(), "ch");
    expect(onChange).not.toHaveBeenCalled();
  });

  it("matches regex metacharacters literally", async () => {
    const user = userEvent.setup();
    const options: ComboboxOption[] = [
      { value: "kiwi", label: "Kiwi (green)" },
      { value: "lime", label: "Lime [sour]" },
      { value: "star", label: "Star*fruit" },
      { value: "pear", label: "Pear.v2" },
    ];
    render(<Field options={options} />);
    await user.type(input(), "(g");
    expect(optionNames()).toEqual(["Kiwi (green)"]);
    await user.clear(input());
    await user.type(input(), "[[s");
    expect(optionNames()).toEqual(["Lime [sour]"]);
    await user.clear(input());
    await user.type(input(), "*");
    expect(optionNames()).toEqual(["Star*fruit"]);
    await user.clear(input());
    await user.type(input(), ".");
    expect(optionNames()).toEqual(["Pear.v2"]);
    await user.clear(input());
    await user.type(input(), "a.p");
    expect(optionNames()).toEqual([]);
    expect(screen.getByRole("status")).toHaveTextContent("No results");
  });

  it("shows No results when there are zero options", async () => {
    const user = userEvent.setup();
    render(<Field options={[]} />);
    await user.type(input(), "a");
    expect(screen.getByRole("status")).toHaveTextContent("No results");
  });
});

describe("Combobox active option (C3)", () => {
  it("ArrowDown when closed opens the list and activates the first enabled option", async () => {
    const user = userEvent.setup();
    render(<Field />);
    await user.click(input());
    await user.keyboard("{ArrowDown}");
    expect(input()).toHaveAttribute("aria-expanded", "true");
    expect(input()).toHaveAttribute("aria-activedescendant", option("Apple").id);
    expect(input()).toHaveFocus();
  });

  it("ArrowDown and ArrowUp move the active option, skipping disabled and wrapping", async () => {
    const user = userEvent.setup();
    render(<Field />);
    await user.click(input());
    await user.keyboard("{ArrowDown}{ArrowDown}");
    expect(input()).toHaveAttribute("aria-activedescendant", option("grape").id);
    await user.keyboard("{ArrowDown}{ArrowDown}");
    expect(input()).toHaveAttribute("aria-activedescendant", option("Apple").id);
    await user.keyboard("{ArrowUp}");
    expect(input()).toHaveAttribute("aria-activedescendant", option("Cherry").id);
  });

  it("prevents default on arrow keys", async () => {
    const user = userEvent.setup();
    render(<Field />);
    await user.click(input());
    expect(fireEvent.keyDown(input(), { key: "ArrowDown" })).toBe(false);
    expect(fireEvent.keyDown(input(), { key: "ArrowUp" })).toBe(false);
  });

  it("has no aria-activedescendant and no infinite loop when every option is disabled", async () => {
    const user = userEvent.setup();
    render(<Field options={[{ value: "a", label: "A", disabled: true }]} />);
    await user.click(input());
    await user.keyboard("{ArrowDown}{ArrowUp}{ArrowDown}");
    expect(input()).not.toHaveAttribute("aria-activedescendant");
  });

  it("resets the active option to the first enabled visible option when typing filters it out", async () => {
    const user = userEvent.setup();
    render(<Field />);
    await user.click(input());
    await user.keyboard("{ArrowDown}{ArrowDown}");
    expect(input()).toHaveAttribute("aria-activedescendant", option("grape").id);
    await user.keyboard("ch");
    expect(input()).toHaveAttribute("aria-activedescendant", option("Cherry").id);
  });

  it("drops aria-activedescendant when no visible option is enabled", async () => {
    const user = userEvent.setup();
    render(<Field />);
    await user.click(input());
    await user.keyboard("{ArrowDown}");
    await user.keyboard("zz");
    expect(input()).not.toHaveAttribute("aria-activedescendant");
    expect(screen.queryByRole("option")).toBeNull();
  });
});

describe("Combobox commit and dismiss (C4 and C5)", () => {
  it("Enter commits the active option, sets its label and closes the list", async () => {
    const user = userEvent.setup();
    const onChange = vi.fn();
    render(<Field onChange={onChange} />);
    await user.click(input());
    await user.keyboard("{ArrowDown}{ArrowDown}{Enter}");
    expect(onChange).toHaveBeenCalledTimes(1);
    expect(onChange).toHaveBeenCalledWith("grape");
    expect(input()).toHaveValue("grape");
    expect(input()).toHaveAttribute("aria-expanded", "false");
    expect(screen.queryByRole("listbox")).toBeNull();
  });

  it("Enter with no active option does nothing", async () => {
    const user = userEvent.setup();
    const onChange = vi.fn();
    render(<Field onChange={onChange} />);
    await user.type(input(), "ap");
    await user.keyboard("{Enter}");
    expect(onChange).not.toHaveBeenCalled();
    expect(input()).toHaveAttribute("aria-expanded", "true");
  });

  it("a click on an enabled option selects it and keeps the input focused", async () => {
    const user = userEvent.setup();
    const onChange = vi.fn();
    render(<Field onChange={onChange} />);
    await user.type(input(), "a");
    await user.click(option("Apple"));
    expect(onChange).toHaveBeenCalledWith("apple");
    expect(input()).toHaveValue("Apple");
    expect(input()).toHaveFocus();
    expect(screen.queryByRole("listbox")).toBeNull();
  });

  it("a click on a disabled option does nothing and keeps the list open", async () => {
    const user = userEvent.setup();
    const onChange = vi.fn();
    render(<Field onChange={onChange} />);
    await user.type(input(), "an");
    await user.click(option("Banana"));
    expect(onChange).not.toHaveBeenCalled();
    expect(screen.getByRole("listbox")).toBeInTheDocument();
  });

  it("Escape closes the list without selecting and reverts to the selected label", async () => {
    const user = userEvent.setup();
    const onChange = vi.fn();
    render(<Field initial="cherry" onChange={onChange} />);
    await user.type(input(), "xyz");
    await user.keyboard("{Escape}");
    expect(screen.queryByRole("listbox")).toBeNull();
    expect(input()).toHaveValue("Cherry");
    expect(onChange).not.toHaveBeenCalled();
  });

  it("Escape with no selection reverts the text to empty", async () => {
    const user = userEvent.setup();
    render(<Field />);
    await user.type(input(), "xyz");
    await user.keyboard("{Escape}");
    expect(input()).toHaveValue("");
  });

  it("Escape when closed does nothing", async () => {
    const user = userEvent.setup();
    const onChange = vi.fn();
    render(<Field initial="apple" onChange={onChange} />);
    await user.keyboard("{Escape}");
    expect(input()).toHaveValue("Apple");
    expect(onChange).not.toHaveBeenCalled();
  });
});

describe("Combobox controlled value (C6)", () => {
  it("shows the selected option's label and follows value changes", () => {
    const Controlled = ({ value }: { value: string | null }) => (
      <Combobox label="Fruit" options={FRUITS} value={value} onChange={() => {}} />
    );
    const { rerender } = render(<Controlled value="apple" />);
    expect(input()).toHaveValue("Apple");
    rerender(<Controlled value="cherry" />);
    expect(input()).toHaveValue("Cherry");
    rerender(<Controlled value={null} />);
    expect(input()).toHaveValue("");
  });

  it("calls onChange(null) once when the text is cleared while a value is selected", async () => {
    const user = userEvent.setup();
    const onChange = vi.fn();
    render(<Field initial="apple" onChange={onChange} />);
    await user.clear(input());
    expect(onChange).toHaveBeenCalledTimes(1);
    expect(onChange).toHaveBeenCalledWith(null);
  });

  it("keeps the input empty and the list open with all options when the parent accepts the clear", async () => {
    const user = userEvent.setup();
    render(<Field initial="apple" />);
    await user.clear(input());
    expect(input()).toHaveValue("");
    expect(input()).toHaveAttribute("aria-expanded", "true");
    expect(optionNames()).toEqual(["Apple", "Banana", "grape", "Cherry"]);
  });

  it("filters normally after an accepted clear without calling onChange again", async () => {
    const user = userEvent.setup();
    const onChange = vi.fn();
    render(<Field initial="apple" onChange={onChange} />);
    await user.clear(input());
    await user.type(input(), "ch");
    expect(optionNames()).toEqual(["Cherry"]);
    expect(onChange).toHaveBeenCalledTimes(1);
  });

  it("reverts the text to the selected label when the parent rejects the clear", async () => {
    const user = userEvent.setup();
    const onChange = vi.fn();
    render(<Combobox label="Fruit" options={FRUITS} value="apple" onChange={onChange} />);
    await user.clear(input());
    expect(onChange).toHaveBeenCalledTimes(1);
    expect(onChange).toHaveBeenCalledWith(null);
    expect(input()).toHaveValue("Apple");
  });

  it("blur closes the list and reverts the text to the selected label without selecting", async () => {
    const user = userEvent.setup();
    const onChange = vi.fn();
    render(<Field initial="apple" onChange={onChange} />);
    await user.type(input(), "xx");
    await user.click(screen.getByRole("button", { name: "Outside" }));
    expect(screen.queryByRole("listbox")).toBeNull();
    expect(input()).toHaveValue("Apple");
    expect(onChange).not.toHaveBeenCalled();
  });

  it("blur with no selection leaves the text empty", async () => {
    const user = userEvent.setup();
    render(<Field />);
    await user.type(input(), "ch");
    await user.click(screen.getByRole("button", { name: "Outside" }));
    expect(input()).toHaveValue("");
  });
});

describe("Combobox no results (C7)", () => {
  it("shows a status message and no options or activedescendant when nothing matches", async () => {
    const user = userEvent.setup();
    render(<Field />);
    await user.type(input(), "zzz");
    expect(screen.getByRole("status")).toHaveTextContent("No results");
    expect(screen.queryAllByRole("option")).toHaveLength(0);
    expect(input()).not.toHaveAttribute("aria-activedescendant");
  });
});

describe("Combobox props and value types (C8)", () => {
  it("passes placeholder to the input", () => {
    render(<Field />);
    expect(input()).toHaveAttribute("placeholder", "Pick a fruit");
  });

  it("supports numeric option values", async () => {
    const user = userEvent.setup();
    const onChange = vi.fn();
    render(
      <Combobox<number>
        label="Count"
        options={[
          { value: 1, label: "One" },
          { value: 2, label: "Two" },
        ]}
        value={null}
        onChange={onChange}
      />,
    );
    await user.type(screen.getByRole("combobox", { name: "Count" }), "t");
    await user.keyboard("{ArrowDown}{Enter}");
    expect(onChange).toHaveBeenCalledWith(2);
  });
});

describe("Combobox changing options (C9 and C10)", () => {
  it("keeps the same option active when an option is prepended while open", async () => {
    const user = userEvent.setup();
    const onChange = vi.fn();
    const { rerender } = render(<Combobox label="Fruit" options={FRUITS} value={null} onChange={onChange} />);
    await user.type(input(), "a");
    await user.keyboard("{ArrowDown}{ArrowDown}");
    expect(input()).toHaveAttribute("aria-activedescendant", option("grape").id);
    const mango = { value: "mango", label: "Mango" };
    rerender(<Combobox label="Fruit" options={[mango, ...FRUITS]} value={null} onChange={onChange} />);
    expect(input()).toHaveAttribute("aria-activedescendant", option("grape").id);
    await user.keyboard("{Enter}");
    expect(onChange).toHaveBeenCalledWith("grape");
  });

  it("drops the active option when it is removed from options", async () => {
    const user = userEvent.setup();
    const onChange = vi.fn();
    const { rerender } = render(<Combobox label="Fruit" options={FRUITS} value={null} onChange={onChange} />);
    await user.type(input(), "a");
    await user.keyboard("{ArrowDown}{ArrowDown}");
    rerender(
      <Combobox label="Fruit" options={FRUITS.filter((item) => item.value !== "grape")} value={null} onChange={onChange} />,
    );
    expect(input()).not.toHaveAttribute("aria-activedescendant");
    await user.keyboard("{Enter}");
    expect(onChange).not.toHaveBeenCalled();
  });

  it("marks the option equal to value with aria-selected and opens on it", async () => {
    const user = userEvent.setup();
    render(<Field initial="cherry" />);
    await user.click(input());
    await user.keyboard("{ArrowDown}");
    expect(option("Cherry")).toHaveAttribute("aria-selected", "true");
    expect(option("Apple")).toHaveAttribute("aria-selected", "false");
    expect(input()).toHaveAttribute("aria-activedescendant", option("Cherry").id);
  });
});

describe("Combobox ids and props", () => {
  it("keeps ids unique and references inside each instance when two are on one page", async () => {
    const user = userEvent.setup();
    render(
      <>
        <Combobox label="First" options={FRUITS} value={null} onChange={() => {}} />
        <Combobox label="Second" options={FRUITS} value={null} onChange={() => {}} />
      </>,
    );
    const first = screen.getByRole("combobox", { name: "First" });
    const second = screen.getByRole("combobox", { name: "Second" });
    await user.click(first);
    await user.keyboard("{ArrowDown}");
    await user.click(second);
    await user.keyboard("{ArrowDown}");
    const ids = Array.from(document.querySelectorAll("[id]"), (element) => element.id);
    expect(new Set(ids).size).toBe(ids.length);
    expect(second).toHaveAttribute("aria-activedescendant", screen.getAllByRole("option")[0].id);
    expect(screen.getByRole("listbox", { name: "Second" })).toHaveAttribute("id", second.getAttribute("aria-controls"));
  });

  it("forwards className, style and data attributes to the root element", () => {
    render(
      <Combobox label="Fruit" options={FRUITS} value={null} onChange={() => {}} className="picker" data-kind="fruit" />,
    );
    expect(input().parentElement).toHaveClass("picker");
    expect(input().parentElement).toHaveAttribute("data-kind", "fruit");
  });
});

describe("Combobox text follows the controlled value (C4, C5 and C6 regressions)", () => {
  it("reverts the text to empty when the parent rejects a keyboard selection", async () => {
    const user = userEvent.setup();
    const onChange = vi.fn();
    render(<Combobox label="Fruit" options={FRUITS} value={null} onChange={onChange} />);
    await user.click(input());
    await user.keyboard("{ArrowDown}{Enter}");
    expect(onChange).toHaveBeenCalledWith("apple");
    expect(input()).toHaveValue("");
    expect(screen.queryByRole("listbox")).toBeNull();
  });

  it("reverts the text to empty when the parent rejects a click selection", async () => {
    const user = userEvent.setup();
    const onChange = vi.fn();
    render(<Combobox label="Fruit" options={FRUITS} value={null} onChange={onChange} />);
    await user.type(input(), "a");
    await user.click(option("Apple"));
    expect(onChange).toHaveBeenCalledWith("apple");
    expect(input()).toHaveValue("");
  });

  it("shows the new label when the selected option's label changes", () => {
    const { rerender } = render(
      <Combobox label="Fruit" options={[{ value: "a", label: "Apple" }]} value="a" onChange={() => {}} />,
    );
    expect(input()).toHaveValue("Apple");
    rerender(<Combobox label="Fruit" options={[{ value: "a", label: "Apricot" }]} value="a" onChange={() => {}} />);
    expect(input()).toHaveValue("Apricot");
  });

  it("keeps the typed text while the list is open when the selected label changes", async () => {
    const user = userEvent.setup();
    const { rerender } = render(
      <Combobox label="Fruit" options={[{ value: "a", label: "Apple" }]} value="a" onChange={() => {}} />,
    );
    // Replaces the selected "Apple" text. Clearing it would be rejected by this parent, which reverts the text to "Apple".
    await user.type(input(), "ap", { initialSelectionStart: 0, initialSelectionEnd: "Apple".length });
    rerender(<Combobox label="Fruit" options={[{ value: "a", label: "Apricot" }]} value="a" onChange={() => {}} />);
    expect(input()).toHaveValue("ap");
  });

  it("shows the label of a value that arrives with async options", () => {
    const { rerender } = render(<Combobox label="Fruit" options={[]} value="a" onChange={() => {}} />);
    expect(input()).toHaveValue("");
    rerender(
      <Combobox label="Fruit" options={[{ value: "a", label: "Apple" }]} value="a" onChange={() => {}} />,
    );
    expect(input()).toHaveValue("Apple");
  });
});

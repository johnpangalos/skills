# @acme/ui

Accessible React components: `Tabs`, `Dialog` and `Combobox`. No CSS is shipped; every component accepts `className` so you can style it yourself.

React 19 is a peer dependency.

## Running

```sh
pnpm install
pnpm test        # Vitest with jsdom and Testing Library
pnpm typecheck   # tsc --noEmit
```

## Tabs

```tsx
import { Tab, TabList, TabPanel, Tabs } from "@acme/ui";

<Tabs defaultValue="account">
  <TabList aria-label="Settings">
    <Tab value="account">Account</Tab>
    <Tab value="billing" disabled>Billing</Tab>
    <Tab value="team">Team</Tab>
  </TabList>
  <TabPanel value="account">Account settings</TabPanel>
  <TabPanel value="team">Team settings</TabPanel>
</Tabs>
```

Uncontrolled by default. Pass `value` and `onValueChange` to control the selection; the selected tab then follows only the `value` prop.

The tab stop (the one tab that `Tab` reaches) is the selected tab when it is enabled, otherwise the first enabled tab, so the tablist stays reachable even when `value` names no tab. In uncontrolled mode, if the selected tab is removed or disabled, the first enabled tab is selected. Neither this fallback nor the initial one calls `onValueChange`.

| Prop | Type | Required / default | Description |
| --- | --- | --- | --- |
| `Tabs.defaultValue` | `string` | optional; first enabled tab | Initial selection (uncontrolled). Falls back to the first enabled tab if it names no enabled tab. |
| `Tabs.value` | `string` | optional | Selected tab (controlled). |
| `Tabs.onValueChange` | `(value: string) => void` | optional | Called when the user selects a tab, with the new value. |
| `TabList.aria-label` | `string` | required | Accessible name of the `tablist`. |
| `Tab.value` | `string` | required | Identifies the tab and matches its `TabPanel`. |
| `Tab.disabled` | `boolean` | optional; `false` | Disables the tab (`aria-disabled="true"`); it cannot be clicked or reached by arrows. |
| `TabPanel.value` | `string` | required | The tab whose panel this is. Unselected panels are `hidden`. |
| `Tab.onClick` / `Tab.onKeyDown` | `function` | optional | Called before the built-in handling. If the handler calls `event.preventDefault()`, the built-in click or key handling is skipped. |
| `className` | `string` | optional | On every component. Other native `div` or `button` props pass through. |

| Key | Action |
| --- | --- |
| `Tab` | Moves focus to the selected tab, then to the selected panel. |
| `ArrowRight` / `ArrowLeft` | Focus and select the next or previous enabled tab, wrapping at the ends. |
| `Home` / `End` | Focus and select the first or last enabled tab. |
| `Enter` / `Space` | Select the focused tab. |

## Dialog

```tsx
import { Dialog } from "@acme/ui";

const [open, setOpen] = useState(false);

<button type="button" onClick={() => setOpen(true)}>Delete</button>
<Dialog
  open={open}
  onOpenChange={setOpen}
  title="Delete project?"
  description="This cannot be undone."
>
  <button type="button" onClick={() => setOpen(false)}>Cancel</button>
  <button type="button">Delete</button>
</Dialog>
```

A modal rendered into `document.body` with a backdrop element (`data-backdrop`). The dialog never closes itself: it only calls `onOpenChange(false)` and the parent decides. Focus moves into the dialog when it opens and returns to the element that had focus before it opened.

| Prop | Type | Required / default | Description |
| --- | --- | --- | --- |
| `open` | `boolean` | required | Whether the dialog is shown. Nothing is rendered when `false`. |
| `onOpenChange` | `(open: boolean) => void` | required | Called with `false` on Escape or a backdrop click. |
| `title` | `ReactNode` | required | Rendered as the heading; labels the dialog. |
| `description` | `ReactNode` | optional | Rendered below the title; describes the dialog. |
| `children` | `ReactNode` | optional | Dialog content. |
| `className` | `string` | optional | Applied to the `role="dialog"` element. |

| Key | Action |
| --- | --- |
| `Escape` | Calls `onOpenChange(false)`. In nested dialogs only the innermost closes. |
| `Tab` / `Shift+Tab` | Moves focus through the dialog, wrapping at the ends. Disabled, hidden, inert and `tabIndex=-1` content is skipped. |
| Backdrop click | Calls `onOpenChange(false)`. Only a press and release that both land on the backdrop close it. A press that starts inside the dialog and ends on the backdrop, or starts on the backdrop and ends inside, does not. |

## Combobox

```tsx
import { Combobox } from "@acme/ui";

const [fruit, setFruit] = useState<string | null>(null);

<Combobox
  label="Fruit"
  placeholder="Type to search"
  options={[
    { value: "apple", label: "Apple" },
    { value: "banana", label: "Banana", disabled: true },
  ]}
  value={fruit}
  onChange={setFruit}
/>
```

A text input with a filtered listbox. Matching is a case-insensitive substring match on the label. The value is controlled: the input shows the label of the option whose `value` matches, and typing or pressing Escape never changes it. The selection changes only through `onChange`. Emptying the text and then pressing Enter or blurring calls `onChange(null)`, which is how a parent clears it; a parent can also set `value` to `null` directly.

| Prop | Type | Required / default | Description |
| --- | --- | --- | --- |
| `label` | `string` | required | Visible label, associated with the input. |
| `options` | `ComboboxOption[]` | required | `{ value: string; label: string; disabled?: boolean }`. |
| `value` | `string \| null` | required | Selected option's value, or `null` for no selection. |
| `onChange` | `(value: string \| null) => void` | required | Called with the value of the option the user commits. |
| `placeholder` | `string` | optional | Placeholder text for the input. |
| `className` | `string` | optional | Applied to the wrapper that contains the label, input and listbox. |

| Key | Action |
| --- | --- |
| Typing | Opens the listbox and filters options by label. |
| `ArrowDown` / `ArrowUp` | Opens the listbox if closed. Otherwise moves the active option among enabled options, wrapping at the ends. |
| `Enter` | Commits the active option and closes the listbox. With no active option it does nothing, except that it is prevented from submitting an enclosing form while the listbox is open or the text is being edited (so it submits only when the listbox is closed and the text is not being edited). If the text was emptied (whitespace only), it calls `onChange(null)` and closes the listbox. |
| `Escape` | Closes the listbox (or the "No results" message) and reverts the text to the selected label. Does not change the value, even if the text was emptied. While the listbox or "No results" is shown, Escape is consumed, so an enclosing Dialog stays open. |
| Blur | Closes the listbox and reverts the text. If the text was emptied, calls `onChange(null)` first. |
| Click on an enabled option | Commits it. Clicking a disabled option does nothing. |

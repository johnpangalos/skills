import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useId,
  useLayoutEffect,
  useRef,
  useState,
  type ButtonHTMLAttributes,
  type HTMLAttributes,
  type KeyboardEvent,
} from "react";
import { idSegment } from "../internal/ids";

export type TabsProps = Omit<HTMLAttributes<HTMLDivElement>, "defaultValue"> & {
  defaultValue?: string;
  value?: string;
  onValueChange?: (value: string) => void;
};

export type TabListProps = HTMLAttributes<HTMLDivElement> &
  ({ "aria-label": string } | { "aria-labelledby": string });

export type TabProps = Omit<ButtonHTMLAttributes<HTMLButtonElement>, "value" | "disabled"> & {
  value: string;
  disabled?: boolean;
};

export type TabPanelProps = HTMLAttributes<HTMLDivElement> & {
  value: string;
};

type TabRecord = { value: string; disabled: boolean; element: HTMLButtonElement };

// The requested tab when it is an enabled tab, otherwise the first enabled tab, so one tab is always tabbable.
// Before any tab has registered, the requested value stands in so the first render already has a selection.
function resolveSelected(tabs: TabRecord[], requested: string | undefined): string | null {
  if (tabs.length === 0) return requested ?? null;
  return (
    tabs.find((tab) => tab.value === requested && !tab.disabled)?.value ??
    tabs.find((tab) => !tab.disabled)?.value ??
    null
  );
}

// Sorts tab records into DOM order. Returns the same array when it is already in order, so state does not change.
function inDomOrder(tabs: TabRecord[]): TabRecord[] {
  const sorted = [...tabs].sort((a, b) =>
    (a.element.compareDocumentPosition(b.element) & Node.DOCUMENT_POSITION_FOLLOWING) !== 0 ? -1 : 1,
  );
  return sorted.every((tab, index) => tab === tabs[index]) ? tabs : sorted;
}

type TabsContextValue = {
  baseId: string;
  selected: string | null;
  tabs: TabRecord[];
  panels: string[];
  select: (value: string) => void;
  registerTab: (record: TabRecord) => () => void;
  registerPanel: (value: string) => () => void;
};

const TabsContext = createContext<TabsContextValue | null>(null);

function useTabsContext(): TabsContextValue {
  const context = useContext(TabsContext);
  if (context === null) {
    throw new Error("Tabs, TabList, Tab and TabPanel must be rendered inside <Tabs>");
  }
  return context;
}

const tabId = (baseId: string, value: string) => `${baseId}-tab-${idSegment(value)}`;
const panelId = (baseId: string, value: string) => `${baseId}-panel-${idSegment(value)}`;

const isEnabledTab = (element: HTMLElement) => element.getAttribute("aria-disabled") !== "true";

// Nearest enabled tab after / before `from`, wrapping and skipping disabled tabs.
function nextEnabledTab(items: HTMLElement[], from: number): HTMLElement | undefined {
  for (let offset = 1; offset <= items.length; offset++) {
    const item = items[(from + offset) % items.length];
    if (isEnabledTab(item)) return item;
  }
  return undefined;
}

function previousEnabledTab(items: HTMLElement[], from: number): HTMLElement | undefined {
  for (let offset = 1; offset <= items.length; offset++) {
    const item = items[(from - offset + items.length) % items.length];
    if (isEnabledTab(item)) return item;
  }
  return undefined;
}

export function Tabs({ defaultValue, value, onValueChange, children, ...rest }: TabsProps) {
  const baseId = useId();
  const [internal, setInternal] = useState<string | undefined>(defaultValue);
  const [tabs, setTabs] = useState<TabRecord[]>([]);
  const [panels, setPanels] = useState<string[]>([]);

  const requested = value ?? internal;
  const selected = resolveSelected(tabs, requested);

  const select = (next: string) => {
    if (value === undefined) setInternal(next);
    onValueChange?.(next);
  };

  const registerTab = useCallback((record: TabRecord) => {
    setTabs((current) => [...current.filter((tab) => tab.value !== record.value), record]);
    return () => setTabs((current) => current.filter((tab) => tab.value !== record.value));
  }, []);

  const registerPanel = useCallback((panelValue: string) => {
    setPanels((current) => [...current.filter((item) => item !== panelValue), panelValue]);
    return () => setPanels((current) => current.filter((item) => item !== panelValue));
  }, []);

  // Runs after every render so tabs that were moved in the DOM are re-sorted before paint.
  useLayoutEffect(() => {
    setTabs(inDomOrder);
  });

  return (
    <TabsContext.Provider value={{ baseId, selected, tabs, panels, select, registerTab, registerPanel }}>
      <div {...rest}>{children}</div>
    </TabsContext.Provider>
  );
}

export function TabList({ children, onKeyDown, ...rest }: TabListProps) {
  const { baseId, selected, tabs, select } = useTabsContext();

  const handleKeyDown = (event: KeyboardEvent<HTMLDivElement>) => {
    onKeyDown?.(event);
    const items = Array.from(event.currentTarget.querySelectorAll<HTMLElement>('[role="tab"]'));
    const index = items.indexOf(event.target as HTMLElement);
    if (index === -1) return;

    let next: HTMLElement | undefined;
    switch (event.key) {
      case "ArrowRight":
        next = nextEnabledTab(items, index);
        break;
      case "ArrowLeft":
        next = previousEnabledTab(items, index);
        break;
      case "Home":
        next = items.find(isEnabledTab);
        break;
      case "End":
        next = [...items].reverse().find(isEnabledTab);
        break;
      default:
        return;
    }
    event.preventDefault();
    if (next === undefined) return;
    const target = next;
    target.focus();
    const nextValue = tabs.find((tab) => tabId(baseId, tab.value) === target.id)?.value;
    if (nextValue !== undefined && nextValue !== selected) select(nextValue);
  };

  return (
    <div {...rest} role="tablist" onKeyDown={handleKeyDown}>
      {children}
    </div>
  );
}

export function Tab({ value, disabled = false, onClick, children, ...rest }: TabProps) {
  const { baseId, selected, panels, select, registerTab } = useTabsContext();
  const ref = useRef<HTMLButtonElement>(null);

  useEffect(() => {
    const element = ref.current;
    if (element === null) return undefined;
    return registerTab({ value, disabled, element });
  }, [registerTab, value, disabled]);

  const isSelected = selected === value && !disabled;
  return (
    <button
      {...rest}
      ref={ref}
      type="button"
      role="tab"
      id={tabId(baseId, value)}
      aria-selected={isSelected}
      aria-disabled={disabled || undefined}
      aria-controls={panels.includes(value) ? panelId(baseId, value) : undefined}
      tabIndex={isSelected ? 0 : -1}
      onClick={(event) => {
        onClick?.(event);
        if (!disabled && !isSelected) select(value);
      }}
    >
      {children}
    </button>
  );
}

export function TabPanel({ value, children, ...rest }: TabPanelProps) {
  const { baseId, selected, tabs, registerPanel } = useTabsContext();

  useEffect(() => registerPanel(value), [registerPanel, value]);

  const hasTab = tabs.some((tab) => tab.value === value);
  return (
    <div
      {...rest}
      role="tabpanel"
      id={panelId(baseId, value)}
      aria-labelledby={hasTab ? tabId(baseId, value) : undefined}
      tabIndex={0}
      hidden={selected !== value}
    >
      {children}
    </div>
  );
}

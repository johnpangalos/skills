import {
  type ComponentPropsWithoutRef,
  type KeyboardEvent as ReactKeyboardEvent,
  createContext,
  useCallback,
  useContext,
  useId,
  useLayoutEffect,
  useRef,
  useState,
} from "react";
import { findEnabledIndex } from "../utils/findEnabledIndex";

export type TabsProps = Omit<ComponentPropsWithoutRef<"div">, "defaultValue"> & {
  defaultValue?: string;
  value?: string;
  onValueChange?: (value: string) => void;
};

export type TabListProps = ComponentPropsWithoutRef<"div"> & {
  "aria-label": string;
};

export type TabProps = Omit<ComponentPropsWithoutRef<"button">, "value"> & {
  value: string;
  disabled?: boolean;
};

export type TabPanelProps = Omit<ComponentPropsWithoutRef<"div">, "value"> & {
  value: string;
};

type TabEntry = {
  value: string;
  disabled: boolean;
  element: HTMLElement;
};

type TabsContextValue = {
  baseId: string;
  selectedValue: string | undefined;
  tabStopValue: string | undefined;
  register: (entry: TabEntry) => () => void;
  select: (value: string) => void;
  handleTabKeyDown: (event: ReactKeyboardEvent<HTMLButtonElement>, tabValue: string) => void;
};

const TabsContext = createContext<TabsContextValue | null>(null);

function useTabsContext(component: string): TabsContextValue {
  const context = useContext(TabsContext);
  if (!context) throw new Error(`${component} must be rendered inside <Tabs>`);
  return context;
}

// encodeURIComponent is injective and yields id-safe characters, so values never collide.
const tabIdFor = (baseId: string, value: string) => `${baseId}-tab-${encodeURIComponent(value)}`;
const panelIdFor = (baseId: string, value: string) => `${baseId}-panel-${encodeURIComponent(value)}`;

// Tabs can be added, removed or moved, so order is read from the DOM when it matters.
function sortByDocumentOrder(entries: TabEntry[]): TabEntry[] {
  return [...entries].sort((a, b) =>
    a.element.compareDocumentPosition(b.element) & Node.DOCUMENT_POSITION_FOLLOWING ? -1 : 1,
  );
}

export function Tabs({ defaultValue, value, onValueChange, ...rest }: TabsProps) {
  const baseId = useId();
  const [internalValue, setInternalValue] = useState(defaultValue);
  const [entries, setEntries] = useState<TabEntry[]>([]);

  const ordered = sortByDocumentOrder(entries);
  const firstEnabled = ordered.find((entry) => !entry.disabled)?.value;
  const selectedValue = value ?? internalValue ?? firstEnabled;
  const selectedEnabled = ordered.some((entry) => entry.value === selectedValue && !entry.disabled);
  const tabStopValue = selectedEnabled ? selectedValue : firstEnabled;

  const register = useCallback((entry: TabEntry) => {
    setEntries((current) => [...current, entry]);
    return () => setEntries((current) => current.filter((item) => item !== entry));
  }, []);

  const select = (next: string) => {
    if (next === selectedValue) return;
    if (value === undefined) setInternalValue(next);
    onValueChange?.(next);
  };

  const handleTabKeyDown = (event: ReactKeyboardEvent<HTMLButtonElement>, tabValue: string) => {
    const tabs = sortByDocumentOrder(entries);
    const current = tabs.findIndex((entry) => entry.value === tabValue);
    if (current < 0) return;
    // findEnabledIndex wraps out-of-range starts itself, so no modulo is needed here.
    const enabled = tabs.map((entry) => !entry.disabled);

    let target: number;
    switch (event.key) {
      case "ArrowRight":
        target = findEnabledIndex(enabled, current + 1, 1);
        break;
      case "ArrowLeft":
        target = findEnabledIndex(enabled, current - 1, -1);
        break;
      case "Home":
        target = findEnabledIndex(enabled, 0, 1);
        break;
      case "End":
        target = findEnabledIndex(enabled, tabs.length - 1, -1);
        break;
      default:
        return;
    }
    event.preventDefault();
    if (target < 0 || target === current) return;
    tabs[target].element.focus();
    select(tabs[target].value);
  };

  return (
    <TabsContext.Provider
      value={{ baseId, selectedValue, tabStopValue, register, select, handleTabKeyDown }}
    >
      <div {...rest} />
    </TabsContext.Provider>
  );
}

export function TabList({ children, ...rest }: TabListProps) {
  return (
    <div {...rest} role="tablist">
      {children}
    </div>
  );
}

export function Tab({ value, disabled = false, onClick, onKeyDown, ...rest }: TabProps) {
  const { baseId, selectedValue, tabStopValue, register, select, handleTabKeyDown } = useTabsContext("Tab");
  const ref = useRef<HTMLButtonElement>(null);

  useLayoutEffect(() => {
    if (ref.current) return register({ value, disabled, element: ref.current });
  }, [register, value, disabled]);

  return (
    <button
      {...rest}
      ref={ref}
      type="button"
      role="tab"
      id={tabIdFor(baseId, value)}
      aria-selected={value === selectedValue}
      aria-controls={panelIdFor(baseId, value)}
      aria-disabled={disabled || undefined}
      disabled={disabled}
      tabIndex={value === tabStopValue ? 0 : -1}
      onClick={(event) => {
        onClick?.(event);
        select(value);
      }}
      onKeyDown={(event) => {
        onKeyDown?.(event);
        handleTabKeyDown(event, value);
      }}
    />
  );
}

export function TabPanel({ value, ...rest }: TabPanelProps) {
  const { baseId, selectedValue } = useTabsContext("TabPanel");
  return (
    <div
      {...rest}
      role="tabpanel"
      id={panelIdFor(baseId, value)}
      aria-labelledby={tabIdFor(baseId, value)}
      tabIndex={0}
      hidden={value !== selectedValue}
    />
  );
}

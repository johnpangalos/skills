import { type ComponentPropsWithoutRef, useEffect, useId, useRef, useState } from "react";
import { createPortal } from "react-dom";
import { isComposing } from "../utils/isComposing";
import { getTabbableElements } from "../utils/tabbable";

export type DialogProps = Omit<ComponentPropsWithoutRef<"div">, "title"> & {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  title: string;
  description?: string;
};

// Open dialogs by layer number. Layers are numbered in render order, so a dialog
// rendered inside another always has a higher number. Only the highest one is the top layer.
const openLayers = new Set<number>();
let layersCreated = 0;

function isTopLayer(layer: number): boolean {
  return [...openLayers].every((open) => open <= layer);
}

function focusFirst(panel: HTMLElement) {
  (getTabbableElements(panel)[0] ?? panel).focus();
}

function cycleFocus(event: KeyboardEvent, panel: HTMLElement) {
  event.preventDefault();
  const tabbable = getTabbableElements(panel);
  if (tabbable.length === 0) {
    panel.focus();
    return;
  }
  const index = tabbable.indexOf(document.activeElement as HTMLElement);
  const last = tabbable.length - 1;
  let next: number;
  if (index === -1) next = event.shiftKey ? last : 0;
  else if (event.shiftKey) next = index === 0 ? last : index - 1;
  else next = index === last ? 0 : index + 1;
  tabbable[next].focus();
}

function handleDialogKeyDown(event: KeyboardEvent, panel: HTMLElement, close: () => void) {
  if (event.key === "Escape" && !event.defaultPrevented) {
    event.preventDefault();
    close();
  } else if (event.key === "Tab") {
    cycleFocus(event, panel);
  }
}

export function Dialog({ open, ...rest }: DialogProps) {
  if (!open) return null;
  return createPortal(<DialogContent {...rest} />, document.body);
}

function DialogContent({ onOpenChange, title, description, children, ...rest }: Omit<DialogProps, "open">) {
  const titleId = useId();
  const descriptionId = useId();
  const [layer] = useState(() => ++layersCreated);
  // Read while rendering: a child's autoFocus moves focus during commit, before effects run.
  const [opener] = useState(() => document.activeElement);
  const panelRef = useRef<HTMLDivElement>(null);
  const onOpenChangeRef = useRef(onOpenChange);
  onOpenChangeRef.current = onOpenChange;
  // A backdrop click needs both the press and the release on the backdrop itself.
  const pressedOnBackdrop = useRef(false);
  const releasedOnBackdrop = useRef(false);

  useEffect(() => {
    const panel = panelRef.current;
    if (!panel) return;
    const onKeyDown = (event: KeyboardEvent) => {
      // Keys that confirm an IME composition belong to the input method, not to the dialog.
      if (isTopLayer(layer) && !isComposing(event)) {
        handleDialogKeyDown(event, panel, () => onOpenChangeRef.current(false));
      }
    };
    const onFocusIn = (event: FocusEvent) => {
      if (isTopLayer(layer) && event.target instanceof Node && !panel.contains(event.target)) focusFirst(panel);
    };
    // Deferred so that tabs which settle their tab stop in a layout-triggered re-render are tabbable first.
    let pending = true;
    queueMicrotask(() => {
      if (pending && isTopLayer(layer) && !panel.contains(document.activeElement)) focusFirst(panel);
    });
    openLayers.add(layer);
    document.addEventListener("keydown", onKeyDown);
    document.addEventListener("focusin", onFocusIn);
    return () => {
      pending = false;
      document.removeEventListener("keydown", onKeyDown);
      document.removeEventListener("focusin", onFocusIn);
      openLayers.delete(layer);
      if (opener instanceof HTMLElement && opener.isConnected) opener.focus();
    };
  }, [layer, opener]);

  return (
    <div
      data-backdrop
      onMouseDown={(event) => {
        pressedOnBackdrop.current = event.target === event.currentTarget;
        releasedOnBackdrop.current = false;
      }}
      onMouseUp={(event) => {
        releasedOnBackdrop.current = event.target === event.currentTarget;
      }}
      onClick={(event) => {
        // Both flags are cleared on every click, so a stale press cannot close the dialog on a later click.
        const closes =
          pressedOnBackdrop.current && releasedOnBackdrop.current && event.target === event.currentTarget;
        pressedOnBackdrop.current = false;
        releasedOnBackdrop.current = false;
        if (closes) onOpenChange(false);
      }}
    >
      <div
        {...rest}
        ref={panelRef}
        role="dialog"
        aria-modal="true"
        aria-labelledby={titleId}
        aria-describedby={description ? descriptionId : undefined}
        tabIndex={-1}
      >
        <h2 id={titleId}>{title}</h2>
        {description ? <p id={descriptionId}>{description}</p> : null}
        {children}
      </div>
    </div>
  );
}

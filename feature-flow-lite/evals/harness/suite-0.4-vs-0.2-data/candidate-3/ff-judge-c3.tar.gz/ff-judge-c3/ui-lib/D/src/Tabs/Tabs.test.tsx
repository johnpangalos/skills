import { act, fireEvent, render, screen, within } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { useState, type KeyboardEvent } from "react";
import { Tab, TabList, TabPanel, Tabs, type TabListProps, type TabsProps } from "./Tabs";

function Basic(props: Omit<TabsProps, "children">) {
  return (
    <Tabs {...props}>
      <TabList aria-label="Sections">
        <Tab value="one">One</Tab>
        <Tab value="two">Two</Tab>
        <Tab value="three" disabled>
          Three
        </Tab>
        <Tab value="four">Four</Tab>
      </TabList>
      <TabPanel value="one">Panel one</TabPanel>
      <TabPanel value="two">Panel two</TabPanel>
      <TabPanel value="three">Panel three</TabPanel>
      <TabPanel value="four">Panel four</TabPanel>
    </Tabs>
  );
}

function getTab(name: string): HTMLElement {
  return screen.getByRole("tab", { name });
}

function focusTab(name: string) {
  act(() => getTab(name).focus());
}

function panelFor(tab: HTMLElement): HTMLElement {
  const panel = document.getElementById(tab.getAttribute("aria-controls") ?? "");
  if (!panel) throw new Error(`no panel for tab ${tab.textContent}`);
  return panel;
}

describe("Tabs structure (T1)", () => {
  it("T1: TabList is a horizontal tablist with the given label", () => {
    render(<Basic defaultValue="one" />);
    const list = screen.getByRole("tablist", { name: "Sections" });
    expect(list).toHaveAttribute("aria-orientation", "horizontal");
  });

  it("T1: Tab is a type=button tab whose aria-controls points at its panel", () => {
    render(<Basic defaultValue="one" />);
    const one = getTab("One");
    expect(one.tagName).toBe("BUTTON");
    expect(one).toHaveAttribute("type", "button");
    expect(one).toHaveAttribute("aria-selected", "true");
    const panel = panelFor(one);
    expect(panel).toHaveAttribute("role", "tabpanel");
    expect(panel).toHaveAttribute("aria-labelledby", one.id);
    expect(panel).toHaveTextContent("Panel one");
  });

  it("T1: TabPanel is focusable and non-selected panels are hidden", () => {
    render(<Basic defaultValue="one" />);
    expect(screen.getByRole("tabpanel")).toHaveTextContent("Panel one");
    expect(panelFor(getTab("One"))).toHaveAttribute("tabindex", "0");
    expect(panelFor(getTab("Two"))).toHaveAttribute("hidden");
    expect(getTab("Two")).toHaveAttribute("aria-selected", "false");
  });
});

describe("Tabs selection (T2)", () => {
  it("T2: defaultValue selects the initial tab", () => {
    render(<Basic defaultValue="two" />);
    expect(getTab("Two")).toHaveAttribute("aria-selected", "true");
  });

  it("T2: the first enabled tab is selected when defaultValue is omitted", () => {
    render(<Basic />);
    expect(getTab("One")).toHaveAttribute("aria-selected", "true");
  });

  it.each(["missing", "three"])("T2: defaultValue %s falls back to the first enabled tab", (defaultValue) => {
    render(<Basic defaultValue={defaultValue} />);
    expect(getTab("One")).toHaveAttribute("aria-selected", "true");
    expect(getTab("Three")).toHaveAttribute("aria-selected", "false");
  });

  it("T2: uncontrolled click selects the tab and reports the new value", async () => {
    const user = userEvent.setup();
    const onValueChange = vi.fn();
    render(<Basic defaultValue="one" onValueChange={onValueChange} />);
    await user.click(getTab("Two"));
    expect(getTab("Two")).toHaveAttribute("aria-selected", "true");
    expect(onValueChange).toHaveBeenCalledTimes(1);
    expect(onValueChange).toHaveBeenCalledWith("two");
  });

  it("T2: re-selecting the selected tab does not report a change", async () => {
    const user = userEvent.setup();
    const onValueChange = vi.fn();
    render(<Basic defaultValue="one" onValueChange={onValueChange} />);
    await user.click(getTab("One"));
    expect(onValueChange).not.toHaveBeenCalled();
  });

  it("T2: controlled value stays put until the parent changes it", async () => {
    const user = userEvent.setup();
    const onValueChange = vi.fn();
    render(<Basic value="two" onValueChange={onValueChange} />);
    await user.click(getTab("Four"));
    expect(onValueChange).toHaveBeenCalledWith("four");
    expect(getTab("Two")).toHaveAttribute("aria-selected", "true");
    expect(getTab("Four")).toHaveAttribute("aria-selected", "false");
  });

  it("T2: a controlled parent that updates value moves the selection", async () => {
    const user = userEvent.setup();
    function Parent() {
      const [value, setValue] = useState("one");
      return <Basic value={value} onValueChange={setValue} />;
    }
    render(<Parent />);
    await user.click(getTab("Two"));
    expect(getTab("Two")).toHaveAttribute("aria-selected", "true");
    expect(panelFor(getTab("Two"))).not.toHaveAttribute("hidden");
  });
});

describe("Tabs roving tabindex (T3)", () => {
  it("T3: only the selected tab is in the tab sequence", () => {
    render(<Basic defaultValue="two" />);
    const tabs = screen.getAllByRole("tab");
    const inSequence = tabs.filter((tab) => tab.tabIndex === 0);
    expect(inSequence).toHaveLength(1);
    expect(inSequence[0]).toBe(getTab("Two"));
    expect(tabs.filter((tab) => tab.tabIndex === -1)).toHaveLength(3);
  });

  it("T3: Tab from before the tablist lands on the selected tab", async () => {
    const user = userEvent.setup();
    render(
      <>
        <button type="button">Before</button>
        <Basic defaultValue="two" />
      </>,
    );
    await user.tab();
    expect(screen.getByRole("button", { name: "Before" })).toHaveFocus();
    await user.tab();
    expect(getTab("Two")).toHaveFocus();
  });

  it("T3: Tab from the selected tab goes to the selected panel", async () => {
    const user = userEvent.setup();
    render(<Basic defaultValue="two" />);
    await user.tab();
    expect(getTab("Two")).toHaveFocus();
    await user.tab();
    expect(screen.getByRole("tabpanel")).toHaveFocus();
  });
});

describe("Tabs keyboard (T4)", () => {
  it("T4: ArrowRight moves focus and selection to the next enabled tab", async () => {
    const user = userEvent.setup();
    const onValueChange = vi.fn();
    render(<Basic defaultValue="one" onValueChange={onValueChange} />);
    await user.tab();
    await user.keyboard("{ArrowRight}");
    expect(getTab("Two")).toHaveFocus();
    expect(getTab("Two")).toHaveAttribute("aria-selected", "true");
    expect(onValueChange).toHaveBeenCalledWith("two");
  });

  it("T4: ArrowRight skips disabled tabs", async () => {
    const user = userEvent.setup();
    render(<Basic defaultValue="one" />);
    await user.tab();
    await user.keyboard("{ArrowRight}{ArrowRight}");
    expect(getTab("Four")).toHaveFocus();
  });

  it("T4: ArrowRight wraps from the last enabled tab to the first", async () => {
    const user = userEvent.setup();
    render(<Basic defaultValue="four" />);
    await user.tab();
    expect(getTab("Four")).toHaveFocus();
    await user.keyboard("{ArrowRight}");
    expect(getTab("One")).toHaveFocus();
  });

  it("T4: ArrowLeft wraps from the first tab to the last enabled tab", async () => {
    const user = userEvent.setup();
    render(<Basic defaultValue="one" />);
    await user.tab();
    await user.keyboard("{ArrowLeft}");
    expect(getTab("Four")).toHaveFocus();
    expect(getTab("Four")).toHaveAttribute("aria-selected", "true");
  });

  it("T4: Home and End go to the first and last enabled tabs", async () => {
    const user = userEvent.setup();
    render(<Basic defaultValue="two" />);
    await user.tab();
    await user.keyboard("{End}");
    expect(getTab("Four")).toHaveFocus();
    await user.keyboard("{Home}");
    expect(getTab("One")).toHaveFocus();
  });

  it("T4: other keys do nothing and handled keys are prevented", async () => {
    const user = userEvent.setup();
    const onValueChange = vi.fn();
    render(<Basic defaultValue="one" onValueChange={onValueChange} />);
    await user.tab();
    await user.keyboard("{ArrowDown}x");
    expect(getTab("One")).toHaveFocus();
    expect(onValueChange).not.toHaveBeenCalled();
    expect(fireEvent.keyDown(getTab("One"), { key: "x" })).toBe(true);
    expect(fireEvent.keyDown(getTab("One"), { key: "ArrowRight" })).toBe(false);
  });
});

describe("Tabs mouse (T5)", () => {
  it("T5: clicking a disabled tab does nothing", async () => {
    const user = userEvent.setup();
    const onValueChange = vi.fn();
    render(<Basic defaultValue="one" onValueChange={onValueChange} />);
    await user.click(getTab("Three"));
    expect(getTab("One")).toHaveAttribute("aria-selected", "true");
    expect(getTab("Three")).toHaveAttribute("aria-selected", "false");
    expect(onValueChange).not.toHaveBeenCalled();
  });

  it("T5: disabled tabs have aria-disabled=true and stay discoverable", () => {
    render(<Basic defaultValue="one" />);
    expect(getTab("Three")).toHaveAttribute("aria-disabled", "true");
    expect(getTab("One")).not.toHaveAttribute("aria-disabled");
  });
});

describe("Tabs hostile inputs (T6)", () => {
  it("T6: with all but one tab disabled, arrows and Home/End keep focus on the enabled tab", async () => {
    const user = userEvent.setup();
    const onValueChange = vi.fn();
    render(
      <Tabs onValueChange={onValueChange}>
        <TabList aria-label="Only">
          <Tab value="a" disabled>
            A
          </Tab>
          <Tab value="b">B</Tab>
          <Tab value="c" disabled>
            C
          </Tab>
        </TabList>
        <TabPanel value="a">a</TabPanel>
        <TabPanel value="b">b</TabPanel>
        <TabPanel value="c">c</TabPanel>
      </Tabs>,
    );
    await user.tab();
    expect(getTab("B")).toHaveFocus();
    await user.keyboard("{ArrowRight}{ArrowLeft}{Home}{End}");
    expect(getTab("B")).toHaveFocus();
    expect(getTab("B")).toHaveAttribute("aria-selected", "true");
    expect(onValueChange).not.toHaveBeenCalled();
  });

  it("T6: when the first tab is disabled and no default is given, the second tab is selected", () => {
    render(
      <Tabs>
        <TabList aria-label="Skip first">
          <Tab value="a" disabled>
            A
          </Tab>
          <Tab value="b">B</Tab>
        </TabList>
        <TabPanel value="a">a</TabPanel>
        <TabPanel value="b">b</TabPanel>
      </Tabs>,
    );
    expect(getTab("B")).toHaveAttribute("aria-selected", "true");
    expect(getTab("B")).toHaveAttribute("tabindex", "0");
  });

  it("T6: a tab inserted between existing tabs is reached in DOM order", async () => {
    const user = userEvent.setup();
    function Insertable({ showMiddle }: { showMiddle: boolean }) {
      return (
        <Tabs defaultValue="one">
          <TabList aria-label="Order">
            <Tab value="one">One</Tab>
            {showMiddle ? <Tab value="middle">Middle</Tab> : null}
            <Tab value="two">Two</Tab>
          </TabList>
          <TabPanel value="one">one</TabPanel>
          <TabPanel value="middle">middle</TabPanel>
          <TabPanel value="two">two</TabPanel>
        </Tabs>
      );
    }
    const { rerender } = render(<Insertable showMiddle={false} />);
    rerender(<Insertable showMiddle />);
    await user.tab();
    await user.keyboard("{ArrowRight}");
    expect(getTab("Middle")).toHaveFocus();
    await user.keyboard("{ArrowRight}");
    expect(getTab("Two")).toHaveFocus();
  });

  it("T6: a controlled value the parent refuses to change keeps aria-selected on the value", async () => {
    const user = userEvent.setup();
    const onValueChange = vi.fn();
    render(<Basic value="one" onValueChange={onValueChange} />);
    await user.tab();
    await user.keyboard("{ArrowRight}");
    expect(onValueChange).toHaveBeenCalledWith("two");
    expect(getTab("One")).toHaveAttribute("aria-selected", "true");
    expect(getTab("Two")).toHaveAttribute("aria-selected", "false");
  });

  it("T6: tab values with spaces and special characters get valid, unique ids", async () => {
    const user = userEvent.setup();
    const values = ["my tab", "a/b?c=d", 'quote"s', "(paren) & more"];
    render(
      <Tabs defaultValue={values[0]}>
        <TabList aria-label="Odd">
          {values.map((value) => (
            <Tab key={value} value={value}>
              {value}
            </Tab>
          ))}
        </TabList>
        {values.map((value) => (
          <TabPanel key={value} value={value}>
            {`panel ${value}`}
          </TabPanel>
        ))}
      </Tabs>,
    );
    const ids = values.map((value) => getTab(value).id);
    expect(new Set(ids).size).toBe(values.length);
    for (const id of ids) expect(id).not.toMatch(/\s/);
    for (const value of values) {
      const tab = getTab(value);
      expect(panelFor(tab)).toHaveTextContent(`panel ${value}`);
      expect(panelFor(tab)).toHaveAttribute("aria-labelledby", tab.id);
    }
    await user.click(getTab("a/b?c=d"));
    expect(getTab("a/b?c=d")).toHaveAttribute("aria-selected", "true");
    expect(panelFor(getTab("a/b?c=d"))).not.toHaveAttribute("hidden");
  });
});

describe("Tabs instances (G3)", () => {
  it("G3: two Tabs on one page have unique ids and independent selection", async () => {
    const user = userEvent.setup();
    render(
      <>
        <Basic defaultValue="one" />
        <Basic defaultValue="one" />
      </>,
    );
    const [first, second] = screen.getAllByRole("tablist");
    await user.click(within(first).getByRole("tab", { name: "Two" }));
    expect(within(first).getByRole("tab", { name: "Two" })).toHaveAttribute("aria-selected", "true");
    expect(within(second).getByRole("tab", { name: "One" })).toHaveAttribute("aria-selected", "true");
    const ids = Array.from(document.querySelectorAll("[id]")).map((element) => element.id);
    expect(new Set(ids).size).toBe(ids.length);
  });
});

function ListWithKeyDown({ onKeyDown }: Pick<TabListProps, "onKeyDown">) {
  return (
    <Tabs defaultValue="one">
      <TabList aria-label="Sections" onKeyDown={onKeyDown}>
        <Tab value="one">One</Tab>
        <Tab value="two">Two</Tab>
      </TabList>
      <TabPanel value="one">Panel one</TabPanel>
      <TabPanel value="two">Panel two</TabPanel>
    </Tabs>
  );
}

describe("Tabs review fixes", () => {
  it("a user onKeyDown on TabList is called, and ArrowRight still moves to the next tab", async () => {
    const user = userEvent.setup();
    const onKeyDown = vi.fn();
    render(<ListWithKeyDown onKeyDown={onKeyDown} />);
    await user.tab();
    await user.keyboard("{ArrowRight}");
    expect(onKeyDown).toHaveBeenCalledTimes(1);
    expect(getTab("Two")).toHaveFocus();
    expect(getTab("Two")).toHaveAttribute("aria-selected", "true");
  });

  it("preventDefault in a user onKeyDown on TabList skips the built-in ArrowRight handling", async () => {
    const user = userEvent.setup();
    const onKeyDown = vi.fn((event: KeyboardEvent<HTMLDivElement>) => {
      if (event.key === "ArrowRight") event.preventDefault();
    });
    render(<ListWithKeyDown onKeyDown={onKeyDown} />);
    await user.tab();
    await user.keyboard("{ArrowRight}");
    expect(onKeyDown).toHaveBeenCalledTimes(1);
    expect(getTab("One")).toHaveFocus();
    expect(getTab("One")).toHaveAttribute("aria-selected", "true");
  });

  it("a controlled value matching no tab gives the first enabled tab the only tabIndex 0", async () => {
    const user = userEvent.setup();
    render(
      <>
        <button type="button">Before</button>
        <Basic value="nope" onValueChange={() => {}} />
      </>,
    );
    const tabs = screen.getAllByRole("tab");
    expect(tabs.filter((tab) => tab.tabIndex === 0)).toEqual([getTab("One")]);
    expect(tabs.filter((tab) => tab.tabIndex === -1)).toHaveLength(3);
    expect(tabs.every((tab) => tab.getAttribute("aria-selected") === "false")).toBe(true);
    await user.tab();
    await user.tab();
    expect(getTab("One")).toHaveFocus();
  });

  it("a controlled value naming a disabled tab falls back to the first enabled tab", () => {
    render(<Basic value="three" onValueChange={() => {}} />);
    const tabs = screen.getAllByRole("tab");
    expect(tabs.filter((tab) => tab.tabIndex === 0)).toEqual([getTab("One")]);
  });

  it("when the parent moves value to a real tab, that tab is the only tab stop", () => {
    const { rerender } = render(<Basic value="nope" onValueChange={() => {}} />);
    rerender(<Basic value="two" onValueChange={() => {}} />);
    const tabs = screen.getAllByRole("tab");
    expect(tabs.filter((tab) => tab.tabIndex === 0)).toEqual([getTab("Two")]);
    expect(getTab("Two")).toHaveAttribute("aria-selected", "true");
  });
});

// The child owns the tab's existence and disabled state, so Tabs and TabList do not re-render on its own.
function Removable() {
  const [shown, setShown] = useState(true);
  return (
    <>
      {shown ? <Tab value="a">A</Tab> : null}
      <button type="button" onClick={() => setShown(false)}>
        Hide A
      </button>
    </>
  );
}

function Toggling() {
  const [disabled, setDisabled] = useState(false);
  return (
    <>
      <Tab value="a" disabled={disabled}>
        A
      </Tab>
      <button type="button" onClick={() => setDisabled(true)}>
        Disable A
      </button>
    </>
  );
}

describe("Tabs review fixes (round 2)", () => {
  afterEach(() => {
    vi.restoreAllMocks();
  });

  it("T3: a child that hides the selected tab leaves exactly one tab stop, on B, and selects B", async () => {
    const user = userEvent.setup();
    const error = vi.spyOn(console, "error");
    render(
      <Tabs defaultValue="a">
        <TabList aria-label="x">
          <Removable />
          <Tab value="b">B</Tab>
        </TabList>
      </Tabs>,
    );
    await user.click(screen.getByRole("button", { name: "Hide A" }));
    const tabs = screen.getAllByRole("tab");
    expect(tabs).toEqual([getTab("B")]);
    expect(tabs.filter((tab) => tab.tabIndex === 0)).toEqual([getTab("B")]);
    expect(getTab("B")).toHaveAttribute("aria-selected", "true");
    expect(error).not.toHaveBeenCalled();
  });

  it("T3: a child that disables the selected tab moves the selection and tab stop to the next enabled tab", async () => {
    const user = userEvent.setup();
    const error = vi.spyOn(console, "error");
    render(
      <Tabs defaultValue="a">
        <TabList aria-label="x">
          <Toggling />
          <Tab value="b">B</Tab>
        </TabList>
      </Tabs>,
    );
    await user.click(screen.getByRole("button", { name: "Disable A" }));
    expect(getTab("A")).toHaveAttribute("aria-disabled", "true");
    expect(getTab("A")).toHaveAttribute("aria-selected", "false");
    expect(getTab("B")).toHaveAttribute("aria-selected", "true");
    expect(screen.getAllByRole("tab").filter((tab) => tab.tabIndex === 0)).toEqual([getTab("B")]);
    expect(error).not.toHaveBeenCalled();
  });

  it("T2: a controlled value naming a disabled tab keeps aria-selected on it, with the tab stop on the first enabled tab", () => {
    render(<Basic value="three" onValueChange={() => {}} />);
    expect(getTab("Three")).toHaveAttribute("aria-selected", "true");
    expect(getTab("Three")).toHaveAttribute("tabindex", "-1");
    expect(getTab("One")).toHaveAttribute("tabindex", "0");
  });
});

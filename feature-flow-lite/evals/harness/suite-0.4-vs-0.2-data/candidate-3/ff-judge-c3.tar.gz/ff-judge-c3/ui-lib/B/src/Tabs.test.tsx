import { useState } from "react";
import { fireEvent, render, screen } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { Tab, TabList, TabPanel, Tabs, type TabsProps } from "./index";

function tabsTree(props: Omit<TabsProps, "children"> = {}, disabled: string[] = []) {
  return (
    <Tabs {...props}>
      <TabList aria-label="Sections">
        <Tab value="one" disabled={disabled.includes("one")}>One</Tab>
        <Tab value="two" disabled={disabled.includes("two")}>Two</Tab>
        <Tab value="three" disabled={disabled.includes("three")}>Three</Tab>
      </TabList>
      <TabPanel value="one">Panel one</TabPanel>
      <TabPanel value="two">Panel two</TabPanel>
      <TabPanel value="three">Panel three</TabPanel>
    </Tabs>
  );
}

function renderTabs(props: Omit<TabsProps, "children"> = {}, disabled: string[] = []) {
  return render(tabsTree(props, disabled));
}

const tab = (name: string) => screen.getByRole("tab", { name });

function DynamicTabs() {
  const [addZero, setAddZero] = useState(false);
  const [keepTwo, setKeepTwo] = useState(true);
  return (
    <>
      <button type="button" onClick={() => setAddZero(true)}>
        Add zero
      </button>
      <button type="button" onClick={() => setKeepTwo(false)}>
        Remove two
      </button>
      <Tabs defaultValue="one">
        <TabList aria-label="Dynamic">
          {addZero && <Tab value="zero">Zero</Tab>}
          <Tab value="one">One</Tab>
          {keepTwo && <Tab value="two">Two</Tab>}
          <Tab value="three">Three</Tab>
        </TabList>
      </Tabs>
    </>
  );
}

describe("Tabs", () => {
  it("T1 exposes tablist, tab and tabpanel roles, names and links", () => {
    renderTabs();
    const list = screen.getByRole("tablist", { name: "Sections" });
    expect(list).toHaveAttribute("aria-orientation", "horizontal");

    const tabs = screen.getAllByRole("tab");
    expect(tabs).toHaveLength(3);
    for (const t of tabs) {
      expect(t.tagName).toBe("BUTTON");
      expect(t).toHaveAttribute("type", "button");
      expect(t.id).not.toBe("");
    }
    expect(tabs[0]).toHaveAttribute("aria-selected", "true");
    expect(tabs[1]).toHaveAttribute("aria-selected", "false");
    expect(tabs[2]).toHaveAttribute("aria-selected", "false");

    const panels = screen.getAllByRole("tabpanel", { hidden: true });
    expect(panels).toHaveLength(3);
    const visible = screen.getByRole("tabpanel");
    expect(visible).toHaveTextContent("Panel one");
    expect(visible).toHaveAttribute("aria-labelledby", tabs[0].id);
    expect(visible).toHaveAttribute("tabindex", "0");
    expect(tabs[0]).toHaveAttribute("aria-controls", visible.id);

    expect(panels[1]).toHaveAttribute("hidden");
    expect(panels[2]).toHaveAttribute("hidden");
    expect(panels[1]).toHaveAttribute("aria-labelledby", tabs[1].id);
    expect(tabs[1]).toHaveAttribute("aria-controls", panels[1].id);
  });

  it("T2 only the selected tab is in the tab order, and Tab moves from it to the panel", async () => {
    const user = userEvent.setup();
    renderTabs({ defaultValue: "two" });
    expect(tab("One")).toHaveAttribute("tabindex", "-1");
    expect(tab("Two")).toHaveAttribute("tabindex", "0");
    expect(tab("Three")).toHaveAttribute("tabindex", "-1");

    await user.tab();
    expect(tab("Two")).toHaveFocus();
    await user.tab();
    expect(screen.getByRole("tabpanel")).toHaveTextContent("Panel two");
    expect(screen.getByRole("tabpanel")).toHaveFocus();
  });

  it("T3 ArrowRight and ArrowLeft move to the next and previous enabled tab, wrapping and skipping disabled tabs", async () => {
    const user = userEvent.setup();
    const onValueChange = vi.fn();
    renderTabs({ onValueChange }, ["two"]);

    await user.tab();
    expect(tab("One")).toHaveFocus();
    await user.keyboard("{ArrowRight}");
    expect(tab("Three")).toHaveFocus();
    expect(tab("Three")).toHaveAttribute("aria-selected", "true");
    expect(onValueChange).toHaveBeenLastCalledWith("three");

    await user.keyboard("{ArrowRight}");
    expect(tab("One")).toHaveFocus();
    expect(onValueChange).toHaveBeenLastCalledWith("one");

    await user.keyboard("{ArrowLeft}");
    expect(tab("Three")).toHaveFocus();
    expect(tab("Three")).toHaveAttribute("aria-selected", "true");
  });

  it("T3 a nested Tabs keeps its arrow and Home/End keys to its own list, so the outer selection does not move", async () => {
    const user = userEvent.setup();
    const outerChange = vi.fn();
    // The inner Tabs sits inside the outer TabList element, so its keydown bubbles up to it.
    render(
      <Tabs defaultValue="x" onValueChange={outerChange}>
        <TabList aria-label="Outer">
          <Tab value="x">X</Tab>
          <Tab value="y">Y</Tab>
          <Tabs defaultValue="a">
            <TabList aria-label="Inner">
              <Tab value="a">A</Tab>
              <Tab value="b">B</Tab>
              <Tab value="c">C</Tab>
            </TabList>
            <TabPanel value="a">Inner A</TabPanel>
            <TabPanel value="b">Inner B</TabPanel>
            <TabPanel value="c">Inner C</TabPanel>
          </Tabs>
        </TabList>
        <TabPanel value="x">Outer X</TabPanel>
        <TabPanel value="y">Outer Y</TabPanel>
      </Tabs>,
    );
    await user.click(tab("A"));
    await user.keyboard("{ArrowRight}");
    expect(tab("B")).toHaveFocus();
    await user.keyboard("{Home}");
    expect(tab("A")).toHaveFocus();
    await user.keyboard("{End}");
    expect(tab("C")).toHaveFocus();
    expect(outerChange).not.toHaveBeenCalled();
    expect(tab("X")).toHaveAttribute("aria-selected", "true");
  });

  it("T3 Home and End move to the first and last enabled tabs", async () => {
    const user = userEvent.setup();
    const onValueChange = vi.fn();
    renderTabs({ onValueChange }, ["one"]);

    await user.tab();
    expect(tab("Two")).toHaveFocus();
    await user.keyboard("{End}");
    expect(tab("Three")).toHaveFocus();
    expect(onValueChange).toHaveBeenLastCalledWith("three");
    await user.keyboard("{Home}");
    expect(tab("Two")).toHaveFocus();
    expect(onValueChange).toHaveBeenLastCalledWith("two");
  });

  it("T3 other keys do nothing and arrow keys call preventDefault", async () => {
    const user = userEvent.setup();
    const onValueChange = vi.fn();
    renderTabs({ onValueChange });

    await user.tab();
    await user.keyboard("a{ArrowDown}");
    expect(tab("One")).toHaveFocus();
    expect(onValueChange).not.toHaveBeenCalled();
    expect(fireEvent.keyDown(tab("One"), { key: "ArrowRight" })).toBe(false);
  });

  it("T4 clicking an enabled tab selects it, and clicking a disabled tab does nothing", async () => {
    const user = userEvent.setup();
    const onValueChange = vi.fn();
    renderTabs({ onValueChange }, ["three"]);

    await user.click(tab("Two"));
    expect(tab("Two")).toHaveAttribute("aria-selected", "true");
    expect(screen.getByRole("tabpanel")).toHaveTextContent("Panel two");

    expect(tab("Three")).toHaveAttribute("aria-disabled", "true");
    await user.click(tab("Three"));
    expect(tab("Three")).toHaveAttribute("aria-selected", "false");
    expect(tab("Two")).toHaveAttribute("aria-selected", "true");
    expect(onValueChange).toHaveBeenCalledTimes(1);
    expect(onValueChange).toHaveBeenCalledWith("two");
  });

  it("T5 uncontrolled: defaultValue sets the initial tab", () => {
    renderTabs({ defaultValue: "two" });
    expect(tab("Two")).toHaveAttribute("aria-selected", "true");
    expect(tab("One")).toHaveAttribute("aria-selected", "false");
  });

  it("T5 controlled: the shown selection follows value, and ignores clicks the parent does not accept", async () => {
    const user = userEvent.setup();
    const onValueChange = vi.fn();
    const { rerender } = renderTabs({ value: "one", onValueChange });

    await user.click(tab("Two"));
    expect(onValueChange).toHaveBeenCalledWith("two");
    expect(tab("One")).toHaveAttribute("aria-selected", "true");
    expect(tab("Two")).toHaveAttribute("aria-selected", "false");
    expect(screen.getByRole("tabpanel")).toHaveTextContent("Panel one");

    rerender(tabsTree({ value: "two", onValueChange }));
    expect(tab("Two")).toHaveAttribute("aria-selected", "true");
    expect(screen.getByRole("tabpanel")).toHaveTextContent("Panel two");
  });

  it("T6 does not call onValueChange when the already-selected tab is activated", async () => {
    const user = userEvent.setup();
    const onValueChange = vi.fn();
    renderTabs({ defaultValue: "one", onValueChange });

    await user.click(tab("One"));
    await user.tab();
    await user.keyboard("{Enter}");
    expect(onValueChange).not.toHaveBeenCalled();
  });

  it("T6 hostile: all tabs but one disabled keeps focus on the one enabled tab", async () => {
    const user = userEvent.setup();
    const onValueChange = vi.fn();
    renderTabs({ onValueChange }, ["one", "three"]);

    await user.tab();
    expect(tab("Two")).toHaveFocus();
    await user.keyboard("{ArrowRight}{ArrowLeft}{ArrowRight}");
    expect(tab("Two")).toHaveFocus();
    expect(onValueChange).not.toHaveBeenCalled();
  });

  it("T6 hostile: all tabs disabled does not hang or select anything", async () => {
    const user = userEvent.setup();
    renderTabs({}, ["one", "two", "three"]);

    tab("One").focus();
    await user.keyboard("{ArrowRight}{End}{Home}{ArrowLeft}");
    expect(tab("One")).toHaveFocus();
    for (const t of screen.getAllByRole("tab")) {
      expect(t).toHaveAttribute("aria-selected", "false");
      expect(t).toHaveAttribute("tabindex", "-1");
    }
  });

  it("T6 hostile: first tab disabled and no defaultValue selects and tabs to the first enabled tab", async () => {
    const user = userEvent.setup();
    renderTabs({}, ["one"]);

    expect(tab("Two")).toHaveAttribute("aria-selected", "true");
    expect(tab("Two")).toHaveAttribute("tabindex", "0");
    expect(tab("One")).toHaveAttribute("tabindex", "-1");
    await user.tab();
    expect(tab("Two")).toHaveFocus();
  });

  it("T6 hostile: keyboard order follows the DOM as tabs are added and removed", async () => {
    const user = userEvent.setup();
    render(<DynamicTabs />);

    await user.click(screen.getByRole("button", { name: "Add zero" }));
    await user.click(tab("One"));
    await user.keyboard("{ArrowLeft}");
    expect(tab("Zero")).toHaveFocus();

    await user.click(screen.getByRole("button", { name: "Remove two" }));
    await user.click(tab("One"));
    await user.keyboard("{ArrowRight}");
    expect(tab("One")).not.toHaveFocus();
    expect(tab("Three")).toHaveFocus();
  });

  it("T6 hostile: a defaultValue that matches no tab selects nothing but keeps the first enabled tab reachable", async () => {
    const user = userEvent.setup();
    renderTabs({ defaultValue: "nope" });

    for (const t of screen.getAllByRole("tab")) {
      expect(t).toHaveAttribute("aria-selected", "false");
    }
    expect(tab("One")).toHaveAttribute("tabindex", "0");
    await user.tab();
    expect(tab("One")).toHaveFocus();
  });

  it("T6 hostile: a controlled value that matches no tab keeps the first enabled tab reachable", async () => {
    const user = userEvent.setup();
    renderTabs({ value: "nope" });

    expect(tab("One")).toHaveAttribute("tabindex", "0");
    expect(tab("One")).toHaveAttribute("aria-selected", "false");
    await user.tab();
    expect(tab("One")).toHaveFocus();
  });

  it("G3 forwards className and native props to the root, and G4 two instances share no ids or state", async () => {
    const user = userEvent.setup();
    render(
      <>
        <Tabs className="root-class" data-testid="root">
          <TabList aria-label="A">
            <Tab value="x">X</Tab>
          </TabList>
        </Tabs>
        {tabsTree()}
        {tabsTree()}
      </>,
    );
    expect(screen.getByTestId("root")).toHaveClass("root-class");

    const tabs = screen.getAllByRole("tab", { name: "Two" });
    const ids = new Set(screen.getAllByRole("tab").map((t) => t.id));
    expect(ids.size).toBe(7);

    await user.click(tabs[0]);
    expect(tabs[0]).toHaveAttribute("aria-selected", "true");
    expect(tabs[1]).toHaveAttribute("aria-selected", "false");
  });
});

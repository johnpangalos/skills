import {
  createContext,
  useContext,
  useId,
  useLayoutEffect,
  useRef,
  useState,
  type ButtonHTMLAttributes,
  type HTMLAttributes,
  type KeyboardEvent,
  type ReactNode,
} from "react";

export interface TabsProps extends Omit<HTMLAttributes<HTMLDivElement>, "defaultValue"> {
  /** Selected tab value. Passing it makes the component controlled. */
  value?: string;
  /** Initially selected tab value when uncontrolled. Falls back to the first enabled tab. */
  defaultValue?: string;
  /** Called with the new value when the user selects a tab. */
  onValueChange?: (value: string) => void;
  children?: ReactNode;
}

export interface TabListProps extends HTMLAttributes<HTMLDivElement> {
  /** Accessible name of the tablist. */
  "aria-label": string;
}

export interface TabProps extends Omit<ButtonHTMLAttributes<HTMLButtonElement>, "type" | "value"> {
  /** Value identifying this tab; the matching TabPanel uses the same value. */
  value: string;
  /** Disabled tabs are skipped by the keyboard and ignore clicks. */
  disabled?: boolean;
}

export interface TabPanelProps extends HTMLAttributes<HTMLDivElement> {
  /** Value of the tab that labels this panel. */
  value: string;
}

interface TabsContextValue {
  baseId: string;
  selected: string | null;
  controlled: boolean;
  select: (value: string) => void;
  setInternal: (value: string) => void;
  // Value of the tab that takes the tab stop instead of the selected one; null when the selected tab can.
  focusable: string | null;
  setFocusable: (value: string | null) => void;
  // Re-renders Tabs so TabList re-runs its sync effect after a Tab mounts, unmounts or changes disabled.
  bump: () => void;
}

const TabsContext = createContext<TabsContextValue | null>(null);

function useTabsContext(): TabsContextValue {
  const context = useContext(TabsContext);
  if (context === null) {
    throw new Error("Tab components must be rendered inside <Tabs>");
  }
  return context;
}

// Values are encoded so ids never contain whitespace or raw special characters.
function tabId(baseId: string, value: string): string {
  return `${baseId}-tab-${encodeURIComponent(value)}`;
}

function panelId(baseId: string, value: string): string {
  return `${baseId}-panel-${encodeURIComponent(value)}`;
}

// Read at key time so the order always matches the DOM, even after tabs are inserted.
function getTabs(list: HTMLElement): HTMLElement[] {
  return Array.from(list.querySelectorAll<HTMLElement>('[role="tab"]'));
}

function isEnabled(tab: HTMLElement): boolean {
  return tab.getAttribute("aria-disabled") !== "true";
}

function nextEnabled(tabs: HTMLElement[], from: number, step: 1 | -1): HTMLElement | undefined {
  for (let offset = 1; offset <= tabs.length; offset++) {
    const index = (((from + step * offset) % tabs.length) + tabs.length) % tabs.length;
    if (isEnabled(tabs[index])) return tabs[index];
  }
  return undefined;
}

export function Tabs({ value, defaultValue, onValueChange, children, ...rest }: TabsProps) {
  const baseId = useId();
  const [internal, setInternal] = useState<string | null>(defaultValue ?? null);
  const controlled = value !== undefined;
  const selected = value ?? internal;
  const [focusable, setFocusable] = useState<string | null>(null);
  const [, setRevision] = useState(0);
  const bump = () => setRevision((revision) => revision + 1);

  const select = (next: string) => {
    if (next === selected) return;
    if (!controlled) setInternal(next);
    onValueChange?.(next);
  };

  return (
    <TabsContext.Provider
      value={{ baseId, selected, controlled, select, setInternal, focusable, setFocusable, bump }}
    >
      <div {...rest}>{children}</div>
    </TabsContext.Provider>
  );
}

export function TabList({ children, onKeyDown: onUserKeyDown, ...rest }: TabListProps) {
  const { controlled, select, setInternal, setFocusable } = useTabsContext();
  const listRef = useRef<HTMLDivElement>(null);

  // If the selected tab is missing or disabled, the first enabled tab takes the tab stop.
  // Uncontrolled, it is also selected. Runs after every render so the DOM is always current.
  useLayoutEffect(() => {
    if (listRef.current === null) return;
    const tabs = getTabs(listRef.current);
    const current = tabs.find((tab) => tab.getAttribute("aria-selected") === "true");
    if (current && isEnabled(current)) {
      setFocusable(null);
      return;
    }
    const first = tabs.find(isEnabled)?.getAttribute("data-value") ?? null;
    setFocusable(first);
    if (!controlled && first !== null) setInternal(first);
  });

  function onKeyDown(event: KeyboardEvent<HTMLDivElement>) {
    onUserKeyDown?.(event);
    if (event.defaultPrevented) return;
    const tabs = getTabs(event.currentTarget);
    const from = tabs.indexOf(event.target as HTMLElement);
    let next: HTMLElement | undefined;
    switch (event.key) {
      case "ArrowRight":
        next = nextEnabled(tabs, from, 1);
        break;
      case "ArrowLeft":
        next = nextEnabled(tabs, from, -1);
        break;
      case "Home":
        next = tabs.find(isEnabled);
        break;
      case "End":
        next = tabs.filter(isEnabled).pop();
        break;
      default:
        return;
    }
    event.preventDefault();
    if (next === undefined) return;
    next.focus();
    select(next.getAttribute("data-value") ?? "");
  }

  return (
    <div {...rest} ref={listRef} role="tablist" aria-orientation="horizontal" onKeyDown={onKeyDown}>
      {children}
    </div>
  );
}

export function Tab({ value, disabled = false, onClick, ...rest }: TabProps) {
  const { baseId, selected, focusable, select, bump } = useTabsContext();
  useLayoutEffect(() => {
    bump();
    return bump;
  }, [disabled]);
  const isSelected = selected === value;
  const isTabStop = focusable === null ? isSelected : focusable === value;
  return (
    <button
      {...rest}
      type="button"
      role="tab"
      id={tabId(baseId, value)}
      data-value={value}
      aria-selected={isSelected}
      aria-controls={panelId(baseId, value)}
      aria-disabled={disabled || undefined}
      tabIndex={isTabStop ? 0 : -1}
      onClick={(event) => {
        onClick?.(event);
        if (!disabled) select(value);
      }}
    />
  );
}

export function TabPanel({ value, ...rest }: TabPanelProps) {
  const { baseId, selected } = useTabsContext();
  return (
    <div
      {...rest}
      role="tabpanel"
      id={panelId(baseId, value)}
      aria-labelledby={tabId(baseId, value)}
      tabIndex={0}
      hidden={selected !== value}
    />
  );
}

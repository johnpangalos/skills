import { act, render, screen, within } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { useState } from "react";
import { Tab, TabList, TabPanel, Tabs } from "../Tabs/Tabs";
import { Dialog } from "./Dialog";

// Opener button outside the dialog; the dialog opens and closes through state.
function WithOpener({ description }: { description?: string }) {
  const [open, setOpen] = useState(false);
  return (
    <>
      <button type="button" onClick={() => setOpen(true)}>
        Open
      </button>
      <Dialog open={open} onOpenChange={setOpen} title="Confirm" description={description}>
        <button type="button">First</button>
        <button type="button">Second</button>
      </Dialog>
    </>
  );
}

// Opener lives beside the dialog so it survives the dialog's unmount.
function Conditional({ showOpener, open }: { showOpener: boolean; open: boolean }) {
  return (
    <>
      {showOpener ? (
        <button type="button">Opener</button>
      ) : null}
      <Dialog open={open} onOpenChange={() => {}} title="Gone">
        <button type="button">Inside</button>
      </Dialog>
    </>
  );
}

function Nested() {
  const [outer, setOuter] = useState(false);
  const [inner, setInner] = useState(false);
  return (
    <>
      <button type="button" onClick={() => setOuter(true)}>
        Open outer
      </button>
      <Dialog open={outer} onOpenChange={setOuter} title="Outer">
        <button type="button" onClick={() => setInner(true)}>
          Open inner
        </button>
        <button type="button">Outer action</button>
        <Dialog open={inner} onOpenChange={setInner} title="Inner">
          <button type="button">Inner action</button>
        </Dialog>
      </Dialog>
    </>
  );
}

function backdrop(): HTMLElement {
  const element = document.querySelector<HTMLElement>("[data-backdrop]");
  if (!element) throw new Error("no backdrop rendered");
  return element;
}

describe("Dialog rendering (D1)", () => {
  it("D1: renders nothing when closed", () => {
    render(
      <Dialog open={false} onOpenChange={() => {}} title="Confirm">
        body
      </Dialog>,
    );
    expect(screen.queryByRole("dialog")).toBeNull();
    expect(document.querySelector("[data-backdrop]")).toBeNull();
  });

  it("D1: when open, renders a backdrop and a modal dialog portaled into document.body", () => {
    const { container } = render(
      <Dialog open onOpenChange={() => {}} title="Confirm" description="Are you sure?">
        <button type="button">First</button>
      </Dialog>,
    );
    const dialog = screen.getByRole("dialog", { name: "Confirm" });
    expect(dialog).toHaveAttribute("aria-modal", "true");
    expect(document.body.contains(dialog)).toBe(true);
    expect(container.contains(dialog)).toBe(false);
    expect(backdrop()).toBeInTheDocument();
    expect(screen.getByRole("heading", { name: "Confirm" })).toBe(
      document.getElementById(dialog.getAttribute("aria-labelledby") ?? ""),
    );
    expect(document.getElementById(dialog.getAttribute("aria-describedby") ?? "")).toHaveTextContent("Are you sure?");
  });

  it("D1: omits aria-describedby when no description is given", () => {
    render(
      <Dialog open onOpenChange={() => {}} title="Confirm">
        <button type="button">First</button>
      </Dialog>,
    );
    expect(screen.getByRole("dialog")).not.toHaveAttribute("aria-describedby");
  });
});

describe("Dialog initial focus (D2)", () => {
  it("D2: moves focus to the first tabbable element on open", async () => {
    const user = userEvent.setup();
    render(<WithOpener />);
    await user.click(screen.getByRole("button", { name: "Open" }));
    expect(screen.getByRole("button", { name: "First" })).toHaveFocus();
  });

  it("D2: focuses the dialog element itself when it has no tabbable content", () => {
    render(
      <Dialog open onOpenChange={() => {}} title="Notice">
        <p>Just text</p>
      </Dialog>,
    );
    const dialog = screen.getByRole("dialog");
    expect(dialog).toHaveAttribute("tabindex", "-1");
    expect(dialog).toHaveFocus();
  });

  it("D2: an element with autoFocus keeps focus", () => {
    render(
      <Dialog open onOpenChange={() => {}} title="Name">
        <button type="button">First</button>
        <input aria-label="Name" autoFocus />
      </Dialog>,
    );
    expect(screen.getByRole("textbox", { name: "Name" })).toHaveFocus();
  });
});

describe("Dialog focus trap (D3)", () => {
  it("D3: Tab from the last tabbable wraps to the first, Shift+Tab from the first wraps to the last", async () => {
    const user = userEvent.setup();
    render(
      <Dialog open onOpenChange={() => {}} title="Three">
        <button type="button">A</button>
        <button type="button">B</button>
        <button type="button">C</button>
      </Dialog>,
    );
    expect(screen.getByRole("button", { name: "A" })).toHaveFocus();
    await user.tab();
    expect(screen.getByRole("button", { name: "B" })).toHaveFocus();
    await user.tab();
    expect(screen.getByRole("button", { name: "C" })).toHaveFocus();
    await user.tab();
    expect(screen.getByRole("button", { name: "A" })).toHaveFocus();
    await user.tab({ shift: true });
    expect(screen.getByRole("button", { name: "C" })).toHaveFocus();
  });

  it("D3: with no tabbable content, Tab keeps focus on the dialog", async () => {
    const user = userEvent.setup();
    render(
      <Dialog open onOpenChange={() => {}} title="Notice">
        <button type="button" disabled>
          Off
        </button>
      </Dialog>,
    );
    const dialog = screen.getByRole("dialog");
    await user.tab();
    expect(dialog).toHaveFocus();
    await user.tab({ shift: true });
    expect(dialog).toHaveFocus();
  });

  it("D3: skips disabled, hidden, tabIndex=-1 and inert content", async () => {
    const user = userEvent.setup();
    render(
      <Dialog open onOpenChange={() => {}} title="Mixed">
        <button type="button">Start</button>
        <button type="button" disabled>
          Disabled
        </button>
        <button type="button" tabIndex={-1}>
          Negative
        </button>
        <div hidden>
          <button type="button">Hidden</button>
        </div>
        <div inert>
          <button type="button">Inert</button>
        </div>
        <button type="button">End</button>
      </Dialog>,
    );
    const reached = new Set<string>();
    for (let step = 0; step < 6; step++) {
      await user.tab();
      reached.add(document.activeElement?.textContent ?? "");
    }
    expect([...reached].sort()).toEqual(["End", "Start"]);
  });

  it("D3: includes elements added after the dialog opened", async () => {
    const user = userEvent.setup();
    function Growing() {
      const [late, setLate] = useState(false);
      return (
        <Dialog open onOpenChange={() => {}} title="Grow">
          <button type="button">Start</button>
          <button type="button" onClick={() => setLate(true)}>
            Add
          </button>
          {late ? <button type="button">Late</button> : null}
        </Dialog>
      );
    }
    render(<Growing />);
    await user.click(screen.getByRole("button", { name: "Add" }));
    await user.tab();
    expect(screen.getByRole("button", { name: "Late" })).toHaveFocus();
    await user.tab();
    expect(screen.getByRole("button", { name: "Start" })).toHaveFocus();
  });

  it("D3: focus that moves outside the dialog is brought back", () => {
    render(
      <>
        <button type="button">Outside</button>
        <Dialog open onOpenChange={() => {}} title="Focus">
          <button type="button">Inside</button>
        </Dialog>
      </>,
    );
    act(() => screen.getByRole("button", { name: "Outside" }).focus());
    expect(screen.getByRole("button", { name: "Inside" })).toHaveFocus();
  });

  it("triggered: Tab inside a dialog never reaches a Tabs component's hidden panel", async () => {
    const user = userEvent.setup();
    render(
      <Dialog open onOpenChange={() => {}} title="Settings">
        <Tabs defaultValue="one">
          <TabList aria-label="Sections">
            <Tab value="one">One</Tab>
            <Tab value="two">Two</Tab>
          </TabList>
          <TabPanel value="one">
            <button type="button">Visible action</button>
          </TabPanel>
          <TabPanel value="two">
            <button type="button">Hidden action</button>
          </TabPanel>
        </Tabs>
        <button type="button">Close</button>
      </Dialog>,
    );
    const reached = new Set<string>();
    for (let step = 0; step < 8; step++) {
      await user.tab();
      reached.add(document.activeElement?.textContent ?? "");
    }
    expect(reached.has("Hidden action")).toBe(false);
    expect(reached.has("Two")).toBe(false);
    expect(reached.has("Close")).toBe(true);
  });
});

describe("Dialog closing (D4)", () => {
  it("D4: Escape calls onOpenChange(false)", async () => {
    const user = userEvent.setup();
    const onOpenChange = vi.fn();
    render(
      <Dialog open onOpenChange={onOpenChange} title="Confirm">
        <button type="button">First</button>
      </Dialog>,
    );
    await user.keyboard("{Escape}");
    expect(onOpenChange).toHaveBeenCalledTimes(1);
    expect(onOpenChange).toHaveBeenCalledWith(false);
  });

  it("D4: clicking the backdrop calls onOpenChange(false)", async () => {
    const user = userEvent.setup();
    const onOpenChange = vi.fn();
    render(
      <Dialog open onOpenChange={onOpenChange} title="Confirm">
        <button type="button">First</button>
      </Dialog>,
    );
    await user.click(backdrop());
    expect(onOpenChange).toHaveBeenCalledTimes(1);
    expect(onOpenChange).toHaveBeenCalledWith(false);
  });

  it("D4: clicks inside the dialog content do not close it", async () => {
    const user = userEvent.setup();
    const onOpenChange = vi.fn();
    render(
      <Dialog open onOpenChange={onOpenChange} title="Confirm">
        <button type="button">First</button>
      </Dialog>,
    );
    await user.click(screen.getByRole("heading", { name: "Confirm" }));
    await user.click(screen.getByRole("button", { name: "First" }));
    expect(onOpenChange).not.toHaveBeenCalled();
  });

  it("D7: mousedown inside the dialog then mouseup on the backdrop does not close it", async () => {
    const user = userEvent.setup();
    const onOpenChange = vi.fn();
    render(
      <Dialog open onOpenChange={onOpenChange} title="Confirm">
        <button type="button">First</button>
      </Dialog>,
    );
    await user.pointer({ keys: "[MouseLeft>]", target: screen.getByRole("button", { name: "First" }) });
    await user.pointer({ keys: "[/MouseLeft]", target: backdrop() });
    expect(onOpenChange).not.toHaveBeenCalled();
  });

  it("D5: Escape returns focus to the element focused before opening", async () => {
    const user = userEvent.setup();
    render(<WithOpener />);
    const opener = screen.getByRole("button", { name: "Open" });
    await user.click(opener);
    expect(screen.getByRole("button", { name: "First" })).toHaveFocus();
    await user.keyboard("{Escape}");
    expect(screen.queryByRole("dialog")).toBeNull();
    expect(opener).toHaveFocus();
  });

  it("D5: unmounting while open returns focus to the opener", () => {
    const { rerender } = render(<Conditional showOpener open={false} />);
    act(() => screen.getByRole("button", { name: "Opener" }).focus());
    rerender(<Conditional showOpener open />);
    expect(screen.getByRole("button", { name: "Inside" })).toHaveFocus();
    rerender(<Conditional showOpener open={false} />);
    expect(screen.getByRole("button", { name: "Opener" })).toHaveFocus();
  });

  it("D5: focus returns to the opener when the opener is in the document", () => {
    const { rerender } = render(<Conditional showOpener open={false} />);
    act(() => screen.getByRole("button", { name: "Opener" }).focus());
    rerender(<Conditional showOpener open />);
    rerender(<Conditional showOpener open={false} />);
    expect(screen.getByRole("button", { name: "Opener" })).toHaveFocus();
  });
});

describe("Dialog controlled-only (D7)", () => {
  it("D7: open and onOpenChange are required props", () => {
    // @ts-expect-error onOpenChange is required
    const missing = <Dialog open title="Confirm">body</Dialog>;
    expect(missing).toBeTruthy();
  });

  it("D7: the dialog stays open after Escape unless the parent sets open to false", async () => {
    const user = userEvent.setup();
    const onOpenChange = vi.fn();
    render(
      <Dialog open onOpenChange={onOpenChange} title="Confirm">
        <button type="button">First</button>
      </Dialog>,
    );
    await user.keyboard("{Escape}");
    expect(onOpenChange).toHaveBeenCalledWith(false);
    expect(screen.getByRole("dialog")).toBeInTheDocument();
  });

  it("D7: removing the opener while open does not throw when the dialog closes", () => {
    const { rerender } = render(<Conditional showOpener open={false} />);
    act(() => screen.getByRole("button", { name: "Opener" }).focus());
    rerender(<Conditional showOpener open />);
    rerender(<Conditional showOpener={false} open />);
    expect(() => rerender(<Conditional showOpener={false} open={false} />)).not.toThrow();
    expect(screen.queryByRole("dialog")).toBeNull();
    expect(document.activeElement).toBe(document.body);
  });

  it("D7: toggling open true, false, true rapidly still restores focus to the original opener", () => {
    const { rerender } = render(<Conditional showOpener open={false} />);
    const opener = screen.getByRole("button", { name: "Opener" });
    act(() => opener.focus());
    rerender(<Conditional showOpener open />);
    rerender(<Conditional showOpener open={false} />);
    rerender(<Conditional showOpener open />);
    rerender(<Conditional showOpener open={false} />);
    expect(opener).toHaveFocus();
  });

  it("D7: with two dialogs open, Escape closes only the topmost", async () => {
    const user = userEvent.setup();
    const onOuter = vi.fn();
    const onInner = vi.fn();
    render(
      <>
        <Dialog open onOpenChange={onOuter} title="First layer">
          <button type="button">One</button>
        </Dialog>
        <Dialog open onOpenChange={onInner} title="Second layer">
          <button type="button">Two</button>
        </Dialog>
      </>,
    );
    await user.keyboard("{Escape}");
    expect(onInner).toHaveBeenCalledTimes(1);
    expect(onInner).toHaveBeenCalledWith(false);
    expect(onOuter).not.toHaveBeenCalled();
  });
});

describe("Dialog nesting (D6)", () => {
  it("D6: a dialog opened inside another traps focus itself and Escape closes only the inner", async () => {
    const user = userEvent.setup();
    render(<Nested />);
    await user.click(screen.getByRole("button", { name: "Open outer" }));
    await user.click(screen.getByRole("button", { name: "Open inner" }));
    const inner = screen.getByRole("dialog", { name: "Inner" });
    expect(within(inner).getByRole("button", { name: "Inner action" })).toHaveFocus();
    await user.tab();
    expect(screen.getByRole("button", { name: "Inner action" })).toHaveFocus();
    await user.tab({ shift: true });
    expect(screen.getByRole("button", { name: "Inner action" })).toHaveFocus();

    await user.keyboard("{Escape}");
    expect(screen.queryByRole("dialog", { name: "Inner" })).toBeNull();
    expect(screen.getByRole("dialog", { name: "Outer" })).toBeInTheDocument();
    expect(screen.getByRole("button", { name: "Open inner" })).toHaveFocus();

    await user.keyboard("{Escape}");
    expect(screen.queryByRole("dialog", { name: "Outer" })).toBeNull();
    expect(screen.getByRole("button", { name: "Open outer" })).toHaveFocus();
  });

  it("D6: a click inside the inner dialog does not close the outer dialog", async () => {
    const user = userEvent.setup();
    render(<Nested />);
    await user.click(screen.getByRole("button", { name: "Open outer" }));
    await user.click(screen.getByRole("button", { name: "Open inner" }));
    await user.click(screen.getByRole("button", { name: "Inner action" }));
    expect(screen.getByRole("dialog", { name: "Outer" })).toBeInTheDocument();
    expect(screen.getByRole("dialog", { name: "Inner" })).toBeInTheDocument();
  });
});

describe("Dialog review fixes", () => {
  it("D3: a hidden input is not tabbable, so Tab moves one -> two and wraps back to one", async () => {
    const user = userEvent.setup();
    render(
      <Dialog open onOpenChange={() => {}} title="Hidden field">
        <button type="button">one</button>
        <input type="hidden" name="h" />
        <button type="button">two</button>
      </Dialog>,
    );
    expect(screen.getByRole("button", { name: "one" })).toHaveFocus();
    await user.tab();
    expect(screen.getByRole("button", { name: "two" })).toHaveFocus();
    await user.tab();
    expect(screen.getByRole("button", { name: "one" })).toHaveFocus();
  });

  it("D3: a hidden input with tabIndex=0 is not tabbable, so Tab moves one -> two -> one", async () => {
    const user = userEvent.setup();
    render(
      <Dialog open onOpenChange={() => {}} title="Hidden field with tabindex">
        <button type="button">one</button>
        <input type="hidden" name="h" tabIndex={0} />
        <button type="button">two</button>
      </Dialog>,
    );
    expect(screen.getByRole("button", { name: "one" })).toHaveFocus();
    await user.tab();
    expect(screen.getByRole("button", { name: "two" })).toHaveFocus();
    await user.tab();
    expect(screen.getByRole("button", { name: "one" })).toHaveFocus();
  });

  it("a user onMouseDown on the dialog is called, and a drag from inside still does not close it", async () => {
    const user = userEvent.setup();
    const onMouseDown = vi.fn();
    const onOpenChange = vi.fn();
    render(
      <Dialog open onOpenChange={onOpenChange} title="Confirm" onMouseDown={onMouseDown}>
        <button type="button">First</button>
      </Dialog>,
    );
    await user.pointer({ keys: "[MouseLeft>]", target: screen.getByRole("button", { name: "First" }) });
    expect(onMouseDown).toHaveBeenCalledTimes(1);
    await user.pointer({ keys: "[/MouseLeft]", target: backdrop() });
    expect(onOpenChange).not.toHaveBeenCalled();
  });
});

import { useState } from "react";
import { fireEvent, render, screen } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { Combobox, type ComboboxOption } from "./index";

const fruits: ComboboxOption[] = [
  { value: "apple", label: "Apple" },
  { value: "apricot", label: "Apricot", disabled: true },
  { value: "banana", label: "Banana" },
  { value: "blueberry", label: "Blueberry" },
];

function Controlled({
  options = fruits,
  initial = null,
  onChange = () => {},
  placeholder,
}: {
  options?: ComboboxOption[];
  initial?: string | null;
  onChange?: (value: string | null) => void;
  placeholder?: string;
}) {
  const [value, setValue] = useState<string | null>(initial);
  return (
    <Combobox
      label="Fruit"
      options={options}
      placeholder={placeholder}
      value={value}
      onChange={(next) => {
        onChange(next);
        setValue(next);
      }}
    />
  );
}

const input = () => screen.getByRole("combobox", { name: "Fruit" });
const optionNamed = (name: string) => screen.getByRole("option", { name });
const activeText = () => document.getElementById(input().getAttribute("aria-activedescendant") ?? "")?.textContent;

describe("Combobox", () => {
  it("C1 labels the input, links it to a labelled listbox, and marks selected and disabled options", async () => {
    const user = userEvent.setup();
    render(<Controlled initial="banana" placeholder="Pick a fruit" />);
    const box = input();
    expect(box).toHaveAttribute("aria-autocomplete", "list");
    expect(box).toHaveAttribute("aria-expanded", "false");
    expect(box).toHaveAttribute("placeholder", "Pick a fruit");
    expect(box).toHaveValue("Banana");

    const listbox = screen.getByRole("listbox", { hidden: true });
    expect(box).toHaveAttribute("aria-controls", listbox.id);

    await user.tab();
    await user.keyboard("{ArrowDown}");
    expect(box).toHaveAttribute("aria-expanded", "true");
    expect(screen.getByRole("listbox", { name: "Fruit" })).toBeInTheDocument();
    expect(optionNamed("Banana")).toHaveAttribute("aria-selected", "true");
    expect(optionNamed("Apple")).toHaveAttribute("aria-selected", "false");
    expect(optionNamed("Apricot")).toHaveAttribute("aria-disabled", "true");

    const ids = screen.getAllByRole("option").map((o) => o.id);
    expect(new Set(ids).size).toBe(4);
    for (const id of ids) expect(id).not.toBe("");
  });

  it("C2 typing filters case-insensitively by substring, and shows No results with Enter doing nothing", async () => {
    const user = userEvent.setup();
    const onChange = vi.fn();
    render(<Controlled onChange={onChange} />);

    await user.type(input(), "AN");
    expect(screen.getAllByRole("option")).toHaveLength(1);
    expect(optionNamed("Banana")).toBeInTheDocument();

    await user.clear(input());
    await user.type(input(), "zzz");
    expect(screen.queryAllByRole("option")).toHaveLength(0);
    expect(screen.getByText("No results")).toBeInTheDocument();
    await user.keyboard("{Enter}");
    expect(onChange).not.toHaveBeenCalled();
  });

  it("C3 ArrowDown opens the popup and moves the active option, skipping disabled options and wrapping", async () => {
    const user = userEvent.setup();
    render(<Controlled />);

    await user.tab();
    await user.keyboard("{ArrowDown}");
    expect(input()).toHaveAttribute("aria-expanded", "true");
    expect(input()).toHaveAttribute("aria-activedescendant", optionNamed("Apple").id);
    expect(input()).toHaveFocus();

    await user.keyboard("{ArrowDown}");
    expect(input()).toHaveAttribute("aria-activedescendant", optionNamed("Banana").id);
    await user.keyboard("{ArrowDown}");
    expect(input()).toHaveAttribute("aria-activedescendant", optionNamed("Blueberry").id);
    await user.keyboard("{ArrowDown}");
    expect(input()).toHaveAttribute("aria-activedescendant", optionNamed("Apple").id);
    await user.keyboard("{ArrowUp}");
    expect(input()).toHaveAttribute("aria-activedescendant", optionNamed("Blueberry").id);
    expect(input()).toHaveFocus();
    expect(fireEvent.keyDown(input(), { key: "ArrowUp" })).toBe(false);
  });

  it("C4 Enter commits the active option, closes the popup and shows its label", async () => {
    const user = userEvent.setup();
    const onChange = vi.fn();
    render(<Controlled onChange={onChange} />);

    await user.tab();
    await user.keyboard("{ArrowDown}{ArrowDown}{Enter}");
    expect(onChange).toHaveBeenCalledTimes(1);
    expect(onChange).toHaveBeenCalledWith("banana");
    expect(input()).toHaveAttribute("aria-expanded", "false");
    expect(input()).toHaveValue("Banana");
  });

  it("C4 clicking an enabled option commits it and keeps focus on the input; clicking a disabled one does nothing", async () => {
    const user = userEvent.setup();
    const onChange = vi.fn();
    render(<Controlled onChange={onChange} />);

    await user.type(input(), "b");
    await user.click(optionNamed("Blueberry"));
    expect(onChange).toHaveBeenLastCalledWith("blueberry");
    expect(input()).toHaveFocus();
    expect(input()).toHaveValue("Blueberry");

    onChange.mockClear();
    await user.clear(input());
    await user.type(input(), "ap");
    await user.click(optionNamed("Apricot"));
    expect(onChange).not.toHaveBeenCalled();
    expect(input()).toHaveAttribute("aria-expanded", "true");
  });

  it("C5 Escape closes without calling onChange and reverts the text to the selected label", async () => {
    const user = userEvent.setup();
    const onChange = vi.fn();
    render(<Controlled initial="banana" onChange={onChange} />);

    await user.tab();
    await user.clear(input());
    await user.type(input(), "ap");
    await user.keyboard("{Escape}");
    expect(input()).toHaveAttribute("aria-expanded", "false");
    expect(input()).toHaveValue("Banana");
    expect(onChange).not.toHaveBeenCalled();
  });

  it("C5 Escape with no selection reverts the text to empty", async () => {
    const user = userEvent.setup();
    render(<Controlled />);

    await user.type(input(), "ap");
    await user.keyboard("{Escape}");
    expect(input()).toHaveValue("");
  });

  it("C5 blur closes the popup and reverts the text", async () => {
    const user = userEvent.setup();
    const onChange = vi.fn();
    render(<Controlled initial="banana" onChange={onChange} />);

    await user.tab();
    await user.clear(input());
    await user.type(input(), "ap");
    await user.click(document.body);
    expect(input()).toHaveAttribute("aria-expanded", "false");
    expect(input()).toHaveValue("Banana");
    expect(onChange).not.toHaveBeenCalled();
  });

  it("C6 controlled: the text follows value, including changes from outside and null", () => {
    const spy = vi.fn();
    const props = { label: "Fruit", options: fruits, onChange: spy };
    const { rerender } = render(<Combobox {...props} value="banana" />);
    expect(input()).toHaveValue("Banana");

    rerender(<Combobox {...props} value="apple" />);
    expect(input()).toHaveValue("Apple");

    rerender(<Combobox {...props} value={null} />);
    expect(input()).toHaveValue("");
  });

  it("C6 controlled: a parent that ignores onChange keeps the shown selection", async () => {
    const user = userEvent.setup();
    const onChange = vi.fn();
    render(<Combobox label="Fruit" options={fruits} value="banana" onChange={onChange} />);

    await user.tab();
    await user.keyboard("{ArrowDown}{ArrowDown}{ArrowDown}{Enter}");
    expect(onChange).toHaveBeenCalledWith("blueberry");
    expect(input()).toHaveValue("Banana");
  });

  it("C7 clearing the text and blurring calls onChange(null) once, and only when a value was set", async () => {
    const user = userEvent.setup();
    const onChange = vi.fn();
    const { unmount } = render(<Controlled initial="banana" onChange={onChange} />);

    await user.clear(input());
    await user.click(document.body);
    expect(onChange).toHaveBeenCalledTimes(1);
    expect(onChange).toHaveBeenCalledWith(null);
    expect(input()).toHaveValue("");
    unmount();

    onChange.mockClear();
    render(<Controlled onChange={onChange} />);
    await user.type(input(), "x");
    await user.clear(input());
    await user.click(document.body);
    expect(onChange).not.toHaveBeenCalled();
  });

  it("C7 clearing the text and pressing Enter with no active option calls onChange(null)", async () => {
    const user = userEvent.setup();
    const onChange = vi.fn();
    render(<Controlled initial="banana" onChange={onChange} />);

    await user.clear(input());
    await user.keyboard("{Enter}");
    expect(onChange).toHaveBeenCalledWith(null);
    expect(onChange).toHaveBeenCalledTimes(1);
  });

  it("C8 the active option stays active while the filter still shows it", async () => {
    const user = userEvent.setup();
    const onChange = vi.fn();
    render(<Controlled onChange={onChange} />);

    await user.tab();
    await user.keyboard("{ArrowDown}{ArrowDown}");
    expect(activeText()).toBe("Banana");
    await user.type(input(), "a");
    expect(activeText()).toBe("Banana");
    await user.keyboard("{Enter}");
    expect(onChange).toHaveBeenCalledWith("banana");
  });

  it("C8 the active option resets when the filter hides it", async () => {
    const user = userEvent.setup();
    const onChange = vi.fn();
    render(<Controlled onChange={onChange} />);

    await user.tab();
    await user.keyboard("{ArrowDown}");
    expect(activeText()).toBe("Apple");
    await user.type(input(), "ban");
    expect(input()).not.toHaveAttribute("aria-activedescendant");
    await user.keyboard("{Enter}");
    expect(onChange).not.toHaveBeenCalled();
  });

  it("C8 hostile: all options disabled means no loop, no active option and Enter does nothing", async () => {
    const user = userEvent.setup();
    const onChange = vi.fn();
    const disabled: ComboboxOption[] = [
      { value: "a", label: "A", disabled: true },
      { value: "b", label: "B", disabled: true },
    ];
    render(<Controlled options={disabled} onChange={onChange} />);

    await user.tab();
    await user.keyboard("{ArrowDown}{ArrowUp}{ArrowDown}");
    expect(input()).not.toHaveAttribute("aria-activedescendant");
    await user.keyboard("{Enter}");
    expect(onChange).not.toHaveBeenCalled();
  });

  it("C8 hostile: regex-special and mixed-case filter text matches literally and case-insensitively", async () => {
    const user = userEvent.setup();
    const options: ComboboxOption[] = [
      { value: "dot", label: "a.b" },
      { value: "paren", label: "(x)" },
      { value: "apple", label: "Apple" },
    ];
    render(<Controlled options={options} />);

    await user.type(input(), ".");
    expect(screen.getAllByRole("option").map((o) => o.textContent)).toEqual(["a.b"]);
    await user.clear(input());
    await user.type(input(), "(");
    expect(screen.getAllByRole("option").map((o) => o.textContent)).toEqual(["(x)"]);
    await user.clear(input());
    await user.type(input(), "aPp");
    expect(screen.getAllByRole("option").map((o) => o.textContent)).toEqual(["Apple"]);
  });

  it("C8 hostile: numeric and spaced option values give valid unique ids and commit the value", async () => {
    const user = userEvent.setup();
    const onChange = vi.fn();
    const options: ComboboxOption<number | string>[] = [
      { value: 1, label: "One" },
      { value: "a b", label: "Spaced" },
    ];
    render(<Combobox label="Fruit" options={options} value={null} onChange={onChange} />);

    await user.tab();
    await user.keyboard("{ArrowDown}");
    const ids = screen.getAllByRole("option").map((o) => o.id);
    expect(new Set(ids).size).toBe(2);
    for (const id of ids) expect(id).not.toMatch(/\s/);
    await user.keyboard("{ArrowDown}{Enter}");
    expect(onChange).toHaveBeenCalledWith("a b");
  });

  it("C8 hostile: a value that matches no option leaves the input empty without throwing", () => {
    render(<Combobox label="Fruit" options={fruits} value="nope" onChange={() => {}} />);
    expect(input()).toHaveValue("");
  });

  it("changing list: prepending an option keeps the same item active, and Enter commits it", async () => {
    const user = userEvent.setup();
    const onChange = vi.fn();
    const props = { label: "Fruit", value: null, onChange };
    const { rerender } = render(<Combobox {...props} options={fruits} />);

    await user.tab();
    await user.keyboard("{ArrowDown}{ArrowDown}");
    expect(activeText()).toBe("Banana");

    rerender(<Combobox {...props} options={[{ value: "kiwi", label: "Kiwi" }, ...fruits]} />);
    expect(activeText()).toBe("Banana");
    await user.keyboard("{Enter}");
    expect(onChange).toHaveBeenCalledWith("banana");
  });

  it("changing list: removing the active option leaves nothing active and Enter does nothing", async () => {
    const user = userEvent.setup();
    const onChange = vi.fn();
    const props = { label: "Fruit", value: null, onChange };
    const { rerender } = render(<Combobox {...props} options={fruits} />);

    await user.tab();
    await user.keyboard("{ArrowDown}{ArrowDown}");
    rerender(<Combobox {...props} options={fruits.filter((o) => o.value !== "banana")} />);
    expect(input()).not.toHaveAttribute("aria-activedescendant");
    await user.keyboard("{Enter}");
    expect(onChange).not.toHaveBeenCalled();
  });

  it("G3 forwards className to the wrapper, and G4 two comboboxes share no ids or text", async () => {
    const user = userEvent.setup();
    render(
      <>
        <Combobox label="Fruit" options={fruits} value={null} onChange={() => {}} className="cb" data-testid="first" />
        <Combobox label="Fruit" options={fruits} value={null} onChange={() => {}} />
      </>,
    );
    expect(screen.getByTestId("first")).toHaveClass("cb");

    const [first, second] = screen.getAllByRole("combobox");
    expect(first.id).not.toBe(second.id);
    await user.type(first, "ap");
    expect(second).toHaveValue("");
    expect(second).toHaveAttribute("aria-expanded", "false");
    const optionIds = [...document.querySelectorAll('[role="option"]')].map((o) => o.id);
    expect(new Set(optionIds).size).toBe(optionIds.length);
  });
});

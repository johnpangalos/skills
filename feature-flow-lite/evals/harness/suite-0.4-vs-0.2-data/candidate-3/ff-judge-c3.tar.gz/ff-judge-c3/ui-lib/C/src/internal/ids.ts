// Turns an arbitrary option or tab value into an id-safe segment.
// Letters, digits and hyphens pass through; every other character becomes `_<hex>_`.
// Underscores are always escaped, so the mapping is injective.
export function idSegment(value: string): string {
  return value.replace(/[^A-Za-z0-9-]/g, (character) => `_${character.charCodeAt(0).toString(16)}_`);
}

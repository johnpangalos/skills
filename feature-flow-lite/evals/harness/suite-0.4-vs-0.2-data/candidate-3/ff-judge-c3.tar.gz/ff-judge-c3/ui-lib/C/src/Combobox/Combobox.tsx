import { useEffect, useId, useState, type ChangeEvent, type HTMLAttributes, type KeyboardEvent } from "react";
import { idSegment } from "../internal/ids";

export type ComboboxOption<T extends string | number = string> = {
  value: T;
  label: string;
  disabled?: boolean;
};

export type ComboboxProps<T extends string | number = string> = Omit<HTMLAttributes<HTMLDivElement>, "onChange"> & {
  label: string;
  options: ComboboxOption<T>[];
  value: T | null;
  onChange: (value: T | null) => void;
  placeholder?: string;
};

// Case-insensitive substring match on the raw text; no regular expressions.
function matching<T extends string | number>(options: ComboboxOption<T>[], query: string): ComboboxOption<T>[] {
  const needle = query.toLowerCase();
  return options.filter((option) => option.label.toLowerCase().includes(needle));
}

function labelOf<T extends string | number>(options: ComboboxOption<T>[], value: T | null): string {
  return options.find((option) => option.value === value)?.label ?? "";
}

export function Combobox<T extends string | number = string>({
  label,
  options,
  value,
  onChange,
  placeholder,
  ...rest
}: ComboboxProps<T>) {
  const baseId = useId();
  const labelId = `${baseId}-label`;
  const inputId = `${baseId}-input`;
  const listboxId = `${baseId}-listbox`;
  const optionId = (optionValue: T) => `${baseId}-option-${idSegment(String(optionValue))}`;

  const [open, setOpen] = useState(false);
  // The text the user has typed since the list last closed. Null means no typing, so the input shows the selected label.
  const [query, setQuery] = useState<string | null>(null);
  // The active option is tracked by value, so it survives options changing around it.
  const [activeValue, setActiveValue] = useState<T | null>(null);
  // Set when the user clears the text and onChange(null) is sent. Cleared once the parent's next value is known.
  const [pendingClear, setPendingClear] = useState(false);

  // If the parent kept its value after the clear, the text goes back to that value's label.
  useEffect(() => {
    if (!pendingClear) return;
    setPendingClear(false);
    if (value !== null) setQuery(null);
  }, [pendingClear, value]);

  // Derived from value and options rather than copied, so it follows label changes and options that arrive late.
  const text = query ?? labelOf(options, value);
  const visible = matching(options, query ?? "");
  const enabled = visible.filter((option) => !option.disabled);
  const active = open ? enabled.find((option) => option.value === activeValue) : undefined;

  const close = () => {
    setOpen(false);
    setActiveValue(null);
    setQuery(null);
  };

  // The text is not set here: it shows the label of whatever value the parent holds after onChange.
  const commit = (option: ComboboxOption<T>) => {
    onChange(option.value);
    setOpen(false);
    setActiveValue(null);
    setQuery(null);
  };

  const handleInput = (event: ChangeEvent<HTMLInputElement>) => {
    const next = event.target.value;
    setQuery(next);
    setOpen(true);
    if (next === "" && value !== null) {
      setPendingClear(true);
      onChange(null);
    }
    const nextEnabled = matching(options, next).filter((option) => !option.disabled);
    if (activeValue !== null && !nextEnabled.some((option) => option.value === activeValue)) {
      setActiveValue(nextEnabled[0]?.value ?? null);
    }
  };

  const handleKeyDown = (event: KeyboardEvent<HTMLInputElement>) => {
    switch (event.key) {
      case "ArrowDown": {
        event.preventDefault();
        if (!open) {
          // Opening activates the selected option, or the first enabled one.
          setOpen(true);
          setActiveValue((enabled.find((option) => option.value === value) ?? enabled[0])?.value ?? null);
          return;
        }
        const index = enabled.findIndex((option) => option.value === activeValue);
        setActiveValue(enabled[index === -1 ? 0 : (index + 1) % enabled.length]?.value ?? null);
        return;
      }
      case "ArrowUp": {
        event.preventDefault();
        if (!open) {
          setOpen(true);
          setActiveValue(enabled[enabled.length - 1]?.value ?? null);
          return;
        }
        const index = enabled.findIndex((option) => option.value === activeValue);
        setActiveValue(
          enabled[index === -1 ? enabled.length - 1 : (index - 1 + enabled.length) % enabled.length]?.value ?? null,
        );
        return;
      }
      case "Enter":
        if (active) {
          event.preventDefault();
          commit(active);
        }
        return;
      case "Escape":
        if (open) {
          // Stop here so an enclosing Dialog does not also close.
          event.preventDefault();
          event.stopPropagation();
          close();
        }
        return;
    }
  };

  return (
    <div {...rest}>
      <label id={labelId} htmlFor={inputId}>
        {label}
      </label>
      <input
        id={inputId}
        type="text"
        role="combobox"
        autoComplete="off"
        aria-autocomplete="list"
        aria-expanded={open}
        aria-controls={open ? listboxId : undefined}
        aria-activedescendant={active ? optionId(active.value) : undefined}
        placeholder={placeholder}
        value={text}
        onChange={handleInput}
        onKeyDown={handleKeyDown}
        onBlur={close}
      />
      {open && (
        <>
          <ul id={listboxId} role="listbox" aria-labelledby={labelId}>
            {visible.map((option) => (
              <li
                key={String(option.value)}
                id={optionId(option.value)}
                role="option"
                aria-selected={option.value === value}
                aria-disabled={option.disabled || undefined}
                // Keeps focus in the input when an option is pressed.
                onMouseDown={(event) => event.preventDefault()}
                onClick={() => {
                  if (!option.disabled) commit(option);
                }}
              >
                {option.label}
              </li>
            ))}
          </ul>
          {visible.length === 0 && <div role="status">No results</div>}
        </>
      )}
    </div>
  );
}

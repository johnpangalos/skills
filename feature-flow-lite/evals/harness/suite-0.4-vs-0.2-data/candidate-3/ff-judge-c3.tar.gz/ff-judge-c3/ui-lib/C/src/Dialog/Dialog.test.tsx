import { StrictMode, useState, type ReactNode } from "react";
import { render, screen } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { describe, expect, it, vi } from "vitest";
import { Combobox } from "../Combobox/Combobox";
import { Tab, TabList, TabPanel, Tabs } from "../Tabs/Tabs";
import { Dialog } from "./Dialog";

const backdropOf = () => document.querySelector<HTMLElement>("[data-dialog-backdrop]");

// Opener button outside the dialog; dialog content is one "Save" button by default.
function Harness({
  onOpenChange,
  description,
  children = <button>Save</button>,
}: {
  onOpenChange?: (open: boolean) => void;
  description?: ReactNode;
  children?: ReactNode;
}) {
  const [open, setOpen] = useState(false);
  return (
    <>
      <button onClick={() => setOpen(true)}>Open dialog</button>
      <Dialog
        open={open}
        onOpenChange={(next) => {
          onOpenChange?.(next);
          setOpen(next);
        }}
        title="Settings"
        description={description}
      >
        {children}
      </Dialog>
    </>
  );
}

describe("Dialog rendering (D1)", () => {
  it("renders nothing when closed", () => {
    render(
      <Dialog open={false} onOpenChange={() => {}} title="Settings">
        body text
      </Dialog>,
    );
    expect(screen.queryByRole("dialog", { hidden: true })).toBeNull();
    expect(backdropOf()).toBeNull();
    expect(screen.queryByText("body text")).toBeNull();
  });

  it("portals a backdrop and a modal dialog into document.body", () => {
    const { container } = render(
      <Dialog open onOpenChange={() => {}} title="Settings">
        body text
      </Dialog>,
    );
    const dialog = screen.getByRole("dialog", { name: "Settings" });
    expect(dialog).toHaveAttribute("aria-modal", "true");
    expect(dialog.parentElement).toBe(document.body);
    expect(container).not.toContainElement(dialog);
    expect(backdropOf()).toBeInTheDocument();
  });

  it("is named by its title and described by its description", () => {
    render(
      <Dialog open onOpenChange={() => {}} title="Delete file" description="This cannot be undone.">
        body text
      </Dialog>,
    );
    const dialog = screen.getByRole("dialog");
    expect(dialog).toHaveAccessibleName("Delete file");
    expect(dialog).toHaveAccessibleDescription("This cannot be undone.");
  });

  it("sets no aria-describedby when description is omitted", () => {
    render(
      <Dialog open onOpenChange={() => {}} title="Settings">
        body text
      </Dialog>,
    );
    expect(screen.getByRole("dialog")).not.toHaveAttribute("aria-describedby");
  });

  it("accepts a ReactNode title", () => {
    render(
      <Dialog open onOpenChange={() => {}} title={<span>Hello <b>you</b></span>}>
        body text
      </Dialog>,
    );
    expect(screen.getByRole("dialog")).toHaveAccessibleName("Hello you");
  });

  it("forwards className, style and data attributes to the dialog element", () => {
    render(
      <Dialog open onOpenChange={() => {}} title="Settings" className="sheet" data-kind="modal" style={{ color: "red" }}>
        body text
      </Dialog>,
    );
    const dialog = screen.getByRole("dialog");
    expect(dialog).toHaveClass("sheet");
    expect(dialog).toHaveAttribute("data-kind", "modal");
    expect(dialog.style.color).toBe("red");
  });
});

describe("Dialog initial focus (D2)", () => {
  it("focuses the first tabbable element in the dialog", () => {
    render(
      <Dialog open onOpenChange={() => {}} title="Settings">
        <button>First</button>
        <button>Second</button>
      </Dialog>,
    );
    expect(screen.getByRole("button", { name: "First" })).toHaveFocus();
  });

  it("focuses the dialog itself when nothing inside is tabbable", () => {
    render(
      <Dialog open onOpenChange={() => {}} title="Settings">
        <p>just text</p>
      </Dialog>,
    );
    const dialog = screen.getByRole("dialog");
    expect(dialog).toHaveAttribute("tabindex", "-1");
    expect(dialog).toHaveFocus();
  });

  it("keeps focus on a child that uses autoFocus", () => {
    render(
      <Dialog open onOpenChange={() => {}} title="Settings">
        <button>First</button>
        <input aria-label="Name" autoFocus />
      </Dialog>,
    );
    expect(screen.getByRole("textbox", { name: "Name" })).toHaveFocus();
  });
});

describe("Dialog focus trap (D3)", () => {
  it("wraps Tab from the last tabbable element to the first", async () => {
    const user = userEvent.setup();
    render(
      <Dialog open onOpenChange={() => {}} title="Settings">
        <button>A</button>
        <button>B</button>
      </Dialog>,
    );
    await user.click(screen.getByRole("button", { name: "B" }));
    await user.tab();
    expect(screen.getByRole("button", { name: "A" })).toHaveFocus();
  });

  it("wraps Shift+Tab from the first tabbable element to the last", async () => {
    const user = userEvent.setup();
    render(
      <Dialog open onOpenChange={() => {}} title="Settings">
        <button>A</button>
        <button>B</button>
      </Dialog>,
    );
    expect(screen.getByRole("button", { name: "A" })).toHaveFocus();
    await user.tab({ shift: true });
    expect(screen.getByRole("button", { name: "B" })).toHaveFocus();
  });

  it("keeps focus on the dialog when there is nothing tabbable", async () => {
    const user = userEvent.setup();
    render(
      <Dialog open onOpenChange={() => {}} title="Settings">
        <p>just text</p>
      </Dialog>,
    );
    await user.tab();
    expect(screen.getByRole("dialog")).toHaveFocus();
    await user.tab({ shift: true });
    expect(screen.getByRole("dialog")).toHaveFocus();
  });

  it("never reaches disabled, tabIndex -1 or hidden content", async () => {
    const user = userEvent.setup();
    render(
      <Dialog open onOpenChange={() => {}} title="Settings">
        <button>A</button>
        <button disabled>Off</button>
        <button tabIndex={-1}>Negative</button>
        <div hidden>
          <button>Hidden</button>
        </div>
        <button>B</button>
      </Dialog>,
    );
    const seen: string[] = [];
    for (let press = 0; press < 6; press++) {
      await user.tab();
      seen.push(document.activeElement?.textContent ?? "");
    }
    expect(seen).toEqual(["B", "A", "B", "A", "B", "A"]);
  });

  it("never reaches inert content", async () => {
    const user = userEvent.setup();
    render(
      <Dialog open onOpenChange={() => {}} title="Settings">
        <button>A</button>
        <div inert>
          <button>Inert</button>
        </div>
        <button>B</button>
      </Dialog>,
    );
    const seen: string[] = [];
    for (let press = 0; press < 4; press++) {
      await user.tab();
      seen.push(document.activeElement?.textContent ?? "");
    }
    expect(seen).toEqual(["B", "A", "B", "A"]);
  });

  it("skips hidden tab panels and unselected tabs when Tabs sit inside the dialog", async () => {
    const user = userEvent.setup();
    render(
      <Dialog open onOpenChange={() => {}} title="Options">
        <Tabs defaultValue="one">
          <TabList aria-label="Sections">
            <Tab value="one">one</Tab>
            <Tab value="two">two</Tab>
          </TabList>
          <TabPanel value="one">
            <button>Inside one</button>
          </TabPanel>
          <TabPanel value="two">
            <button>Inside two</button>
          </TabPanel>
        </Tabs>
        <button>Done</button>
      </Dialog>,
    );
    const seen = new Set<string>();
    for (let press = 0; press < 8; press++) {
      await user.tab();
      seen.add(document.activeElement?.textContent ?? "");
    }
    expect([...seen].sort()).toEqual(["Done", "Inside one", "one"]);
  });

  it("includes elements added after the dialog opened", async () => {
    const user = userEvent.setup();
    const content = (extra: boolean) => (
      <Dialog open onOpenChange={() => {}} title="Settings">
        <button>A</button>
        <button>B</button>
        {extra && <button>Late</button>}
      </Dialog>
    );
    const { rerender } = render(content(false));
    await user.click(screen.getByRole("button", { name: "B" }));
    rerender(content(true));
    await user.tab();
    expect(screen.getByRole("button", { name: "Late" })).toHaveFocus();
  });

  it("pulls focus back inside when it moves outside", async () => {
    const user = userEvent.setup();
    render(
      <>
        <button>Outside</button>
        <Dialog open onOpenChange={() => {}} title="Settings">
          <button>A</button>
        </Dialog>
      </>,
    );
    await user.click(screen.getByRole("button", { name: "Outside" }));
    expect(screen.getByRole("button", { name: "A" })).toHaveFocus();
  });
});

describe("Dialog dismissal (D4)", () => {
  it("calls onOpenChange(false) on Escape", async () => {
    const user = userEvent.setup();
    const onOpenChange = vi.fn();
    render(
      <Dialog open onOpenChange={onOpenChange} title="Settings">
        <button>A</button>
      </Dialog>,
    );
    await user.keyboard("{Escape}");
    expect(onOpenChange).toHaveBeenCalledTimes(1);
    expect(onOpenChange).toHaveBeenCalledWith(false);
  });

  it("calls onOpenChange(false) once on a click on the backdrop", async () => {
    const user = userEvent.setup();
    const onOpenChange = vi.fn();
    render(
      <Dialog open onOpenChange={onOpenChange} title="Settings">
        <button>A</button>
      </Dialog>,
    );
    await user.click(backdropOf()!);
    expect(onOpenChange).toHaveBeenCalledTimes(1);
    expect(onOpenChange).toHaveBeenCalledWith(false);
  });

  it("does not close on a click inside the dialog content", async () => {
    const user = userEvent.setup();
    const onOpenChange = vi.fn();
    render(
      <Dialog open onOpenChange={onOpenChange} title="Settings">
        <p>body text</p>
      </Dialog>,
    );
    await user.click(screen.getByText("body text"));
    expect(onOpenChange).not.toHaveBeenCalled();
  });

  it("does not close when a press starts inside the content and ends on the backdrop", async () => {
    const user = userEvent.setup();
    const onOpenChange = vi.fn();
    render(
      <Dialog open onOpenChange={onOpenChange} title="Settings">
        <p>body text</p>
      </Dialog>,
    );
    await user.pointer([
      { keys: "[MouseLeft>]", target: screen.getByText("body text") },
      { target: backdropOf()! },
      { keys: "[/MouseLeft]" },
    ]);
    expect(onOpenChange).not.toHaveBeenCalled();
  });
});

describe("Dialog focus return (D5)", () => {
  it("returns focus to the opener when it closes", async () => {
    const user = userEvent.setup();
    render(<Harness />);
    await user.click(screen.getByRole("button", { name: "Open dialog" }));
    expect(screen.getByRole("button", { name: "Save" })).toHaveFocus();
    await user.keyboard("{Escape}");
    expect(screen.queryByRole("dialog")).toBeNull();
    expect(screen.getByRole("button", { name: "Open dialog" })).toHaveFocus();
  });

  it("returns focus to the opener even when a child uses autoFocus", async () => {
    const user = userEvent.setup();
    render(
      <Harness>
        <input aria-label="Name" autoFocus />
      </Harness>,
    );
    await user.click(screen.getByRole("button", { name: "Open dialog" }));
    expect(screen.getByRole("textbox", { name: "Name" })).toHaveFocus();
    await user.keyboard("{Escape}");
    expect(screen.getByRole("button", { name: "Open dialog" })).toHaveFocus();
  });

  it("returns focus to the opener under StrictMode with an autoFocus child", async () => {
    const user = userEvent.setup();
    render(
      <StrictMode>
        <Harness>
          <input aria-label="Name" autoFocus />
        </Harness>
      </StrictMode>,
    );
    await user.click(screen.getByRole("button", { name: "Open dialog" }));
    expect(screen.getByRole("textbox", { name: "Name" })).toHaveFocus();
    await user.keyboard("{Escape}");
    expect(screen.getByRole("button", { name: "Open dialog" })).toHaveFocus();
  });

  it("returns focus to the opener when the dialog unmounts while open", async () => {
    const user = userEvent.setup();
    const Host = ({ open }: { open: boolean }) => (
      <>
        <button>Opener</button>
        {open && (
          <Dialog open onOpenChange={() => {}} title="Settings">
            <button>Inside</button>
          </Dialog>
        )}
      </>
    );
    const { rerender } = render(<Host open={false} />);
    await user.click(screen.getByRole("button", { name: "Opener" }));
    rerender(<Host open />);
    expect(screen.getByRole("button", { name: "Inside" })).toHaveFocus();
    rerender(<Host open={false} />);
    expect(screen.getByRole("button", { name: "Opener" })).toHaveFocus();
  });

  it("returns focus to an opener inside a shadow root", () => {
    const host = document.createElement("div");
    document.body.appendChild(host);
    const shadow = host.attachShadow({ mode: "open" });
    const opener = document.createElement("button");
    opener.textContent = "Shadow opener";
    shadow.appendChild(opener);

    const Controlled = ({ open }: { open: boolean }) => (
      <Dialog open={open} onOpenChange={() => {}} title="Settings">
        <button>Save</button>
      </Dialog>
    );
    const { rerender } = render(<Controlled open={false} />);
    opener.focus();
    expect(shadow.activeElement).toBe(opener);
    rerender(<Controlled open />);
    expect(screen.getByRole("button", { name: "Save" })).toHaveFocus();
    rerender(<Controlled open={false} />);
    expect(shadow.activeElement).toBe(opener);
    host.remove();
  });

  it("does not throw when the opener was removed while the dialog was open", () => {
    const Host = ({ showOpener, open }: { showOpener: boolean; open: boolean }) => (
      <>
        {showOpener && <button>Opener</button>}
        <Dialog open={open} onOpenChange={() => {}} title="Settings">
          <button>Inside</button>
        </Dialog>
      </>
    );
    const { rerender } = render(<Host showOpener open={false} />);
    screen.getByRole("button", { name: "Opener" }).focus();
    rerender(<Host showOpener open />);
    rerender(<Host showOpener={false} open />);
    expect(() => rerender(<Host showOpener={false} open={false} />)).not.toThrow();
    expect(screen.queryByRole("dialog")).toBeNull();
  });

  describe("nested dialogs", () => {
    function Nested({ onOuter, onInner }: { onOuter: (open: boolean) => void; onInner: (open: boolean) => void }) {
      const [outer, setOuter] = useState(false);
      const [inner, setInner] = useState(false);
      return (
        <>
          <button onClick={() => setOuter(true)}>Open outer</button>
          <Dialog
            open={outer}
            onOpenChange={(next) => {
              onOuter(next);
              setOuter(next);
            }}
            title="Outer"
          >
            <button onClick={() => setInner(true)}>Open inner</button>
            <Dialog
              open={inner}
              onOpenChange={(next) => {
                onInner(next);
                setInner(next);
              }}
              title="Inner"
            >
              <button>Inner first</button>
              <button>Inner second</button>
            </Dialog>
          </Dialog>
        </>
      );
    }

    it("Escape closes only the inner dialog", async () => {
      const user = userEvent.setup();
      const onOuter = vi.fn();
      const onInner = vi.fn();
      render(<Nested onOuter={onOuter} onInner={onInner} />);
      await user.click(screen.getByRole("button", { name: "Open outer" }));
      await user.click(screen.getByRole("button", { name: "Open inner" }));
      expect(screen.getByRole("button", { name: "Inner first" })).toHaveFocus();
      await user.keyboard("{Escape}");
      expect(onInner).toHaveBeenCalledTimes(1);
      expect(onInner).toHaveBeenCalledWith(false);
      expect(onOuter).not.toHaveBeenCalled();
      expect(screen.getByRole("dialog", { name: "Outer" })).toBeInTheDocument();
      expect(screen.queryByRole("dialog", { name: "Inner" })).toBeNull();
    });

    it("the inner dialog owns the trap while it is open", async () => {
      const user = userEvent.setup();
      render(<Nested onOuter={() => {}} onInner={() => {}} />);
      await user.click(screen.getByRole("button", { name: "Open outer" }));
      await user.click(screen.getByRole("button", { name: "Open inner" }));
      const inner = screen.getByRole("dialog", { name: "Inner" });
      await user.click(screen.getByRole("button", { name: "Inner second" }));
      await user.tab();
      expect(screen.getByRole("button", { name: "Inner first" })).toHaveFocus();
      await user.tab({ shift: true });
      expect(screen.getByRole("button", { name: "Inner second" })).toHaveFocus();
      expect(inner).toContainElement(document.activeElement as HTMLElement);
    });

    it("returns focus into the outer dialog when the inner one closes", async () => {
      const user = userEvent.setup();
      render(<Nested onOuter={() => {}} onInner={() => {}} />);
      await user.click(screen.getByRole("button", { name: "Open outer" }));
      await user.click(screen.getByRole("button", { name: "Open inner" }));
      await user.keyboard("{Escape}");
      expect(screen.getByRole("button", { name: "Open inner" })).toHaveFocus();
    });
  });

  it("Escape inside an open combobox closes the list, not the dialog", async () => {
    const user = userEvent.setup();
    const onOpenChange = vi.fn();
    render(
      <Dialog open onOpenChange={onOpenChange} title="Pick">
        <Combobox label="Fruit" options={[{ value: "apple", label: "Apple" }]} value={null} onChange={() => {}} />
      </Dialog>,
    );
    await user.type(screen.getByRole("combobox", { name: "Fruit" }), "a");
    expect(screen.getByRole("listbox")).toBeInTheDocument();
    await user.keyboard("{Escape}");
    expect(screen.queryByRole("listbox")).toBeNull();
    expect(onOpenChange).not.toHaveBeenCalled();
    await user.keyboard("{Escape}");
    expect(onOpenChange).toHaveBeenCalledWith(false);
  });
});

describe("Dialog controlled behaviour (D6)", () => {
  it("stays open when the parent keeps open true after onOpenChange(false)", async () => {
    const user = userEvent.setup();
    const onOpenChange = vi.fn();
    render(
      <Dialog open onOpenChange={onOpenChange} title="Settings">
        <button>A</button>
      </Dialog>,
    );
    await user.keyboard("{Escape}");
    await user.click(backdropOf()!);
    expect(onOpenChange).toHaveBeenCalledTimes(2);
    expect(screen.getByRole("dialog")).toBeInTheDocument();
  });
});

describe("Dialog document side effects (D7)", () => {
  it("does not change attributes on the document, html or body", () => {
    const attributes = (element: Element) =>
      element.getAttributeNames().map((name) => `${name}=${element.getAttribute(name)}`);
    const before = [attributes(document.documentElement), attributes(document.body)];
    render(
      <Dialog open onOpenChange={() => {}} title="Settings">
        <button>A</button>
      </Dialog>,
    );
    expect([attributes(document.documentElement), attributes(document.body)]).toEqual(before);
  });
});

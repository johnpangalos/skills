import { useState, type ReactNode } from "react";
import { render, screen } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { describe, expect, it, vi } from "vitest";
import { Dialog, Tab, TabList, TabPanel, Tabs } from "../src/index";

const backdrop = () => document.querySelector<HTMLElement>("[data-backdrop]") as HTMLElement;

// A parent that owns `open`, the way a real page would.
function Page({
  onOpenChange,
  children,
  description,
}: {
  onOpenChange?: (open: boolean) => void;
  children?: ReactNode;
  description?: string;
}) {
  const [open, setOpen] = useState(false);
  return (
    <>
      <button type="button" onClick={() => setOpen(true)}>
        Open
      </button>
      <Dialog
        open={open}
        onOpenChange={(next) => {
          onOpenChange?.(next);
          setOpen(next);
        }}
        title="Confirm"
        description={description}
      >
        {children ?? (
          <>
            <button type="button">Yes</button>
            <button type="button">No</button>
          </>
        )}
      </Dialog>
    </>
  );
}

// Two stacked dialogs: the inner one is opened from a button inside the outer one.
function Nested({ onOuterChange, onInnerChange }: { onOuterChange: (open: boolean) => void; onInnerChange: (open: boolean) => void }) {
  const [outer, setOuter] = useState(true);
  const [inner, setInner] = useState(false);
  return (
    <>
      <Dialog
        open={outer}
        onOpenChange={(next) => {
          onOuterChange(next);
          setOuter(next);
        }}
        title="Outer"
      >
        <button type="button" onClick={() => setInner(true)}>
          Open inner
        </button>
        <Dialog
          open={inner}
          onOpenChange={(next) => {
            onInnerChange(next);
            setInner(next);
          }}
          title="Inner"
        >
          <button type="button">Inner action</button>
        </Dialog>
        <button type="button">Outer action</button>
      </Dialog>
    </>
  );
}

describe("Dialog", () => {
  describe("rendering (D1)", () => {
    it("renders nothing when open is false", () => {
      render(
        <Dialog open={false} onOpenChange={() => {}} title="Confirm">
          <button type="button">Yes</button>
        </Dialog>,
      );
      expect(screen.queryByRole("dialog")).toBeNull();
      expect(document.querySelector("[data-backdrop]")).toBeNull();
    });

    it("renders a backdrop and a modal role=dialog into document.body via a portal", () => {
      const { container } = render(
        <Dialog open onOpenChange={() => {}} title="Confirm" description="Are you sure?">
          <button type="button">Yes</button>
        </Dialog>,
      );
      const dialog = screen.getByRole("dialog", { name: "Confirm" });
      expect(dialog).toHaveAttribute("aria-modal", "true");
      expect(backdrop()).not.toBeNull();
      expect(container.contains(dialog)).toBe(false);
      expect(document.body.contains(dialog)).toBe(true);
    });

    it("wires aria-labelledby to the title heading and aria-describedby to the description", () => {
      render(
        <Dialog open onOpenChange={() => {}} title="Confirm" description="Are you sure?">
          <button type="button">Yes</button>
        </Dialog>,
      );
      const dialog = screen.getByRole("dialog");
      expect(dialog.getAttribute("aria-labelledby")).toBe(screen.getByRole("heading", { name: "Confirm" }).id);
      expect(dialog).toHaveAccessibleDescription("Are you sure?");
    });

    it("omits aria-describedby when there is no description", () => {
      render(
        <Dialog open onOpenChange={() => {}} title="Confirm">
          <button type="button">Yes</button>
        </Dialog>,
      );
      expect(screen.getByRole("dialog")).not.toHaveAttribute("aria-describedby");
    });
  });

  describe("initial focus (D2)", () => {
    it("moves focus to the first focusable element inside the dialog", () => {
      render(
        <Dialog open onOpenChange={() => {}} title="Confirm">
          <button type="button">Yes</button>
          <button type="button">No</button>
        </Dialog>,
      );
      expect(screen.getByRole("button", { name: "Yes" })).toHaveFocus();
    });

    it("focuses the dialog container when there is nothing focusable", () => {
      render(
        <Dialog open onOpenChange={() => {}} title="Confirm">
          <p>Just text</p>
        </Dialog>,
      );
      expect(screen.getByRole("dialog")).toHaveFocus();
      expect(screen.getByRole("dialog")).toHaveAttribute("tabindex", "-1");
    });

    it("keeps focus on a child that has autoFocus", () => {
      render(
        <Dialog open onOpenChange={() => {}} title="Confirm">
          <input aria-label="Name" autoFocus />
          <button type="button">Yes</button>
        </Dialog>,
      );
      expect(screen.getByRole("textbox", { name: "Name" })).toHaveFocus();
    });
  });

  describe("focus trap (D3)", () => {
    it("Tab from the last focusable wraps to the first, and Shift+Tab from the first wraps to the last", async () => {
      const user = userEvent.setup();
      render(
        <Dialog open onOpenChange={() => {}} title="Confirm">
          <button type="button">a</button>
          <button type="button">b</button>
          <button type="button">c</button>
        </Dialog>,
      );
      await user.keyboard("{Tab}");
      expect(screen.getByRole("button", { name: "b" })).toHaveFocus();
      await user.keyboard("{Tab}{Tab}");
      expect(screen.getByRole("button", { name: "a" })).toHaveFocus();
      await user.keyboard("{Shift>}{Tab}{/Shift}");
      expect(screen.getByRole("button", { name: "c" })).toHaveFocus();
    });

    it("keeps focus on the dialog when there are no focusable children", async () => {
      const user = userEvent.setup();
      render(
        <Dialog open onOpenChange={() => {}} title="Confirm">
          <p>Just text</p>
        </Dialog>,
      );
      await user.keyboard("{Tab}");
      expect(screen.getByRole("dialog")).toHaveFocus();
      await user.keyboard("{Shift>}{Tab}{/Shift}");
      expect(screen.getByRole("dialog")).toHaveFocus();
    });

    it("never reaches disabled, hidden, inert or tabIndex=-1 content", async () => {
      const user = userEvent.setup();
      render(
        <Dialog open onOpenChange={() => {}} title="Confirm">
          <button type="button">first</button>
          <button type="button" disabled>
            disabled
          </button>
          <div hidden>
            <button type="button">hidden</button>
          </div>
          <button type="button" tabIndex={-1}>
            skipped
          </button>
          <div inert>
            <button type="button">inert</button>
          </div>
          <button type="button">last</button>
        </Dialog>,
      );
      expect(screen.getByRole("button", { name: "first" })).toHaveFocus();
      await user.keyboard("{Shift>}{Tab}{/Shift}");
      expect(screen.getByRole("button", { name: "last" })).toHaveFocus();
      await user.keyboard("{Tab}");
      expect(screen.getByRole("button", { name: "first" })).toHaveFocus();
    });

    it("never reaches the hidden panels of a Tabs inside the dialog", async () => {
      const user = userEvent.setup();
      render(
        <Dialog open onOpenChange={() => {}} title="Confirm">
          <Tabs defaultValue="a">
            <TabList aria-label="Sections">
              <Tab value="a">a</Tab>
              <Tab value="b">b</Tab>
            </TabList>
            <TabPanel value="a">
              <button type="button">in a</button>
            </TabPanel>
            <TabPanel value="b">
              <button type="button">in b</button>
            </TabPanel>
          </Tabs>
        </Dialog>,
      );
      const seen = new Set<string>();
      for (let i = 0; i < 6; i++) {
        await user.keyboard("{Tab}");
        seen.add(document.activeElement?.textContent ?? "");
      }
      expect([...seen].sort()).toEqual(["a", "in a"]);
    });

    it("includes elements added after the dialog opened", async () => {
      const user = userEvent.setup();
      const { rerender } = render(
        <Dialog open onOpenChange={() => {}} title="Confirm">
          <button type="button">first</button>
          <button type="button">last</button>
        </Dialog>,
      );
      screen.getByRole("button", { name: "last" }).focus();
      rerender(
        <Dialog open onOpenChange={() => {}} title="Confirm">
          <button type="button">first</button>
          <button type="button">last</button>
          <button type="button">added</button>
        </Dialog>,
      );
      await user.keyboard("{Tab}");
      expect(screen.getByRole("button", { name: "added" })).toHaveFocus();
      await user.keyboard("{Tab}");
      expect(screen.getByRole("button", { name: "first" })).toHaveFocus();
    });
  });

  describe("dismissal (D4)", () => {
    it("calls onOpenChange(false) on Escape", async () => {
      const user = userEvent.setup();
      const onOpenChange = vi.fn();
      render(
        <Dialog open onOpenChange={onOpenChange} title="Confirm">
          <button type="button">Yes</button>
        </Dialog>,
      );
      await user.keyboard("{Escape}");
      expect(onOpenChange).toHaveBeenCalledTimes(1);
      expect(onOpenChange).toHaveBeenCalledWith(false);
    });

    it("does not close on clicks inside the dialog content", async () => {
      const user = userEvent.setup();
      const onOpenChange = vi.fn();
      render(
        <Dialog open onOpenChange={onOpenChange} title="Confirm">
          <p>Body text</p>
        </Dialog>,
      );
      await user.click(screen.getByText("Body text"));
      await user.click(screen.getByRole("heading", { name: "Confirm" }));
      expect(onOpenChange).not.toHaveBeenCalled();
    });

    it("calls onOpenChange(false) on a mousedown and click on the backdrop", async () => {
      const user = userEvent.setup();
      const onOpenChange = vi.fn();
      render(
        <Dialog open onOpenChange={onOpenChange} title="Confirm">
          <button type="button">Yes</button>
        </Dialog>,
      );
      await user.click(backdrop());
      expect(onOpenChange).toHaveBeenCalledWith(false);
    });

    it("does not close when a drag starts inside the content and ends on the backdrop", async () => {
      const user = userEvent.setup();
      const onOpenChange = vi.fn();
      render(
        <Dialog open onOpenChange={onOpenChange} title="Confirm">
          <button type="button">Yes</button>
        </Dialog>,
      );
      await user.pointer([
        { keys: "[MouseLeft>]", target: screen.getByRole("button", { name: "Yes" }) },
        { target: backdrop() },
        { keys: "[/MouseLeft]", target: backdrop() },
      ]);
      expect(onOpenChange).not.toHaveBeenCalled();
    });
  });

  describe("focus return (D5)", () => {
    it("returns focus to the trigger when closed with Escape", async () => {
      const user = userEvent.setup();
      render(<Page />);
      await user.click(screen.getByRole("button", { name: "Open" }));
      expect(screen.getByRole("button", { name: "Yes" })).toHaveFocus();
      await user.keyboard("{Escape}");
      expect(screen.getByRole("button", { name: "Open" })).toHaveFocus();
    });

    it("returns focus to the trigger even when a child uses autoFocus", async () => {
      const user = userEvent.setup();
      render(
        <Page>
          <input aria-label="Name" autoFocus />
        </Page>,
      );
      await user.click(screen.getByRole("button", { name: "Open" }));
      expect(screen.getByRole("textbox", { name: "Name" })).toHaveFocus();
      await user.keyboard("{Escape}");
      expect(screen.getByRole("button", { name: "Open" })).toHaveFocus();
    });

    it("returns focus when open goes false from the parent, not only on Escape", () => {
      const trigger = (
        <button type="button">Trigger</button>
      );
      const { rerender } = render(
        <>
          {trigger}
          <Dialog open={false} onOpenChange={() => {}} title="Confirm">
            <button type="button">Yes</button>
          </Dialog>
        </>,
      );
      screen.getByRole("button", { name: "Trigger" }).focus();
      rerender(
        <>
          {trigger}
          <Dialog open onOpenChange={() => {}} title="Confirm">
            <button type="button">Yes</button>
          </Dialog>
        </>,
      );
      expect(screen.getByRole("button", { name: "Yes" })).toHaveFocus();
      rerender(
        <>
          {trigger}
          <Dialog open={false} onOpenChange={() => {}} title="Confirm">
            <button type="button">Yes</button>
          </Dialog>
        </>,
      );
      expect(screen.getByRole("button", { name: "Trigger" })).toHaveFocus();
    });

    it("closes without error when the trigger was removed while open", () => {
      const view = (open: boolean, showTrigger: boolean) => (
        <>
          {showTrigger && <button type="button">Trigger</button>}
          <Dialog open={open} onOpenChange={() => {}} title="Confirm">
            <button type="button">Yes</button>
          </Dialog>
        </>
      );
      const { rerender } = render(view(false, true));
      screen.getByRole("button", { name: "Trigger" }).focus();
      rerender(view(true, true));
      rerender(view(true, false));
      expect(() => rerender(view(false, false))).not.toThrow();
      expect(screen.queryByRole("dialog")).toBeNull();
      expect(document.activeElement).toBe(document.body);
    });
  });

  describe("controlled only (D6)", () => {
    it("never closes itself: it reports Escape and stays open until the parent changes open", async () => {
      const user = userEvent.setup();
      const onOpenChange = vi.fn();
      render(
        <Dialog open onOpenChange={onOpenChange} title="Confirm">
          <button type="button">Yes</button>
        </Dialog>,
      );
      await user.keyboard("{Escape}");
      expect(onOpenChange).toHaveBeenCalledWith(false);
      expect(screen.getByRole("dialog")).toBeInTheDocument();
    });

    it("opens on first render with no previous focus to return to, without error", async () => {
      const user = userEvent.setup();
      const onOpenChange = vi.fn();
      const { unmount } = render(
        <Dialog open onOpenChange={onOpenChange} title="Confirm">
          <button type="button">Yes</button>
        </Dialog>,
      );
      expect(screen.getByRole("button", { name: "Yes" })).toHaveFocus();
      await user.keyboard("{Escape}");
      expect(onOpenChange).toHaveBeenCalledWith(false);
      expect(() => unmount()).not.toThrow();
    });
  });

  describe("nesting and composition", () => {
    it("Escape closes only the inner dialog and returns focus to its trigger in the outer dialog", async () => {
      const user = userEvent.setup();
      const onOuterChange = vi.fn();
      const onInnerChange = vi.fn();
      render(<Nested onOuterChange={onOuterChange} onInnerChange={onInnerChange} />);
      await user.click(screen.getByRole("button", { name: "Open inner" }));
      expect(screen.getByRole("button", { name: "Inner action" })).toHaveFocus();
      await user.keyboard("{Escape}");
      expect(onInnerChange).toHaveBeenCalledTimes(1);
      expect(onInnerChange).toHaveBeenCalledWith(false);
      expect(onOuterChange).not.toHaveBeenCalled();
      expect(screen.queryByRole("heading", { name: "Inner" })).toBeNull();
      expect(screen.getByRole("dialog", { name: "Outer" })).toBeInTheDocument();
      expect(screen.getByRole("button", { name: "Open inner" })).toHaveFocus();
    });

    it("the inner trap keeps Tab inside the inner dialog, and the outer trap still works after it closes", async () => {
      const user = userEvent.setup();
      render(<Nested onOuterChange={() => {}} onInnerChange={() => {}} />);
      await user.click(screen.getByRole("button", { name: "Open inner" }));
      await user.keyboard("{Tab}");
      expect(screen.getByRole("button", { name: "Inner action" })).toHaveFocus();
      await user.keyboard("{Escape}");
      await user.keyboard("{Tab}");
      expect(screen.getByRole("button", { name: "Outer action" })).toHaveFocus();
      await user.keyboard("{Tab}");
      expect(screen.getByRole("button", { name: "Open inner" })).toHaveFocus();
    });

    it("Escape with the inner dialog closed closes the outer dialog", async () => {
      const user = userEvent.setup();
      const onOuterChange = vi.fn();
      render(<Nested onOuterChange={onOuterChange} onInnerChange={() => {}} />);
      await user.keyboard("{Escape}");
      expect(onOuterChange).toHaveBeenCalledWith(false);
    });
  });

  describe("ids and props (G2, G3)", () => {
    it("gives two dialogs on one page unique ids", () => {
      render(
        <>
          <Dialog open onOpenChange={() => {}} title="One" description="d1">
            <button type="button">a</button>
          </Dialog>
          <Dialog open onOpenChange={() => {}} title="Two" description="d2">
            <button type="button">b</button>
          </Dialog>
        </>,
      );
      const ids = Array.from(document.querySelectorAll("[id]")).map((el) => el.id);
      expect(ids.length).toBeGreaterThan(0);
      expect(new Set(ids).size).toBe(ids.length);
      const dialogs = screen.getAllByRole("dialog");
      expect(dialogs[0].getAttribute("aria-labelledby")).not.toBe(dialogs[1].getAttribute("aria-labelledby"));
    });

    it("forwards className to the dialog element", () => {
      render(
        <Dialog open onOpenChange={() => {}} title="Confirm" className="my-dialog">
          <button type="button">Yes</button>
        </Dialog>,
      );
      expect(screen.getByRole("dialog")).toHaveClass("my-dialog");
    });
  });

  describe("backdrop press, release and click (D7)", () => {
    it("does not close when the press starts on the backdrop and the release lands in the content", async () => {
      const user = userEvent.setup();
      const onOpenChange = vi.fn();
      render(
        <Dialog open onOpenChange={onOpenChange} title="Confirm">
          <button type="button">Yes</button>
        </Dialog>,
      );
      await user.pointer([
        { keys: "[MouseLeft>]", target: backdrop() },
        { target: screen.getByRole("button", { name: "Yes" }) },
        { keys: "[/MouseLeft]", target: screen.getByRole("button", { name: "Yes" }) },
      ]);
      expect(onOpenChange).not.toHaveBeenCalled();
    });

    it("still closes when the press and the release both land on the backdrop", async () => {
      const user = userEvent.setup();
      const onOpenChange = vi.fn();
      render(
        <Dialog open onOpenChange={onOpenChange} title="Confirm">
          <button type="button">Yes</button>
        </Dialog>,
      );
      await user.pointer([
        { keys: "[MouseLeft>]", target: backdrop() },
        { keys: "[/MouseLeft]", target: backdrop() },
      ]);
      expect(onOpenChange).toHaveBeenCalledTimes(1);
      expect(onOpenChange).toHaveBeenCalledWith(false);
    });
  });

  describe("Tabs inside a dialog (D2, T4)", () => {
    it("focuses the selected tab when the dialog opens, and Tab from it moves to the selected panel", async () => {
      const user = userEvent.setup();
      render(
        <Page>
          <Tabs defaultValue="a">
            <TabList aria-label="Sections">
              <Tab value="a">A</Tab>
              <Tab value="b">B</Tab>
            </TabList>
            <TabPanel value="a">
              <button type="button">In A</button>
            </TabPanel>
            <TabPanel value="b">
              <button type="button">In B</button>
            </TabPanel>
          </Tabs>
        </Page>,
      );
      await user.click(screen.getByRole("button", { name: "Open" }));
      expect(screen.getByRole("tab", { name: "A" })).toHaveFocus();
      await user.tab();
      expect(screen.getByRole("tabpanel", { name: "A" })).toHaveFocus();
    });
  });
});

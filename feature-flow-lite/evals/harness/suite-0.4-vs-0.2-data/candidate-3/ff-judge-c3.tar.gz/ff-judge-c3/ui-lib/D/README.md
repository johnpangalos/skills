# @acme/ui

Accessible React 19 components: `Tabs`, `Dialog`, and `Combobox`. No CSS is shipped; every component accepts `className` and forwards other native props to the element it renders.

User event handlers passed as props (`onKeyDown`, `onBlur`, `onMouseDown`, and so on) run first, before the component's own logic. For key handlers, calling `event.preventDefault()` skips the built-in key handling for that event.

## Run

```sh
pnpm install
pnpm test       # vitest run
pnpm typecheck  # tsc --noEmit
```

Import from the package entry, `src/index.ts`:

```ts
import { Tabs, TabList, Tab, TabPanel, Dialog, Combobox } from "./src";
```

Ids come from `React.useId`, so several instances can share a page.

## Tabs

`Tabs` owns the selection. `TabList` renders the `tablist`, `Tab` the buttons, and `TabPanel` the panels. Non-selected panels get `hidden`.

### Tabs props

| Name | Type | Required / default | Description |
| --- | --- | --- | --- |
| `value` | `string` | optional | Selected tab. Passing it makes the component controlled. |
| `defaultValue` | `string` | optional, first enabled tab | Initial selection when uncontrolled. A missing or disabled value falls back to the first enabled tab. |
| `onValueChange` | `(value: string) => void` | optional | Called when the user selects a different tab. Not called for re-selecting the current tab or for the automatic fallback. |
| `className` | `string` | optional | Applied to the wrapper `div`. Other `div` props are forwarded. |

### TabList props

| Name | Type | Required / default | Description |
| --- | --- | --- | --- |
| `aria-label` | `string` | required | Accessible name of the tablist. |
| `className` | `string` | optional | Applied to the `role="tablist"` element. Other `div` props are forwarded. |

### Tab props

| Name | Type | Required / default | Description |
| --- | --- | --- | --- |
| `value` | `string` | required | Identifies the tab. The matching `TabPanel` uses the same value. |
| `disabled` | `boolean` | optional, `false` | Skipped by the keyboard; clicks are ignored. Rendered with `aria-disabled="true"`, so it stays discoverable. |
| `className` | `string` | optional | Applied to the button. Other button props are forwarded, except `type`. |

### TabPanel props

| Name | Type | Required / default | Description |
| --- | --- | --- | --- |
| `value` | `string` | required | The tab this panel belongs to. Hidden unless it is selected. |
| `className` | `string` | optional | Applied to the `role="tabpanel"` element. Other `div` props are forwarded. |

### Tabs keyboard

| Key | Behavior |
| --- | --- |
| `Tab` | Moves into the tablist on the selected tab, then to the selected panel. |
| `ArrowRight` / `ArrowLeft` | Focus and select the next / previous enabled tab. Wraps at the ends and skips disabled tabs. |
| `Home` / `End` | Focus and select the first / last enabled tab. |

Tab order follows the DOM order of the tabs, including tabs inserted after mount. Only the selected tab has `tabIndex=0`. If the selected tab is missing or disabled, the first enabled tab gets `tabIndex=0` instead, so the tablist stays reachable by keyboard. Uncontrolled, that tab is also selected. Controlled, `aria-selected` follows `value` even when it names a disabled tab (for example `value="three"` with `three` disabled); the tab stop still moves to the first enabled tab. A missing value (for example `value="nope"`) leaves no tab marked selected.

### Tabs example

```tsx
// Uncontrolled
<Tabs defaultValue="profile">
  <TabList aria-label="Settings">
    <Tab value="profile">Profile</Tab>
    <Tab value="billing">Billing</Tab>
  </TabList>
  <TabPanel value="profile">Profile form</TabPanel>
  <TabPanel value="billing">Billing form</TabPanel>
</Tabs>

// Controlled
const [tab, setTab] = useState("profile");
<Tabs value={tab} onValueChange={setTab}>
  {/* same TabList and TabPanels */}
</Tabs>
```

## Dialog

A modal dialog rendered into `document.body`, with a backdrop. It is controlled only: the parent owns `open`.

### Dialog props

| Name | Type | Required / default | Description |
| --- | --- | --- | --- |
| `open` | `boolean` | required | Whether the dialog is shown. Renders nothing when `false`. |
| `onOpenChange` | `(open: boolean) => void` | required | Called with `false` on Escape or a backdrop click. The component never closes itself; the parent must set `open`. |
| `title` | `string` | required | Rendered as an `h2` and used as the accessible name. |
| `description` | `string` | optional | Rendered below the title and linked with `aria-describedby`. |
| `className` | `string` | optional | Applied to the `role="dialog"` element. Other `div` props are forwarded. |

Behavior:

- On open, focus moves to the first tabbable element. An element with `autoFocus` keeps focus. With no tabbable element, the dialog itself is focused.
- Focus is trapped. Tab and Shift+Tab cycle through the tabbable elements, computed at keypress time. Disabled, `hidden`, `tabIndex=-1`, `type="hidden"` inputs, and `inert` content is skipped. Focus that leaves the dialog is brought back.
- On close (or unmount while open), focus returns to the element focused before opening, if it is still in the document.
- A click counts as a backdrop click only when both the press and the release happen on the backdrop.
- Nested dialogs stack. Only the topmost handles Escape and Tab.

### Dialog keyboard

| Key | Behavior |
| --- | --- |
| `Tab` / `Shift+Tab` | Move through the dialog's tabbable elements, wrapping at both ends. |
| `Escape` | Calls `onOpenChange(false)` for the topmost dialog only. |

### Dialog example

```tsx
// Controlled (the only mode)
const [open, setOpen] = useState(false);
<button onClick={() => setOpen(true)}>Delete account</button>
<Dialog open={open} onOpenChange={setOpen} title="Delete account" description="This cannot be undone.">
  <button onClick={() => setOpen(false)}>Cancel</button>
  <button>Delete</button>
</Dialog>
```

## Combobox

A text input that filters a list of options. The component is controlled: `value` and `onChange` are required.

### Combobox props

| Name | Type | Required / default | Description |
| --- | --- | --- | --- |
| `label` | `string` | required | Visible label, associated with the input. |
| `options` | `ComboboxOption<T>[]` | required | `{ value: T; label: string; disabled?: boolean }`. `T extends string`, default `string`. |
| `value` | `T \| null` | required | Selected option value, or `null` for none. A value matching no option shows an empty input. |
| `onChange` | `(value: T \| null) => void` | required | Called when the user commits an option, or clears the selection (see below). |
| `placeholder` | `string` | optional | Forwarded to the input. |
| `className` | `string` | optional | Applied to the `role="combobox"` input. Other input props are forwarded, except `value`, `defaultValue`, `onChange`, `role`, and `type`. |

Behavior:

- Typing opens the popup and filters options by case-insensitive substring of `label`. The query is literal; regex characters match only themselves. An empty query shows every option.
- The active option is tracked by value and exposed through `aria-activedescendant`. DOM focus stays on the input. Disabled options are skipped and never selected.
- If the active option is filtered out or removed, it becomes inactive. Nothing is active until an arrow key is pressed.
- Clicking an enabled option commits it. Clicking a disabled option does nothing. Option mousedown is prevented, so the input keeps focus.
- Clearing the text and then blurring, or pressing Enter with no active option, calls `onChange(null)` once. Nothing is called if the value is already `null`.
- Blur closes the popup and reverts the text to the selected label, without `onChange` unless the text was cleared.
- The component never changes the displayed selection on its own. The displayed text follows the `value` prop.
- With the popup open, Escape stops propagation so an enclosing dialog stays open.

### Combobox keyboard

| Key | Behavior |
| --- | --- |
| `ArrowDown` / `ArrowUp` | Open the popup if closed, then move the active option to the next / previous enabled option. Wraps. |
| `Alt+ArrowDown` / `Alt+ArrowUp` | Open the popup without moving the active option. |
| `Enter` | Commit the active option. With no active option and cleared text, clear the selection (`onChange(null)`). Otherwise does nothing. |
| `Escape` | Close the popup, revert the text to the selected label, no `onChange`. When already closed, only reverts the text. |
| `Tab` (blur) | Closes the popup; see blur behavior above. |

A user `onKeyDown` runs before these rows. If it calls `preventDefault()`, none of them run for that key.

### Combobox example

```tsx
// Controlled
const [fruit, setFruit] = useState<string | null>(null);
<Combobox
  label="Fruit"
  options={[
    { value: "apple", label: "Apple" },
    { value: "banana", label: "Banana", disabled: true },
  ]}
  value={fruit}
  onChange={setFruit}
/>

// Uncontrolled use is not supported: pass `value` and `onChange` even if the value never changes.
```

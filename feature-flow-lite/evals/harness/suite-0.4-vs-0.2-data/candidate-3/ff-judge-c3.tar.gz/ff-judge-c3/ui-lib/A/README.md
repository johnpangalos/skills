# @acme/ui

Accessible React 19 components: `Tabs`, `Dialog` and `Combobox`. TypeScript, no CSS, no runtime dependencies (React and React DOM are peers). Each widget follows its WAI-ARIA Authoring Practices pattern, and every id comes from `useId`, so several instances can share a page.

```tsx
import { Tabs, TabList, Tab, TabPanel, Dialog, Combobox } from "@acme/ui";
```

Scripts: `pnpm test` runs Vitest in jsdom, and `pnpm typecheck` runs `tsc --noEmit`.

Every component passes `className` and other native props to one element. `Tabs` puts them on its wrapping `div`, `TabList` on its `role="tablist"` div, `Tab` on its button, and `TabPanel` on its `role="tabpanel"` div. `Dialog` puts them on its `role="dialog"` panel, not on the backdrop. `Combobox` puts them on its wrapping `div`.

## Tabs

`<Tabs>` holds one `<TabList>` with `<Tab>` buttons, and one `<TabPanel>` per tab value.

### Props

| Name | Type | Default | Description |
| --- | --- | --- | --- |
| `defaultValue` | `string` | first enabled tab | Initially selected value (uncontrolled). |
| `value` | `string` | none | Selected value. When set, the component is controlled and `value` wins over `defaultValue`. |
| `onValueChange` | `(value: string) => void` | none | Called with the new value when the user selects a tab. Fires in controlled and uncontrolled mode. |

`<TabList aria-label>` takes `aria-label: string` (required) and renders `role="tablist"`.

`<Tab value disabled>` takes `value: string` (required) and `disabled?: boolean` (default `false`). It renders a `<button type="button" role="tab">`. A disabled tab has `disabled` and `aria-disabled="true"`.

`<TabPanel value>` takes `value: string` (required). It renders `role="tabpanel"` with `tabIndex={0}`. Panels that are not selected get the `hidden` attribute.

### Keyboard

| Key | Action |
| --- | --- |
| `ArrowRight` / `ArrowLeft` | Move focus to the next or previous enabled tab, wrapping at the ends. Selection follows focus. |
| `Home` / `End` | Move focus to the first or last enabled tab. Selection follows focus. |
| `Tab` | From the selected tab, moves into the active panel. Only the selected tab is in the tab order. |

Click selects a tab. Disabled tabs are skipped by the keys and cannot be selected by click. Other keys are not handled and are not prevented.

If the selected value matches no enabled tab, the first enabled tab takes the tab stop, so the tab list stays reachable.

### Example

```tsx
// Uncontrolled
<Tabs defaultValue="profile">
  <TabList aria-label="Settings">
    <Tab value="profile">Profile</Tab>
    <Tab value="billing">Billing</Tab>
  </TabList>
  <TabPanel value="profile">Profile form</TabPanel>
  <TabPanel value="billing">Billing form</TabPanel>
</Tabs>

// Controlled: the UI changes only when the parent updates `value`
const [tab, setTab] = useState("profile");
<Tabs value={tab} onValueChange={setTab}>{/* same children */}</Tabs>
```

## Dialog

A modal dialog, rendered with a portal into `document.body`. Nothing is rendered while `open` is `false`.

### Props

| Name | Type | Default | Description |
| --- | --- | --- | --- |
| `open` | `boolean` | none (required) | Whether the dialog is shown. The component never changes it. |
| `onOpenChange` | `(open: boolean) => void` | none (required) | Called with `false` on Escape or a backdrop click. The parent must set `open` to close the dialog. |
| `title` | `string` | none (required) | Rendered as the `<h2>` that labels the dialog (`aria-labelledby`). |
| `description` | `string` | none | Rendered as a `<p>` that describes the dialog (`aria-describedby`). The attribute is absent when no description is given. |

The dialog renders a backdrop (`data-backdrop`) around a `role="dialog"` element with `aria-modal="true"`.

### Behavior

- On open, focus moves to the first tabbable element in the dialog, or to the dialog itself when there is none. A child with `autoFocus` keeps focus.
- Focus is trapped. Tab and Shift+Tab wrap inside the dialog. Disabled, `tabIndex={-1}`, `hidden` and `inert` elements are skipped. The list is read on each keypress, so elements added after opening count. Focus that moves outside is pulled back in.
- On close (or unmount), focus returns to the element that had it before opening, if that element is still in the document.
- Nested dialogs: only the top dialog handles Escape and the focus trap. Escape closes the inner dialog and focus returns to the element that opened it.

### Keyboard

| Key | Action |
| --- | --- |
| `Escape` | Calls `onOpenChange(false)`. Ignored if a child already called `preventDefault()` on the event. |
| `Tab` / `Shift+Tab` | Move through the tabbable elements, wrapping at both ends. |

A click on the backdrop calls `onOpenChange(false)`. The mousedown and the mouseup must both land on the backdrop itself, so a press that starts inside the dialog and is released on the backdrop does not close it, and neither does a press that starts on the backdrop and is released inside the dialog. Clicks inside the dialog never close it.

### Example

```tsx
const [open, setOpen] = useState(false);
<button onClick={() => setOpen(true)}>Delete</button>
<Dialog open={open} onOpenChange={setOpen} title="Delete file?" description="This cannot be undone.">
  <button onClick={() => setOpen(false)}>Cancel</button>
</Dialog>
```

## Combobox

A text input with a listbox popup. The component is controlled only: `value` and `onChange` are required, and there is no uncontrolled mode.

### Props

| Name | Type | Default | Description |
| --- | --- | --- | --- |
| `label` | `string` | none (required) | Text of the `<label>` for the input. |
| `options` | `ComboboxOption[]` | none (required) | The options to show. |
| `value` | `string \| null` | none (required) | The selected option's value, or `null` for no selection. An unknown value shows an empty input. |
| `onChange` | `(value: string \| null) => void` | none (required) | Called with the option's value on selection, or with `null` when the selection is cleared (see below). |
| `placeholder` | `string` | none | Placeholder for the input. |

`ComboboxOption` is `{ value: string; label: string; disabled?: boolean }`.

### Behavior

- Typing opens the popup and keeps the options whose label contains the typed text. The match ignores case and leading or trailing whitespace, and it is a plain substring match. Whitespace-only text shows all options.
- When nothing matches, the popup shows "No results" and no options.
- The active option is tracked by value. When the list changes, the active option stays the same item if it is still visible and enabled. Otherwise it moves to the first enabled visible option. When typing and nothing is active, the first enabled match becomes active. Clearing the text makes nothing active.
- Movement wraps at both ends. From no active option, `ArrowDown` goes to the first enabled option, and `ArrowUp` goes to the last.
- Clearing the text and then blurring the input, or pressing Enter with nothing active, calls `onChange(null)`. This applies only when a label was selected before, so an unknown value does not trigger it.
- Blur closes the popup and reverts the text to the selected label.
- When the parent ignores `onChange`, the input keeps showing the selected label.
- While an IME composition is in progress, keys are ignored by both `Combobox` and `Dialog`. A keydown counts as composition when `isComposing` is set or `keyCode` is 229 (Safari sends this for the Enter that confirms a composition). Enter and Escape confirm the composition, so they do not select an option, close the popup or close an enclosing dialog.

### Keyboard

| Key | Action |
| --- | --- |
| `ArrowDown` / `ArrowUp` | Open the popup if closed, and in the same press move the active option: `ArrowDown` to the next enabled option (the first when none is active), `ArrowUp` to the previous one (the last when none is active). Movement wraps at the ends. Disabled options are never active. |
| `Enter` | With an active option, calls `onChange(option.value)`, closes the popup, and shows its label. With no active option, closes the popup and calls `onChange(null)` if the text was cleared. |
| `Escape` | With the popup open, closes it without calling `onChange`, restores the selected label, and stops propagation so an enclosing dialog stays open. With the popup closed, it does nothing here. |
| Click an option | Selects an enabled option the same way as Enter. Clicking a disabled option does nothing. Focus stays in the input. |

`aria-activedescendant` on the input is the active option's id. It is absent when the popup is closed or no option is active.

### Example

```tsx
const [fruit, setFruit] = useState<string | null>(null);
<Combobox
  label="Fruit"
  placeholder="Type to search"
  options={[
    { value: "apple", label: "Apple" },
    { value: "banana", label: "Banana" },
    { value: "cherry", label: "Cherry", disabled: true },
  ]}
  value={fruit}
  onChange={setFruit}
/>
```

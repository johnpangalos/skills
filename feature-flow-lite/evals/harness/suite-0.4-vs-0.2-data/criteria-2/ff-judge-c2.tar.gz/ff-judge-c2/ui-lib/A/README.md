# @acme/ui

Accessible React 19 components (Tabs, Dialog, Combobox). They ship no CSS: style them through `className` and the `data-active` attribute on combobox options. Other HTML props pass through to the root element (for `Combobox`, to the `<input>`). Ids come from `useId()`, so several instances can share a page.

Run `pnpm test` and `pnpm typecheck`.

## Tabs

Tabs supports more than one `TabList`, and nested Tabs are independent of each other.

```tsx
import { Tabs, TabList, Tab, TabPanel } from "@acme/ui";

<Tabs defaultValue="billing">
  <TabList aria-label="Account">
    <Tab value="profile">Profile</Tab>
    <Tab value="billing">Billing</Tab>
    <Tab value="legacy" disabled>Legacy</Tab>
  </TabList>
  <TabPanel value="profile">Profile form</TabPanel>
  <TabPanel value="billing">Billing form</TabPanel>
</Tabs>;
```

| Component | Prop | Type | Required / default | Description |
| --- | --- | --- | --- | --- |
| `Tabs` | `value` | `string` | optional | Selected tab. When set, the component is controlled. |
| `Tabs` | `defaultValue` | `string` | optional; first enabled tab | Initial tab in uncontrolled mode. |
| `Tabs` | `onValueChange` | `(value: string) => void` | optional | Called on every user-driven selection change. |
| `TabList` | `aria-label` | `string` | required | Accessible name of the tablist. |
| `Tab` | `value` | `string` | required | Identifies the tab and its panel. |
| `Tab` | `disabled` | `boolean` | optional; `false` | Sets `aria-disabled="true"`; the tab cannot be selected or reached by arrows. |
| `TabPanel` | `value` | `string` | required | Panel for the tab with the same value. Unselected panels get `hidden`. |

If `defaultValue` or `value` names no enabled tab, the first enabled tab is the one reachable with Tab.

| Key / action | Behavior |
| --- | --- |
| Tab | Moves focus into the tablist to the selected tab (roving tabindex). |
| ArrowRight / ArrowLeft | Focus and select the next / previous enabled tab, wrapping at the ends. |
| Home / End | Focus and select the first / last enabled tab. |
| Click | Selects an enabled tab. |

## Dialog

```tsx
import { Dialog } from "@acme/ui";

<Dialog open={open} onOpenChange={setOpen} title="Delete project" description="This cannot be undone.">
  <button onClick={confirm}>Delete</button>
</Dialog>;
```

Renders nothing when `open` is false. When open it renders into `document.body` with a backdrop and a `role="dialog"` element.

| Prop | Type | Required / default | Description |
| --- | --- | --- | --- |
| `open` | `boolean` | required | Whether the dialog is shown. |
| `onOpenChange` | `(open: boolean) => void` | required | Called with `false` on Escape or a backdrop click. The dialog never closes itself. |
| `title` | `ReactNode` | required | Rendered in the heading that labels the dialog. |
| `description` | `ReactNode` | optional | Rendered below the title and referenced by `aria-describedby`. |
| `children` | `ReactNode` | optional | Dialog body. |
| `className` | `string` | optional | Class on the `role="dialog"` element. |
| `backdropClassName` | `string` | optional | Class on the backdrop element. |

On open, focus moves to the first tabbable element, or the dialog itself if there is none. On close (or unmount), focus returns to the element that was focused before opening, if it is still in the document.

| Key / action | Behavior |
| --- | --- |
| Tab / Shift+Tab | Cycles focus inside the dialog; wraps from last to first and first to last. |
| Escape | Calls `onOpenChange(false)`, even when focus is in a nested input. |
| Click on backdrop | Calls `onOpenChange(false)`. A press that starts inside the dialog and ends on the backdrop does not close it. |

## Combobox

```tsx
import { Combobox } from "@acme/ui";

<Combobox
  label="Fruit"
  placeholder="Type to search"
  options={[
    { value: "apple", label: "Apple" },
    { value: "pear", label: "Pear", disabled: true },
  ]}
  value={fruit}
  onChange={setFruit}
/>;
```

| Prop | Type | Required / default | Description |
| --- | --- | --- | --- |
| `label` | `string` | required | Visible label, associated with the input. |
| `options` | `ComboboxOption[]` | required | `{ value: string; label: string; disabled?: boolean }`. |
| `value` | `string \| null` | required | Selected option value, or `null`. |
| `onChange` | `(value: string \| null) => void` | required | Called when the selection changes. |
| `placeholder` | `string` | optional | Passed to the input. |
| `className` | `string` | optional | Class on the input. |

Typing filters options by case-insensitive substring. The input text shows the selected label when not being edited. Options carry `data-active` while active, and the input's `aria-activedescendant` points to them.

| Key / action | Behavior |
| --- | --- |
| Typing | Opens the listbox and filters options. |
| ArrowDown / ArrowUp | Opens the listbox if closed (the selected option is active, or the first enabled one). Otherwise moves the active option, skipping disabled options and wrapping. Focus stays on the input. |
| Enter | With an active option, selects it and closes. With empty text and a selected value, calls `onChange(null)`. Otherwise does nothing. |
| Escape | Closes the listbox without calling `onChange` and restores the input text to the selected label (or empty). Propagation stops only when the listbox was open, so an enclosing Dialog stays open. |
| Click input | Opens the listbox. |
| Click option | Selects an enabled option (disabled options are ignored). |
| Blur | Closes the listbox and restores the input text. If the text was cleared and a value was set, calls `onChange(null)`. |

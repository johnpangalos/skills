import {
  useId,
  useState,
  type ChangeEvent,
  type ComponentPropsWithoutRef,
  type FocusEvent,
  type KeyboardEvent,
  type MouseEvent,
} from "react";
import { encodeId } from "../encodeId";

export interface ComboboxOption {
  value: string;
  label: string;
  disabled?: boolean;
}

export interface ComboboxProps
  extends Omit<ComponentPropsWithoutRef<"input">, "value" | "onChange" | "role" | "type"> {
  label: string;
  options: ComboboxOption[];
  value: string | null;
  onChange: (value: string | null) => void;
}

// Wraps around at both ends; starts at the first (ArrowDown) or last (ArrowUp) enabled option when none is active.
function nextEnabled(options: ComboboxOption[], activeValue: string | null, step: 1 | -1): ComboboxOption | undefined {
  const enabled = options.filter((option) => !option.disabled);
  if (enabled.length === 0) return undefined;
  const index = enabled.findIndex((option) => option.value === activeValue);
  if (index === -1) return step === 1 ? enabled[0] : enabled[enabled.length - 1];
  return enabled[(index + step + enabled.length) % enabled.length];
}

export function Combobox({ label, options, value, onChange, className, onKeyDown, onBlur, ...rest }: ComboboxProps) {
  const baseId = useId();
  const labelId = `${baseId}-label`;
  const inputId = `${baseId}-input`;
  const listboxId = `${baseId}-listbox`;
  const optionId = (optionValue: string) => `${baseId}-option-${encodeId(optionValue)}`;

  // query is null while the input shows the selected label, and holds the typed text otherwise.
  const [open, setOpen] = useState(false);
  const [query, setQuery] = useState<string | null>(null);
  const [activeValue, setActiveValue] = useState<string | null>(null);

  const selectedLabel = options.find((option) => option.value === value)?.label ?? "";
  const needle = (query ?? "").toLowerCase();
  const visible = options.filter((option) => option.label.toLowerCase().includes(needle));
  const activeOption = open ? visible.find((option) => option.value === activeValue && !option.disabled) : undefined;

  const close = () => {
    setOpen(false);
    setQuery(null);
    setActiveValue(null);
  };

  const choose = (option: ComboboxOption) => {
    onChange(option.value);
    close();
  };

  // Blur and Enter without an active option: an emptied input clears the value.
  const dismiss = () => {
    if (query === "" && value !== null) onChange(null);
    close();
  };

  const handleChange = (event: ChangeEvent<HTMLInputElement>) => {
    setQuery(event.target.value);
    setActiveValue(null);
    setOpen(true);
  };

  const handleKeyDown = (event: KeyboardEvent<HTMLInputElement>) => {
    onKeyDown?.(event);
    if (event.key === "ArrowDown" || event.key === "ArrowUp") {
      event.preventDefault();
      setOpen(true);
      setActiveValue(nextEnabled(visible, activeValue, event.key === "ArrowDown" ? 1 : -1)?.value ?? null);
    } else if (event.key === "Enter" && open) {
      event.preventDefault();
      if (activeOption) {
        choose(activeOption);
      } else {
        dismiss();
      }
    } else if (event.key === "Escape" && open) {
      event.stopPropagation();
      close();
    }
  };

  const handleBlur = (event: FocusEvent<HTMLInputElement>) => {
    onBlur?.(event);
    dismiss();
  };

  return (
    <div>
      <label id={labelId} htmlFor={inputId}>
        {label}
      </label>
      <input
        {...rest}
        id={inputId}
        type="text"
        role="combobox"
        className={className}
        value={query ?? selectedLabel}
        onChange={handleChange}
        onKeyDown={handleKeyDown}
        onBlur={handleBlur}
        autoComplete="off"
        aria-autocomplete="list"
        aria-expanded={open}
        aria-controls={listboxId}
        aria-activedescendant={activeOption ? optionId(activeOption.value) : undefined}
      />
      <ul id={listboxId} role="listbox" aria-labelledby={labelId} hidden={!open}>
        {open && visible.length === 0 && <li role="presentation">No results</li>}
        {open &&
          visible.map((option) => (
            <li
              key={option.value}
              id={optionId(option.value)}
              role="option"
              aria-selected={option.value === value}
              aria-disabled={option.disabled ? "true" : undefined}
              data-active={option.value === activeOption?.value ? "true" : undefined}
              onMouseDown={(event: MouseEvent<HTMLLIElement>) => event.preventDefault()}
              onClick={() => {
                if (!option.disabled) choose(option);
              }}
            >
              {option.label}
            </li>
          ))}
      </ul>
    </div>
  );
}

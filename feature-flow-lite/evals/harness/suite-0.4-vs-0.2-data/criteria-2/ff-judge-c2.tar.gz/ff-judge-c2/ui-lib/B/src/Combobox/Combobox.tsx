import { useId, useState, type ChangeEvent, type KeyboardEvent } from "react";

export interface ComboboxOption {
  value: string;
  label: string;
  disabled?: boolean;
}

export interface ComboboxProps {
  label: string;
  options: ComboboxOption[];
  /** The committed value. `null` means nothing is selected. */
  value: string | null;
  onChange: (value: string | null) => void;
  placeholder?: string;
  className?: string;
}

// Index (into `options`) of the option that becomes active after moving `direction` from `from`.
// Skips disabled options and wraps. `from` null means no option is active yet.
function moveActive(
  options: ComboboxOption[],
  visible: number[],
  from: number | null,
  direction: 1 | -1,
): number | null {
  const count = visible.length;
  if (count === 0) {
    return null;
  }
  const at = from === null ? -1 : visible.indexOf(from);
  const start = at === -1 ? (direction === 1 ? -1 : count) : at;
  for (let step = 1; step <= count; step++) {
    const index = visible[(((start + direction * step) % count) + count) % count];
    if (!options[index].disabled) {
      return index;
    }
  }
  return null;
}

export function Combobox({ label, options, value, onChange, placeholder, className }: ComboboxProps) {
  const baseId = useId();
  const labelId = `${baseId}-label`;
  const inputId = `${baseId}-input`;
  const listboxId = `${baseId}-listbox`;
  const optionId = (index: number) => `${baseId}-option-${index}`;

  const selectedLabel = options.find((option) => option.value === value)?.label ?? "";
  const [text, setText] = useState(selectedLabel);
  const [syncedLabel, setSyncedLabel] = useState(selectedLabel);
  const [open, setOpen] = useState(false);
  const [active, setActive] = useState<number | null>(null);
  // What the user typed. Filtering uses this, not the shown label, so opening a selection shows all options.
  const [query, setQuery] = useState("");

  // Show the selected label only when the value or that option's label changes, so typing is not overwritten.
  if (selectedLabel !== syncedLabel) {
    setSyncedLabel(selectedLabel);
    setText(selectedLabel);
    setQuery("");
  }

  const needle = query.toLowerCase();
  const visible = options
    .map((_, index) => index)
    .filter((index) => options[index].label.toLowerCase().includes(needle));
  const activeIndex = open && active !== null && visible.includes(active) ? active : null;

  const close = () => {
    setOpen(false);
    setActive(null);
  };

  const choose = (index: number) => {
    const option = options[index];
    onChange(option.value);
    setText(option.label);
    setQuery("");
    close();
  };

  const handleChange = (event: ChangeEvent<HTMLInputElement>) => {
    const next = event.target.value;
    setText(next);
    setQuery(next);
    setOpen(true);
    setActive(null);
    if (next === "" && value !== null) {
      onChange(null);
    }
  };

  const handleBlur = () => {
    close();
    setText(selectedLabel);
    setQuery("");
  };

  const handleKeyDown = (event: KeyboardEvent<HTMLInputElement>) => {
    switch (event.key) {
      case "ArrowDown":
      case "ArrowUp":
        event.preventDefault();
        setOpen(true);
        setActive(moveActive(options, visible, activeIndex, event.key === "ArrowDown" ? 1 : -1));
        return;
      case "Enter":
        if (!open) {
          return;
        }
        event.preventDefault();
        if (activeIndex !== null) {
          choose(activeIndex);
        }
        return;
      case "Escape":
        if (!open) {
          return;
        }
        event.stopPropagation();
        close();
        return;
    }
  };

  return (
    <div className={className}>
      <label id={labelId} htmlFor={inputId}>
        {label}
      </label>
      <input
        id={inputId}
        role="combobox"
        type="text"
        autoComplete="off"
        placeholder={placeholder}
        value={text}
        aria-autocomplete="list"
        aria-expanded={open}
        aria-controls={listboxId}
        aria-activedescendant={activeIndex !== null ? optionId(activeIndex) : undefined}
        onChange={handleChange}
        onClick={() => setOpen(true)}
        onBlur={handleBlur}
        onKeyDown={handleKeyDown}
      />
      {open && visible.length === 0 && <div role="status">No results</div>}
      <div id={listboxId} role="listbox" aria-labelledby={labelId} hidden={!open}>
        {visible.map((index) => {
          const option = options[index];
          return (
            <div
              key={optionId(index)}
              id={optionId(index)}
              role="option"
              aria-selected={option.value === value}
              aria-disabled={option.disabled ? "true" : undefined}
              data-active={index === activeIndex ? "true" : undefined}
              onMouseDown={(event) => event.preventDefault()}
              onClick={() => {
                if (!option.disabled) {
                  choose(index);
                }
              }}
            >
              {option.label}
            </div>
          );
        })}
      </div>
    </div>
  );
}

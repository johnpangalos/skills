import {
  useEffect,
  useId,
  useRef,
  type ComponentPropsWithoutRef,
  type KeyboardEvent,
  type MouseEvent,
} from "react";
import { createPortal } from "react-dom";

export interface DialogProps extends Omit<ComponentPropsWithoutRef<"div">, "title" | "role"> {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  title: string;
  description?: string;
}

type DialogContentProps = Omit<DialogProps, "open">;

const FOCUSABLE =
  'a[href], button:not(:disabled), input:not(:disabled):not([type="hidden"]), select:not(:disabled), textarea:not(:disabled), [tabindex]';

// Open dialogs, innermost last. Only the innermost one keeps focus, so nested dialogs don't pull focus back and forth.
const openDialogs: HTMLElement[] = [];

function getFocusable(container: HTMLElement): HTMLElement[] {
  return Array.from(container.querySelectorAll<HTMLElement>(FOCUSABLE)).filter(
    (element) => element.tabIndex >= 0 && !element.closest("[hidden]"),
  );
}

// Keeps Tab and Shift+Tab cycling inside the dialog.
function keepFocusInside(event: KeyboardEvent<HTMLElement>, dialog: HTMLElement) {
  if (event.key !== "Tab") return;
  const focusable = getFocusable(dialog);
  const first = focusable[0] ?? dialog;
  const last = focusable[focusable.length - 1] ?? dialog;
  const active = document.activeElement;
  const inside = active !== null && dialog.contains(active);
  const atEdge = event.shiftKey ? active === first || active === dialog : active === last || active === dialog;
  if (atEdge || !inside) {
    event.preventDefault();
    (event.shiftKey ? last : first).focus();
  }
}

export function Dialog({ open, ...rest }: DialogProps) {
  if (!open) return null;
  return createPortal(<DialogContent {...rest} />, document.body);
}

// Mounted only while open, so mount/unmount effects map to open/close.
function DialogContent({ title, description, onOpenChange, onKeyDown, children, ...rest }: DialogContentProps) {
  const baseId = useId();
  const titleId = `${baseId}-title`;
  const descriptionId = `${baseId}-description`;
  const dialogRef = useRef<HTMLDivElement>(null);
  const pressStartedOnBackdrop = useRef(false);

  useEffect(() => {
    const dialog = dialogRef.current!;
    const previous = document.activeElement;
    openDialogs.push(dialog);
    const isInnermost = () => openDialogs[openDialogs.length - 1] === dialog;
    // Focus can't leave the dialog: focus moved outside is pulled back in, and Tab from outside (for example from body) is redirected in.
    const pullFocusIn = (event: FocusEvent) => {
      if (isInnermost() && event.target instanceof Node && !dialog.contains(event.target)) {
        (getFocusable(dialog)[0] ?? dialog).focus();
      }
    };
    const pullTabIn = (event: globalThis.KeyboardEvent) => {
      if (!isInnermost() || event.key !== "Tab" || dialog.contains(document.activeElement)) return;
      event.preventDefault();
      const focusable = getFocusable(dialog);
      const target = event.shiftKey ? focusable[focusable.length - 1] : focusable[0];
      (target ?? dialog).focus();
    };
    document.addEventListener("focusin", pullFocusIn);
    document.addEventListener("keydown", pullTabIn);
    (getFocusable(dialog)[0] ?? dialog).focus();
    return () => {
      // Listeners go first so the focus restore below is not pulled back into the dialog.
      document.removeEventListener("focusin", pullFocusIn);
      document.removeEventListener("keydown", pullTabIn);
      openDialogs.splice(openDialogs.indexOf(dialog), 1);
      if (previous instanceof HTMLElement && previous.isConnected) {
        previous.focus();
      }
    };
  }, []);

  // Escape is handled on the dialog's React onKeyDown so a child's stopPropagation can prevent it.
  const handleKeyDown = (event: KeyboardEvent<HTMLDivElement>) => {
    onKeyDown?.(event);
    // Keys from a nested dialog bubble through its portal to this handler; they belong to that dialog.
    if (!event.currentTarget.contains(event.target as Node)) return;
    if (event.key === "Escape") {
      onOpenChange(false);
      return;
    }
    keepFocusInside(event, event.currentTarget);
  };

  // A click only dismisses when the press and release both happened on the backdrop.
  const handleBackdropMouseDown = (event: MouseEvent<HTMLDivElement>) => {
    pressStartedOnBackdrop.current = event.target === event.currentTarget;
  };

  const handleBackdropMouseUp = (event: MouseEvent<HTMLDivElement>) => {
    if (event.target !== event.currentTarget) pressStartedOnBackdrop.current = false;
  };

  const handleBackdropClick = (event: MouseEvent<HTMLDivElement>) => {
    if (pressStartedOnBackdrop.current && event.target === event.currentTarget) {
      onOpenChange(false);
    }
  };

  return (
    <div
      data-dialog-backdrop=""
      onMouseDown={handleBackdropMouseDown}
      onMouseUp={handleBackdropMouseUp}
      onClick={handleBackdropClick}
    >
      <div
        {...rest}
        ref={dialogRef}
        role="dialog"
        aria-modal="true"
        aria-labelledby={titleId}
        aria-describedby={description ? descriptionId : undefined}
        tabIndex={-1}
        onKeyDown={handleKeyDown}
      >
        <h2 id={titleId}>{title}</h2>
        {description && <p id={descriptionId}>{description}</p>}
        {children}
      </div>
    </div>
  );
}

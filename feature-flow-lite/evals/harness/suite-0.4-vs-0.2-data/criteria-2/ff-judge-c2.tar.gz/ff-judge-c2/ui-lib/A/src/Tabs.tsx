import {
  createContext,
  useCallback,
  useContext,
  useId,
  useLayoutEffect,
  useRef,
  useState,
  type ComponentPropsWithoutRef,
  type KeyboardEvent,
} from "react";

type TabsContextValue = {
  baseId: string;
  selected: string | null;
  tabbable: string | null;
  refresh: () => void;
  select: (value: string) => void;
};

const TabsContext = createContext<TabsContextValue | null>(null);

function useTabsContext(): TabsContextValue {
  const context = useContext(TabsContext);
  if (context === null) {
    throw new Error("Tab, TabList and TabPanel must be rendered inside <Tabs>");
  }
  return context;
}

function tabIdFor(baseId: string, value: string): string {
  return `${baseId}-tab-${encodeURIComponent(value)}`;
}

function panelIdFor(baseId: string, value: string): string {
  return `${baseId}-panel-${encodeURIComponent(value)}`;
}

/** Enabled tabs owned by the Tabs instance `baseId` inside `container`, in DOM order. Nested Tabs are excluded. */
function enabledTabsIn(container: HTMLElement, baseId: string): HTMLElement[] {
  return Array.from(
    container.querySelectorAll<HTMLElement>(
      `[role="tab"][data-tabs-owner="${baseId}"]:not([aria-disabled="true"])`,
    ),
  );
}

function sameValues(a: string[], b: string[]): boolean {
  return a.length === b.length && a.every((value, index) => value === b[index]);
}

export type TabsProps = ComponentPropsWithoutRef<"div"> & {
  /** Selected tab value. When provided, the component is controlled. */
  value?: string;
  /** Initially selected tab value (uncontrolled). Defaults to the first enabled tab. */
  defaultValue?: string;
  /** Called with the new value whenever the user changes the selection. */
  onValueChange?: (value: string) => void;
};

export function Tabs({ value, defaultValue, onValueChange, children, ...rest }: TabsProps) {
  const baseId = useId();
  const ref = useRef<HTMLDivElement>(null);
  const [internalValue, setInternalValue] = useState<string | undefined>(defaultValue);
  const [enabledValues, setEnabled] = useState<string[]>([]);
  const [version, setVersion] = useState(0);

  const stored = value ?? internalValue ?? null;
  const selected = stored ?? enabledValues[0] ?? null;
  const tabbable =
    selected !== null && enabledValues.includes(selected) ? selected : (enabledValues[0] ?? null);

  // Tabs call this when they mount, unmount, or change value/disabled, so enabled tabs are re-scanned.
  const refresh = useCallback(() => setVersion((count) => count + 1), []);

  // Re-discover enabled tabs in DOM order, across every TabList under this Tabs.
  useLayoutEffect(() => {
    const root = ref.current;
    if (!root) return;
    const values = enabledTabsIn(root, baseId).map((tab) => tab.dataset.value ?? "");
    setEnabled((previous) => (sameValues(previous, values) ? previous : values));
    // Pin the implicit selection so it does not jump when the first tab is re-enabled.
    if (value === undefined && internalValue === undefined && values.length > 0) {
      setInternalValue(values[0]);
    }
  }, [version, baseId, value, internalValue]);

  const select = (next: string) => {
    if (next === selected) return;
    if (value === undefined) setInternalValue(next);
    onValueChange?.(next);
  };

  return (
    <TabsContext.Provider value={{ baseId, selected, tabbable, refresh, select }}>
      <div {...rest} ref={ref}>
        {children}
      </div>
    </TabsContext.Provider>
  );
}

export type TabListProps = ComponentPropsWithoutRef<"div"> & {
  "aria-label": string;
};

export function TabList({ children, ...rest }: TabListProps) {
  const { baseId, select } = useTabsContext();

  const onKeyDown = (event: KeyboardEvent<HTMLDivElement>) => {
    const list = event.currentTarget;
    const tabs = enabledTabsIn(list, baseId);
    const index = tabs.indexOf(event.target as HTMLElement);
    if (index === -1) return;

    let next: number;
    switch (event.key) {
      case "ArrowRight":
        next = (index + 1) % tabs.length;
        break;
      case "ArrowLeft":
        next = (index - 1 + tabs.length) % tabs.length;
        break;
      case "Home":
        next = 0;
        break;
      case "End":
        next = tabs.length - 1;
        break;
      default:
        return;
    }

    event.preventDefault();
    tabs[next].focus();
    select(tabs[next].dataset.value ?? "");
  };

  return (
    <div {...rest} role="tablist" onKeyDown={onKeyDown}>
      {children}
    </div>
  );
}

export type TabProps = Omit<ComponentPropsWithoutRef<"button">, "value"> & {
  value: string;
  disabled?: boolean;
};

export function Tab({ value, disabled = false, onClick, children, ...rest }: TabProps) {
  const { baseId, selected, tabbable, refresh, select } = useTabsContext();

  useLayoutEffect(() => {
    refresh();
    return () => refresh();
  }, [value, disabled, refresh]);

  return (
    <button
      type="button"
      {...rest}
      role="tab"
      id={tabIdFor(baseId, value)}
      aria-controls={panelIdFor(baseId, value)}
      aria-selected={value === selected}
      aria-disabled={disabled ? true : undefined}
      tabIndex={value === tabbable ? 0 : -1}
      data-value={value}
      data-tabs-owner={baseId}
      onClick={(event) => {
        onClick?.(event);
        if (!disabled) select(value);
      }}
    >
      {children}
    </button>
  );
}

export type TabPanelProps = ComponentPropsWithoutRef<"div"> & {
  value: string;
};

export function TabPanel({ value, children, ...rest }: TabPanelProps) {
  const { baseId, selected } = useTabsContext();

  return (
    <div
      {...rest}
      role="tabpanel"
      id={panelIdFor(baseId, value)}
      aria-labelledby={tabIdFor(baseId, value)}
      tabIndex={0}
      hidden={value !== selected}
    >
      {children}
    </div>
  );
}

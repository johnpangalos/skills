import {
  createContext,
  useCallback,
  useContext,
  useId,
  useLayoutEffect,
  useRef,
  useState,
  type ComponentPropsWithoutRef,
  type KeyboardEvent,
  type ReactNode,
  type RefObject,
} from "react";
import { encodeId } from "../encodeId";

export interface TabsProps {
  defaultValue?: string;
  value?: string;
  onValueChange?: (value: string) => void;
  children?: ReactNode;
}

export interface TabListProps extends Omit<ComponentPropsWithoutRef<"div">, "role" | "aria-orientation"> {
  "aria-label": string;
}

export interface TabProps extends Omit<ComponentPropsWithoutRef<"button">, "value" | "role" | "type"> {
  value: string;
  disabled?: boolean;
}

export interface TabPanelProps extends Omit<ComponentPropsWithoutRef<"div">, "role" | "value"> {
  value: string;
}

interface TabsContextValue {
  baseId: string;
  current: string | null;
  tabStop: string | null;
  listRef: RefObject<HTMLDivElement | null>;
  panels: Set<string>;
  tabValues: Set<string>;
  registerPanel: (value: string) => () => void;
  select: (value: string) => void;
  setTabStop: (value: string | null) => void;
  setTabValues: (values: Set<string>) => void;
}

const TabsContext = createContext<TabsContextValue | null>(null);

function useTabsContext(component: string): TabsContextValue {
  const context = useContext(TabsContext);
  if (context === null) {
    throw new Error(`${component} must be rendered inside <Tabs>`);
  }
  return context;
}

function tabId(baseId: string, value: string): string {
  return `${baseId}-tab-${encodeId(value)}`;
}

function panelId(baseId: string, value: string): string {
  return `${baseId}-panel-${encodeId(value)}`;
}

// Tab order is read from the DOM so added, removed and reordered tabs are navigated correctly.
function getTabs(list: HTMLElement | null): HTMLButtonElement[] {
  return list ? Array.from(list.querySelectorAll<HTMLButtonElement>('[role="tab"]')) : [];
}

// Lets TabList skip a state update when the published tab values have not changed.
function sameSet(a: Set<string>, b: Set<string>): boolean {
  return a.size === b.size && Array.from(a).every((value) => b.has(value));
}

function findTabTarget(tabs: HTMLButtonElement[], from: HTMLButtonElement, key: string): HTMLButtonElement | undefined {
  const index = tabs.indexOf(from);
  switch (key) {
    case "ArrowRight":
      return tabs[(index + 1) % tabs.length];
    case "ArrowLeft":
      return tabs[(index - 1 + tabs.length) % tabs.length];
    case "Home":
      return tabs[0];
    case "End":
      return tabs[tabs.length - 1];
    default:
      return undefined;
  }
}

export function Tabs({ defaultValue, value, onValueChange, children }: TabsProps) {
  const baseId = useId();
  const listRef = useRef<HTMLDivElement>(null);
  const [internal, setInternal] = useState<string | null>(defaultValue ?? null);
  // The tab that is reachable with Tab: the selected one, or the first enabled one when the selection matches no enabled tab.
  const [tabStop, setTabStop] = useState<string | null>(null);
  // Values of the mounted TabPanels, so a Tab only points aria-controls at a panel that exists.
  const [panels, setPanels] = useState<Set<string>>(() => new Set());
  // Values of the tabs in the DOM, published by TabList, so a TabPanel only points aria-labelledby at a tab that exists.
  const [tabValues, setTabValues] = useState<Set<string>>(() => new Set());

  // Uncontrolled with no defaultValue: the first enabled tab is selected.
  const current = value ?? internal ?? tabStop;

  const select = (next: string) => {
    if (next === current) return;
    if (value === undefined) setInternal(next);
    onValueChange?.(next);
  };

  // Stable, so TabPanel's registration effect runs on mount and unmount only.
  const registerPanel = useCallback((panel: string) => {
    setPanels((previous) => new Set(previous).add(panel));
    return () => {
      setPanels((previous) => {
        const next = new Set(previous);
        next.delete(panel);
        return next;
      });
    };
  }, []);

  return (
    <TabsContext.Provider
      value={{
        baseId,
        current,
        tabStop,
        listRef,
        panels,
        tabValues,
        registerPanel,
        select,
        setTabStop,
        setTabValues,
      }}
    >
      {children}
    </TabsContext.Provider>
  );
}

export function TabList({ children, ...rest }: TabListProps) {
  const { current, listRef, setTabStop, tabValues, setTabValues } = useTabsContext("TabList");

  // Runs after every render so the roving tab stop and the published tab values follow the DOM.
  useLayoutEffect(() => {
    const tabs = getTabs(listRef.current);
    const enabled = tabs.filter((tab) => !tab.disabled);
    const selectedIsEnabled = enabled.some((tab) => tab.dataset.value === current);
    setTabStop(selectedIsEnabled ? current : (enabled[0]?.dataset.value ?? null));
    const values = new Set(tabs.map((tab) => tab.dataset.value!));
    if (!sameSet(tabValues, values)) setTabValues(values);
  });

  return (
    <div {...rest} ref={listRef} role="tablist" aria-orientation="horizontal">
      {children}
    </div>
  );
}

export function Tab({ value, disabled, onClick, onKeyDown, children, ...rest }: TabProps) {
  const { baseId, current, tabStop, listRef, panels, select } = useTabsContext("Tab");

  const handleKeyDown = (event: KeyboardEvent<HTMLButtonElement>) => {
    onKeyDown?.(event);
    const enabled = getTabs(listRef.current).filter((tab) => !tab.disabled);
    const target = findTabTarget(enabled, event.currentTarget, event.key);
    if (!target) return;
    event.preventDefault();
    target.focus();
    select(target.dataset.value!);
  };

  return (
    <button
      {...rest}
      type="button"
      role="tab"
      id={tabId(baseId, value)}
      data-value={value}
      aria-selected={value === current}
      aria-controls={panels.has(value) ? panelId(baseId, value) : undefined}
      tabIndex={value === tabStop ? 0 : -1}
      disabled={disabled}
      onClick={(event) => {
        onClick?.(event);
        select(value);
      }}
      onKeyDown={handleKeyDown}
    >
      {children}
    </button>
  );
}

export function TabPanel({ value, children, ...rest }: TabPanelProps) {
  const { baseId, current, tabValues, registerPanel } = useTabsContext("TabPanel");
  const selected = value === current;

  useLayoutEffect(() => registerPanel(value), [registerPanel, value]);

  return (
    <div
      {...rest}
      role="tabpanel"
      id={panelId(baseId, value)}
      aria-labelledby={tabValues.has(value) ? tabId(baseId, value) : undefined}
      tabIndex={0}
      hidden={!selected}
    >
      {selected ? children : null}
    </div>
  );
}

import { fireEvent, render, screen } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { Combobox, type ComboboxOption, type ComboboxProps } from "../src";

const user = userEvent.setup();

const options: ComboboxOption[] = [
  { value: "apple", label: "Apple" },
  { value: "banana", label: "Banana", disabled: true },
  { value: "cherry", label: "Cherry" },
  { value: "grape", label: "Grape (green)" },
];

function renderCombobox(props: Partial<ComboboxProps> = {}) {
  const onChange = vi.fn();
  const utils = render(
    <Combobox
      label="Fruit"
      options={options}
      value={null}
      onChange={onChange}
      placeholder="Pick one"
      {...props}
    />,
  );
  return { ...utils, onChange, input: screen.getByRole("combobox", { name: "Fruit" }) };
}

function optionNames(): string[] {
  return screen.queryAllByRole("option").map((option) => option.textContent ?? "");
}

describe("Combobox", () => {
  it("associates the label with the input and wires ARIA attributes", () => {
    const { input } = renderCombobox({ value: "cherry" });
    const listbox = document.querySelector('[role="listbox"]') as HTMLElement;
    expect(input).toHaveAttribute("placeholder", "Pick one");
    expect(input).toHaveAttribute("aria-autocomplete", "list");
    expect(input).toHaveAttribute("aria-expanded", "false");
    expect(input).toHaveAttribute("aria-controls", listbox.id);
    expect(listbox).toHaveAttribute("aria-labelledby", screen.getByText("Fruit").id);
    expect(input).not.toHaveAttribute("aria-activedescendant");
    expect(input).toHaveValue("Cherry");
    expect(listbox).not.toBeVisible();
  });

  it("gives options unique ids, aria-selected and aria-disabled", async () => {
    const { input } = renderCombobox({ value: "cherry" });
    await user.click(input);
    const all = screen.getAllByRole("option", { hidden: true });
    expect(new Set(all.map((option) => option.id)).size).toBe(options.length);
    expect(screen.getByRole("option", { name: "Cherry" })).toHaveAttribute("aria-selected", "true");
    expect(screen.getByRole("option", { name: "Apple" })).toHaveAttribute("aria-selected", "false");
    expect(screen.getByRole("option", { name: "Banana" })).toHaveAttribute("aria-disabled", "true");
  });

  it("shows the selected label and updates when the parent changes value", () => {
    const { rerender, input, onChange } = renderCombobox({ value: "apple" });
    expect(input).toHaveValue("Apple");
    rerender(
      <Combobox label="Fruit" options={options} value="grape" onChange={onChange} />,
    );
    expect(input).toHaveValue("Grape (green)");
  });

  it("shows empty text when value is not present in options", () => {
    const { input } = renderCombobox({ value: "missing" });
    expect(input).toHaveValue("");
  });

  it("filters case-insensitively by substring and shows all options when empty", async () => {
    const { input } = renderCombobox();
    await user.type(input, "AN");
    expect(optionNames()).toEqual(["Banana"]);
    await user.clear(input);
    expect(optionNames()).toEqual(["Apple", "Banana", "Cherry", "Grape (green)"]);
  });

  it("treats regex characters in the filter text literally", async () => {
    const { input } = renderCombobox();
    await user.type(input, "(");
    expect(optionNames()).toEqual(["Grape (green)"]);
    await user.clear(input);
    await user.type(input, ".*");
    expect(screen.queryAllByRole("option")).toHaveLength(0);
    expect(screen.getByText("No results")).toBeInTheDocument();
  });

  it("shows No results without any option role when nothing matches", async () => {
    const { input } = renderCombobox();
    await user.type(input, "zzz");
    expect(screen.getByText("No results")).toBeInTheDocument();
    expect(screen.queryByRole("option")).toBeNull();
    expect(input).not.toHaveAttribute("aria-activedescendant");
  });

  it("opens with ArrowDown showing the selected option active, keeping focus on the input", async () => {
    const { input } = renderCombobox({ value: "cherry" });
    await user.click(input);
    await user.keyboard("{Escape}");
    expect(input).toHaveAttribute("aria-expanded", "false");
    await user.keyboard("{ArrowDown}");
    expect(input).toHaveAttribute("aria-expanded", "true");
    expect(input).toHaveFocus();
    expect(input).toHaveAttribute("aria-activedescendant", screen.getByRole("option", { name: "Cherry" }).id);
    expect(screen.getByRole("option", { name: "Cherry" })).toHaveAttribute("data-active");
  });

  it("opens with ArrowDown on the first enabled option when no option is selected", async () => {
    const { input } = renderCombobox();
    input.focus();
    await user.keyboard("{ArrowDown}");
    expect(input).toHaveAttribute("aria-activedescendant", screen.getByRole("option", { name: "Apple" }).id);
  });

  it("moves the active option with ArrowDown and ArrowUp, skipping disabled and wrapping", async () => {
    const { input } = renderCombobox();
    input.focus();
    await user.keyboard("{ArrowDown}");
    const activeName = () => document.getElementById(input.getAttribute("aria-activedescendant") ?? "")?.textContent;
    expect(activeName()).toBe("Apple");
    await user.keyboard("{ArrowDown}");
    expect(activeName()).toBe("Cherry");
    await user.keyboard("{ArrowDown}");
    expect(activeName()).toBe("Grape (green)");
    await user.keyboard("{ArrowDown}");
    expect(activeName()).toBe("Apple");
    await user.keyboard("{ArrowUp}");
    expect(activeName()).toBe("Grape (green)");
    expect(input).toHaveFocus();
  });

  it("selects the active option on Enter, fills the label and closes", async () => {
    const { input, onChange } = renderCombobox();
    input.focus();
    await user.keyboard("{ArrowDown}{ArrowDown}{Enter}");
    expect(onChange).toHaveBeenCalledWith("cherry");
    expect(input).toHaveValue("");
    expect(input).toHaveAttribute("aria-expanded", "false");
  });

  it("does not call onChange on Enter with no active option", async () => {
    const { input, onChange } = renderCombobox({ value: "apple" });
    await user.type(input, "ch");
    await user.keyboard("{Enter}");
    expect(onChange).not.toHaveBeenCalled();
  });

  it("calls onChange(null) on Enter when the text is cleared and a value is set", async () => {
    const { input, onChange } = renderCombobox({ value: "apple" });
    await user.clear(input);
    await user.keyboard("{Enter}");
    expect(onChange).toHaveBeenCalledWith(null);
  });

  it("selects an enabled option on click and ignores a disabled one", async () => {
    const { input, onChange } = renderCombobox();
    await user.click(input);
    await user.click(screen.getByRole("option", { name: "Banana" }));
    expect(onChange).not.toHaveBeenCalled();
    expect(input).toHaveFocus();
    await user.click(screen.getByRole("option", { name: "Apple" }));
    expect(onChange).toHaveBeenCalledWith("apple");
    expect(input).toHaveFocus();
  });

  it("selects on a fired click without a preceding mousedown", () => {
    const { onChange } = renderCombobox();
    fireEvent.click(document.getElementById(optionIdOf("Cherry")) as HTMLElement);
    expect(onChange).toHaveBeenCalledWith("cherry");
  });

  it("closes on Escape without onChange and restores the selected label", async () => {
    const { input, onChange } = renderCombobox({ value: "apple" });
    await user.click(input);
    await user.clear(input);
    await user.type(input, "ch");
    await user.keyboard("{Escape}");
    expect(onChange).not.toHaveBeenCalled();
    expect(input).toHaveAttribute("aria-expanded", "false");
    expect(input).toHaveValue("Apple");
  });

  it("stops Escape propagation only while the listbox is open", async () => {
    const onKeyDown = vi.fn();
    render(
      <div onKeyDown={onKeyDown}>
        <Combobox label="Fruit" options={options} value={null} onChange={() => {}} />
      </div>,
    );
    const input = screen.getByRole("combobox", { name: "Fruit" });
    await user.click(input);
    await user.keyboard("{Escape}");
    expect(onKeyDown).not.toHaveBeenCalled();
    await user.keyboard("{Escape}");
    expect(onKeyDown).toHaveBeenCalledTimes(1);
  });

  it("closes on blur, restores the label and calls onChange(null) when cleared", async () => {
    const { input, onChange } = renderCombobox({ value: "apple" });
    await user.clear(input);
    await user.tab();
    expect(onChange).toHaveBeenCalledWith(null);
    expect(input).toHaveAttribute("aria-expanded", "false");
    expect(input).toHaveValue("Apple");
  });

  it("closes on blur without onChange when the text was only typed over", async () => {
    const { input, onChange } = renderCombobox({ value: "apple" });
    await user.type(input, "ch");
    await user.tab();
    expect(onChange).not.toHaveBeenCalled();
    expect(input).toHaveValue("Apple");
  });

  it("opens the full list on click", async () => {
    const { input } = renderCombobox({ value: "cherry" });
    await user.click(input);
    expect(input).toHaveAttribute("aria-expanded", "true");
    expect(optionNames()).toHaveLength(options.length);
  });

  it("does nothing with arrows when all options are disabled", async () => {
    const { input } = renderCombobox({
      options: [
        { value: "a", label: "A", disabled: true },
        { value: "b", label: "B", disabled: true },
      ],
    });
    input.focus();
    await user.keyboard("{ArrowDown}{ArrowUp}");
    expect(input).toHaveAttribute("aria-expanded", "true");
    expect(input).not.toHaveAttribute("aria-activedescendant");
    await user.keyboard("{Enter}");
    expect(input).toHaveAttribute("aria-expanded", "true");
  });

  it("drops the active option when the options list shrinks past it", async () => {
    const { input, rerender, onChange } = renderCombobox();
    input.focus();
    await user.keyboard("{ArrowDown}{ArrowDown}");
    expect(screen.getByRole("option", { name: "Cherry" })).toHaveAttribute("data-active");
    rerender(<Combobox label="Fruit" options={options.slice(0, 1)} value={null} onChange={onChange} />);
    expect(input).toHaveAttribute("aria-expanded", "true");
    expect(input).not.toHaveAttribute("aria-activedescendant");
    expect(screen.getAllByRole("option")).toHaveLength(1);
  });

  it("discards the in-progress edit when the parent changes value mid-edit", async () => {
    const onChange = vi.fn();
    const fruits: ComboboxOption[] = [
      { value: "a", label: "Apple" },
      { value: "b", label: "Banana" },
    ];
    const { rerender } = render(
      <Combobox label="Fruit" options={fruits} value={null} onChange={onChange} />,
    );
    await user.type(screen.getByRole("combobox"), "ap");
    rerender(<Combobox label="Fruit" options={fruits} value="b" onChange={onChange} />);
    expect(screen.getByRole("combobox")).toHaveValue("Banana");
    expect(screen.getByRole("combobox")).toHaveAttribute("aria-expanded", "false");
    expect(screen.getByRole("combobox")).not.toHaveAttribute("aria-activedescendant");
  });
});

function optionIdOf(label: string): string {
  return screen.getByRole("option", { name: label, hidden: true }).id;
}

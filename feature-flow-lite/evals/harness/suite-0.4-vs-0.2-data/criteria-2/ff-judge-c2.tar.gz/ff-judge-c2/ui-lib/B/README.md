# @acme/ui

Accessible React 19 components in TypeScript. They ship no styles and no CSS: each component renders plain elements and accepts `className` so you can style it.

```ts
import { Tabs, TabList, Tab, TabPanel, Dialog, Combobox } from "@acme/ui";
```

All components are exported from `src/index.ts` along with their props types. Generated ids come from `React.useId()`, so several instances can share a page.

## Tabs

A tab list with panels. Uncontrolled by default; pass `value` to control it.

```tsx
<Tabs defaultValue="account" onValueChange={(value) => console.log(value)}>
  <TabList aria-label="Settings">
    <Tab value="account">Account</Tab>
    <Tab value="billing">Billing</Tab>
    <Tab value="legacy" disabled>Legacy</Tab>
  </TabList>
  <TabPanel value="account">Account settings</TabPanel>
  <TabPanel value="billing">Billing settings</TabPanel>
  <TabPanel value="legacy">Not shown</TabPanel>
</Tabs>
```

### Tabs props

| Name | Type | Required / Default | Description |
| --- | --- | --- | --- |
| `value` | `string` | Optional; undefined means uncontrolled | Selected tab value. When defined, the selection changes only when the owner updates it. |
| `defaultValue` | `string` | Optional; first enabled tab | Initially selected value when uncontrolled. If it names a disabled tab, the first enabled tab is selected instead. |
| `onValueChange` | `(value: string) => void` | Optional | Called when the user selects a different tab (click or arrow/Home/End keys). Not called for the already-selected tab. |
| `className` | `string` | Optional | Class name for the wrapper element. |

### TabList props

| Name | Type | Required / Default | Description |
| --- | --- | --- | --- |
| `aria-label` | `string` | Required | Accessible name of the `role="tablist"` element. |
| `className` | `string` | Optional | Class name for the tablist element. |

The tablist always renders `aria-orientation="horizontal"`. Other native `div` attributes pass through, except `role` and `onKeyDown`.

Every `Tab` needs a `TabPanel` with the same `value`, and every `TabPanel` needs a `Tab`, because `aria-controls` and `aria-labelledby` reference each other.

### Tab props

| Name | Type | Required / Default | Description |
| --- | --- | --- | --- |
| `value` | `string` | Required | Value this tab selects. Matches a `TabPanel` with the same value. |
| `disabled` | `boolean` | Optional; `false` | Disabled tabs are not focusable, cannot be clicked, and are skipped by the keyboard. They render `aria-disabled="true"`. |
| `className` | `string` | Optional | Class name for the tab button. |

Native button attributes pass through, except `type`, `role` and `value`, which the component sets.

### TabPanel props

| Name | Type | Required / Default | Description |
| --- | --- | --- | --- |
| `value` | `string` | Required | Tab value this panel belongs to. Non-selected panels get the `hidden` attribute. |
| `className` | `string` | Optional | Class name for the panel element. |

### Tabs keyboard

| Key | Behavior |
| --- | --- |
| Right Arrow | Moves focus to the next enabled tab and selects it. Wraps from the last tab to the first. |
| Left Arrow | Moves focus to the previous enabled tab and selects it. Wraps from the first tab to the last. |
| Home | Moves focus to the first enabled tab and selects it. |
| End | Moves focus to the last enabled tab and selects it. |

Only one tab is in the tab order: the selected tab, or the first enabled tab when no tab is selected. Tabs nested inside a `TabPanel` have their own keyboard set.

## Dialog

A modal dialog rendered into `document.body`. It is fully controlled: it never changes `open` itself.

```tsx
const [open, setOpen] = useState(false);

<button onClick={() => setOpen(true)}>Delete account</button>
<Dialog
  open={open}
  onOpenChange={setOpen}
  title="Delete account?"
  description="This cannot be undone."
>
  <button onClick={() => setOpen(false)}>Cancel</button>
  <button onClick={confirmDelete}>Delete</button>
</Dialog>
```

When open, focus moves to the first tabbable element inside the dialog, or to the dialog itself when there is none. When it closes, focus returns to the element that was focused before it opened, if that element is still in the document.

### Dialog props

| Name | Type | Required / Default | Description |
| --- | --- | --- | --- |
| `open` | `boolean` | Required | Whether the dialog is shown. Nothing is rendered when `false`. |
| `onOpenChange` | `(open: boolean) => void` | Required | Called with `false` on Escape or on a backdrop click. |
| `title` | `ReactNode` | Required | Rendered in an `h2` and used as the accessible name. |
| `description` | `ReactNode` | Optional | Rendered below the title and used as the accessible description. Omitted when not given. |
| `className` | `string` | Optional | Class name for the dialog content element (`role="dialog"`). |
| `children` | `ReactNode` | Optional | Dialog body. |

### Dialog keyboard

| Key | Behavior |
| --- | --- |
| Tab | Moves to the next tabbable element. From the last one it wraps to the first. With no tabbable elements, focus stays on the dialog. |
| Shift+Tab | Moves to the previous tabbable element. From the first one it wraps to the last. |
| Escape | Calls `onOpenChange(false)`. Handled on the dialog, so a `Combobox` that handles Escape keeps the dialog open. |

A click closes the dialog only when the press and the release both happen on the backdrop. Clicks inside the dialog, or a press that starts inside and ends on the backdrop, do not close it.

## Combobox

A text input that filters a list of options. It is controlled: `value` is the committed option value, and `onChange` reports changes.

```tsx
const [fruit, setFruit] = useState<string | null>(null);

<Combobox
  label="Fruit"
  placeholder="Search fruit"
  options={[
    { value: "apple", label: "Apple" },
    { value: "kiwi", label: "Kiwi", disabled: true },
  ]}
  value={fruit}
  onChange={setFruit}
/>
```

The input shows the label of the option matching `value`, or nothing when there is no match. Typing filters the options by the typed text, case-insensitively, as a literal substring. Deleting all the text calls `onChange(null)` immediately when `value` is not already `null`. Blurring the input closes the list and resets the text to the selected label.

### Combobox props

| Name | Type | Required / Default | Description |
| --- | --- | --- | --- |
| `label` | `string` | Required | Visible label, associated with the input and used as the listbox name. |
| `options` | `ComboboxOption[]` | Required | Options, each `{ value: string; label: string; disabled?: boolean }`. |
| `value` | `string \| null` | Required | Committed option value. `null` means nothing is selected. |
| `onChange` | `(value: string \| null) => void` | Required | Called when an option is committed (`value` of that option) or when the text is cleared (`null`). |
| `placeholder` | `string` | Optional | Placeholder for the input. |
| `className` | `string` | Optional | Class name for the root element. |

The listbox is always in the DOM and is `hidden` while closed. `aria-selected="true"` marks the committed value only. The option being navigated with the keyboard is exposed through `aria-activedescendant` on the input, and carries `data-active="true"`. A "No results" status appears while the list is open and nothing matches.

### Combobox keyboard

| Key | Behavior |
| --- | --- |
| Down Arrow | When closed, opens the list and activates the first enabled match. When open, activates the next enabled match, wrapping. |
| Up Arrow | When closed, opens the list and activates the last enabled match. When open, activates the previous enabled match, wrapping. |
| Enter | With an active option: commits it, sets the text to its label, and closes the list. Prevented while the list is open, so a form does not submit. With no active option, nothing is selected and the list stays open. When closed, Enter is not prevented. |
| Escape | When open: closes the list without calling `onChange`, keeps the typed text, and stops propagation so an enclosing `Dialog` stays open. When closed, the event propagates. |

Clicking an enabled option commits it and keeps focus in the input. Clicking a disabled option does nothing.

## Development

- `pnpm test` runs the Vitest suite.
- `pnpm typecheck` runs `tsc --noEmit`.

import { render, screen } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { useState } from "react";
import { Tab, TabList, TabPanel, Tabs, type TabsProps } from "../src";

const user = userEvent.setup();

function Example({ disabled = [], ...props }: TabsProps & { disabled?: string[] }) {
  return (
    <Tabs {...props}>
      <TabList aria-label="Sections">
        <Tab value="one" disabled={disabled.includes("one")}>
          One
        </Tab>
        <Tab value="two" disabled={disabled.includes("two")}>
          Two
        </Tab>
        <Tab value="three" disabled={disabled.includes("three")}>
          Three
        </Tab>
      </TabList>
      <TabPanel value="one">Panel one</TabPanel>
      <TabPanel value="two">Panel two</TabPanel>
      <TabPanel value="three">Panel three</TabPanel>
    </Tabs>
  );
}

function tab(name: string) {
  return screen.getByRole("tab", { name });
}

describe("Tabs", () => {
  it("renders tablist, tabs and panels with matching ARIA relationships", () => {
    render(<Example />);
    expect(screen.getByRole("tablist", { name: "Sections" })).toBeInTheDocument();
    const tabs = screen.getAllByRole("tab");
    expect(tabs).toHaveLength(3);
    for (const t of tabs) {
      expect(t).toHaveAttribute("type", "button");
      expect(t.id).not.toBe("");
      const panel = document.getElementById(t.getAttribute("aria-controls") ?? "");
      expect(panel).toHaveAttribute("role", "tabpanel");
      expect(panel).toHaveAttribute("aria-labelledby", t.id);
      expect(panel).toHaveAttribute("tabindex", "0");
    }
    expect(screen.getByRole("tabpanel")).toHaveTextContent("Panel one");
    expect(screen.getAllByRole("tabpanel", { hidden: true })).toHaveLength(3);
  });

  it("uses defaultValue for the initial tab", () => {
    render(<Example defaultValue="three" />);
    expect(tab("Three")).toHaveAttribute("aria-selected", "true");
    expect(screen.getByRole("tabpanel")).toHaveTextContent("Panel three");
  });

  it("selects the first enabled tab when defaultValue is omitted", () => {
    render(<Example disabled={["one"]} />);
    expect(tab("Two")).toHaveAttribute("aria-selected", "true");
    expect(tab("One")).toHaveAttribute("aria-selected", "false");
  });

  it("lets value alone decide selection and reports user changes", async () => {
    const onValueChange = vi.fn();
    render(<Example value="one" onValueChange={onValueChange} />);
    await user.click(tab("Two"));
    expect(onValueChange).toHaveBeenCalledWith("two");
    expect(tab("One")).toHaveAttribute("aria-selected", "true");
    expect(tab("Two")).toHaveAttribute("aria-selected", "false");
  });

  it("keeps selection when a controlled parent ignores onValueChange", async () => {
    const onValueChange = vi.fn();
    render(<Example value="one" onValueChange={onValueChange} />);
    await user.keyboard("{Tab}");
    expect(tab("One")).toHaveFocus();
    await user.keyboard("{ArrowRight}");
    expect(onValueChange).toHaveBeenCalledWith("two");
    expect(tab("Two")).toHaveFocus();
    expect(tab("One")).toHaveAttribute("aria-selected", "true");
  });

  it("gives only the selected tab tabIndex 0", () => {
    render(<Example defaultValue="two" />);
    expect(tab("One")).toHaveAttribute("tabindex", "-1");
    expect(tab("Two")).toHaveAttribute("tabindex", "0");
    expect(tab("Three")).toHaveAttribute("tabindex", "-1");
  });

  it("moves focus and selection with arrows, wrapping and skipping disabled tabs", async () => {
    const onValueChange = vi.fn();
    render(<Example disabled={["two"]} onValueChange={onValueChange} />);
    tab("One").focus();
    await user.keyboard("{ArrowRight}");
    expect(tab("Three")).toHaveFocus();
    expect(tab("Three")).toHaveAttribute("aria-selected", "true");
    expect(onValueChange).toHaveBeenLastCalledWith("three");
    await user.keyboard("{ArrowRight}");
    expect(tab("One")).toHaveFocus();
    await user.keyboard("{ArrowLeft}");
    expect(tab("Three")).toHaveFocus();
  });

  it("moves to the first and last enabled tab with Home and End", async () => {
    render(<Example disabled={["one"]} />);
    tab("Two").focus();
    await user.keyboard("{End}");
    expect(tab("Three")).toHaveFocus();
    await user.keyboard("{Home}");
    expect(tab("Two")).toHaveFocus();
    expect(tab("Two")).toHaveAttribute("aria-selected", "true");
  });

  it("selects an enabled tab on click and ignores a disabled one", async () => {
    const onValueChange = vi.fn();
    render(<Example disabled={["three"]} onValueChange={onValueChange} />);
    await user.click(tab("Three"));
    expect(onValueChange).not.toHaveBeenCalled();
    expect(tab("Three")).toHaveAttribute("aria-disabled", "true");
    expect(tab("One")).toHaveAttribute("aria-selected", "true");
    await user.click(tab("Two"));
    expect(tab("Two")).toHaveAttribute("aria-selected", "true");
    expect(onValueChange).toHaveBeenCalledWith("two");
  });

  it("does nothing with arrows when every tab is disabled", async () => {
    render(<Example disabled={["one", "two", "three"]} />);
    for (const t of screen.getAllByRole("tab")) {
      expect(t).toHaveAttribute("tabindex", "-1");
    }
    tab("One").focus();
    await user.keyboard("{ArrowRight}{End}{Home}");
    expect(tab("One")).toHaveFocus();
  });

  it("keeps a single tab focused and selected when arrows are pressed", async () => {
    const onValueChange = vi.fn();
    render(
      <Tabs onValueChange={onValueChange}>
        <TabList aria-label="Solo">
          <Tab value="only">Only</Tab>
        </TabList>
        <TabPanel value="only">Solo panel</TabPanel>
      </Tabs>,
    );
    tab("Only").focus();
    await user.keyboard("{ArrowRight}{ArrowLeft}{Home}{End}");
    expect(tab("Only")).toHaveFocus();
    expect(tab("Only")).toHaveAttribute("aria-selected", "true");
    expect(onValueChange).not.toHaveBeenCalled();
  });

  it("makes the first enabled tab tabbable when defaultValue names a disabled tab", () => {
    render(<Example defaultValue="two" disabled={["two"]} />);
    expect(tab("One")).toHaveAttribute("tabindex", "0");
    expect(tab("Two")).toHaveAttribute("tabindex", "-1");
  });

  it("makes the first enabled tab tabbable when defaultValue names no tab", () => {
    render(<Example defaultValue="nope" />);
    expect(tab("One")).toHaveAttribute("tabindex", "0");
    expect(tab("Two")).toHaveAttribute("tabindex", "-1");
    expect(tab("Three")).toHaveAttribute("tabindex", "-1");
  });

  it("does not move outer tabs when arrows are pressed in nested tabs", async () => {
    const onValueChange = vi.fn();
    render(
      <Tabs defaultValue="outer-a" onValueChange={onValueChange}>
        <TabList aria-label="Outer">
          <Tab value="outer-a">Outer A</Tab>
          <Tab value="outer-b">Outer B</Tab>
        </TabList>
        <TabPanel value="outer-a">
          <Tabs defaultValue="inner-x">
            <TabList aria-label="Inner">
              <Tab value="inner-x">Inner X</Tab>
              <Tab value="inner-y">Inner Y</Tab>
            </TabList>
            <TabPanel value="inner-x">Inner panel X</TabPanel>
            <TabPanel value="inner-y">Inner panel Y</TabPanel>
          </Tabs>
        </TabPanel>
        <TabPanel value="outer-b">Outer panel B</TabPanel>
      </Tabs>,
    );
    tab("Inner X").focus();
    await user.keyboard("{ArrowRight}");
    expect(tab("Inner Y")).toHaveFocus();
    expect(tab("Inner Y")).toHaveAttribute("aria-selected", "true");
    expect(tab("Outer A")).toHaveAttribute("aria-selected", "true");
    expect(onValueChange).not.toHaveBeenCalled();
  });

  it("discovers tabs added after mount in DOM order", async () => {
    function Conditional({ show }: { show: boolean }) {
      return (
        <Tabs defaultValue="a">
          <TabList aria-label="Conditional">
            <Tab value="a">A</Tab>
            {show && <Tab value="b">B</Tab>}
            <Tab value="c">C</Tab>
          </TabList>
          <TabPanel value="a">Panel A</TabPanel>
        </Tabs>
      );
    }
    const { rerender } = render(<Conditional show={false} />);
    rerender(<Conditional show={true} />);
    tab("A").focus();
    await user.keyboard("{ArrowRight}");
    expect(tab("B")).toHaveFocus();
    await user.keyboard("{ArrowRight}");
    expect(tab("C")).toHaveFocus();
  });

  it("throws a clear error when Tab is rendered outside Tabs", () => {
    const spy = vi.spyOn(console, "error").mockImplementation(() => {});
    expect(() => render(<Tab value="x">X</Tab>)).toThrow(
      "Tab, TabList and TabPanel must be rendered inside <Tabs>",
    );
    spy.mockRestore();
  });

  it("registers a tab that mounts because of a child component's own state", async () => {
    function Sub() {
      const [show, setShow] = useState(false);
      return (
        <>
          <button type="button" onClick={() => setShow(true)}>
            Reveal
          </button>
          {show && <Tab value="x">X</Tab>}
        </>
      );
    }
    render(
      <Tabs>
        <TabList aria-label="Child">
          <Sub />
        </TabList>
        <TabPanel value="x">Panel X</TabPanel>
      </Tabs>,
    );
    await user.click(screen.getByRole("button", { name: "Reveal" }));
    expect(tab("X")).toHaveAttribute("aria-selected", "true");
    expect(tab("X")).toHaveAttribute("tabindex", "0");
    expect(screen.getByRole("tabpanel")).not.toHaveAttribute("hidden");
  });

  it("supports two TabLists under one Tabs and keeps arrow keys inside each list", async () => {
    render(
      <Tabs defaultValue="a1">
        <TabList aria-label="First">
          <Tab value="a1">A1</Tab>
          <Tab value="a2">A2</Tab>
        </TabList>
        <TabList aria-label="Second">
          <Tab value="b1">B1</Tab>
          <Tab value="b2">B2</Tab>
        </TabList>
      </Tabs>,
    );
    tab("A1").focus();
    await user.keyboard("{ArrowRight}");
    expect(tab("A2")).toHaveFocus();
    tab("B1").focus();
    await user.keyboard("{ArrowRight}");
    expect(tab("B2")).toHaveFocus();
    await user.keyboard("{ArrowRight}");
    expect(tab("B1")).toHaveFocus();
    expect(tab("B1")).toHaveAttribute("aria-selected", "true");
  });

  it("keeps the implicit selection when a disabled first tab is re-enabled", () => {
    const { rerender } = render(<Example disabled={["one"]} />);
    expect(tab("Two")).toHaveAttribute("aria-selected", "true");
    rerender(<Example />);
    expect(tab("Two")).toHaveAttribute("aria-selected", "true");
    expect(tab("One")).toHaveAttribute("aria-selected", "false");
  });
});

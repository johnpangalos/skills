# @acme/ui

Accessible React 19 components: `Tabs`, `Dialog` and `Combobox`. No runtime dependencies beyond `react` and `react-dom`, and no styling: components render unstyled elements and forward `className` and native props.

Every id is generated with `React.useId()`, so several instances can live on one page.

## Installation

Import from the package entry point:

```tsx
import { Tabs, TabList, Tab, TabPanel, Dialog, Combobox } from "@acme/ui";
```

## Development

```sh
pnpm install
pnpm test       # vitest (jsdom) with Testing Library and user-event
pnpm typecheck  # tsc --noEmit
```

## Tabs

Usage:

```tsx
<Tabs defaultValue="profile">
  <TabList aria-label="Account">
    <Tab value="profile">Profile</Tab>
    <Tab value="billing">Billing</Tab>
    <Tab value="security" disabled>Security</Tab>
  </TabList>
  <TabPanel value="profile">Profile settings</TabPanel>
  <TabPanel value="billing">Billing settings</TabPanel>
  <TabPanel value="security">Security settings</TabPanel>
</Tabs>
```

Controlled: pass `value` and `onValueChange`. The selection only changes when the parent updates `value`.

### Tabs props

| Name | Type | Default | Description |
| --- | --- | --- | --- |
| `defaultValue` | `string` | first enabled tab | Initially selected tab, uncontrolled mode. |
| `value` | `string` | — | Selected tab, controlled mode. |
| `onValueChange` | `(value: string) => void` | — | Called when the user selects a different tab. Not called when the selected tab is clicked. |

### TabList props

| Name | Type | Default | Description |
| --- | --- | --- | --- |
| `aria-label` | `string` | required | Accessible name of the tablist. Required by the type. `aria-labelledby` is also accepted as a native div prop. |
| `...rest` | `ComponentPropsWithoutRef<"div">` | — | Forwarded to the `div[role="tablist"]`. `role` and `aria-orientation` are fixed to `tablist` and `horizontal`. |

### Tab props

| Name | Type | Default | Description |
| --- | --- | --- | --- |
| `value` | `string` | required | Value this tab selects. |
| `disabled` | `boolean` | `false` | Native `disabled` on the button. Disabled tabs can't be clicked or reached by keyboard. |
| `...rest` | `ComponentPropsWithoutRef<"button">` | — | Forwarded to the `button[role="tab"]`. `type` is fixed to `button`. |

### TabPanel props

| Name | Type | Default | Description |
| --- | --- | --- | --- |
| `value` | `string` | required | Tab this panel belongs to. |
| `...rest` | `ComponentPropsWithoutRef<"div">` | — | Forwarded to the `div[role="tabpanel"]`. |

Choices:

- **Tab order is read from the DOM** on each key press and on every render of `TabList`, so tabs added, removed or reordered after mount are navigated in DOM order.
- **Roving tab stop:** the selected tab has `tabIndex=0`, others `-1`. If no enabled tab matches the selection (for example, a controlled `value` that matches nothing), the first enabled tab gets `tabIndex=0`.
- **Selection follows focus:** arrow keys and Home/End move focus and select the tab. Arrow keys wrap around.
- Hidden panels are not rendered at all (their content is absent from the DOM) and carry the `hidden` attribute.

### Tabs keyboard

| Key | Action |
| --- | --- |
| `ArrowRight` | Focus and select the next enabled tab, wrapping from last to first. |
| `ArrowLeft` | Focus and select the previous enabled tab, wrapping from first to last. |
| `Home` | Focus and select the first enabled tab. |
| `End` | Focus and select the last enabled tab. |
| `Tab` | Moves focus into the selected panel (the tab stop is the selected tab). |

Other keys are ignored and their default action is not prevented.

## Dialog

Usage:

```tsx
const [open, setOpen] = useState(false);

<button onClick={() => setOpen(true)}>Rename</button>
<Dialog open={open} onOpenChange={setOpen} title="Rename file" description="Pick a new name.">
  <input aria-label="File name" />
  <button onClick={() => setOpen(false)}>Save</button>
</Dialog>
```

### Dialog props

| Name | Type | Default | Description |
| --- | --- | --- | --- |
| `open` | `boolean` | required | Whether the dialog is shown. Nothing is rendered when `false`. |
| `onOpenChange` | `(open: boolean) => void` | required | Called with `false` on Escape or a backdrop click. The parent decides whether to close. |
| `title` | `string` | required | Rendered as an `h2` and used as the accessible name. Not forwarded as an HTML `title` attribute. |
| `description` | `string` | — | Rendered in a `p` and linked with `aria-describedby`. The attribute is omitted when no description is given. |
| `...rest` | `ComponentPropsWithoutRef<"div">` | — | Forwarded to the `div[role="dialog"]`. `title` and `role` are excluded. |

Choices:

- The dialog is rendered into `document.body` with `createPortal`. It is mounted only while `open` is true.
- **Focus on open:** the first focusable element inside the dialog. If there is none, the dialog element itself (`tabIndex=-1`).
- **Focus trap:** Tab and Shift+Tab wrap inside the dialog. Focusable elements exclude disabled controls, `tabindex="-1"` and hidden elements. With no focusable elements, Tab keeps focus on the dialog.
- **Focus restore:** when the dialog closes or unmounts, focus returns to the element focused before it opened, if it is still in the document.
- **Escape** is handled by a React `onKeyDown` on the dialog element, not a document listener. A child that calls `stopPropagation` on its React keydown (such as an open `Combobox`) keeps Escape from reaching the dialog.
- **Backdrop:** a click closes the dialog only when both the mousedown and the mouseup happened on the backdrop. A press that starts inside the dialog and ends outside does not close it.
- The backdrop is a plain `div` with `data-dialog-backdrop`, with no styling. Style it with your own CSS.

### Dialog keyboard

| Key | Action |
| --- | --- |
| `Escape` | Calls `onOpenChange(false)`. |
| `Tab` | Moves to the next focusable element, wrapping from last to first. |
| `Shift+Tab` | Moves to the previous focusable element, wrapping from first to last. |

## Combobox

Usage:

```tsx
const fruits = [
  { value: "apple", label: "Apple" },
  { value: "banana", label: "Banana" },
  { value: "cherry", label: "Cherry", disabled: true },
];

const [value, setValue] = useState<string | null>(null);

<Combobox label="Fruit" options={fruits} value={value} onChange={setValue} placeholder="Search fruit" />
```

### Combobox props

| Name | Type | Default | Description |
| --- | --- | --- | --- |
| `label` | `string` | required | Visible label, associated with the input. Also names the listbox. |
| `options` | `ComboboxOption[]` | required | `{ value: string; label: string; disabled?: boolean }`. |
| `value` | `string \| null` | required | Selected option value. `null`, or a value that matches no option, shows an empty input. Controlled only. |
| `onChange` | `(value: string \| null) => void` | required | Called when an option is chosen, or with `null` when the text is cleared and the input is closed. |
| `placeholder` | `string` | — | Forwarded to the input. |
| `...rest` | `ComponentPropsWithoutRef<"input">` | — | Forwarded to the `input[role="combobox"]`. `value`, `onChange`, `role` and `type` are fixed or excluded. |

Choices:

- **Matching:** case-insensitive substring match on the label. The text is never treated as a regular expression. An empty filter shows all options.
- **Opening:** typing, ArrowDown, ArrowUp and Alt+ArrowDown open the listbox. Focusing or clicking the input alone does not open it.
- **Active option:** ArrowDown from closed activates the first enabled option, ArrowUp activates the last. Disabled options are skipped.
- **Wrapping:** ArrowDown and ArrowUp wrap at both ends of the enabled options.
- **Escape and blur:** Escape closes the listbox and restores the selected label. Blur does the same. Neither calls `onChange` unless the clear rule below applies.
- **Clearing to null:** if the text is emptied and the input is then closed by blur or by Enter with no active option, `onChange(null)` is called (only when a value was selected). The input stays empty. Escape never clears the value.
- **Escape inside a Dialog:** while the listbox is open, Escape calls `stopPropagation`, so only the listbox closes. When the listbox is closed, Escape is not stopped and reaches the dialog.
- **No results:** when the filter matches nothing, a "No results" message is shown inside the listbox as a non-option `li role="presentation"`. It is not focusable and is never set as `aria-activedescendant`.
- **Options change while open:** if the active option is removed, `aria-activedescendant` is removed too.
- The listbox is always in the DOM (hidden when closed), so `aria-controls` always points at an existing element.

### Combobox keyboard

| Key | Action |
| --- | --- |
| `ArrowDown` / `Alt+ArrowDown` | Opens the listbox if closed; moves the active option to the next enabled option (wraps). |
| `ArrowUp` | Opens the listbox if closed; moves the active option to the previous enabled option (wraps). |
| `Enter` | With an active option: selects it, closes the listbox and sets the text to its label. With no active option and the listbox open: closes it (clearing the value if the text is empty) and does not submit an enclosing form. |
| `Escape` | With the listbox open: closes it, restores the selected label, and stops propagation. With it closed: not handled, so it reaches the parent (for example, a Dialog). |
| `Tab` | Moves focus away; the input blurs and the listbox closes. |

Clicking an enabled option selects it. Clicking a disabled option does nothing. The input keeps focus during the click.

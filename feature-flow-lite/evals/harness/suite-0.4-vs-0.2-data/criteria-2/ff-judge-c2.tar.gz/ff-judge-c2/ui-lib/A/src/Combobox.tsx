import {
  useId,
  useState,
  type ComponentPropsWithoutRef,
  type FocusEvent,
  type KeyboardEvent,
} from "react";

export type ComboboxOption = { value: string; label: string; disabled?: boolean };

export type ComboboxProps = Omit<
  ComponentPropsWithoutRef<"input">,
  "value" | "onChange" | "role" | "type"
> & {
  label: string;
  options: ComboboxOption[];
  /** Selected option value, or `null` for no selection. */
  value: string | null;
  onChange: (value: string | null) => void;
};

/** Index of the next enabled option from `from` in `step` direction, wrapping. */
function stepEnabled(options: ComboboxOption[], from: number, step: 1 | -1): number | null {
  const count = options.length;
  for (let offset = 1; offset <= count; offset++) {
    const index = (((from + step * offset) % count) + count) % count;
    if (!options[index].disabled) return index;
  }
  return null;
}

function optionIdFor(baseId: string, value: string): string {
  return `${baseId}-option-${encodeURIComponent(value)}`;
}

export function Combobox({
  label,
  options,
  value,
  onChange,
  className,
  onKeyDown,
  onBlur,
  onClick,
  ...rest
}: ComboboxProps) {
  const baseId = useId();
  const inputId = `${baseId}-input`;
  const labelId = `${baseId}-label`;
  const listboxId = `${baseId}-listbox`;

  // null means the user is not editing: the input shows the selected label.
  const [editText, setEditText] = useState<string | null>(null);
  const [open, setOpen] = useState(false);
  const [activeIndex, setActiveIndex] = useState<number | null>(null);
  const [prevValue, setPrevValue] = useState(value);

  // A parent-driven value change discards any in-progress edit so the input shows the new label.
  if (value !== prevValue) {
    setPrevValue(value);
    setEditText(null);
    setOpen(false);
    setActiveIndex(null);
  }

  const selectedOption = options.find((option) => option.value === value);
  const query = editText ?? "";
  const visible =
    query === ""
      ? options
      : options.filter((option) => option.label.toLowerCase().includes(query.toLowerCase()));
  const active =
    activeIndex !== null && activeIndex < visible.length && !visible[activeIndex].disabled
      ? activeIndex
      : null;
  const activeOption = active === null ? undefined : visible[active];
  const text = editText ?? selectedOption?.label ?? "";

  const close = () => {
    setOpen(false);
    setActiveIndex(null);
    setEditText(null);
  };

  const choose = (option: ComboboxOption) => {
    onChange(option.value);
    close();
  };

  const initialActive = () => {
    const selectedIndex =
      editText === null ? visible.findIndex((option) => option.value === value) : -1;
    return selectedIndex !== -1 && !visible[selectedIndex].disabled
      ? selectedIndex
      : stepEnabled(visible, -1, 1);
  };

  const handleKeyDown = (event: KeyboardEvent<HTMLInputElement>) => {
    onKeyDown?.(event);
    switch (event.key) {
      case "ArrowDown":
      case "ArrowUp": {
        event.preventDefault();
        if (!open) {
          setOpen(true);
          setActiveIndex(initialActive());
          return;
        }
        const step = event.key === "ArrowDown" ? 1 : -1;
        const from = active ?? (step === 1 ? -1 : visible.length);
        setActiveIndex(stepEnabled(visible, from, step));
        return;
      }
      case "Enter":
        if (open && activeOption !== undefined) {
          event.preventDefault();
          choose(activeOption);
        } else if (editText === "" && value !== null) {
          event.preventDefault();
          onChange(null);
          close();
        }
        return;
      case "Escape":
        if (!open) return;
        // Stop here so an enclosing Dialog stays open while the listbox closes.
        event.stopPropagation();
        close();
        return;
    }
  };

  const handleBlur = (event: FocusEvent<HTMLInputElement>) => {
    onBlur?.(event);
    if (editText === "" && value !== null) onChange(null);
    close();
  };

  return (
    <>
      <label id={labelId} htmlFor={inputId}>
        {label}
      </label>
      <input
        {...rest}
        id={inputId}
        role="combobox"
        type="text"
        className={className}
        value={text}
        autoComplete="off"
        aria-autocomplete="list"
        aria-expanded={open}
        aria-controls={listboxId}
        aria-activedescendant={
          activeOption !== undefined ? optionIdFor(baseId, activeOption.value) : undefined
        }
        onChange={(event) => {
          setEditText(event.target.value);
          setOpen(true);
          setActiveIndex(null);
        }}
        onClick={(event) => {
          onClick?.(event);
          setOpen(true);
        }}
        onKeyDown={handleKeyDown}
        onBlur={handleBlur}
      />
      <ul id={listboxId} role="listbox" aria-labelledby={labelId} hidden={!open}>
        {visible.map((option, index) => (
          <li
            key={option.value}
            id={optionIdFor(baseId, option.value)}
            role="option"
            aria-selected={option.value === value}
            aria-disabled={option.disabled ? true : undefined}
            data-active={index === active ? true : undefined}
            onMouseDown={(event) => event.preventDefault()}
            onClick={() => {
              if (!option.disabled) choose(option);
            }}
          >
            {option.label}
          </li>
        ))}
      </ul>
      {open && visible.length === 0 && <p>No results</p>}
    </>
  );
}

// Id-safe and injective: "_" is escaped too, so each encoded value decodes to exactly one input.
export function encodeId(value: string): string {
  let encoded = "";
  for (const char of value) {
    encoded += /^[A-Za-z0-9-]$/.test(char) ? char : `_${char.codePointAt(0)!.toString(16)}_`;
  }
  return encoded;
}

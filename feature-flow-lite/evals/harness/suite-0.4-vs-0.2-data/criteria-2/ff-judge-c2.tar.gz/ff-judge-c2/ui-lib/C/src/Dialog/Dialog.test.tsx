import { render, screen } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { useState, type ReactNode } from "react";
import { Dialog, type DialogProps } from "./Dialog";

function Harness({ children, ...props }: Partial<DialogProps> & { children?: ReactNode }) {
  const [open, setOpen] = useState(false);
  return (
    <>
      <button onClick={() => setOpen(true)}>Open</button>
      <Dialog open={open} onOpenChange={setOpen} title="Edit" {...props}>
        {children ?? <input aria-label="Name" />}
      </Dialog>
    </>
  );
}

function NestedDialogs() {
  const [outer, setOuter] = useState(false);
  const [inner, setInner] = useState(false);
  return (
    <>
      <button onClick={() => setOuter(true)}>Open outer</button>
      <Dialog open={outer} onOpenChange={setOuter} title="Outer">
        <button onClick={() => setInner(true)}>Open inner</button>
        <Dialog open={inner} onOpenChange={setInner} title="Inner">
          <input aria-label="Inner input" />
          <button>Inner button</button>
        </Dialog>
      </Dialog>
    </>
  );
}

describe("Dialog", () => {
  it("renders nothing when closed", () => {
    render(<Dialog open={false} onOpenChange={() => {}} title="Hidden" />);
    expect(screen.queryByRole("dialog")).toBeNull();
  });

  it("renders a modal dialog into document.body labelled by its title and described by its description", () => {
    const { container } = render(
      <Dialog open onOpenChange={() => {}} title="Save" description="Are you sure?">
        <button>OK</button>
      </Dialog>,
    );
    const dialog = screen.getByRole("dialog", { name: "Save" });
    expect(dialog).toHaveAttribute("aria-modal", "true");
    expect(dialog).toHaveAccessibleDescription("Are you sure?");
    expect(screen.getByRole("heading", { name: "Save" })).toBeInTheDocument();
    expect(container).toBeEmptyDOMElement();
    expect(dialog.closest("body")).toBe(document.body);
  });

  it("has no aria-describedby when no description is given", () => {
    render(<Dialog open onOpenChange={() => {}} title="Save" />);
    expect(screen.getByRole("dialog")).not.toHaveAttribute("aria-describedby");
  });

  it("does not render the title prop as an HTML title attribute", () => {
    render(<Dialog open onOpenChange={() => {}} title="Save" />);
    expect(screen.getByRole("dialog")).not.toHaveAttribute("title");
    expect(document.querySelector("[title]")).toBeNull();
  });

  it("moves focus to the first focusable element on open", () => {
    render(
      <Dialog open onOpenChange={() => {}} title="Form">
        <button disabled>Disabled</button>
        <input aria-label="Name" />
        <button>Save</button>
      </Dialog>,
    );
    expect(screen.getByRole("textbox", { name: "Name" })).toHaveFocus();
  });

  it("focuses the dialog itself when it has no focusable children", () => {
    render(
      <Dialog open onOpenChange={() => {}} title="Notice">
        <button disabled>Disabled</button>
        <button tabIndex={-1}>Skipped</button>
      </Dialog>,
    );
    expect(screen.getByRole("dialog")).toHaveFocus();
  });

  it("keeps focus on the dialog when Tab is pressed and it has no focusable children", async () => {
    const user = userEvent.setup();
    render(
      <Dialog open onOpenChange={() => {}} title="Notice">
        <button disabled>Disabled</button>
      </Dialog>,
    );
    await user.tab();
    expect(screen.getByRole("dialog")).toHaveFocus();
    await user.tab({ shift: true });
    expect(screen.getByRole("dialog")).toHaveFocus();
  });

  it("wraps Tab from the last focusable element to the first", async () => {
    const user = userEvent.setup();
    render(
      <Dialog open onOpenChange={() => {}} title="Form">
        <button>First</button>
        <button>Last</button>
      </Dialog>,
    );
    screen.getByRole("button", { name: "Last" }).focus();
    await user.tab();
    expect(screen.getByRole("button", { name: "First" })).toHaveFocus();
  });

  it("wraps Shift+Tab from the first focusable element and from the dialog container to the last", async () => {
    const user = userEvent.setup();
    render(
      <Dialog open onOpenChange={() => {}} title="Form">
        <button>First</button>
        <button>Last</button>
      </Dialog>,
    );
    await user.tab({ shift: true });
    expect(screen.getByRole("button", { name: "Last" })).toHaveFocus();
    screen.getByRole("dialog").focus();
    await user.tab({ shift: true });
    expect(screen.getByRole("button", { name: "Last" })).toHaveFocus();
  });

  it("calls onOpenChange(false) on Escape", async () => {
    const user = userEvent.setup();
    const onOpenChange = vi.fn();
    render(<Dialog open onOpenChange={onOpenChange} title="Form" />);
    await user.keyboard("{Escape}");
    expect(onOpenChange).toHaveBeenCalledTimes(1);
    expect(onOpenChange).toHaveBeenCalledWith(false);
  });

  it("calls onOpenChange(false) on Escape pressed in a nested input", async () => {
    const user = userEvent.setup();
    const onOpenChange = vi.fn();
    render(
      <Dialog open onOpenChange={onOpenChange} title="Form">
        <input aria-label="Name" />
      </Dialog>,
    );
    await user.keyboard("{Escape}");
    expect(onOpenChange).toHaveBeenCalledWith(false);
  });

  it("calls onOpenChange(false) when the backdrop is clicked", async () => {
    const user = userEvent.setup();
    const onOpenChange = vi.fn();
    render(<Dialog open onOpenChange={onOpenChange} title="Form" />);
    await user.click(document.querySelector("[data-dialog-backdrop]") as HTMLElement);
    expect(onOpenChange).toHaveBeenCalledWith(false);
  });

  it("does not close when clicking inside the dialog", async () => {
    const user = userEvent.setup();
    const onOpenChange = vi.fn();
    render(<Dialog open onOpenChange={onOpenChange} title="Form">Body text</Dialog>);
    await user.click(screen.getByText("Body text"));
    await user.click(screen.getByRole("heading", { name: "Form" }));
    expect(onOpenChange).not.toHaveBeenCalled();
  });

  it("does not close when a mousedown inside ends outside the dialog", async () => {
    const user = userEvent.setup();
    const onOpenChange = vi.fn();
    render(<Dialog open onOpenChange={onOpenChange} title="Form">Body text</Dialog>);
    const backdrop = document.querySelector("[data-dialog-backdrop]") as HTMLElement;
    await user.pointer([
      { keys: "[MouseLeft>]", target: screen.getByText("Body text") },
      { target: backdrop },
      { keys: "[/MouseLeft]", target: backdrop },
    ]);
    expect(onOpenChange).not.toHaveBeenCalled();
  });

  it("returns focus to the previously focused element when closed", async () => {
    const user = userEvent.setup();
    render(<Harness />);
    const trigger = screen.getByRole("button", { name: "Open" });
    await user.click(trigger);
    expect(screen.getByRole("textbox", { name: "Name" })).toHaveFocus();
    await user.keyboard("{Escape}");
    expect(screen.queryByRole("dialog")).toBeNull();
    expect(trigger).toHaveFocus();
  });

  it("returns focus to the previously focused element when unmounted while open", () => {
    const trigger = document.createElement("button");
    document.body.appendChild(trigger);
    trigger.focus();
    const { unmount } = render(<Dialog open onOpenChange={() => {}} title="Form" />);
    expect(screen.getByRole("dialog")).toHaveFocus();
    unmount();
    expect(trigger).toHaveFocus();
    trigger.remove();
  });

  it("does not crash on close when nothing was focused before opening", () => {
    (document.activeElement as HTMLElement | null)?.blur();
    const { unmount } = render(<Dialog open onOpenChange={() => {}} title="Form" />);
    expect(() => unmount()).not.toThrow();
  });

  it("stays open when a controlled parent ignores onOpenChange(false)", async () => {
    const user = userEvent.setup();
    const onOpenChange = vi.fn();
    render(<Dialog open onOpenChange={onOpenChange} title="Form" />);
    await user.keyboard("{Escape}");
    expect(onOpenChange).toHaveBeenCalledWith(false);
    expect(screen.getByRole("dialog")).toBeInTheDocument();
  });

  it("keeps ids unique across two open instances", () => {
    render(
      <>
        <Dialog open onOpenChange={() => {}} title="One" description="First" />
        <Dialog open onOpenChange={() => {}} title="Two" description="Second" />
      </>,
    );
    const [first, second] = screen.getAllByRole("dialog");
    expect(first.getAttribute("aria-labelledby")).not.toBe(second.getAttribute("aria-labelledby"));
    expect(first.getAttribute("aria-describedby")).not.toBe(second.getAttribute("aria-describedby"));
  });

  it("keeps Tab inside when focus was lost to body", async () => {
    const user = userEvent.setup();
    render(
      <>
        <button>Outside</button>
        <Dialog open onOpenChange={() => {}} title="Form">
          <button>Inside</button>
        </Dialog>
      </>,
    );
    screen.getByRole("button", { name: "Inside" }).blur();
    expect(document.body).toHaveFocus();
    await user.tab();
    expect(screen.getByRole("button", { name: "Inside" })).toHaveFocus();
  });

  it("keeps Shift+Tab inside when focus was lost to body", async () => {
    const user = userEvent.setup();
    render(
      <>
        <button>Outside</button>
        <Dialog open onOpenChange={() => {}} title="Form">
          <button>First</button>
          <button>Last</button>
        </Dialog>
      </>,
    );
    screen.getByRole("button", { name: "First" }).blur();
    await user.tab({ shift: true });
    expect(screen.getByRole("button", { name: "Last" })).toHaveFocus();
  });

  it("pulls focus back in when an outside element is focused", () => {
    render(
      <>
        <button>Outside</button>
        <Dialog open onOpenChange={() => {}} title="Form">
          <button>Inside</button>
        </Dialog>
      </>,
    );
    screen.getByRole("button", { name: "Outside" }).focus();
    expect(screen.getByRole("button", { name: "Inside" })).toHaveFocus();
  });

  it("keeps focus inside after a backdrop click that the parent ignores", async () => {
    const user = userEvent.setup();
    render(
      <>
        <button>Outside</button>
        <Dialog open onOpenChange={() => {}} title="Form">
          <button>Inside</button>
        </Dialog>
      </>,
    );
    await user.click(document.querySelector("[data-dialog-backdrop]")!);
    await user.tab();
    expect(screen.getByRole("button", { name: "Inside" })).toHaveFocus();
  });

  it("keeps focus in the innermost of two open dialogs without looping", async () => {
    const user = userEvent.setup();
    render(
      <>
        <Dialog open onOpenChange={() => {}} title="Outer">
          <button>Outer action</button>
        </Dialog>
        <Dialog open onOpenChange={() => {}} title="Inner">
          <button>Inner action</button>
        </Dialog>
      </>,
    );
    expect(screen.getByRole("button", { name: "Inner action" })).toHaveFocus();
    screen.getByRole("button", { name: "Inner action" }).blur();
    await user.tab();
    expect(screen.getByRole("button", { name: "Inner action" })).toHaveFocus();
  });

  it("keeps focus on the dialog element when Tab is pressed with no focusable children", async () => {
    const user = userEvent.setup();
    render(
      <>
        <button>Outside</button>
        <Dialog open onOpenChange={() => {}} title="Form" />
      </>,
    );
    (document.activeElement as HTMLElement).blur();
    await user.tab();
    expect(screen.getByRole("dialog")).toHaveFocus();
  });

  it("restores focus to the trigger on close after the focus trap was active", async () => {
    const user = userEvent.setup();
    render(<Harness />);
    await user.click(screen.getByRole("button", { name: "Open" }));
    await user.keyboard("{Escape}");
    expect(screen.queryByRole("dialog")).toBeNull();
    expect(screen.getByRole("button", { name: "Open" })).toHaveFocus();
  });

  it("closes only the inner of two nested dialogs on Escape, then the outer on a second Escape", async () => {
    const user = userEvent.setup();
    render(<NestedDialogs />);
    await user.click(screen.getByRole("button", { name: "Open outer" }));
    await user.click(screen.getByRole("button", { name: "Open inner" }));
    await user.keyboard("{Escape}");
    expect(screen.queryByRole("dialog", { name: "Inner" })).toBeNull();
    expect(screen.getByRole("dialog", { name: "Outer" })).toBeInTheDocument();
    expect(screen.getByRole("button", { name: "Open inner" })).toHaveFocus();
    await user.keyboard("{Escape}");
    expect(screen.queryByRole("dialog", { name: "Outer" })).toBeNull();
  });

  it("keeps Tab wrapping inside the inner of two nested dialogs", async () => {
    const user = userEvent.setup();
    render(<NestedDialogs />);
    await user.click(screen.getByRole("button", { name: "Open outer" }));
    await user.click(screen.getByRole("button", { name: "Open inner" }));
    expect(screen.getByRole("textbox", { name: "Inner input" })).toHaveFocus();
    await user.tab();
    expect(screen.getByRole("button", { name: "Inner button" })).toHaveFocus();
    await user.tab();
    expect(screen.getByRole("textbox", { name: "Inner input" })).toHaveFocus();
    expect(screen.getByRole("dialog", { name: "Outer" })).toBeInTheDocument();
  });
});

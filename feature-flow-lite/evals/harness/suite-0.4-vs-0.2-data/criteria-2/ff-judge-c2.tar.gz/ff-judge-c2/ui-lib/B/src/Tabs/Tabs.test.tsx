import { StrictMode } from "react";
import { fireEvent, render, screen } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { Tab, TabList, TabPanel, Tabs, type TabsProps } from "./Tabs";

function Example({ disabled = [], ...tabsProps }: Omit<TabsProps, "children"> & { disabled?: string[] }) {
  const values = ["one", "two", "three"];
  return (
    <Tabs {...tabsProps}>
      <TabList aria-label="Demo">
        {values.map((value) => (
          <Tab key={value} value={value} disabled={disabled.includes(value)}>
            {value}
          </Tab>
        ))}
      </TabList>
      {values.map((value) => (
        <TabPanel key={value} value={value}>
          panel {value}
        </TabPanel>
      ))}
    </Tabs>
  );
}

const tab = (name: string) => screen.getByRole("tab", { name });

describe("Tabs", () => {
  it("uses defaultValue, or the first enabled tab, as the uncontrolled selection", () => {
    const { unmount } = render(<Example defaultValue="two" />);
    expect(tab("two")).toHaveAttribute("aria-selected", "true");
    unmount();

    render(<Example disabled={["one"]} />);
    expect(tab("two")).toHaveAttribute("aria-selected", "true");
    expect(tab("one")).toHaveAttribute("aria-selected", "false");
  });

  it("calls onValueChange on user selection in uncontrolled mode, not when the tab is already selected", async () => {
    const user = userEvent.setup();
    const onValueChange = vi.fn();
    render(<Example onValueChange={onValueChange} />);

    await user.click(tab("one"));
    expect(onValueChange).not.toHaveBeenCalled();

    await user.click(tab("two"));
    expect(onValueChange).toHaveBeenCalledTimes(1);
    expect(onValueChange).toHaveBeenCalledWith("two");
    expect(tab("two")).toHaveAttribute("aria-selected", "true");
  });

  it("changes selection in controlled mode only when the owner updates value", async () => {
    const user = userEvent.setup();
    const onValueChange = vi.fn();
    const { rerender } = render(<Example value="one" onValueChange={onValueChange} />);

    await user.click(tab("two"));
    expect(onValueChange).toHaveBeenCalledWith("two");
    expect(tab("one")).toHaveAttribute("aria-selected", "true");
    expect(tab("two")).toHaveAttribute("aria-selected", "false");

    rerender(<Example value="two" onValueChange={onValueChange} />);
    expect(tab("two")).toHaveAttribute("aria-selected", "true");
  });

  it("renders the tablist with its label and horizontal orientation", () => {
    render(<Example />);
    const list = screen.getByRole("tablist", { name: "Demo" });
    expect(list).toHaveAttribute("aria-orientation", "horizontal");
  });

  it("wires tab and panel ids and aria attributes, and puts one tab in the tab order", () => {
    render(<Example defaultValue="one" disabled={["three"]} />);
    const selected = tab("one");
    const panel = screen.getByRole("tabpanel", { name: "one" });

    expect(panel).toHaveAttribute("aria-labelledby", selected.id);
    expect(selected).toHaveAttribute("aria-controls", panel.id);
    expect(panel).toHaveAttribute("tabindex", "0");
    expect(selected).toHaveAttribute("tabindex", "0");
    expect(tab("two")).toHaveAttribute("tabindex", "-1");
    expect(screen.getByText("panel two")).toHaveAttribute("hidden");
    expect(tab("three")).toBeDisabled();
    expect(tab("three")).toHaveAttribute("aria-disabled", "true");
  });

  it("gives the first enabled tab tabIndex 0 when controlled value matches no tab", () => {
    render(<Example value="missing" disabled={["one"]} />);
    expect(tab("one")).toHaveAttribute("tabindex", "-1");
    expect(tab("two")).toHaveAttribute("tabindex", "0");
    expect(tab("two")).toHaveAttribute("aria-selected", "false");
  });

  it("does not select a disabled tab by click", async () => {
    const user = userEvent.setup();
    const onValueChange = vi.fn();
    render(<Example disabled={["two"]} onValueChange={onValueChange} />);
    await user.click(tab("two"));
    expect(onValueChange).not.toHaveBeenCalled();
    expect(tab("two")).toHaveAttribute("aria-selected", "false");
  });

  it("moves focus and selection with arrow keys, wrapping and skipping disabled tabs", async () => {
    const user = userEvent.setup();
    const onValueChange = vi.fn();
    render(<Example defaultValue="one" disabled={["two"]} onValueChange={onValueChange} />);
    tab("one").focus();

    await user.keyboard("{ArrowRight}");
    expect(tab("three")).toHaveFocus();
    expect(tab("three")).toHaveAttribute("aria-selected", "true");

    await user.keyboard("{ArrowRight}");
    expect(tab("one")).toHaveFocus();

    await user.keyboard("{ArrowLeft}");
    expect(tab("three")).toHaveFocus();
    expect(onValueChange.mock.calls).toEqual([["three"], ["one"], ["three"]]);
  });

  it("moves to the first and last enabled tabs with Home and End, and ignores other keys", () => {
    render(<Example defaultValue="two" disabled={["one"]} />);
    const two = tab("two");
    two.focus();

    expect(fireEvent.keyDown(two, { key: "End" })).toBe(false);
    expect(tab("three")).toHaveFocus();

    expect(fireEvent.keyDown(tab("three"), { key: "Home" })).toBe(false);
    expect(tab("two")).toHaveFocus();

    expect(fireEvent.keyDown(tab("two"), { key: "a" })).toBe(true);
    expect(tab("two")).toHaveFocus();
  });

  it("selects and focuses a tab on click", async () => {
    const user = userEvent.setup();
    render(<Example />);
    await user.click(tab("three"));
    expect(tab("three")).toHaveFocus();
    expect(tab("three")).toHaveAttribute("aria-selected", "true");
  });

  it("keeps focus in place when every other tab is disabled", async () => {
    const user = userEvent.setup();
    const onValueChange = vi.fn();
    render(<Example defaultValue="one" disabled={["two", "three"]} onValueChange={onValueChange} />);
    tab("one").focus();

    await user.keyboard("{ArrowRight}");
    await user.keyboard("{End}");
    expect(tab("one")).toHaveFocus();
    expect(onValueChange).not.toHaveBeenCalled();
  });

  it("keeps focus on the current tab with Home and End when the end tabs are disabled", () => {
    render(<Example defaultValue="two" disabled={["one", "three"]} />);
    tab("two").focus();
    fireEvent.keyDown(tab("two"), { key: "Home" });
    expect(tab("two")).toHaveFocus();
    fireEvent.keyDown(tab("two"), { key: "End" });
    expect(tab("two")).toHaveFocus();
  });

  it("cycles only the inner tabs when a Tabs is nested in another Tabs panel", async () => {
    const user = userEvent.setup();
    render(
      <Tabs defaultValue="outer-a">
        <TabList aria-label="Outer">
          <Tab value="outer-a">outer-a</Tab>
          <Tab value="outer-b">outer-b</Tab>
        </TabList>
        <TabPanel value="outer-a">
          <Tabs defaultValue="inner-1">
            <TabList aria-label="Inner">
              <Tab value="inner-1">inner-1</Tab>
              <Tab value="inner-2">inner-2</Tab>
            </TabList>
            <TabPanel value="inner-1">first</TabPanel>
            <TabPanel value="inner-2">second</TabPanel>
          </Tabs>
        </TabPanel>
        <TabPanel value="outer-b">other</TabPanel>
      </Tabs>,
    );
    tab("inner-1").focus();

    await user.keyboard("{ArrowRight}");
    expect(tab("inner-2")).toHaveFocus();
    await user.keyboard("{ArrowRight}");
    expect(tab("inner-1")).toHaveFocus();
    expect(tab("outer-a")).toHaveAttribute("aria-selected", "true");
  });

  it("handles values with spaces and quotes in ids and keyboard navigation", async () => {
    const user = userEvent.setup();
    render(
      <Tabs defaultValue='a b'>
        <TabList aria-label="Odd">
          <Tab value="a b">a b</Tab>
          <Tab value={'c"d'}>c&quot;d</Tab>
        </TabList>
        <TabPanel value="a b">first</TabPanel>
        <TabPanel value={'c"d'}>second</TabPanel>
      </Tabs>,
    );
    const first = tab("a b");
    const panel = screen.getByRole("tabpanel", { name: "a b" });
    expect(document.getElementById(first.getAttribute("aria-controls")!)).toBe(panel);
    expect(document.getElementById(panel.getAttribute("aria-labelledby")!)).toBe(first);

    first.focus();
    await user.keyboard("{ArrowRight}");
    expect(screen.getByRole("tab", { name: 'c"d' })).toHaveFocus();
  });

  it("includes a tab added later in keyboard order", async () => {
    const user = userEvent.setup();
    function Late({ show }: { show: boolean }) {
      return (
        <Tabs defaultValue="one">
          <TabList aria-label="Late">
            <Tab value="one">one</Tab>
            {show && <Tab value="two">two</Tab>}
          </TabList>
        </Tabs>
      );
    }
    const { rerender } = render(<Late show={false} />);
    rerender(<Late show />);
    tab("one").focus();
    await user.keyboard("{ArrowRight}");
    expect(tab("two")).toHaveFocus();
  });

  it("renders ids that resolve for a lone surrogate value and a value with a space", () => {
    render(
      <Tabs defaultValue={"\uD800"}>
        <TabList aria-label="Ids">
          <Tab value={"\uD800"}>lone</Tab>
          <Tab value="a b">spaced</Tab>
        </TabList>
        <TabPanel value={"\uD800"}>lone panel</TabPanel>
        <TabPanel value="a b">spaced panel</TabPanel>
      </Tabs>,
    );
    const lonePanel = screen.getByText("lone panel");
    const spacedPanel = screen.getByText("spaced panel");
    expect(document.getElementById(tab("lone").getAttribute("aria-controls")!)).toBe(lonePanel);
    expect(document.getElementById(lonePanel.getAttribute("aria-labelledby")!)).toBe(tab("lone"));
    expect(document.getElementById(tab("spaced").getAttribute("aria-controls")!)).toBe(spacedPanel);
    expect(document.getElementById(spacedPanel.getAttribute("aria-labelledby")!)).toBe(tab("spaced"));
  });

  it("gives distinct ids to values '_20_' and ' '", () => {
    render(
      <Tabs>
        <TabList aria-label="Distinct">
          <Tab value="_20_">underscores</Tab>
          <Tab value=" ">space</Tab>
        </TabList>
        <TabPanel value="_20_">first panel</TabPanel>
        <TabPanel value=" ">second panel</TabPanel>
      </Tabs>,
    );
    expect(tab("underscores").id).not.toBe(tab("space").id);
    expect(screen.getByText("first panel").id).not.toBe(screen.getByText("second panel").id);
  });

  it("selects the first enabled tab when defaultValue names a disabled tab", () => {
    const onValueChange = vi.fn();
    render(<Example defaultValue="one" disabled={["one"]} onValueChange={onValueChange} />);
    expect(tab("two")).toHaveAttribute("aria-selected", "true");
    expect(tab("one")).toHaveAttribute("aria-selected", "false");
    expect(screen.getByRole("tabpanel", { name: "two" })).toBeVisible();
    expect(screen.getByText("panel one")).toHaveAttribute("hidden");
    expect(onValueChange).not.toHaveBeenCalled();
  });

  describe("removing the selected tab in uncontrolled mode", () => {
    function Removable({ showThree }: { showThree: boolean }) {
      return (
        <Tabs defaultValue="three">
          <TabList aria-label="Removable">
            <Tab value="one">one</Tab>
            <Tab value="two">two</Tab>
            {showThree && <Tab value="three">three</Tab>}
          </TabList>
          <TabPanel value="one">panel one</TabPanel>
          <TabPanel value="two">panel two</TabPanel>
          <TabPanel value="three">panel three</TabPanel>
        </Tabs>
      );
    }

    it("selects the first enabled tab and shows its panel when the selected tab is removed", () => {
      const { rerender } = render(<Removable showThree />);
      expect(tab("three")).toHaveAttribute("aria-selected", "true");

      rerender(<Removable showThree={false} />);
      expect(tab("one")).toHaveAttribute("aria-selected", "true");
      expect(tab("one")).toHaveAttribute("tabindex", "0");
      expect(tab("two")).toHaveAttribute("aria-selected", "false");
      expect(screen.getByRole("tabpanel", { name: "one" })).toBeVisible();
      expect(screen.getByText("panel two")).toHaveAttribute("hidden");
    });

    it("keeps the fallback tab selected when the removed tab is added back", () => {
      const { rerender } = render(<Removable showThree />);
      rerender(<Removable showThree={false} />);
      rerender(<Removable showThree />);

      expect(tab("one")).toHaveAttribute("aria-selected", "true");
      expect(tab("three")).toHaveAttribute("aria-selected", "false");
      expect(screen.getByText("panel three")).toHaveAttribute("hidden");
    });

    it("selects the fallback tab under StrictMode and keeps it when the tab is added back", () => {
      const { rerender } = render(
        <StrictMode>
          <Removable showThree />
        </StrictMode>,
      );
      rerender(
        <StrictMode>
          <Removable showThree={false} />
        </StrictMode>,
      );
      expect(tab("one")).toHaveAttribute("aria-selected", "true");
      expect(screen.getByRole("tabpanel", { name: "one" })).toBeVisible();

      rerender(
        <StrictMode>
          <Removable showThree />
        </StrictMode>,
      );
      expect(tab("one")).toHaveAttribute("aria-selected", "true");
      expect(tab("three")).toHaveAttribute("aria-selected", "false");
    });
  });
});

describe("Tab onClick", () => {
  it("calls a consumer onClick and still selects the tab", async () => {
    const user = userEvent.setup();
    const onClick = vi.fn();
    render(
      <Tabs>
        <TabList aria-label="Demo">
          <Tab value="a">A</Tab>
          <Tab value="b" onClick={onClick}>B</Tab>
        </TabList>
        <TabPanel value="a">Panel A</TabPanel>
        <TabPanel value="b">Panel B</TabPanel>
      </Tabs>,
    );
    await user.click(screen.getByRole("tab", { name: "B" }));
    expect(onClick).toHaveBeenCalledTimes(1);
    expect(screen.getByRole("tab", { name: "B" })).toHaveAttribute("aria-selected", "true");
  });
});

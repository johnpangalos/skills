import {
  useId,
  useLayoutEffect,
  useRef,
  type ComponentPropsWithoutRef,
  type KeyboardEvent,
  type ReactNode,
} from "react";
import { createPortal } from "react-dom";

const TABBABLE_SELECTOR =
  'a[href], button, input:not([type="hidden"]), select, textarea, [tabindex], [contenteditable="true"]';

function getTabbables(container: HTMLElement): HTMLElement[] {
  return Array.from(container.querySelectorAll<HTMLElement>(TABBABLE_SELECTOR)).filter(
    (element) =>
      !element.hasAttribute("disabled") &&
      element.getAttribute("aria-disabled") !== "true" &&
      element.tabIndex >= 0,
  );
}

export type DialogProps = Omit<ComponentPropsWithoutRef<"div">, "title"> & {
  open: boolean;
  /** Called with `false` on Escape or a backdrop click. The dialog never closes itself. */
  onOpenChange: (open: boolean) => void;
  title: ReactNode;
  description?: ReactNode;
  backdropClassName?: string;
};

export function Dialog({
  open,
  onOpenChange,
  title,
  description,
  backdropClassName,
  children,
  onKeyDown,
  ...rest
}: DialogProps) {
  const baseId = useId();
  const titleId = `${baseId}-title`;
  const descriptionId = `${baseId}-description`;
  const dialogRef = useRef<HTMLDivElement>(null);
  const pressStartedInside = useRef(false);

  useLayoutEffect(() => {
    if (!open) return;
    const dialog = dialogRef.current;
    if (!dialog) return;
    const previous = document.activeElement;
    (getTabbables(dialog)[0] ?? dialog).focus();
    return () => {
      if (previous instanceof HTMLElement && previous !== document.body && previous.isConnected) {
        previous.focus();
      }
    };
  }, [open]);

  if (!open) return null;

  const hasDescription = description !== undefined && description !== null;

  const handleKeyDown = (event: KeyboardEvent<HTMLDivElement>) => {
    onKeyDown?.(event);
    // Nested dialogs portal into body but bubble through the React tree; only handle keys from this dialog's DOM.
    if (!event.currentTarget.contains(event.target as Node)) return;
    // Stop propagation when handling a key so an enclosing Dialog does not also react to it.
    if (event.key === "Escape") {
      event.stopPropagation();
      onOpenChange(false);
      return;
    }
    if (event.key !== "Tab") return;

    const dialog = event.currentTarget;
    const tabbables = getTabbables(dialog);
    if (tabbables.length === 0) {
      event.preventDefault();
      event.stopPropagation();
      return;
    }
    const first = tabbables[0];
    const last = tabbables[tabbables.length - 1];
    const active = document.activeElement;
    if (event.shiftKey && (active === first || active === dialog)) {
      event.preventDefault();
      event.stopPropagation();
      last.focus();
    } else if (!event.shiftKey && active === last) {
      event.preventDefault();
      event.stopPropagation();
      first.focus();
    }
  };

  return createPortal(
    <div
      className={backdropClassName}
      onMouseDown={(event) => {
        pressStartedInside.current = dialogRef.current?.contains(event.target as Node) ?? false;
      }}
      onClick={(event) => {
        const startedInside = pressStartedInside.current;
        pressStartedInside.current = false;
        if (event.target === event.currentTarget && !startedInside) onOpenChange(false);
      }}
    >
      <div
        {...rest}
        ref={dialogRef}
        role="dialog"
        aria-modal="true"
        aria-labelledby={titleId}
        aria-describedby={hasDescription ? descriptionId : undefined}
        tabIndex={-1}
        onKeyDown={handleKeyDown}
      >
        <h2 id={titleId}>{title}</h2>
        {hasDescription && <p id={descriptionId}>{description}</p>}
        {children}
      </div>
    </div>,
    document.body,
  );
}

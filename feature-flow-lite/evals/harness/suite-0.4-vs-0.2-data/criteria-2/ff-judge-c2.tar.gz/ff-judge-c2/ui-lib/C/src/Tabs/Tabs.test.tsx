import { fireEvent, render, screen } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { useState } from "react";
import { Tab, TabList, TabPanel, Tabs, type TabsProps } from "./Tabs";

function TestTabs({
  values = ["one", "two", "three"],
  disabled = [],
  ...props
}: TabsProps & { values?: string[]; disabled?: string[] }) {
  return (
    <Tabs {...props}>
      <TabList aria-label="Sections">
        {values.map((value) => (
          <Tab key={value} value={value} disabled={disabled.includes(value)}>
            {value}
          </Tab>
        ))}
      </TabList>
      {values.map((value) => (
        <TabPanel key={value} value={value}>
          Content {value}
        </TabPanel>
      ))}
    </Tabs>
  );
}

const tab = (name: string) => screen.getByRole("tab", { name });

describe("Tabs", () => {
  it("selects the first non-disabled tab when uncontrolled without defaultValue", () => {
    render(<TestTabs disabled={["one"]} />);
    expect(tab("one")).toHaveAttribute("aria-selected", "false");
    expect(tab("two")).toHaveAttribute("aria-selected", "true");
  });

  it("selects defaultValue when uncontrolled", () => {
    render(<TestTabs defaultValue="three" />);
    expect(tab("three")).toHaveAttribute("aria-selected", "true");
    expect(tab("one")).toHaveAttribute("aria-selected", "false");
  });

  it("calls onValueChange once on click and not when the selected tab is clicked", async () => {
    const user = userEvent.setup();
    const onValueChange = vi.fn();
    render(<TestTabs defaultValue="one" onValueChange={onValueChange} />);
    await user.click(tab("two"));
    await user.click(tab("two"));
    expect(onValueChange).toHaveBeenCalledTimes(1);
    expect(onValueChange).toHaveBeenCalledWith("two");
    expect(tab("two")).toHaveAttribute("aria-selected", "true");
  });

  it("does not change selection when controlled and the parent ignores onValueChange", async () => {
    const user = userEvent.setup();
    const onValueChange = vi.fn();
    render(<TestTabs value="one" onValueChange={onValueChange} />);
    await user.click(tab("two"));
    tab("two").focus();
    await user.keyboard("{ArrowRight}");
    expect(onValueChange).toHaveBeenCalledWith("two");
    expect(onValueChange).toHaveBeenCalledWith("three");
    expect(tab("one")).toHaveAttribute("aria-selected", "true");
    expect(tab("two")).toHaveAttribute("aria-selected", "false");
  });

  it("renders a labelled horizontal tablist with linked tabs and panels", () => {
    render(<TestTabs defaultValue="one" />);
    const list = screen.getByRole("tablist", { name: "Sections" });
    expect(list).toHaveAttribute("aria-orientation", "horizontal");
    const panel = screen.getByRole("tabpanel");
    expect(panel).toHaveAttribute("aria-labelledby", tab("one").id);
    expect(tab("one")).toHaveAttribute("aria-controls", panel.id);
    expect(tab("one")).toHaveAttribute("type", "button");
    expect(panel).toHaveTextContent("Content one");
    expect(panel).toHaveAttribute("tabindex", "0");
  });

  it("renders only the selected panel content", () => {
    render(<TestTabs defaultValue="two" />);
    expect(screen.getByRole("tabpanel")).toHaveTextContent("Content two");
    expect(screen.queryByText("Content one")).toBeNull();
  });

  it("uses a roving tabindex with only the selected tab in the tab order", () => {
    render(<TestTabs defaultValue="two" />);
    expect(tab("one")).toHaveAttribute("tabindex", "-1");
    expect(tab("two")).toHaveAttribute("tabindex", "0");
    expect(tab("three")).toHaveAttribute("tabindex", "-1");
  });

  it("makes the first enabled tab the tab stop when the controlled value matches no tab", () => {
    render(<TestTabs value="missing" disabled={["one"]} />);
    expect(tab("one")).toHaveAttribute("tabindex", "-1");
    expect(tab("two")).toHaveAttribute("tabindex", "0");
    expect(tab("two")).toHaveAttribute("aria-selected", "false");
  });

  it("moves focus and selects with ArrowRight and ArrowLeft, wrapping and skipping disabled tabs", async () => {
    const user = userEvent.setup();
    const onValueChange = vi.fn();
    render(<TestTabs defaultValue="one" disabled={["two"]} onValueChange={onValueChange} />);
    tab("one").focus();
    await user.keyboard("{ArrowRight}");
    expect(tab("three")).toHaveFocus();
    expect(tab("three")).toHaveAttribute("aria-selected", "true");
    await user.keyboard("{ArrowRight}");
    expect(tab("one")).toHaveFocus();
    await user.keyboard("{ArrowLeft}");
    expect(tab("three")).toHaveFocus();
    expect(onValueChange.mock.calls).toEqual([["three"], ["one"], ["three"]]);
  });

  it("moves to the first and last enabled tabs with Home and End", async () => {
    const user = userEvent.setup();
    render(<TestTabs defaultValue="two" disabled={["one", "three"]} values={["one", "two", "three", "four"]} />);
    tab("two").focus();
    await user.keyboard("{End}");
    expect(tab("four")).toHaveFocus();
    await user.keyboard("{Home}");
    expect(tab("two")).toHaveFocus();
  });

  it("skips disabled first and last tabs for Home and End", async () => {
    const user = userEvent.setup();
    render(<TestTabs defaultValue="two" disabled={["one", "three"]} />);
    tab("two").focus();
    await user.keyboard("{End}");
    expect(tab("two")).toHaveFocus();
    await user.keyboard("{Home}");
    expect(tab("two")).toHaveFocus();
  });

  it("leaves focus in place when only one tab is enabled", async () => {
    const user = userEvent.setup();
    const onValueChange = vi.fn();
    render(<TestTabs defaultValue="two" disabled={["one", "three"]} onValueChange={onValueChange} />);
    tab("two").focus();
    await user.keyboard("{ArrowRight}{ArrowLeft}");
    expect(tab("two")).toHaveFocus();
    expect(onValueChange).not.toHaveBeenCalled();
  });

  it("ignores other keys and does not prevent their default", () => {
    render(<TestTabs defaultValue="one" />);
    const notPrevented = fireEvent.keyDown(tab("one"), { key: "a" });
    expect(notPrevented).toBe(true);
    expect(tab("one")).toHaveAttribute("aria-selected", "true");
  });

  it("prevents the default for handled keys", () => {
    render(<TestTabs defaultValue="one" />);
    expect(fireEvent.keyDown(tab("one"), { key: "ArrowRight" })).toBe(false);
  });

  it("navigates in DOM order after tabs are added, removed and reordered", async () => {
    const user = userEvent.setup();
    const { rerender } = render(<TestTabs defaultValue="one" values={["one", "two"]} />);
    rerender(<TestTabs defaultValue="one" values={["two", "four", "one"]} />);
    tab("one").focus();
    await user.keyboard("{ArrowRight}");
    expect(tab("two")).toHaveFocus();
    await user.keyboard("{ArrowRight}");
    expect(tab("four")).toHaveFocus();
    await user.keyboard("{End}");
    expect(tab("one")).toHaveFocus();
  });

  it("selects a tab on click when the controlled parent updates value", async () => {
    const user = userEvent.setup();
    function Controlled() {
      const [value, setValue] = useState("one");
      return <TestTabs value={value} onValueChange={setValue} />;
    }
    render(<Controlled />);
    await user.click(tab("three"));
    expect(tab("three")).toHaveAttribute("aria-selected", "true");
    expect(screen.getByRole("tabpanel")).toHaveTextContent("Content three");
  });

  it("keeps ids unique and state independent across two instances", async () => {
    const user = userEvent.setup();
    render(
      <>
        <TestTabs defaultValue="one" />
        <TestTabs defaultValue="one" />
      </>,
    );
    const [first, second] = screen.getAllByRole("tablist");
    const firstTabs = first.querySelectorAll('[role="tab"]');
    const secondTabs = second.querySelectorAll('[role="tab"]');
    expect(firstTabs[0].id).not.toBe(secondTabs[0].id);
    await user.click(screen.getAllByRole("tab", { name: "two" })[0]);
    expect(screen.getAllByRole("tab", { name: "two" })[0]).toHaveAttribute("aria-selected", "true");
    expect(screen.getAllByRole("tab", { name: "two" })[1]).toHaveAttribute("aria-selected", "false");
  });

  it("throws when a tab is rendered outside Tabs", () => {
    vi.spyOn(console, "error").mockImplementation(() => {});
    expect(() => render(<Tab value="x">x</Tab>)).toThrow("Tab must be rendered inside <Tabs>");
  });

  it("sets aria-controls only on tabs whose panel is rendered", () => {
    render(
      <Tabs defaultValue="one">
        <TabList aria-label="Sections">
          <Tab value="one">one</Tab>
          <Tab value="orphan">orphan</Tab>
        </TabList>
        <TabPanel value="one">Content one</TabPanel>
      </Tabs>,
    );
    const controls = tab("one").getAttribute("aria-controls");
    expect(controls).not.toBeNull();
    expect(document.getElementById(controls!)).toHaveAttribute("role", "tabpanel");
    expect(tab("orphan")).not.toHaveAttribute("aria-controls");
  });

  it("drops aria-controls when its panel is unmounted", () => {
    const { rerender } = render(
      <Tabs defaultValue="one">
        <TabList aria-label="Sections">
          <Tab value="one">one</Tab>
        </TabList>
        <TabPanel value="one">Content one</TabPanel>
      </Tabs>,
    );
    expect(tab("one")).toHaveAttribute("aria-controls");
    rerender(
      <Tabs defaultValue="one">
        <TabList aria-label="Sections">
          <Tab value="one">one</Tab>
        </TabList>
      </Tabs>,
    );
    expect(tab("one")).not.toHaveAttribute("aria-controls");
  });

  it("renders values with lone surrogates without throwing and keeps their ids unique", () => {
    render(<TestTabs values={["a b", "a_20_b", "\uD800"]} defaultValue="a b" />);
    const ids = screen.getAllByRole("tab").map((element) => element.id);
    expect(new Set(ids).size).toBe(3);
    expect(screen.getByRole("tab", { name: "\uD800" })).toBeInTheDocument();
  });

  it("omits aria-labelledby on a panel whose value matches no tab", () => {
    render(
      <Tabs defaultValue="one">
        <TabList aria-label="Sections">
          <Tab value="one">one</Tab>
        </TabList>
        <TabPanel value="one">Content one</TabPanel>
        <TabPanel value="ghost">Content ghost</TabPanel>
      </Tabs>,
    );
    const [realPanel, ghostPanel] = screen.getAllByRole("tabpanel", { hidden: true });
    expect(realPanel).toHaveAttribute("aria-labelledby", tab("one").id);
    expect(ghostPanel).not.toHaveAttribute("aria-labelledby");
  });

  it("points every aria-controls and aria-labelledby at an existing element, including with a ghost panel", () => {
    const { container } = render(
      <Tabs defaultValue="one">
        <TabList aria-label="Sections">
          <Tab value="one">one</Tab>
          <Tab value="two">two</Tab>
        </TabList>
        <TabPanel value="one">Content one</TabPanel>
        <TabPanel value="two">Content two</TabPanel>
        <TabPanel value="ghost">Content ghost</TabPanel>
      </Tabs>,
    );
    const references = container.querySelectorAll("[aria-controls], [aria-labelledby]");
    expect(references.length).toBeGreaterThan(0);
    for (const element of Array.from(references)) {
      for (const attribute of ["aria-controls", "aria-labelledby"]) {
        const id = element.getAttribute(attribute);
        if (id !== null) expect(document.getElementById(id)).not.toBeNull();
      }
    }
  });
});

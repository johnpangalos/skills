import { useId, useLayoutEffect, useRef, type KeyboardEvent, type MouseEvent, type ReactNode } from "react";
import { createPortal } from "react-dom";

export interface DialogProps {
  /** Whether the dialog is shown. The Dialog never changes this itself. */
  open: boolean;
  /** Called with `false` on Escape or a backdrop click. */
  onOpenChange: (open: boolean) => void;
  title: ReactNode;
  description?: ReactNode;
  className?: string;
  children?: ReactNode;
}

const TABBABLE = 'a[href], button, input:not([type="hidden"]), select, textarea, [tabindex]';

// Elements a keyboard user can reach inside the dialog, in DOM order.
function getTabbables(container: HTMLElement): HTMLElement[] {
  return Array.from(container.querySelectorAll<HTMLElement>(TABBABLE)).filter(
    (element) => !element.matches(":disabled") && element.tabIndex >= 0 && !element.closest("[hidden]"),
  );
}

export function Dialog({ open, onOpenChange, title, description, className, children }: DialogProps) {
  const titleId = useId();
  const descriptionId = useId();
  const contentRef = useRef<HTMLDivElement>(null);
  const pressedBackdropRef = useRef(false);
  const releasedBackdropRef = useRef(false);

  useLayoutEffect(() => {
    if (!open) {
      return;
    }
    const previous = document.activeElement as HTMLElement | null;
    const content = contentRef.current;
    if (!content) {
      return;
    }
    (getTabbables(content)[0] ?? content).focus();
    return () => {
      if (previous?.isConnected) {
        previous.focus();
      }
    };
  }, [open]);

  const handleKeyDown = (event: KeyboardEvent<HTMLDivElement>) => {
    if (event.key === "Escape") {
      onOpenChange(false);
      return;
    }
    if (event.key !== "Tab") {
      return;
    }
    const content = event.currentTarget;
    const tabbables = getTabbables(content);
    const first = tabbables[0];
    if (!first) {
      event.preventDefault();
      content.focus();
      return;
    }
    const last = tabbables[tabbables.length - 1];
    const active = document.activeElement;
    if (event.shiftKey && (active === first || active === content)) {
      event.preventDefault();
      last.focus();
    } else if (!event.shiftKey && active === last) {
      event.preventDefault();
      first.focus();
    }
  };

  // A click closes only when the press and the release both land on the backdrop itself.
  const handleBackdropMouseDown = (event: MouseEvent<HTMLDivElement>) => {
    pressedBackdropRef.current = event.target === event.currentTarget;
    releasedBackdropRef.current = false;
  };

  const handleBackdropMouseUp = (event: MouseEvent<HTMLDivElement>) => {
    releasedBackdropRef.current = event.target === event.currentTarget;
  };

  const handleBackdropClick = (event: MouseEvent<HTMLDivElement>) => {
    if (pressedBackdropRef.current && releasedBackdropRef.current && event.target === event.currentTarget) {
      onOpenChange(false);
    }
    pressedBackdropRef.current = false;
    releasedBackdropRef.current = false;
  };

  if (!open) {
    return null;
  }

  return createPortal(
    <div
      onMouseDown={handleBackdropMouseDown}
      onMouseUp={handleBackdropMouseUp}
      onClick={handleBackdropClick}
    >
      <div
        ref={contentRef}
        role="dialog"
        aria-modal="true"
        aria-labelledby={titleId}
        aria-describedby={description != null ? descriptionId : undefined}
        tabIndex={-1}
        className={className}
        onKeyDown={handleKeyDown}
      >
        <h2 id={titleId}>{title}</h2>
        {description != null && <div id={descriptionId}>{description}</div>}
        {children}
      </div>
    </div>,
    document.body,
  );
}

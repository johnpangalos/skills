import { fireEvent, render, screen } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { useState } from "react";
import { Combobox, Dialog } from "../src";

const user = userEvent.setup();

const fruits = [{ value: "apple", label: "Apple" }];

function Harness({ onClose }: { onClose?: () => void }) {
  const [open, setOpen] = useState(false);
  return (
    <>
      <button onClick={() => setOpen(true)}>Open</button>
      <Dialog
        open={open}
        onOpenChange={(next) => {
          setOpen(next);
          if (!next) onClose?.();
        }}
        title="Pick"
      >
        <button>Inside</button>
      </Dialog>
    </>
  );
}

describe("Dialog", () => {
  it("renders nothing when closed", () => {
    render(<Dialog open={false} onOpenChange={() => {}} title="Hidden" />);
    expect(screen.queryByRole("dialog")).toBeNull();
    expect(screen.queryByText("Hidden")).toBeNull();
  });

  it("renders a labelled modal dialog with a backdrop in document.body", () => {
    const { container } = render(
      <Dialog open onOpenChange={() => {}} title="Confirm" description="Are you sure?">
        <p>Body text</p>
      </Dialog>,
    );
    expect(container).toBeEmptyDOMElement();
    const dialog = screen.getByRole("dialog", { name: "Confirm" });
    expect(dialog).toHaveAttribute("aria-modal", "true");
    expect(dialog).toHaveAccessibleDescription("Are you sure?");
    expect(dialog).toContainElement(screen.getByText("Body text"));
    expect(dialog.parentElement?.parentElement).toBe(document.body);
  });

  it("omits aria-describedby when no description is given", () => {
    render(<Dialog open onOpenChange={() => {}} title="No description" />);
    expect(screen.getByRole("dialog")).not.toHaveAttribute("aria-describedby");
  });

  it("renders a ReactNode title inside the labelling heading", () => {
    render(
      <Dialog open onOpenChange={() => {}} title={<span>Rich <em>title</em></span>} />,
    );
    const heading = screen.getByRole("heading", { name: "Rich title" });
    expect(screen.getByRole("dialog")).toHaveAttribute("aria-labelledby", heading.id);
  });

  it("focuses the first tabbable element on open", () => {
    render(
      <Dialog open onOpenChange={() => {}} title="Focus">
        <button disabled>Disabled</button>
        <button tabIndex={-1}>Skipped</button>
        <button>First</button>
        <button>Second</button>
      </Dialog>,
    );
    expect(screen.getByRole("button", { name: "First" })).toHaveFocus();
  });

  it("focuses the dialog container when there is no tabbable element", () => {
    render(
      <Dialog open onOpenChange={() => {}} title="Empty">
        <p>Just text</p>
      </Dialog>,
    );
    expect(screen.getByRole("dialog")).toHaveFocus();
  });

  it("wraps Tab from the last tabbable to the first and Shift+Tab back", async () => {
    render(
      <Dialog open onOpenChange={() => {}} title="Trap">
        <button>First</button>
        <button tabIndex={-1}>Skipped</button>
        <button disabled>Disabled</button>
        <button>Last</button>
      </Dialog>,
    );
    expect(screen.getByRole("button", { name: "First" })).toHaveFocus();
    await user.tab();
    expect(screen.getByRole("button", { name: "Last" })).toHaveFocus();
    await user.tab();
    expect(screen.getByRole("button", { name: "First" })).toHaveFocus();
    await user.tab({ shift: true });
    expect(screen.getByRole("button", { name: "Last" })).toHaveFocus();
  });

  it("keeps focus on the dialog when there are no tabbables and Tab is pressed", async () => {
    render(
      <Dialog open onOpenChange={() => {}} title="Nothing">
        <button disabled>Off</button>
      </Dialog>,
    );
    await user.tab();
    expect(screen.getByRole("dialog")).toHaveFocus();
    await user.tab({ shift: true });
    expect(screen.getByRole("dialog")).toHaveFocus();
  });

  it("calls onOpenChange(false) on Escape, including from a nested input", async () => {
    const onOpenChange = vi.fn();
    render(
      <Dialog open onOpenChange={onOpenChange} title="Escape">
        <input aria-label="Name" />
      </Dialog>,
    );
    await user.click(screen.getByRole("textbox", { name: "Name" }));
    await user.keyboard("{Escape}");
    expect(onOpenChange).toHaveBeenCalledTimes(1);
    expect(onOpenChange).toHaveBeenCalledWith(false);
  });

  it("closes on a plain backdrop click but not on a click inside the dialog", async () => {
    const onOpenChange = vi.fn();
    render(
      <Dialog open onOpenChange={onOpenChange} title="Click" backdropClassName="backdrop">
        <p>Content</p>
      </Dialog>,
    );
    await user.click(screen.getByText("Content"));
    expect(onOpenChange).not.toHaveBeenCalled();
    fireEvent.click(document.querySelector(".backdrop") as HTMLElement);
    expect(onOpenChange).toHaveBeenCalledWith(false);
  });

  it("does not close when a press starts inside the content and ends on the backdrop", () => {
    const onOpenChange = vi.fn();
    render(
      <Dialog open onOpenChange={onOpenChange} title="Drag" backdropClassName="backdrop">
        <p>Content</p>
      </Dialog>,
    );
    const backdrop = document.querySelector(".backdrop") as HTMLElement;
    fireEvent.mouseDown(screen.getByText("Content"));
    fireEvent.click(backdrop);
    expect(onOpenChange).not.toHaveBeenCalled();
    fireEvent.mouseDown(backdrop);
    fireEvent.click(backdrop);
    expect(onOpenChange).toHaveBeenCalledTimes(1);
  });

  it("restores focus to the opener when closed with Escape", async () => {
    render(<Harness />);
    await user.click(screen.getByRole("button", { name: "Open" }));
    expect(screen.getByRole("button", { name: "Inside" })).toHaveFocus();
    await user.keyboard("{Escape}");
    expect(screen.queryByRole("dialog")).toBeNull();
    expect(screen.getByRole("button", { name: "Open" })).toHaveFocus();
  });

  it("restores focus to the previously focused element when open turns false", () => {
    function Controlled({ open }: { open: boolean }) {
      return (
        <>
          <button>Opener</button>
          <Dialog open={open} onOpenChange={() => {}} title="Ctl">
            <button>Inside</button>
          </Dialog>
        </>
      );
    }
    const { rerender } = render(<Controlled open={false} />);
    screen.getByRole("button", { name: "Opener" }).focus();
    rerender(<Controlled open />);
    expect(screen.getByRole("button", { name: "Inside" })).toHaveFocus();
    rerender(<Controlled open={false} />);
    expect(screen.getByRole("button", { name: "Opener" })).toHaveFocus();
  });

  it("restores focus when it unmounts while open, and skips detached elements", () => {
    function Unmounting({ open }: { open: boolean }) {
      return (
        <>
          <button>Opener</button>
          {open && (
            <Dialog open onOpenChange={() => {}} title="Gone">
              <button>Inside</button>
            </Dialog>
          )}
        </>
      );
    }
    const { rerender } = render(<Unmounting open={false} />);
    screen.getByRole("button", { name: "Opener" }).focus();
    rerender(<Unmounting open />);
    rerender(<Unmounting open={false} />);
    expect(screen.getByRole("button", { name: "Opener" })).toHaveFocus();
  });

  it("does not crash or restore when the dialog opens with body focused", () => {
    document.body.focus();
    const { rerender } = render(<Dialog open={false} onOpenChange={() => {}} title="Body" />);
    rerender(<Dialog open onOpenChange={() => {}} title="Body" />);
    expect(screen.getByRole("dialog")).toHaveFocus();
    rerender(<Dialog open={false} onOpenChange={() => {}} title="Body" />);
    expect(document.body).toHaveFocus();
  });

  it("never closes itself when the parent ignores onOpenChange", async () => {
    const onOpenChange = vi.fn();
    render(
      <Dialog open onOpenChange={onOpenChange} title="Stubborn">
        <button>Inside</button>
      </Dialog>,
    );
    await user.keyboard("{Escape}");
    fireEvent.click(screen.getByRole("dialog").parentElement as HTMLElement);
    expect(onOpenChange).toHaveBeenCalledTimes(2);
    expect(screen.getByRole("dialog")).toBeInTheDocument();
  });

  it("closes the combobox listbox on the first Escape and the dialog on the second", async () => {
    const onOpenChange = vi.fn();
    render(
      <Dialog open onOpenChange={onOpenChange} title="Pick fruit">
        <Combobox label="Fruit" options={fruits} value={null} onChange={() => {}} />
      </Dialog>,
    );
    const input = screen.getByRole("combobox", { name: "Fruit" });
    expect(input).toHaveFocus();
    await user.type(input, "a");
    expect(input).toHaveAttribute("aria-expanded", "true");
    await user.keyboard("{Escape}");
    expect(onOpenChange).not.toHaveBeenCalled();
    expect(input).toHaveAttribute("aria-expanded", "false");
    await user.keyboard("{Escape}");
    expect(onOpenChange).toHaveBeenCalledTimes(1);
    expect(onOpenChange).toHaveBeenCalledWith(false);
  });

  it("closes only the inner dialog on Escape when dialogs are nested", async () => {
    const onOuter = vi.fn();
    const onInner = vi.fn();
    render(
      <Dialog open onOpenChange={onOuter} title="Outer">
        <Dialog open onOpenChange={onInner} title="Inner">
          <button type="button">Inside</button>
        </Dialog>
      </Dialog>,
    );
    screen.getByRole("button", { name: "Inside" }).focus();
    await user.keyboard("{Escape}");
    expect(onInner).toHaveBeenCalledTimes(1);
    expect(onInner).toHaveBeenCalledWith(false);
    expect(onOuter).not.toHaveBeenCalled();
  });

  it("keeps Tab inside the inner dialog when dialogs are nested", async () => {
    render(
      <Dialog open onOpenChange={() => {}} title="outer">
        <Dialog open onOpenChange={() => {}} title="inner">
          <button type="button">i1</button>
          <button type="button">i2</button>
        </Dialog>
      </Dialog>,
    );
    screen.getByRole("button", { name: "i1" }).focus();
    await user.tab();
    expect(screen.getByRole("button", { name: "i2" })).toHaveFocus();
  });
});

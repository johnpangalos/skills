import { fireEvent, render, screen } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { Combobox, type ComboboxOption, type ComboboxProps } from "./Combobox";

const options: ComboboxOption[] = [
  { value: "apple", label: "Apple" },
  { value: "banana", label: "Banana", disabled: true },
  { value: "cherry", label: "Cherry" },
  { value: "cpp", label: "C++" },
];

function Fruit({
  value = null,
  onChange = () => {},
  list = options,
}: Partial<Omit<ComboboxProps, "options">> & { list?: ComboboxOption[] }) {
  return <Combobox label="Fruit" placeholder="Pick one" options={list} value={value} onChange={onChange} />;
}

const input = () => screen.getByRole("combobox", { name: "Fruit" });
const option = (name: string) => screen.getByRole("option", { name });
const optionNames = () => screen.queryAllByRole("option").map((element) => element.textContent);

describe("Combobox", () => {
  it("labels the input and wires its ARIA attributes", () => {
    render(<Fruit />);
    const field = input();
    expect(field).toHaveAttribute("aria-autocomplete", "list");
    expect(field).toHaveAttribute("aria-expanded", "false");
    expect(field).toHaveAttribute("placeholder", "Pick one");

    const listbox = document.getElementById(field.getAttribute("aria-controls")!)!;
    expect(listbox).toHaveAttribute("role", "listbox");
    expect(listbox).toHaveAttribute("aria-labelledby", screen.getByText("Fruit").id);
    expect(listbox).toHaveAttribute("hidden");
  });

  it("shows the selected label, follows value changes, and resets typed text on blur", async () => {
    const user = userEvent.setup();
    const { rerender } = render(<Fruit value="apple" />);
    expect(input()).toHaveValue("Apple");

    rerender(<Fruit value="cherry" />);
    expect(input()).toHaveValue("Cherry");

    await user.type(input(), "xyz");
    expect(input()).toHaveValue("Cherryxyz");

    await user.tab();
    expect(input()).toHaveValue("Cherry");
    expect(input()).toHaveAttribute("aria-expanded", "false");
  });

  it("shows empty text for a value that is not in options", () => {
    render(<Fruit value="ghost" />);
    expect(input()).toHaveValue("");
  });

  it("filters case-insensitively by literal substring, and opens on click or typing", async () => {
    const user = userEvent.setup();
    render(<Fruit />);
    await user.click(input());
    expect(input()).toHaveAttribute("aria-expanded", "true");
    expect(optionNames()).toEqual(["Apple", "Banana", "Cherry", "C++"]);

    await user.type(input(), "c++");
    expect(optionNames()).toEqual(["C++"]);

    await user.clear(input());
    expect(optionNames()).toHaveLength(4);
  });

  it("calls onChange(null) as soon as the text is deleted", async () => {
    const user = userEvent.setup();
    const onChange = vi.fn();
    render(<Fruit value="apple" onChange={onChange} />);
    await user.clear(input());
    expect(onChange).toHaveBeenCalledWith(null);
  });

  it("marks the committed option aria-selected and disabled options aria-disabled", async () => {
    const user = userEvent.setup();
    render(<Fruit value="cherry" />);
    await user.click(input());
    expect(option("Cherry")).toHaveAttribute("aria-selected", "true");
    expect(option("Apple")).toHaveAttribute("aria-selected", "false");
    expect(option("Banana")).toHaveAttribute("aria-disabled", "true");
    expect(option("Apple")).toBeVisible();
  });

  it("moves the active option with arrow keys, skipping disabled options and wrapping", async () => {
    const user = userEvent.setup();
    render(<Fruit />);
    input().focus();

    expect(fireEvent.keyDown(input(), { key: "ArrowDown" })).toBe(false);
    expect(input()).toHaveAttribute("aria-expanded", "true");
    expect(input()).toHaveAttribute("aria-activedescendant", option("Apple").id);
    expect(input()).toHaveFocus();

    await user.keyboard("{ArrowDown}");
    expect(input()).toHaveAttribute("aria-activedescendant", option("Cherry").id);

    await user.keyboard("{ArrowDown}");
    expect(input()).toHaveAttribute("aria-activedescendant", option("C++").id);

    await user.keyboard("{ArrowDown}");
    expect(input()).toHaveAttribute("aria-activedescendant", option("Apple").id);

    await user.keyboard("{ArrowUp}");
    expect(input()).toHaveAttribute("aria-activedescendant", option("C++").id);
  });

  it("opens on the last enabled option when ArrowUp is pressed while closed", async () => {
    const user = userEvent.setup();
    render(<Fruit />);
    input().focus();
    await user.keyboard("{ArrowUp}");
    expect(input()).toHaveAttribute("aria-activedescendant", option("C++").id);
  });

  it("commits the active option with Enter, preventing it only while open", async () => {
    const user = userEvent.setup();
    const onChange = vi.fn();
    render(<Fruit onChange={onChange} />);
    input().focus();

    expect(fireEvent.keyDown(input(), { key: "Enter" })).toBe(true);
    expect(onChange).not.toHaveBeenCalled();

    await user.keyboard("{ArrowDown}");
    expect(fireEvent.keyDown(input(), { key: "Enter" })).toBe(false);
    expect(onChange).toHaveBeenCalledWith("apple");
    expect(input()).toHaveValue("Apple");
    expect(input()).toHaveAttribute("aria-expanded", "false");
  });

  it("does nothing on Enter with no active option, leaving the listbox open", async () => {
    const user = userEvent.setup();
    const onChange = vi.fn();
    render(<Fruit onChange={onChange} />);
    await user.click(input());

    expect(fireEvent.keyDown(input(), { key: "Enter" })).toBe(false);
    expect(onChange).not.toHaveBeenCalled();
    expect(input()).toHaveAttribute("aria-expanded", "true");
  });

  it("commits an enabled option on click, keeps focus in the input, and ignores disabled options", async () => {
    const user = userEvent.setup();
    const onChange = vi.fn();
    render(<Fruit onChange={onChange} />);
    await user.click(input());

    await user.click(option("Banana"));
    expect(onChange).not.toHaveBeenCalled();
    expect(input()).toHaveAttribute("aria-expanded", "true");

    await user.click(option("Cherry"));
    expect(onChange).toHaveBeenCalledWith("cherry");
    expect(input()).toHaveValue("Cherry");
    expect(input()).toHaveFocus();
  });

  it("closes on Escape without calling onChange, keeps the text, and stops propagation", async () => {
    const user = userEvent.setup();
    const onChange = vi.fn();
    const parentKeyDown = vi.fn();
    render(
      <div onKeyDown={parentKeyDown}>
        <Fruit onChange={onChange} />
      </div>,
    );
    await user.type(input(), "ch");
    parentKeyDown.mockClear();

    await user.keyboard("{Escape}");
    expect(input()).toHaveAttribute("aria-expanded", "false");
    expect(input()).toHaveValue("ch");
    expect(onChange).not.toHaveBeenCalled();
    expect(parentKeyDown).not.toHaveBeenCalled();

    await user.keyboard("{Escape}");
    expect(parentKeyDown).toHaveBeenCalledTimes(1);
  });

  it("shows a No results status with no options when nothing matches", async () => {
    const user = userEvent.setup();
    render(<Fruit />);
    await user.type(input(), "zzz");
    expect(screen.getByRole("status")).toHaveTextContent("No results");
    expect(optionNames()).toEqual([]);

    expect(fireEvent.keyDown(input(), { key: "ArrowDown" })).toBe(false);
    expect(input()).not.toHaveAttribute("aria-activedescendant");
  });

  it("treats regex characters in labels as literal text", async () => {
    const user = userEvent.setup();
    render(
      <Fruit
        list={[
          { value: "a", label: "(a" },
          { value: "b", label: "." },
          { value: "c", label: "a.b" },
        ]}
      />,
    );
    await user.type(input(), "(a");
    expect(optionNames()).toEqual(["(a"]);

    await user.clear(input());
    await user.type(input(), ".");
    expect(optionNames()).toEqual([".", "a.b"]);
  });

  it("renders no options and a No results status for an empty options array", async () => {
    const user = userEvent.setup();
    render(<Fruit list={[]} />);
    await user.click(input());
    expect(optionNames()).toEqual([]);
    expect(screen.getByRole("status")).toHaveTextContent("No results");
  });

  it("selects nothing when every match is disabled", async () => {
    const user = userEvent.setup();
    const onChange = vi.fn();
    render(<Fruit list={[{ value: "banana", label: "Banana", disabled: true }]} onChange={onChange} />);
    input().focus();
    await user.keyboard("{ArrowDown}");
    expect(input()).not.toHaveAttribute("aria-activedescendant");

    fireEvent.keyDown(input(), { key: "Enter" });
    expect(onChange).not.toHaveBeenCalled();
  });

  it("commits values that contain spaces", async () => {
    const user = userEvent.setup();
    const onChange = vi.fn();
    render(<Fruit list={[{ value: "new york", label: "New York" }]} onChange={onChange} />);
    await user.click(input());
    await user.click(option("New York"));
    expect(onChange).toHaveBeenCalledWith("new york");
  });

  it("drops the active option when further typing filters it out", async () => {
    const user = userEvent.setup();
    render(<Fruit />);
    input().focus();
    await user.keyboard("{ArrowDown}");
    expect(input()).toHaveAttribute("aria-activedescendant", option("Apple").id);

    await user.keyboard("c");
    expect(input()).not.toHaveAttribute("aria-activedescendant");
  });

  it("gives two comboboxes on one page distinct ids and independent active options", async () => {
    const user = userEvent.setup();
    render(
      <>
        <Combobox label="First" options={options} value={null} onChange={vi.fn()} />
        <Combobox label="Second" options={options} value={null} onChange={vi.fn()} />
      </>,
    );
    const first = screen.getByRole("combobox", { name: "First" });
    const second = screen.getByRole("combobox", { name: "Second" });
    expect(first.id).not.toBe(second.id);
    expect(first.getAttribute("aria-controls")).not.toBe(second.getAttribute("aria-controls"));

    first.focus();
    await user.keyboard("{ArrowDown}");
    expect(first).toHaveAttribute("aria-activedescendant");
    expect(second).not.toHaveAttribute("aria-activedescendant");
  });
});

import { render, screen } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { useState, type FormEvent } from "react";
import { Dialog } from "../Dialog/Dialog";
import { Combobox, type ComboboxOption } from "./Combobox";

const fruits: ComboboxOption[] = [
  { value: "apple", label: "Apple" },
  { value: "banana", label: "Banana" },
  { value: "cherry", label: "Cherry", disabled: true },
  { value: "blueberry", label: "Blueberry" },
];

function Controlled({ options = fruits, initial = null, onChange }: {
  options?: ComboboxOption[];
  initial?: string | null;
  onChange?: (value: string | null) => void;
}) {
  const [value, setValue] = useState<string | null>(initial);
  return (
    <Combobox
      label="Fruit"
      options={options}
      value={value}
      placeholder="Pick a fruit"
      onChange={(next) => {
        setValue(next);
        onChange?.(next);
      }}
    />
  );
}

const input = () => screen.getByRole("combobox", { name: "Fruit" });
const option = (name: string) => screen.getByRole("option", { name });

describe("Combobox", () => {
  it("associates the label with the input and exposes combobox attributes", () => {
    render(<Combobox label="Fruit" options={fruits} value={null} onChange={() => {}} placeholder="Pick a fruit" />);
    const box = input();
    expect(box).toHaveAttribute("aria-autocomplete", "list");
    expect(box).toHaveAttribute("aria-expanded", "false");
    expect(box).toHaveAttribute("placeholder", "Pick a fruit");
    expect(box).not.toHaveAttribute("aria-activedescendant");
    const listbox = screen.getByRole("listbox", { hidden: true });
    expect(box).toHaveAttribute("aria-controls", listbox.id);
    expect(listbox).toHaveAttribute("aria-labelledby", screen.getByText("Fruit").id);
  });

  it("shows the selected label when closed, and an empty input for null or unknown values", () => {
    const { rerender } = render(<Combobox label="Fruit" options={fruits} value="banana" onChange={() => {}} />);
    expect(input()).toHaveValue("Banana");
    rerender(<Combobox label="Fruit" options={fruits} value="missing" onChange={() => {}} />);
    expect(input()).toHaveValue("");
    rerender(<Combobox label="Fruit" options={fruits} value={null} onChange={() => {}} />);
    expect(input()).toHaveValue("");
  });

  it("opens on typing and filters by case-insensitive substring; clearing shows all options", async () => {
    const user = userEvent.setup();
    render(<Controlled />);
    await user.type(input(), "BERRY");
    expect(input()).toHaveAttribute("aria-expanded", "true");
    expect(screen.getAllByRole("option")).toHaveLength(1);
    expect(option("Blueberry")).toBeInTheDocument();
    await user.clear(input());
    expect(screen.getAllByRole("option")).toHaveLength(4);
  });

  it("treats regex characters in the filter text literally", async () => {
    const user = userEvent.setup();
    render(<Controlled />);
    await user.type(input(), "(");
    expect(screen.queryAllByRole("option")).toHaveLength(0);
    expect(screen.getByText("No results")).toBeInTheDocument();
    await user.clear(input());
    await user.type(input(), ".");
    expect(screen.queryAllByRole("option")).toHaveLength(0);
  });

  it("does not open when the input is focused or clicked without typing", async () => {
    const user = userEvent.setup();
    render(<Controlled />);
    await user.click(input());
    expect(input()).toHaveFocus();
    expect(input()).toHaveAttribute("aria-expanded", "false");
    await user.tab({ shift: true });
    await user.tab();
    expect(input()).toHaveAttribute("aria-expanded", "false");
  });

  it("moves the active option with ArrowDown and ArrowUp, skipping disabled options and wrapping", async () => {
    const user = userEvent.setup();
    render(<Controlled />);
    input().focus();
    await user.keyboard("{ArrowDown}");
    expect(input()).toHaveAttribute("aria-expanded", "true");
    expect(input()).toHaveAttribute("aria-activedescendant", option("Apple").id);
    expect(option("Apple")).toHaveAttribute("data-active", "true");
    await user.keyboard("{ArrowDown}");
    expect(input()).toHaveAttribute("aria-activedescendant", option("Banana").id);
    await user.keyboard("{ArrowDown}");
    expect(input()).toHaveAttribute("aria-activedescendant", option("Blueberry").id);
    await user.keyboard("{ArrowDown}");
    expect(input()).toHaveAttribute("aria-activedescendant", option("Apple").id);
    await user.keyboard("{ArrowUp}");
    expect(input()).toHaveAttribute("aria-activedescendant", option("Blueberry").id);
  });

  it("opens with Alt+ArrowDown too", async () => {
    const user = userEvent.setup();
    render(<Controlled />);
    input().focus();
    await user.keyboard("{Alt>}{ArrowDown}{/Alt}");
    expect(input()).toHaveAttribute("aria-expanded", "true");
  });

  it("sets no active option when every option is disabled", async () => {
    const user = userEvent.setup();
    render(
      <Controlled
        options={[
          { value: "a", label: "A", disabled: true },
          { value: "b", label: "B", disabled: true },
        ]}
      />,
    );
    input().focus();
    await user.keyboard("{ArrowDown}{ArrowDown}{ArrowUp}");
    expect(input()).not.toHaveAttribute("aria-activedescendant");
    expect(screen.getAllByRole("option")[0]).toHaveAttribute("aria-disabled", "true");
  });

  it("selects the active option on Enter, closes, and shows its label", async () => {
    const user = userEvent.setup();
    const onChange = vi.fn();
    render(<Controlled onChange={onChange} />);
    input().focus();
    await user.keyboard("{ArrowDown}{ArrowDown}{Enter}");
    expect(onChange).toHaveBeenCalledTimes(1);
    expect(onChange).toHaveBeenCalledWith("banana");
    expect(input()).toHaveValue("Banana");
    expect(input()).toHaveAttribute("aria-expanded", "false");
    expect(input()).not.toHaveAttribute("aria-activedescendant");
  });

  it("selects an enabled option on click and ignores a disabled option", async () => {
    const user = userEvent.setup();
    const onChange = vi.fn();
    render(<Controlled onChange={onChange} />);
    await user.click(input());
    await user.type(input(), "e");
    await user.click(option("Cherry"));
    expect(onChange).not.toHaveBeenCalled();
    expect(input()).toHaveAttribute("aria-expanded", "true");
    await user.click(option("Blueberry"));
    expect(onChange).toHaveBeenCalledWith("blueberry");
    expect(input()).toHaveValue("Blueberry");
  });

  it("does not submit an enclosing form on Enter while the list is open with no active option", async () => {
    const user = userEvent.setup();
    const onSubmit = vi.fn((event: FormEvent) => event.preventDefault());
    render(
      <form onSubmit={onSubmit}>
        <Controlled />
      </form>,
    );
    await user.type(input(), "ban");
    await user.keyboard("{Enter}");
    expect(onSubmit).not.toHaveBeenCalled();
    expect(input()).toHaveAttribute("aria-expanded", "false");
  });

  it("closes on Escape without calling onChange and restores the selected label", async () => {
    const user = userEvent.setup();
    const onChange = vi.fn();
    render(<Controlled initial="apple" onChange={onChange} />);
    await user.type(input(), "ban");
    expect(input()).toHaveValue("Appleban");
    await user.keyboard("{Escape}");
    expect(onChange).not.toHaveBeenCalled();
    expect(input()).toHaveAttribute("aria-expanded", "false");
    expect(input()).toHaveValue("Apple");
  });

  it("closes on blur and restores the selected label without changing the value", async () => {
    const user = userEvent.setup();
    const onChange = vi.fn();
    render(
      <>
        <Controlled initial="apple" onChange={onChange} />
        <button>Elsewhere</button>
      </>,
    );
    await user.type(input(), "ban");
    await user.click(screen.getByRole("button", { name: "Elsewhere" }));
    expect(input()).toHaveAttribute("aria-expanded", "false");
    expect(input()).toHaveValue("Apple");
    expect(onChange).not.toHaveBeenCalled();
  });

  it("calls onChange(null) when the text is emptied and the input is then blurred", async () => {
    const user = userEvent.setup();
    const onChange = vi.fn();
    render(
      <>
        <Controlled initial="apple" onChange={onChange} />
        <button>Elsewhere</button>
      </>,
    );
    await user.clear(input());
    await user.click(screen.getByRole("button", { name: "Elsewhere" }));
    expect(onChange).toHaveBeenCalledTimes(1);
    expect(onChange).toHaveBeenCalledWith(null);
    expect(input()).toHaveValue("");
  });

  it("calls onChange(null) when the text is emptied and Enter is pressed with no active option", async () => {
    const user = userEvent.setup();
    const onChange = vi.fn();
    render(<Controlled initial="apple" onChange={onChange} />);
    await user.clear(input());
    await user.keyboard("{Enter}");
    expect(onChange).toHaveBeenCalledWith(null);
    expect(input()).toHaveValue("");
  });

  it("does not call onChange on blur or Escape when nothing was selected and the text is empty", async () => {
    const user = userEvent.setup();
    const onChange = vi.fn();
    render(<Controlled onChange={onChange} />);
    await user.type(input(), "x");
    await user.clear(input());
    await user.keyboard("{Escape}");
    expect(onChange).not.toHaveBeenCalled();
  });

  it("keeps the selected value when the text is emptied and Escape is pressed", async () => {
    const user = userEvent.setup();
    const onChange = vi.fn();
    render(<Controlled initial="apple" onChange={onChange} />);
    await user.clear(input());
    await user.keyboard("{Escape}");
    expect(onChange).not.toHaveBeenCalled();
    expect(input()).toHaveValue("Apple");
  });

  it("shows a No results message for an empty options array, not as an option", async () => {
    const user = userEvent.setup();
    render(<Controlled options={[]} />);
    await user.type(input(), "a");
    expect(screen.getByText("No results")).toBeInTheDocument();
    expect(screen.queryAllByRole("option")).toHaveLength(0);
    expect(input()).not.toHaveAttribute("aria-activedescendant");
  });

  it("keeps all duplicate-label options as separate options", async () => {
    const user = userEvent.setup();
    render(
      <Controlled
        options={[
          { value: "1", label: "Same" },
          { value: "2", label: "Same" },
        ]}
      />,
    );
    await user.type(input(), "same");
    expect(screen.getAllByRole("option", { name: "Same" })).toHaveLength(2);
  });

  it("does not change the value when a controlled parent ignores onChange", async () => {
    const user = userEvent.setup();
    const onChange = vi.fn();
    render(<Combobox label="Fruit" options={fruits} value="apple" onChange={onChange} />);
    await user.click(input());
    await user.clear(input());
    await user.keyboard("{ArrowDown}{ArrowDown}{Enter}");
    expect(onChange).toHaveBeenCalledWith("banana");
    expect(input()).toHaveValue("Apple");
  });

  it("drops the active option when it is removed while open", async () => {
    const user = userEvent.setup();
    const { rerender } = render(<Combobox label="Fruit" options={fruits} value={null} onChange={() => {}} />);
    input().focus();
    await user.keyboard("{ArrowDown}{ArrowDown}");
    expect(input()).toHaveAttribute("aria-activedescendant", option("Banana").id);
    rerender(
      <Combobox label="Fruit" options={fruits.filter((item) => item.value !== "banana")} value={null} onChange={() => {}} />,
    );
    expect(input()).not.toHaveAttribute("aria-activedescendant");
  });

  it("keeps ids unique and state independent across two instances", async () => {
    const user = userEvent.setup();
    render(
      <>
        <Controlled />
        <Controlled />
      </>,
    );
    const [first, second] = screen.getAllByRole("combobox");
    expect(first.id).not.toBe(second.id);
    await user.click(first);
    await user.type(first, "app");
    expect(first).toHaveAttribute("aria-expanded", "true");
    expect(second).toHaveAttribute("aria-expanded", "false");
    expect(second).toHaveValue("");
  });

  describe("inside a Dialog", () => {
    function DialogWithCombobox({ onOpenChange }: { onOpenChange: (open: boolean) => void }) {
      return (
        <Dialog open onOpenChange={onOpenChange} title="Pick">
          <Controlled />
        </Dialog>
      );
    }

    it("closes only the listbox on the first Escape and the dialog on the second", async () => {
      const user = userEvent.setup();
      const onOpenChange = vi.fn();
      render(<DialogWithCombobox onOpenChange={onOpenChange} />);
      await user.type(input(), "b");
      expect(input()).toHaveAttribute("aria-expanded", "true");
      await user.keyboard("{Escape}");
      expect(onOpenChange).not.toHaveBeenCalled();
      expect(input()).toHaveAttribute("aria-expanded", "false");
      expect(screen.getByRole("dialog")).toBeInTheDocument();
      await user.keyboard("{Escape}");
      expect(onOpenChange).toHaveBeenCalledWith(false);
    });

    it("closes the dialog on Escape when the listbox is closed", async () => {
      const user = userEvent.setup();
      const onOpenChange = vi.fn();
      render(<DialogWithCombobox onOpenChange={onOpenChange} />);
      await user.keyboard("{Escape}");
      expect(onOpenChange).toHaveBeenCalledWith(false);
    });
  });

  it("opens with values containing lone surrogates and keeps option ids unique", async () => {
    const user = userEvent.setup();
    const options: ComboboxOption[] = [
      { value: "\uD800", label: "Broken" },
      { value: "a b", label: "Space" },
      { value: "a_20_b", label: "Underscore" },
    ];
    render(<Combobox label="Fruit" options={options} value={null} onChange={() => {}} />);
    await user.click(screen.getByRole("combobox"));
    await user.keyboard("{ArrowDown}");
    const ids = screen.getAllByRole("option").map((option) => option.id);
    expect(new Set(ids).size).toBe(3);
  });
});

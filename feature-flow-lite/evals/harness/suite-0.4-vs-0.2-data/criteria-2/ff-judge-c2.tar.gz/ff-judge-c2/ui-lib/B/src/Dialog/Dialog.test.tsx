import { fireEvent, render, screen } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { useState } from "react";
import { Combobox } from "../Combobox";
import { Dialog } from "./Dialog";

describe("Dialog", () => {
  it("renders nothing when closed", () => {
    render(<Dialog open={false} onOpenChange={vi.fn()} title="Closed" />);
    expect(screen.queryByRole("dialog")).toBeNull();
  });

  it("renders into document.body with the ARIA wiring for title and description", () => {
    render(
      <Dialog open onOpenChange={vi.fn()} title="Confirm" description="Are you sure?">
        <button>OK</button>
      </Dialog>,
    );
    const dialog = screen.getByRole("dialog", { name: "Confirm" });
    expect(dialog).toHaveAttribute("aria-modal", "true");
    expect(dialog).toHaveAttribute("aria-describedby", screen.getByText("Are you sure?").id);
    expect(dialog.parentElement!.parentElement).toBe(document.body);
  });

  it("omits aria-describedby when no description is given", () => {
    render(<Dialog open onOpenChange={vi.fn()} title="Plain" />);
    expect(screen.getByRole("dialog", { name: "Plain" })).not.toHaveAttribute("aria-describedby");
  });

  it("focuses the first tabbable element on open, skipping disabled and tabindex -1", () => {
    render(
      <Dialog open onOpenChange={vi.fn()} title="Focus">
        <button disabled>off</button>
        <button tabIndex={-1}>negative</button>
        <button>first</button>
        <button>second</button>
      </Dialog>,
    );
    expect(screen.getByRole("button", { name: "first" })).toHaveFocus();
  });

  it("focuses the dialog itself when it has no tabbable elements", () => {
    render(
      <Dialog open onOpenChange={vi.fn()} title="Empty">
        <p>just text</p>
      </Dialog>,
    );
    expect(screen.getByRole("dialog")).toHaveFocus();
  });

  it("traps Tab and Shift+Tab inside the dialog", async () => {
    const user = userEvent.setup();
    render(
      <Dialog open onOpenChange={vi.fn()} title="Trap">
        <button>a</button>
        <button>b</button>
      </Dialog>,
    );
    expect(screen.getByRole("button", { name: "a" })).toHaveFocus();

    await user.keyboard("{Shift>}{Tab}{/Shift}");
    expect(screen.getByRole("button", { name: "b" })).toHaveFocus();

    await user.keyboard("{Tab}");
    expect(screen.getByRole("button", { name: "a" })).toHaveFocus();
  });

  it("keeps focus on the dialog when there is nothing to tab to", async () => {
    const user = userEvent.setup();
    render(
      <Dialog open onOpenChange={vi.fn()} title="Nothing">
        <p>text</p>
      </Dialog>,
    );
    await user.tab();
    expect(screen.getByRole("dialog")).toHaveFocus();
    await user.tab({ shift: true });
    expect(screen.getByRole("dialog")).toHaveFocus();
  });

  it("calls onOpenChange(false) on Escape without changing open itself", async () => {
    const user = userEvent.setup();
    const onOpenChange = vi.fn();
    render(
      <Dialog open onOpenChange={onOpenChange} title="Esc">
        <button>inside</button>
      </Dialog>,
    );
    await user.keyboard("{Escape}");
    expect(onOpenChange).toHaveBeenCalledWith(false);
    expect(screen.getByRole("dialog")).toBeInTheDocument();
  });

  it("calls onOpenChange(false) only for a press and release on the backdrop", async () => {
    const user = userEvent.setup();
    const onOpenChange = vi.fn();
    render(
      <Dialog open onOpenChange={onOpenChange} title="Backdrop">
        <button>inside</button>
      </Dialog>,
    );
    const dialog = screen.getByRole("dialog");
    const backdrop = dialog.parentElement!;

    await user.click(dialog);
    expect(onOpenChange).not.toHaveBeenCalled();

    await user.pointer([
      { keys: "[MouseLeft>]", target: screen.getByRole("button", { name: "inside" }) },
      { target: backdrop },
      { keys: "[/MouseLeft]", target: backdrop },
    ]);
    expect(onOpenChange).not.toHaveBeenCalled();

    await user.click(backdrop);
    expect(onOpenChange).toHaveBeenCalledTimes(1);
    expect(onOpenChange).toHaveBeenCalledWith(false);
  });

  it("does not close when the press starts on the backdrop and is released inside the content", () => {
    const onOpenChange = vi.fn();
    render(
      <Dialog open onOpenChange={onOpenChange} title="Drag">
        <button>inside</button>
      </Dialog>,
    );
    const content = screen.getByRole("dialog");
    const backdrop = content.parentElement!;

    fireEvent.mouseDown(backdrop);
    fireEvent.mouseUp(content);
    fireEvent.click(backdrop);
    expect(onOpenChange).not.toHaveBeenCalled();
  });

  it("returns focus to the previously focused element on close", async () => {
    const user = userEvent.setup();
    function Host() {
      const [open, setOpen] = useState(false);
      return (
        <>
          <button onClick={() => setOpen(true)}>open</button>
          <Dialog open={open} onOpenChange={setOpen} title="Host">
            <button>inside</button>
          </Dialog>
        </>
      );
    }
    render(<Host />);
    const opener = screen.getByRole("button", { name: "open" });
    await user.click(opener);
    expect(screen.getByRole("button", { name: "inside" })).toHaveFocus();

    await user.keyboard("{Escape}");
    expect(opener).toHaveFocus();
  });

  it("records the previously focused element when mounted open", () => {
    const outside = document.createElement("button");
    document.body.append(outside);
    outside.focus();

    const { rerender } = render(
      <Dialog open onOpenChange={vi.fn()} title="Mounted">
        <button>inside</button>
      </Dialog>,
    );
    expect(screen.getByRole("button", { name: "inside" })).toHaveFocus();

    rerender(<Dialog open={false} onOpenChange={vi.fn()} title="Mounted" />);
    expect(outside).toHaveFocus();
    outside.remove();
  });

  it("does not throw on close when the trigger was removed while open", () => {
    const trigger = document.createElement("button");
    document.body.append(trigger);
    trigger.focus();

    const { rerender } = render(
      <Dialog open onOpenChange={vi.fn()} title="Removed">
        <button>inside</button>
      </Dialog>,
    );
    trigger.remove();
    expect(() => rerender(<Dialog open={false} onOpenChange={vi.fn()} title="Removed" />)).not.toThrow();
    expect(screen.queryByRole("dialog")).toBeNull();
  });

  it("uses the current tabbable elements after children change while open", async () => {
    const user = userEvent.setup();
    const { rerender } = render(
      <Dialog open onOpenChange={vi.fn()} title="Changing">
        <button>a</button>
      </Dialog>,
    );
    rerender(
      <Dialog open onOpenChange={vi.fn()} title="Changing">
        <button>a</button>
        <button>b</button>
      </Dialog>,
    );
    await user.keyboard("{Shift>}{Tab}{/Shift}");
    expect(screen.getByRole("button", { name: "b" })).toHaveFocus();
  });

  it("lets Escape close an open Combobox listbox without closing the dialog", async () => {
    const user = userEvent.setup();
    const onOpenChange = vi.fn();
    render(
      <Dialog open onOpenChange={onOpenChange} title="Pick">
        <Combobox
          label="Fruit"
          options={[{ value: "apple", label: "Apple" }]}
          value={null}
          onChange={vi.fn()}
        />
      </Dialog>,
    );
    const input = screen.getByRole("combobox", { name: "Fruit" });
    await user.click(input);
    expect(input).toHaveAttribute("aria-expanded", "true");

    await user.keyboard("{Escape}");
    expect(input).toHaveAttribute("aria-expanded", "false");
    expect(onOpenChange).not.toHaveBeenCalled();

    await user.keyboard("{Escape}");
    expect(onOpenChange).toHaveBeenCalledWith(false);
  });
});

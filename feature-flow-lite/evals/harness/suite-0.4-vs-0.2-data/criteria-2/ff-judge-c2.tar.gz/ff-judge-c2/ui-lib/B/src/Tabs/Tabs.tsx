import {
  createContext,
  useCallback,
  useContext,
  useId,
  useLayoutEffect,
  useRef,
  useState,
  type ButtonHTMLAttributes,
  type HTMLAttributes,
  type KeyboardEvent,
  type ReactNode,
  type RefObject,
} from "react";

export interface TabsProps {
  /** Selected tab value. When defined the component is controlled. */
  value?: string;
  /** Initially selected value when uncontrolled. Defaults to the first enabled tab. */
  defaultValue?: string;
  /** Called when the user selects a different tab. */
  onValueChange?: (value: string) => void;
  className?: string;
  children?: ReactNode;
}

export interface TabListProps extends Omit<HTMLAttributes<HTMLDivElement>, "role" | "onKeyDown"> {
  "aria-label": string;
}

export interface TabProps extends Omit<ButtonHTMLAttributes<HTMLButtonElement>, "value" | "type" | "role"> {
  value: string;
}

export interface TabPanelProps extends Omit<HTMLAttributes<HTMLDivElement>, "role"> {
  value: string;
}

interface TabsContextValue {
  baseId: string;
  selectedValue: string | undefined;
  tabStop: string | null;
  listRef: RefObject<HTMLDivElement | null>;
  select: (value: string) => void;
  requestSync: () => void;
}

const TabsContext = createContext<TabsContextValue | null>(null);

function useTabsContext(component: string): TabsContextValue {
  const context = useContext(TabsContext);
  if (!context) {
    throw new Error(`${component} must be rendered inside <Tabs>.`);
  }
  return context;
}

// Escapes every character outside [A-Za-z0-9-] as _hex_. Underscores are escaped too, so the
// mapping is injective. Never throws (unlike encodeURIComponent on lone surrogates).
// Ids are never used to build selectors.
function encodeId(value: string): string {
  return value.replace(/[^A-Za-z0-9-]/g, (char) => `_${char.charCodeAt(0).toString(16)}_`);
}
const tabDomId = (baseId: string, value: string) => `${baseId}-tab-${encodeId(value)}`;
const panelDomId = (baseId: string, value: string) => `${baseId}-panel-${encodeId(value)}`;

// Tabs whose nearest tablist is `list`, in DOM order.
function getTabs(list: HTMLElement): HTMLButtonElement[] {
  return Array.from(list.querySelectorAll<HTMLButtonElement>('[role="tab"]')).filter(
    (tab) => tab.closest('[role="tablist"]') === list,
  );
}

// The tab focus moves to for a navigation key, or undefined when the key does nothing.
function pickTab(tabs: HTMLButtonElement[], index: number, key: string): HTMLButtonElement | undefined {
  const enabled = tabs.filter((tab) => !tab.disabled);
  if (enabled.length === 0) {
    return undefined;
  }
  if (key === "Home") {
    return enabled[0];
  }
  if (key === "End") {
    return enabled[enabled.length - 1];
  }
  const direction = key === "ArrowRight" ? 1 : key === "ArrowLeft" ? -1 : 0;
  if (direction === 0) {
    return undefined;
  }
  const count = tabs.length;
  for (let step = 1; step <= count; step++) {
    const tab = tabs[(((index + direction * step) % count) + count) % count];
    if (!tab.disabled) {
      return tab;
    }
  }
  return undefined;
}

export function Tabs({ value, defaultValue, onValueChange, className, children }: TabsProps) {
  const baseId = useId();
  const isControlled = value !== undefined;
  const [internalValue, setInternalValue] = useState(defaultValue);
  const [tabStop, setTabStop] = useState<string | null>(null);
  const [version, setVersion] = useState(0);
  const listRef = useRef<HTMLDivElement>(null);
  const selectedValue = isControlled ? value : internalValue;

  const select = (next: string) => {
    if (next === selectedValue) {
      return;
    }
    if (!isControlled) {
      setInternalValue(next);
    }
    onValueChange?.(next);
  };

  // The single tab stop is the selected enabled tab, or the first enabled tab when none is selected.
  const syncTabStop = useCallback(() => {
    const list = listRef.current;
    if (!list) {
      return;
    }
    const tabs = getTabs(list);
    const enabled = tabs.filter((tab) => !tab.disabled);
    const stop = enabled.find((tab) => tab.value === selectedValue) ?? enabled[0];
    setTabStop(stop?.value ?? null);
    // Uncontrolled: keep the internal value only while it names an enabled tab in the DOM, else fall back to the first enabled tab.
    if (!isControlled && stop) {
      setInternalValue((previous) =>
        tabs.some((tab) => tab.value === previous && !tab.disabled) ? previous : stop.value,
      );
    }
  }, [selectedValue, isControlled]);

  // Tabs mount and unmount request a sync instead of syncing inline, so the sync runs against the committed DOM.
  const requestSync = useCallback(() => setVersion((v) => v + 1), []);

  // Runs after the children's refs attach, so the first sync sees the tablist even on mount.
  useLayoutEffect(() => syncTabStop(), [syncTabStop, version]);

  return (
    <TabsContext.Provider value={{ baseId, selectedValue, tabStop, listRef, select, requestSync }}>
      <div className={className}>{children}</div>
    </TabsContext.Provider>
  );
}

export function TabList({ className, children, ...rest }: TabListProps) {
  const { listRef, select } = useTabsContext("TabList");

  const handleKeyDown = (event: KeyboardEvent<HTMLDivElement>) => {
    const tabs = getTabs(event.currentTarget);
    const index = tabs.indexOf(event.target as HTMLButtonElement);
    const next = index === -1 ? undefined : pickTab(tabs, index, event.key);
    if (!next) {
      return;
    }
    event.preventDefault();
    next.focus();
    select(next.value);
  };

  return (
    <div
      {...rest}
      ref={listRef}
      role="tablist"
      aria-orientation="horizontal"
      className={className}
      onKeyDown={handleKeyDown}
    >
      {children}
    </div>
  );
}

export function Tab({ value, disabled = false, className, children, ...rest }: TabProps) {
  const { baseId, selectedValue, tabStop, select, requestSync } = useTabsContext("Tab");
  const ref = useRef<HTMLButtonElement>(null);

  useLayoutEffect(() => {
    requestSync();
    return requestSync;
  }, [requestSync, value, disabled]);

  const selected = value === selectedValue;

  return (
    <button
      {...rest}
      ref={ref}
      type="button"
      role="tab"
      id={tabDomId(baseId, value)}
      value={value}
      disabled={disabled}
      aria-selected={selected}
      aria-controls={panelDomId(baseId, value)}
      aria-disabled={disabled ? "true" : undefined}
      tabIndex={value === tabStop ? 0 : -1}
      className={className}
      onClick={(event) => {
        rest.onClick?.(event);
        event.currentTarget.focus();
        select(value);
      }}
    >
      {children}
    </button>
  );
}

export function TabPanel({ value, className, children, ...rest }: TabPanelProps) {
  const { baseId, selectedValue } = useTabsContext("TabPanel");

  return (
    <div
      {...rest}
      role="tabpanel"
      id={panelDomId(baseId, value)}
      aria-labelledby={tabDomId(baseId, value)}
      tabIndex={0}
      hidden={value !== selectedValue}
      className={className}
    >
      {children}
    </div>
  );
}

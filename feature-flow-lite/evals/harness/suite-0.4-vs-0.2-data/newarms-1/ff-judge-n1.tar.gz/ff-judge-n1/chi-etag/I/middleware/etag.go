package middleware

import (
	"bufio"
	"bytes"
	"crypto/sha256"
	"encoding/hex"
	"errors"
	"fmt"
	"net"
	"net/http"
	"strings"
)

// ETag adds a strong ETag to 200 responses to GET and HEAD requests. The ETag
// is the hex SHA-256 digest of the response body. An ETag set by the handler is
// never overwritten. When If-None-Match matches the response's ETag, ETag
// answers 304 Not Modified with no body.
//
// ETag buffers the full GET or HEAD response in memory before sending it, so
// it is unsuitable for very large bodies. A HEAD response gets an ETag only when
// the handler wrote body bytes. Calling Flush stops buffering: the response is
// sent as is, without an ETag or a 304.
//
// Placed outside Compress, ETag hashes the encoded bytes. Placed inside Compress
// (Compress(ETag(h))), ETag hashes the uncompressed bytes. NoCache strips
// If-None-Match from the request, so ETag never answers 304 when NoCache runs
// before it.
func ETag(next http.Handler) http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		if r.Method != http.MethodGet && r.Method != http.MethodHead {
			next.ServeHTTP(w, r)
			return
		}

		ew := &etagResponseWriter{
			ResponseWriter: w,
			method:         r.Method,
			ifNoneMatch:    r.Header.Values("If-None-Match"),
		}
		next.ServeHTTP(ew, r)
		ew.finish()
	})
}

type etagResponseWriter struct {
	http.ResponseWriter
	method      string
	ifNoneMatch []string
	status      int
	wroteHeader bool
	streaming   bool
	buf         bytes.Buffer
}

func (w *etagResponseWriter) WriteHeader(code int) {
	if code < 100 || code > 999 {
		panic(fmt.Sprintf("invalid WriteHeader code %v", code))
	}

	// 1xx informational responses (other than 101) go out immediately and
	// are not the final status.
	if code >= 100 && code <= 199 && code != http.StatusSwitchingProtocols {
		if !w.wroteHeader {
			w.ResponseWriter.WriteHeader(code)
		}
		return
	}

	if w.wroteHeader {
		return
	}
	w.status = code
	w.wroteHeader = true
}

func (w *etagResponseWriter) Write(p []byte) (int, error) {
	if !w.wroteHeader {
		w.WriteHeader(http.StatusOK)
	}

	if w.streaming {
		return w.ResponseWriter.Write(p)
	}
	return w.buf.Write(p)
}

func (w *etagResponseWriter) Flush() {
	if !w.streaming {
		w.start()
	}
	if f, ok := w.ResponseWriter.(http.Flusher); ok {
		f.Flush()
	}
}

// start stops buffering. It sends the status, headers and buffered body
// unchanged, so later writes go straight to the underlying writer.
func (w *etagResponseWriter) start() {
	if !w.wroteHeader {
		w.WriteHeader(http.StatusOK)
	}
	w.streaming = true
	w.ResponseWriter.WriteHeader(w.status)
	w.ResponseWriter.Write(w.buf.Bytes())
	w.buf = bytes.Buffer{}
}

// finish sends the buffered response once the handler has returned.
func (w *etagResponseWriter) finish() {
	if w.streaming {
		return
	}
	if !w.wroteHeader {
		w.WriteHeader(http.StatusOK)
	}

	if w.status == http.StatusOK {
		w.addETag()
		if etagNotModified(w.ifNoneMatch, w.Header().Get("ETag")) {
			// Send a 304 without the representation headers, as net/http does.
			h := w.Header()
			h.Del("Content-Type")
			h.Del("Content-Length")
			h.Del("Content-Encoding")
			if h.Get("ETag") != "" {
				h.Del("Last-Modified")
			}
			w.ResponseWriter.WriteHeader(http.StatusNotModified)
			return
		}
	}
	w.start()
}

// addETag sets the strong body-derived ETag unless the handler set one. A HEAD
// response with no body bytes gets none, since the empty digest is not the
// digest of the GET representation.
func (w *etagResponseWriter) addETag() {
	if w.Header().Get("ETag") != "" {
		return
	}
	if w.method == http.MethodHead && w.buf.Len() == 0 {
		return
	}
	sum := sha256.Sum256(w.buf.Bytes())
	w.Header().Set("ETag", `"`+hex.EncodeToString(sum[:])+`"`)
}

// etagNotModified reports whether any If-None-Match header line matches etag.
func etagNotModified(ifNoneMatch []string, etag string) bool {
	for _, line := range ifNoneMatch {
		if etagListMatches(line, etag) {
			return true
		}
	}
	return false
}

// etagListMatches parses a comma-separated If-None-Match list per RFC 9110
// section 13.1.2. A malformed member ends the list without a match.
func etagListMatches(list, etag string) bool {
	rest := list
	for {
		rest = strings.Trim(rest, " \t")
		if rest == "" {
			return false
		}
		if rest[0] == ',' {
			rest = rest[1:]
			continue
		}
		if rest[0] == '*' {
			after := strings.TrimLeft(rest[1:], " \t")
			return after == "" || after[0] == ','
		}

		tag, after, ok := scanETag(rest)
		if !ok {
			return false
		}
		// Weak comparison (RFC 9110 section 8.8.3.2) ignores a W/ prefix.
		if strings.TrimPrefix(tag, "W/") == strings.TrimPrefix(etag, "W/") {
			return true
		}
		rest = strings.TrimLeft(after, " \t")
		if rest != "" && rest[0] != ',' {
			return false
		}
	}
}

// scanETag reads one entity-tag, either "opaque-tag" or W/"opaque-tag", from
// the front of s. It returns the tag and the text after it.
func scanETag(s string) (tag, rest string, ok bool) {
	start := 0
	if strings.HasPrefix(s, "W/") {
		start = 2
	}
	if len(s) < start+2 || s[start] != '"' {
		return "", "", false
	}
	for i := start + 1; i < len(s); i++ {
		c := s[i]
		if c == '"' {
			return s[:i+1], s[i+1:], true
		}
		// etagc: %x21 / %x23-7E / obs-text (%x80-FF)
		if c != 0x21 && (c < 0x23 || c > 0x7E) && c < 0x80 {
			return "", "", false
		}
	}
	return "", "", false
}

func (w *etagResponseWriter) Hijack() (net.Conn, *bufio.ReadWriter, error) {
	if hj, ok := w.ResponseWriter.(http.Hijacker); ok {
		// Hand what the handler already wrote to the underlying writer, so
		// Hijack behaves as it would without ETag.
		if w.wroteHeader && !w.streaming {
			w.start()
		}
		// The handler owns the connection now, so nothing else may be written.
		w.streaming = true
		return hj.Hijack()
	}
	return nil, nil, errors.New("chi/middleware: http.Hijacker is unavailable on the writer")
}

func (w *etagResponseWriter) Push(target string, opts *http.PushOptions) error {
	if ps, ok := w.ResponseWriter.(http.Pusher); ok {
		return ps.Push(target, opts)
	}
	return errors.New("chi/middleware: http.Pusher is unavailable on the writer")
}

func (w *etagResponseWriter) Unwrap() http.ResponseWriter {
	return w.ResponseWriter
}

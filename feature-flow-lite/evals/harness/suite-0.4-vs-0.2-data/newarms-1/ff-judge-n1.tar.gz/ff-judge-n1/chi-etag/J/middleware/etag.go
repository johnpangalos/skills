package middleware

import (
	"bufio"
	"bytes"
	"crypto/sha256"
	"encoding/hex"
	"errors"
	"net"
	"net/http"
	"strings"
)

// ETag buffers the whole response of GET and HEAD requests in memory. When the
// final status is 200 and the handler did not set an ETag header, it sets a
// strong ETag computed from the SHA-256 of the body. If If-None-Match matches
// the response ETag, it answers 304 Not Modified with an empty body instead.
// If-None-Match uses the weak comparison of RFC 9110, so a W/ prefix is ignored
// on either side. Because the body is held in memory, ETag is unsuited to large
// or streamed responses. Other methods and non-200 responses pass through
// unchanged, and calling Flush stops buffering and commits the response as it
// stands.
func ETag(next http.Handler) http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		if r.Method != http.MethodGet && r.Method != http.MethodHead {
			next.ServeHTTP(w, r)
			return
		}

		ew := &etagResponseWriter{
			ResponseWriter: w,
			ifNoneMatch:    r.Header.Values("If-None-Match"),
		}
		next.ServeHTTP(ew, r)
		ew.finish()
	})
}

type etagResponseWriter struct {
	http.ResponseWriter

	ifNoneMatch []string
	buf         bytes.Buffer
	status      int
	wroteHeader bool
	streaming   bool
	hijacked    bool
}

func (ew *etagResponseWriter) WriteHeader(code int) {
	// Informational responses are forwarded immediately and do not set the final status.
	if code >= 100 && code <= 199 {
		ew.ResponseWriter.WriteHeader(code)
		return
	}
	if ew.wroteHeader {
		return
	}
	ew.wroteHeader = true
	ew.status = code
	if code != http.StatusOK {
		ew.startStreaming()
	}
}

func (ew *etagResponseWriter) Write(p []byte) (int, error) {
	if !ew.wroteHeader {
		ew.WriteHeader(http.StatusOK)
	}
	if ew.streaming {
		return ew.ResponseWriter.Write(p)
	}
	return ew.buf.Write(p)
}

func (ew *etagResponseWriter) Flush() {
	if !ew.streaming {
		if !ew.wroteHeader {
			ew.WriteHeader(http.StatusOK)
		}
		ew.startStreaming()
	}
	if f, ok := ew.ResponseWriter.(http.Flusher); ok {
		f.Flush()
	}
}

// startStreaming commits the status and headers as they stand, writes any
// buffered body, and sends everything after it straight through.
func (ew *etagResponseWriter) startStreaming() {
	ew.streaming = true
	ew.ResponseWriter.WriteHeader(ew.status)
	if ew.buf.Len() > 0 {
		ew.ResponseWriter.Write(ew.buf.Bytes())
		ew.buf.Reset()
	}
}

// finish completes a buffered response once the handler has returned.
func (ew *etagResponseWriter) finish() {
	if ew.streaming || ew.hijacked {
		return
	}
	if !ew.wroteHeader {
		ew.status = http.StatusOK
	}

	h := ew.ResponseWriter.Header()
	if h.Get("ETag") == "" {
		sum := sha256.Sum256(ew.buf.Bytes())
		h.Set("ETag", `"`+hex.EncodeToString(sum[:])+`"`)
	}
	if etagMatches(ew.ifNoneMatch, h.Get("ETag")) {
		// Mirrors net/http's writeNotModified.
		h.Del("Content-Type")
		h.Del("Content-Length")
		h.Del("Content-Encoding")
		h.Del("Last-Modified")
		ew.ResponseWriter.WriteHeader(http.StatusNotModified)
		return
	}
	ew.startStreaming()
}

func (ew *etagResponseWriter) Hijack() (net.Conn, *bufio.ReadWriter, error) {
	if hj, ok := ew.ResponseWriter.(http.Hijacker); ok {
		conn, rw, err := hj.Hijack()
		ew.hijacked = err == nil
		return conn, rw, err
	}
	return nil, nil, errors.New("chi/middleware: http.Hijacker is unavailable on the writer")
}

func (ew *etagResponseWriter) Push(target string, opts *http.PushOptions) error {
	if ps, ok := ew.ResponseWriter.(http.Pusher); ok {
		return ps.Push(target, opts)
	}
	return errors.New("chi/middleware: http.Pusher is unavailable on the writer")
}

func (ew *etagResponseWriter) Unwrap() http.ResponseWriter {
	return ew.ResponseWriter
}

// etagMatches reports whether any If-None-Match line matches etag. A line whose
// whole value is "*" matches any ETag.
func etagMatches(lines []string, etag string) bool {
	for _, line := range lines {
		if strings.Trim(line, " \t") == "*" {
			return true
		}
		if etagListMatches(line, etag) {
			return true
		}
	}
	return false
}

// etagListMatches reports whether a comma-separated list of entity tags contains
// a member that weakly matches etag. Empty members are skipped and parsing stops
// at the first malformed member, as net/http's checkIfNoneMatch does.
func etagListMatches(list, etag string) bool {
	if valid, _ := scanETag(etag); valid != etag {
		return false
	}
	for {
		list = strings.Trim(list, " \t")
		if list == "" {
			return false
		}
		if list[0] == ',' {
			list = list[1:]
			continue
		}
		member, rest := scanETag(list)
		if member == "" {
			return false
		}
		// Weak comparison (RFC 9110): ignore a W/ prefix on either side.
		if strings.TrimPrefix(member, "W/") == strings.TrimPrefix(etag, "W/") {
			return true
		}
		list = rest
	}
}

// scanETag returns the entity tag at the start of s, including its optional W/
// prefix and quotes, along with the rest of s. It returns "" when s does not
// start with a well-formed entity tag.
func scanETag(s string) (tag, rest string) {
	start := 0
	if strings.HasPrefix(s, "W/") {
		start = 2
	}
	if len(s) <= start || s[start] != '"' {
		return "", ""
	}
	for i := start + 1; i < len(s); i++ {
		switch c := s[i]; {
		case c == '"':
			return s[:i+1], s[i+1:]
		case c == 0x21 || (c >= 0x23 && c <= 0x7E) || c >= 0x80:
			// etagc characters per RFC 9110.
		default:
			return "", ""
		}
	}
	return "", ""
}

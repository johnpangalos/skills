package middleware

import (
	"bufio"
	"bytes"
	"crypto/sha256"
	"encoding/hex"
	"errors"
	"net"
	"net/http"
	"strings"
)

// ETag sets a strong ETag on GET and HEAD responses with status 200 that the
// handler did not give an ETag, and answers 304 Not Modified when the request's
// If-None-Match matches the response's ETag.
//
// The generated ETag is the first 128 bits of the SHA-256 of the whole body,
// hex-encoded and quoted. To compute it, the body is buffered in memory until
// the handler returns, so memory use grows with the response size. Responses
// with any other status on GET and HEAD are buffered too and sent unchanged
// when the handler returns; they are not streamed. A 304 keeps the headers the
// handler set, except Content-Length and Content-Type, and has no body. A
// handler-set ETag, strong or weak, is kept and is the value matched against
// If-None-Match. Calling Flush ends buffering: the response is sent as it
// stands, with no generated ETag and no 304, and later writes go straight
// through. Other methods pass through unchanged.
//
// For a distinct ETag per content coding, put ETag before Compress, so the
// hash covers the encoded body:
//
//	r.Use(middleware.ETag, middleware.Compress(5))
//
// NoCache deletes If-None-Match, so ETag produces no 304s behind it.
func ETag(next http.Handler) http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		if r.Method != http.MethodGet && r.Method != http.MethodHead {
			next.ServeHTTP(w, r)
			return
		}
		ew := &etagResponseWriter{ResponseWriter: w}
		next.ServeHTTP(ew, r)
		ew.finish(r)
	})
}

type etagResponseWriter struct {
	http.ResponseWriter

	status      int         // final status; 0 until the handler sets one
	header      http.Header // headers as they were when the final status was set; nil until then
	body        bytes.Buffer
	passthrough bool // true once the response is sent or hijacked
}

func (ew *etagResponseWriter) WriteHeader(code int) {
	// Informational responses other than 101 are not the final status.
	if ew.passthrough || (code >= 100 && code < 200 && code != http.StatusSwitchingProtocols) {
		ew.ResponseWriter.WriteHeader(code)
		return
	}
	if ew.status == 0 { // the first call wins, as in net/http
		ew.status = code
		ew.header = ew.ResponseWriter.Header().Clone()
	}
}

func (ew *etagResponseWriter) Write(p []byte) (int, error) {
	if ew.passthrough {
		return ew.ResponseWriter.Write(p)
	}
	if ew.status == 0 {
		ew.WriteHeader(http.StatusOK)
	}
	return ew.body.Write(p)
}

// finish decides the final response for r and sends it.
func (ew *etagResponseWriter) finish(r *http.Request) {
	if ew.passthrough {
		return
	}
	ew.restore()
	if ew.status == 0 {
		ew.status = http.StatusOK
	}
	if ew.status == http.StatusOK {
		if ew.Header().Get("ETag") == "" && (r.Method == http.MethodGet || ew.body.Len() > 0) {
			ew.Header().Set("ETag", etagFor(ew.body.Bytes()))
		}
		if ifNoneMatch(r.Header, ew.Header().Get("ETag")) {
			ew.status = http.StatusNotModified
			ew.body.Reset()
			ew.Header().Del("Content-Length")
			ew.Header().Del("Content-Type")
		}
	}
	ew.send()
}

// send writes the pending status, headers and buffered body to the underlying
// writer, and switches to pass-through. It does nothing once already sent.
func (ew *etagResponseWriter) send() {
	if ew.passthrough {
		return
	}
	ew.passthrough = true
	if ew.status != 0 {
		ew.ResponseWriter.WriteHeader(ew.status)
		if ew.body.Len() > 0 {
			ew.ResponseWriter.Write(ew.body.Bytes())
		}
	}
	ew.body.Reset()
}

// restore sets the underlying header map back to the headers the handler had
// when it set the final status, so changes made after that do not go out.
func (ew *etagResponseWriter) restore() {
	if ew.passthrough || ew.header == nil {
		return
	}
	h := ew.ResponseWriter.Header()
	for k := range h {
		if _, ok := ew.header[k]; !ok {
			delete(h, k)
		}
	}
	for k, v := range ew.header {
		h[k] = v
	}
}

func (ew *etagResponseWriter) Flush() {
	if ew.status == 0 {
		ew.status = http.StatusOK
	}
	ew.restore()
	ew.send()
	if f, ok := ew.ResponseWriter.(http.Flusher); ok {
		f.Flush()
	}
}

func (ew *etagResponseWriter) Hijack() (net.Conn, *bufio.ReadWriter, error) {
	hj, ok := ew.ResponseWriter.(http.Hijacker)
	if !ok {
		return nil, nil, errors.New("chi/middleware: http.Hijacker is unavailable on the writer")
	}
	ew.restore()
	ew.send()
	return hj.Hijack()
}

func (ew *etagResponseWriter) Push(target string, opts *http.PushOptions) error {
	if ps, ok := ew.ResponseWriter.(http.Pusher); ok {
		return ps.Push(target, opts)
	}
	return errors.New("chi/middleware: http.Pusher is unavailable on the writer")
}

func (ew *etagResponseWriter) Unwrap() http.ResponseWriter {
	return ew.ResponseWriter
}

// etagFor returns the strong ETag for body: its SHA-256 digest, cut to 128 bits.
func etagFor(body []byte) string {
	sum := sha256.Sum256(body)
	return `"` + hex.EncodeToString(sum[:16]) + `"`
}

// ifNoneMatch reports whether the If-None-Match header matches etag under the
// weak comparison of RFC 9110 section 8.8.3.2. A field value of "*" matches any
// response. Header lines are read as one comma-separated list.
func ifNoneMatch(h http.Header, etag string) bool {
	list := strings.Join(h.Values("If-None-Match"), ",")
	if strings.Trim(list, " \t") == "*" {
		return true
	}
	want, ok := opaqueTag(etag)
	if !ok {
		return false
	}
	for {
		list = strings.TrimLeft(list, " \t,")
		if list == "" {
			return false
		}
		var member string
		member, list = cutMember(list)
		if tag, ok := opaqueTag(member); ok && tag == want {
			return true
		}
	}
}

// cutMember splits the first member off a comma-separated list. A comma inside
// a quoted string does not split the list.
func cutMember(list string) (member, rest string) {
	quoted := false
	for i := 0; i < len(list); i++ {
		switch list[i] {
		case '"':
			quoted = !quoted
		case ',':
			if !quoted {
				return strings.Trim(list[:i], " \t"), list[i+1:]
			}
		}
	}
	return strings.Trim(list, " \t"), ""
}

// opaqueTag returns the entity-tag s with any W/ prefix removed, and reports
// whether s is a well-formed entity-tag: a quoted string with no quote inside.
func opaqueTag(s string) (string, bool) {
	tag := strings.TrimPrefix(s, "W/")
	if len(tag) < 2 || tag[0] != '"' || tag[len(tag)-1] != '"' || strings.Contains(tag[1:len(tag)-1], `"`) {
		return "", false
	}
	return tag, true
}

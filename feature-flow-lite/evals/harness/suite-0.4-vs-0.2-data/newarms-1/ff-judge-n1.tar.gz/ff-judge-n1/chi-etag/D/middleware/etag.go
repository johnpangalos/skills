package middleware

import (
	"bufio"
	"bytes"
	"crypto/sha256"
	"encoding/hex"
	"errors"
	"net"
	"net/http"
	"strconv"
	"strings"
)

// ETag buffers the response to GET and HEAD requests. When the final status is
// 200 and the handler did not set an ETag header, it sets a strong ETag computed
// from the SHA-256 of the body. If the request's If-None-Match matches the ETag
// (weak comparison, RFC 9110 section 13.1.2; "*" matches any 200 response), it
// answers 304 Not Modified with no body, keeping the handler's non-content headers.
// Any other status is passed through unbuffered as soon as WriteHeader is called,
// and every request with another method is not wrapped at all. Flush ends
// buffering: the response is committed with the body so far, and later writes
// stream straight through. Hijack commits the buffered response the same way
// before it hands over the connection. Header changes made after the final 200
// is recorded are ignored, as in net/http.
func ETag(next http.Handler) http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		if r.Method != http.MethodGet && r.Method != http.MethodHead {
			next.ServeHTTP(w, r)
			return
		}
		ew := &etagResponseWriter{
			ResponseWriter: w,
			head:           r.Method == http.MethodHead,
			ifNoneMatch:    r.Header.Values("If-None-Match"),
		}
		next.ServeHTTP(ew, r)
		ew.finish()
	})
}

type etagResponseWriter struct {
	http.ResponseWriter
	buf         bytes.Buffer
	head        bool
	ifNoneMatch []string
	status      int         // final status; 0 until known
	snapshot    http.Header // headers as they stood when the final 200 was recorded
	committed   bool        // status and headers have been sent; writes go straight through
}

func (ew *etagResponseWriter) WriteHeader(code int) {
	if code >= 100 && code <= 199 && code != http.StatusSwitchingProtocols {
		ew.ResponseWriter.WriteHeader(code)
		return
	}
	if ew.status != 0 {
		return
	}
	ew.status = code
	if code != http.StatusOK {
		ew.commit()
	} else {
		ew.snapshot = ew.Header().Clone()
	}
}

func (ew *etagResponseWriter) Write(p []byte) (int, error) {
	ew.WriteHeader(http.StatusOK)
	if ew.committed {
		return ew.ResponseWriter.Write(p)
	}
	return ew.buf.Write(p)
}

func (ew *etagResponseWriter) Flush() {
	if !ew.committed {
		ew.WriteHeader(http.StatusOK)
		ew.commitBuffered()
	}
	if f, ok := ew.ResponseWriter.(http.Flusher); ok {
		f.Flush()
	}
}

func (ew *etagResponseWriter) Hijack() (net.Conn, *bufio.ReadWriter, error) {
	hj, ok := ew.ResponseWriter.(http.Hijacker)
	if !ok {
		return nil, nil, errors.New("chi/middleware: http.Hijacker is unavailable on the writer")
	}
	if !ew.committed && ew.status != 0 {
		ew.commitBuffered()
	}
	conn, rw, err := hj.Hijack()
	if err == nil {
		ew.committed = true // the connection is the handler's now; finish must not write
	}
	return conn, rw, err
}

func (ew *etagResponseWriter) Push(target string, opts *http.PushOptions) error {
	if ps, ok := ew.ResponseWriter.(http.Pusher); ok {
		return ps.Push(target, opts)
	}
	return errors.New("chi/middleware: http.Pusher is unavailable on the writer")
}

func (ew *etagResponseWriter) Unwrap() http.ResponseWriter {
	return ew.ResponseWriter
}

// commit sends the status and the headers as they stand; it makes no ETag decision.
func (ew *etagResponseWriter) commit() {
	ew.committed = true
	ew.ResponseWriter.WriteHeader(ew.status)
}

// commitBuffered sends the pending 200 with the headers it was recorded with,
// then the buffered body, and stops buffering. It makes no ETag decision.
func (ew *etagResponseWriter) commitBuffered() {
	ew.restoreHeader()
	ew.commit()
	ew.ResponseWriter.Write(ew.buf.Bytes())
}

// restoreHeader resets the live header map to the snapshot taken when the final
// 200 was recorded, so header changes made after that point are dropped. Trailer
// values, which handlers set after writing, are kept.
func (ew *etagResponseWriter) restoreHeader() {
	if ew.snapshot == nil {
		return
	}
	h := ew.Header()
	for k := range h {
		if !isTrailer(ew.snapshot, k) {
			delete(h, k)
		}
	}
	for k, v := range ew.snapshot {
		h[k] = v
	}
}

// finish runs once the handler returns. Responses that were not committed
// earlier have status 200, so it either answers 304 or sends the buffered body.
func (ew *etagResponseWriter) finish() {
	if ew.committed {
		return
	}
	ew.WriteHeader(http.StatusOK)
	ew.restoreHeader()
	h := ew.Header()
	if h.Get("ETag") == "" && (!ew.head || ew.buf.Len() > 0) {
		h.Set("ETag", strongETag(ew.buf.Bytes()))
	}
	if ifNoneMatchMatches(ew.ifNoneMatch, h.Get("ETag")) {
		h.Del("Content-Type")
		h.Del("Content-Length")
		h.Del("Content-Encoding")
		ew.status = http.StatusNotModified
		ew.commit()
		return
	}
	if !ew.head && h.Get("Content-Length") == "" && !hasTrailers(h) {
		h.Set("Content-Length", strconv.Itoa(ew.buf.Len()))
	}
	ew.commit()
	ew.ResponseWriter.Write(ew.buf.Bytes())
}

// isTrailer reports whether key is a trailer: declared in h's Trailer header
// or named with http.TrailerPrefix.
func isTrailer(h http.Header, key string) bool {
	if strings.HasPrefix(key, http.TrailerPrefix) {
		return true
	}
	for _, v := range h.Values("Trailer") {
		for _, name := range strings.Split(v, ",") {
			if http.CanonicalHeaderKey(strings.TrimSpace(name)) == key {
				return true
			}
		}
	}
	return false
}

// hasTrailers reports whether the response declares or sets trailers, which a
// Content-Length would stop net/http from sending.
func hasTrailers(h http.Header) bool {
	if len(h.Values("Trailer")) > 0 {
		return true
	}
	for k := range h {
		if strings.HasPrefix(k, http.TrailerPrefix) {
			return true
		}
	}
	return false
}

// strongETag returns a strong entity-tag: the quoted hex SHA-256 of the body.
func strongETag(body []byte) string {
	sum := sha256.Sum256(body)
	return `"` + hex.EncodeToString(sum[:]) + `"`
}

// ifNoneMatchMatches reports whether any If-None-Match header line matches etag.
func ifNoneMatchMatches(lines []string, etag string) bool {
	for _, line := range lines {
		if strings.Trim(line, " \t") == "*" {
			return true
		}
		if etagListMatches(line, etag) {
			return true
		}
	}
	return false
}

// etagListMatches scans a comma-separated list of entity-tags. Commas inside
// quotes belong to the tag, so the list is not split on ",". A malformed member
// ends the scan without a match.
func etagListMatches(list, etag string) bool {
	for {
		list = strings.TrimLeft(list, " \t,")
		if list == "" {
			return false
		}
		member, rest, ok := scanETag(list)
		if !ok {
			return false
		}
		rest = strings.TrimLeft(rest, " \t")
		if rest != "" && rest[0] != ',' {
			return false
		}
		if opaqueTag(member) == opaqueTag(etag) {
			return true
		}
		list = rest
	}
}

// scanETag reads one entity-tag from the start of s: an optional "W/" prefix,
// then a quoted run of etagc characters (RFC 9110 section 8.8.3). It returns the
// tag and the text after its closing quote.
func scanETag(s string) (tag, rest string, ok bool) {
	start := 0
	if strings.HasPrefix(s, "W/") {
		start = 2
	}
	if start >= len(s) || s[start] != '"' {
		return "", "", false
	}
	for i := start + 1; i < len(s); i++ {
		c := s[i]
		if c == '"' {
			return s[:i+1], s[i+1:], true
		}
		if c <= 0x20 || c == 0x7F {
			return "", "", false
		}
	}
	return "", "", false
}

// opaqueTag drops the weakness indicator, which weak comparison ignores.
func opaqueTag(tag string) string {
	return strings.TrimPrefix(tag, "W/")
}

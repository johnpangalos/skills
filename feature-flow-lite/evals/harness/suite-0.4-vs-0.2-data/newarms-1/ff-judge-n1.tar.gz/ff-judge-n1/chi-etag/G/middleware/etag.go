package middleware

import (
	"bufio"
	"bytes"
	"crypto/sha256"
	"encoding/hex"
	"errors"
	"net"
	"net/http"
	"strings"
)

// ETag buffers whole GET and HEAD responses in memory. A 200 response that the
// handler gave no ETag gets a strong one: the quoted SHA-256 of the body bytes.
// If-None-Match is matched as RFC 9110 section 13.1.2 describes (weak comparison,
// comma-separated lists, and "*" alone), and a match is answered with 304 Not
// Modified and no body. Other methods and other statuses pass through unchanged.
// A handler that calls Flush stops the buffering: its response streams as is,
// without an ETag.
//
// Register ETag outside (before) Compress so each encoding gets its own ETag.
func ETag(next http.Handler) http.Handler {
	fn := func(w http.ResponseWriter, r *http.Request) {
		if r.Method != http.MethodGet && r.Method != http.MethodHead {
			next.ServeHTTP(w, r)
			return
		}

		ew := &etagResponseWriter{ResponseWriter: w}
		next.ServeHTTP(ew, r)
		ew.finish(r)
	}

	return http.HandlerFunc(fn)
}

type etagResponseWriter struct {
	http.ResponseWriter
	wroteHeader bool
	status      int
	header      http.Header // headers as they were at the final WriteHeader
	body        bytes.Buffer
	streaming   bool  // set by Flush; from then on writes go straight through
	hijacked    bool  // set by a successful Hijack; the connection is no longer ours
	err         error // error from writing the buffered body during Flush
}

func (ew *etagResponseWriter) WriteHeader(code int) {
	if ew.wroteHeader {
		return
	}

	// Informational responses are sent right away and are not the final status.
	if code >= 100 && code < 200 && code != http.StatusSwitchingProtocols {
		ew.ResponseWriter.WriteHeader(code)
		return
	}

	ew.wroteHeader = true
	ew.status = code
	ew.header = ew.Header().Clone()
}

func (ew *etagResponseWriter) Write(p []byte) (int, error) {
	if ew.streaming {
		if ew.err != nil {
			return 0, ew.err
		}
		return ew.ResponseWriter.Write(p)
	}

	if !ew.wroteHeader {
		ew.WriteHeader(http.StatusOK)
	}
	return ew.body.Write(p)
}

func (ew *etagResponseWriter) Flush() {
	if !ew.streaming {
		ew.stream()
	}

	if f, ok := ew.ResponseWriter.(http.Flusher); ok {
		f.Flush()
	}
}

// stream stops buffering: the status, headers and body so far are sent unchanged.
func (ew *etagResponseWriter) stream() {
	if !ew.wroteHeader {
		ew.WriteHeader(http.StatusOK)
	}

	trailers := ew.liveTrailers()
	ew.sendHeader(ew.status)
	if ew.body.Len() > 0 {
		_, ew.err = ew.ResponseWriter.Write(ew.body.Bytes())
	}
	ew.restoreTrailers(trailers)
	ew.streaming = true
}

func (ew *etagResponseWriter) Hijack() (net.Conn, *bufio.ReadWriter, error) {
	if hj, ok := ew.ResponseWriter.(http.Hijacker); ok {
		conn, rw, err := hj.Hijack()
		ew.hijacked = err == nil
		return conn, rw, err
	}
	return nil, nil, errors.New("chi/middleware: http.Hijacker is unavailable on the writer")
}

func (ew *etagResponseWriter) Push(target string, opts *http.PushOptions) error {
	if ps, ok := ew.ResponseWriter.(http.Pusher); ok {
		return ps.Push(target, opts)
	}
	return errors.New("chi/middleware: http.Pusher is unavailable on the writer")
}

func (ew *etagResponseWriter) Unwrap() http.ResponseWriter {
	return ew.ResponseWriter
}

// finish sends the buffered response once the handler has returned.
func (ew *etagResponseWriter) finish(r *http.Request) {
	if ew.streaming || ew.hijacked {
		return
	}

	if !ew.wroteHeader {
		ew.WriteHeader(http.StatusOK)
	}

	if ew.status == http.StatusOK {
		etag := ew.header.Get("ETag")
		if etag == "" && (r.Method == http.MethodGet || ew.body.Len() > 0) {
			etag = etagFor(ew.body.Bytes())
			ew.header.Set("ETag", etag)
		}

		if etagNotModified(r.Header.Values("If-None-Match"), etag) {
			ew.header.Del("Content-Type")
			ew.header.Del("Content-Length")
			ew.header.Del("Content-Encoding")
			ew.sendHeader(http.StatusNotModified)
			return
		}
	}

	trailers := ew.liveTrailers()
	ew.sendHeader(ew.status)
	if ew.body.Len() > 0 {
		ew.ResponseWriter.Write(ew.body.Bytes())
	}
	ew.restoreTrailers(trailers)
}

// sendHeader replaces the underlying headers with the snapshot and writes status.
func (ew *etagResponseWriter) sendHeader(status int) {
	dst := ew.ResponseWriter.Header()
	for k := range dst {
		delete(dst, k)
	}
	for k, v := range ew.header {
		dst[k] = v
	}
	ew.ResponseWriter.WriteHeader(status)
}

// liveTrailers returns the handler's current values for the trailers declared in
// the snapshot and for any http.TrailerPrefix keys. sendHeader would drop them.
func (ew *etagResponseWriter) liveTrailers() http.Header {
	live := ew.ResponseWriter.Header()
	trailers := http.Header{}
	for _, v := range ew.header.Values("Trailer") {
		for _, name := range strings.Split(v, ",") {
			k := http.CanonicalHeaderKey(strings.TrimSpace(name))
			if vv, ok := live[k]; ok {
				trailers[k] = vv
			}
		}
	}
	for k, vv := range live {
		if strings.HasPrefix(k, http.TrailerPrefix) {
			trailers[k] = vv
		}
	}
	return trailers
}

// restoreTrailers puts back the values from liveTrailers once the body is written.
func (ew *etagResponseWriter) restoreTrailers(trailers http.Header) {
	dst := ew.ResponseWriter.Header()
	for k, vv := range trailers {
		dst[k] = vv
	}
}

// etagFor returns the strong entity-tag for body: its SHA-256 in hex, in quotes.
func etagFor(body []byte) string {
	sum := sha256.Sum256(body)
	return `"` + hex.EncodeToString(sum[:]) + `"`
}

// etagNotModified reports whether If-None-Match matches etag. A lone "*" matches
// any etag, and a malformed etag matches nothing else.
func etagNotModified(values []string, etag string) bool {
	if len(values) == 1 && strings.Trim(values[0], " \t") == "*" {
		return true
	}

	opaque, ok := etagOpaque(etag)
	if !ok {
		return false
	}
	for _, v := range values {
		for _, member := range etagList(v) {
			if m, ok := etagOpaque(member); ok && m == opaque {
				return true
			}
		}
	}
	return false
}

// etagList splits an If-None-Match value at the commas that are outside quotes.
// Members are trimmed of optional whitespace and may be empty.
func etagList(v string) []string {
	var members []string
	start, quoted := 0, false
	for i := 0; i < len(v); i++ {
		switch v[i] {
		case '"':
			quoted = !quoted
		case ',':
			if !quoted {
				members = append(members, strings.Trim(v[start:i], " \t"))
				start = i + 1
			}
		}
	}
	return append(members, strings.Trim(v[start:], " \t"))
}

// etagOpaque returns the opaque-tag of a well-formed entity-tag such as "x" or W/"x".
func etagOpaque(tag string) (string, bool) {
	tag = strings.TrimPrefix(tag, "W/")
	if len(tag) < 2 || tag[0] != '"' || tag[len(tag)-1] != '"' {
		return "", false
	}

	opaque := tag[1 : len(tag)-1]
	if strings.Contains(opaque, `"`) {
		return "", false
	}
	return opaque, true
}

package middleware

import (
	"bufio"
	"bytes"
	"context"
	"errors"
	"io"
	"log"
	"net"
	"net/http"
	"net/http/httptest"
	"net/http/httptrace"
	"net/textproto"
	"regexp"
	"strings"
	"testing"
	"time"

	"github.com/go-chi/chi/v5"
)

var errEtagSentinel = errors.New("sentinel")

// etagFullRecorder is a recorder that also implements http.Hijacker and http.Pusher.
type etagFullRecorder struct {
	*httptest.ResponseRecorder
}

func (etagFullRecorder) Hijack() (net.Conn, *bufio.ReadWriter, error) {
	return nil, nil, errEtagSentinel
}

func (etagFullRecorder) Push(string, *http.PushOptions) error {
	return errEtagSentinel
}

// etagRouter mounts h on every method behind ETag, as a chi router would.
func etagRouter(h http.HandlerFunc) http.Handler {
	r := chi.NewRouter()
	r.Use(ETag)
	r.Handle("/", h)
	return r
}

// etagServe sends one request through etagRouter and returns the recorded response.
func etagServe(method string, h http.HandlerFunc, ifNoneMatch ...string) *httptest.ResponseRecorder {
	req := httptest.NewRequest(method, "/", nil)
	for _, v := range ifNoneMatch {
		req.Header.Add("If-None-Match", v)
	}
	rec := httptest.NewRecorder()
	etagRouter(h).ServeHTTP(rec, req)
	return rec
}

func writeBody(body string) http.HandlerFunc {
	return func(w http.ResponseWriter, r *http.Request) {
		w.Write([]byte(body))
	}
}

func setETagBody(etag, body string) http.HandlerFunc {
	return func(w http.ResponseWriter, r *http.Request) {
		w.Header().Set("ETag", etag)
		w.Write([]byte(body))
	}
}

func TestETagGeneratesStrongETag(t *testing.T) {
	rec := etagServe(http.MethodGet, writeBody("hello"))
	if rec.Code != http.StatusOK {
		t.Fatalf("status = %d, want 200", rec.Code)
	}
	etag := rec.Header().Get("ETag")
	if len(etag) != 66 || etag[0] != '"' || etag[65] != '"' || strings.HasPrefix(etag, "W/") {
		t.Fatalf("ETag = %q, want a strong quoted SHA-256 tag", etag)
	}
	if rec.Body.String() != "hello" {
		t.Fatalf("body = %q, want %q", rec.Body.String(), "hello")
	}
	if got := etagServe(http.MethodGet, writeBody("hello")).Header().Get("ETag"); got != etag {
		t.Fatalf("same body gave ETag %q, want %q", got, etag)
	}
	if got := etagServe(http.MethodGet, writeBody("hellp")).Header().Get("ETag"); got == etag {
		t.Fatalf("different body gave the same ETag %q", got)
	}
}

func TestETagCoversAllWrites(t *testing.T) {
	chunked := etagServe(http.MethodGet, func(w http.ResponseWriter, r *http.Request) {
		for i := 0; i < 1000; i++ {
			w.Write([]byte("abc"))
		}
	})
	whole := etagServe(http.MethodGet, writeBody(strings.Repeat("abc", 1000)))
	if whole.Header().Get("ETag") == "" {
		t.Fatal("single write has no ETag")
	}
	if chunked.Header().Get("ETag") != whole.Header().Get("ETag") {
		t.Fatalf("chunked ETag %q, single write ETag %q", chunked.Header().Get("ETag"), whole.Header().Get("ETag"))
	}
	if chunked.Body.String() != whole.Body.String() {
		t.Fatal("chunked body differs from the handler's bytes")
	}
}

func TestETagEmptyBodyGET(t *testing.T) {
	rec := etagServe(http.MethodGet, func(w http.ResponseWriter, r *http.Request) {})
	if rec.Code != http.StatusOK {
		t.Fatalf("status = %d, want 200", rec.Code)
	}
	if etag := rec.Header().Get("ETag"); len(etag) != 66 {
		t.Fatalf("ETag = %q, want a strong tag for the empty body", etag)
	}
	if got := rec.Header().Get("Content-Length"); got != "0" {
		t.Fatalf("Content-Length = %q, want 0", got)
	}
	if rec.Body.Len() != 0 {
		t.Fatalf("body = %q, want empty", rec.Body.String())
	}
}

func TestETagKeepsHandlerETag(t *testing.T) {
	rec := etagServe(http.MethodGet, setETagBody(`W/"x"`, "body"))
	if got := rec.Header().Get("ETag"); got != `W/"x"` {
		t.Fatalf("ETag = %q, want the handler's %q", got, `W/"x"`)
	}
	rec = etagServe(http.MethodGet, setETagBody(`W/"x"`, "body"), `"x"`)
	if rec.Code != http.StatusNotModified {
		t.Fatalf("status = %d, want 304 for weak handler ETag and strong If-None-Match", rec.Code)
	}
}

func TestETagHEAD(t *testing.T) {
	noBody := etagServe(http.MethodHead, func(w http.ResponseWriter, r *http.Request) {})
	if noBody.Code != http.StatusOK {
		t.Fatalf("status = %d, want 200", noBody.Code)
	}
	if got, ok := noBody.Header()["Etag"]; ok {
		t.Fatalf("HEAD without body generated ETag %q", got)
	}

	handlerETag := etagServe(http.MethodHead, func(w http.ResponseWriter, r *http.Request) {
		w.Header().Set("ETag", `"x"`)
	}, `"x"`)
	if handlerETag.Code != http.StatusNotModified {
		t.Fatalf("status = %d, want 304 for handler ETag", handlerETag.Code)
	}

	get := etagServe(http.MethodGet, writeBody("body"))
	head := etagServe(http.MethodHead, writeBody("body"))
	if head.Header().Get("ETag") == "" || head.Header().Get("ETag") != get.Header().Get("ETag") {
		t.Fatalf("HEAD ETag %q, GET ETag %q", head.Header().Get("ETag"), get.Header().Get("ETag"))
	}
}

func TestETagContentLength(t *testing.T) {
	get := etagServe(http.MethodGet, writeBody("hello"))
	if got := get.Header().Get("Content-Length"); got != "5" {
		t.Fatalf("GET Content-Length = %q, want 5", got)
	}
	head := etagServe(http.MethodHead, writeBody("hello"))
	if got, ok := head.Header()["Content-Length"]; ok {
		t.Fatalf("HEAD set Content-Length %q", got)
	}
}

func TestETagNotModifiedKeepsNonContentHeaders(t *testing.T) {
	rec := etagServe(http.MethodGet, func(w http.ResponseWriter, r *http.Request) {
		h := w.Header()
		h.Set("ETag", `"v1"`)
		h.Set("Cache-Control", "max-age=60")
		h.Set("Content-Location", "/other")
		h.Set("Expires", "Wed, 21 Oct 2037 07:28:00 GMT")
		h.Set("Vary", "Accept-Encoding")
		h.Set("Content-Type", "text/plain")
		h.Set("Content-Length", "4")
		h.Set("Content-Encoding", "gzip")
		w.Write([]byte("body"))
	}, `"v1"`)
	if rec.Code != http.StatusNotModified {
		t.Fatalf("status = %d, want 304", rec.Code)
	}
	if rec.Body.Len() != 0 {
		t.Fatalf("304 body = %q, want empty", rec.Body.String())
	}
	for _, k := range []string{"Content-Type", "Content-Length", "Content-Encoding"} {
		if got, ok := rec.Header()[k]; ok {
			t.Fatalf("304 kept %s = %q", k, got)
		}
	}
	kept := []string{"Cache-Control", "Content-Location", "Expires", "Etag", "Vary"}
	if len(rec.Header()) != len(kept) {
		t.Fatalf("304 has %d headers %v, want exactly %v", len(rec.Header()), rec.Header(), kept)
	}
	for _, k := range kept {
		if rec.Header().Get(k) == "" {
			t.Fatalf("304 lost header %s", k)
		}
	}
}

func TestETagIfNoneMatch(t *testing.T) {
	cases := []struct {
		name string
		etag string
		inm  []string
		want int
	}{
		{"list member", `"b"`, []string{`"a", "b"`}, http.StatusNotModified},
		{"OWS around members", `"b"`, []string{" \"a\" ,\t\"b\" "}, http.StatusNotModified},
		{"weak member matches strong", `"b"`, []string{`W/"b"`}, http.StatusNotModified},
		{"weak handler tag matches strong member", `W/"b"`, []string{`"b"`}, http.StatusNotModified},
		{"multiple header lines", `"b"`, []string{`"a"`, `"b"`}, http.StatusNotModified},
		{"star matches 200", `"b"`, []string{"*"}, http.StatusNotModified},
		{"comma inside quotes is one tag", `"a,b"`, []string{`"a,b"`}, http.StatusNotModified},
		{"comma inside quotes is not split", `"a,b"`, []string{`"a"`}, http.StatusOK},
		{"no member matches", `"b"`, []string{`"a", "c"`}, http.StatusOK},
		{"unquoted", `"abc"`, []string{"abc"}, http.StatusOK},
		{"unterminated", `"abc"`, []string{`"abc`}, http.StatusOK},
		{"weak without quotes", `"abc"`, []string{"W/abc"}, http.StatusOK},
		{"empty header", `"abc"`, []string{""}, http.StatusOK},
		{"only commas", `"abc"`, []string{",,"}, http.StatusOK},
		{"quoted space", `"abc"`, []string{`" "`}, http.StatusOK},
		{"lowercase weak prefix", `"abc"`, []string{`w/"abc"`}, http.StatusOK},
		{"case mismatch", `"abc"`, []string{`"ABC"`}, http.StatusOK},
		{"junk after closing quote", `"abc"`, []string{`"abc"x`}, http.StatusOK},
		{"two members without comma", `"abc"`, []string{`"x" "abc"`}, http.StatusOK},
		{"malformed member after match candidate", `"abc"`, []string{`"x", *`}, http.StatusOK},
		{"star with trailing text", `"abc"`, []string{"*x"}, http.StatusOK},
	}
	for _, tc := range cases {
		t.Run(tc.name, func(t *testing.T) {
			rec := etagServe(http.MethodGet, setETagBody(tc.etag, "body"), tc.inm...)
			if rec.Code != tc.want {
				t.Fatalf("status = %d, want %d", rec.Code, tc.want)
			}
		})
	}
}

func TestETagStarOnNotFoundPassesThrough(t *testing.T) {
	rec := etagServe(http.MethodGet, func(w http.ResponseWriter, r *http.Request) {
		w.WriteHeader(http.StatusNotFound)
		w.Write([]byte("missing"))
	}, "*")
	if rec.Code != http.StatusNotFound {
		t.Fatalf("status = %d, want 404", rec.Code)
	}
	if got := rec.Header().Get("ETag"); got != "" {
		t.Fatalf("404 got ETag %q", got)
	}
}

func TestETagPartialContentPassesThrough(t *testing.T) {
	rec := etagServe(http.MethodGet, func(w http.ResponseWriter, r *http.Request) {
		w.Header().Set("ETag", `"x"`)
		w.WriteHeader(http.StatusPartialContent)
		w.Write([]byte("part"))
	}, `"x"`)
	if rec.Code != http.StatusPartialContent {
		t.Fatalf("status = %d, want 206", rec.Code)
	}
	if rec.Body.String() != "part" {
		t.Fatalf("body = %q, want %q", rec.Body.String(), "part")
	}
}

func TestETagNonGetHeadIsNotWrapped(t *testing.T) {
	for _, method := range []string{http.MethodPost, http.MethodPut, http.MethodDelete, http.MethodPatch, http.MethodOptions} {
		t.Run(method, func(t *testing.T) {
			rec := etagServe(method, writeBody("body"), "*", `"x"`)
			if rec.Code != http.StatusOK {
				t.Fatalf("status = %d, want 200", rec.Code)
			}
			if got := rec.Header().Get("ETag"); got != "" {
				t.Fatalf("ETag %q added to %s", got, method)
			}
			if rec.Body.String() != "body" {
				t.Fatalf("body = %q, want %q", rec.Body.String(), "body")
			}
		})
	}
}

func TestETagNonGetHeadFlushesDirectly(t *testing.T) {
	rec := etagServe(http.MethodPost, func(w http.ResponseWriter, r *http.Request) {
		w.Write([]byte("a"))
		w.(http.Flusher).Flush()
	})
	if !rec.Flushed {
		t.Fatal("POST response was not flushed")
	}
}

func TestETagNonOKStatusStreamsDirectly(t *testing.T) {
	for _, code := range []int{http.StatusCreated, http.StatusNoContent, http.StatusMovedPermanently, http.StatusNotFound, http.StatusInternalServerError} {
		rec := httptest.NewRecorder()
		h := http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
			w.WriteHeader(code)
			if rec.Code != code {
				t.Errorf("status %d not written through when WriteHeader was called", code)
			}
			w.Write([]byte("x"))
		})
		req := httptest.NewRequest(http.MethodGet, "/", nil)
		req.Header.Set("If-None-Match", "*")
		ETag(h).ServeHTTP(rec, req)
		if rec.Code != code {
			t.Fatalf("status = %d, want %d", rec.Code, code)
		}
		if got := rec.Header().Get("ETag"); got != "" {
			t.Fatalf("status %d got ETag %q", code, got)
		}
	}
}

func TestETagFirstWriteHeaderWins(t *testing.T) {
	rec := etagServe(http.MethodGet, func(w http.ResponseWriter, r *http.Request) {
		w.WriteHeader(http.StatusCreated)
		w.WriteHeader(http.StatusInternalServerError)
		w.Write([]byte("made"))
	})
	if rec.Code != http.StatusCreated {
		t.Fatalf("status = %d, want 201", rec.Code)
	}

	rec = etagServe(http.MethodGet, func(w http.ResponseWriter, r *http.Request) {
		w.WriteHeader(http.StatusOK)
		w.WriteHeader(http.StatusNotFound)
		w.Write([]byte("body"))
	})
	if rec.Code != http.StatusOK || rec.Header().Get("ETag") == "" {
		t.Fatalf("status = %d ETag %q, want 200 with a generated ETag", rec.Code, rec.Header().Get("ETag"))
	}
}

func TestETagFlushCommitsAndStreams(t *testing.T) {
	rec := etagServe(http.MethodGet, func(w http.ResponseWriter, r *http.Request) {
		w.Write([]byte("a"))
		w.(http.Flusher).Flush()
		w.Write([]byte("b"))
	})
	if !rec.Flushed {
		t.Fatal("underlying writer was not flushed")
	}
	if rec.Body.String() != "ab" {
		t.Fatalf("body = %q, want %q", rec.Body.String(), "ab")
	}
	if got := rec.Header().Get("ETag"); got != "" {
		t.Fatalf("streamed response got ETag %q", got)
	}
}

func TestETagWriteAfterNotModifiedDoesNotPanic(t *testing.T) {
	var saved http.ResponseWriter
	req := httptest.NewRequest(http.MethodGet, "/", nil)
	req.Header.Set("If-None-Match", `"x"`)
	rec := httptest.NewRecorder()
	ETag(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		saved = w
		w.Header().Set("ETag", `"x"`)
		w.Write([]byte("body"))
	})).ServeHTTP(rec, req)
	if rec.Code != http.StatusNotModified {
		t.Fatalf("status = %d, want 304", rec.Code)
	}
	saved.Write([]byte("late"))
	if rec.Code != http.StatusNotModified {
		t.Fatalf("status changed to %d after a late write", rec.Code)
	}
}

func TestETagWriterCapabilities(t *testing.T) {
	req := httptest.NewRequest(http.MethodGet, "/", nil)

	var hijackErr, pushErr error
	ETag(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		_, _, hijackErr = w.(http.Hijacker).Hijack()
		pushErr = w.(http.Pusher).Push("/x", nil)
	})).ServeHTTP(httptest.NewRecorder(), req)
	if hijackErr == nil || hijackErr.Error() != "chi/middleware: http.Hijacker is unavailable on the writer" {
		t.Fatalf("Hijack error = %v, want the unavailable error", hijackErr)
	}
	if pushErr == nil || pushErr.Error() != "chi/middleware: http.Pusher is unavailable on the writer" {
		t.Fatalf("Push error = %v, want the unavailable error", pushErr)
	}

	hijackErr, pushErr = nil, nil
	ETag(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		_, _, hijackErr = w.(http.Hijacker).Hijack()
		pushErr = w.(http.Pusher).Push("/x", nil)
	})).ServeHTTP(etagFullRecorder{httptest.NewRecorder()}, req)
	if !errors.Is(hijackErr, errEtagSentinel) || !errors.Is(pushErr, errEtagSentinel) {
		t.Fatalf("Hijack error %v, Push error %v, want the underlying writer's errors", hijackErr, pushErr)
	}

	rec := httptest.NewRecorder()
	var unwrapped http.ResponseWriter
	ETag(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		unwrapped = w.(interface{ Unwrap() http.ResponseWriter }).Unwrap()
	})).ServeHTTP(rec, req)
	if unwrapped != rec {
		t.Fatalf("Unwrap returned %v, want the underlying writer", unwrapped)
	}
}

func TestETagRoundTrip(t *testing.T) {
	srv := httptest.NewServer(etagRouter(writeBody("hello")))
	defer srv.Close()

	do := func(method, inm string) (*http.Response, string) {
		req, err := http.NewRequest(method, srv.URL+"/", nil)
		if err != nil {
			t.Fatalf("NewRequest: %v", err)
		}
		if inm != "" {
			req.Header.Set("If-None-Match", inm)
		}
		resp, err := srv.Client().Do(req)
		if err != nil {
			t.Fatalf("%s: %v", method, err)
		}
		defer resp.Body.Close()
		body, err := io.ReadAll(resp.Body)
		if err != nil {
			t.Fatalf("reading body: %v", err)
		}
		return resp, string(body)
	}

	resp, body := do(http.MethodGet, "")
	etag := resp.Header.Get("ETag")
	if resp.StatusCode != http.StatusOK || body != "hello" || len(etag) != 66 {
		t.Fatalf("GET = %d %q ETag %q, want 200 hello with a strong ETag", resp.StatusCode, body, etag)
	}

	resp, body = do(http.MethodGet, etag)
	if resp.StatusCode != http.StatusNotModified || body != "" {
		t.Fatalf("conditional GET = %d %q, want 304 with no body", resp.StatusCode, body)
	}

	resp, body = do(http.MethodHead, "")
	if resp.StatusCode != http.StatusOK || body != "" || resp.Header.Get("ETag") != etag {
		t.Fatalf("HEAD = %d ETag %q, want 200 with the GET ETag %q", resp.StatusCode, resp.Header.Get("ETag"), etag)
	}

	resp, _ = do(http.MethodHead, etag)
	if resp.StatusCode != http.StatusNotModified {
		t.Fatalf("conditional HEAD = %d, want 304", resp.StatusCode)
	}
}

func TestETagRoundTripInformational(t *testing.T) {
	srv := httptest.NewServer(etagRouter(func(w http.ResponseWriter, r *http.Request) {
		w.WriteHeader(http.StatusEarlyHints)
		w.WriteHeader(http.StatusOK)
		w.Write([]byte("hi"))
	}))
	defer srv.Close()

	var informational []int
	trace := &httptrace.ClientTrace{
		Got1xxResponse: func(code int, _ textproto.MIMEHeader) error {
			informational = append(informational, code)
			return nil
		},
	}
	ctx := httptrace.WithClientTrace(context.Background(), trace)
	req, err := http.NewRequestWithContext(ctx, http.MethodGet, srv.URL+"/", nil)
	if err != nil {
		t.Fatalf("NewRequest: %v", err)
	}
	resp, err := srv.Client().Do(req)
	if err != nil {
		t.Fatalf("GET: %v", err)
	}
	defer resp.Body.Close()
	body, _ := io.ReadAll(resp.Body)

	if len(informational) != 1 || informational[0] != http.StatusEarlyHints {
		t.Fatalf("informational responses = %v, want [103]", informational)
	}
	if resp.StatusCode != http.StatusOK || string(body) != "hi" || resp.Header.Get("ETag") == "" {
		t.Fatalf("final response = %d %q ETag %q, want 200 hi with an ETag", resp.StatusCode, body, resp.Header.Get("ETag"))
	}
}

// etagHijackWire serves h over a real server and returns the raw bytes the client
// reads after the handler hijacks the connection, plus the server's error log.
// h must return normally so that the log is complete when it is read.
func etagHijackWire(t *testing.T, h http.Handler) (string, string) {
	t.Helper()
	var logs bytes.Buffer
	done := make(chan struct{})
	srv := httptest.NewUnstartedServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		defer close(done)
		h.ServeHTTP(w, r)
	}))
	srv.Config.ErrorLog = log.New(&logs, "", 0)
	srv.Start()
	defer srv.Close()

	conn, err := net.Dial("tcp", srv.Listener.Addr().String())
	if err != nil {
		t.Fatalf("Dial: %v", err)
	}
	defer conn.Close()
	conn.SetDeadline(time.Now().Add(5 * time.Second))
	if _, err := io.WriteString(conn, "GET / HTTP/1.1\r\nHost: example.com\r\n\r\n"); err != nil {
		t.Fatalf("writing request: %v", err)
	}
	wire, err := io.ReadAll(conn)
	if err != nil {
		t.Fatalf("reading response: %v", err)
	}
	<-done
	return string(wire), logs.String()
}

// etagSendRaw hijacks the connection, writes raw to it and closes it.
func etagSendRaw(t *testing.T, w http.ResponseWriter, raw string) {
	t.Helper()
	conn, _, err := w.(http.Hijacker).Hijack()
	if err != nil {
		t.Errorf("Hijack: %v", err)
		return
	}
	defer conn.Close()
	io.WriteString(conn, raw)
}

func TestETagHijackAfterWriteMatchesNetHTTP(t *testing.T) {
	handler := func(w http.ResponseWriter, r *http.Request) {
		w.Header().Set("X-A", "1")
		w.Write([]byte("hello"))
		etagSendRaw(t, w, "RAW")
	}
	plain, _ := etagHijackWire(t, http.HandlerFunc(handler))
	wrapped, logs := etagHijackWire(t, ETag(http.HandlerFunc(handler)))
	if logs != "" {
		t.Fatalf("server logged %q, want nothing", logs)
	}
	if !strings.HasPrefix(wrapped, "HTTP/1.1 200 OK\r\nX-A: 1\r\n") || !strings.HasSuffix(wrapped, "RAW") {
		t.Fatalf("wire = %q, want the status line, X-A, the body and then the raw bytes", wrapped)
	}
	date := regexp.MustCompile(`Date: [^\r]*\r\n`)
	if date.ReplaceAllString(wrapped, "") != date.ReplaceAllString(plain, "") {
		t.Fatalf("wire = %q, plain net/http sent %q", wrapped, plain)
	}
}

func TestETagHijackWithoutWriteSendsNothingExtra(t *testing.T) {
	wire, logs := etagHijackWire(t, ETag(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		etagSendRaw(t, w, "RAW")
	})))
	if wire != "RAW" {
		t.Fatalf("wire = %q, want only the raw bytes", wire)
	}
	if logs != "" {
		t.Fatalf("server logged %q, want nothing", logs)
	}
}

func TestETagLateHeaderChangeIgnoredAfter200(t *testing.T) {
	cases := []struct {
		name    string
		handler http.HandlerFunc
	}{
		{"explicit WriteHeader", func(w http.ResponseWriter, r *http.Request) {
			w.WriteHeader(http.StatusOK)
			w.Header().Set("Content-Type", "text/csv")
			w.Header().Set("X-Late", "1")
			w.Write([]byte("hi"))
		}},
		{"implicit WriteHeader", func(w http.ResponseWriter, r *http.Request) {
			w.Write([]byte("hi"))
			w.Header().Set("Content-Type", "text/csv")
			w.Header().Set("X-Late", "1")
			w.Write([]byte("!"))
		}},
	}
	for _, tc := range cases {
		t.Run(tc.name, func(t *testing.T) {
			plain := etagGetHeader(t, tc.handler)
			wrapped := etagGetHeader(t, etagRouter(tc.handler))
			if plain.Get("X-Late") != "" {
				t.Fatalf("plain net/http sent X-Late %q", plain.Get("X-Late"))
			}
			for _, k := range []string{"Content-Type", "X-Late"} {
				if got, want := wrapped.Get(k), plain.Get(k); got != want {
					t.Fatalf("%s = %q, plain net/http sent %q", k, got, want)
				}
			}
		})
	}
}

// etagGetHeader serves h over httptest.NewServer, sends one GET and returns the response headers.
func etagGetHeader(t *testing.T, h http.Handler) http.Header {
	t.Helper()
	srv := httptest.NewServer(h)
	defer srv.Close()
	resp, err := srv.Client().Get(srv.URL + "/")
	if err != nil {
		t.Fatalf("GET: %v", err)
	}
	defer resp.Body.Close()
	io.Copy(io.Discard, resp.Body)
	return resp.Header
}

func TestETagKeepsTrailers(t *testing.T) {
	r := chi.NewRouter()
	r.Use(ETag)
	r.Get("/declared", func(w http.ResponseWriter, r *http.Request) {
		w.Header().Set("Trailer", "X-Sum")
		w.Write([]byte("body"))
		w.Header().Set("X-Sum", "abc")
	})
	r.Get("/prefix", func(w http.ResponseWriter, r *http.Request) {
		w.Write([]byte("body"))
		w.Header().Set(http.TrailerPrefix+"X-Sum", "abc")
	})
	ts := httptest.NewServer(r)
	defer ts.Close()

	for _, path := range []string{"/declared", "/prefix"} {
		res, err := http.Get(ts.URL + path)
		if err != nil {
			t.Fatal(err)
		}
		body, _ := io.ReadAll(res.Body)
		res.Body.Close()
		if string(body) != "body" {
			t.Fatalf("%s: body = %q", path, body)
		}
		if res.Header.Get("ETag") == "" {
			t.Fatalf("%s: missing ETag", path)
		}
		if got := res.Trailer.Get("X-Sum"); got != "abc" {
			t.Fatalf("%s: trailer X-Sum = %q, want %q", path, got, "abc")
		}
	}
}

type failingHijackRecorder struct {
	*httptest.ResponseRecorder
}

func (failingHijackRecorder) Hijack() (net.Conn, *bufio.ReadWriter, error) {
	return nil, nil, errors.New("no hijack")
}

func TestETagFailedHijackStillSetsETag(t *testing.T) {
	h := ETag(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		if _, _, err := w.(http.Hijacker).Hijack(); err == nil {
			t.Fatal("expected hijack error")
		}
		w.Write([]byte("body"))
	}))
	rec := failingHijackRecorder{httptest.NewRecorder()}
	h.ServeHTTP(rec, httptest.NewRequest("GET", "/", nil))
	if rec.Code != 200 || rec.Body.String() != "body" {
		t.Fatalf("got %d %q", rec.Code, rec.Body.String())
	}
	if rec.Header().Get("ETag") != strongETag([]byte("body")) {
		t.Fatalf("ETag = %q", rec.Header().Get("ETag"))
	}
}

import random
import threading
import time
import unittest
from unittest import mock

from shop.auth import (
    InvalidToken,
    TokenExpired,
    TokenUsed,
    issue_reset_token,
    redeem_reset_token,
)


class _SlowSet(set):
    """Used-token set that pauses inside the membership check, widening the race window."""

    def __contains__(self, item):
        found = set.__contains__(self, item)
        time.sleep(0.001)
        return found


def _redeem_outcome(token, now):
    try:
        return redeem_reset_token(token, now=now)
    except TokenExpired:
        return "expired"
    except TokenUsed:
        return "used"


class ResetTokenTest(unittest.TestCase):
    def test_round_trip(self):
        token = issue_reset_token("ada")
        self.assertEqual(redeem_reset_token(token), "ada")

    def test_unknown_token(self):
        for bad in ["not-a-token", "", None]:
            with self.subTest(token=bad):
                with self.assertRaises(InvalidToken) as cm:
                    redeem_reset_token(bad)
                self.assertIs(type(cm.exception), InvalidToken)

    def test_redeem_after_ttl_raises_expired(self):
        token = issue_reset_token("ada", now=1000)
        with self.assertRaises(TokenExpired):
            redeem_reset_token(token, now=1000 + 1800.000001)

    def test_exactly_ttl_still_succeeds(self):
        token = issue_reset_token("ada", now=1000)
        self.assertEqual(redeem_reset_token(token, now=2800), "ada")

    def test_second_redeem_raises_used(self):
        for later in [1002, 5000]:  # within the TTL and after it
            with self.subTest(later=later):
                token = issue_reset_token("ada", now=1000)
                self.assertEqual(redeem_reset_token(token, now=1001), "ada")
                with self.assertRaises(TokenUsed):
                    redeem_reset_token(token, now=later)

    def test_expired_attempt_does_not_mark_used(self):
        token = issue_reset_token("ada", now=1000)
        with self.assertRaises(TokenExpired):
            redeem_reset_token(token, now=3000)
        with self.assertRaises(TokenExpired):
            redeem_reset_token(token, now=3001)

    def test_expired_and_used_are_invalid_token(self):
        self.assertTrue(issubclass(TokenExpired, InvalidToken))
        self.assertTrue(issubclass(TokenUsed, InvalidToken))

    def test_now_zero_is_a_real_timestamp(self):
        token = issue_reset_token("ada", now=0)
        self.assertEqual(redeem_reset_token(token, now=1800), "ada")
        token = issue_reset_token("ada", now=0)
        with self.assertRaises(TokenExpired):
            redeem_reset_token(token, now=1801)
        token = issue_reset_token("ada", now=-1800)
        self.assertEqual(redeem_reset_token(token, now=0), "ada")
        token = issue_reset_token("ada", now=-1801)
        with self.assertRaises(TokenExpired):
            redeem_reset_token(token, now=0)
        token = issue_reset_token("ada", now=0)
        self.assertEqual(redeem_reset_token(token, now=0), "ada")

    def test_redeem_before_issue_time_does_not_expire(self):
        token = issue_reset_token("ada", now=1000)
        self.assertEqual(redeem_reset_token(token, now=500), "ada")

    def test_float_timestamps(self):
        token = issue_reset_token("ada", now=1000.5)
        self.assertEqual(redeem_reset_token(token, now=2800.5), "ada")
        token = issue_reset_token("ada", now=1000.5)
        with self.assertRaises(TokenExpired):
            redeem_reset_token(token, now=2800.6)

    def test_default_now_is_evaluated_at_call_time(self):
        token = issue_reset_token("ada", now=time.time() - 1801)
        with self.assertRaises(TokenExpired):
            redeem_reset_token(token)

    def test_issue_without_now_records_call_time(self):
        with mock.patch("shop.auth.time.time", return_value=1000.0):
            token = issue_reset_token("ada")
        with self.assertRaises(TokenExpired):
            redeem_reset_token(token, now=1000 + 1800.000001)
        with mock.patch("shop.auth.time.time", return_value=1000.0):
            token = issue_reset_token("ada")
        self.assertEqual(redeem_reset_token(token, now=1000 + 1800), "ada")

    def test_redeem_without_now_uses_call_time(self):
        token = issue_reset_token("ada", now=1000)
        with mock.patch("shop.auth.time.time", return_value=1000 + 1800.000001):
            with self.assertRaises(TokenExpired):
                redeem_reset_token(token)
        token = issue_reset_token("ada", now=1000)
        with mock.patch("shop.auth.time.time", return_value=1000 + 1800):
            self.assertEqual(redeem_reset_token(token), "ada")

    def test_property_ttl_and_single_use(self):
        rng = random.Random(7)
        for _ in range(1000):
            issued = rng.choice([0, -1, 1000.5, rng.uniform(-1e9, 1e9)])
            redeem_at = issued + rng.choice([0, 1800, 1800.000001, rng.uniform(-3600, 7200)])
            expected = "expired" if redeem_at - issued > 1800 else "ada"
            want_second = "used" if expected == "ada" else "expired"
            token = issue_reset_token("ada", now=issued)
            first = _redeem_outcome(token, redeem_at)
            second = _redeem_outcome(token, redeem_at)
            if (first, second) != (expected, want_second):
                self.fail(f"first failing input: issued={issued!r} redeem_at={redeem_at!r} "
                          f"got {(first, second)!r}, want {(expected, want_second)!r}")

    def test_two_tokens_for_same_user_are_independent(self):
        first = issue_reset_token("ada")
        second = issue_reset_token("ada")
        self.assertEqual(redeem_reset_token(first), "ada")
        self.assertEqual(redeem_reset_token(second), "ada")
        with self.assertRaises(TokenUsed):
            redeem_reset_token(first)

    def test_concurrent_redeem_has_one_winner(self):
        threads_per_round = 8
        with mock.patch("shop.auth._USED", _SlowSet()):
            for _ in range(50):
                token = issue_reset_token("ada")
                barrier = threading.Barrier(threads_per_round)
                results = []

                def worker():
                    barrier.wait()
                    try:
                        results.append(redeem_reset_token(token))
                    except TokenUsed:
                        results.append("used")

                threads = [threading.Thread(target=worker) for _ in range(threads_per_round)]
                for t in threads:
                    t.start()
                for t in threads:
                    t.join()
                self.assertEqual(len(results), threads_per_round)
                self.assertEqual(results.count("ada"), 1)
                self.assertEqual(results.count("used"), threads_per_round - 1)

import collections
import threading
import unittest
from unittest import mock

from shop.auth import (
    InvalidToken,
    TokenExpired,
    TokenUsed,
    issue_reset_token,
    redeem_reset_token,
)

ISSUED = 1_000_000.0


class ResetTokenTest(unittest.TestCase):
    def test_round_trip(self):
        token = issue_reset_token("ada")
        self.assertEqual(redeem_reset_token(token), "ada")

    def test_unknown_token(self):
        with self.assertRaises(InvalidToken):
            redeem_reset_token("not-a-token")

    def test_unknown_token_is_plain_invalid_token(self):
        for token in ("not-a-token", "", None):
            with self.assertRaises(InvalidToken) as cm:
                redeem_reset_token(token)
            self.assertIs(type(cm.exception), InvalidToken)

    def test_expiry_subclasses_invalid_token(self):
        self.assertTrue(issubclass(TokenExpired, InvalidToken))
        self.assertTrue(issubclass(TokenUsed, InvalidToken))

    def test_redeem_at_exact_window_end_succeeds(self):
        token = issue_reset_token("ada", now=ISSUED)
        self.assertEqual(redeem_reset_token(token, now=ISSUED + 1800), "ada")

    def test_redeem_just_past_window_raises_expired(self):
        token = issue_reset_token("ada", now=ISSUED)
        with self.assertRaises(TokenExpired):
            redeem_reset_token(token, now=ISSUED + 1800.001)

    def test_second_redeem_raises_used(self):
        token = issue_reset_token("ada", now=ISSUED)
        redeem_reset_token(token, now=ISSUED)
        with self.assertRaises(TokenUsed):
            redeem_reset_token(token, now=ISSUED)

    def test_second_redeem_after_window_raises_used(self):
        token = issue_reset_token("ada", now=0)
        self.assertEqual(redeem_reset_token(token, now=100), "ada")
        with self.assertRaises(TokenUsed) as cm:
            redeem_reset_token(token, now=5000)
        self.assertIs(type(cm.exception), TokenUsed)

    def test_expired_attempt_does_not_consume_token(self):
        token = issue_reset_token("ada", now=ISSUED)
        for _ in range(2):
            with self.assertRaises(TokenExpired) as cm:
                redeem_reset_token(token, now=ISSUED + 1801)
            self.assertIs(type(cm.exception), TokenExpired)

    def test_clock_skew_before_issue_succeeds(self):
        token = issue_reset_token("ada", now=ISSUED)
        self.assertEqual(redeem_reset_token(token, now=ISSUED - 500), "ada")

    def test_tokens_are_independent(self):
        first = issue_reset_token("ada", now=ISSUED)
        second = issue_reset_token("ada", now=ISSUED)
        self.assertEqual(redeem_reset_token(first, now=ISSUED), "ada")
        self.assertEqual(redeem_reset_token(second, now=ISSUED), "ada")
        with self.assertRaises(TokenUsed):
            redeem_reset_token(first, now=ISSUED)
        with self.assertRaises(TokenUsed):
            redeem_reset_token(second, now=ISSUED)

    def test_zero_now_is_used_as_given(self):
        token = issue_reset_token("ada", now=0)
        self.assertEqual(redeem_reset_token(token, now=1800), "ada")
        token = issue_reset_token("ada", now=0)
        with self.assertRaises(TokenExpired):
            redeem_reset_token(token, now=1801)

    def test_float_boundary(self):
        token = issue_reset_token("ada", now=0)
        self.assertEqual(redeem_reset_token(token, now=1800.0), "ada")
        token = issue_reset_token("ada", now=0)
        with self.assertRaises(TokenExpired):
            redeem_reset_token(token, now=1800.0001)

    def test_default_now_is_read_per_call(self):
        with mock.patch("shop.auth.time.time", return_value=ISSUED):
            token = issue_reset_token("ada")
        with mock.patch("shop.auth.time.time", return_value=ISSUED + 1800):
            self.assertEqual(redeem_reset_token(token), "ada")
        with mock.patch("shop.auth.time.time", return_value=ISSUED):
            token = issue_reset_token("ada")
        with mock.patch("shop.auth.time.time", return_value=ISSUED + 1801):
            with self.assertRaises(TokenExpired):
                redeem_reset_token(token)

    def test_default_now_round_trip(self):
        token = issue_reset_token("ada")
        self.assertEqual(redeem_reset_token(token), "ada")

    def test_token_issued_in_far_past_is_expired_by_default_now(self):
        token = issue_reset_token("ada", now=1000)
        with self.assertRaises(TokenExpired):
            redeem_reset_token(token)


class ResetTokenConcurrencyTest(unittest.TestCase):
    THREADS = 8
    ROUNDS = 100

    def test_concurrent_redeem_has_one_winner(self):
        for _ in range(self.ROUNDS):
            token = issue_reset_token("ada", now=ISSUED)
            barrier = threading.Barrier(self.THREADS)
            outcomes = []

            def worker():
                barrier.wait()
                try:
                    redeem_reset_token(token, now=ISSUED)
                    outcomes.append("ok")
                except Exception as exc:
                    outcomes.append(type(exc).__name__)

            threads = [threading.Thread(target=worker) for _ in range(self.THREADS)]
            for thread in threads:
                thread.start()
            for thread in threads:
                thread.join()
            self.assertEqual(
                collections.Counter(outcomes),
                {"ok": 1, "TokenUsed": self.THREADS - 1},
            )

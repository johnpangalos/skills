"""Password-reset tokens (in-memory store)."""

import secrets
import threading
import time

TOKEN_TTL_SECONDS = 1800

_TOKENS = {}  # token -> (username, issued_at)
_USED = set()
_LOCK = threading.Lock()


class InvalidToken(Exception):
    pass


class TokenExpired(InvalidToken):
    pass


class TokenUsed(InvalidToken):
    pass


def issue_reset_token(username, now=None):
    """Create a reset token for username, issued at now (default: current time)."""
    if now is None:
        now = time.time()
    token = secrets.token_urlsafe(16)
    with _LOCK:
        _TOKENS[token] = (username, now)
    return token


def redeem_reset_token(token, now=None):
    """Return the username a token was issued for, and mark the token used."""
    if now is None:
        now = time.time()
    with _LOCK:
        record = _TOKENS.get(token)
        if record is None:
            raise InvalidToken("unknown token")
        username, issued_at = record
        if token in _USED:
            raise TokenUsed("token already used")
        if now - issued_at > TOKEN_TTL_SECONDS:
            raise TokenExpired("token expired")
        _USED.add(token)
    return username

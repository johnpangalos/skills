import random
import threading
import time
import unittest
from unittest import mock

from shop import auth
from shop.auth import (
    InvalidToken,
    TokenExpired,
    TokenUsed,
    issue_reset_token,
    redeem_reset_token,
)

HOSTILE_TIMES = [0, -5, 1000.5, 1800, 1800.001, 2800.5, 2800.6]


class _SlowReadRecord(dict):
    """Token record whose 'used' read is slow, so an unlocked check-then-write overlaps."""

    def __getitem__(self, key):
        value = super().__getitem__(key)
        if key == "used":
            time.sleep(0.001)
        return value


class ResetTokenTest(unittest.TestCase):
    def test_round_trip(self):
        token = issue_reset_token("ada")
        self.assertEqual(redeem_reset_token(token), "ada")

    def test_unknown_token(self):
        with self.assertRaises(InvalidToken):
            redeem_reset_token("not-a-token")

    def test_default_now_is_evaluated_at_call_time(self):
        with mock.patch("shop.auth.time.time", return_value=0):
            token = issue_reset_token("ada")
        with mock.patch("shop.auth.time.time", return_value=1801):
            with self.assertRaises(TokenExpired):
                redeem_reset_token(token)

    def test_zero_is_a_real_timestamp(self):
        token = issue_reset_token("ada", now=0)
        with self.assertRaises(TokenExpired):
            redeem_reset_token(token, now=1801)

    def test_expires_after_1800_seconds(self):
        token = issue_reset_token("ada", now=1000)
        self.assertEqual(redeem_reset_token(token, now=2800), "ada")
        token = issue_reset_token("ada", now=1000)
        with self.assertRaises(TokenExpired):
            redeem_reset_token(token, now=2800.001)

    def test_float_timestamps_at_the_boundary(self):
        token = issue_reset_token("ada", now=1000.5)
        self.assertEqual(redeem_reset_token(token, now=2800.5), "ada")
        token = issue_reset_token("ada", now=1000.5)
        with self.assertRaises(TokenExpired):
            redeem_reset_token(token, now=2800.6)

    def test_zero_issue_time_redeems_at_1800(self):
        token = issue_reset_token("ada", now=0)
        self.assertEqual(redeem_reset_token(token, now=1800), "ada")

    def test_redeem_before_issue_is_not_expired(self):
        token = issue_reset_token("ada", now=1000)
        self.assertEqual(redeem_reset_token(token, now=500), "ada")

    def test_expired_token_stays_expired_and_unused(self):
        token = issue_reset_token("ada", now=0)
        with self.assertRaises(TokenExpired):
            redeem_reset_token(token, now=1801)
        with self.assertRaises(TokenExpired):
            redeem_reset_token(token, now=1802)
        self.assertEqual(redeem_reset_token(token, now=100), "ada")

    def test_single_use(self):
        token = issue_reset_token("ada", now=0)
        self.assertEqual(redeem_reset_token(token, now=0), "ada")
        with self.assertRaises(TokenUsed):
            redeem_reset_token(token, now=1)

    def test_used_takes_precedence_over_expired(self):
        token = issue_reset_token("ada", now=0)
        redeem_reset_token(token, now=0)
        with self.assertRaises(TokenUsed):
            redeem_reset_token(token, now=5000)

    def test_same_user_tokens_are_independent(self):
        first = issue_reset_token("ada", now=0)
        second = issue_reset_token("ada", now=0)
        self.assertEqual(redeem_reset_token(first, now=0), "ada")
        self.assertEqual(redeem_reset_token(second, now=0), "ada")

    def test_concurrent_redeem_has_one_winner(self):
        for _ in range(20):
            token = issue_reset_token("ada", now=0)
            auth._TOKENS[token] = _SlowReadRecord(auth._TOKENS[token])
            barrier = threading.Barrier(8)
            outcomes = []

            def redeem_when_ready():
                barrier.wait()
                try:
                    outcomes.append(redeem_reset_token(token, now=0))
                except TokenUsed:
                    outcomes.append("used")

            threads = [threading.Thread(target=redeem_when_ready) for _ in range(8)]
            for thread in threads:
                thread.start()
            for thread in threads:
                thread.join()
            self.assertEqual(sorted(outcomes), ["ada"] + ["used"] * 7)

    def test_token_errors_subclass_invalid_token(self):
        self.assertTrue(issubclass(TokenExpired, InvalidToken))
        self.assertTrue(issubclass(TokenUsed, InvalidToken))

    def test_unknown_tokens_raise_plain_invalid_token(self):
        for token in ["", "not-a-token", None]:
            with self.subTest(token=token):
                with self.assertRaises(InvalidToken) as caught:
                    redeem_reset_token(token, now=0)
                self.assertIs(type(caught.exception), InvalidToken)
                self.assertEqual(str(caught.exception), "unknown token")

    def test_matches_model_over_generated_inputs(self):
        rng = random.Random(1234)
        for case in range(1000):
            issued_at = rng.choice(HOSTILE_TIMES + [rng.uniform(0, 1e6)])
            token = issue_reset_token("ada", now=issued_at)
            used = False
            for step in range(3):
                now = rng.choice(HOSTILE_TIMES + [rng.uniform(0, 1e6)])
                if used:
                    expected = TokenUsed
                elif now - issued_at > 1800:
                    expected = TokenExpired
                else:
                    expected = "ada"
                try:
                    outcome = redeem_reset_token(token, now=now)
                except InvalidToken as error:
                    outcome = type(error)
                used = used or outcome == "ada"
                self.assertEqual(
                    outcome,
                    expected,
                    f"case={case} step={step} issued_at={issued_at!r} now={now!r}",
                )

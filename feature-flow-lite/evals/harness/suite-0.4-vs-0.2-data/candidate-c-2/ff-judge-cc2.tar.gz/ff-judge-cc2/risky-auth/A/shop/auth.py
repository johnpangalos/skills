"""Password-reset tokens (in-memory store)."""

import secrets
import threading
import time

RESET_TTL = 1800  # seconds

_TOKENS = {}  # token -> {"username", "issued_at", "used"}
_LOCK = threading.Lock()


class InvalidToken(Exception):
    pass


class TokenExpired(InvalidToken):
    pass


class TokenUsed(InvalidToken):
    pass


def issue_reset_token(username, now=None):
    """Create a reset token for username, issued at now (Unix seconds)."""
    if now is None:
        now = time.time()
    token = secrets.token_urlsafe(16)
    _TOKENS[token] = {"username": username, "issued_at": now, "used": False}
    return token


def redeem_reset_token(token, now=None):
    """Return the username a token was issued for; each token works once, within RESET_TTL."""
    if now is None:
        now = time.time()
    with _LOCK:
        record = _TOKENS.get(token)
        if record is None:
            raise InvalidToken("unknown token")
        if record["used"]:
            raise TokenUsed("token already used")
        if now - record["issued_at"] > RESET_TTL:
            raise TokenExpired("token expired")
        record["used"] = True
        return record["username"]

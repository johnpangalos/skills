"""Orders and partial refunds (in-memory, thread-safe)."""

import threading
import uuid
from dataclasses import dataclass
from decimal import Decimal, InvalidOperation

from shop.money import CENT

_LOCK = threading.Lock()  # guards every order's refunds


class RefundError(ValueError):
    pass


@dataclass(frozen=True)
class Refund:
    order_id: str
    amount: Decimal
    key: str


class Order:
    def __init__(self, total):
        self.id = uuid.uuid4().hex
        self.total = total
        self._refunds = {}  # idempotency key -> Refund

    def refunded(self):
        """Sum of this order's refunds, in cents."""
        with _LOCK:
            return _refunded(self)

    def refundable(self):
        return self.total - self.refunded()


def _refunded(order):
    """Sum of order's refunds. Caller holds _LOCK."""
    return sum((record.amount for record in order._refunds.values()), Decimal("0.00"))


def place_order(cart):
    """Create an Order for the cart's current total."""
    if not cart.items:
        raise ValueError("cart is empty")
    return Order(cart.total())


def _whole_cents(amount):
    """True for a finite, positive Decimal with no fractional cents."""
    if not isinstance(amount, Decimal) or not amount.is_finite() or amount <= 0:
        return False
    try:
        return amount == amount.quantize(CENT)
    except InvalidOperation:  # more digits than the decimal context allows
        return False


def refund(order, amount, key):
    """Refund amount from order. Repeating key with the same amount returns the first Refund."""
    if not _whole_cents(amount):
        raise RefundError("amount must be a positive whole-cent Decimal")
    amount = amount.quantize(CENT)
    with _LOCK:
        done = order._refunds.get(key)
        if done is not None:
            if done.amount != amount:
                raise RefundError(f"key {key!r} was already used for a different amount")
            return done
        if amount > order.total - _refunded(order):
            raise RefundError("amount exceeds refundable balance")
        record = Refund(order.id, amount, key)
        order._refunds[key] = record
        return record

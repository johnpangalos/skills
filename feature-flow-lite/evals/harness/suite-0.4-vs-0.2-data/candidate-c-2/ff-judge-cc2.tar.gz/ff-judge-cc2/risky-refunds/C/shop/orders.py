"""Orders and refunds (in-memory store)."""

import threading
import uuid
from dataclasses import dataclass
from decimal import Decimal, InvalidOperation

from shop.money import CENT


class RefundError(ValueError):
    pass


@dataclass(frozen=True)
class Refund:
    order_id: str
    amount: Decimal
    key: str


class Order:
    def __init__(self, total):
        self.id = uuid.uuid4().hex
        self.total = total
        self._lock = threading.Lock()
        self._refunds = []
        self._by_key = {}
        self._refunded = Decimal("0.00")

    @property
    def refunds(self):
        """Refunds in the order they were recorded."""
        return tuple(self._refunds)

    def refunded(self):
        return self._refunded

    def refundable(self):
        return self.total - self.refunded()

    def refund(self, amount, key):
        _check_amount(amount)
        with self._lock:
            prior = self._by_key.get(key)
            if prior is not None:
                if prior.amount != amount:
                    raise RefundError("key was already used for a different amount")
                return prior
            if amount > self.refundable():
                raise RefundError("amount is more than the refundable balance")
            record = Refund(self.id, amount, key)
            self._refunds.append(record)
            self._by_key[key] = record
            self._refunded += amount
            return record


def _check_amount(amount):
    """Raise RefundError unless amount is a finite, positive Decimal in whole cents."""
    if not isinstance(amount, Decimal) or not amount.is_finite():
        raise RefundError("amount must be a finite Decimal")
    try:
        whole_cents = amount == amount.quantize(CENT)
    except InvalidOperation:
        raise RefundError("amount is out of range") from None
    if not whole_cents:
        raise RefundError("amount must be whole cents")
    if amount <= 0:
        raise RefundError("amount must be greater than zero")


def place_order(cart):
    """Create an order for the cart's current total."""
    if not cart.items:
        raise ValueError("cannot place an order from an empty cart")
    return Order(cart.total())


def refund(order, amount, key):
    """Refund amount from order. Reusing a key returns its original refund."""
    return order.refund(amount, key)

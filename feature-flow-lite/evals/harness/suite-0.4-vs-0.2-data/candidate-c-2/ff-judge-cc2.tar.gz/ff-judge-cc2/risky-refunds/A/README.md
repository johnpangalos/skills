# shop

Checkout logic for a small online coffee shop: catalog, cart totals, receipts,
orders with partial refunds, and password-reset tokens. Standard library only.
Refunds are whole-cent amounts that can't take an order past its total, and
repeating a refund key returns the original refund (`shop/orders.py`).

    ./check.sh        # lint + unit tests (run before every commit)

Money is `Decimal` dollars, rounded to cents half-up (`shop/money.py`).
Shipping is a flat $7.95, free once the merchandise subtotal reaches $75.
Sales tax is 8.25% of merchandise only; shipping is not taxed.

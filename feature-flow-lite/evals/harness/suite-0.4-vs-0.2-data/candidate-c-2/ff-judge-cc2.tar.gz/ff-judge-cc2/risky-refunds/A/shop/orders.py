"""Orders and partial refunds (in-memory store)."""

import itertools
import threading
from decimal import Decimal, InvalidOperation

from shop.money import CENT

_LOCK = threading.RLock()  # guards order ids and every refund check-and-write
_ORDER_IDS = itertools.count(1)


class RefundError(ValueError):
    pass


class Order:
    def __init__(self, order_id, total):
        self.id = order_id
        self.total = total
        self._refunds = {}  # idempotency key -> Refund

    def refunded(self):
        """Sum of this order's refunds."""
        with _LOCK:
            return sum((r.amount for r in self._refunds.values()), Decimal("0.00"))

    def refundable(self):
        """Amount of the total not yet refunded."""
        with _LOCK:
            return self.total - self.refunded()


class Refund:
    def __init__(self, order_id, amount, key):
        self.order_id = order_id
        self.amount = amount
        self.key = key


def place_order(cart):
    """Freeze the cart's current total into a new Order."""
    if not cart.items:
        raise ValueError("cannot place an order for an empty cart")
    total = cart.total()
    with _LOCK:
        order_id = next(_ORDER_IDS)
    return Order(order_id, total)


def _check_amount(amount):
    """Raise RefundError unless amount is a positive Decimal in whole cents."""
    if not isinstance(amount, Decimal) or not amount.is_finite() or amount <= 0:
        raise RefundError(f"refund amount must be a positive finite Decimal: {amount!r}")
    try:
        whole_cents = amount == amount.quantize(CENT)
    except InvalidOperation:  # too many digits to quantize
        whole_cents = False
    if not whole_cents:
        raise RefundError(f"refund amount must be whole cents: {amount!r}")


def refund(order, amount, key):
    """Refund amount from order. Repeating a key returns its original Refund."""
    _check_amount(amount)
    with _LOCK:
        previous = order._refunds.get(key)
        if previous is not None:
            if previous.amount != amount:
                raise RefundError(f"key {key!r} was already used for {previous.amount}")
            return previous
        available = order.refundable()
        if amount > available:
            raise RefundError(f"refund {amount} exceeds refundable {available}")
        record = Refund(order.id, amount, key)
        order._refunds[key] = record
        return record

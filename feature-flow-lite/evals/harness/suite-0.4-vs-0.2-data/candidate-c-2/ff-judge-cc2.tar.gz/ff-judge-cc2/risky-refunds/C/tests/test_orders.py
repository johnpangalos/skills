import random
import threading
import unittest
from dataclasses import FrozenInstanceError
from decimal import Decimal
from unittest import mock

from shop.cart import Cart
from shop.orders import Refund, RefundError, place_order, refund

TOTAL = Decimal("54.77")  # BEAN-ETH x2 + FILTER, with shipping and tax

HOSTILE_AMOUNTS = [
    5, 5.0, "5.00", True, None,
    Decimal("0"), Decimal("-0"), Decimal("0.00"), Decimal("-1.00"),
    Decimal("0.001"), Decimal("1.005"),
    Decimal("NaN"), Decimal("sNaN"), Decimal("Infinity"), Decimal("-Infinity"),
    Decimal("1E+1000"), Decimal("1E-1000"),
]


def _cart():
    cart = Cart()
    cart.add("BEAN-ETH", 2)
    cart.add("FILTER")
    return cart


def _order():
    return place_order(_cart())


def _random_amount(rng):
    if rng.random() < 0.2:
        return rng.choice(HOSTILE_AMOUNTS)
    return Decimal(rng.randrange(-500, 6000)).scaleb(-rng.choice((0, 1, 2, 3)))


class PlaceOrderTest(unittest.TestCase):
    def test_total_is_cart_total_when_placed(self):
        self.assertEqual(place_order(_cart()).total, TOTAL)

    def test_adding_items_after_placing_does_not_change_total(self):
        cart = _cart()
        order = place_order(cart)
        cart.add("MUG", 3)
        self.assertEqual(order.total, TOTAL)

    def test_removing_all_items_after_placing_does_not_change_total(self):
        cart = _cart()
        order = place_order(cart)
        for sku in list(cart.items):
            cart.remove(sku)
        self.assertEqual(cart.items, {})
        self.assertEqual(order.total, TOTAL)

    def test_two_orders_from_same_cart_have_distinct_ids(self):
        cart = _cart()
        first = place_order(cart)
        second = place_order(cart)
        self.assertIsNot(first, second)
        self.assertNotEqual(first.id, second.id)

    def test_concurrent_placement_gives_unique_ids(self):
        cart = _cart()
        ids = []
        lock = threading.Lock()
        barrier = threading.Barrier(8)

        def place():
            barrier.wait()
            for _ in range(50):
                order = place_order(cart)
                with lock:
                    ids.append(order.id)

        threads = [threading.Thread(target=place) for _ in range(8)]
        for thread in threads:
            thread.start()
        for thread in threads:
            thread.join()
        self.assertEqual(len(ids), 400)
        self.assertEqual(len(set(ids)), 400)

    def test_empty_cart_raises_value_error(self):
        with mock.patch("shop.orders.Order") as order_cls:
            with self.assertRaises(ValueError) as ctx:
                place_order(Cart())
        self.assertIs(type(ctx.exception), ValueError)
        self.assertEqual(str(ctx.exception), "cannot place an order from an empty cart")
        order_cls.assert_not_called()

    def test_cart_with_all_items_removed_raises_value_error(self):
        cart = _cart()
        cart.remove("BEAN-ETH")
        cart.remove("FILTER")
        with mock.patch("shop.orders.Order") as order_cls:
            with self.assertRaises(ValueError) as ctx:
                place_order(cart)
        self.assertIs(type(ctx.exception), ValueError)
        self.assertEqual(str(ctx.exception), "cannot place an order from an empty cart")
        order_cls.assert_not_called()

    def test_next_order_after_failed_empty_placement_works(self):
        cart = Cart()
        with self.assertRaises(ValueError):
            place_order(cart)
        cart.add("BEAN-ETH", 2)
        cart.add("FILTER")
        self.assertEqual(place_order(cart).total, TOTAL)


class RefundAmountTest(unittest.TestCase):
    def test_error_is_value_error(self):
        self.assertTrue(issubclass(RefundError, ValueError))

    def test_whole_cent_spellings_accepted(self):
        for amount in (Decimal("5"), Decimal("5.0"), Decimal("5.00")):
            with self.subTest(amount=repr(amount)):
                self.assertEqual(refund(_order(), amount, "k").amount, amount)

    def test_hostile_amounts_raise_refund_error(self):
        for amount in HOSTILE_AMOUNTS:
            with self.subTest(amount=repr(amount)):
                order = _order()
                with self.assertRaises(RefundError):
                    refund(order, amount, "k")
                self.assertEqual(order.refunds, ())
                self.assertEqual(order.refunded(), Decimal("0.00"))


class RefundBalanceTest(unittest.TestCase):
    def test_nothing_refunded_yet(self):
        order = _order()
        self.assertEqual(order.refunded(), Decimal("0.00"))
        self.assertEqual(order.refundable(), TOTAL)

    def test_partials_accumulate(self):
        order = _order()
        refund(order, Decimal("10.00"), "a")
        refund(order, Decimal("2.50"), "b")
        self.assertEqual(order.refunded(), Decimal("12.50"))
        self.assertEqual(order.refundable(), Decimal("42.27"))
        self.assertEqual(order.refundable(), order.total - order.refunded())

    def test_total_plus_a_cent_fails_and_changes_nothing(self):
        order = _order()
        with self.assertRaises(RefundError):
            refund(order, TOTAL + Decimal("0.01"), "k")
        self.assertEqual(order.refunds, ())
        self.assertEqual(order.refunded(), Decimal("0.00"))
        self.assertEqual(order.refundable(), TOTAL)
        self.assertEqual(refund(order, TOTAL, "k").amount, TOTAL)

    def test_exact_total_succeeds_then_any_more_fails(self):
        order = _order()
        refund(order, TOTAL, "a")
        self.assertEqual(order.refundable(), Decimal("0.00"))
        with self.assertRaises(RefundError):
            refund(order, Decimal("0.01"), "b")
        self.assertEqual(order.refunded(), TOTAL)

    def test_partials_exceeding_total_fail_and_change_nothing(self):
        order = _order()
        first = refund(order, Decimal("30.00"), "a")
        with self.assertRaises(RefundError):
            refund(order, Decimal("24.78"), "b")
        self.assertEqual(order.refunds, (first,))
        self.assertEqual(order.refunded(), Decimal("30.00"))
        self.assertEqual(order.refundable(), Decimal("24.77"))
        self.assertEqual(refund(order, Decimal("24.77"), "b").amount, Decimal("24.77"))


class RefundIdempotencyTest(unittest.TestCase):
    def test_replay_returns_original_object_and_changes_nothing(self):
        order = _order()
        first = refund(order, Decimal("5.00"), "k")
        self.assertIs(refund(order, Decimal("5.00"), "k"), first)
        self.assertEqual(order.refunded(), Decimal("5.00"))
        self.assertEqual(order.refunds, (first,))

    def test_numerically_equal_amounts_are_the_same(self):
        order = _order()
        first = refund(order, Decimal("5"), "k")
        self.assertIs(refund(order, Decimal("5.00"), "k"), first)

    def test_replay_after_full_refund(self):
        order = _order()
        first = refund(order, TOTAL, "k")
        self.assertIs(refund(order, TOTAL, "k"), first)
        self.assertEqual(order.refundable(), Decimal("0.00"))

    def test_same_key_different_amount_raises_and_changes_nothing(self):
        order = _order()
        first = refund(order, Decimal("5.00"), "k")
        with self.assertRaises(RefundError):
            refund(order, Decimal("6.00"), "k")
        self.assertEqual(order.refunds, (first,))
        self.assertEqual(order.refunded(), Decimal("5.00"))

    def test_replay_with_invalid_amount_raises(self):
        for amount in (5.0, Decimal("5.001")):
            with self.subTest(amount=repr(amount)):
                order = _order()
                first = refund(order, Decimal("5.00"), "k")
                with self.assertRaises(RefundError):
                    refund(order, amount, "k")
                self.assertEqual(order.refunds, (first,))

    def test_same_key_on_another_order_is_independent(self):
        a = _order()
        b = _order()
        refund_a = refund(a, Decimal("5.00"), "k")
        refund_b = refund(b, Decimal("5.00"), "k")
        self.assertIsNot(refund_a, refund_b)
        self.assertEqual(refund_b.order_id, b.id)
        self.assertEqual(b.refunded(), Decimal("5.00"))

    def test_failed_refund_does_not_record_key(self):
        for amount in (Decimal("5.001"), 5.0, Decimal("NaN")):
            with self.subTest(amount=repr(amount)):
                order = _order()
                with self.assertRaises(RefundError):
                    refund(order, amount, "k")
                self.assertEqual(refund(order, Decimal("5.00"), "k").amount, Decimal("5.00"))


class RefundRecordTest(unittest.TestCase):
    def test_fields(self):
        order = _order()
        record = refund(order, Decimal("5.00"), "k")
        self.assertIsInstance(record, Refund)
        self.assertEqual(record.order_id, order.id)
        self.assertEqual(record.amount, Decimal("5.00"))
        self.assertEqual(record.key, "k")

    def test_is_immutable(self):
        record = refund(_order(), Decimal("5.00"), "k")
        with self.assertRaises(FrozenInstanceError):
            record.amount = Decimal("9.00")


class RefundConcurrencyTest(unittest.TestCase):
    def test_distinct_keys_never_exceed_total(self):
        # Each refund is 10.00 and TOTAL is 54.77, so exactly 5 of 8 may succeed.
        for _ in range(50):
            order = _order()
            outcomes = []
            errors = []
            lock = threading.Lock()
            barrier = threading.Barrier(8)

            def attempt(i):
                barrier.wait()
                try:
                    refund(order, Decimal("10.00"), f"key-{i}")
                    result = "ok"
                except RefundError:
                    result = "refused"
                except Exception as exc:
                    with lock:
                        errors.append(exc)
                    return
                with lock:
                    outcomes.append(result)

            threads = [threading.Thread(target=attempt, args=(i,)) for i in range(8)]
            for thread in threads:
                thread.start()
            for thread in threads:
                thread.join()
            self.assertEqual(errors, [])
            self.assertEqual(outcomes.count("ok"), 5)
            self.assertEqual(outcomes.count("refused"), 3)
            self.assertEqual(order.refunded(), Decimal("50.00"))
            self.assertLessEqual(order.refunded(), order.total)

    def test_same_key_from_many_threads_makes_one_refund(self):
        for _ in range(50):
            order = _order()
            results = []
            lock = threading.Lock()
            barrier = threading.Barrier(8)

            def attempt():
                barrier.wait()
                record = refund(order, Decimal("5.00"), "k")
                with lock:
                    results.append(record)

            threads = [threading.Thread(target=attempt) for _ in range(8)]
            for thread in threads:
                thread.start()
            for thread in threads:
                thread.join()
            self.assertEqual(len(results), 8)
            self.assertEqual(len(order.refunds), 1)
            self.assertEqual(order.refunded(), Decimal("5.00"))
            self.assertTrue(all(record is results[0] for record in results))


class RefundPropertyTest(unittest.TestCase):
    def test_invariants_hold_for_generated_amounts(self):
        rng = random.Random(1234)
        order = _order()
        for _ in range(1000):
            amount = _random_amount(rng)
            key = f"k{rng.randrange(20)}"
            before = order.refunds
            try:
                first = refund(order, amount, key)
            except RefundError:
                first = None
                self.assertEqual(order.refunds, before, msg=f"changed by {amount!r}")
            after = order.refunds
            self.assertEqual(order.refunded(), sum((r.amount for r in after), Decimal("0.00")),
                             msg=f"sum differs after {amount!r}")
            self.assertLessEqual(order.refunded(), order.total, msg=f"over total after {amount!r}")
            self.assertEqual(order.refundable(), order.total - order.refunded(),
                             msg=f"refundable differs after {amount!r}")
            if first is not None:
                # doing it twice equals doing it once
                self.assertIs(refund(order, amount, key), first, msg=f"replay differs for {amount!r}")
                self.assertEqual(order.refunds, after, msg=f"replay changed state for {amount!r}")

import dataclasses
import random
import threading
import time
import unittest
from decimal import Decimal
from unittest import mock

from shop.cart import Cart
from shop.orders import Order, Refund, RefundError, _refunded, place_order, refund

THREADS = 8
ROUNDS = 10
HALF = Decimal("0.50")
WIDEN_SECONDS = 0.001
real_refunded = _refunded


def widened_refunded(order):
    """Read the refunded sum, then pause before refund() writes, so a missing lock loses updates."""
    total = real_refunded(order)
    time.sleep(WIDEN_SECONDS)
    return total


HOSTILE_AMOUNTS = [
    5,
    5.0,
    "5.00",
    True,
    None,
    Decimal("0"),
    Decimal("-0"),
    Decimal("-1.00"),
    Decimal("0.001"),
    Decimal("1.005"),
    Decimal("NaN"),
    Decimal("sNaN"),
    Decimal("Infinity"),
    Decimal("-Infinity"),
    Decimal("1E+30"),
]


def make_order(*skus):
    cart = Cart()
    for sku in skus or ["MUG"]:
        cart.add(sku)
    return place_order(cart)


def run_in_threads(worker, count=THREADS):
    """Start count threads at once and return the exceptions they raised."""
    barrier = threading.Barrier(count)
    errors = []

    def run(index):
        barrier.wait()
        try:
            worker(index)
        except Exception as exc:
            errors.append(exc)

    threads = [threading.Thread(target=run, args=(i,)) for i in range(count)]
    for thread in threads:
        thread.start()
    for thread in threads:
        thread.join()
    return errors


class PlaceOrderTest(unittest.TestCase):
    def test_total_matches_cart(self):
        cart = Cart()
        cart.add("BEAN-ETH", 2)
        order = place_order(cart)
        self.assertIsInstance(order, Order)
        self.assertEqual(order.total, cart.total())

    def test_later_cart_changes_do_not_change_total(self):
        cart = Cart()
        cart.add("MUG")
        order = place_order(cart)
        total = order.total
        cart.add("BEAN-ETH", 3)
        cart.remove("MUG")
        self.assertEqual(order.total, total)

    def test_same_cart_twice_gives_distinct_orders(self):
        cart = Cart()
        cart.add("MUG")
        first = place_order(cart)
        second = place_order(cart)
        self.assertIsNot(first, second)
        self.assertNotEqual(first.id, second.id)

    def test_empty_cart_raises(self):
        with self.assertRaises(ValueError) as ctx:
            place_order(Cart())
        self.assertEqual(str(ctx.exception), "cart is empty")

    def test_cart_with_all_items_removed_raises(self):
        cart = Cart()
        cart.add("MUG")
        cart.remove("MUG")
        with self.assertRaises(ValueError) as ctx:
            place_order(cart)
        self.assertEqual(str(ctx.exception), "cart is empty")

    def test_ids_unique_across_threads(self):
        ids = []

        def worker(index):
            for _ in range(100):
                ids.append(make_order().id)

        self.assertEqual(run_in_threads(worker), [])
        self.assertEqual(len(ids), THREADS * 100)
        self.assertEqual(len(set(ids)), len(ids))


class TotalsTest(unittest.TestCase):
    def test_nothing_refunded_yet(self):
        order = make_order()
        self.assertEqual(order.refunded(), Decimal("0.00"))
        self.assertEqual(str(order.refunded()), "0.00")
        self.assertEqual(order.refundable(), order.total)

    def test_refundable_is_total_minus_refunded(self):
        order = make_order()
        refund(order, Decimal("10.00"), "a")
        self.assertEqual(order.refunded(), Decimal("10.00"))
        self.assertEqual(order.refundable(), order.total - Decimal("10.00"))


class RefundAmountTest(unittest.TestCase):
    def test_hostile_amounts_raise_and_change_nothing(self):
        order = make_order()
        for amount in HOSTILE_AMOUNTS:
            with self.subTest(amount=amount):
                with self.assertRaises(RefundError) as ctx:
                    refund(order, amount, "k")
                self.assertEqual(
                    str(ctx.exception), "amount must be a positive whole-cent Decimal"
                )
                self.assertEqual(order.refunded(), Decimal("0.00"))
        # none of the rejected attempts consumed the key
        self.assertEqual(refund(order, Decimal("1.00"), "k").amount, Decimal("1.00"))

    def test_whole_cents_spelled_differently_are_accepted(self):
        order = make_order()
        self.assertEqual(refund(order, Decimal("5.000"), "a").amount, Decimal("5.00"))


class PartialRefundTest(unittest.TestCase):
    def test_over_refundable_raises_and_key_is_not_consumed(self):
        order = make_order()
        with self.assertRaises(RefundError):
            refund(order, order.refundable() + Decimal("0.01"), "k")
        self.assertEqual(order.refunded(), Decimal("0.00"))
        self.assertEqual(refund(order, Decimal("1.00"), "k").amount, Decimal("1.00"))

    def test_series_reaching_total_then_one_cent_more_raises(self):
        order = make_order()
        total = order.total
        refund(order, Decimal("10.00"), "a")
        refund(order, Decimal("5.00"), "b")
        refund(order, order.refundable(), "c")
        self.assertEqual(order.refunded(), total)
        self.assertEqual(order.refundable(), Decimal("0.00"))
        with self.assertRaises(RefundError):
            refund(order, Decimal("0.01"), "d")
        self.assertEqual(order.refunded(), total)

    def test_refund_on_fully_refunded_order_raises(self):
        order = make_order()
        refund(order, order.total, "a")
        with self.assertRaises(RefundError):
            refund(order, Decimal("0.01"), "b")


class IdempotencyTest(unittest.TestCase):
    def test_same_key_same_amount_returns_original(self):
        order = make_order()
        first = refund(order, Decimal("5"), "k")
        again = refund(order, Decimal("5.00"), "k")
        self.assertIs(first, again)
        self.assertEqual(order.refunded(), Decimal("5.00"))

    def test_same_key_after_fully_refunded_returns_original(self):
        order = make_order()
        first = refund(order, order.total, "k")
        again = refund(order, order.total, "k")
        self.assertIs(first, again)
        self.assertEqual(order.refunded(), order.total)

    def test_same_key_different_amount_raises_and_changes_nothing(self):
        order = make_order()
        refund(order, Decimal("5.00"), "k")
        with self.assertRaises(RefundError):
            refund(order, Decimal("6.00"), "k")
        self.assertEqual(order.refunded(), Decimal("5.00"))

    def test_same_key_on_other_order_is_independent(self):
        first_order = make_order()
        second_order = make_order()
        first = refund(first_order, Decimal("5.00"), "k")
        second = refund(second_order, Decimal("7.00"), "k")
        self.assertEqual(second.order_id, second_order.id)
        self.assertEqual(second.amount, Decimal("7.00"))
        self.assertEqual(first.amount, Decimal("5.00"))


class RefundRecordTest(unittest.TestCase):
    def test_records_order_amount_and_key(self):
        order = make_order()
        record = refund(order, Decimal("5"), "k")
        self.assertIsInstance(record, Refund)
        self.assertEqual(record.order_id, order.id)
        self.assertEqual(record.amount, Decimal("5.00"))
        self.assertEqual(str(record.amount), "5.00")
        self.assertEqual(record.key, "k")

    def test_refund_is_immutable(self):
        record = refund(make_order(), Decimal("5.00"), "k")
        with self.assertRaises(dataclasses.FrozenInstanceError):
            record.amount = Decimal("1.00")


class ConcurrencyTest(unittest.TestCase):
    def setUp(self):
        patcher = mock.patch("shop.orders._refunded", widened_refunded)
        patcher.start()
        self.addCleanup(patcher.stop)

    def test_concurrent_refunds_never_exceed_total(self):
        for _ in range(ROUNDS):
            order = make_order("BEAN-ETH")
            accepted = []

            def worker(index):
                for n in range(20):
                    try:
                        refund(order, HALF, f"{index}-{n}")
                        accepted.append(index)
                    except RefundError:
                        pass

            self.assertEqual(run_in_threads(worker), [])
            self.assertLessEqual(order.refunded(), order.total)
            self.assertEqual(order.refunded(), HALF * len(accepted))
            self.assertLess(order.refundable(), HALF)

    def test_same_key_from_many_threads_gives_one_refund(self):
        for _ in range(ROUNDS):
            order = make_order()
            seen = [None] * THREADS

            def worker(index):
                seen[index] = refund(order, Decimal("5.00"), "k")

            self.assertEqual(run_in_threads(worker), [])
            self.assertEqual(order.refunded(), Decimal("5.00"))
            self.assertTrue(all(record is seen[0] for record in seen))


class RandomInputTest(unittest.TestCase):
    def test_random_inputs_keep_invariants(self):
        rng = random.Random(1234)
        order = make_order()
        for _ in range(1000):
            if rng.random() < 0.3:
                amount = rng.choice(HOSTILE_AMOUNTS)
            else:
                amount = Decimal(rng.randint(-100, 4000)) / Decimal(rng.choice([100, 1000]))
            key = rng.choice("abcd")
            before = order.refunded()
            try:
                record = refund(order, amount, key)
            except RefundError:
                record = None
            after = order.refunded()
            ok = 0 <= after <= order.total and order.refundable() == order.total - after
            if record is None:
                ok = ok and after == before
            else:
                ok = ok and after in (before, before + record.amount)
            self.assertTrue(ok, f"failing input (amount, key): {(amount, key)}")

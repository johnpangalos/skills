package middleware

import (
	"bufio"
	"bytes"
	"crypto/sha256"
	"encoding/hex"
	"errors"
	"net"
	"net/http"
	"strings"
)

// ETag is a middleware that adds a strong ETag header to GET and HEAD responses
// with status 200 that don't already set one. The ETag is the hex-encoded SHA-256
// of the response body. When If-None-Match matches the ETag, or is "*", it responds
// 304 Not Modified with no body.
//
// The whole response is buffered in memory until the handler returns, so avoid it
// for very large bodies. A Flush call or a non-200 status stops buffering and
// streams the response unchanged.
//
// NoCache strips If-None-Match from the request, so it must not run before ETag.
func ETag(next http.Handler) http.Handler {
	fn := func(w http.ResponseWriter, r *http.Request) {
		if r.Method != http.MethodGet && r.Method != http.MethodHead {
			next.ServeHTTP(w, r)
			return
		}

		ew := &etagResponseWriter{ResponseWriter: w}
		next.ServeHTTP(ew, r)
		ew.finish(r)
	}

	return http.HandlerFunc(fn)
}

type etagResponseWriter struct {
	http.ResponseWriter

	wroteHeader bool
	status      int
	streaming   bool
	buf         bytes.Buffer
}

func (ew *etagResponseWriter) WriteHeader(code int) {
	if ew.wroteHeader {
		return
	}
	// 101 Switching Protocols is final, as in net/http, so it is not forwarded as informational.
	if code >= 100 && code <= 199 && code != http.StatusSwitchingProtocols {
		// Informational responses are not the final status, so forward them now.
		ew.ResponseWriter.WriteHeader(code)
		return
	}

	ew.wroteHeader = true
	ew.status = code
	if code != http.StatusOK {
		ew.stream()
	}
}

func (ew *etagResponseWriter) Write(p []byte) (int, error) {
	if ew.streaming {
		return ew.ResponseWriter.Write(p)
	}
	if !ew.wroteHeader {
		ew.wroteHeader = true
		ew.status = http.StatusOK
	}

	return ew.buf.Write(p)
}

// stream stops buffering. It sends the pending status, headers and body unchanged.
func (ew *etagResponseWriter) stream() {
	if ew.streaming {
		return
	}
	ew.streaming = true
	if !ew.wroteHeader {
		ew.wroteHeader = true
		ew.status = http.StatusOK
	}

	ew.ResponseWriter.WriteHeader(ew.status)
	if ew.buf.Len() > 0 {
		ew.ResponseWriter.Write(ew.buf.Bytes())
	}
	ew.buf.Reset()
}

// finish runs after the handler returns. For a buffered 200 response it sets the
// ETag, then answers 304 or sends the buffered 200 response.
func (ew *etagResponseWriter) finish(r *http.Request) {
	if ew.streaming {
		return
	}

	h := ew.Header()
	head := r.Method == http.MethodHead
	// A HEAD response with no body has no meaningful hash, so it gets no ETag.
	if len(h.Values("ETag")) == 0 && (!head || ew.buf.Len() > 0) {
		sum := sha256.Sum256(ew.buf.Bytes())
		h.Set("ETag", `"`+hex.EncodeToString(sum[:])+`"`)
	}

	if etagNoneMatch(r.Header.Values("If-None-Match"), h.Get("ETag")) {
		h.Del("Content-Length")
		h.Del("Content-Type")
		ew.ResponseWriter.WriteHeader(http.StatusNotModified)
		return
	}

	ew.ResponseWriter.WriteHeader(http.StatusOK)
	if !head && ew.buf.Len() > 0 {
		ew.ResponseWriter.Write(ew.buf.Bytes())
	}
}

// etagNoneMatch reports whether any member of the If-None-Match header values is "*"
// or weakly matches etag. Members are separated by commas, but a comma inside a quoted
// entity-tag does not separate members. Malformed members are skipped.
func etagNoneMatch(values []string, etag string) bool {
	for _, s := range values {
		s = strings.TrimLeft(s, " \t")
		for s != "" {
			if s[0] == '*' && isETagMemberEnd(s[1:]) {
				return true
			}

			tag, rest := scanETag(s)
			if tag != "" && isETagMemberEnd(rest) {
				// Weak comparison ignores a leading W/ on either tag.
				if strings.TrimPrefix(tag, "W/") == strings.TrimPrefix(etag, "W/") {
					return true
				}
				s = rest
			} else {
				// Malformed member: skip to the next comma.
				i := strings.IndexByte(s, ',')
				if i < 0 {
					break
				}
				s = s[i:]
			}

			// Consume the separator and any whitespace around it.
			s = strings.TrimLeft(s, " \t")
			s = strings.TrimPrefix(s, ",")
			s = strings.TrimLeft(s, " \t")
		}
	}

	return false
}

// isETagMemberEnd reports whether s, after optional whitespace, is empty or starts
// with the comma that separates If-None-Match members.
func isETagMemberEnd(s string) bool {
	s = strings.TrimLeft(s, " \t")
	return s == "" || s[0] == ','
}

// scanETag returns the entity-tag at the start of s, either W/"text" or "text", and
// the remainder of s after it. It returns an empty tag if s does not start with one.
func scanETag(s string) (etag string, remain string) {
	s = strings.TrimSpace(s)
	start := 0
	if strings.HasPrefix(s, "W/") {
		start = 2
	}
	if len(s[start:]) < 2 || s[start] != '"' {
		return "", ""
	}
	// The opaque-tag allows 0x21, 0x23-0x7E and 0x80 and above. A comma is allowed.
	for i := start + 1; i < len(s); i++ {
		c := s[i]
		switch {
		case c == 0x21 || c >= 0x23 && c <= 0x7E || c >= 0x80:
		case c == '"':
			return s[:i+1], s[i+1:]
		default:
			return "", ""
		}
	}
	return "", ""
}

func (ew *etagResponseWriter) Flush() {
	ew.stream()
	if f, ok := ew.ResponseWriter.(http.Flusher); ok {
		f.Flush()
	}
}

func (ew *etagResponseWriter) Hijack() (net.Conn, *bufio.ReadWriter, error) {
	hj, ok := ew.ResponseWriter.(http.Hijacker)
	if !ok {
		return nil, nil, errors.New("chi/middleware: http.Hijacker is unavailable on the writer")
	}
	// Send a pending status and buffered body first, as net/http does. With nothing
	// written, send nothing, so the caller can write its own raw response (e.g. a 101).
	if ew.wroteHeader {
		ew.Flush()
	}
	ew.streaming = true // The connection is no longer ours to buffer.
	return hj.Hijack()
}

func (ew *etagResponseWriter) Push(target string, opts *http.PushOptions) error {
	if ps, ok := ew.ResponseWriter.(http.Pusher); ok {
		return ps.Push(target, opts)
	}
	return errors.New("chi/middleware: http.Pusher is unavailable on the writer")
}

func (ew *etagResponseWriter) Unwrap() http.ResponseWriter {
	return ew.ResponseWriter
}

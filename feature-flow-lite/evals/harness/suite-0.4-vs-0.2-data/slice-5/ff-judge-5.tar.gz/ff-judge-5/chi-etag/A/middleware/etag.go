package middleware

import (
	"bufio"
	"bytes"
	"crypto/sha256"
	"encoding/hex"
	"errors"
	"maps"
	"net"
	"net/http"
	"strings"
)

// ETag is a middleware that validates GET and HEAD responses with entity tags.
// The response is buffered until the handler returns. A 200 response that the
// handler did not tag gets a strong ETag: the quoted hex SHA-256 of its body.
// A HEAD response with no body gets no generated ETag. When If-None-Match matches
// the response ETag (weak comparison, as in RFC 9110 section 13.1.2), the response
// becomes 304 Not Modified with no body. Other methods and non-200 responses pass
// through unchanged.
//
// ETag tags the bytes that reach it. Register it before Compress to tag the
// compressed representation, or after Compress to tag the identity bytes.
// ETag reads If-None-Match before calling the next handler, so a NoCache inside
// it, as in r.Use(ETag, NoCache), does not stop a 304. Registered after NoCache,
// ETag sees no If-None-Match.
func ETag(next http.Handler) http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		if r.Method != http.MethodGet && r.Method != http.MethodHead {
			next.ServeHTTP(w, r)
			return
		}
		ifNoneMatch := r.Header.Values("If-None-Match")
		ew := &etagResponseWriter{ResponseWriter: w}
		next.ServeHTTP(ew, r)
		ew.finish(r.Method, ifNoneMatch)
	})
}

type etagResponseWriter struct {
	http.ResponseWriter

	snapshot    http.Header // copy of the headers taken at WriteHeader
	body        bytes.Buffer
	status      int
	wroteHeader bool
	hijacked    bool
}

// Header returns the live header map. The committed headers are the snapshot
// taken at WriteHeader, so later changes to this map do not reach the client.
func (ew *etagResponseWriter) Header() http.Header {
	return ew.ResponseWriter.Header()
}

// WriteHeader records the final status and snapshots the headers. Informational
// 1xx responses except 101 are forwarded at once and do not count as the final status.
func (ew *etagResponseWriter) WriteHeader(code int) {
	if code >= 100 && code < 200 && code != http.StatusSwitchingProtocols {
		ew.ResponseWriter.WriteHeader(code)
		return
	}
	if ew.wroteHeader {
		return
	}
	ew.wroteHeader = true
	ew.status = code
	ew.snapshot = ew.ResponseWriter.Header().Clone()
}

func (ew *etagResponseWriter) Write(p []byte) (int, error) {
	if ew.hijacked {
		return 0, http.ErrHijacked
	}
	if !ew.wroteHeader {
		ew.WriteHeader(http.StatusOK)
	}
	return ew.body.Write(p)
}

// Flush is a no-op: nothing is sent until the handler returns.
func (ew *etagResponseWriter) Flush() {}

func (ew *etagResponseWriter) Hijack() (net.Conn, *bufio.ReadWriter, error) {
	hj, ok := ew.ResponseWriter.(http.Hijacker)
	if !ok {
		return nil, nil, errors.New("chi/middleware: http.Hijacker is unavailable on the writer")
	}
	conn, rw, err := hj.Hijack()
	if err == nil {
		ew.hijacked = true
	}
	return conn, rw, err
}

func (ew *etagResponseWriter) Push(target string, opts *http.PushOptions) error {
	if ps, ok := ew.ResponseWriter.(http.Pusher); ok {
		return ps.Push(target, opts)
	}
	return http.ErrNotSupported
}

func (ew *etagResponseWriter) Unwrap() http.ResponseWriter {
	return ew.ResponseWriter
}

// finish sends the buffered response to the underlying writer.
func (ew *etagResponseWriter) finish(method string, ifNoneMatch []string) {
	if ew.hijacked {
		return
	}
	ew.WriteHeader(http.StatusOK) // no-op if the handler already wrote a status
	if ew.status == http.StatusOK {
		etag := ew.snapshot.Get("ETag")
		if etag == "" && (method != http.MethodHead || ew.body.Len() > 0) {
			etag = ew.generateETag()
		}
		if etag != "" && etagMatch(ifNoneMatch, etag) {
			ew.notModified()
		}
	}

	dst := ew.ResponseWriter.Header()
	trailers := liveTrailers(dst, ew.snapshot)
	clear(dst)
	maps.Copy(dst, ew.snapshot)
	ew.ResponseWriter.WriteHeader(ew.status)
	ew.ResponseWriter.Write(ew.body.Bytes())
	// Late trailer values go on the live map after the headers are sent, so they
	// are not sent as headers and do not overwrite values set before WriteHeader.
	maps.Copy(dst, trailers)
}

// generateETag sets a strong ETag computed from the body and returns it.
func (ew *etagResponseWriter) generateETag() string {
	sum := sha256.Sum256(ew.body.Bytes())
	etag := `"` + hex.EncodeToString(sum[:]) + `"`
	ew.snapshot.Set("ETag", etag)
	return etag
}

// notModified turns the buffered response into a 304 with no body.
func (ew *etagResponseWriter) notModified() {
	ew.status = http.StatusNotModified
	ew.snapshot.Del("Content-Length")
	ew.snapshot.Del("Content-Type")
	ew.snapshot.Del("Transfer-Encoding")
	ew.body.Reset()
}

// liveTrailers returns the trailer values the handler set on the live header map
// after WriteHeader: keys declared in the snapshot's Trailer header, and
// http.TrailerPrefix keys.
func liveTrailers(live, snapshot http.Header) http.Header {
	trailers := http.Header{}
	for _, decl := range snapshot.Values("Trailer") {
		for _, name := range strings.Split(decl, ",") {
			key := http.CanonicalHeaderKey(strings.TrimSpace(name))
			if vv, ok := live[key]; ok {
				trailers[key] = vv
			}
		}
	}
	for key, vv := range live {
		if strings.HasPrefix(key, http.TrailerPrefix) {
			trailers[key] = vv
		}
	}
	return trailers
}

// etagMatch reports whether any If-None-Match header line matches etag.
func etagMatch(lines []string, etag string) bool {
	for _, line := range lines {
		if etagMatchLine(line, etag) {
			return true
		}
	}
	return false
}

// etagMatchLine reports whether an If-None-Match header line matches etag.
// Malformed members are skipped.
func etagMatchLine(line, etag string) bool {
	line = strings.TrimSpace(line)
	if line == "*" {
		return true
	}
	want := strings.TrimPrefix(etag, "W/")
	for {
		line = strings.TrimLeft(line, " \t,")
		if line == "" {
			return false
		}
		tag, rest, ok := nextEntityTag(line)
		if ok && tag == want {
			return true
		}
		line = rest
	}
}

// nextEntityTag parses the entity-tag at the start of s and returns it without
// its W/ prefix, plus the input after it. For a malformed member, ok is false
// and rest starts at the next comma.
func nextEntityTag(s string) (tag, rest string, ok bool) {
	body := strings.TrimPrefix(s, "W/")
	if !strings.HasPrefix(body, `"`) {
		return "", skipMember(s), false
	}
	end := strings.IndexByte(body[1:], '"')
	if end < 0 {
		return "", "", false
	}
	tag = body[:end+2]
	rest = strings.TrimLeft(body[end+2:], " \t")
	if rest != "" && rest[0] != ',' {
		return "", skipMember(rest), false
	}
	return tag, rest, true
}

// skipMember returns s from its next comma, or an empty string if there is none.
func skipMember(s string) string {
	if i := strings.IndexByte(s, ','); i >= 0 {
		return s[i:]
	}
	return ""
}

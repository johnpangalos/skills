package middleware

import (
	"bufio"
	"context"
	"errors"
	"io"
	"net"
	"net/http"
	"net/http/httptest"
	"net/http/httptrace"
	"net/textproto"
	"strings"
	"testing"
	"time"
)

// etagRequest serves method with the given If-None-Match header lines through
// the ETag middleware and returns the recorded response.
func etagRequest(method string, ifNoneMatch []string, h http.HandlerFunc) *httptest.ResponseRecorder {
	req := httptest.NewRequest(method, "/resource", nil)
	for _, v := range ifNoneMatch {
		req.Header.Add("If-None-Match", v)
	}
	rec := httptest.NewRecorder()
	ETag(h).ServeHTTP(rec, req)
	return rec
}

func TestETagPassesThroughOtherMethods(t *testing.T) {
	for _, method := range []string{http.MethodPost, http.MethodPut, http.MethodDelete, http.MethodOptions} {
		var got http.ResponseWriter
		rec := etagRequest(method, []string{"*"}, func(w http.ResponseWriter, r *http.Request) {
			got = w
			w.Write([]byte("hello"))
		})

		if got != rec {
			t.Fatalf("%s: handler got a wrapped writer, want the original", method)
		}
		if rec.Code != http.StatusOK || rec.Body.String() != "hello" {
			t.Fatalf("%s: got %d %q, want 200 \"hello\"", method, rec.Code, rec.Body.String())
		}
		if etag := rec.Header().Get("ETag"); etag != "" {
			t.Fatalf("%s: unexpected ETag %q", method, etag)
		}
	}
}

func TestETagComputesStrongETag(t *testing.T) {
	hello := etagRequest(http.MethodGet, nil, func(w http.ResponseWriter, r *http.Request) {
		w.Write([]byte("hello"))
	})
	etag := hello.Header().Get("ETag")
	if len(etag) != 66 || etag[0] != '"' || etag[65] != '"' || strings.HasPrefix(etag, "W/") {
		t.Fatalf("want strong quoted sha256 ETag, got %q", etag)
	}
	if etag != strongETag([]byte("hello")) {
		t.Fatalf("ETag %q does not hash the body", etag)
	}
	if hello.Code != http.StatusOK || hello.Body.String() != "hello" {
		t.Fatalf("got %d %q, want 200 \"hello\"", hello.Code, hello.Body.String())
	}

	again := etagRequest(http.MethodGet, nil, func(w http.ResponseWriter, r *http.Request) {
		w.Write([]byte("hello"))
	})
	other := etagRequest(http.MethodGet, nil, func(w http.ResponseWriter, r *http.Request) {
		w.Write([]byte("bye"))
	})
	if again.Header().Get("ETag") != etag {
		t.Fatal("same body gave a different ETag")
	}
	if other.Header().Get("ETag") == etag {
		t.Fatal("different body gave the same ETag")
	}
}

func TestETagEmptyBodyAndContentLength(t *testing.T) {
	empty := etagRequest(http.MethodGet, nil, func(w http.ResponseWriter, r *http.Request) {})
	if empty.Code != http.StatusOK || empty.Header().Get("ETag") != strongETag(nil) {
		t.Fatalf("got %d ETag %q, want 200 with ETag of empty body", empty.Code, empty.Header().Get("ETag"))
	}

	sized := etagRequest(http.MethodGet, nil, func(w http.ResponseWriter, r *http.Request) {
		w.Header().Set("Content-Length", "5")
		w.Write([]byte("hello"))
	})
	if got := sized.Header().Get("Content-Length"); got != "5" {
		t.Fatalf("Content-Length = %q, want \"5\"", got)
	}
}

func TestETagKeepsHandlerETag(t *testing.T) {
	for _, etag := range []string{`"mine"`, `W/"mine"`} {
		rec := etagRequest(http.MethodGet, nil, func(w http.ResponseWriter, r *http.Request) {
			w.Header().Set("ETag", etag)
			w.Write([]byte("hello"))
		})
		if got := rec.Header().Get("ETag"); got != etag {
			t.Fatalf("ETag = %q, want handler value %q", got, etag)
		}
	}
}

func TestETagNotModifiedKeepsHeaders(t *testing.T) {
	rec := etagRequest(http.MethodGet, []string{strongETag([]byte("hello"))}, func(w http.ResponseWriter, r *http.Request) {
		h := w.Header()
		h.Set("Cache-Control", "max-age=60")
		h.Set("Content-Location", "/resource.en")
		h.Set("Date", "Mon, 02 Jan 2006 15:04:05 GMT")
		h.Set("Expires", "Mon, 02 Jan 2006 16:04:05 GMT")
		h.Set("Vary", "Accept-Encoding")
		h.Set("X-Custom", "yes")
		h.Set("Content-Type", "text/plain")
		h.Set("Content-Encoding", "identity")
		h.Set("Content-Length", "5")
		w.Write([]byte("hello"))
	})

	if rec.Code != http.StatusNotModified {
		t.Fatalf("status = %d, want 304", rec.Code)
	}
	if rec.Body.Len() != 0 {
		t.Fatalf("304 body = %q, want empty", rec.Body.String())
	}
	for k, want := range map[string]string{
		"ETag":             strongETag([]byte("hello")),
		"Cache-Control":    "max-age=60",
		"Content-Location": "/resource.en",
		"Date":             "Mon, 02 Jan 2006 15:04:05 GMT",
		"Expires":          "Mon, 02 Jan 2006 16:04:05 GMT",
		"Vary":             "Accept-Encoding",
		"X-Custom":         "yes",
	} {
		if got := rec.Header().Get(k); got != want {
			t.Fatalf("%s = %q, want %q", k, got, want)
		}
	}
	for _, k := range []string{"Content-Length", "Content-Type", "Content-Encoding"} {
		if _, ok := rec.Header()[k]; ok {
			t.Fatalf("304 must not have %s", k)
		}
	}
}

func TestETagNonOKPassesThrough(t *testing.T) {
	for _, code := range []int{http.StatusCreated, http.StatusNoContent, http.StatusPartialContent, http.StatusMovedPermanently, http.StatusNotFound, http.StatusInternalServerError} {
		rec := etagRequest(http.MethodGet, []string{`"v1"`}, func(w http.ResponseWriter, r *http.Request) {
			w.Header().Set("ETag", `"v1"`)
			w.Header().Set("X-Status", "kept")
			w.WriteHeader(code)
			w.Write([]byte("body"))
		})
		if rec.Code != code || rec.Body.String() != "body" {
			t.Fatalf("got %d %q, want %d \"body\"", rec.Code, rec.Body.String(), code)
		}
		if rec.Header().Get("ETag") != `"v1"` || rec.Header().Get("X-Status") != "kept" {
			t.Fatalf("%d: headers changed: %v", code, rec.Header())
		}
	}

	rec := etagRequest(http.MethodGet, []string{"*"}, func(w http.ResponseWriter, r *http.Request) {
		w.WriteHeader(http.StatusNotFound)
		w.Write([]byte("missing"))
	})
	if rec.Code != http.StatusNotFound || rec.Header().Get("ETag") != "" {
		t.Fatalf("404 got %d ETag %q, want 404 without ETag", rec.Code, rec.Header().Get("ETag"))
	}
}

func TestETagIfNoneMatch(t *testing.T) {
	tests := []struct {
		name    string
		header  []string
		etag    string // ETag set by the handler; empty means the computed one
		want304 bool
	}{
		{name: "star", header: []string{"*"}, etag: `"abc"`, want304: true},
		{name: "list with OWS", header: []string{`"x", "abc" ,  "y"`}, etag: `"abc"`, want304: true},
		{name: "list with empty elements", header: []string{`, "abc",`}, etag: `"abc"`, want304: true},
		{name: "weak request matches strong", header: []string{`W/"abc"`}, etag: `"abc"`, want304: true},
		{name: "strong request matches weak", header: []string{`"abc"`}, etag: `W/"abc"`, want304: true},
		{name: "exact mismatch", header: []string{`"abd"`}, etag: `"abc"`, want304: false},
		{name: "lowercase w is not weak", header: []string{`w/"abc"`}, etag: `"abc"`, want304: false},
		{name: "empty tag", header: []string{`""`}, etag: `""`, want304: true},
		{name: "weak empty tag", header: []string{`W/""`}, etag: `""`, want304: true},
		{name: "empty tag never matches computed hash", header: []string{`""`}, want304: false},
		{name: "weak list spacing", header: []string{`W/"a", "b" ,  "c"`}, etag: `"c"`, want304: true},
		{name: "comma inside quotes", header: []string{`"a,b"`}, etag: `"a,b"`, want304: true},
		{name: "comma inside quotes in list", header: []string{`"a,b", "c"`}, etag: `"c"`, want304: true},
		{name: "comma split does not form a tag", header: []string{`"a", "b"`}, etag: `"a,b"`, want304: false},
		{name: "unquoted tag", header: []string{`abc`}, etag: `abc`, want304: false},
		{name: "weak unquoted tag", header: []string{`W/abc`}, etag: `"abc"`, want304: false},
		{name: "unterminated quote", header: []string{`"unterminated`}, etag: `"unterminated`, want304: false},
		{name: "space inside tag", header: []string{`"a b"`}, etag: `"a b"`, want304: false},
		{name: "weak prefix without tag", header: []string{`W/`}, etag: `"abc"`, want304: false},
		{name: "empty header value", header: []string{``}, etag: `"abc"`, want304: false},
		{name: "lines are combined", header: []string{`"x"`, `"abc"`}, etag: `"abc"`, want304: true},
		{name: "malformed line does not swallow next line", header: []string{`"unterminated`, `"abc"`}, etag: `"abc"`, want304: true},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			rec := etagRequest(http.MethodGet, tt.header, func(w http.ResponseWriter, r *http.Request) {
				if tt.etag != "" {
					w.Header().Set("ETag", tt.etag)
				}
				w.Write([]byte("abc"))
			})
			if tt.want304 {
				if rec.Code != http.StatusNotModified || rec.Body.Len() != 0 {
					t.Fatalf("got %d %q, want 304 with no body", rec.Code, rec.Body.String())
				}
				return
			}
			if rec.Code != http.StatusOK || rec.Body.String() != "abc" {
				t.Fatalf("got %d %q, want 200 \"abc\"", rec.Code, rec.Body.String())
			}
		})
	}
}

func TestETagHead(t *testing.T) {
	ts := httptest.NewServer(ETag(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		w.Write([]byte("hello"))
	})))
	defer ts.Close()

	req, body := testRequest(t, ts, http.MethodHead, "/", nil)
	if body != "" {
		t.Fatalf("HEAD body = %q, want empty", body)
	}
	if got := req.Header.Get("ETag"); got != strongETag([]byte("hello")) {
		t.Fatalf("HEAD ETag = %q, want ETag of handler body", got)
	}
}

func TestETagFlushAndCopyAreBuffered(t *testing.T) {
	rec := etagRequest(http.MethodGet, nil, func(w http.ResponseWriter, r *http.Request) {
		http.NewResponseController(w).Flush()
		if ew := w.(*etagResponseWriter); ew.body.Len() != 0 {
			t.Error("Flush wrote the body early")
		}
		if _, err := io.Copy(w, strings.NewReader("hello")); err != nil {
			t.Error(err)
		}
	})
	if rec.Flushed {
		t.Fatal("Flush reached the client before the handler returned")
	}
	if rec.Body.String() != "hello" || rec.Code != http.StatusOK {
		t.Fatalf("got %d %q, want 200 \"hello\"", rec.Code, rec.Body.String())
	}
}

func TestETagHijackUnavailable(t *testing.T) {
	var err error
	etagRequest(http.MethodGet, nil, func(w http.ResponseWriter, r *http.Request) {
		_, _, err = w.(http.Hijacker).Hijack()
	})
	if err == nil || err.Error() != "chi/middleware: http.Hijacker is unavailable on the writer" {
		t.Fatalf("Hijack error = %v, want unavailable error", err)
	}
}

func TestETagHijackForwarded(t *testing.T) {
	ts := httptest.NewServer(ETag(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		conn, _, err := http.NewResponseController(w).Hijack()
		if err != nil {
			t.Error(err)
			return
		}
		conn.Write([]byte("HTTP/1.1 200 OK\r\nContent-Length: 2\r\nConnection: close\r\n\r\nok"))
		conn.Close()
	})))
	defer ts.Close()

	conn, err := net.Dial("tcp", ts.Listener.Addr().String())
	if err != nil {
		t.Fatal(err)
	}
	defer conn.Close()
	conn.Write([]byte("GET / HTTP/1.1\r\nHost: test\r\n\r\n"))
	resp, err := http.ReadResponse(bufio.NewReader(conn), nil)
	if err != nil {
		t.Fatal(err)
	}
	body, _ := io.ReadAll(resp.Body)
	if string(body) != "ok" || resp.Header.Get("ETag") != "" {
		t.Fatalf("got %q with ETag %q, want \"ok\" without ETag", body, resp.Header.Get("ETag"))
	}
}

func TestETagTrailersReachClient(t *testing.T) {
	for _, code := range []int{http.StatusOK, http.StatusNotFound} {
		ts := httptest.NewServer(ETag(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
			w.Header().Set("Trailer", "X-T")
			w.WriteHeader(code)
			w.Write([]byte("hello"))
			w.Header().Set("X-T", "a")
			w.Header().Set(http.TrailerPrefix+"X-Late", "b")
		})))

		resp, body := testRequest(t, ts, http.MethodGet, "/", nil)
		ts.Close()
		if resp.StatusCode != code || body != "hello" {
			t.Fatalf("got %d %q, want %d \"hello\"", resp.StatusCode, body, code)
		}
		if got := resp.Trailer.Get("X-T"); got != "a" {
			t.Fatalf("%d: trailer X-T = %q, want \"a\"", code, got)
		}
		if got := resp.Trailer.Get("X-Late"); got != "b" {
			t.Fatalf("%d: trailer X-Late = %q, want \"b\"", code, got)
		}
	}
}

func TestETagEarlyHintsSendHeaders(t *testing.T) {
	ts := httptest.NewServer(ETag(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		w.Header().Set("Link", "</style.css>; rel=preload")
		w.WriteHeader(http.StatusEarlyHints)
		w.Write([]byte("hello"))
	})))
	defer ts.Close()

	var code int
	var hints textproto.MIMEHeader
	trace := &httptrace.ClientTrace{
		Got1xxResponse: func(c int, h textproto.MIMEHeader) error {
			code, hints = c, h
			return nil
		},
	}
	req, err := http.NewRequestWithContext(httptrace.WithClientTrace(context.Background(), trace), http.MethodGet, ts.URL, nil)
	if err != nil {
		t.Fatal(err)
	}
	resp, err := http.DefaultClient.Do(req)
	if err != nil {
		t.Fatal(err)
	}
	resp.Body.Close()

	if code != http.StatusEarlyHints || hints.Get("Link") != "</style.css>; rel=preload" {
		t.Fatalf("got 1xx %d with Link %q, want 103 with the handler's Link", code, hints.Get("Link"))
	}
	if resp.StatusCode != http.StatusOK {
		t.Fatalf("final status = %d, want 200", resp.StatusCode)
	}
}

func TestETagSecondWriteHeaderIgnored(t *testing.T) {
	rec := etagRequest(http.MethodGet, nil, func(w http.ResponseWriter, r *http.Request) {
		w.WriteHeader(http.StatusCreated)
		w.WriteHeader(http.StatusInternalServerError)
		w.Write([]byte("body"))
	})
	if rec.Code != http.StatusCreated || rec.Body.String() != "body" {
		t.Fatalf("got %d %q, want 201 \"body\"", rec.Code, rec.Body.String())
	}
}

func TestETagHeadersAfterWriteHeaderIgnored(t *testing.T) {
	rec := etagRequest(http.MethodGet, nil, func(w http.ResponseWriter, r *http.Request) {
		w.Header().Set("X-A", "1")
		w.WriteHeader(http.StatusOK)
		w.Header().Set("X-A", "2")
		w.Header().Set("X-B", "3")
		w.Write([]byte("body"))
	})
	if got := rec.Header().Get("X-A"); got != "1" {
		t.Fatalf("X-A = %q, want the value at WriteHeader", got)
	}
	if _, ok := rec.Header()["X-B"]; ok {
		t.Fatal("X-B set after WriteHeader was sent")
	}
	if got := rec.Header().Get("ETag"); got != strongETag([]byte("body")) {
		t.Fatalf("ETag = %q, want ETag of the body", got)
	}
}

// pushRecorder is a ResponseRecorder that also accepts server pushes.
type pushRecorder struct {
	*httptest.ResponseRecorder
	pushed string
}

func (p *pushRecorder) Push(target string, _ *http.PushOptions) error {
	p.pushed = target
	return nil
}

func TestETagForwardsPush(t *testing.T) {
	pr := &pushRecorder{ResponseRecorder: httptest.NewRecorder()}
	ETag(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		if err := w.(http.Pusher).Push("/style.css", nil); err != nil {
			t.Error(err)
		}
	})).ServeHTTP(pr, httptest.NewRequest(http.MethodGet, "/resource", nil))
	if pr.pushed != "/style.css" {
		t.Fatalf("pushed %q, want \"/style.css\"", pr.pushed)
	}
}

func TestETagPushNotSupported(t *testing.T) {
	var err error
	etagRequest(http.MethodGet, nil, func(w http.ResponseWriter, r *http.Request) {
		err = w.(http.Pusher).Push("/style.css", nil)
	})
	if !errors.Is(err, http.ErrNotSupported) {
		t.Fatalf("Push error = %v, want feature not supported", err)
	}
}

// deadlineRecorder is a ResponseRecorder that records deadlines and full duplex.
type deadlineRecorder struct {
	*httptest.ResponseRecorder
	writeDeadline time.Time
	readDeadline  time.Time
	fullDuplex    bool
}

func (d *deadlineRecorder) SetWriteDeadline(t time.Time) error {
	d.writeDeadline = t
	return nil
}

func (d *deadlineRecorder) SetReadDeadline(t time.Time) error {
	d.readDeadline = t
	return nil
}

func (d *deadlineRecorder) EnableFullDuplex() error {
	d.fullDuplex = true
	return nil
}

func TestETagForwardsDeadlinesAndFullDuplex(t *testing.T) {
	dr := &deadlineRecorder{ResponseRecorder: httptest.NewRecorder()}
	want := time.Date(2030, 1, 2, 3, 4, 5, 0, time.UTC)
	ETag(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		rc := http.NewResponseController(w)
		if err := rc.SetWriteDeadline(want); err != nil {
			t.Error(err)
		}
		if err := rc.SetReadDeadline(want); err != nil {
			t.Error(err)
		}
		if err := rc.EnableFullDuplex(); err != nil {
			t.Error(err)
		}
		w.Write([]byte("hello"))
	})).ServeHTTP(dr, httptest.NewRequest(http.MethodGet, "/resource", nil))
	if !dr.writeDeadline.Equal(want) || !dr.readDeadline.Equal(want) || !dr.fullDuplex {
		t.Fatalf("deadlines %v %v full duplex %v, want forwarded", dr.writeDeadline, dr.readDeadline, dr.fullDuplex)
	}
}

func TestETagDeadlinesNotSupported(t *testing.T) {
	var errs []error
	etagRequest(http.MethodGet, nil, func(w http.ResponseWriter, r *http.Request) {
		rc := http.NewResponseController(w)
		errs = append(errs, rc.SetWriteDeadline(time.Now()), rc.SetReadDeadline(time.Now()), rc.EnableFullDuplex())
	})
	for i, err := range errs {
		if !errors.Is(err, http.ErrNotSupported) {
			t.Fatalf("call %d error = %v, want feature not supported", i, err)
		}
	}
}

func TestETagServeContentHead(t *testing.T) {
	serve := http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		http.ServeContent(w, r, "resource.txt", time.Time{}, strings.NewReader("hello"))
	})

	head := etagRequest(http.MethodHead, nil, serve)
	if got := head.Header().Get("ETag"); got != "" {
		t.Fatalf("HEAD ETag = %q, want none", got)
	}
	if head.Body.Len() != 0 {
		t.Fatalf("HEAD body = %q, want empty", head.Body.String())
	}

	get := etagRequest(http.MethodGet, nil, serve)
	if got := get.Header().Get("ETag"); got != strongETag([]byte("hello")) {
		t.Fatalf("GET ETag = %q, want ETag of the body", got)
	}
}

func TestETagHeadHandlerETagMatches(t *testing.T) {
	rec := etagRequest(http.MethodHead, []string{`"abc"`}, func(w http.ResponseWriter, r *http.Request) {
		w.Header().Set("ETag", `"abc"`)
	})
	if rec.Code != http.StatusNotModified || rec.Body.Len() != 0 {
		t.Fatalf("got %d %q, want 304 with no body", rec.Code, rec.Body.String())
	}
}

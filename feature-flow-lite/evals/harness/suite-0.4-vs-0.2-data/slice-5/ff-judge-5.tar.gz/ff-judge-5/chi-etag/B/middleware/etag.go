package middleware

import (
	"bufio"
	"bytes"
	"crypto/sha256"
	"encoding/hex"
	"errors"
	"net"
	"net/http"
	"strings"
)

// ETag buffers the responses to GET and HEAD requests in order to set a strong
// ETag on them. A 200 response that the handler gave no ETag gets one computed
// from a SHA-256 hash of its body. When If-None-Match matches the response's
// ETag using weak comparison (RFC 9110 section 13.1.2), the response is sent as
// 304 Not Modified without a body. Other methods, and responses with a status
// other than 200, are passed through unchanged. The whole body is buffered in
// memory before it is sent. When used with Compress, register ETag outside
// Compress (before middleware.Compress) so each content-coding gets its own ETag.
func ETag(next http.Handler) http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		if r.Method != http.MethodGet && r.Method != http.MethodHead {
			next.ServeHTTP(w, r)
			return
		}
		ew := &etagResponseWriter{ResponseWriter: w}
		next.ServeHTTP(ew, r)
		ew.finish(r)
	})
}

type etagResponseWriter struct {
	http.ResponseWriter

	status    int          // final status, 0 until WriteHeader or Write is called
	buf       bytes.Buffer // body held back until the response is finished
	streaming bool         // set once writes go straight to the underlying writer
}

func (w *etagResponseWriter) WriteHeader(code int) {
	if w.status != 0 {
		return // The first final status wins, as in net/http.
	}
	if code >= 100 && code < 200 && code != http.StatusSwitchingProtocols {
		w.ResponseWriter.WriteHeader(code) // Informational, not a final status.
		return
	}
	w.status = code
	if code != http.StatusOK {
		w.startStreaming()
	}
}

func (w *etagResponseWriter) Write(p []byte) (int, error) {
	if w.streaming {
		return w.ResponseWriter.Write(p)
	}
	if w.status == 0 {
		w.status = http.StatusOK
	}
	return w.buf.Write(p)
}

// startStreaming sends the status and any buffered body, then passes all later
// writes straight through to the underlying writer.
func (w *etagResponseWriter) startStreaming() {
	w.streaming = true
	if w.status == 0 {
		w.status = http.StatusOK
	}
	w.ResponseWriter.WriteHeader(w.status)
	w.ResponseWriter.Write(w.buf.Bytes())
	w.buf.Reset()
}

func (w *etagResponseWriter) Flush() {
	if !w.streaming {
		w.startStreaming()
	}
	if f, ok := w.ResponseWriter.(http.Flusher); ok {
		f.Flush()
	}
}

func (w *etagResponseWriter) Hijack() (net.Conn, *bufio.ReadWriter, error) {
	hj, ok := w.ResponseWriter.(http.Hijacker)
	if !ok {
		return nil, nil, errors.New("chi/middleware: http.Hijacker is unavailable on the writer")
	}
	if !w.streaming && w.status != 0 {
		w.startStreaming()
	}
	w.streaming = true
	return hj.Hijack()
}

func (w *etagResponseWriter) Push(target string, opts *http.PushOptions) error {
	if ps, ok := w.ResponseWriter.(http.Pusher); ok {
		return ps.Push(target, opts)
	}
	return errors.New("chi/middleware: http.Pusher is unavailable on the writer")
}

func (w *etagResponseWriter) Unwrap() http.ResponseWriter {
	return w.ResponseWriter
}

// finish sends the buffered response, adding the ETag and answering 304 when
// If-None-Match matches it. A response that was never written is a 200.
func (w *etagResponseWriter) finish(r *http.Request) {
	if w.streaming {
		return
	}
	etag := w.Header().Get("ETag")
	// A HEAD response with no body gets no computed ETag, since it would not
	// match the ETag of the GET response for the same resource.
	if etag == "" && (r.Method == http.MethodGet || w.buf.Len() > 0) {
		etag = bodyETag(w.buf.Bytes())
		w.Header().Set("ETag", etag)
	}
	if ifNoneMatch(r.Header.Values("If-None-Match"), etag) {
		w.Header().Del("Content-Length")
		w.ResponseWriter.WriteHeader(http.StatusNotModified)
		return
	}
	w.ResponseWriter.WriteHeader(http.StatusOK)
	w.ResponseWriter.Write(w.buf.Bytes())
}

// bodyETag returns a strong entity-tag for body: its SHA-256 digest, quoted.
func bodyETag(body []byte) string {
	sum := sha256.Sum256(body)
	return `"` + hex.EncodeToString(sum[:]) + `"`
}

// ifNoneMatch reports whether the If-None-Match header values match etag under
// weak comparison. A header value of "*" matches any response.
func ifNoneMatch(values []string, etag string) bool {
	want := strings.TrimPrefix(etag, "W/")
	for _, line := range values {
		if strings.Trim(line, " \t") == "*" {
			return true
		}
		if etagListMatches(line, want) {
			return true
		}
	}
	return false
}

// etagListMatches reports whether an entity-tag in the comma-separated list s has
// the opaque-tag want. A member that is not a valid entity-tag never matches, and
// scanning resumes at the first comma after its start, since a comma is a legal
// character inside a quoted entity-tag.
func etagListMatches(s, want string) bool {
	for {
		s = strings.TrimLeft(s, " \t,")
		if s == "" {
			return false
		}
		tag, rest, ok := parseETag(s)
		rest = strings.TrimLeft(rest, " \t")
		if ok && (rest == "" || rest[0] == ',') {
			if tag == want {
				return true
			}
			s = rest
			continue
		}
		i := strings.IndexByte(s, ',')
		if i < 0 {
			return false
		}
		s = s[i+1:]
	}
}

// parseETag parses the entity-tag at the start of s, which may have a W/ prefix.
// It returns the opaque-tag without the prefix and the text after its closing
// quote. ok is false if s does not start with a valid entity-tag.
func parseETag(s string) (tag, rest string, ok bool) {
	tag = strings.TrimPrefix(s, "W/")
	if tag == "" || tag[0] != '"' {
		return "", "", false
	}
	for i := 1; i < len(tag); i++ {
		// etagc is %x21 / %x23-7E / obs-text (%x80-FF): no controls, space, DEL or '"'.
		switch c := tag[i]; {
		case c == '"':
			return tag[:i+1], tag[i+1:], true
		case c <= ' ' || c == 0x7f:
			return "", "", false
		}
	}
	return "", "", false
}

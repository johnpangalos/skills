package middleware

import (
	"bufio"
	"bytes"
	"crypto/sha256"
	"encoding/hex"
	"errors"
	"maps"
	"net"
	"net/http"
	"strings"
	"time"
)

// ETag is a middleware that adds an ETag to GET and HEAD responses and
// answers conditional requests with 304 Not Modified.
//
// The response is buffered until the handler returns. If the handler responds
// 200 OK without setting an ETag, the middleware sets a strong ETag made of the
// quoted hex SHA-256 of the body. An ETag set by the handler, strong or weak,
// is kept as is. A HEAD response that wrote no body gets no computed ETag.
//
// When the request's If-None-Match matches the response ETag, the middleware
// responds 304 Not Modified without a body. Matching follows RFC 9110 §13.1.2
// with weak comparison, comma-separated lists and "*". The 304 drops
// Content-Length, Content-Type and Content-Encoding and keeps the other
// headers. Other methods and non-200 responses pass through unchanged.
//
// Place ETag before Compress in the chain, so that Compress wraps the handler
// and the ETag is computed over the encoded body. A strong ETag must differ per
// content-coding.
//
// NOTE: NoCache removes If-None-Match from the request. If NoCache wraps
// ETag, no request can get a 304.
func ETag(next http.Handler) http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		if r.Method != http.MethodGet && r.Method != http.MethodHead {
			next.ServeHTTP(w, r)
			return
		}
		ew := &etagResponseWriter{w: w, header: w.Header().Clone()}
		next.ServeHTTP(ew, r)
		ew.finish(r)
	})
}

// etagResponseWriter buffers the status, headers and body of a response
// until the handler returns.
type etagResponseWriter struct {
	w        http.ResponseWriter
	header   http.Header // headers the handler modifies
	snapshot http.Header // header copy taken at WriteHeader, sent to w
	status   int
	body     bytes.Buffer
	hijacked bool
}

// WriteHeader records the status and freezes the headers, like net/http does.
// Informational 1xx responses are sent directly, with the headers set so far.
func (ew *etagResponseWriter) WriteHeader(code int) {
	if code >= 100 && code < 200 {
		copyHeader(ew.w.Header(), ew.header)
		ew.w.WriteHeader(code)
		return
	}
	if ew.snapshot != nil {
		return
	}
	ew.status = code
	ew.snapshot = ew.header.Clone()
}

// Header returns the buffered headers.
func (ew *etagResponseWriter) Header() http.Header {
	return ew.header
}

// Write buffers the body and records an implicit 200 OK.
func (ew *etagResponseWriter) Write(p []byte) (int, error) {
	if ew.snapshot == nil {
		ew.WriteHeader(http.StatusOK)
	}
	return ew.body.Write(p)
}

// Flush is a no-op because the response is buffered until the handler returns.
func (ew *etagResponseWriter) Flush() {}

// Hijack hands the connection to the handler. The buffered response is then
// discarded.
func (ew *etagResponseWriter) Hijack() (net.Conn, *bufio.ReadWriter, error) {
	hj, ok := ew.w.(http.Hijacker)
	if !ok {
		return nil, nil, errors.New("chi/middleware: http.Hijacker is unavailable on the writer")
	}
	conn, rw, err := hj.Hijack()
	if err == nil {
		ew.hijacked = true
	}
	return conn, rw, err
}

// Push forwards the server push to the underlying writer.
func (ew *etagResponseWriter) Push(target string, opts *http.PushOptions) error {
	ps, ok := ew.w.(http.Pusher)
	if !ok {
		return http.ErrNotSupported
	}
	return ps.Push(target, opts)
}

// SetWriteDeadline forwards the deadline to the underlying writer.
func (ew *etagResponseWriter) SetWriteDeadline(deadline time.Time) error {
	return http.NewResponseController(ew.w).SetWriteDeadline(deadline)
}

// SetReadDeadline forwards the deadline to the underlying writer.
func (ew *etagResponseWriter) SetReadDeadline(deadline time.Time) error {
	return http.NewResponseController(ew.w).SetReadDeadline(deadline)
}

// EnableFullDuplex forwards the request to the underlying writer.
func (ew *etagResponseWriter) EnableFullDuplex() error {
	return http.NewResponseController(ew.w).EnableFullDuplex()
}

// finish sets the ETag and sends the buffered response, or a 304 when the
// request's If-None-Match matches it.
func (ew *etagResponseWriter) finish(r *http.Request) {
	if ew.hijacked {
		return
	}
	if ew.snapshot == nil {
		ew.WriteHeader(http.StatusOK)
	}
	// A HEAD response without a body, such as one from http.ServeContent, gets
	// no ETag. Its hash would not match the one of the GET response.
	if ew.status == http.StatusOK && ew.snapshot.Get("ETag") == "" && (r.Method == http.MethodGet || ew.body.Len() > 0) {
		ew.snapshot.Set("ETag", strongETag(ew.body.Bytes()))
	}

	dst := ew.w.Header()
	copyHeader(dst, ew.snapshot)

	if ew.status == http.StatusOK && ifNoneMatchMatches(r, dst.Get("ETag")) {
		dst.Del("Content-Length")
		dst.Del("Content-Type")
		dst.Del("Content-Encoding")
		ew.w.WriteHeader(http.StatusNotModified)
		return
	}
	ew.w.WriteHeader(ew.status)
	ew.w.Write(ew.body.Bytes())
	ew.copyTrailers()
}

// copyTrailers copies the trailers the handler set after writing the body into
// the header map. net/http sends declared trailers and TrailerPrefix keys from
// that map once the handler returns.
func (ew *etagResponseWriter) copyTrailers() {
	dst := ew.w.Header()
	for _, list := range ew.snapshot.Values("Trailer") {
		for _, name := range strings.Split(list, ",") {
			name = http.CanonicalHeaderKey(strings.TrimSpace(name))
			if v, ok := ew.header[name]; ok {
				dst[name] = v
			}
		}
	}
	for k, v := range ew.header {
		if strings.HasPrefix(k, http.TrailerPrefix) {
			dst[k] = v
		}
	}
}

// copyHeader replaces the contents of dst with those of src.
func copyHeader(dst, src http.Header) {
	clear(dst)
	maps.Copy(dst, src)
}

// strongETag returns the quoted hex SHA-256 of body.
func strongETag(body []byte) string {
	sum := sha256.Sum256(body)
	return `"` + hex.EncodeToString(sum[:]) + `"`
}

// ifNoneMatchMatches reports whether any If-None-Match line of r matches etag.
// Each line is parsed on its own so that a malformed line cannot swallow the next one.
func ifNoneMatchMatches(r *http.Request, etag string) bool {
	for _, line := range r.Header.Values("If-None-Match") {
		if strings.TrimSpace(line) == "*" || etagListMatches(line, etag) {
			return true
		}
	}
	return false
}

// etagListMatches reports whether any entity-tag in the comma-separated list
// matches etag.
func etagListMatches(list, etag string) bool {
	for _, tag := range splitETagList(list) {
		tag = strings.Trim(tag, " \t")
		if etagMatches(tag, etag) {
			return true
		}
	}
	return false
}

// splitETagList splits list on commas that are outside quoted strings, since
// an entity-tag may contain a comma.
func splitETagList(list string) []string {
	var tags []string
	inQuotes := false
	start := 0
	for i := 0; i < len(list); i++ {
		switch list[i] {
		case '"':
			inQuotes = !inQuotes
		case ',':
			if !inQuotes {
				tags = append(tags, list[start:i])
				start = i + 1
			}
		}
	}
	return append(tags, list[start:])
}

// etagMatches reports whether the entity-tag tag matches etag with weak
// comparison. Both may have a W/ prefix, which is ignored. The opaque tags
// must be identical byte for byte and tag must be a well-formed opaque tag.
func etagMatches(tag, etag string) bool {
	tag = strings.TrimPrefix(tag, "W/")
	etag = strings.TrimPrefix(etag, "W/")
	return isOpaqueTag(tag) && tag == etag
}

// isOpaqueTag reports whether s is a quoted string of etagc characters
// (RFC 9110 §8.8.3). Space, DQUOTE and control characters are not allowed.
func isOpaqueTag(s string) bool {
	if len(s) < 2 || s[0] != '"' || s[len(s)-1] != '"' {
		return false
	}
	for i := 1; i < len(s)-1; i++ {
		c := s[i]
		if c == '!' || (c >= '#' && c <= '~') || c >= 0x80 {
			continue
		}
		return false
	}
	return true
}

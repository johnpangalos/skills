package middleware

import (
	"bufio"
	"bytes"
	"crypto/sha256"
	"encoding/hex"
	"errors"
	"net"
	"net/http"
	"strings"
)

// ETag is a middleware that buffers the body of GET and HEAD responses with a
// 200 status and adds a strong ETag derived from that body when the handler has
// not set one. When If-None-Match matches the response's ETag, a 304 Not Modified
// is sent instead. The whole body is held in memory until the handler returns, so
// avoid wrapping handlers that stream large bodies. Calling Flush or Hijack stops
// buffering: the response is sent as it is, without a computed ETag.
func ETag(next http.Handler) http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		if r.Method != http.MethodGet && r.Method != http.MethodHead {
			next.ServeHTTP(w, r)
			return
		}
		ew := &etagResponseWriter{ResponseWriter: w, status: http.StatusOK}
		next.ServeHTTP(ew, r)
		ew.finish(r)
	})
}

type etagResponseWriter struct {
	http.ResponseWriter

	buf         bytes.Buffer
	status      int
	wroteHeader bool
	committed   bool
}

func (ew *etagResponseWriter) WriteHeader(code int) {
	// Informational responses are sent as they come and do not set the final status.
	if code >= 100 && code <= 199 && code != http.StatusSwitchingProtocols {
		ew.ResponseWriter.WriteHeader(code)
		return
	}
	if ew.wroteHeader {
		return
	}
	ew.wroteHeader = true
	ew.status = code
	// Only a 200 body can be tagged, so any other status is sent right away.
	if code != http.StatusOK {
		ew.commit()
	}
}

func (ew *etagResponseWriter) Write(p []byte) (int, error) {
	ew.WriteHeader(http.StatusOK)
	if ew.committed {
		return ew.ResponseWriter.Write(p)
	}
	return ew.buf.Write(p)
}

func (ew *etagResponseWriter) Flush() {
	ew.WriteHeader(http.StatusOK)
	ew.commit()
	if f, ok := ew.ResponseWriter.(http.Flusher); ok {
		f.Flush()
	}
}

func (ew *etagResponseWriter) Hijack() (net.Conn, *bufio.ReadWriter, error) {
	hj, ok := ew.ResponseWriter.(http.Hijacker)
	if !ok {
		return nil, nil, errors.New("chi/middleware: http.Hijacker is unavailable on the writer")
	}
	// Send the status and headers the handler already wrote before the connection
	// is taken over, as net/http does. Like net/http, unflushed body bytes are dropped.
	if ew.wroteHeader {
		ew.commit()
	}
	conn, rw, err := hj.Hijack()
	if err == nil {
		ew.committed = true
	}
	return conn, rw, err
}

func (ew *etagResponseWriter) Push(target string, opts *http.PushOptions) error {
	if ps, ok := ew.ResponseWriter.(http.Pusher); ok {
		return ps.Push(target, opts)
	}
	return errors.New("chi/middleware: http.Pusher is unavailable on the writer")
}

func (ew *etagResponseWriter) Unwrap() http.ResponseWriter {
	return ew.ResponseWriter
}

// commit sends the status and any buffered body to the underlying writer. Writes
// after it go straight through.
func (ew *etagResponseWriter) commit() {
	if ew.committed {
		return
	}
	ew.committed = true
	ew.ResponseWriter.WriteHeader(ew.status)
	if ew.buf.Len() > 0 {
		ew.ResponseWriter.Write(ew.buf.Bytes())
	}
	ew.buf.Reset()
}

// finish sends the buffered response once the handler has returned. It adds a
// computed ETag when the body can be tagged, and answers 304 when If-None-Match
// matches. A response that was already committed is left alone.
func (ew *etagResponseWriter) finish(r *http.Request) {
	if ew.committed {
		return
	}
	h := ew.Header()
	body := ew.buf.Bytes()
	if h.Get("ETag") == "" && !declaresUnwrittenBody(h, body) {
		h.Set("ETag", bodyETag(body))
	}
	if etagMatches(r.Header.Values("If-None-Match"), h.Get("ETag")) {
		ew.status = http.StatusNotModified
		ew.buf.Reset()
		h.Del("Content-Type")
		h.Del("Content-Length")
		h.Del("Content-Encoding")
	}
	ew.commit()
}

// declaresUnwrittenBody reports whether the response declares a non-zero
// Content-Length but the handler wrote no body, as a HEAD handler may do. Hashing
// the empty buffer would tag a body that was never sent.
func declaresUnwrittenBody(h http.Header, body []byte) bool {
	length := h.Get("Content-Length")
	return len(body) == 0 && length != "" && length != "0"
}

// bodyETag returns a strong entity-tag made from the first 16 bytes of the
// SHA-256 digest of body, hex-encoded.
func bodyETag(body []byte) string {
	sum := sha256.Sum256(body)
	return `"` + hex.EncodeToString(sum[:16]) + `"`
}

// etagMatches reports whether If-None-Match matches an entity with the given
// ETag, using weak comparison as RFC 9110 section 13.1.2 requires. A value of "*"
// matches any representation.
func etagMatches(ifNoneMatch []string, etag string) bool {
	for _, value := range ifNoneMatch {
		if strings.Trim(value, " \t") == "*" {
			return true
		}
	}
	want, ok := opaqueTag(etag)
	if !ok {
		return false
	}
	for _, value := range ifNoneMatch {
		for _, member := range splitETags(value) {
			if got, ok := opaqueTag(strings.Trim(member, " \t")); ok && got == want {
				return true
			}
		}
	}
	return false
}

// splitETags splits a header value on the commas that are outside quoted strings,
// so that a comma inside an entity-tag does not start a new one.
func splitETags(value string) []string {
	var tags []string
	start := 0
	inQuotes := false
	for i := 0; i < len(value); i++ {
		switch value[i] {
		case '"':
			inQuotes = !inQuotes
		case ',':
			if !inQuotes {
				tags = append(tags, value[start:i])
				start = i + 1
			}
		}
	}
	return append(tags, value[start:])
}

// opaqueTag removes the optional weak prefix from an entity-tag and returns the
// quoted opaque-tag. It reports false when s is not a well-formed entity-tag.
func opaqueTag(s string) (string, bool) {
	s = strings.TrimPrefix(s, "W/")
	if len(s) < 2 || s[0] != '"' || s[len(s)-1] != '"' {
		return "", false
	}
	for i := 1; i < len(s)-1; i++ {
		// etagc is %x21 / %x23-7E / obs-text, so a double quote may not appear inside.
		c := s[i]
		if c != 0x21 && (c < 0x23 || c > 0x7e) && c < 0x80 {
			return "", false
		}
	}
	return s, true
}

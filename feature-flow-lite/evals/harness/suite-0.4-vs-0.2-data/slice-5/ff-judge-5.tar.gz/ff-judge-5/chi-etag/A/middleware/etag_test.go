package middleware

import (
	"bufio"
	"crypto/sha256"
	"encoding/hex"
	"errors"
	"net"
	"net/http"
	"net/http/httptest"
	"reflect"
	"strings"
	"testing"
)

func etagOf(body string) string {
	sum := sha256.Sum256([]byte(body))
	return `"` + hex.EncodeToString(sum[:]) + `"`
}

func serveETag(h http.HandlerFunc, method string, ifNoneMatch ...string) *httptest.ResponseRecorder {
	req := httptest.NewRequest(method, "/", nil)
	for _, v := range ifNoneMatch {
		req.Header.Add("If-None-Match", v)
	}
	rec := httptest.NewRecorder()
	ETag(h).ServeHTTP(rec, req)
	return rec
}

func writeBody(body string) http.HandlerFunc {
	return func(w http.ResponseWriter, _ *http.Request) {
		w.Write([]byte(body))
	}
}

func TestETagGeneratesStrongTag(t *testing.T) {
	rec := serveETag(writeBody("hello"), http.MethodGet)
	if rec.Code != http.StatusOK || rec.Body.String() != "hello" {
		t.Fatalf("got %d %q, want 200 \"hello\"", rec.Code, rec.Body.String())
	}
	if got := rec.Header().Get("ETag"); got != etagOf("hello") {
		t.Errorf("ETag = %q, want %q", got, etagOf("hello"))
	}

	again := serveETag(writeBody("hello"), http.MethodGet)
	other := serveETag(writeBody("world"), http.MethodGet)
	if again.Header().Get("ETag") != rec.Header().Get("ETag") {
		t.Error("identical bodies produced different ETags")
	}
	if other.Header().Get("ETag") == rec.Header().Get("ETag") {
		t.Error("different bodies produced the same ETag")
	}
}

func TestETagExplicitAndEmptyResponses(t *testing.T) {
	explicit := serveETag(func(w http.ResponseWriter, _ *http.Request) {
		w.WriteHeader(http.StatusOK)
		w.Write([]byte("x"))
	}, http.MethodGet)
	if got := explicit.Header().Get("ETag"); got != etagOf("x") {
		t.Errorf("explicit 200 ETag = %q, want %q", got, etagOf("x"))
	}

	empty := serveETag(func(http.ResponseWriter, *http.Request) {}, http.MethodGet)
	if empty.Code != http.StatusOK || empty.Body.Len() != 0 {
		t.Fatalf("got %d with %d body bytes, want 200 empty", empty.Code, empty.Body.Len())
	}
	if got := empty.Header().Get("ETag"); got != etagOf("") {
		t.Errorf("empty body ETag = %q, want %q", got, etagOf(""))
	}

	head := serveETag(writeBody("hello"), http.MethodHead)
	if got := head.Header().Get("ETag"); got != etagOf("hello") {
		t.Errorf("HEAD ETag = %q, want %q", got, etagOf("hello"))
	}
}

func TestETagHEADWithoutBodyGetsNoGeneratedTag(t *testing.T) {
	headEmpty := serveETag(func(http.ResponseWriter, *http.Request) {}, http.MethodHead)
	if got, ok := headEmpty.Header()["Etag"]; ok {
		t.Errorf("HEAD without body got ETag %q, want none", got)
	}

	// Same as FileServer HEAD: the empty-body tag must not match.
	rec := serveETag(func(http.ResponseWriter, *http.Request) {}, http.MethodHead, etagOf(""))
	if rec.Code != http.StatusOK {
		t.Errorf("HEAD If-None-Match of empty-body tag: status = %d, want 200", rec.Code)
	}

	handlerTag := serveETag(func(w http.ResponseWriter, _ *http.Request) {
		w.Header().Set("ETag", `"mine"`)
	}, http.MethodHead, `"mine"`)
	if handlerTag.Code != http.StatusNotModified {
		t.Errorf("HEAD handler-set ETag: status = %d, want 304", handlerTag.Code)
	}
}

func TestETagHandlerSetTagKept(t *testing.T) {
	for _, tag := range []string{`"mine"`, `W/"weak"`} {
		rec := serveETag(func(w http.ResponseWriter, _ *http.Request) {
			w.Header().Set("ETag", tag)
			w.Write([]byte("body"))
		}, http.MethodGet)
		if got := rec.Header().Get("ETag"); got != tag {
			t.Errorf("ETag = %q, want handler value %q", got, tag)
		}
	}
}

func TestETagBuffersUntilHandlerReturns(t *testing.T) {
	rec := httptest.NewRecorder()
	ETag(http.HandlerFunc(func(w http.ResponseWriter, _ *http.Request) {
		w.Header().Set("X-Early", "1")
		w.WriteHeader(http.StatusOK)
		w.Write([]byte("part1"))
		w.(http.Flusher).Flush()
		if rec.Flushed || rec.Body.Len() != 0 {
			t.Errorf("response leaked before handler returned: flushed=%v body=%q", rec.Flushed, rec.Body.String())
		}
		w.Header().Set("X-Late", "1")
		w.Write([]byte("part2"))
	})).ServeHTTP(rec, httptest.NewRequest(http.MethodGet, "/", nil))
	if rec.Body.String() != "part1part2" {
		t.Errorf("body = %q, want %q", rec.Body.String(), "part1part2")
	}
	if rec.Header().Get("X-Late") != "" {
		t.Error("header set after WriteHeader reached the client")
	}
}

func TestETagManySmallChunksAndLargeBody(t *testing.T) {
	large := strings.Repeat("abcdefgh", 1<<17)
	rec := serveETag(func(w http.ResponseWriter, _ *http.Request) {
		for i := 0; i < len(large); i++ {
			w.Write([]byte{large[i]})
		}
	}, http.MethodGet)
	if rec.Body.String() != large {
		t.Fatalf("body length = %d, want %d", rec.Body.Len(), len(large))
	}
	if got := rec.Header().Get("ETag"); got != etagOf(large) {
		t.Errorf("ETag mismatch for large body")
	}
}

func TestETagIfNoneMatch(t *testing.T) {
	tag := etagOf("hello")
	tests := []struct {
		name string
		inm  []string
		want int
	}{
		{"strong match", []string{tag}, http.StatusNotModified},
		{"weak request matches strong", []string{"W/" + tag}, http.StatusNotModified},
		{"list with whitespace", []string{`"x", W/` + tag + ` ,"y"`}, http.StatusNotModified},
		{"star matches any", []string{"*"}, http.StatusNotModified},
		{"multiple header lines", []string{`"x"`, tag}, http.StatusNotModified},
		{"no match", []string{`"x"`}, http.StatusOK},
		{"unquoted member", []string{"abc"}, http.StatusOK},
		{"unterminated quote", []string{`"` + tag[1:len(tag)-1]}, http.StatusOK},
		{"empty members", []string{",,"}, http.StatusOK},
		{"bare weak prefix", []string{"W/"}, http.StatusOK},
		{"lowercase weak prefix", []string{"w/" + tag}, http.StatusOK},
		{"malformed then match", []string{`abc, ,` + tag}, http.StatusNotModified},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			rec := serveETag(writeBody("hello"), http.MethodGet, tt.inm...)
			if rec.Code != tt.want {
				t.Fatalf("status = %d, want %d", rec.Code, tt.want)
			}
		})
	}
}

func TestETagCommaInsideQuotes(t *testing.T) {
	handler := func(w http.ResponseWriter, _ *http.Request) {
		w.Header().Set("ETag", `"a,b"`)
		w.Write([]byte("body"))
	}
	if rec := serveETag(handler, http.MethodGet, `"a,b"`); rec.Code != http.StatusNotModified {
		t.Errorf(`"a,b" status = %d, want 304`, rec.Code)
	}
	if rec := serveETag(handler, http.MethodGet, `"a", "b"`); rec.Code != http.StatusOK {
		t.Errorf(`"a", "b" status = %d, want 200`, rec.Code)
	}
}

func TestETagNotModifiedHeaders(t *testing.T) {
	rec := serveETag(func(w http.ResponseWriter, _ *http.Request) {
		w.Header().Set("Cache-Control", "max-age=60")
		w.Header().Set("Vary", "Accept")
		w.Header().Set("Content-Type", "text/plain")
		w.Header().Set("Content-Length", "5")
		w.Write([]byte("hello"))
	}, http.MethodGet, etagOf("hello"))
	if rec.Code != http.StatusNotModified || rec.Body.Len() != 0 {
		t.Fatalf("got %d with %d body bytes, want 304 empty", rec.Code, rec.Body.Len())
	}
	if rec.Header().Get("ETag") != etagOf("hello") || rec.Header().Get("Cache-Control") != "max-age=60" || rec.Header().Get("Vary") != "Accept" {
		t.Errorf("validator headers not kept: %v", rec.Header())
	}
	for _, h := range []string{"Content-Length", "Content-Type", "Transfer-Encoding"} {
		if _, ok := rec.Header()[h]; ok {
			t.Errorf("%s should be removed on 304", h)
		}
	}
}

func TestETagHEADNotModified(t *testing.T) {
	rec := serveETag(writeBody("hello"), http.MethodHead, etagOf("hello"))
	if rec.Code != http.StatusNotModified {
		t.Errorf("HEAD status = %d, want 304", rec.Code)
	}
}

func TestETagWithNoCacheInside(t *testing.T) {
	const noCache = "no-cache, no-store, no-transform, must-revalidate, private, max-age=0"
	req := httptest.NewRequest(http.MethodGet, "/", nil)
	req.Header.Set("If-None-Match", etagOf("hello"))
	rec := httptest.NewRecorder()
	ETag(NoCache(writeBody("hello"))).ServeHTTP(rec, req)
	if rec.Code != http.StatusNotModified || rec.Body.Len() != 0 {
		t.Errorf("ETag(NoCache) status = %d with %d body bytes, want 304 empty", rec.Code, rec.Body.Len())
	}
	if rec.Header().Get("Cache-Control") != noCache {
		t.Errorf("Cache-Control = %q, want NoCache value kept", rec.Header().Get("Cache-Control"))
	}

	req = httptest.NewRequest(http.MethodGet, "/", nil)
	req.Header.Set("If-None-Match", etagOf("hello"))
	rec = httptest.NewRecorder()
	NoCache(ETag(writeBody("hello"))).ServeHTTP(rec, req)
	if rec.Code != http.StatusOK || rec.Body.String() != "hello" {
		t.Errorf("NoCache(ETag) status = %d, want 200 with body", rec.Code)
	}
}

func TestETagNonGetHeadPassesThrough(t *testing.T) {
	rec := httptest.NewRecorder()
	req := httptest.NewRequest(http.MethodPost, "/", nil)
	req.Header.Set("If-None-Match", etagOf("part1part2"))
	ETag(http.HandlerFunc(func(w http.ResponseWriter, _ *http.Request) {
		w.Write([]byte("part1"))
		w.(http.Flusher).Flush()
		if !rec.Flushed {
			t.Error("Flush did not reach the client for POST")
		}
		w.Write([]byte("part2"))
	})).ServeHTTP(rec, req)
	if rec.Code != http.StatusOK || rec.Body.String() != "part1part2" {
		t.Errorf("got %d %q, want 200 unchanged body", rec.Code, rec.Body.String())
	}
	if rec.Header().Get("ETag") != "" {
		t.Errorf("ETag added to POST response: %q", rec.Header().Get("ETag"))
	}
}

func TestETagNon200PassesThrough(t *testing.T) {
	statuses := []int{
		http.StatusCreated,
		http.StatusNoContent,
		http.StatusPartialContent,
		http.StatusMovedPermanently,
		http.StatusNotFound,
		http.StatusInternalServerError,
		http.StatusNotModified,
	}
	for _, status := range statuses {
		t.Run(http.StatusText(status), func(t *testing.T) {
			rec := serveETag(func(w http.ResponseWriter, _ *http.Request) {
				w.Header().Set("X-Custom", "1")
				w.WriteHeader(status)
				if status != http.StatusNoContent && status != http.StatusNotModified {
					w.Write([]byte("body"))
				}
			}, http.MethodGet, "*")
			if rec.Code != status {
				t.Errorf("status = %d, want %d", rec.Code, status)
			}
			if rec.Header().Get("X-Custom") != "1" {
				t.Error("handler header dropped")
			}
			if rec.Header().Get("ETag") != "" {
				t.Errorf("ETag added to %d response", status)
			}
		})
	}
}

// etagInfoRecorder records informational 1xx statuses instead of committing them,
// since httptest.ResponseRecorder would treat them as the final status.
type etagInfoRecorder struct {
	*httptest.ResponseRecorder
	informational []int
}

func (i *etagInfoRecorder) WriteHeader(code int) {
	if code >= 100 && code < 200 {
		i.informational = append(i.informational, code)
		return
	}
	i.ResponseRecorder.WriteHeader(code)
}

func TestETagInformationalForwarded(t *testing.T) {
	handler := func(w http.ResponseWriter, _ *http.Request) {
		w.WriteHeader(http.StatusEarlyHints)
		w.Header().Set("Content-Type", "text/plain")
		w.Header().Set("Cache-Control", "max-age=60")
		w.WriteHeader(http.StatusOK)
		w.Write([]byte("hello"))
	}

	under := &etagInfoRecorder{ResponseRecorder: httptest.NewRecorder()}
	ETag(http.HandlerFunc(handler)).ServeHTTP(under, httptest.NewRequest(http.MethodGet, "/", nil))
	if !reflect.DeepEqual(under.informational, []int{http.StatusEarlyHints}) {
		t.Errorf("informational = %v, want [103]", under.informational)
	}
	if under.Code != http.StatusOK || under.Body.String() != "hello" {
		t.Errorf("got %d %q, want 200 \"hello\"", under.Code, under.Body.String())
	}
	if under.Header().Get("Content-Type") != "text/plain" || under.Header().Get("Cache-Control") != "max-age=60" {
		t.Errorf("headers set around 1xx lost: %v", under.Header())
	}
	if under.Header().Get("ETag") != etagOf("hello") {
		t.Errorf("ETag = %q, want %q", under.Header().Get("ETag"), etagOf("hello"))
	}

	under = &etagInfoRecorder{ResponseRecorder: httptest.NewRecorder()}
	req := httptest.NewRequest(http.MethodGet, "/", nil)
	req.Header.Set("If-None-Match", "*")
	ETag(http.HandlerFunc(handler)).ServeHTTP(under, req)
	if under.Code != http.StatusNotModified {
		t.Errorf("If-None-Match * after 1xx: status = %d, want 304", under.Code)
	}
}

func TestETagTrailersMatchWithoutMiddleware(t *testing.T) {
	handlers := map[string]http.HandlerFunc{
		"set after write": func(w http.ResponseWriter, _ *http.Request) {
			w.Header().Set("Trailer", "X-Sum")
			w.Write([]byte("body"))
			w.Header().Set("X-Sum", "abc")
			w.Header().Set(http.TrailerPrefix+"X-Late", "zz")
		},
		"set before WriteHeader": func(w http.ResponseWriter, _ *http.Request) {
			w.Header().Set("Trailer", "X-Sum")
			w.Header().Set("X-Sum", "pre")
			w.WriteHeader(http.StatusNotFound)
			w.Write([]byte("body"))
			w.Header().Set("X-Sum", "post")
		},
	}
	for name, handler := range handlers {
		t.Run(name, func(t *testing.T) {
			// Content-Type is preset so the recorder does not sniff it differently
			// with and without the middleware. The middleware's own ETag is dropped.
			plain := httptest.NewRecorder()
			plain.Header().Set("Content-Type", "text/plain; charset=utf-8")
			handler.ServeHTTP(plain, httptest.NewRequest(http.MethodGet, "/", nil))
			wrapped := httptest.NewRecorder()
			wrapped.Header().Set("Content-Type", "text/plain; charset=utf-8")
			ETag(handler).ServeHTTP(wrapped, httptest.NewRequest(http.MethodGet, "/", nil))

			want, got := plain.Result(), wrapped.Result()
			got.Header.Del("ETag")
			if got.StatusCode != want.StatusCode {
				t.Errorf("status = %d, want %d", got.StatusCode, want.StatusCode)
			}
			if !reflect.DeepEqual(got.Header, want.Header) {
				t.Errorf("header = %v, want %v", got.Header, want.Header)
			}
			if !reflect.DeepEqual(got.Trailer, want.Trailer) {
				t.Errorf("trailers = %v, want %v", got.Trailer, want.Trailer)
			}
		})
	}
}

func TestETagWrapperCapabilities(t *testing.T) {
	t.Run("unwrap", func(t *testing.T) {
		rec := httptest.NewRecorder()
		ew := &etagResponseWriter{ResponseWriter: rec}
		if ew.Unwrap() != rec {
			t.Error("Unwrap did not return the underlying writer")
		}
	})

	t.Run("hijack unsupported", func(t *testing.T) {
		ew := &etagResponseWriter{ResponseWriter: httptest.NewRecorder()}
		_, _, err := ew.Hijack()
		if err == nil || err.Error() != "chi/middleware: http.Hijacker is unavailable on the writer" {
			t.Errorf("Hijack error = %v", err)
		}
	})

	t.Run("hijack forwarded and later writes rejected", func(t *testing.T) {
		under := &etagHijackRecorder{ResponseRecorder: httptest.NewRecorder()}
		var writeErr error
		ETag(http.HandlerFunc(func(w http.ResponseWriter, _ *http.Request) {
			if _, _, err := w.(http.Hijacker).Hijack(); err != nil {
				t.Errorf("Hijack: %v", err)
			}
			_, writeErr = w.Write([]byte("late"))
		})).ServeHTTP(under, httptest.NewRequest(http.MethodGet, "/", nil))
		if !under.hijacked {
			t.Error("Hijack was not forwarded")
		}
		if !errors.Is(writeErr, http.ErrHijacked) {
			t.Errorf("Write after Hijack error = %v, want http.ErrHijacked", writeErr)
		}
		if under.Body.Len() != 0 {
			t.Errorf("body written after Hijack: %q", under.Body.String())
		}
	})

	t.Run("push unsupported", func(t *testing.T) {
		ew := &etagResponseWriter{ResponseWriter: httptest.NewRecorder()}
		if err := ew.Push("/x", nil); !errors.Is(err, http.ErrNotSupported) {
			t.Errorf("Push error = %v, want http.ErrNotSupported", err)
		}
	})

	t.Run("push forwarded", func(t *testing.T) {
		under := &etagPushRecorder{ResponseRecorder: httptest.NewRecorder()}
		ETag(http.HandlerFunc(func(w http.ResponseWriter, _ *http.Request) {
			w.(http.Pusher).Push("/style.css", nil)
		})).ServeHTTP(under, httptest.NewRequest(http.MethodGet, "/", nil))
		if under.pushed != "/style.css" {
			t.Errorf("pushed = %q, want /style.css", under.pushed)
		}
	})
}

type etagHijackRecorder struct {
	*httptest.ResponseRecorder
	hijacked bool
}

func (h *etagHijackRecorder) Hijack() (net.Conn, *bufio.ReadWriter, error) {
	h.hijacked = true
	return nil, nil, nil
}

type etagPushRecorder struct {
	*httptest.ResponseRecorder
	pushed string
}

func (p *etagPushRecorder) Push(target string, _ *http.PushOptions) error {
	p.pushed = target
	return nil
}

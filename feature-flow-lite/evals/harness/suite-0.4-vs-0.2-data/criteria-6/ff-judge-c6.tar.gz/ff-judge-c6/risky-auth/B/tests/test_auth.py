import threading
import time
import unittest
from unittest.mock import patch

from shop.auth import (
    InvalidToken,
    TokenExpired,
    TokenUsed,
    issue_reset_token,
    redeem_reset_token,
)


class ResetTokenTest(unittest.TestCase):
    def test_round_trip(self):
        token = issue_reset_token("ada")
        self.assertEqual(redeem_reset_token(token), "ada")

    def test_unknown_token(self):
        with self.assertRaises(InvalidToken):
            redeem_reset_token("not-a-token")

    def test_unknown_token_is_plain_invalid_token(self):
        for bad in ("", None):
            with self.subTest(token=bad):
                with self.assertRaises(InvalidToken) as cm:
                    redeem_reset_token(bad)
                self.assertIs(type(cm.exception), InvalidToken)
                self.assertEqual(str(cm.exception), "unknown token")

    def test_exactly_ttl_is_still_valid(self):
        token = issue_reset_token("ada", now=1000)
        self.assertEqual(redeem_reset_token(token, now=1000 + 1800), "ada")

    def test_past_ttl_is_expired(self):
        for elapsed in (1800.5, 1801):
            with self.subTest(elapsed=elapsed):
                token = issue_reset_token("ada", now=1000)
                with self.assertRaises(TokenExpired) as cm:
                    redeem_reset_token(token, now=1000 + elapsed)
                self.assertIs(type(cm.exception), TokenExpired)
                self.assertEqual(str(cm.exception), "token expired")

    def test_second_redeem_is_token_used(self):
        token = issue_reset_token("ada", now=1000)
        redeem_reset_token(token, now=1000)
        with self.assertRaises(TokenUsed) as cm:
            redeem_reset_token(token, now=1000)
        self.assertIs(type(cm.exception), TokenUsed)
        self.assertEqual(str(cm.exception), "token already used")

    def test_used_takes_precedence_over_expiry(self):
        token = issue_reset_token("ada", now=1000)
        redeem_reset_token(token, now=1000)
        with self.assertRaises(TokenUsed):
            redeem_reset_token(token, now=1000 + 5000)

    def test_failed_expired_redeem_does_not_consume_token(self):
        token = issue_reset_token("ada", now=1000)
        for _ in range(2):
            with self.assertRaises(TokenExpired):
                redeem_reset_token(token, now=1000 + 1801)

    def test_clock_skew_is_valid(self):
        token = issue_reset_token("ada", now=1000)
        self.assertEqual(redeem_reset_token(token, now=500), "ada")

    def test_float_timestamps(self):
        token = issue_reset_token("ada", now=0.5)
        self.assertEqual(redeem_reset_token(token, now=1800.5), "ada")

    def test_now_zero_is_a_real_timestamp(self):
        token = issue_reset_token("ada", now=0)
        self.assertEqual(redeem_reset_token(token, now=0), "ada")
        other = issue_reset_token("ada", now=0)
        with self.assertRaises(TokenExpired):
            redeem_reset_token(other, now=1801)

    def test_default_now_reads_clock_at_call_time(self):
        with patch("shop.auth.time") as fake_clock:
            fake_clock.time.return_value = 5000.0
            token = issue_reset_token("ada")
            fake_clock.time.return_value = 6801.0
            with self.assertRaises(TokenExpired):
                redeem_reset_token(token)

    def test_error_types_are_invalid_token(self):
        self.assertTrue(issubclass(TokenExpired, InvalidToken))
        self.assertTrue(issubclass(TokenUsed, InvalidToken))

    def test_concurrent_redeem_succeeds_exactly_once(self):
        class SlowSet(set):
            # Widen the gap between "is it used?" and "mark it used".
            def __contains__(self, item):
                found = super().__contains__(item)
                time.sleep(0.01)
                return found

        threads = 8
        token = issue_reset_token("ada", now=1000)
        start = threading.Barrier(threads)
        results = []

        def redeem():
            start.wait()
            try:
                results.append(redeem_reset_token(token, now=1000))
            except TokenUsed:
                results.append("used")

        workers = [threading.Thread(target=redeem) for _ in range(threads)]
        with patch("shop.auth._USED", SlowSet()):
            for worker in workers:
                worker.start()
            for worker in workers:
                worker.join()
        self.assertEqual(results.count("ada"), 1)
        self.assertEqual(results.count("used"), threads - 1)

import unittest
from unittest import mock

from shop.auth import (
    InvalidToken,
    TokenExpired,
    TokenUsed,
    issue_reset_token,
    redeem_reset_token,
)


class ResetTokenTest(unittest.TestCase):
    def test_round_trip(self):
        token = issue_reset_token("ada")
        self.assertEqual(redeem_reset_token(token), "ada")

    def test_unknown_token(self):
        with self.assertRaises(InvalidToken):
            redeem_reset_token("not-a-token")

    def test_round_trip_with_injected_now(self):
        token = issue_reset_token("ada", now=100)
        self.assertEqual(redeem_reset_token(token, now=101), "ada")

    def test_default_now_uses_time_time(self):
        with mock.patch("shop.auth.time.time", return_value=1000.0):
            token = issue_reset_token("ada")
        with mock.patch("shop.auth.time.time", return_value=1000.0 + 1801):
            with self.assertRaises(TokenExpired):
                redeem_reset_token(token)

    def test_exactly_1800_seconds_is_valid(self):
        token = issue_reset_token("ada", now=1000)
        self.assertEqual(redeem_reset_token(token, now=2800), "ada")

    def test_1800_0001_seconds_expires(self):
        token = issue_reset_token("ada", now=1000)
        with self.assertRaises(TokenExpired) as cm:
            redeem_reset_token(token, now=1000 + 1800.0001)
        self.assertEqual(str(cm.exception), "token expired")

    def test_float_timestamps(self):
        token = issue_reset_token("ada", now=1000.5)
        self.assertEqual(redeem_reset_token(token, now=1000.75), "ada")

    def test_now_zero_is_used_as_given(self):
        token = issue_reset_token("ada", now=0)
        with self.assertRaises(TokenExpired):
            redeem_reset_token(token, now=1801)

    def test_now_zero_redeem_is_valid_when_issued_at_zero(self):
        token = issue_reset_token("ada", now=0)
        self.assertEqual(redeem_reset_token(token, now=0), "ada")

    def test_reuse_raises_token_used(self):
        token = issue_reset_token("ada", now=100)
        self.assertEqual(redeem_reset_token(token, now=101), "ada")
        with self.assertRaises(TokenUsed) as cm:
            redeem_reset_token(token, now=102)
        self.assertEqual(str(cm.exception), "token already used")

    def test_used_is_checked_before_expiry(self):
        token = issue_reset_token("ada", now=100)
        redeem_reset_token(token, now=101)
        with self.assertRaises(TokenUsed):
            redeem_reset_token(token, now=100 + 5000)

    def test_expired_redemption_does_not_consume_token(self):
        token = issue_reset_token("ada", now=1000)
        with self.assertRaises(TokenExpired):
            redeem_reset_token(token, now=3000)
        with self.assertRaises(TokenExpired):
            redeem_reset_token(token, now=3001)

    def test_unknown_token_is_plain_invalid_token(self):
        for bad in ["", None, "not-a-token"]:
            with self.subTest(token=bad):
                with self.assertRaises(InvalidToken) as cm:
                    redeem_reset_token(bad)
                self.assertIs(type(cm.exception), InvalidToken)
                self.assertEqual(str(cm.exception), "unknown token")

    def test_expired_and_used_subclass_invalid_token(self):
        self.assertTrue(issubclass(TokenExpired, InvalidToken))
        self.assertTrue(issubclass(TokenUsed, InvalidToken))
        self.assertTrue(issubclass(InvalidToken, Exception))
        self.assertFalse(issubclass(InvalidToken, TokenExpired))
        self.assertFalse(issubclass(InvalidToken, TokenUsed))

    def test_second_token_does_not_affect_first(self):
        first = issue_reset_token("ada", now=1000)
        second = issue_reset_token("ada", now=2000)
        with self.assertRaises(TokenExpired):
            redeem_reset_token(first, now=2900)
        self.assertEqual(redeem_reset_token(second, now=2900), "ada")

    def test_clock_skew_before_issue_succeeds(self):
        token = issue_reset_token("ada", now=1000)
        self.assertEqual(redeem_reset_token(token, now=990), "ada")

    def test_exactly_1800_seconds_on_large_float_base_is_valid(self):
        issued = 15567.621338918869
        token = issue_reset_token("ada", now=issued)
        self.assertEqual(redeem_reset_token(token, now=issued + 1800), "ada")

"""Password-reset tokens (in-memory store)."""

import secrets
import threading
import time

RESET_TOKEN_TTL = 1800  # seconds

_TOKENS = {}  # token -> (username, issued_at)
_USED = set()  # tokens already redeemed
_LOCK = threading.Lock()  # guards check-then-mark in redeem_reset_token


class InvalidToken(Exception):
    pass


class TokenExpired(InvalidToken):
    pass


class TokenUsed(InvalidToken):
    pass


def issue_reset_token(username, now=None):
    """Create a reset token for username, issued at now (default: current time)."""
    if now is None:
        now = time.time()
    token = secrets.token_urlsafe(16)
    _TOKENS[token] = (username, now)
    return token


def redeem_reset_token(token, now=None):
    """Return the username for token and mark it used; raise TokenExpired, TokenUsed or InvalidToken."""
    if now is None:
        now = time.time()
    with _LOCK:
        entry = _TOKENS.get(token)
        if entry is None:
            raise InvalidToken("unknown token")
        if token in _USED:
            raise TokenUsed("token already used")
        username, issued_at = entry
        if now - issued_at > RESET_TOKEN_TTL:
            raise TokenExpired("token expired")
        _USED.add(token)
        return username

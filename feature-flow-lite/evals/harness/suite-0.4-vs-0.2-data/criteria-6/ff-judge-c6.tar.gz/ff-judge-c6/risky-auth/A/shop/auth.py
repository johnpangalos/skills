"""Password-reset tokens (in-memory store).

A token expires RESET_TTL seconds after it was issued and is single-use: the
first successful redemption consumes it. A redemption that fails because the
token expired does not consume it.
"""

import secrets
import time
from dataclasses import dataclass

RESET_TTL = 1800  # seconds a reset token stays valid after issue

_TOKENS = {}  # token -> _ResetToken


@dataclass
class _ResetToken:
    username: str
    issued_at: float
    used: bool = False


class InvalidToken(Exception):
    pass


class TokenExpired(InvalidToken):
    pass


class TokenUsed(InvalidToken):
    pass


def issue_reset_token(username, now=None):
    """Create a reset token for username, issued at `now` (default: time.time())."""
    if now is None:
        now = time.time()
    token = secrets.token_urlsafe(16)
    _TOKENS[token] = _ResetToken(username, now)
    return token


def redeem_reset_token(token, now=None):
    """Return the username a token was issued for and mark the token used.

    `now` defaults to time.time(). Raises InvalidToken for an unknown token,
    TokenUsed if it was already redeemed, and TokenExpired if more than
    RESET_TTL seconds have passed since issue. Only a successful redemption
    consumes the token.
    """
    if now is None:
        now = time.time()
    record = _TOKENS.get(token)
    if record is None:
        raise InvalidToken("unknown token")
    if record.used:
        raise TokenUsed("token already used")
    if now > record.issued_at + RESET_TTL:
        raise TokenExpired("token expired")
    record.used = True
    return record.username

"""Orders and idempotent refunds (in-memory store)."""

import itertools
from dataclasses import dataclass, field
from decimal import Decimal

from shop.money import to_cents

_ORDER_IDS = itertools.count(1)


class RefundError(ValueError):
    pass


@dataclass(frozen=True)
class Refund:
    order_id: int
    amount: Decimal
    key: str


@dataclass
class Order:
    id: int
    total: Decimal
    refunds: dict = field(default_factory=dict)  # key -> Refund

    def refunded(self):
        return to_cents(sum((r.amount for r in self.refunds.values()), Decimal("0")))

    def refundable(self):
        return self.total - self.refunded()


def place_order(cart):
    """Snapshot the cart's total into a new order."""
    if not cart.items:
        raise ValueError("cannot place an order for an empty cart")
    return Order(next(_ORDER_IDS), cart.total())


def _is_whole_cents(amount):
    # Exact and context-free: quantize() raises InvalidOperation for huge amounts.
    _, digits, exponent = amount.as_tuple()
    return exponent >= -2 or not any(digits[exponent + 2:])


def _check_amount(amount):
    if not isinstance(amount, Decimal) or not amount.is_finite():
        raise RefundError("amount must be a finite Decimal")
    if amount <= 0:
        raise RefundError("amount must be greater than zero")
    if not _is_whole_cents(amount):
        raise RefundError("amount must be a whole number of cents")


def refund(order, amount, key):
    """Refund amount against order; a repeated key returns the original refund."""
    _check_amount(amount)
    if key in order.refunds:
        previous = order.refunds[key]
        if amount != previous.amount:
            raise RefundError("key reused with a different amount")
        return previous
    if amount > order.refundable():
        raise RefundError("refund exceeds refundable amount")
    record = Refund(order.id, to_cents(amount), key)
    order.refunds[key] = record
    return record

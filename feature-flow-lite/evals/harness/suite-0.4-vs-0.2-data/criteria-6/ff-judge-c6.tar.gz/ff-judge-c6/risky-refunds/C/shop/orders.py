"""Orders with idempotent, capped refunds (in-memory store)."""

import itertools
import threading
from dataclasses import dataclass, field
from decimal import MAX_PREC, Context, Decimal, localcontext

_ORDER_IDS = itertools.count(1)
_REFUND_LOCK = threading.Lock()  # one refund() at a time, across all orders
_EXACT = Context(prec=MAX_PREC)  # sums stay exact whatever the caller's context


class RefundError(ValueError):
    pass


@dataclass(frozen=True)
class Refund:
    order_id: int
    amount: Decimal
    key: str


@dataclass
class Order:
    total: Decimal
    id: int = field(default_factory=lambda: next(_ORDER_IDS))
    refunds: dict = field(default_factory=dict)  # key -> Refund

    def refunded(self):
        with localcontext(_EXACT):
            return sum((r.amount for r in tuple(self.refunds.values())), Decimal("0.00"))

    def refundable(self):
        with localcontext(_EXACT):
            return self.total - self.refunded()


def place_order(cart):
    """Freeze the cart's current total into a new order."""
    if not cart.items:
        raise ValueError("cart is empty")
    return Order(total=cart.total())


def _is_whole_cents(amount):
    """True if amount (positive, finite) has no digits past the cent place.

    Works on the digit tuple, so huge exponents cannot raise InvalidOperation.
    """
    _, digits, exponent = amount.as_tuple()
    keep = max(len(digits) + exponent + 2, 0)  # digits up to the cent place
    return not any(digits[keep:])


def refund(order, amount, key):
    """Refund amount from order. A repeated key returns the original Refund."""
    if not isinstance(amount, Decimal) or not amount.is_finite():
        raise RefundError("amount must be a finite Decimal")
    if amount <= 0:
        raise RefundError("amount must be positive")
    if not _is_whole_cents(amount):
        raise RefundError("amount must be whole cents")
    with _REFUND_LOCK:
        previous = order.refunds.get(key)
        if previous is not None:
            if previous.amount != amount:
                raise RefundError("key already used for a different amount")
            return previous
        if amount > order.refundable():
            raise RefundError("refund exceeds refundable amount")
        record = Refund(order.id, amount, key)
        order.refunds[key] = record
        return record

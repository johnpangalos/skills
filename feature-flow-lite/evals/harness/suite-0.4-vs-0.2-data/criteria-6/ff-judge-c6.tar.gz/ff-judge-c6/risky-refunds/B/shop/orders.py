"""Orders placed from a cart, with idempotent partial refunds."""

import itertools
import threading
from dataclasses import dataclass, field
from decimal import Decimal, InvalidOperation

from shop.money import to_cents

_ORDER_IDS = itertools.count(1)
_LOCK = threading.Lock()  # serializes refund() so checks and records are atomic


class RefundError(ValueError):
    pass


@dataclass
class Refund:
    order_id: int
    amount: Decimal
    key: str


@dataclass
class Order:
    id: int
    total: Decimal
    refunds: dict = field(default_factory=dict)  # key -> Refund

    def refunded(self):
        return to_cents(sum((r.amount for r in list(self.refunds.values())), Decimal("0")))

    def refundable(self):
        return self.total - self.refunded()


def place_order(cart):
    """Snapshot the cart's total into a new Order."""
    if not cart.items:
        raise ValueError("cart is empty")
    return Order(next(_ORDER_IDS), cart.total())


def _check_amount(amount):
    """Return amount as a plain Decimal, or raise RefundError unless it is a positive, whole-cent value."""
    if not isinstance(amount, Decimal):
        raise RefundError("amount must be a positive, finite Decimal")
    # Copy to a plain Decimal so a subclass cannot override comparisons.
    amount = Decimal(amount)
    if not amount.is_finite() or amount <= 0:
        raise RefundError("amount must be a positive, finite Decimal")
    try:
        whole = amount == to_cents(amount)
    except InvalidOperation:
        whole = False
    if not whole:
        raise RefundError("amount must be in whole cents")
    return amount


def refund(order, amount, key):
    """Refund amount from order. Repeating a key returns the original Refund."""
    amount = _check_amount(amount)
    if not isinstance(key, str):
        raise RefundError("key must be a str")
    with _LOCK:
        previous = order.refunds.get(key)
        if previous is not None:
            if previous.amount != amount:
                raise RefundError("key already used for a different amount")
            return previous
        if amount > order.refundable():
            raise RefundError("refund exceeds refundable amount")
        record = Refund(order.id, amount, key)
        order.refunds[key] = record
        return record

import sys
import threading
import unittest
from dataclasses import FrozenInstanceError
from decimal import Decimal, localcontext

from shop.cart import Cart
from shop.orders import Order, Refund, RefundError, place_order, refund

TOTAL = Decimal("54.77")  # BEAN-ETH x2 + FILTER, see test_cart


def _order():
    cart = Cart()
    cart.add("BEAN-ETH", 2)
    cart.add("FILTER")
    return place_order(cart)


class PlaceOrderTest(unittest.TestCase):
    def test_total_matches_cart(self):
        cart = Cart()
        cart.add("BEAN-ETH", 2)
        cart.add("FILTER")
        order = place_order(cart)
        self.assertIsInstance(order, Order)
        self.assertIsInstance(order.total, Decimal)
        self.assertEqual(order.total, TOTAL)

    def test_empty_cart_raises(self):
        with self.assertRaises(ValueError) as ctx:
            place_order(Cart())
        self.assertEqual(str(ctx.exception), "cart is empty")

    def test_added_then_removed_cart_raises(self):
        cart = Cart()
        cart.add("FILTER")
        cart.remove("FILTER")
        with self.assertRaises(ValueError) as ctx:
            place_order(cart)
        self.assertEqual(str(ctx.exception), "cart is empty")

    def test_total_frozen_after_cart_changes(self):
        cart = Cart()
        cart.add("BEAN-ETH", 2)
        cart.add("FILTER")
        order = place_order(cart)
        cart.add("MUG", 3)
        cart.remove("BEAN-ETH")
        self.assertEqual(order.total, TOTAL)

    def test_ids_are_unique(self):
        cart = Cart()
        cart.add("FILTER")
        first = place_order(cart)
        second = place_order(cart)
        third = _order()
        self.assertNotEqual(first.id, second.id)
        self.assertNotEqual(first.id, third.id)
        self.assertNotEqual(second.id, third.id)


class OrderTotalsTest(unittest.TestCase):
    def test_nothing_refunded_yet(self):
        order = _order()
        self.assertEqual(order.refunded(), Decimal("0.00"))
        self.assertEqual(order.refundable(), TOTAL)

    def test_refundable_is_total_minus_refunded(self):
        order = _order()
        refund(order, Decimal("4.77"), "a")
        self.assertEqual(order.refunded(), Decimal("4.77"))
        self.assertEqual(order.refundable(), TOTAL - Decimal("4.77"))


class RefundValidationTest(unittest.TestCase):
    def assertRejected(self, order, amount, message):
        before = order.refunded()
        with self.assertRaises(RefundError) as ctx:
            refund(order, amount, "k")
        self.assertEqual(str(ctx.exception), message)
        self.assertEqual(order.refunded(), before)
        self.assertEqual(order.refunds, {})

    def test_non_decimal_types_rejected(self):
        order = _order()
        for bad in [5, 5.0, "5.00", True, None]:
            with self.subTest(amount=repr(bad)):
                self.assertRejected(order, bad, "amount must be a finite Decimal")

    def test_non_finite_rejected(self):
        order = _order()
        for bad in [Decimal("NaN"), Decimal("sNaN"), Decimal("Infinity"), Decimal("-Infinity")]:
            with self.subTest(amount=str(bad)):
                self.assertRejected(order, bad, "amount must be a finite Decimal")

    def test_non_positive_rejected(self):
        order = _order()
        for bad in [Decimal("0"), Decimal("0.00"), Decimal("-0"), Decimal("-1.00")]:
            with self.subTest(amount=str(bad)):
                self.assertRejected(order, bad, "amount must be positive")

    def test_fractional_cents_rejected(self):
        order = _order()
        for bad in [Decimal("0.001"), Decimal("1.005"), Decimal("1.234")]:
            with self.subTest(amount=str(bad)):
                self.assertRejected(order, bad, "amount must be whole cents")

    def test_whole_cents_accepted(self):
        order = _order()
        self.assertEqual(refund(order, Decimal("1.230"), "a").amount, Decimal("1.230"))

    def test_huge_values_rejected_as_over_refund(self):
        order = _order()
        for bad in [Decimal("1E+100"), Decimal("1E+1000000")]:
            with self.subTest(amount=str(bad)):
                self.assertRejected(order, bad, "refund exceeds refundable amount")


class RefundCapTest(unittest.TestCase):
    def test_refund_over_total_rejected(self):
        order = _order()
        with self.assertRaises(RefundError) as ctx:
            refund(order, TOTAL + Decimal("0.01"), "a")
        self.assertEqual(str(ctx.exception), "refund exceeds refundable amount")
        self.assertEqual(order.refunded(), Decimal("0.00"))
        self.assertEqual(order.refunds, {})

    def test_two_refunds_together_over_total_rejected(self):
        order = _order()
        refund(order, Decimal("30.00"), "a")
        with self.assertRaises(RefundError) as ctx:
            refund(order, Decimal("24.78"), "b")
        self.assertEqual(str(ctx.exception), "refund exceeds refundable amount")
        self.assertEqual(order.refunded(), Decimal("30.00"))
        self.assertNotIn("b", order.refunds)

    def test_rejected_key_can_be_reused_with_valid_amount(self):
        order = _order()
        with self.assertRaises(RefundError):
            refund(order, TOTAL + Decimal("0.01"), "a")
        record = refund(order, Decimal("10.00"), "a")
        self.assertEqual(record.amount, Decimal("10.00"))
        self.assertEqual(order.refunded(), Decimal("10.00"))

    def test_partial_then_remainder_exhausts_refundable(self):
        order = _order()
        refund(order, Decimal("10.00"), "a")
        refund(order, TOTAL - Decimal("10.00"), "b")
        self.assertEqual(order.refundable(), Decimal("0"))

    def test_full_refund_then_more_rejected(self):
        order = _order()
        refund(order, TOTAL, "a")
        self.assertEqual(order.refundable(), Decimal("0"))
        with self.assertRaises(RefundError) as ctx:
            refund(order, Decimal("0.01"), "b")
        self.assertEqual(str(ctx.exception), "refund exceeds refundable amount")
        self.assertEqual(order.refunded(), TOTAL)


class RefundIdempotencyTest(unittest.TestCase):
    def test_replay_returns_same_object_and_changes_nothing(self):
        order = _order()
        first = refund(order, Decimal("5"), "a")
        again = refund(order, Decimal("5.00"), "a")
        self.assertIs(again, first)
        self.assertEqual(order.refunded(), Decimal("5.00"))

    def test_replay_after_full_refund_returns_original(self):
        order = _order()
        first = refund(order, TOTAL, "a")
        again = refund(order, TOTAL, "a")
        self.assertIs(again, first)
        self.assertEqual(order.refunded(), TOTAL)

    def test_same_key_different_amount_rejected(self):
        order = _order()
        refund(order, Decimal("5.00"), "a")
        with self.assertRaises(RefundError) as ctx:
            refund(order, Decimal("6.00"), "a")
        self.assertEqual(str(ctx.exception), "key already used for a different amount")
        self.assertEqual(order.refunded(), Decimal("5.00"))
        self.assertEqual(order.refunds["a"].amount, Decimal("5.00"))

    def test_same_key_on_two_orders_is_independent(self):
        first_order = _order()
        second_order = _order()
        first = refund(first_order, Decimal("5.00"), "a")
        second = refund(second_order, Decimal("7.00"), "a")
        self.assertIsNot(first, second)
        self.assertEqual(second.order_id, second_order.id)
        self.assertEqual(first_order.refunded(), Decimal("5.00"))
        self.assertEqual(second_order.refunded(), Decimal("7.00"))


class RefundRecordTest(unittest.TestCase):
    def test_records_order_amount_and_key(self):
        order = _order()
        record = refund(order, Decimal("2.50"), "a")
        self.assertIsInstance(record, Refund)
        self.assertEqual(record.order_id, order.id)
        self.assertEqual(record.amount, Decimal("2.50"))
        self.assertEqual(record.key, "a")

    def test_refund_is_immutable(self):
        record = refund(_order(), Decimal("2.50"), "a")
        with self.assertRaises(FrozenInstanceError):
            record.amount = Decimal("9.99")


class LowPrecisionContextTest(unittest.TestCase):
    def test_refund_to_total_then_more_rejected_under_low_precision(self):
        order = _order()
        with localcontext() as low:
            low.prec = 3
            refund(order, TOTAL, "a")
            self.assertEqual(order.refundable(), Decimal("0"))
            with self.assertRaises(RefundError) as ctx:
                refund(order, Decimal("0.01"), "b")
        self.assertEqual(str(ctx.exception), "refund exceeds refundable amount")
        self.assertEqual(order.refunded(), TOTAL)
        self.assertEqual(order.refundable(), Decimal("0"))

    def test_over_total_rejected_under_low_precision(self):
        order = _order()
        with localcontext() as low:
            low.prec = 3
            with self.assertRaises(RefundError) as ctx:
                refund(order, Decimal("54.8"), "a")
        self.assertEqual(str(ctx.exception), "refund exceeds refundable amount")
        self.assertEqual(order.refunds, {})

    def test_sums_stay_exact_under_low_precision(self):
        order = _order()
        refund(order, Decimal("30.00"), "a")
        with localcontext() as low:
            low.prec = 3
            refund(order, Decimal("24.77"), "b")
            self.assertEqual(order.refunded(), TOTAL)
            self.assertEqual(order.refundable(), Decimal("0"))
        self.assertEqual(order.refunded(), TOTAL)


def _burst(work, count):
    """Run work(index) on count threads started together; return each result.

    An exception raised by work is returned in its slot instead.
    """
    barrier = threading.Barrier(count)
    results = [None] * count

    def run(index):
        barrier.wait()
        try:
            results[index] = work(index)
        except Exception as exc:
            results[index] = exc

    threads = [threading.Thread(target=run, args=(i,)) for i in range(count)]
    for thread in threads:
        thread.start()
    for thread in threads:
        thread.join()
    return results


class ConcurrentRefundTest(unittest.TestCase):
    def setUp(self):
        previous = sys.getswitchinterval()
        sys.setswitchinterval(1e-6)  # switch threads often to widen races
        self.addCleanup(sys.setswitchinterval, previous)

    def test_concurrent_refunds_never_pass_total(self):
        for _ in range(20):
            order = _order()

            def work(index):
                for _ in range(100):
                    order.refunded()  # reads while other threads insert
                return refund(order, Decimal("10.00"), f"k{index}")

            outcomes = _burst(work, 8)
            accepted = [o for o in outcomes if isinstance(o, Refund)]
            rejected = [o for o in outcomes if isinstance(o, RefundError)]
            self.assertEqual(len(accepted), 5)
            self.assertEqual(len(rejected), 3)
            self.assertEqual(order.refunded(), Decimal("50.00"))
            self.assertLessEqual(order.refunded(), TOTAL)

    def test_same_key_burst_yields_one_refund(self):
        for _ in range(20):
            order = _order()
            outcomes = _burst(lambda _: refund(order, Decimal("10.00"), "same"), 8)
            self.assertIsInstance(outcomes[0], Refund)
            self.assertTrue(all(o is outcomes[0] for o in outcomes))
            self.assertEqual(len(order.refunds), 1)
            self.assertEqual(order.refunded(), Decimal("10.00"))

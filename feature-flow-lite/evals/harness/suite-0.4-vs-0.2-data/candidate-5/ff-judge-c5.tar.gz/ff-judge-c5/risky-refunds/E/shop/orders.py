"""Orders placed from a cart, and refunds against them (in-memory store)."""

import decimal
import itertools
import threading
from dataclasses import dataclass
from decimal import Decimal

_ORDER_IDS = itertools.count(1)
_ORDER_IDS_LOCK = threading.Lock()
# Exact money arithmetic, so results never depend on the caller's decimal context.
_CTX = decimal.Context(prec=decimal.MAX_PREC, Emax=decimal.MAX_EMAX, Emin=decimal.MIN_EMIN)


class RefundError(ValueError):
    pass


@dataclass(frozen=True)
class Refund:
    order_id: int
    amount: Decimal
    key: str


class Order:
    def __init__(self, order_id, total):
        self.id = order_id
        self.total = total
        self._refunds = {}  # key -> Refund
        self._lock = threading.RLock()

    def refunded(self):
        with self._lock:
            total = Decimal("0.00")
            for r in self._refunds.values():
                total = _CTX.add(total, r.amount)
            return total

    def refundable(self):
        return _CTX.subtract(self.total, self.refunded())


def place_order(cart):
    """Freeze a non-empty cart into an Order at its current total."""
    if not cart.items:
        raise ValueError("cart is empty")
    total = cart.total()
    with _ORDER_IDS_LOCK:
        order_id = next(_ORDER_IDS)
    return Order(order_id, total)


def _checked_amount(amount):
    """Return a plain copy of amount if it is a positive, finite, whole-cent Decimal, else raise RefundError."""
    if not isinstance(amount, Decimal):
        raise RefundError("amount must be a positive, finite Decimal")
    value = Decimal(amount)  # plain copy, so a subclass cannot override the checks
    if not value.is_finite() or value <= 0:
        raise RefundError("amount must be a positive, finite Decimal")
    _, digits, exponent = value.as_tuple()
    below_cent = -2 - exponent  # trailing digits that fall past the cent
    if below_cent > 0 and any(digits[-below_cent:]):
        raise RefundError("amount must be a whole number of cents")
    return value


def _to_cents(value):
    """Return a validated whole-cent amount as a Decimal with exponent -2, using digit tuples only."""
    _, digits, exponent = value.as_tuple()
    shift = exponent + 2  # zeros to append when >= 0, trailing digits to drop when < 0
    if shift < 0:
        digits = digits[:shift]
    else:
        digits = digits + (0,) * shift
    return Decimal((0, digits, -2))


def refund(order, amount, key):
    """Refund amount against order once per key; a replayed key returns its original Refund."""
    try:
        hash(key)
    except TypeError:
        raise RefundError("key must be hashable") from None
    value = _checked_amount(amount)
    if value > order.total:  # exact comparison, checked before any conversion
        raise RefundError("amount exceeds order total")
    cents = _to_cents(value)
    with order._lock:
        prior = order._refunds.get(key)
        if prior is not None:
            if prior.amount != cents:
                raise RefundError("key already used with a different amount")
            return prior
        if cents > order.refundable():
            raise RefundError("amount exceeds refundable balance")
        record = Refund(order.id, cents, key)
        order._refunds[key] = record
        return record

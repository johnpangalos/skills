"""Orders placed from a cart, with idempotent partial refunds (in-memory store)."""

import itertools
import threading
from dataclasses import dataclass
from decimal import Context, Decimal, localcontext

from shop.money import CENT

AMOUNT_ERROR = "amount must be a finite, positive whole-cent Decimal"
REUSED_KEY_ERROR = "key already used for a different amount"
OVER_CAP_ERROR = "amount exceeds refundable total"
KEY_ERROR = "key must be hashable"
_CTX = Context(prec=60)  # money math never depends on the caller's context

_ids = itertools.count(1)
_ids_lock = threading.Lock()


class RefundError(ValueError):
    pass


@dataclass(frozen=True)
class Refund:
    order_id: int
    amount: Decimal
    key: object  # any hashable value


class Order:
    def __init__(self, total):
        with _ids_lock:
            self.id = next(_ids)
        self.total = total  # snapshot; the cart may change afterwards
        self._refunds = {}  # key -> Refund
        self._lock = threading.Lock()

    def refunded(self):
        with localcontext(_CTX):
            return sum((r.amount for r in list(self._refunds.values())), Decimal("0.00"))

    def refundable(self):
        with localcontext(_CTX):
            return self.total - self.refunded()


def place_order(cart):
    """Create an order for the cart's current total."""
    if not cart.items:
        raise ValueError("cannot place an order from an empty cart")
    with localcontext(_CTX):
        return Order(cart.total())


def _plain_amount(amount):
    """Return amount as a plain Decimal; raise RefundError unless it is a finite, positive, whole-cent value."""
    with localcontext(_CTX):
        try:
            if isinstance(amount, Decimal):
                plain = Decimal(amount)  # drops any subclass overrides
                valid = plain.is_finite() and plain > 0 and plain == plain.quantize(CENT)
            else:
                valid = False
        except Exception:  # hostile objects can raise from isinstance, comparisons or quantize
            valid = False
    if not valid:
        raise RefundError(AMOUNT_ERROR)
    return plain


def _check_key(key):
    """Raise RefundError unless key can be hashed."""
    try:
        hash(key)
    except Exception:  # hostile keys can raise anything from __hash__
        raise RefundError(KEY_ERROR) from None


def refund(order, amount, key):
    """Refund amount from order. A repeated key returns the original Refund."""
    amount = _plain_amount(amount)
    _check_key(key)
    with order._lock:
        try:
            earlier = order._refunds.get(key)
        except Exception:  # hostile keys can raise from __eq__ during the lookup
            raise RefundError(KEY_ERROR) from None
        if earlier is not None:
            if earlier.amount != amount:
                raise RefundError(REUSED_KEY_ERROR)
            return earlier
        if amount > order.refundable():
            raise RefundError(OVER_CAP_ERROR)
        record = Refund(order.id, amount, key)
        order._refunds[key] = record
        return record

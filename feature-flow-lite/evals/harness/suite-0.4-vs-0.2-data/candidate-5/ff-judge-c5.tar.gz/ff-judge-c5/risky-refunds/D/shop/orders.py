"""Orders and partial refunds (in-memory)."""

import threading
import uuid
from dataclasses import dataclass
from decimal import ROUND_HALF_UP, Context, Decimal, InvalidOperation, localcontext

from shop.money import to_cents

# Pinned so the caller's decimal context cannot change validation or the cap.
_CONTEXT = Context(prec=28, rounding=ROUND_HALF_UP)


class RefundError(ValueError):
    pass


@dataclass(frozen=True)
class Refund:
    order_id: str
    amount: Decimal
    key: str


class Order:
    def __init__(self, total):
        self.id = uuid.uuid4().hex
        self.total = total
        self._by_key = {}  # idempotency key -> Refund, in the order accepted
        self._lock = threading.Lock()

    def refunded(self):
        """Sum of this order's refunds."""
        with localcontext(_CONTEXT):
            return _dollars(sum(_cents(r.amount) for r in list(self._by_key.values())))

    def refundable(self):
        """Amount still open to refund."""
        with localcontext(_CONTEXT):
            return self.total - self.refunded()


def place_order(cart):
    """Create an Order priced at the cart's current total."""
    if not cart.items:
        raise ValueError("cannot place an order for an empty cart")
    return Order(cart.total())


def _cents(amount):
    """Whole cents of a whole-cent Decimal, as an int so sums are exact. Caller holds _CONTEXT."""
    return int(amount.scaleb(2))


def _dollars(cents):
    """Exact Decimal dollars for an int number of cents, independent of the context."""
    return Decimal(f"{cents}E-2")


def _whole_cents(amount):
    """Return amount as a plain whole-cent Decimal, or raise RefundError. Caller holds _CONTEXT."""
    if not isinstance(amount, Decimal):
        raise RefundError("amount must be a positive finite Decimal")
    amount = Decimal(amount)  # plain Decimal: subclasses can override comparisons
    if not amount.is_finite() or amount <= 0:
        raise RefundError("amount must be a positive finite Decimal")
    try:
        cents = to_cents(amount)
        if cents != amount:
            raise RefundError("amount must be in whole cents")
    except InvalidOperation:
        raise RefundError("amount is too large") from None
    return cents


def _check_key(key):
    """Raise RefundError unless key can index the order's refunds."""
    try:
        hash(key)
    except TypeError:
        raise RefundError("key must be hashable") from None


def refund(order, amount, key):
    """Refund part of an order; a repeated key with the same amount returns the first Refund."""
    with localcontext(_CONTEXT):
        _check_key(key)
        amount = _whole_cents(amount)
        with order._lock:
            original = order._by_key.get(key)
            if original is not None:
                if original.amount != amount:
                    raise RefundError("key was already used for a different amount")
                return original
            if _dollars(_cents(order.refunded()) + _cents(amount)) > order.total:
                raise RefundError("refund exceeds refundable amount")
            record = Refund(order.id, amount, key)
            order._by_key[key] = record
            return record

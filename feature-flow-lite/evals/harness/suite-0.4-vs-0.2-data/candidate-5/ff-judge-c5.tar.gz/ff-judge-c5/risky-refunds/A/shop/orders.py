"""Orders and idempotent partial refunds (in-memory store)."""

import itertools
import threading
from dataclasses import dataclass
from decimal import (
    ROUND_HALF_UP,
    Context,
    Decimal,
    DivisionByZero,
    InvalidOperation,
    Overflow,
    localcontext,
)
from functools import reduce

from shop.money import CENT

_IDS = itertools.count(1)
_REFUNDS = {}  # order id -> {key: Refund}
_LOCK = threading.Lock()  # guards _IDS and _REFUNDS
# All money arithmetic here uses this context, so a caller's decimal context cannot change results.
_CONTEXT = Context(prec=28, rounding=ROUND_HALF_UP, traps=[InvalidOperation, DivisionByZero, Overflow])


class RefundError(ValueError):
    pass


@dataclass(frozen=True)
class Refund:
    order_id: int
    amount: Decimal
    key: str


@dataclass(frozen=True)
class Order:
    id: int
    total: Decimal

    def refunded(self):
        with _LOCK:
            return _refunded_sum(_history(self.id))

    def refundable(self):
        with _LOCK:
            return _remaining(self)


def _history(order_id):
    """Return the refund history for order_id; the caller must hold _LOCK."""
    return _REFUNDS.setdefault(order_id, {})


def _refunded_sum(refunds):
    return reduce(_CONTEXT.add, (record.amount for record in refunds.values()), Decimal("0.00"))


def _remaining(order):
    """Return what is left to refund; the caller must hold _LOCK."""
    return _CONTEXT.subtract(order.total, _refunded_sum(_history(order.id)))


_BAD_AMOUNT = "amount must be a positive whole-cent Decimal"
_BAD_KEY = "key must be hashable"


def _check_key(key):
    try:
        hash(key)
    except TypeError:
        raise RefundError(_BAD_KEY) from None


def _whole_cents(amount):
    """Return amount as a 2-dp Decimal, or raise RefundError if it is not a usable amount."""
    if not isinstance(amount, Decimal) or not amount.is_finite() or amount <= 0:
        raise RefundError(_BAD_AMOUNT)
    try:
        cents = _CONTEXT.quantize(amount, CENT)
    except InvalidOperation:
        raise RefundError(_BAD_AMOUNT) from None
    if cents != amount:
        raise RefundError(_BAD_AMOUNT)
    return cents


def place_order(cart):
    """Create an Order holding the cart's current total; the cart is not changed."""
    if not cart.items:
        raise ValueError("cannot place an order for an empty cart")
    with localcontext(_CONTEXT):
        total = cart.total()
    with _LOCK:
        return Order(next(_IDS), total)


def refund(order, amount, key):
    """Refund amount from order. Repeating key with the same amount returns the first refund."""
    amount = _whole_cents(amount)
    _check_key(key)
    with _LOCK:
        refunds = _history(order.id)
        earlier = refunds.get(key)
        if earlier is not None:
            if earlier.amount != amount:
                raise RefundError("key already used with a different amount")
            return earlier
        if amount > _remaining(order):
            raise RefundError("refund exceeds refundable amount")
        record = Refund(order.id, amount, key)
        refunds[key] = record
        return record

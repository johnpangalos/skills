"""Orders placed from a cart, with idempotent partial refunds (in-memory store)."""

import decimal
import itertools
import threading
from dataclasses import dataclass
from decimal import Decimal

from shop.money import to_cents

AMOUNT_MESSAGE = "amount must be a finite, positive Decimal in whole cents"

# Fixed arithmetic for all order money, whatever context the caller has set.
_CONTEXT = decimal.Context(
    prec=50,
    rounding=decimal.ROUND_HALF_UP,
    traps=[decimal.InvalidOperation, decimal.DivisionByZero, decimal.Overflow],
)
_LOCK = threading.RLock()  # guards order ids and every order's refunds
_ORDER_IDS = itertools.count(1)


class RefundError(ValueError):
    pass


@dataclass(frozen=True)
class Refund:
    order_id: int
    amount: Decimal
    key: str


class Order:
    def __init__(self, order_id, total):
        self.id = order_id
        self._total = total
        self._refunds = {}  # key -> Refund

    @property
    def total(self):
        return self._total

    def refunded(self):
        """Sum of this order's refunds."""
        with _LOCK, decimal.localcontext(_CONTEXT):
            return sum((r.amount for r in self._refunds.values()), Decimal("0.00"))

    def refundable(self):
        """Part of the total not yet refunded."""
        with _LOCK, decimal.localcontext(_CONTEXT):
            return self._total - self.refunded()


def place_order(cart):
    """Create an order for the cart's current total."""
    if not cart.items:
        raise ValueError("cannot place an order from an empty cart")
    with decimal.localcontext(_CONTEXT):
        total = cart.total()
    with _LOCK:
        order_id = next(_ORDER_IDS)
    return Order(order_id, total)


def refund(order, amount, key):
    """Refund amount from order under an idempotency key.

    Replaying a key with an equal amount returns the original Refund.
    """
    if not issubclass(type(key), str):
        raise RefundError("key must be a non-empty str")
    key = str.__str__(key)  # plain copy: subclass overrides never run below
    if not key:
        raise RefundError("key must be a non-empty str")
    if not issubclass(type(amount), Decimal):
        raise RefundError(AMOUNT_MESSAGE)
    amount = Decimal(amount)  # plain copy: subclass overrides never run below
    if not _valid_amount(amount):
        raise RefundError(AMOUNT_MESSAGE)
    with _LOCK, decimal.localcontext(_CONTEXT):
        previous = order._refunds.get(key)
        if previous is not None:
            if previous.amount != amount:
                raise RefundError("key was already used for a different amount")
            return previous
        if amount > order.refundable():
            raise RefundError("amount exceeds refundable balance")
        record = Refund(order.id, to_cents(amount), key)
        order._refunds[key] = record
        return record


def _valid_amount(amount):
    """True for a finite, positive Decimal that is a whole number of cents."""
    if not amount.is_finite() or amount <= 0:
        return False
    _, digits, exponent = amount.as_tuple()
    extra = -exponent - 2  # digits past the cent place
    if extra <= 0:
        return True
    return extra <= len(digits) and not any(digits[len(digits) - extra:])

import random
import threading
import unittest
from unittest import mock

from shop import auth
from shop.auth import (
    InvalidToken,
    TokenExpired,
    TokenUsed,
    issue_reset_token,
    redeem_reset_token,
)


def attempt(token, now):
    """Redeem a token and return the username or the name of the error raised."""
    try:
        return redeem_reset_token(token, now=now)
    except InvalidToken as exc:
        return type(exc).__name__


class ResetTokenTest(unittest.TestCase):
    def setUp(self):
        auth._TOKENS.clear()

    def test_round_trip(self):
        token = issue_reset_token("ada")
        self.assertEqual(redeem_reset_token(token), "ada")

    def test_unknown_token(self):
        with self.assertRaises(InvalidToken):
            redeem_reset_token("not-a-token")

    def test_unknown_token_is_plain_invalid_token(self):
        with self.assertRaises(InvalidToken) as cm:
            redeem_reset_token("not-a-token", now=0)
        self.assertIs(type(cm.exception), InvalidToken)
        self.assertEqual(str(cm.exception), "unknown token")

    def test_empty_and_none_tokens_raise_invalid_token(self):
        for bad in ("", None):
            with self.subTest(token=bad):
                with self.assertRaises(InvalidToken) as cm:
                    redeem_reset_token(bad, now=0)
                self.assertIs(type(cm.exception), InvalidToken)

    def test_expired_and_used_subclass_invalid_token(self):
        self.assertTrue(issubclass(TokenExpired, InvalidToken))
        self.assertTrue(issubclass(TokenUsed, InvalidToken))

    def test_zero_now_is_honoured(self):
        token = issue_reset_token("ada", now=0)
        self.assertEqual(redeem_reset_token(token, now=0), "ada")
        token = issue_reset_token("ada", now=0)
        with self.assertRaises(TokenExpired):
            redeem_reset_token(token, now=1801)

    def test_float_now_is_accepted(self):
        token = issue_reset_token("ada", now=1000.5)
        self.assertEqual(redeem_reset_token(token, now=2800.5), "ada")
        token = issue_reset_token("ada", now=1000.5)
        with self.assertRaises(TokenExpired):
            redeem_reset_token(token, now=2800.6)

    def test_redeem_at_exact_window_end_succeeds(self):
        token = issue_reset_token("ada", now=1000)
        self.assertEqual(redeem_reset_token(token, now=1000 + 1800), "ada")

    def test_redeem_just_past_window_raises_expired(self):
        for later in (1801, 1800.001):
            with self.subTest(later=later):
                token = issue_reset_token("ada", now=1000)
                with self.assertRaises(TokenExpired) as cm:
                    redeem_reset_token(token, now=1000 + later)
                self.assertEqual(str(cm.exception), "token expired")

    def test_fractional_issue_time_window_edge_is_exact(self):
        rng = random.Random(1800)
        issued_times = [1000.104, 1700000000.123]
        issued_times += [rng.uniform(0, 2e9) for _ in range(1000)]
        for issued in issued_times:
            token = issue_reset_token("ada", now=issued)
            self.assertEqual(attempt(token, now=issued + 1800), "ada", f"issued={issued!r}")
            token = issue_reset_token("ada", now=issued)
            late = issued + 1800 + 0.001
            self.assertEqual(attempt(token, now=late), "TokenExpired", f"issued={issued!r} late={late!r}")

    def test_redeem_before_issue_time_succeeds(self):
        token = issue_reset_token("ada", now=1000)
        self.assertEqual(redeem_reset_token(token, now=500), "ada")

    def test_expired_redemption_does_not_consume_token(self):
        token = issue_reset_token("ada", now=0)
        with self.assertRaises(TokenExpired) as cm:
            redeem_reset_token(token, now=1801)
        self.assertEqual(str(cm.exception), "token expired")
        with self.assertRaises(TokenExpired):
            redeem_reset_token(token, now=1801)

    def test_expired_token_stays_expired_for_earlier_now(self):
        token = issue_reset_token("ada", now=0)
        with self.assertRaises(TokenExpired):
            redeem_reset_token(token, now=1801)
        for earlier in (1, 0):
            with self.subTest(earlier=earlier):
                with self.assertRaises(TokenExpired) as cm:
                    redeem_reset_token(token, now=earlier)
                self.assertEqual(str(cm.exception), "token expired")

    def test_nan_issue_time_fails_closed(self):
        token = issue_reset_token("ada", now=float("nan"))
        with self.assertRaises(TokenExpired) as cm:
            redeem_reset_token(token, now=1e9)
        self.assertEqual(str(cm.exception), "token expired")

    def test_nan_redeem_time_fails_closed(self):
        token = issue_reset_token("ada", now=1000)
        with self.assertRaises(TokenExpired) as cm:
            redeem_reset_token(token, now=float("nan"))
        self.assertEqual(str(cm.exception), "token expired")

    def test_second_redeem_raises_used(self):
        token = issue_reset_token("ada", now=1000)
        self.assertEqual(redeem_reset_token(token, now=1001), "ada")
        with self.assertRaises(TokenUsed) as cm:
            redeem_reset_token(token, now=1002)
        self.assertEqual(str(cm.exception), "token already used")

    def test_used_takes_precedence_over_expired(self):
        token = issue_reset_token("ada", now=0)
        self.assertEqual(redeem_reset_token(token, now=1), "ada")
        with self.assertRaises(TokenUsed):
            redeem_reset_token(token, now=1801)

    def test_tokens_for_same_user_are_independent(self):
        first = issue_reset_token("ada", now=1000)
        second = issue_reset_token("ada", now=1000)
        self.assertNotEqual(first, second)
        self.assertEqual(redeem_reset_token(first, now=1000), "ada")
        self.assertEqual(redeem_reset_token(second, now=1000), "ada")

    def test_default_now_is_read_at_call_time(self):
        with mock.patch("shop.auth.time.time", return_value=5000.0):
            token = issue_reset_token("ada")
        with mock.patch("shop.auth.time.time", return_value=5000.0 + 1801):
            with self.assertRaises(TokenExpired):
                redeem_reset_token(token)

    def test_default_now_within_window_succeeds(self):
        with mock.patch("shop.auth.time.time", return_value=5000.0):
            token = issue_reset_token("ada")
        with mock.patch("shop.auth.time.time", return_value=5000.0 + 1800):
            self.assertEqual(redeem_reset_token(token), "ada")

    def test_concurrent_redeem_has_one_winner(self):
        for _ in range(200):
            token = issue_reset_token("ada", now=1000)
            outcomes = []
            barrier = threading.Barrier(8)

            def race():
                barrier.wait()
                outcomes.append(attempt(token, now=1000))

            threads = [threading.Thread(target=race) for _ in range(8)]
            for thread in threads:
                thread.start()
            for thread in threads:
                thread.join()
            self.assertEqual(sorted(outcomes), ["TokenUsed"] * 7 + ["ada"])

    def test_property_matches_window_model(self):
        rng = random.Random(20261117)
        offsets = [-5000, -1, 0, 1, 1799, 1800, 1800.001, 1800.5, 1801, 4000]
        for i in range(1000):
            issued = rng.choice([0, rng.randint(-10**9, 2 * 10**9) + 0.5, rng.randint(-10**9, 2 * 10**9), rng.uniform(0, 2e9)])
            offset = rng.choice(offsets)
            redeemed = issued + offset
            token = issue_reset_token("ada", now=issued)
            first = attempt(token, now=redeemed)
            expected_first = "TokenExpired" if offset > 1800 else "ada"
            self.assertEqual(first, expected_first, f"iteration={i} issued={issued!r} redeemed={redeemed!r}")
            if first == "ada":
                self.assertEqual(attempt(token, now=redeemed), "TokenUsed", f"iteration={i}")
            else:
                earlier = rng.choice([issued, issued + rng.uniform(0, offset)])
                self.assertEqual(attempt(token, now=earlier), "TokenExpired", f"iteration={i} earlier={earlier!r}")
            self.assertEqual(attempt("", now=redeemed), "InvalidToken")

"""Password-reset tokens (in-memory store)."""

import secrets
import threading
import time

TOKEN_TTL_SECONDS = 1800  # 30 minutes

_TOKENS = {}  # token -> (username, issued_at)
_USED = set()  # tokens redeemed successfully
_LOCK = threading.Lock()  # guards _TOKENS and _USED


class InvalidToken(Exception):
    pass


class TokenExpired(InvalidToken):
    pass


class TokenUsed(InvalidToken):
    pass


def issue_reset_token(username, now=None):
    """Create a reset token for username, issued at now (Unix seconds)."""
    if now is None:
        now = time.time()
    token = secrets.token_urlsafe(16)
    with _LOCK:
        _TOKENS[token] = (username, now)
    return token


def redeem_reset_token(token, now=None):
    """Return the username a token was issued for, and mark the token used."""
    if now is None:
        now = time.time()
    with _LOCK:
        if token in _USED:
            raise TokenUsed("token already used")
        record = _TOKENS.get(token)
        if record is None:
            raise InvalidToken("unknown token")
        username, issued_at = record
        # Written as "not <=" so a NaN elapsed time (NaN comparisons are False) counts as expired.
        if not now - issued_at <= TOKEN_TTL_SECONDS:
            raise TokenExpired("token expired")
        _USED.add(token)
    return username

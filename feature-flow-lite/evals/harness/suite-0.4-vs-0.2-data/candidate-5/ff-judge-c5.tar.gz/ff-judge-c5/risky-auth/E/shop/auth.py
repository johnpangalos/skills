"""Password-reset tokens (in-memory store)."""

import secrets
import threading
import time

RESET_TOKEN_TTL = 1800  # seconds after issue

_TOKENS = {}  # token -> (username, issued_at)
_USED = set()  # tokens already redeemed
_LOCK = threading.Lock()  # guards the check-then-mark in redeem_reset_token


class InvalidToken(Exception):
    pass


class TokenExpired(InvalidToken):
    pass


class TokenUsed(InvalidToken):
    pass


def issue_reset_token(username, now=None):
    """Create a reset token for username, valid for RESET_TOKEN_TTL seconds.

    `now` is Unix seconds; the default is time.time() at call time.
    """
    if now is None:
        now = time.time()
    token = secrets.token_urlsafe(16)
    _TOKENS[token] = (username, now)
    return token


def redeem_reset_token(token, now=None):
    """Return the username a token was issued for, marking the token used.

    A token works once and only within RESET_TOKEN_TTL seconds of issue.
    Raises TokenUsed if already redeemed, TokenExpired if past the window,
    and InvalidToken for unknown tokens. Failed attempts do not mark the
    token used. `now` is Unix seconds; the default is time.time() at call time.
    """
    if now is None:
        now = time.time()
    with _LOCK:
        record = _TOKENS.get(token)
        if record is None:
            raise InvalidToken("unknown token")
        if token in _USED:
            raise TokenUsed("token already used")
        username, issued_at = record
        if now - issued_at > RESET_TOKEN_TTL:
            raise TokenExpired("token expired")
        _USED.add(token)
        return username

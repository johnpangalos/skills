import threading
import unittest
from unittest import mock

from shop.auth import (
    RESET_TOKEN_TTL,
    InvalidToken,
    TokenExpired,
    TokenUsed,
    issue_reset_token,
    redeem_reset_token,
)


class RaceSet(set):
    """A set that holds each membership answer until every racing thread reads.

    Without a lock, every thread reads "unused" before any thread can add the
    token, so all of them succeed. With a lock only one thread is in the check
    at a time, so the 1 ms wait just times out and correct behavior holds.
    """

    def __init__(self, parties):
        super().__init__()
        self._parties = parties
        self._arrived = 0
        self._cond = threading.Condition()

    def __contains__(self, item):
        present = set.__contains__(self, item)
        with self._cond:
            self._arrived += 1
            self._cond.notify_all()
            self._cond.wait_for(lambda: self._arrived >= self._parties, timeout=0.001)
        return present


class ResetTokenTest(unittest.TestCase):
    def test_round_trip(self):
        token = issue_reset_token("ada")
        self.assertEqual(redeem_reset_token(token), "ada")

    def test_unknown_token(self):
        with self.assertRaises(InvalidToken):
            redeem_reset_token("not-a-token")

    def test_ttl_is_thirty_minutes(self):
        self.assertEqual(RESET_TOKEN_TTL, 1800)

    def test_redeem_at_exact_ttl_succeeds(self):
        token = issue_reset_token("ada", now=1000)
        self.assertEqual(redeem_reset_token(token, now=2800), "ada")

    def test_redeem_just_past_ttl_expires(self):
        token = issue_reset_token("ada", now=1000)
        with self.assertRaises(TokenExpired) as ctx:
            redeem_reset_token(token, now=2800.001)
        self.assertEqual(str(ctx.exception), "token expired")

    def test_float_timestamps(self):
        token = issue_reset_token("ada", now=1000.5)
        self.assertEqual(redeem_reset_token(token, now=2800.5), "ada")
        token = issue_reset_token("ada", now=1000.5)
        with self.assertRaises(TokenExpired):
            redeem_reset_token(token, now=2800.501)

    def test_now_zero_is_used_as_zero(self):
        token = issue_reset_token("ada", now=0)
        self.assertEqual(redeem_reset_token(token, now=1800), "ada")
        token = issue_reset_token("ada", now=0)
        with self.assertRaises(TokenExpired):
            redeem_reset_token(token, now=1801)

    def test_clock_skew_is_not_expired(self):
        token = issue_reset_token("ada", now=1000)
        self.assertEqual(redeem_reset_token(token, now=500), "ada")

    def test_default_now_is_read_at_call_time(self):
        with mock.patch("shop.auth.time.time", return_value=1000.0):
            token = issue_reset_token("ada")
        with mock.patch("shop.auth.time.time", return_value=2801.0):
            with self.assertRaises(TokenExpired):
                redeem_reset_token(token)

    def test_second_redeem_is_used(self):
        token = issue_reset_token("ada", now=1000)
        self.assertEqual(redeem_reset_token(token, now=1000), "ada")
        with self.assertRaises(TokenUsed) as ctx:
            redeem_reset_token(token, now=1001)
        self.assertEqual(str(ctx.exception), "token already used")

    def test_used_takes_precedence_over_expired(self):
        token = issue_reset_token("ada", now=1000)
        redeem_reset_token(token, now=1000)
        with self.assertRaises(TokenUsed):
            redeem_reset_token(token, now=5000)

    def test_tokens_for_same_user_are_independent(self):
        first = issue_reset_token("ada", now=1000)
        second = issue_reset_token("ada", now=1000)
        self.assertEqual(redeem_reset_token(first, now=1000), "ada")
        self.assertEqual(redeem_reset_token(second, now=1000), "ada")

    def test_expired_redeem_does_not_mark_used(self):
        token = issue_reset_token("ada", now=1000)
        with self.assertRaises(TokenExpired):
            redeem_reset_token(token, now=2801)
        with self.assertRaises(TokenExpired) as ctx:
            redeem_reset_token(token, now=2802)
        self.assertEqual(str(ctx.exception), "token expired")

    def test_unknown_token_never_becomes_used(self):
        for _ in range(2):
            with self.assertRaises(InvalidToken) as ctx:
                redeem_reset_token("never-issued", now=1000)
            self.assertIs(type(ctx.exception), InvalidToken)
            self.assertEqual(str(ctx.exception), "unknown token")

    def test_error_hierarchy(self):
        self.assertTrue(issubclass(TokenExpired, InvalidToken))
        self.assertTrue(issubclass(TokenUsed, InvalidToken))

    def test_empty_and_none_tokens_are_invalid(self):
        for bad in ("", None):
            with self.subTest(token=bad):
                with self.assertRaises(InvalidToken) as ctx:
                    redeem_reset_token(bad, now=1000)
                self.assertIs(type(ctx.exception), InvalidToken)
                self.assertEqual(str(ctx.exception), "unknown token")

    def test_concurrent_redeem_succeeds_exactly_once(self):
        threads_n = 8
        rounds = 20
        for _ in range(rounds):
            # Widen the check-then-mark window so a missing lock shows up.
            with mock.patch("shop.auth._USED", RaceSet(threads_n)):
                token = issue_reset_token("ada", now=1000)
                barrier = threading.Barrier(threads_n)
                outcomes = []

                def redeem():
                    barrier.wait()
                    try:
                        outcomes.append(redeem_reset_token(token, now=1000))
                    except TokenUsed:
                        outcomes.append("used")

                threads = [threading.Thread(target=redeem) for _ in range(threads_n)]
                for thread in threads:
                    thread.start()
                for thread in threads:
                    thread.join()
            self.assertEqual(outcomes.count("ada"), 1)
            self.assertEqual(outcomes.count("used"), threads_n - 1)

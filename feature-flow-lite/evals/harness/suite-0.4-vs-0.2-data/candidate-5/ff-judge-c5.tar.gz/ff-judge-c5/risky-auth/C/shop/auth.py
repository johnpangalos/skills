"""Password-reset tokens (in-memory store)."""

import secrets
import threading
import time

RESET_WINDOW_SECONDS = 1800

_TOKENS = {}  # token -> [username, issued_at, used, expired]
_LOCK = threading.Lock()


class InvalidToken(Exception):
    pass


class TokenExpired(InvalidToken):
    pass


class TokenUsed(InvalidToken):
    pass


def issue_reset_token(username, now=None):
    """Create a reset token for username, valid for RESET_WINDOW_SECONDS."""
    if now is None:
        now = time.time()
    token = secrets.token_urlsafe(16)
    _TOKENS[token] = [username, now, False, False]
    return token


def redeem_reset_token(token, now=None):
    """Return the username a token was issued for, marking the token as used."""
    if now is None:
        now = time.time()
    with _LOCK:
        record = _TOKENS.get(token)
        if record is None:
            raise InvalidToken("unknown token")
        username, issued_at, used, expired = record
        if used:
            raise TokenUsed("token already used")
        if expired or not (now <= issued_at + RESET_WINDOW_SECONDS):
            record[3] = True
            raise TokenExpired("token expired")
        record[2] = True
    return username

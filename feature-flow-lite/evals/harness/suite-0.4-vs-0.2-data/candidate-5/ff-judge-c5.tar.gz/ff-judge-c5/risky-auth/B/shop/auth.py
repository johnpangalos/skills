"""Password-reset tokens (in-memory store)."""

import math
import secrets
import threading
import time

TOKEN_TTL_SECONDS = 1800

_TOKENS = {}  # token -> {"username", "issued_at", "used"}
_LOCK = threading.Lock()  # guards every read-check-write on _TOKENS


class InvalidToken(Exception):
    pass


class TokenExpired(InvalidToken):
    pass


class TokenUsed(InvalidToken):
    pass


def _check_now(now):
    """Return `now` as a float, or raise if it is not a usable Unix timestamp."""
    if isinstance(now, bool) or not isinstance(now, (int, float)):
        raise TypeError("now must be an int or float of Unix seconds")
    try:
        now = float(now)
    except OverflowError:
        raise ValueError("now must be finite") from None
    if not math.isfinite(now):
        raise ValueError("now must be finite")
    return now


def issue_reset_token(username, now=None):
    """Create a reset token for username, valid for 30 minutes after `now`.

    `now` is Unix seconds (int or float); it defaults to the current time.
    Raises TypeError if `now` is not a number and ValueError if it is NaN,
    infinite, or too large for a float. Nothing is stored in either case.
    """
    if now is None:
        now = time.time()
    now = _check_now(now)
    token = secrets.token_urlsafe(16)
    with _LOCK:
        _TOKENS[token] = {"username": username, "issued_at": now, "used": False}
    return token


def redeem_reset_token(token, now=None):
    """Return the username a token was issued for.

    Tokens are single-use and expire 30 minutes after issue. `now` is Unix
    seconds (int or float); it defaults to the current time. Raises TypeError
    if `now` is not a number and ValueError if it is NaN, infinite, or too
    large for a float; the token is left unused in either case.
    """
    if now is None:
        now = time.time()
    now = _check_now(now)
    with _LOCK:
        entry = _TOKENS.get(token) if isinstance(token, str) else None
        if entry is None:
            raise InvalidToken("unknown token")
        if entry["used"]:
            raise TokenUsed("token already used")
        if now - entry["issued_at"] > TOKEN_TTL_SECONDS:
            raise TokenExpired("token expired")
        entry["used"] = True
        return entry["username"]

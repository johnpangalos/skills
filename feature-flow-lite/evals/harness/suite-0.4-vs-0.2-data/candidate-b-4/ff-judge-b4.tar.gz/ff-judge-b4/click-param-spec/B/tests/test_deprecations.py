import importlib.metadata
import warnings

import pytest

import click
import click.core
import click.parser
import click.shell_completion
import click.utils


@pytest.mark.parametrize(
    ("module", "name", "target"),
    [
        # Stream helpers, re-exported from both `click` and `click.utils`.
        (click, "get_binary_stream", click.utils._get_binary_stream),
        (click, "get_text_stream", click.utils._get_text_stream),
        (click.utils, "get_binary_stream", click.utils._get_binary_stream),
        (click.utils, "get_text_stream", click.utils._get_text_stream),
        # Command-class aliases, re-exported from `click` and `click.core`.
        (click, "BaseCommand", click.core._BaseCommand),
        (click, "MultiCommand", click.core._MultiCommand),
        (click.core, "BaseCommand", click.core._BaseCommand),
        (click.core, "MultiCommand", click.core._MultiCommand),
        # Old parser API (moved to `optparse`); `OptionParser` is also
        # re-exported from the top-level `click` namespace.
        (click, "OptionParser", click.parser._OptionParser),
        (click.parser, "OptionParser", click.parser._OptionParser),
        (click.parser, "Argument", click.parser._Argument),
        (click.parser, "Option", click.parser._Option),
        (click.parser, "split_opt", click.parser._split_opt),
        (click.parser, "normalize_opt", click.parser._normalize_opt),
        (click.parser, "ParsingState", click.parser._ParsingState),
        (click.parser, "split_arg_string", click.shell_completion.split_arg_string),
        # Deprecated `click.utils` utilities.
        (click.utils, "LazyFile", click.utils._LazyFile),
        (click.utils, "KeepOpenFile", click.utils._KeepOpenFile),
        (click.utils, "make_default_short_help", click.utils._make_default_short_help),
        (click.utils, "PacifyFlushWrapper", click.utils._PacifyFlushWrapper),
        (click.utils, "safecall", click.utils._safecall),
        # Version metadata attribute.
        (click, "__version__", importlib.metadata.version("click")),
    ],
    ids=lambda v: getattr(v, "__name__", v),
)
def test_attr_deprecated(module, name, target):
    with pytest.warns(DeprecationWarning, match=name):
        value = getattr(module, name)

    assert value == target


@pytest.mark.parametrize(
    "module",
    [click, click.core, click.parser, click.utils],
    ids=lambda m: m.__name__,
)
def test_unknown_attribute_raises(module):
    with pytest.raises(AttributeError, match="no_such_attribute"):
        _ = module.no_such_attribute


def test_context_protected_args_deprecated():
    ctx = click.Context(click.Command("cli"))

    with pytest.warns(DeprecationWarning, match="protected_args"):
        assert ctx.protected_args == []


def test_isolated_filesystem_deprecated(runner):
    with pytest.warns(DeprecationWarning, match="isolated_filesystem"):
        with runner.isolated_filesystem():
            pass


@pytest.mark.parametrize(
    ("make_param", "match"),
    [
        pytest.param(
            lambda: click.Argument(["0foo"]),
            "not a valid Python identifier",
            id="argument-leading-digit",
        ),
        pytest.param(
            lambda: click.Argument(["foo.bar"]),
            "not a valid Python identifier",
            id="argument-dot",
        ),
        pytest.param(
            lambda: click.Argument(["foo bar"]),
            "not a valid Python identifier",
            id="argument-space",
        ),
        pytest.param(
            lambda: click.Argument([""]),
            "not a valid Python identifier",
            id="argument-empty-decl",
        ),
        pytest.param(
            lambda: click.Argument(["0foo"], expose_value=False),
            "not a valid Python identifier",
            id="argument-unexposed",
        ),
        pytest.param(
            lambda: click.Argument([], expose_value=False),
            "not a valid Python identifier",
            id="argument-no-decl",
        ),
        pytest.param(
            lambda: click.Option(["--0foo"], expose_value=False),
            "not a valid Python identifier",
            id="option-unexposed",
        ),
        pytest.param(
            lambda: click.Option([], expose_value=False),
            "not a valid Python identifier",
            id="option-no-decl",
        ),
        # A keyword is an identifier too, so this rule alone reports it.
        pytest.param(
            lambda: click.Option(["--from"]),
            "is a Python keyword",
            id="option-from",
        ),
        pytest.param(
            lambda: click.Option(["--import"]),
            "is a Python keyword",
            id="option-import",
        ),
        pytest.param(
            lambda: click.Argument(["class"]),
            "is a Python keyword",
            id="argument-class",
        ),
    ],
)
def test_unusable_name_deprecated(make_param, match):
    """A name Click 9.0 refuses reports which of its two rules it broke."""
    with pytest.warns(DeprecationWarning, match=match):
        make_param()


@pytest.mark.parametrize(
    "make_param",
    [
        pytest.param(lambda: click.Argument(["foo-bar"]), id="argument-hyphen"),
        pytest.param(lambda: click.Argument(["Foo_Bar"]), id="argument-case"),
        pytest.param(lambda: click.Option(["--foo-bar"]), id="option-hyphen"),
        pytest.param(
            lambda: click.Option(["--0foo", "zero_foo"]), id="option-explicit-name"
        ),
        # Soft keywords are contextual and name a parameter fine.
        pytest.param(lambda: click.Option(["--match"]), id="soft-keyword-match"),
        pytest.param(lambda: click.Argument(["type"]), id="soft-keyword-type"),
        # These lower case out of the keyword set.
        pytest.param(lambda: click.Option(["--True"]), id="true"),
        pytest.param(lambda: click.Option(["--None"]), id="none"),
    ],
)
def test_usable_name_not_deprecated(recwarn, make_param):
    """A name a callback can declare keeps working, and says nothing."""
    make_param()
    assert [w for w in recwarn if issubclass(w.category, DeprecationWarning)] == []


@pytest.mark.parametrize(
    "make_param",
    [
        pytest.param(lambda: click.Option(["--from"]), id="keyword"),
        pytest.param(lambda: click.Argument(["0foo"]), id="non-identifier"),
    ],
)
def test_unusable_name_names_the_release_that_refuses_it(make_param):
    """Both refusals name the release that turns the warning into an error."""
    match = r"will raise a TypeError in Click 9\.0"
    with pytest.warns(DeprecationWarning, match=match):
        make_param()


@pytest.mark.parametrize(
    ("decl", "expect"),
    [
        pytest.param("Foo_Bar", "foo_bar", id="mixed-case"),
        pytest.param("X_Y", "x_y", id="upper-case"),
        pytest.param("ΟΔΟΣ", "οδος", id="final-sigma"),
        pytest.param("\N{KELVIN SIGN}", "k", id="kelvin-sign"),
    ],
)
def test_unnormalized_explicit_name_deprecated(decl, expect):
    """Click 9.0 lower cases an explicit name like any other declaration."""
    with pytest.warns(DeprecationWarning, match="lower cases an explicit name"):
        param = click.Option(["--x", decl])

    assert param.name == decl
    assert decl.lower() == expect


@pytest.mark.parametrize(
    "decls",
    [
        pytest.param(["--x", "foo_bar"], id="already-lower"),
        pytest.param(["--x", "_from"], id="leading-underscore"),
        pytest.param(["--Foo-Bar"], id="derived-not-explicit"),
        pytest.param(["--x", "café"], id="lower-case-non-ascii"),
    ],
)
def test_normalized_explicit_name_not_deprecated(recwarn, decls):
    """A name already spelled the way 9.0 spells it says nothing."""
    click.Option(decls)
    assert [w for w in recwarn if issubclass(w.category, DeprecationWarning)] == []


def test_unnormalized_name_on_a_refused_option_is_silent():
    """An option that cannot be built at all warns about nothing."""
    with pytest.raises(TypeError, match="No options defined"):
        with warnings.catch_warnings():
            warnings.simplefilter("error", DeprecationWarning)
            click.Option(["Foo_Bar"])


class _PlainParameter(click.Parameter):
    def _parse_decls(self, decls, expose_value):
        return decls[0], [], []

    def add_to_parser(self, parser, ctx):
        pass


@pytest.mark.parametrize(
    "make_param",
    [
        pytest.param(lambda: click.Option(["-t", "--times"]), id="option"),
        pytest.param(lambda: click.Argument(["filename"]), id="argument"),
        pytest.param(lambda: _PlainParameter(["thing"]), id="parameter"),
    ],
)
def test_human_readable_name_warns_and_returns_spec(make_param):
    """The old name still answers with the spec, and says so on every access."""
    param = make_param()

    with pytest.warns(DeprecationWarning) as record:
        first = param.human_readable_name
        second = param.human_readable_name

    assert first == second == param.spec
    assert len(record) == 2

    for warning in record:
        message = str(warning.message)
        assert "'human_readable_name' is deprecated" in message
        assert "Use 'spec' instead" in message
        assert "Click 9.0" in message
        assert warning.filename == __file__


@pytest.mark.parametrize("base", [click.Option, click.Argument, _PlainParameter])
def test_overriding_human_readable_name_warns_at_class_statement(base, recwarn):
    """Defining the old name in a subclass warns once, at its class statement, and
    a subclass of that subclass does not warn again.
    """

    class Middle(base):
        pass

    assert [w for w in recwarn if issubclass(w.category, DeprecationWarning)] == []

    with pytest.warns(DeprecationWarning, match="'Leaf' defines") as record:

        class Leaf(Middle):
            @property
            def human_readable_name(self):
                return "WRONG"

    assert len(record) == 1
    assert record[0].filename == __file__
    assert "Override 'spec' instead" in str(record[0].message)

    recwarn.clear()

    class Again(Leaf):
        pass

    assert [w for w in recwarn if issubclass(w.category, DeprecationWarning)] == []


def test_override_of_human_readable_name_does_not_reach_click_messages(runner):
    """Click reads spec, so a subclass that overrides only the old name changes no
    message.
    """
    with pytest.warns(DeprecationWarning, match="'Renamed' defines"):

        class Renamed(click.Option):
            @property
            def human_readable_name(self):
                return "WRONG"

    with pytest.raises(ValueError) as excinfo:
        Renamed(["--times"], required=True, deprecated=True)

    assert str(excinfo.value) == (
        "The option '--times' is deprecated and still required. A deprecated option"
        " cannot be required."
    )
    assert str(click.MissingParameter(param=Renamed(["--times"]))) == (
        "Missing parameter: --times"
    )

    cmd = click.Command(
        "cli", params=[Renamed(["--times"], deprecated=True)], callback=None
    )
    result = runner.invoke(cmd, ["--times", "3"])
    assert "The option '--times' is deprecated." in result.output


def test_class_statement_warning_skips_custom_metaclass_new(tmp_path):
    """A metaclass __new__ in another file sits between the class statement and
    __init_subclass__, so the warning must still point at the subclass's file.
    """
    meta_file = str(tmp_path / "metamod.py")
    subclass_file = str(tmp_path / "subclass_mod.py")
    ns = {}
    exec(
        compile(
            "import abc\n"
            "class M(abc.ABCMeta):\n"
            "    def __new__(mcls, name, bases, namespace, **kwargs):\n"
            "        return super().__new__(mcls, name, bases, namespace, **kwargs)\n",
            meta_file,
            "exec",
        ),
        ns,
    )

    with pytest.warns(DeprecationWarning, match="'A' defines") as record:
        exec(
            compile(
                "import click\n"
                "class A(click.Parameter, metaclass=M):\n"
                "    human_readable_name = property(lambda self: 'WRONG')\n",
                subclass_file,
                "exec",
            ),
            ns,
        )

    assert len(record) == 1
    assert record[0].filename == subclass_file

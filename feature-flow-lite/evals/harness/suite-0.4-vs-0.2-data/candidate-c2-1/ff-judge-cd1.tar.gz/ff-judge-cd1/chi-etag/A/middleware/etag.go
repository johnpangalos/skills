package middleware

import (
	"bufio"
	"bytes"
	"crypto/sha256"
	"encoding/hex"
	"errors"
	"maps"
	"net"
	"net/http"
	"strings"
)

// ETag buffers the whole response to a GET or HEAD request in memory. A 200 response
// that doesn't set its own ETag gets a strong one: a hex SHA-256 of the bytes the
// handler writes. If the If-None-Match request header matches the response's ETag,
// the client gets 304 Not Modified with no body. The ETag is computed from the body
// bytes, so use ETag before Compress if both are used, so each encoding gets its own tag.
// Use ETag before NoCache too, since NoCache strips If-None-Match from the request.
//
// A handler Flush switches the response to streaming: from then on it is sent as
// written, with no generated ETag and no 304. Other methods and statuses pass through
// unchanged.
func ETag(next http.Handler) http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		if r.Method != http.MethodGet && r.Method != http.MethodHead {
			next.ServeHTTP(w, r)
			return
		}
		ew := &etagResponseWriter{
			ResponseWriter: w,
			head:           r.Method == http.MethodHead,
			ifNoneMatch:    r.Header.Values("If-None-Match"),
		}
		next.ServeHTTP(ew, r)
		ew.finish()
	})
}

// etagResponseWriter holds a GET or HEAD response until the handler returns, so the
// ETag can be computed from the whole body.
type etagResponseWriter struct {
	http.ResponseWriter
	head        bool
	ifNoneMatch []string
	wroteHeader bool        // the handler's final status is recorded
	code        int         // the handler's final status
	header      http.Header // headers as they were at the first WriteHeader or Write
	buf         bytes.Buffer
	sent        bool // status and headers went to the client; later calls pass through
}

func (w *etagResponseWriter) WriteHeader(code int) {
	if w.wroteHeader {
		return
	}
	if code >= 100 && code <= 199 && code != http.StatusSwitchingProtocols {
		w.ResponseWriter.WriteHeader(code) // informational, not the final status
		return
	}
	w.wroteHeader = true
	w.code = code
	w.header = w.ResponseWriter.Header().Clone()
	if code != http.StatusOK {
		w.stream()
	}
}

func (w *etagResponseWriter) Write(p []byte) (int, error) {
	if !w.wroteHeader {
		w.WriteHeader(http.StatusOK)
	}
	if w.sent {
		return w.ResponseWriter.Write(p)
	}
	return w.buf.Write(p)
}

func (w *etagResponseWriter) Flush() {
	if !w.wroteHeader {
		w.WriteHeader(http.StatusOK)
	}
	if !w.sent {
		w.stream()
	}
	if f, ok := w.ResponseWriter.(http.Flusher); ok {
		f.Flush()
	}
}

func (w *etagResponseWriter) Hijack() (net.Conn, *bufio.ReadWriter, error) {
	hj, ok := w.ResponseWriter.(http.Hijacker)
	if !ok {
		return nil, nil, errors.New("chi/middleware: http.Hijacker is unavailable on the writer")
	}
	if w.wroteHeader && !w.sent {
		w.stream()
	}
	conn, rw, err := hj.Hijack()
	if err == nil {
		w.sent = true // the connection is no longer ours to write to
	}
	return conn, rw, err
}

func (w *etagResponseWriter) Push(target string, opts *http.PushOptions) error {
	if ps, ok := w.ResponseWriter.(http.Pusher); ok {
		return ps.Push(target, opts)
	}
	return errors.New("chi/middleware: http.Pusher is unavailable on the writer")
}

func (w *etagResponseWriter) Unwrap() http.ResponseWriter {
	return w.ResponseWriter
}

// stream sends the recorded status, the headers from the first write and any buffered
// body. Later calls pass straight through.
func (w *etagResponseWriter) stream() {
	w.sent = true
	trailers := w.restoreHeader()
	w.ResponseWriter.WriteHeader(w.code)
	w.putTrailers(trailers)
	if w.buf.Len() > 0 {
		w.ResponseWriter.Write(w.buf.Bytes())
	}
	w.buf = bytes.Buffer{}
}

// restoreHeader resets the live header map to the snapshot, so headers changed after the
// first write are dropped, as net/http drops them. It returns the live value of each trailer,
// nil where the handler has deleted it. net/http reads trailers from the live map after the
// handler returns, so the caller puts them back with putTrailers once the underlying
// WriteHeader has taken its snapshot.
func (w *etagResponseWriter) restoreHeader() http.Header {
	h := w.ResponseWriter.Header()
	trailers := make(http.Header)
	for k, v := range h {
		if w.isTrailer(k) {
			trailers[k] = v
		}
	}
	for k := range w.header {
		if _, ok := trailers[k]; !ok && w.isTrailer(k) {
			trailers[k] = nil
		}
	}
	clear(h)
	maps.Copy(h, w.header)
	return trailers
}

// putTrailers puts the trailers from restoreHeader back in the live header map. A nil
// value removes the key.
func (w *etagResponseWriter) putTrailers(trailers http.Header) {
	h := w.ResponseWriter.Header()
	for k, v := range trailers {
		if v == nil {
			delete(h, k)
		} else {
			h[k] = v
		}
	}
}

// isTrailer reports whether key is a trailer: a name the snapshot's Trailer header declares,
// or a key with the http.TrailerPrefix prefix.
func (w *etagResponseWriter) isTrailer(key string) bool {
	if strings.HasPrefix(key, http.TrailerPrefix) {
		return true
	}
	for _, v := range w.header.Values("Trailer") {
		for _, name := range strings.Split(v, ",") {
			if http.CanonicalHeaderKey(strings.TrimSpace(name)) == key {
				return true
			}
		}
	}
	return false
}

// finish sends a buffered response once the handler has returned. A handler that
// panics never reaches finish, so nothing is sent.
func (w *etagResponseWriter) finish() {
	if w.sent {
		return
	}
	if !w.wroteHeader {
		w.WriteHeader(http.StatusOK)
	}
	trailers := w.restoreHeader()
	h := w.ResponseWriter.Header()
	if h.Get("ETag") == "" && (!w.head || w.buf.Len() > 0) {
		h.Set("ETag", strongTag(w.buf.Bytes()))
	}
	code := http.StatusOK
	if matchesIfNoneMatch(w.ifNoneMatch, h.Get("ETag")) {
		h.Del("Content-Length")
		h.Del("Content-Type")
		h.Del("Content-Encoding")
		code = http.StatusNotModified
	}
	w.ResponseWriter.WriteHeader(code)
	w.putTrailers(trailers)
	if code == http.StatusOK && w.buf.Len() > 0 {
		w.ResponseWriter.Write(w.buf.Bytes())
	}
}

// strongTag returns the strong entity-tag for body: its SHA-256 digest in quotes.
func strongTag(body []byte) string {
	sum := sha256.Sum256(body)
	return `"` + hex.EncodeToString(sum[:]) + `"`
}

// matchesIfNoneMatch reports whether the If-None-Match lines match etag, the ETag of a
// 200 response to GET or HEAD. etag is empty when the response has none. The comparison
// is weak (RFC 9110 section 13.1.2): a W/ prefix is ignored on both sides.
func matchesIfNoneMatch(lines []string, etag string) bool {
	members, ok := parseIfNoneMatch(lines)
	if !ok {
		return false
	}
	if len(members) == 1 && members[0] == "*" {
		return true
	}
	want, ok := opaqueTag(etag)
	if !ok {
		return false
	}
	for _, m := range members {
		if got, ok := opaqueTag(m); ok && got == want {
			return true
		}
	}
	return false
}

// parseIfNoneMatch returns the members of the If-None-Match lines, which form one list.
// ok is false if any member is neither "*" nor a valid entity-tag.
func parseIfNoneMatch(lines []string) (members []string, ok bool) {
	for _, line := range lines {
		for _, m := range splitMembers(line) {
			m = strings.Trim(m, " \t")
			if m == "" {
				continue // empty list elements are allowed (RFC 9110 section 5.6.1)
			}
			if _, valid := opaqueTag(m); !valid && m != "*" {
				return nil, false
			}
			members = append(members, m)
		}
	}
	return members, true
}

// splitMembers splits a list header value on the commas outside quoted strings.
func splitMembers(line string) []string {
	var members []string
	start, quoted := 0, false
	for i := 0; i < len(line); i++ {
		switch {
		case line[i] == '"':
			quoted = !quoted
		case line[i] == ',' && !quoted:
			members = append(members, line[start:i])
			start = i + 1
		}
	}
	return append(members, line[start:])
}

// opaqueTag strips a W/ prefix from an entity-tag and returns the quoted opaque-tag. It
// reports false if s is not a valid entity-tag: the opaque-tag may not hold DQUOTE,
// control characters, space or DEL.
func opaqueTag(s string) (string, bool) {
	s = strings.TrimPrefix(s, "W/")
	if len(s) < 2 || s[0] != '"' || s[len(s)-1] != '"' {
		return "", false
	}
	for i := 1; i < len(s)-1; i++ {
		if c := s[i]; c < 0x21 || c == '"' || c == 0x7f {
			return "", false
		}
	}
	return s, true
}

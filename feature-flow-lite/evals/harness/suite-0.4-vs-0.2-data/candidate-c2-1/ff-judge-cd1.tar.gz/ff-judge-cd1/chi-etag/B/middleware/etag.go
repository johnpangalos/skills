package middleware

import (
	"bufio"
	"bytes"
	"crypto/sha256"
	"encoding/hex"
	"errors"
	"maps"
	"net"
	"net/http"
	"strings"
)

// ETag sets a strong ETag, computed from the response body with SHA-256, on
// successful GET and HEAD responses that do not already carry one. When the
// request's If-None-Match matches the ETag, it answers 304 Not Modified without
// a body. Other methods, and responses with a status other than 200, pass
// through unchanged.
func ETag(next http.Handler) http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		if r.Method != http.MethodGet && r.Method != http.MethodHead {
			next.ServeHTTP(w, r)
			return
		}
		ew := &etagResponseWriter{ResponseWriter: w}
		next.ServeHTTP(ew, r)
		ew.finish(r)
	})
}

type etagResponseWriter struct {
	http.ResponseWriter

	// status is the committed status, or 0 while undecided. Only 200 is
	// buffered in body; any other status streams straight through.
	status int
	// implicit is set when the 200 was committed by Write, not WriteHeader.
	implicit bool
	// sent is set once the buffered 200 has been written to the underlying writer.
	sent bool
	// hijacked is set once the connection has been hijacked.
	hijacked bool
	// header is the snapshot of the handler's headers taken at commit time.
	header http.Header
	body   bytes.Buffer
}

func (ew *etagResponseWriter) WriteHeader(code int) {
	if code >= 100 && code <= 199 && code != http.StatusSwitchingProtocols {
		ew.ResponseWriter.WriteHeader(code)
		return
	}
	ew.commit(code)
}

// commit fixes the status on the first call and snapshots the headers.
func (ew *etagResponseWriter) commit(code int) {
	if ew.status != 0 || ew.hijacked {
		return
	}
	ew.status = code
	ew.header = ew.ResponseWriter.Header().Clone()
	if code != http.StatusOK {
		ew.ResponseWriter.WriteHeader(code)
	}
}

func (ew *etagResponseWriter) Write(p []byte) (int, error) {
	if ew.hijacked {
		return 0, http.ErrHijacked
	}
	if ew.status == 0 {
		ew.implicit = true
		ew.commit(http.StatusOK)
	}
	if ew.buffering() {
		return ew.body.Write(p)
	}
	return ew.ResponseWriter.Write(p)
}

// buffering reports whether a 200 is held in body rather than sent.
func (ew *etagResponseWriter) buffering() bool {
	return ew.status == http.StatusOK && !ew.sent
}

func (ew *etagResponseWriter) Flush() {
	if ew.hijacked || ew.status == 0 || ew.buffering() {
		return
	}
	if f, ok := ew.ResponseWriter.(http.Flusher); ok {
		f.Flush()
	}
}

// Hijack sends a buffered 200 first, as net/http does, so the client receives
// the status line and headers before the connection is handed over.
func (ew *etagResponseWriter) Hijack() (net.Conn, *bufio.ReadWriter, error) {
	hj, ok := ew.ResponseWriter.(http.Hijacker)
	if !ok {
		return nil, nil, errors.New("chi/middleware: http.Hijacker is unavailable on the writer")
	}
	if ew.buffering() {
		ew.writeBuffered()
	}
	conn, rw, err := hj.Hijack()
	ew.hijacked = err == nil
	return conn, rw, err
}

func (ew *etagResponseWriter) Push(target string, opts *http.PushOptions) error {
	if ps, ok := ew.ResponseWriter.(http.Pusher); ok {
		return ps.Push(target, opts)
	}
	return errors.New("chi/middleware: http.Pusher is unavailable on the writer")
}

func (ew *etagResponseWriter) Unwrap() http.ResponseWriter {
	return ew.ResponseWriter
}

// finish writes out a buffered 200 response, or answers 304 when it matches.
func (ew *etagResponseWriter) finish(r *http.Request) {
	if ew.hijacked || ew.sent {
		return
	}
	ew.commit(http.StatusOK)
	if ew.status != http.StatusOK {
		return
	}

	trailers := ew.trailers()
	etag := ew.header.Get("ETag")
	if etag == "" && (r.Method == http.MethodGet || ew.body.Len() > 0) {
		sum := sha256.Sum256(ew.body.Bytes())
		etag = `"` + hex.EncodeToString(sum[:]) + `"`
		ew.header.Set("ETag", etag)
	}
	ew.restoreHeader()

	if etagNotModified(r.Header.Values("If-None-Match"), etag) {
		h := ew.ResponseWriter.Header()
		h.Del("Content-Type")
		h.Del("Content-Length")
		h.Del("Content-Encoding")
		h.Del("Last-Modified")
		ew.ResponseWriter.WriteHeader(http.StatusNotModified)
		return
	}

	ew.writeBuffered()
	h := ew.ResponseWriter.Header()
	for k, vals := range trailers {
		h[k] = vals
	}
}

// writeBuffered sends the buffered 200 with the headers snapshotted at commit.
func (ew *etagResponseWriter) writeBuffered() {
	ew.restoreHeader()
	ew.sent = true
	if !ew.implicit {
		ew.ResponseWriter.WriteHeader(http.StatusOK)
	}
	ew.ResponseWriter.Write(ew.body.Bytes())
}

// restoreHeader replaces the underlying header with the snapshot from commit.
func (ew *etagResponseWriter) restoreHeader() {
	h := ew.ResponseWriter.Header()
	clear(h)
	maps.Copy(h, ew.header)
}

// trailers returns the values the handler set on the live header after the
// commit, for the names listed in the snapshot's Trailer header and for keys
// with the http.TrailerPrefix. net/http sends these as trailers and ignores
// other late header changes.
func (ew *etagResponseWriter) trailers() http.Header {
	live := ew.ResponseWriter.Header()
	out := http.Header{}
	for _, v := range ew.header.Values("Trailer") {
		for _, name := range strings.Split(v, ",") {
			name = http.CanonicalHeaderKey(strings.TrimSpace(name))
			if vals, ok := live[name]; ok {
				out[name] = vals
			}
		}
	}
	for k, vals := range live {
		if strings.HasPrefix(k, http.TrailerPrefix) {
			out[k] = vals
		}
	}
	return out
}

// etagNotModified reports whether any If-None-Match member matches etag under
// the weak comparison of RFC 9110 §13.1.2. A field value of "*" alone matches
// any representation. Empty list elements are skipped, as RFC 9110 §5.6.1
// requires.
func etagNotModified(lines []string, etag string) bool {
	for _, line := range lines {
		if strings.Trim(line, " \t") == "*" {
			return true
		}
		for {
			line = strings.TrimLeft(line, " \t,")
			if line == "" {
				break
			}
			member, rest, ok := scanMember(line)
			if !ok {
				break
			}
			rest = strings.TrimLeft(rest, " \t")
			if rest != "" && rest[0] != ',' {
				break
			}
			if strings.TrimPrefix(member, "W/") == strings.TrimPrefix(etag, "W/") {
				return true
			}
			line = rest
		}
	}
	return false
}

// scanMember parses the entity-tag (RFC 9110 §8.8.3) at the start of s. It
// returns the tag with the rest of s, and reports false if s does not start
// with a well-formed tag; a "*" is not a tag, so it ends the list. Control
// characters and DEL are not allowed inside the quotes.
func scanMember(s string) (member, rest string, ok bool) {
	start := 0
	if strings.HasPrefix(s, "W/") {
		start = 2
	}
	if start >= len(s) || s[start] != '"' {
		return "", "", false
	}
	for i := start + 1; i < len(s); i++ {
		c := s[i]
		if c == '"' {
			return s[:i+1], s[i+1:], true
		}
		if c <= 0x20 || c == 0x7f {
			return "", "", false
		}
	}
	return "", "", false
}

package middleware

import (
	"bufio"
	"bytes"
	"crypto/sha256"
	"encoding/hex"
	"errors"
	"maps"
	"net"
	"net/http"
	"strings"
)

// ETag adds a strong ETag to GET and HEAD responses and answers conditional
// requests with 304 Not Modified.
//
// For GET and HEAD requests whose final status is 200, the whole response body
// is buffered in memory until the handler returns. Nothing is sent early, not
// even on Flush. When the handler sets no ETag, one is computed as a hash of
// the body bytes. The ETag is then compared with the If-None-Match request
// header, using weak comparison as in RFC 9110 section 13.1.2. On a match the
// response becomes a 304 with no body. Responses with any other status, and
// requests with other methods, are passed through unchanged and streamed.
//
// Headers that outer middleware sets after ETag returns are not sent for a
// buffered response, because its head is already sent by then.
//
// Register ETag before Compress (r.Use(ETag) then r.Use(Compress(...))), so
// that ETag wraps Compress and sees the compressed bytes. Otherwise a single
// strong ETag would cover different content encodings.
func ETag(next http.Handler) http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		if r.Method != http.MethodGet && r.Method != http.MethodHead {
			next.ServeHTTP(w, r)
			return
		}
		ew := &etagResponseWriter{ResponseWriter: w, hdr: w.Header().Clone()}
		next.ServeHTTP(ew, r)
		ew.finish(r)
	})
}

type etagResponseWriter struct {
	http.ResponseWriter
	hdr      http.Header // the handler's headers, copied to the underlying writer when committed
	snap     http.Header // hdr as of the buffered 200 WriteHeader
	code     int         // final status; 0 until WriteHeader, Write or Flush
	buf      bytes.Buffer
	flushed  bool // Flush committed the 200 before any body bytes
	sent     bool // the buffered 200 head and body have been sent
	hijacked bool
}

// streaming reports whether writes go straight through: the final status is not
// 200, or the buffered 200 has already been sent.
func (ew *etagResponseWriter) streaming() bool {
	return ew.sent || (ew.code != 0 && ew.code != http.StatusOK)
}

// Header returns the handler's own headers. Trailers set through it after the
// first write are forwarded by finish.
func (ew *etagResponseWriter) Header() http.Header {
	return ew.hdr
}

func (ew *etagResponseWriter) WriteHeader(code int) {
	if ew.hijacked {
		return
	}
	if code >= 100 && code <= 199 && code != http.StatusSwitchingProtocols {
		if ew.code == 0 {
			ew.copyHeader(ew.hdr)
			ew.ResponseWriter.WriteHeader(code)
		}
		return
	}
	if ew.code != 0 {
		return
	}
	ew.code = code
	if code == http.StatusOK {
		ew.snap = ew.hdr.Clone()
		return
	}
	ew.copyHeader(ew.hdr)
	ew.ResponseWriter.WriteHeader(code)
}

func (ew *etagResponseWriter) Write(p []byte) (int, error) {
	if ew.hijacked {
		return 0, http.ErrHijacked
	}
	if ew.code == 0 {
		ew.WriteHeader(http.StatusOK)
	}
	if ew.streaming() {
		return ew.ResponseWriter.Write(p)
	}
	return ew.buf.Write(p)
}

// Flush commits a 200 when no status is known yet, as net/http does. A buffered
// 200 is still not sent, so Flush does nothing for it.
func (ew *etagResponseWriter) Flush() {
	if ew.hijacked {
		return
	}
	if ew.code == 0 {
		ew.WriteHeader(http.StatusOK)
		ew.flushed = true
	}
	if f, ok := ew.ResponseWriter.(http.Flusher); ok && ew.streaming() {
		f.Flush()
	}
}

func (ew *etagResponseWriter) Hijack() (net.Conn, *bufio.ReadWriter, error) {
	if ew.hijacked {
		return nil, nil, http.ErrHijacked
	}
	hj, ok := ew.ResponseWriter.(http.Hijacker)
	if !ok {
		return nil, nil, errors.New("chi/middleware: http.Hijacker is unavailable on the writer")
	}
	if ew.code == http.StatusOK && !ew.sent {
		ew.sendBuffered()
	}
	conn, rw, err := hj.Hijack()
	if err == nil {
		ew.hijacked = true
	}
	return conn, rw, err
}

func (ew *etagResponseWriter) Push(target string, opts *http.PushOptions) error {
	if ps, ok := ew.ResponseWriter.(http.Pusher); ok {
		return ps.Push(target, opts)
	}
	return errors.New("chi/middleware: http.Pusher is unavailable on the writer")
}

func (ew *etagResponseWriter) Unwrap() http.ResponseWriter {
	return ew.ResponseWriter
}

// finish sends a buffered 200 response, or a 304 when If-None-Match matches. A
// 304 is sent without trailers.
func (ew *etagResponseWriter) finish(r *http.Request) {
	if ew.hijacked {
		return
	}
	if ew.code == 0 {
		ew.WriteHeader(http.StatusOK)
	}
	if ew.streaming() {
		ew.sendTrailers()
		return
	}
	h := ew.snap
	body := ew.buf.Bytes()
	if h.Get("ETag") == "" && (r.Method == http.MethodGet || len(body) > 0) {
		sum := sha256.Sum256(body)
		h.Set("ETag", `"`+hex.EncodeToString(sum[:16])+`"`)
	}
	if etagMatches(r.Header.Values("If-None-Match"), h.Get("ETag")) {
		h.Del("Content-Type")
		h.Del("Content-Length")
		h.Del("Content-Encoding")
		if h.Get("ETag") != "" {
			h.Del("Last-Modified")
		}
		ew.copyHeader(h)
		ew.ResponseWriter.WriteHeader(http.StatusNotModified)
		return
	}
	ew.sendBuffered()
	ew.sendTrailers()
}

// sendBuffered sends the buffered 200 head and body as the handler wrote them.
func (ew *etagResponseWriter) sendBuffered() {
	ew.sent = true
	h := ew.snap
	if _, ok := h["Content-Type"]; !ok && ew.flushed {
		// net/http sent the head at Flush, before any body bytes, so it never
		// sniffed a Content-Type. A nil value stops the underlying writer from
		// sniffing one now, and sends no header.
		h["Content-Type"] = nil
	}
	ew.copyHeader(h)
	ew.ResponseWriter.WriteHeader(http.StatusOK)
	// net/http does not send the body of a HEAD response.
	ew.ResponseWriter.Write(ew.buf.Bytes())
}

// sendTrailers gives the underlying writer the trailers the handler set after
// its first write. net/http reads them when the response ends. The declared
// names are the Trailer header the underlying writer committed.
func (ew *etagResponseWriter) sendTrailers() {
	under := ew.ResponseWriter.Header()
	for k, vv := range ew.hdr {
		if strings.HasPrefix(k, http.TrailerPrefix) {
			under[k] = vv
		}
	}
	for _, v := range under.Values("Trailer") {
		for _, name := range strings.Split(v, ",") {
			name = http.CanonicalHeaderKey(strings.TrimSpace(name))
			if vv, ok := ew.hdr[name]; ok {
				under[name] = vv
			}
		}
	}
}

// copyHeader makes the underlying writer's header map a copy of h.
func (ew *etagResponseWriter) copyHeader(h http.Header) {
	under := ew.ResponseWriter.Header()
	clear(under)
	maps.Copy(under, h)
}

// etagMatches reports whether any If-None-Match member matches etag under weak
// comparison. A "*" member matches any representation.
func etagMatches(lines []string, etag string) bool {
	etag = strings.TrimPrefix(etag, "W/")
	for _, line := range lines {
		rest := line
		for {
			rest = strings.TrimLeft(rest, " \t,")
			if rest == "" {
				break
			}
			if rest[0] == '*' {
				return true
			}
			tag, after, ok := cutETag(rest)
			if !ok {
				break
			}
			if tag == etag {
				return true
			}
			rest = after
		}
	}
	return false
}

// cutETag splits one entity-tag off the front of s. It returns the tag without
// its W/ prefix and the text after it. ok is false if s does not start with a
// well-formed entity-tag.
func cutETag(s string) (tag, rest string, ok bool) {
	s = strings.TrimPrefix(s, "W/")
	if len(s) < 2 || s[0] != '"' {
		return "", "", false
	}
	end := strings.IndexByte(s[1:], '"')
	if end < 0 {
		return "", "", false
	}
	tag = s[:end+2]
	if strings.ContainsFunc(tag[1:len(tag)-1], func(r rune) bool { return r <= 0x20 || r == 0x7f }) {
		return "", "", false
	}
	return tag, s[end+2:], true
}

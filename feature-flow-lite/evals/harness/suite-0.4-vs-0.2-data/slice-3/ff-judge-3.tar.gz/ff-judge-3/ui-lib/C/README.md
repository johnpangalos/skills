# @acme/ui

Small, accessible React 19 components: `Tabs`, `Dialog` and `Combobox`. They follow the WAI-ARIA Authoring Practices patterns, ship no styles, and forward `className` (and other native props) to their root element so you style them yourself.

## Install

This package is private (`"private": true`), so it is consumed from this repository's workspace rather than installed from a registry. It needs `react` and `react-dom` 19 as peer dependencies.

## Usage

```tsx
import { Combobox, Dialog, Tab, TabList, TabPanel, Tabs } from "@acme/ui";
```

## Tabs

```tsx
<Tabs defaultValue="profile">
  <TabList aria-label="Settings">
    <Tab value="profile">Profile</Tab>
    <Tab value="billing" disabled>Billing</Tab>
    <Tab value="security">Security</Tab>
  </TabList>
  <TabPanel value="profile">Profile settings</TabPanel>
  <TabPanel value="billing">Billing settings</TabPanel>
  <TabPanel value="security">Security settings</TabPanel>
</Tabs>
```

Controlled: pass `value` and update it in `onValueChange`.

### Tabs props (`TabsProps`)

| Name | Type | Required | Description |
| --- | --- | --- | --- |
| `defaultValue` | `string` | no | Initially selected tab (uncontrolled). |
| `value` | `string` | no | Selected tab (controlled). |
| `onValueChange` | `(value: string) => void` | no | Called when the user selects a tab. |
| `className` | `string` | no | Class on the root `div`. Other `div` props are forwarded. |

### TabList props (`TabListProps`)

| Name | Type | Required | Description |
| --- | --- | --- | --- |
| `aria-label` | `string` | yes | Accessible name of the tablist. |
| `className` | `string` | no | Class on the `role="tablist"` element. |

### Tab props (`TabProps`)

| Name | Type | Required | Description |
| --- | --- | --- | --- |
| `value` | `string` | yes | Identifies the tab and links it to its panel. |
| `disabled` | `boolean` | no | Sets `aria-disabled="true"`; the tab cannot be selected by click or keyboard. |
| `className` | `string` | no | Class on the `<button>`. |

### TabPanel props (`TabPanelProps`)

| Name | Type | Required | Description |
| --- | --- | --- | --- |
| `value` | `string` | yes | The tab this panel belongs to. Hidden unless that tab is selected. |
| `className` | `string` | no | Class on the `role="tabpanel"` element. |

### Tabs keyboard

| Key | Behaviour |
| --- | --- |
| Tab | Moves focus into the selected tab, then out of the tablist. |
| ArrowRight / ArrowLeft | Moves to the next / previous enabled tab, wrapping at both ends. Selection follows focus. |
| Home / End | Moves to the first / last enabled tab. Selection follows focus. |

## Dialog

```tsx
const [open, setOpen] = useState(false);

<button onClick={() => setOpen(true)}>Delete</button>
<Dialog open={open} onOpenChange={setOpen} title="Delete item" description="This cannot be undone.">
  <button onClick={() => setOpen(false)}>Cancel</button>
  <button>Confirm</button>
</Dialog>
```

Renders into `document.body` through a portal, with a backdrop around a `role="dialog"` panel. Focus moves into the dialog on open and returns to the previously focused element on close. The dialog never closes itself; it only calls `onOpenChange(false)`.

### Dialog props (`DialogProps`)

| Name | Type | Required | Description |
| --- | --- | --- | --- |
| `open` | `boolean` | yes | Whether the dialog is shown. |
| `onOpenChange` | `(open: boolean) => void` | yes | Called with `false` on Escape or a backdrop click. |
| `title` | `string` | yes | Rendered in a heading that names the dialog. |
| `description` | `string` | no | Rendered below the title and linked with `aria-describedby`. |
| `className` | `string` | no | Class on the `role="dialog"` element. Other `div` props are forwarded to it. |
| `children` | `ReactNode` | no | Dialog content. |

### Dialog keyboard

| Key | Behaviour |
| --- | --- |
| Tab | Moves to the next focusable element; wraps from the last back to the first. |
| Shift+Tab | Moves to the previous focusable element; wraps from the first (or the dialog itself) to the last. |
| Escape | Calls `onOpenChange(false)`, from anywhere inside the dialog, unless an inner control already handled the key. An open Combobox list handles Escape first, so it only closes the list; in nested dialogs only the innermost one closes. |

A click on the backdrop calls `onOpenChange(false)` only when both the mousedown and the mouseup happened on the backdrop. Clicks inside the panel, and drags that start on the backdrop and end inside the panel, do not close it.

## Combobox

```tsx
const [fruit, setFruit] = useState<string | null>(null);

<Combobox
  label="Fruit"
  placeholder="Search fruit"
  options={[
    { value: "apple", label: "Apple" },
    { value: "banana", label: "Banana", disabled: true },
    { value: "cherry", label: "Cherry" },
  ]}
  value={fruit}
  onChange={setFruit}
/>
```

Typing filters the options by case-insensitive substring match; regex characters are matched literally. With unchanged text the full list is shown.

### Combobox props (`ComboboxProps`)

| Name | Type | Required | Description |
| --- | --- | --- | --- |
| `label` | `string` | yes | Visible label; the accessible name of the input. |
| `options` | `ComboboxOption[]` | yes | Options to choose from. |
| `value` | `string \| null` | yes | Selected option value, or `null` for none (controlled). |
| `onChange` | `(value: string \| null) => void` | yes | Called when an option is chosen, or when the text is cleared (see below). |
| `placeholder` | `string` | no | Placeholder of the input. |
| `className` | `string` | no | Class on the wrapping `div`. Other input props are forwarded to the `<input>`. |

### ComboboxOption

| Name | Type | Required | Description |
| --- | --- | --- | --- |
| `value` | `string` | yes | Value passed to `onChange`. |
| `label` | `string` | yes | Text shown in the input and the list. |
| `disabled` | `boolean` | no | Shown with `aria-disabled="true"`; cannot be chosen or made active. |

### Combobox behaviour

- Clicking the input or typing opens the list. Escape, blur or choosing an option closes it.
- Choosing an option (Enter on the active option, or click) calls `onChange(value)` and sets the input text to its label.
- Escape and blur restore the input text to the selected option's label (empty when `value` is `null` or matches no option) and do not call `onChange`.
- Emptying the text (whitespace-only counts as empty), then pressing Enter with no active option, or blurring, calls `onChange(null)` when a value was selected. A value that matches no option is left alone until the user edits the text.
- If the parent ignores `onChange`, the value stays and the text reverts on blur or Escape.
- The listbox is always rendered (hidden while closed), so `aria-controls` always resolves. A consumer `onClick`, `onKeyDown` or `onBlur` runs before the built-in handling, and `id` sets the input id.
- Options are matched by index, so duplicate labels with different values choose the right value.

### Combobox keyboard

| Key | Behaviour |
| --- | --- |
| ArrowDown | Opens the list if closed (and activates the first enabled option); otherwise moves the active option down. Wraps at the end. |
| ArrowUp | Moves the active option up, skipping disabled options. Wraps at the start. Does nothing when closed. |
| Enter | Chooses the active option. With no active option and text the user emptied, clears the selection (`onChange(null)`). |
| Escape | Closes the list and restores the input text. When the list is already closed it does nothing itself, so the key reaches any enclosing handler (an enclosing `Dialog` closes). |
| Tab | Moves focus out; blur closes the list and restores the text. |

## Development

```sh
pnpm test        # run the test suite (Vitest + Testing Library)
pnpm typecheck   # TypeScript, strict mode
```

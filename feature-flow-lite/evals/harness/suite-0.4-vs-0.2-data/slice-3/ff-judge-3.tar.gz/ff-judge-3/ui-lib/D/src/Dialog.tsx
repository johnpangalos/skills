import {
  useId,
  useLayoutEffect,
  useRef,
  type ComponentPropsWithoutRef,
  type KeyboardEvent,
  type ReactNode,
} from "react";
import { createPortal } from "react-dom";

export type DialogProps = Omit<ComponentPropsWithoutRef<"div">, "title"> & {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  title: ReactNode;
  description?: ReactNode;
};

const FOCUSABLE = 'a[href], button, input:not([type="hidden"]), select, textarea, [tabindex], [contenteditable="true"]';

function getFocusable(container: HTMLElement): HTMLElement[] {
  return Array.from(container.querySelectorAll<HTMLElement>(FOCUSABLE)).filter(
    (el) =>
      !el.hasAttribute("disabled") &&
      (el.tabIndex >= 0 || (el.getAttribute("contenteditable") === "true" && !el.hasAttribute("tabindex"))) &&
      !el.closest("[hidden]") &&
      getComputedStyle(el).display !== "none",
  );
}

// The element Tab lands on. A focused element outside the list (the container, or a tabIndex -1 element) is placed by document order.
function getTabTarget(items: HTMLElement[], active: Element, backward: boolean): HTMLElement {
  const index = items.indexOf(active as HTMLElement);
  if (index >= 0) return items[(index + (backward ? items.length - 1 : 1)) % items.length];
  if (backward) {
    const preceding = [...items].reverse().find((item) => active.compareDocumentPosition(item) & Node.DOCUMENT_POSITION_PRECEDING);
    return preceding ?? items[items.length - 1];
  }
  return items.find((item) => active.compareDocumentPosition(item) & Node.DOCUMENT_POSITION_FOLLOWING) ?? items[0];
}

export function Dialog({ open, onOpenChange, title, description, children, onKeyDown, ...rest }: DialogProps) {
  const baseId = useId();
  const dialogRef = useRef<HTMLDivElement>(null);
  const titleId = `${baseId}-title`;
  const descriptionId = `${baseId}-description`;

  // Focus moves in when the dialog opens and returns to the previously focused element when it closes or unmounts.
  useLayoutEffect(() => {
    const dialog = dialogRef.current;
    if (!open || !dialog) return;
    const previous = document.activeElement;
    (getFocusable(dialog)[0] ?? dialog).focus();
    return () => {
      if (previous instanceof HTMLElement && previous.isConnected) previous.focus();
    };
  }, [open]);

  const handleKeyDown = (event: KeyboardEvent<HTMLDivElement>) => {
    onKeyDown?.(event);
    if (event.key === "Escape") {
      // Stops here so an enclosing dialog (reached through the portal's React bubbling) does not also close.
      event.preventDefault();
      event.stopPropagation();
      onOpenChange(false);
      return;
    }
    const dialog = dialogRef.current;
    // Portals bubble React keydown events up to enclosing dialogs, so only handle Tab whose nearest dialog is this one.
    if (event.key !== "Tab" || !dialog || (event.target as Element).closest('[role="dialog"]') !== dialog) return;
    event.preventDefault();
    const items = getFocusable(dialog);
    if (items.length === 0) {
      dialog.focus();
      return;
    }
    getTabTarget(items, document.activeElement ?? dialog, event.shiftKey).focus();
  };

  if (!open) return null;

  return createPortal(
    <>
      <div data-backdrop="" aria-hidden="true" onClick={() => onOpenChange(false)} />
      <div
        {...rest}
        ref={dialogRef}
        role="dialog"
        aria-modal="true"
        aria-labelledby={titleId}
        aria-describedby={description != null ? descriptionId : undefined}
        tabIndex={-1}
        onKeyDown={handleKeyDown}
      >
        <h2 id={titleId}>{title}</h2>
        {description != null && <p id={descriptionId}>{description}</p>}
        {children}
      </div>
    </>,
    document.body,
  );
}

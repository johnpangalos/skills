import {
  createContext,
  useCallback,
  useContext,
  useId,
  useLayoutEffect,
  useRef,
  useState,
  type ButtonHTMLAttributes,
  type HTMLAttributes,
  type KeyboardEvent,
} from "react";

type TabEntry = { value: string; disabled: boolean; element: HTMLButtonElement };

type TabsContextValue = {
  baseId: string;
  selected: string | null;
  tabs: TabEntry[];
  select: (value: string) => void;
  register: (entry: TabEntry) => () => void;
};

const TabsContext = createContext<TabsContextValue | null>(null);

function useTabsContext() {
  const context = useContext(TabsContext);
  if (!context) {
    throw new Error("Tab, TabList and TabPanel must be rendered inside <Tabs>");
  }
  return context;
}

// Replaces every character outside [A-Za-z0-9-] with an escape starting with "_", so the id is one
// token (aria-controls and aria-labelledby are space-separated) and distinct values never collide.
const idPart = (value: string) => value.replace(/[^A-Za-z0-9-]/g, (char) => `_${char.charCodeAt(0).toString(16)}_`);
const tabId = (baseId: string, value: string) => `${baseId}-tab-${idPart(value)}`;
const panelId = (baseId: string, value: string) => `${baseId}-panel-${idPart(value)}`;

const byDocumentOrder = (a: TabEntry, b: TabEntry) =>
  a.element.compareDocumentPosition(b.element) & Node.DOCUMENT_POSITION_FOLLOWING ? -1 : 1;

export type TabsProps = Omit<HTMLAttributes<HTMLDivElement>, "defaultValue"> & {
  /** Initially selected tab value (uncontrolled). */
  defaultValue?: string;
  /** Selected tab value (controlled). */
  value?: string;
  /** Called with the requested value whenever the selection should change. */
  onValueChange?: (value: string) => void;
};

export function Tabs({ defaultValue, value, onValueChange, children, ...props }: TabsProps) {
  const baseId = useId();
  const [internalValue, setInternalValue] = useState<string | null>(defaultValue ?? null);
  const [entries, setEntries] = useState<TabEntry[]>([]);

  const tabs = [...entries].sort(byDocumentOrder);
  const enabledValues = tabs.filter((tab) => !tab.disabled).map((tab) => tab.value);
  const requested = value ?? internalValue;
  // Falls back to the first enabled tab when the requested one is missing or disabled. Before the tabs
  // have registered (first commit), trust the requested value so layout effects see the right tab.
  const selected =
    entries.length === 0 || enabledValues.includes(requested ?? "") ? requested : (enabledValues[0] ?? null);

  const select = (next: string) => {
    if (next === selected) return;
    if (value === undefined) setInternalValue(next);
    onValueChange?.(next);
  };

  const register = useCallback((entry: TabEntry) => {
    setEntries((prev) => [...prev, entry]);
    return () => setEntries((prev) => prev.filter((item) => item !== entry));
  }, []);

  return (
    <TabsContext.Provider value={{ baseId, selected, tabs, select, register }}>
      <div {...props}>{children}</div>
    </TabsContext.Provider>
  );
}

export type TabListProps = HTMLAttributes<HTMLDivElement> & {
  "aria-label": string;
};

export function TabList({ onKeyDown, ...props }: TabListProps) {
  const { tabs, select } = useTabsContext();

  const handleKeyDown = (event: KeyboardEvent<HTMLDivElement>) => {
    onKeyDown?.(event);
    const enabled = tabs.filter((tab) => !tab.disabled);
    const current = enabled.findIndex((tab) => tab.element === event.target);
    if (current === -1) return;

    let next: number;
    switch (event.key) {
      case "ArrowRight":
        next = (current + 1) % enabled.length;
        break;
      case "ArrowLeft":
        next = (current - 1 + enabled.length) % enabled.length;
        break;
      case "Home":
        next = 0;
        break;
      case "End":
        next = enabled.length - 1;
        break;
      default:
        return;
    }
    event.preventDefault();
    enabled[next].element.focus();
    select(enabled[next].value);
  };

  return <div {...props} role="tablist" onKeyDown={handleKeyDown} />;
}

export type TabProps = Omit<ButtonHTMLAttributes<HTMLButtonElement>, "type" | "value"> & {
  value: string;
  disabled?: boolean;
};

export function Tab({ value, disabled, onClick, ...props }: TabProps) {
  const { baseId, selected, select, register } = useTabsContext();
  const ref = useRef<HTMLButtonElement>(null);

  useLayoutEffect(() => {
    const element = ref.current;
    if (!element) return;
    return register({ value, disabled: Boolean(disabled), element });
  }, [register, value, disabled]);

  const isSelected = selected === value;

  return (
    <button
      {...props}
      ref={ref}
      type="button"
      role="tab"
      id={tabId(baseId, value)}
      aria-selected={isSelected}
      aria-controls={panelId(baseId, value)}
      tabIndex={isSelected ? 0 : -1}
      disabled={disabled}
      onClick={(event) => {
        onClick?.(event);
        select(value);
      }}
    />
  );
}

export type TabPanelProps = HTMLAttributes<HTMLDivElement> & {
  value: string;
};

export function TabPanel({ value, ...props }: TabPanelProps) {
  const { baseId, selected } = useTabsContext();

  return (
    <div
      {...props}
      role="tabpanel"
      id={panelId(baseId, value)}
      aria-labelledby={tabId(baseId, value)}
      tabIndex={0}
      hidden={selected !== value}
    />
  );
}

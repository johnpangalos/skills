import { render, screen, waitFor } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { useState, type ReactNode } from "react";
import { Dialog, type DialogProps } from "./Dialog";
import { Tab, TabList, TabPanel, Tabs } from "../Tabs/Tabs";

function Harness({ initialOpen = true, description, children }: { initialOpen?: boolean; description?: string; children?: ReactNode }) {
  const [open, setOpen] = useState(initialOpen);
  return (
    <>
      <button onClick={() => setOpen(true)}>Open</button>
      <Dialog open={open} onOpenChange={setOpen} title="Confirm" description={description}>
        {children ?? <button>Ok</button>}
      </Dialog>
    </>
  );
}

function ControlledDialog(props: Omit<DialogProps, "title" | "children">) {
  return (
    <Dialog title="Confirm" {...props}>
      <button>First</button>
      <button>Second</button>
    </Dialog>
  );
}

const backdropOf = (dialog: HTMLElement) => dialog.parentElement as HTMLElement;

describe("Dialog", () => {
  describe("rendering", () => {
    it("renders nothing when closed", () => {
      render(<ControlledDialog open={false} onOpenChange={vi.fn()} />);
      expect(screen.queryByRole("dialog")).not.toBeInTheDocument();
      expect(document.querySelector("[data-backdrop]")).toBeNull();
    });

    it("renders into document.body through a portal, with a backdrop", () => {
      const { container } = render(<ControlledDialog open onOpenChange={vi.fn()} />);
      const dialog = screen.getByRole("dialog");
      expect(container).not.toContainElement(dialog);
      expect(document.body).toContainElement(dialog);
      expect(backdropOf(dialog)).toHaveAttribute("data-backdrop");
    });

    it("is modal and labelled by its title, with no describedby when no description is given", () => {
      render(<ControlledDialog open onOpenChange={vi.fn()} />);
      const dialog = screen.getByRole("dialog", { name: "Confirm" });
      expect(dialog).toHaveAttribute("aria-modal", "true");
      expect(dialog).not.toHaveAttribute("aria-describedby");
    });

    it("is described by the description when one is given", () => {
      render(<ControlledDialog open onOpenChange={vi.fn()} description="This cannot be undone." />);
      const dialog = screen.getByRole("dialog", { name: "Confirm" });
      expect(dialog).toHaveAccessibleDescription("This cannot be undone.");
      expect(dialog.getAttribute("aria-describedby")).toBe(screen.getByText("This cannot be undone.").id);
    });

    it("two dialogs on one page have no duplicate ids", () => {
      render(
        <>
          <ControlledDialog open onOpenChange={vi.fn()} description="one" />
          <Dialog open onOpenChange={vi.fn()} title="Other" description="two">
            <span>body</span>
          </Dialog>
        </>,
      );
      const ids = Array.from(document.querySelectorAll("[id]")).map((element) => element.id);
      expect(new Set(ids).size).toBe(ids.length);
    });
  });

  describe("focus", () => {
    it("moves focus to the first tabbable element on open", () => {
      render(<ControlledDialog open onOpenChange={vi.fn()} />);
      expect(screen.getByRole("button", { name: "First" })).toHaveFocus();
    });

    it("focuses the dialog itself when it has no tabbable elements", () => {
      render(
        <Dialog open onOpenChange={vi.fn()} title="Empty">
          <p>Nothing to press</p>
        </Dialog>,
      );
      expect(screen.getByRole("dialog")).toHaveFocus();
    });

    it("skips disabled buttons and tabindex=-1 elements when choosing the first tabbable", () => {
      render(
        <Dialog open onOpenChange={vi.fn()} title="Skip">
          <button disabled>Disabled</button>
          <div tabIndex={-1}>Not tabbable</div>
          <button>Real</button>
        </Dialog>,
      );
      expect(screen.getByRole("button", { name: "Real" })).toHaveFocus();
    });

    it("focuses the first tab when Tabs have no defaultValue and come before other content", async () => {
      render(
        <Dialog open title="Confirm" onOpenChange={vi.fn()}>
          <Tabs>
            <TabList aria-label="Sections">
              <Tab value="a">Tab A</Tab>
              <Tab value="b">Tab B</Tab>
            </TabList>
            <TabPanel value="a">Panel A</TabPanel>
            <TabPanel value="b">Panel B</TabPanel>
          </Tabs>
          <button>after</button>
        </Dialog>,
      );
      await waitFor(() => expect(screen.getByRole("tab", { name: "Tab A" })).toHaveFocus());
    });

    it("focuses the first enabled tab when defaultValue names a disabled tab", async () => {
      render(
        <Dialog open title="Confirm" onOpenChange={vi.fn()}>
          <Tabs defaultValue="a">
            <TabList aria-label="Sections">
              <Tab value="a" disabled>
                Tab A
              </Tab>
              <Tab value="b">Tab B</Tab>
            </TabList>
            <TabPanel value="a">Panel A</TabPanel>
            <TabPanel value="b">Panel B</TabPanel>
          </Tabs>
          <button>after</button>
        </Dialog>,
      );
      await waitFor(() => expect(screen.getByRole("tab", { name: "Tab B" })).toHaveFocus());
    });

    it("focuses the selected tab on open when Tabs come before other content in the dialog", () => {
      render(
        <Dialog open title="Confirm" onOpenChange={vi.fn()}>
          <Tabs defaultValue="a">
            <TabList aria-label="Sections">
              <Tab value="a">Tab A</Tab>
              <Tab value="b">Tab B</Tab>
            </TabList>
            <TabPanel value="a">Panel A</TabPanel>
            <TabPanel value="b">Panel B</TabPanel>
          </Tabs>
          <button>after</button>
        </Dialog>,
      );
      expect(screen.getByRole("tab", { name: "Tab A" })).toHaveFocus();
    });

    it("skips elements in hidden subtrees and input[type=hidden] when choosing the first tabbable", () => {
      render(
        <Dialog open title="Confirm" onOpenChange={vi.fn()}>
          <div hidden>
            <button>Hidden</button>
          </div>
          <input type="hidden" name="token" />
          <button>Real</button>
        </Dialog>,
      );
      expect(screen.getByRole("button", { name: "Real" })).toHaveFocus();
    });

    it("Tab from the last visible tabbable wraps inside when a Tabs panel is hidden", async () => {
      const user = userEvent.setup();
      render(
        <Dialog open title="Confirm" onOpenChange={vi.fn()}>
          <Tabs defaultValue="a">
            <TabList aria-label="Sections">
              <Tab value="a">Tab A</Tab>
              <Tab value="b">Tab B</Tab>
            </TabList>
            <TabPanel value="a">
              <button>Visible</button>
            </TabPanel>
            <TabPanel value="b">
              <button>Hidden panel</button>
            </TabPanel>
          </Tabs>
        </Dialog>,
      );
      screen.getByRole("button", { name: "Visible" }).focus();
      await user.tab();
      expect(screen.getByRole("tab", { name: "Tab A" })).toHaveFocus();
    });

    it("wraps Tab from the last tabbable to the first", async () => {
      const user = userEvent.setup();
      render(<ControlledDialog open onOpenChange={vi.fn()} />);
      await user.tab();
      expect(screen.getByRole("button", { name: "Second" })).toHaveFocus();
      await user.tab();
      expect(screen.getByRole("button", { name: "First" })).toHaveFocus();
    });

    it("wraps Shift+Tab from the first tabbable to the last", async () => {
      const user = userEvent.setup();
      render(<ControlledDialog open onOpenChange={vi.fn()} />);
      await user.tab({ shift: true });
      expect(screen.getByRole("button", { name: "Second" })).toHaveFocus();
    });

    it("keeps focus on the dialog when it has no tabbables, for Tab and Shift+Tab", async () => {
      const user = userEvent.setup();
      render(
        <Dialog open onOpenChange={vi.fn()} title="Empty">
          <p>Nothing to press</p>
        </Dialog>,
      );
      await user.tab();
      expect(screen.getByRole("dialog")).toHaveFocus();
      await user.tab({ shift: true });
      expect(screen.getByRole("dialog")).toHaveFocus();
    });

    it("Shift+Tab with focus on the dialog container goes to the last tabbable", async () => {
      const user = userEvent.setup();
      render(<ControlledDialog open onOpenChange={vi.fn()} />);
      screen.getByRole("dialog").focus();
      await user.tab({ shift: true });
      expect(screen.getByRole("button", { name: "Second" })).toHaveFocus();
    });

    it("returns focus to the previously focused element when closed", async () => {
      const user = userEvent.setup();
      render(<Harness initialOpen={false} />);
      const opener = screen.getByRole("button", { name: "Open" });
      opener.focus();
      await user.click(opener);
      expect(screen.getByRole("button", { name: "Ok" })).toHaveFocus();

      await user.keyboard("{Escape}");
      expect(screen.queryByRole("dialog")).not.toBeInTheDocument();
      expect(opener).toHaveFocus();
    });

    it("returns focus when the dialog unmounts while open", () => {
      const opener = document.createElement("button");
      document.body.appendChild(opener);
      opener.focus();
      const { rerender } = render(<ControlledDialog open onOpenChange={vi.fn()} />);
      expect(screen.getByRole("button", { name: "First" })).toHaveFocus();
      rerender(<></>);
      expect(opener).toHaveFocus();
      opener.remove();
    });
  });

  describe("closing", () => {
    it("Escape calls onOpenChange(false)", async () => {
      const user = userEvent.setup();
      const onOpenChange = vi.fn();
      render(<ControlledDialog open onOpenChange={onOpenChange} />);
      await user.keyboard("{Escape}");
      expect(onOpenChange).toHaveBeenCalledWith(false);
    });

    it("Escape while a nested element is focused still closes", async () => {
      const user = userEvent.setup();
      const onOpenChange = vi.fn();
      render(<ControlledDialog open onOpenChange={onOpenChange} />);
      screen.getByRole("button", { name: "Second" }).focus();
      await user.keyboard("{Escape}");
      expect(onOpenChange).toHaveBeenCalledWith(false);
    });

    it("a click on the backdrop calls onOpenChange(false)", async () => {
      const user = userEvent.setup();
      const onOpenChange = vi.fn();
      render(<ControlledDialog open onOpenChange={onOpenChange} />);
      await user.click(backdropOf(screen.getByRole("dialog")));
      expect(onOpenChange).toHaveBeenCalledWith(false);
    });

    it("clicks inside the dialog do not close it", async () => {
      const user = userEvent.setup();
      const onOpenChange = vi.fn();
      render(<ControlledDialog open onOpenChange={onOpenChange} description="Body text" />);
      await user.click(screen.getByText("Body text"));
      await user.click(screen.getByRole("button", { name: "Second" }));
      expect(onOpenChange).not.toHaveBeenCalled();
    });

    it("a drag that starts inside the dialog and ends on the backdrop does not close", async () => {
      const user = userEvent.setup();
      const onOpenChange = vi.fn();
      render(<ControlledDialog open onOpenChange={onOpenChange} />);
      const dialog = screen.getByRole("dialog");
      await user.pointer([
        { keys: "[MouseLeft>]", target: screen.getByRole("button", { name: "First" }) },
        { target: backdropOf(dialog) },
        { keys: "[/MouseLeft]", target: backdropOf(dialog) },
      ]);
      expect(onOpenChange).not.toHaveBeenCalled();
    });

    it("a mouse press on the backdrop keeps focus inside, so Tab stays in the dialog", async () => {
      const user = userEvent.setup();
      render(<ControlledDialog open onOpenChange={vi.fn()} />);
      const dialog = screen.getByRole("dialog");
      await user.pointer([
        { keys: "[MouseLeft>]", target: backdropOf(dialog) },
        { keys: "[/MouseLeft]", target: dialog },
      ]);
      await user.tab();
      expect(dialog.contains(document.activeElement)).toBe(true);
    });

    it("Escape inside a nested dialog does not reach the outer dialog", async () => {
      const user = userEvent.setup();
      const outer = vi.fn();
      const inner = vi.fn();
      function Nested() {
        const [innerOpen, setInnerOpen] = useState(true);
        return (
          <Dialog open title="Outer" onOpenChange={outer}>
            <button>Outer button</button>
            <Dialog
              open={innerOpen}
              title="Inner"
              onOpenChange={(next) => {
                inner(next);
                setInnerOpen(next);
              }}
            >
              <button>Inner button</button>
            </Dialog>
          </Dialog>
        );
      }
      render(<Nested />);
      screen.getByRole("button", { name: "Inner button" }).focus();
      await user.keyboard("{Escape}");
      expect(inner).toHaveBeenCalledWith(false);
      expect(outer).not.toHaveBeenCalled();
    });

    it("Tab inside a nested dialog does not reach the outer dialog's focus trap", async () => {
      const user = userEvent.setup();
      render(
        <Dialog open title="Outer" onOpenChange={vi.fn()}>
          <button>Outer button</button>
          <Dialog open title="Inner" onOpenChange={vi.fn()}>
            <button>Inner button</button>
          </Dialog>
        </Dialog>,
      );
      const inner = screen.getByRole("button", { name: "Inner button" });
      inner.focus();
      await user.tab();
      expect(inner).toHaveFocus();
    });

    it("Escape and Tab still work after the focused element removes itself", async () => {
      const user = userEvent.setup();
      const onOpenChange = vi.fn();
      function SelfRemoving() {
        const [shown, setShown] = useState(true);
        return (
          <Dialog open title="Confirm" onOpenChange={onOpenChange}>
            {shown && <button onClick={() => setShown(false)}>Remove me</button>}
            <button>Other</button>
          </Dialog>
        );
      }
      render(<SelfRemoving />);
      await user.click(screen.getByRole("button", { name: "Remove me" }));
      expect(document.activeElement).toBe(document.body);
      await user.keyboard("{Escape}");
      expect(onOpenChange).toHaveBeenCalledWith(false);
      await user.tab();
      expect(screen.getByRole("button", { name: "Other" })).toHaveFocus();
    });

    it("stays open when the parent ignores onOpenChange (controlled)", async () => {
      const user = userEvent.setup();
      const onOpenChange = vi.fn();
      render(<ControlledDialog open onOpenChange={onOpenChange} />);
      await user.keyboard("{Escape}");
      expect(onOpenChange).toHaveBeenCalledWith(false);
      expect(screen.getByRole("dialog")).toBeInTheDocument();
    });
  });
});

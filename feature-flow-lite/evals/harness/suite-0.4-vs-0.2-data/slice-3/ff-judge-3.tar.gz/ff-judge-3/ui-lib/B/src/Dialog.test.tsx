import { render, screen } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { useState, type ReactNode } from "react";
import { describe, expect, it, vi } from "vitest";
import { Combobox } from "./Combobox";
import { Dialog } from "./Dialog";

// Renders an opener button that toggles the dialog, so focus restoration can be exercised.
function Harness({ onOpenChange = vi.fn(), children }: { onOpenChange?: (open: boolean) => void; children?: ReactNode }) {
  const [open, setOpen] = useState(false);
  return (
    <>
      <button onClick={() => setOpen(true)}>Open</button>
      <Dialog
        open={open}
        title="Confirm"
        onOpenChange={(next) => {
          onOpenChange(next);
          setOpen(next);
        }}
      >
        {children ?? (
          <>
            <button>First</button>
            <button>Last</button>
          </>
        )}
      </Dialog>
    </>
  );
}

describe("Dialog", () => {
  it("renders nothing when closed", () => {
    render(<Dialog open={false} onOpenChange={vi.fn()} title="Hidden">Body</Dialog>);
    expect(screen.queryByRole("dialog")).not.toBeInTheDocument();
  });

  it("renders into body with labelled title and optional description", () => {
    const { container } = render(
      <Dialog open onOpenChange={vi.fn()} title="Delete" description="This cannot be undone">
        <button>OK</button>
      </Dialog>,
    );
    const dialog = screen.getByRole("dialog", { name: "Delete" });
    expect(container).toBeEmptyDOMElement();
    expect(dialog.parentElement).toBe(document.body);
    expect(dialog).toHaveAttribute("aria-modal", "true");
    expect(dialog).toHaveAccessibleDescription("This cannot be undone");
    expect(document.querySelector("[data-backdrop]")).toBeInTheDocument();
  });

  it("omits aria-describedby when there is no description", () => {
    render(<Dialog open onOpenChange={vi.fn()} title="Plain">Body</Dialog>);
    expect(screen.getByRole("dialog")).not.toHaveAttribute("aria-describedby");
  });

  it("moves focus to the first tabbable element on open", async () => {
    const user = userEvent.setup();
    render(<Harness />);
    await user.click(screen.getByRole("button", { name: "Open" }));
    expect(screen.getByRole("button", { name: "First" })).toHaveFocus();
  });

  it("focuses the dialog itself when it has no tabbable elements", async () => {
    const user = userEvent.setup();
    render(<Harness>{<p>Only text</p>}</Harness>);
    await user.click(screen.getByRole("button", { name: "Open" }));
    const dialog = screen.getByRole("dialog");
    expect(dialog).toHaveFocus();
    await user.tab();
    expect(dialog).toHaveFocus();
    await user.tab({ shift: true });
    expect(dialog).toHaveFocus();
  });

  it("wraps Tab from the last tabbable to the first and Shift+Tab back", async () => {
    const user = userEvent.setup();
    render(<Harness />);
    await user.click(screen.getByRole("button", { name: "Open" }));
    await user.tab();
    expect(screen.getByRole("button", { name: "Last" })).toHaveFocus();
    await user.tab();
    expect(screen.getByRole("button", { name: "First" })).toHaveFocus();
    await user.tab({ shift: true });
    expect(screen.getByRole("button", { name: "Last" })).toHaveFocus();
  });

  it("skips disabled, tabindex=-1 and hidden elements in the focus trap", async () => {
    const user = userEvent.setup();
    render(
      <Harness>
        <button>First</button>
        <button disabled>Disabled</button>
        <button tabIndex={-1}>Negative</button>
        <button hidden>Hidden</button>
        <button>Last</button>
      </Harness>,
    );
    await user.click(screen.getByRole("button", { name: "Open" }));
    await user.tab();
    expect(screen.getByRole("button", { name: "Last" })).toHaveFocus();
    await user.tab();
    expect(screen.getByRole("button", { name: "First" })).toHaveFocus();
  });

  it("closes on Escape through onOpenChange", async () => {
    const user = userEvent.setup();
    const onOpenChange = vi.fn();
    render(<Harness onOpenChange={onOpenChange} />);
    await user.click(screen.getByRole("button", { name: "Open" }));
    await user.keyboard("{Escape}");
    expect(onOpenChange).toHaveBeenCalledWith(false);
    expect(screen.queryByRole("dialog")).not.toBeInTheDocument();
  });

  it("stays open when the parent ignores onOpenChange", async () => {
    const user = userEvent.setup();
    const onOpenChange = vi.fn();
    render(<Dialog open onOpenChange={onOpenChange} title="Sticky"><button>OK</button></Dialog>);
    await user.keyboard("{Escape}");
    expect(onOpenChange).toHaveBeenCalledWith(false);
    expect(screen.getByRole("dialog")).toBeInTheDocument();
  });

  it("closes on backdrop click but not on content click", async () => {
    const user = userEvent.setup();
    const onOpenChange = vi.fn();
    render(<Harness onOpenChange={onOpenChange} />);
    await user.click(screen.getByRole("button", { name: "Open" }));
    await user.click(screen.getByRole("button", { name: "First" }));
    expect(onOpenChange).not.toHaveBeenCalled();
    await user.click(document.querySelector("[data-backdrop]") as HTMLElement);
    expect(onOpenChange).toHaveBeenCalledWith(false);
  });

  it("does not close when a press starts inside and ends on the backdrop", async () => {
    const user = userEvent.setup();
    const onOpenChange = vi.fn();
    render(<Harness onOpenChange={onOpenChange} />);
    await user.click(screen.getByRole("button", { name: "Open" }));
    const backdrop = document.querySelector("[data-backdrop]") as HTMLElement;
    await user.pointer([
      { keys: "[MouseLeft>]", target: screen.getByRole("button", { name: "First" }) },
      { target: backdrop },
      { keys: "[/MouseLeft]", target: backdrop },
    ]);
    expect(onOpenChange).not.toHaveBeenCalled();
    expect(screen.getByRole("dialog")).toBeInTheDocument();
  });

  it("restores focus to the opener when closed", async () => {
    const user = userEvent.setup();
    render(<Harness />);
    const opener = screen.getByRole("button", { name: "Open" });
    await user.click(opener);
    await user.keyboard("{Escape}");
    expect(opener).toHaveFocus();
  });

  it("restores focus to the original opener after quick close and reopen", async () => {
    const { rerender } = render(<Dialog open={false} onOpenChange={vi.fn()} title="T"><button>Inner</button></Dialog>);
    const opener = document.createElement("button");
    document.body.appendChild(opener);
    opener.focus();
    rerender(<Dialog open onOpenChange={vi.fn()} title="T"><button>Inner</button></Dialog>);
    rerender(<Dialog open={false} onOpenChange={vi.fn()} title="T"><button>Inner</button></Dialog>);
    rerender(<Dialog open onOpenChange={vi.fn()} title="T"><button>Inner</button></Dialog>);
    expect(screen.getByRole("button", { name: "Inner" })).toHaveFocus();
    rerender(<Dialog open={false} onOpenChange={vi.fn()} title="T"><button>Inner</button></Dialog>);
    expect(opener).toHaveFocus();
    opener.remove();
  });

  it("does not throw when the opener has been removed from the document", () => {
    const opener = document.createElement("button");
    document.body.appendChild(opener);
    opener.focus();
    const { rerender } = render(<Dialog open={false} onOpenChange={vi.fn()} title="T">x</Dialog>);
    rerender(<Dialog open onOpenChange={vi.fn()} title="T">x</Dialog>);
    opener.remove();
    expect(() => rerender(<Dialog open={false} onOpenChange={vi.fn()} title="T">x</Dialog>)).not.toThrow();
  });

  it("closes only the top dialog on Escape when dialogs are nested", async () => {
    const user = userEvent.setup();
    const onOuter = vi.fn();
    const onInner = vi.fn();
    render(
      <Dialog open onOpenChange={onOuter} title="Outer">
        <Dialog open onOpenChange={onInner} title="Inner">
          <button>Inner action</button>
        </Dialog>
      </Dialog>,
    );
    await user.click(screen.getByRole("button", { name: "Inner action" }));
    await user.keyboard("{Escape}");
    expect(onInner).toHaveBeenCalledTimes(1);
    expect(onInner).toHaveBeenCalledWith(false);
    expect(onOuter).not.toHaveBeenCalled();
  });

  it("closes only the Combobox listbox on Escape when open inside the dialog", async () => {
    const user = userEvent.setup();
    const onOpenChange = vi.fn();
    render(
      <Dialog open onOpenChange={onOpenChange} title="Pick">
        <Combobox
          label="Fruit"
          options={[{ value: "apple", label: "Apple" }]}
          value={null}
          onChange={vi.fn()}
        />
      </Dialog>,
    );
    await user.type(screen.getByRole("combobox"), "a");
    expect(screen.getByRole("listbox")).toBeInTheDocument();
    await user.keyboard("{Escape}");
    expect(screen.queryByRole("listbox")).not.toBeInTheDocument();
    expect(onOpenChange).not.toHaveBeenCalled();
    await user.keyboard("{Escape}");
    expect(onOpenChange).toHaveBeenCalledWith(false);
  });

  it("keeps focus inside when the backdrop is clicked and the parent ignores onOpenChange", async () => {
    const user = userEvent.setup();
    const onOpenChange = vi.fn();
    render(<Dialog open onOpenChange={onOpenChange} title="Sticky"><button>OK</button></Dialog>);
    await user.click(document.querySelector("[data-backdrop]") as HTMLElement);
    expect(onOpenChange).toHaveBeenCalledWith(false);
    expect(screen.getByRole("button", { name: "OK" })).toHaveFocus();
    await user.keyboard("{Escape}");
    expect(onOpenChange).toHaveBeenCalledTimes(2);
    expect(onOpenChange).toHaveBeenLastCalledWith(false);
  });

  it("applies backdropClassName to the backdrop and keeps data-backdrop", () => {
    render(<Dialog open onOpenChange={vi.fn()} title="Scrim" backdropClassName="scrim">Body</Dialog>);
    const backdrop = document.querySelector("[data-backdrop]");
    expect(backdrop).toHaveClass("scrim");
    expect(screen.getByRole("dialog")).not.toHaveClass("scrim");
  });

  it("calls a consumer onMouseDown and still treats the press as inside", async () => {
    const user = userEvent.setup();
    const onMouseDown = vi.fn();
    const onOpenChange = vi.fn();
    render(
      <Dialog open onOpenChange={onOpenChange} title="Press" onMouseDown={onMouseDown}>
        <button>OK</button>
      </Dialog>,
    );
    const backdrop = document.querySelector("[data-backdrop]") as HTMLElement;
    await user.pointer([
      { keys: "[MouseLeft>]", target: screen.getByRole("button", { name: "OK" }) },
      { target: backdrop },
      { keys: "[/MouseLeft]", target: backdrop },
    ]);
    expect(onMouseDown).toHaveBeenCalledTimes(1);
    expect(onOpenChange).not.toHaveBeenCalled();
  });

  it("renders a description of 0 inside the description paragraph", () => {
    render(<Dialog open onOpenChange={vi.fn()} title="Count" description={0}>Body</Dialog>);
    expect(screen.getByRole("dialog")).toHaveAccessibleDescription("0");
    expect(screen.getByText("0").tagName).toBe("P");
  });
});

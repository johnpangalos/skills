import { useId, useLayoutEffect, useRef, type HTMLAttributes, type KeyboardEvent, type ReactNode } from "react";
import { createPortal } from "react-dom";

const TABBABLE_SELECTOR = "a[href], button, input, select, textarea, [tabindex], [contenteditable='true']";

function getTabbables(container: HTMLElement): HTMLElement[] {
  const candidates = container.querySelectorAll<HTMLElement>(TABBABLE_SELECTOR);
  return [...candidates].filter(
    (element) =>
      element.tabIndex >= 0 &&
      !element.matches(":disabled") &&
      !element.closest("[hidden]") &&
      !element.matches("input[type=hidden]"),
  );
}

// Open dialogs in the order they opened; the last one is topmost.
const openDialogs: HTMLElement[] = [];

function keepFocusInside(event: { shiftKey: boolean; preventDefault: () => void }, dialog: HTMLElement) {
  const tabbables = getTabbables(dialog);
  if (tabbables.length === 0) {
    event.preventDefault();
    dialog.focus();
    return;
  }
  // -1 when focus is on the dialog container itself (or outside it).
  const index = tabbables.indexOf(document.activeElement as HTMLElement);
  const last = tabbables.length - 1;
  if (event.shiftKey) {
    if (index <= 0) {
      event.preventDefault();
      tabbables[last].focus();
    }
  } else if (index === -1 || index === last) {
    event.preventDefault();
    tabbables[0].focus();
  }
}

export type DialogProps = Omit<HTMLAttributes<HTMLDivElement>, "title"> & {
  open: boolean;
  /** Called with the requested state when Escape or a backdrop click should change it. */
  onOpenChange: (open: boolean) => void;
  title: ReactNode;
  description?: ReactNode;
};

export function Dialog({
  open,
  onOpenChange,
  title,
  description,
  children,
  onKeyDown,
  ...props
}: DialogProps) {
  const titleId = useId();
  const descriptionId = useId();
  const dialogRef = useRef<HTMLDivElement>(null);
  const pressedBackdrop = useRef(false);
  const onOpenChangeRef = useRef(onOpenChange);
  onOpenChangeRef.current = onOpenChange;

  useLayoutEffect(() => {
    if (!open) return;
    const opener = document.activeElement instanceof HTMLElement ? document.activeElement : null;
    const dialog = dialogRef.current;
    if (!dialog) return;
    let mounted = true;
    const initial = getTabbables(dialog)[0] ?? dialog;
    initial.focus();
    // Children such as Tabs re-render after this layout effect and can change the first tabbable, so
    // re-check once that render has committed. Focus that the user moved elsewhere is left alone.
    queueMicrotask(() => {
      if (!mounted) return;
      if (document.activeElement === initial || document.activeElement === document.body) {
        (getTabbables(dialog)[0] ?? dialog).focus();
      }
    });
    // Keys reach the document when focus was lost (e.g. the focused element was removed), so Escape and
    // Tab are also handled here, by the topmost dialog only.
    const onDocumentKeyDown = (event: globalThis.KeyboardEvent) => {
      if (openDialogs[openDialogs.length - 1] !== dialog) return;
      if (event.key === "Escape") {
        event.preventDefault();
        onOpenChangeRef.current(false);
      } else if (event.key === "Tab") {
        keepFocusInside(event, dialog);
      }
    };
    openDialogs.push(dialog);
    document.addEventListener("keydown", onDocumentKeyDown);
    return () => {
      mounted = false;
      document.removeEventListener("keydown", onDocumentKeyDown);
      openDialogs.splice(openDialogs.indexOf(dialog), 1);
      if (opener?.isConnected) opener.focus();
    };
  }, [open]);

  if (!open) return null;

  const handleKeyDown = (event: KeyboardEvent<HTMLDivElement>) => {
    onKeyDown?.(event);
    // Stop here so an enclosing dialog never handles the same key.
    if (event.key === "Escape") {
      event.preventDefault();
      event.stopPropagation();
      onOpenChange(false);
    } else if (event.key === "Tab" && dialogRef.current) {
      event.stopPropagation();
      keepFocusInside(event, dialogRef.current);
    }
  };

  return createPortal(
    <div
      data-backdrop=""
      onMouseDown={(event) => {
        pressedBackdrop.current = event.target === event.currentTarget;
        // Keep focus where it is so a backdrop press cannot move it out of the dialog.
        if (pressedBackdrop.current) event.preventDefault();
      }}
      onClick={(event) => {
        if (pressedBackdrop.current && event.target === event.currentTarget) onOpenChange(false);
      }}
    >
      <div
        {...props}
        ref={dialogRef}
        role="dialog"
        aria-modal="true"
        aria-labelledby={titleId}
        aria-describedby={description != null ? descriptionId : undefined}
        tabIndex={-1}
        onKeyDown={handleKeyDown}
      >
        <h2 id={titleId}>{title}</h2>
        {description != null && <p id={descriptionId}>{description}</p>}
        {children}
      </div>
    </div>,
    document.body,
  );
}

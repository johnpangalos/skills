import { render, screen } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { useState } from "react";
import { Combobox, type ComboboxOption } from "./Combobox";

const FRUITS: ComboboxOption[] = [
  { value: "apple", label: "Apple" },
  { value: "banana", label: "Banana", disabled: true },
  { value: "cherry", label: "Cherry" },
  { value: "apricot", label: "Apricot" },
];

function Harness({
  options = FRUITS,
  initial = null,
  onChange,
}: {
  options?: ComboboxOption[];
  initial?: string | null;
  onChange: (value: string | null) => void;
}) {
  const [value, setValue] = useState<string | null>(initial);
  return (
    <form onSubmit={(event) => event.preventDefault()}>
      <Combobox
        label="Fruit"
        placeholder="Pick a fruit"
        options={options}
        value={value}
        onChange={(next) => {
          setValue(next);
          onChange(next);
        }}
      />
    </form>
  );
}

const input = () => screen.getByRole("combobox", { name: "Fruit" });
const optionNames = () => screen.queryAllByRole("option").map((option) => option.textContent);

describe("Combobox", () => {
  it("wires label, input, listbox and ARIA attributes", () => {
    render(<Harness onChange={vi.fn()} />);
    const field = input();
    expect(field).toHaveAttribute("aria-expanded", "false");
    expect(field).toHaveAttribute("aria-autocomplete", "list");
    expect(field).not.toHaveAttribute("aria-activedescendant");
    expect(field).toHaveAttribute("placeholder", "Pick a fruit");

    const listbox = screen.getByRole("listbox", { hidden: true });
    expect(field).toHaveAttribute("aria-controls", listbox.id);
    expect(listbox).toHaveAttribute("aria-labelledby", screen.getByText("Fruit").id);
  });

  it("gives each instance unique ids", () => {
    render(
      <>
        <Harness onChange={vi.fn()} />
        <Harness onChange={vi.fn()} />
      </>,
    );
    const ids = screen.getAllByRole("combobox").map((element) => element.id);
    const listboxIds = screen.getAllByRole("listbox", { hidden: true }).map((element) => element.id);
    expect(new Set([...ids, ...listboxIds]).size).toBe(4);
  });

  it("shows the selected label in the input and updates when the value prop changes", () => {
    const { rerender } = render(<Harness initial="cherry" onChange={vi.fn()} />);
    expect(input()).toHaveValue("Cherry");

    rerender(
      <Combobox label="Fruit" options={FRUITS} value="apple" onChange={vi.fn()} />,
    );
    expect(input()).toHaveValue("Apple");
  });

  it("shows empty text when the value is not among the options", () => {
    render(<Combobox label="Fruit" options={FRUITS} value="kiwi" onChange={vi.fn()} />);
    expect(input()).toHaveValue("");
  });

  it("opens and filters options case-insensitively by substring when typing", async () => {
    const user = userEvent.setup();
    render(<Harness onChange={vi.fn()} />);

    await user.type(input(), "AP");
    expect(input()).toHaveAttribute("aria-expanded", "true");
    expect(optionNames()).toEqual(["Apple", "Apricot"]);

    await user.clear(input());
    expect(optionNames()).toEqual(["Apple", "Banana", "Cherry", "Apricot"]);

    await user.type(input(), "an");
    expect(optionNames()).toEqual(["Banana"]);
  });

  it("matches special regex characters literally", async () => {
    const user = userEvent.setup();
    render(<Harness onChange={vi.fn()} />);

    await user.type(input(), ".*");
    expect(optionNames()).toEqual([]);
    expect(screen.getByRole("status")).toHaveTextContent("No results");

    await user.clear(input());
    await user.type(input(), "[[");
    expect(optionNames()).toEqual([]);

    await user.clear(input());
    await user.type(input(), "(");
    expect(screen.getByRole("status")).toHaveTextContent("No results");
  });

  it("shows a No results message and no active option when nothing matches", async () => {
    const user = userEvent.setup();
    render(<Harness onChange={vi.fn()} />);

    await user.type(input(), "zzz");
    expect(screen.getByRole("status")).toHaveTextContent("No results");
    expect(screen.queryAllByRole("option")).toHaveLength(0);
    expect(input()).not.toHaveAttribute("aria-activedescendant");
  });

  it("moves the active option with ArrowDown and ArrowUp, skipping disabled and wrapping", async () => {
    const user = userEvent.setup();
    render(<Harness onChange={vi.fn()} />);
    await user.click(input());

    await user.keyboard("{ArrowDown}");
    expect(input()).toHaveAttribute("aria-expanded", "true");
    expect(input()).toHaveAttribute("aria-activedescendant", screen.getByRole("option", { name: "Apple" }).id);
    expect(input()).toHaveFocus();

    await user.keyboard("{ArrowDown}");
    expect(input()).toHaveAttribute("aria-activedescendant", screen.getByRole("option", { name: "Cherry" }).id);

    await user.keyboard("{ArrowDown}");
    expect(input()).toHaveAttribute("aria-activedescendant", screen.getByRole("option", { name: "Apricot" }).id);

    await user.keyboard("{ArrowDown}");
    expect(input()).toHaveAttribute("aria-activedescendant", screen.getByRole("option", { name: "Apple" }).id);

    await user.keyboard("{ArrowUp}");
    expect(input()).toHaveAttribute("aria-activedescendant", screen.getByRole("option", { name: "Apricot" }).id);
  });

  it("marks disabled options and selected option", () => {
    render(<Harness initial="apple" onChange={vi.fn()} />);
    const listbox = screen.getByRole("listbox", { hidden: true });
    expect(listbox).toHaveAttribute("aria-labelledby");
    expect(screen.getByRole("option", { hidden: true, name: "Apple" })).toHaveAttribute("aria-selected", "true");
    expect(screen.getByRole("option", { hidden: true, name: "Banana" })).toHaveAttribute("aria-disabled", "true");
  });

  it("selects the active option with Enter and closes", async () => {
    const user = userEvent.setup();
    const onChange = vi.fn();
    render(<Harness onChange={onChange} />);
    await user.click(input());

    await user.keyboard("{ArrowDown}{ArrowDown}{Enter}");
    expect(onChange).toHaveBeenCalledTimes(1);
    expect(onChange).toHaveBeenCalledWith("cherry");
    expect(input()).toHaveValue("Cherry");
    expect(input()).toHaveAttribute("aria-expanded", "false");
    expect(input()).not.toHaveAttribute("aria-activedescendant");
  });

  it("does nothing on Enter without an active option and does not submit the form", async () => {
    const user = userEvent.setup();
    const onChange = vi.fn();
    const onSubmit = vi.fn();
    render(
      <form onSubmit={(event) => {
        event.preventDefault();
        onSubmit();
      }}>
        <Combobox label="Fruit" options={FRUITS} value={null} onChange={onChange} />
      </form>,
    );

    await user.type(input(), "ch");
    await user.keyboard("{Enter}");
    expect(onChange).not.toHaveBeenCalled();
    expect(onSubmit).not.toHaveBeenCalled();
    expect(input()).toHaveValue("ch");
    expect(input()).toHaveAttribute("aria-expanded", "true");
  });

  it("selects an enabled option on click and closes", async () => {
    const user = userEvent.setup();
    const onChange = vi.fn();
    render(<Harness onChange={onChange} />);

    await user.type(input(), "c");
    await user.click(screen.getByRole("option", { name: "Cherry" }));
    expect(onChange).toHaveBeenCalledWith("cherry");
    expect(input()).toHaveValue("Cherry");
    expect(input()).toHaveAttribute("aria-expanded", "false");
    expect(input()).toHaveFocus();
  });

  it("ignores clicks on disabled options and keeps the popup open", async () => {
    const user = userEvent.setup();
    const onChange = vi.fn();
    render(<Harness onChange={onChange} />);

    await user.type(input(), "an");
    await user.click(screen.getByRole("option", { name: "Banana" }));
    expect(onChange).not.toHaveBeenCalled();
    expect(input()).toHaveAttribute("aria-expanded", "true");
    expect(input()).toHaveFocus();
  });

  it("closes on Escape without selecting and restores the selected label", async () => {
    const user = userEvent.setup();
    const onChange = vi.fn();
    render(<Harness initial="apple" onChange={onChange} />);
    expect(input()).toHaveValue("Apple");

    await user.clear(input());
    await user.type(input(), "ch");
    await user.keyboard("{ArrowDown}{Escape}");
    expect(onChange).not.toHaveBeenCalled();
    expect(input()).toHaveAttribute("aria-expanded", "false");
    expect(input()).toHaveValue("Apple");
    expect(input()).not.toHaveAttribute("aria-activedescendant");
  });

  it("clears the input back to empty on Escape when nothing is selected", async () => {
    const user = userEvent.setup();
    render(<Harness onChange={vi.fn()} />);

    await user.type(input(), "ch");
    await user.keyboard("{Escape}");
    expect(input()).toHaveValue("");
  });

  it("closes on blur and resets text to the selected label without changing the value", async () => {
    const user = userEvent.setup();
    const onChange = vi.fn();
    render(<Harness initial="banana" onChange={onChange} />);

    await user.clear(input());
    await user.type(input(), "ch");
    await user.tab();
    expect(input()).toHaveAttribute("aria-expanded", "false");
    expect(input()).toHaveValue("Banana");
    expect(onChange).not.toHaveBeenCalled();
  });

  it("calls onChange(null) once when cleared text is blurred", async () => {
    const user = userEvent.setup();
    const onChange = vi.fn();
    render(<Harness initial="apple" onChange={onChange} />);

    await user.clear(input());
    await user.tab();
    expect(input()).toHaveValue("");
    expect(onChange).toHaveBeenCalledTimes(1);
    expect(onChange).toHaveBeenCalledWith(null);
  });

  it("drops the active option when the filter removes it", async () => {
    const user = userEvent.setup();
    render(<Harness onChange={vi.fn()} />);

    await user.type(input(), "a");
    await user.keyboard("{ArrowDown}");
    expect(input()).toHaveAttribute("aria-activedescendant");

    await user.type(input(), "zz");
    expect(input()).not.toHaveAttribute("aria-activedescendant");
    expect(screen.getByRole("status")).toHaveTextContent("No results");
  });

  it("never sets an active option when every option is disabled", async () => {
    const user = userEvent.setup();
    const onChange = vi.fn();
    const options = [{ value: "a", label: "Alpha", disabled: true }];
    render(<Harness options={options} onChange={onChange} />);
    await user.click(input());

    await user.keyboard("{ArrowDown}");
    expect(input()).not.toHaveAttribute("aria-activedescendant");
    expect(input()).toHaveAttribute("aria-expanded", "true");

    await user.keyboard("{Enter}");
    expect(onChange).not.toHaveBeenCalled();
  });

  it("keeps the value distinct for options with duplicate labels", async () => {
    const user = userEvent.setup();
    const onChange = vi.fn();
    const options = [
      { value: "1", label: "Same" },
      { value: "2", label: "Same" },
    ];
    render(<Harness options={options} initial="2" onChange={onChange} />);
    expect(input()).toHaveValue("Same");
    expect(screen.getAllByRole("option", { hidden: true })[1]).toHaveAttribute("aria-selected", "true");

    await user.click(input());
    await user.keyboard("{ArrowDown}");
    await user.click(screen.getAllByRole("option")[0]);
    expect(onChange).toHaveBeenCalledWith("1");
    expect(input()).toHaveValue("Same");
  });

  it("calls onChange(null) once when cleared text is confirmed with Enter, and not again on blur", async () => {
    const user = userEvent.setup();
    const onChange = vi.fn();
    render(<Harness initial="apple" onChange={onChange} />);

    await user.clear(input());
    await user.keyboard("{Enter}");
    expect(onChange).toHaveBeenCalledTimes(1);
    expect(onChange).toHaveBeenCalledWith(null);
    expect(input()).toHaveValue("");
    expect(input()).toHaveAttribute("aria-expanded", "false");

    await user.tab();
    expect(onChange).toHaveBeenCalledTimes(1);
  });

  it("does not call onChange for cleared text when no value was selected", async () => {
    const user = userEvent.setup();
    const onChange = vi.fn();
    render(<Harness onChange={onChange} />);

    await user.type(input(), "a");
    await user.clear(input());
    await user.keyboard("{Enter}");
    await user.tab();
    expect(onChange).not.toHaveBeenCalled();
  });

  it("opens the listbox when the input is clicked", async () => {
    const user = userEvent.setup();
    render(<Harness onChange={vi.fn()} />);
    expect(input()).toHaveAttribute("aria-expanded", "false");

    await user.click(input());
    expect(input()).toHaveAttribute("aria-expanded", "true");
    expect(optionNames()).toEqual(["Apple", "Banana", "Cherry", "Apricot"]);
  });
});

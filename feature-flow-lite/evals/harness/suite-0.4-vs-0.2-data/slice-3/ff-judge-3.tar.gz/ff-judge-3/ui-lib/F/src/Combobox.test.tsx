import { fireEvent, render, screen } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { useState } from "react";
import { describe, expect, it, vi } from "vitest";
import { Combobox, type ComboboxOption, type ComboboxProps } from "./Combobox";
import { Dialog } from "./Dialog";

const fruits: ComboboxOption[] = [
  { value: "apple", label: "Apple" },
  { value: "banana", label: "Banana", disabled: true },
  { value: "blueberry", label: "Blueberry" },
  { value: "cherry", label: "Cherry" },
];

function ui(props: Partial<ComboboxProps> = {}) {
  return <Combobox label="Fruit" options={fruits} value={null} onChange={vi.fn()} placeholder="Pick a fruit" {...props} />;
}

// Parent that owns the value, as a real consumer would.
function Stateful({
  onChange,
  initial = null,
  items = fruits,
}: {
  onChange: (value: string | null) => void;
  initial?: string | null;
  items?: ComboboxOption[];
}) {
  const [value, setValue] = useState<string | null>(initial);
  return (
    <Combobox
      label="Fruit"
      options={items}
      value={value}
      placeholder="Pick a fruit"
      onChange={(next) => {
        onChange(next);
        setValue(next);
      }}
    />
  );
}

const input = () => screen.getByRole("combobox") as HTMLInputElement;
const option = (name: string) => screen.getByRole("option", { name });

describe("Combobox markup", () => {
  it("labels the input and wires it to a listbox of options", async () => {
    const user = userEvent.setup();
    render(<Stateful onChange={vi.fn()} initial="cherry" />);
    const combobox = screen.getByRole("combobox", { name: "Fruit" });
    expect(combobox).toHaveAttribute("aria-autocomplete", "list");
    expect(combobox).toHaveAttribute("aria-expanded", "false");
    const listbox = document.getElementById(combobox.getAttribute("aria-controls") ?? "");
    expect(listbox).toHaveAttribute("role", "listbox");

    await user.click(combobox);
    await user.keyboard("{ArrowDown}");
    expect(combobox).toHaveAttribute("aria-expanded", "true");
    expect(screen.getByRole("listbox", { name: "Fruit" })).toBe(listbox);
    const options = screen.getAllByRole("option");
    expect(options.map((element) => element.textContent)).toEqual(["Apple", "Banana", "Blueberry", "Cherry"]);
    expect(new Set(options.map((element) => element.id)).size).toBe(4);
    expect(option("Cherry")).toHaveAttribute("aria-selected", "true");
    expect(option("Apple")).toHaveAttribute("aria-selected", "false");
    expect(option("Banana")).toHaveAttribute("aria-disabled", "true");
  });
});

describe("Combobox display and filtering", () => {
  it("shows the selected label and passes the placeholder through", () => {
    render(<Stateful onChange={vi.fn()} initial="cherry" />);
    expect(input()).toHaveValue("Cherry");
    expect(input()).toHaveAttribute("placeholder", "Pick a fruit");
  });

  it("filters options case-insensitively by substring when typing", async () => {
    const user = userEvent.setup();
    render(<Stateful onChange={vi.fn()} initial="cherry" />);
    await user.clear(input());
    await user.type(input(), "BERRY");
    expect(screen.getAllByRole("option").map((element) => element.textContent)).toEqual(["Blueberry"]);
  });

  it("resets the active option to the first enabled match when typing", async () => {
    const user = userEvent.setup();
    render(<Stateful onChange={vi.fn()} />);
    await user.click(input());
    await user.keyboard("{ArrowDown}{ArrowDown}");
    expect(input()).toHaveAttribute("aria-activedescendant", option("Blueberry").id);
    await user.keyboard("a");
    expect(input()).toHaveAttribute("aria-activedescendant", option("Apple").id);
  });

  it("lists disabled matches without making them active", async () => {
    const user = userEvent.setup();
    render(<Stateful onChange={vi.fn()} />);
    await user.click(input());
    await user.keyboard("an");
    expect(option("Banana")).toHaveAttribute("aria-disabled", "true");
    expect(input()).not.toHaveAttribute("aria-activedescendant");
  });

  it("treats regex characters in the query as literal text", async () => {
    const user = userEvent.setup();
    render(<Stateful onChange={vi.fn()} />);
    await user.click(input());
    await user.keyboard("(");
    expect(screen.getByText("No results")).toBeInTheDocument();
    await user.clear(input());
    await user.keyboard(".");
    expect(screen.getByText("No results")).toBeInTheDocument();
    expect(screen.queryAllByRole("option")).toHaveLength(0);
  });
});

describe("Combobox keyboard navigation", () => {
  it("ArrowDown opens the listbox and moves the active option, skipping disabled ones", async () => {
    const user = userEvent.setup();
    render(<Stateful onChange={vi.fn()} />);
    await user.click(input());
    await user.keyboard("{ArrowDown}");
    expect(input()).toHaveAttribute("aria-expanded", "true");
    expect(input()).toHaveAttribute("aria-activedescendant", option("Apple").id);
    await user.keyboard("{ArrowDown}");
    expect(input()).toHaveAttribute("aria-activedescendant", option("Blueberry").id);
    expect(input()).toHaveFocus();
  });

  it("ArrowUp moves the active option back and wraps from the first to the last", async () => {
    const user = userEvent.setup();
    render(<Stateful onChange={vi.fn()} />);
    await user.click(input());
    await user.keyboard("{ArrowDown}{ArrowDown}{ArrowUp}");
    expect(input()).toHaveAttribute("aria-activedescendant", option("Apple").id);
    await user.keyboard("{ArrowUp}");
    expect(input()).toHaveAttribute("aria-activedescendant", option("Cherry").id);
  });

  it("removes aria-activedescendant when the listbox closes", async () => {
    const user = userEvent.setup();
    render(<Stateful onChange={vi.fn()} />);
    await user.click(input());
    await user.keyboard("{ArrowDown}");
    expect(input()).toHaveAttribute("aria-activedescendant");
    await user.keyboard("{Escape}");
    expect(input()).not.toHaveAttribute("aria-activedescendant");
    expect(input()).toHaveAttribute("aria-expanded", "false");
  });
});

describe("Combobox selection", () => {
  it("Enter selects the active option, closes, and shows its label", async () => {
    const user = userEvent.setup();
    const onChange = vi.fn();
    render(<Stateful onChange={onChange} />);
    await user.click(input());
    await user.keyboard("{ArrowDown}{ArrowDown}{Enter}");
    expect(onChange).toHaveBeenCalledTimes(1);
    expect(onChange).toHaveBeenCalledWith("blueberry");
    expect(input()).toHaveValue("Blueberry");
    expect(input()).toHaveAttribute("aria-expanded", "false");
  });

  it("clicking an enabled option selects it", async () => {
    const user = userEvent.setup();
    const onChange = vi.fn();
    render(<Stateful onChange={onChange} />);
    await user.click(input());
    await user.keyboard("{ArrowDown}");
    await user.click(option("Cherry"));
    expect(onChange).toHaveBeenCalledWith("cherry");
    expect(input()).toHaveValue("Cherry");
    expect(input()).toHaveAttribute("aria-expanded", "false");
  });

  it("clicking a disabled option does nothing", async () => {
    const user = userEvent.setup();
    const onChange = vi.fn();
    render(<Stateful onChange={onChange} />);
    await user.click(input());
    await user.keyboard("{ArrowDown}");
    await user.click(option("Banana"));
    expect(onChange).not.toHaveBeenCalled();
    expect(input()).toHaveAttribute("aria-expanded", "true");
  });

  it("Enter with no active option does nothing and prevents default while open", async () => {
    const user = userEvent.setup();
    const onChange = vi.fn();
    render(<Stateful onChange={onChange} />);
    await user.click(input());
    await user.keyboard("zzz");
    expect(fireEvent.keyDown(input(), { key: "Enter" })).toBe(false);
    expect(onChange).not.toHaveBeenCalled();
    expect(input()).toHaveAttribute("aria-expanded", "true");
  });
});

describe("Combobox escape and blur", () => {
  it("Escape closes without calling onChange and restores the selected label", async () => {
    const user = userEvent.setup();
    const onChange = vi.fn();
    render(<Stateful onChange={onChange} initial="cherry" />);
    await user.clear(input());
    await user.type(input(), "app");
    await user.keyboard("{Escape}");
    expect(input()).toHaveValue("Cherry");
    expect(input()).toHaveAttribute("aria-expanded", "false");
    expect(onChange).not.toHaveBeenCalled();
  });

  it("Escape with nothing selected restores an empty input", async () => {
    const user = userEvent.setup();
    render(<Stateful onChange={vi.fn()} />);
    await user.type(input(), "ap");
    await user.keyboard("{Escape}");
    expect(input()).toHaveValue("");
  });

  it("blur closes the listbox and discards typed text without calling onChange", async () => {
    const user = userEvent.setup();
    const onChange = vi.fn();
    render(<Stateful onChange={onChange} />);
    await user.type(input(), "ap");
    await user.tab();
    expect(input()).toHaveValue("");
    expect(input()).toHaveAttribute("aria-expanded", "false");
    expect(onChange).not.toHaveBeenCalled();
  });

  it("blur restores the selected label without calling onChange", async () => {
    const user = userEvent.setup();
    const onChange = vi.fn();
    render(<Stateful onChange={onChange} initial="cherry" />);
    await user.clear(input());
    await user.type(input(), "app");
    await user.tab();
    expect(input()).toHaveValue("Cherry");
    expect(onChange).not.toHaveBeenCalled();
  });
});

describe("Combobox no results", () => {
  it("shows a No results message that is not an option", async () => {
    const user = userEvent.setup();
    render(<Stateful onChange={vi.fn()} />);
    await user.type(input(), "zzz");
    const message = screen.getByText("No results");
    expect(message).not.toHaveAttribute("role");
    expect(screen.queryAllByRole("option")).toHaveLength(0);
    expect(input()).not.toHaveAttribute("aria-activedescendant");
  });
});

describe("Combobox controlled value", () => {
  it("updates the displayed label when value changes from outside", () => {
    const { rerender } = render(ui({ value: "apple" }));
    expect(input()).toHaveValue("Apple");
    rerender(ui({ value: "cherry" }));
    expect(input()).toHaveValue("Cherry");
    rerender(ui({ value: null }));
    expect(input()).toHaveValue("");
  });

  it("shows an empty input when value matches no option", () => {
    render(ui({ value: "kiwi" }));
    expect(input()).toHaveValue("");
  });

  it("calls onChange(null) once when the input is emptied and Enter is pressed", async () => {
    const user = userEvent.setup();
    const onChange = vi.fn();
    render(<Stateful onChange={onChange} initial="apple" />);
    await user.clear(input());
    await user.keyboard("{Enter}");
    expect(onChange).toHaveBeenCalledTimes(1);
    expect(onChange).toHaveBeenCalledWith(null);
    expect(input()).toHaveValue("");
  });

  it("calls onChange(null) once when the emptied input is blurred", async () => {
    const user = userEvent.setup();
    const onChange = vi.fn();
    render(<Stateful onChange={onChange} initial="apple" />);
    await user.clear(input());
    await user.tab();
    expect(onChange).toHaveBeenCalledTimes(1);
    expect(onChange).toHaveBeenCalledWith(null);
  });

  it("Escape on an emptied input reverts without calling onChange", async () => {
    const user = userEvent.setup();
    const onChange = vi.fn();
    render(<Stateful onChange={onChange} initial="apple" />);
    await user.clear(input());
    await user.keyboard("{Escape}");
    expect(input()).toHaveValue("Apple");
    expect(onChange).not.toHaveBeenCalled();
  });
});

describe("Combobox hostile inputs", () => {
  it("lists all-disabled options with no active option, and Enter and click do nothing", async () => {
    const user = userEvent.setup();
    const onChange = vi.fn();
    const allDisabled = fruits.map((item) => ({ ...item, disabled: true }));
    render(<Stateful onChange={onChange} items={allDisabled} />);
    await user.click(input());
    await user.keyboard("{ArrowDown}");
    expect(screen.getAllByRole("option")).toHaveLength(4);
    expect(input()).not.toHaveAttribute("aria-activedescendant");
    await user.keyboard("{Enter}");
    await user.click(option("Apple"));
    expect(onChange).not.toHaveBeenCalled();
  });

  it("gives duplicate labels distinct ids and selects the clicked option's value", async () => {
    const user = userEvent.setup();
    const onChange = vi.fn();
    const duplicates: ComboboxOption[] = [
      { value: "a1", label: "Same" },
      { value: "a2", label: "Same" },
    ];
    render(<Stateful onChange={onChange} items={duplicates} />);
    await user.click(input());
    await user.keyboard("{ArrowDown}");
    const [first, second] = screen.getAllByRole("option");
    expect(first.id).not.toBe(second.id);
    await user.click(second);
    expect(onChange).toHaveBeenCalledWith("a2");
  });
});

describe("Combobox options changing while open", () => {
  it("Enter does nothing when the active option is removed from options", async () => {
    const user = userEvent.setup();
    const onChange = vi.fn();
    const { rerender } = render(ui({ onChange }));
    await user.click(input());
    await user.keyboard("{ArrowDown}");
    expect(option("Apple")).toHaveAttribute("data-active");

    rerender(<Combobox label="Fruit" options={[{ value: "cherry", label: "Cherry" }]} value={null} onChange={onChange} />);
    expect(input()).not.toHaveAttribute("aria-activedescendant");
    await user.keyboard("{Enter}");
    expect(onChange).not.toHaveBeenCalled();
  });

  it("Enter does nothing when the active option becomes disabled", async () => {
    const user = userEvent.setup();
    const onChange = vi.fn();
    const { rerender } = render(ui({ onChange }));
    await user.click(input());
    await user.keyboard("{ArrowDown}");

    const disabledApple: ComboboxOption[] = [{ value: "apple", label: "Apple", disabled: true }, ...fruits.slice(1)];
    rerender(<Combobox label="Fruit" options={disabledApple} value={null} onChange={onChange} />);
    expect(input()).not.toHaveAttribute("aria-activedescendant");
    await user.keyboard("{Enter}");
    expect(onChange).not.toHaveBeenCalled();
  });

  it("Enter selects the displayed active option after the options are reordered", async () => {
    const user = userEvent.setup();
    const onChange = vi.fn();
    const { rerender } = render(ui({ onChange }));
    await user.click(input());
    await user.keyboard("{ArrowDown}");

    rerender(<Combobox label="Fruit" options={[...fruits].reverse()} value={null} onChange={onChange} />);
    expect(input()).toHaveAttribute("aria-activedescendant", option("Apple").id);
    await user.keyboard("{Enter}");
    expect(onChange).toHaveBeenCalledTimes(1);
    expect(onChange).toHaveBeenCalledWith("apple");
  });
});

describe("Combobox ids, forwarding and dialogs", () => {
  it("gives two comboboxes distinct input, listbox and option ids", () => {
    render(
      <>
        {ui()}
        {ui()}
      </>,
    );
    const [first, second] = screen.getAllByRole("combobox");
    expect(first.id).not.toBe(second.id);
    expect(first.getAttribute("aria-controls")).not.toBe(second.getAttribute("aria-controls"));
    expect(first).toHaveAccessibleName("Fruit");
    expect(second).toHaveAccessibleName("Fruit");
  });

  it("forwards className and HTML props to the input", () => {
    render(<Combobox label="Fruit" options={fruits} value={null} onChange={vi.fn()} className="fruit" data-testid="fruit" />);
    expect(screen.getByTestId("fruit")).toHaveClass("fruit");
    expect(screen.getByTestId("fruit")).toBe(input());
  });

  it("Escape closes the listbox but does not close an enclosing dialog", async () => {
    const user = userEvent.setup();
    const onOpenChange = vi.fn();
    render(
      <Dialog open onOpenChange={onOpenChange} title="Pick a fruit">
        <Combobox label="Fruit" options={fruits} value={null} onChange={vi.fn()} />
      </Dialog>,
    );
    await user.type(input(), "a");
    expect(input()).toHaveAttribute("aria-expanded", "true");

    await user.keyboard("{Escape}");
    expect(input()).toHaveAttribute("aria-expanded", "false");
    expect(onOpenChange).not.toHaveBeenCalled();

    await user.keyboard("{Escape}");
    expect(onOpenChange).toHaveBeenCalledTimes(1);
    expect(onOpenChange).toHaveBeenCalledWith(false);
  });
});

# @acme/ui

Accessible React components. No CSS is shipped and no runtime dependencies beyond React and React DOM. Components forward `className` and other standard HTML props to their main element: the root `div` for Tabs, TabList and TabPanel, the `button` for Tab, the `role="dialog"` element for Dialog, and the `<input>` for Combobox.

## Setup

```sh
pnpm install
pnpm test        # vitest + jsdom + Testing Library
pnpm typecheck   # tsc --noEmit
```

Import from the package entry point:

```ts
import { Tabs, TabList, Tab, TabPanel, Dialog, Combobox } from "./src/index";
import type { ComboboxOption } from "./src/index";
```

## Tabs

Follows the WAI-ARIA tabs pattern.

```tsx
<Tabs defaultValue="profile">
  <TabList aria-label="Settings">
    <Tab value="profile">Profile</Tab>
    <Tab value="billing" disabled>Billing</Tab>
    <Tab value="team">Team</Tab>
  </TabList>
  <TabPanel value="profile">...</TabPanel>
  <TabPanel value="billing">...</TabPanel>
  <TabPanel value="team">...</TabPanel>
</Tabs>
```

### Props

- `Tabs`
  - `defaultValue?: string`: initially selected tab (uncontrolled). If absent, or it names no enabled tab, the first enabled tab is selected.
  - `value?: string`: selected tab (controlled). When set, it wins over `defaultValue`; selection changes only when the parent updates `value`.
  - `onValueChange?: (value: string) => void`: called with the new value when the user selects a different tab. Not called when the selected tab is re-selected. Fires in both modes.
  - Other `div` props are forwarded to the root element.
- `TabList`
  - `aria-label: string` (required). Renders `role="tablist"`.
  - Other `div` props are forwarded.
- `Tab`
  - `value: string` (required): identifies the tab and links it to its panel.
  - `disabled?: boolean`: renders a native disabled button. It cannot be clicked or focused with the arrow keys.
  - Other `button` props are forwarded. `type` is always `"button"`.
- `TabPanel`
  - `value: string` (required): the tab whose selection shows this panel. Unselected panels get the `hidden` attribute.
  - Other `div` props are forwarded. Panels are focusable (`tabIndex={0}`).

### Keyboard

| Key | Behavior |
| --- | --- |
| `ArrowRight` | Focus and select the next enabled tab. Wraps from last to first. |
| `ArrowLeft` | Focus and select the previous enabled tab. Wraps from first to last. |
| `Home` | Focus and select the first enabled tab. |
| `End` | Focus and select the last enabled tab. |
| `Tab` | Moves focus into the selected tab only (roving `tabIndex`). |

Handled keys call `preventDefault`. Other keys are ignored. Selection follows focus. In controlled mode the focus still moves, but the selection changes only when the parent updates `value`.

## Dialog

A modal dialog rendered into `document.body` through a portal.

```tsx
<Dialog open={open} onOpenChange={setOpen} title="Delete project" description="This cannot be undone.">
  <button onClick={() => setOpen(false)}>Cancel</button>
</Dialog>
```

### Props

- `open: boolean` (required): renders nothing when `false`.
- `onOpenChange: (open: boolean) => void` (required): called with `false` on Escape or a backdrop click. The component never closes itself.
- `title: string` (required): rendered as an `h2`. The dialog is labelled by it (`aria-labelledby`).
- `description?: string`: rendered as a `p` and referenced by `aria-describedby`. Omitted entirely when not given.
- `children`, plus other `div` props, are forwarded to the dialog element (`role="dialog"`, `aria-modal="true"`).

The backdrop is a `div[data-backdrop]` with `aria-hidden="true"`, placed as a sibling of the dialog in `document.body`.

### Behavior

- On open, focus moves to the first tabbable element inside the dialog, or to the dialog itself (`tabIndex={-1}`) if there is none.
- Focus is trapped. Tab from the last tabbable element wraps to the first, and Shift+Tab from the first (or from the dialog itself) wraps to the last. Focus that moves outside the dialog is pulled back.
- On close (or unmount), focus returns to the element that had focus before opening, if it is still in the document.
- A mousedown inside the dialog that is released on the backdrop does not close it.

### Keyboard

| Key | Behavior |
| --- | --- |
| `Escape` | Calls `onOpenChange(false)`, from any element inside the dialog or with focus on `body`. |
| `Tab` / `Shift+Tab` | Cycle focus within the dialog. |

### Nested dialogs

Dialogs stack in the order they open. Only the topmost dialog traps focus and handles Escape, so one Escape closes only the inner dialog, and focus returns to the control that opened it. A backdrop click calls the `onOpenChange` of the dialog whose backdrop was clicked, so an outer backdrop is only reachable when the inner dialog does not cover it.

## Combobox

A text input with a listbox popup, following the WAI-ARIA combobox pattern. The component is controlled: `value` is the selected option's value, or `null` for no selection.

```tsx
const [fruit, setFruit] = useState<string | null>(null);

<Combobox
  label="Fruit"
  placeholder="Type to search"
  options={[
    { value: "apple", label: "Apple" },
    { value: "banana", label: "Banana", disabled: true },
  ]}
  value={fruit}
  onChange={setFruit}
/>;
```

### Props

- `label: string` (required): rendered as a `label` associated with the input.
- `options: ComboboxOption[]` (required). `ComboboxOption` is `{ value: string; label: string; disabled?: boolean }`.
- `value: string | null` (required): the selected option's value, or `null`. A value that matches no option shows an empty input.
- `onChange: (value: string | null) => void` (required): called with the chosen option's value, or with `null` when the user clears the input and commits (see Behavior).
- `placeholder?: string` and other `input` props are forwarded to the input. `role` is always `"combobox"`.

### Behavior

- Typing opens the listbox and filters options by label: case-insensitive substring match, with regex characters treated literally. The active option becomes the first enabled match. Clearing the text leaves no active option.
- Disabled options are listed, marked `aria-disabled="true"`, and never become active or selectable.
- When nothing matches, the listbox shows "No results", which is not an `option`.
- The input displays the selected option's label while the user is not typing. Changing `value` from outside updates the displayed label.
- `aria-selected="true"` marks the committed `value`, not the active option.
- The listbox stays mounted and is hidden while closed, so `aria-controls` always resolves. `aria-activedescendant` is set only while open and an option is active.
- Clicking an option selects it. Clicks on disabled options do nothing.
- Blurring the input closes the listbox. Typed text is discarded and the label is restored.

### Keyboard

| Key | Behavior |
| --- | --- |
| Typing | Opens the listbox and filters options. The active option resets to the first enabled match. |
| `ArrowDown` | Opens the listbox if closed. Moves the active option to the next enabled option, wrapping. |
| `ArrowUp` | Opens the listbox if closed. Moves the active option to the previous enabled option, wrapping. |
| `Enter` | With an active enabled option: selects it, closes the listbox. With the input emptied and a value selected: calls `onChange(null)` and closes. Otherwise does nothing. Prevents form submission while the listbox is open. |
| `Escape` | Closes the listbox and restores the selected label (or empty input). Does not call `onChange`. Stops propagation while open, so an enclosing dialog stays open. |

DOM focus stays on the input. The active option is announced through `aria-activedescendant`.

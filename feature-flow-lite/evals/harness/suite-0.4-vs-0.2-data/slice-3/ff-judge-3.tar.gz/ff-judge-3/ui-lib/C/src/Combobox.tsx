import {
  useEffect,
  useId,
  useState,
  type ChangeEvent,
  type InputHTMLAttributes,
  type KeyboardEvent,
} from "react";

export interface ComboboxOption {
  value: string;
  label: string;
  disabled?: boolean;
}

export interface ComboboxProps extends Omit<InputHTMLAttributes<HTMLInputElement>, "value" | "onChange" | "type"> {
  label: string;
  options: ComboboxOption[];
  value: string | null;
  onChange: (value: string | null) => void;
}

/** Indexes of options whose label contains the text (case-insensitive). Blank text matches everything. */
function matchingIndexes(options: ComboboxOption[], text: string): number[] {
  const query = text.trim() === "" ? "" : text.toLowerCase();
  return options.flatMap((option, index) => (option.label.toLowerCase().includes(query) ? [index] : []));
}

/** Next index in `enabled` after `current` (wrapping), or the first/last when nothing is active. */
function stepActive(enabled: number[], current: number | null, step: 1 | -1): number | null {
  if (enabled.length === 0) return null;
  const position = current === null ? -1 : enabled.indexOf(current);
  if (position === -1) return step === 1 ? enabled[0] : enabled[enabled.length - 1];
  return enabled[(position + step + enabled.length) % enabled.length];
}

export function Combobox({
  label,
  options,
  value,
  onChange,
  className,
  id,
  onBlur,
  onClick,
  onKeyDown,
  ...rest
}: ComboboxProps) {
  const base = useId();
  const labelId = `${base}-label`;
  const inputId = id ?? `${base}-input`;
  const listId = `${base}-listbox`;
  const optionId = (index: number) => `${base}-option-${index}`;

  const selectedLabel = options.find((option) => option.value === value)?.label ?? "";
  const [text, setText] = useState(selectedLabel);
  const [open, setOpen] = useState(false);
  // Only typing filters the list; with unchanged text the full list is shown.
  const [filtering, setFiltering] = useState(false);
  const [active, setActive] = useState<number | null>(null);

  useEffect(() => {
    setText(selectedLabel);
  }, [selectedLabel]);

  const matches = matchingIndexes(options, filtering ? text : "");
  const enabled = matches.filter((index) => !options[index].disabled);
  const shown = open ? matches : [];
  // A stale active index (options shrank or were filtered out) counts as no active option.
  const current = active !== null && enabled.includes(active) ? active : null;
  // Only text the user typed down to empty clears the selection; a value matching no option is left alone.
  const cleared = filtering && text.trim() === "" && value !== null;

  function choose(index: number) {
    onChange(options[index].value);
    setText(options[index].label);
    setOpen(false);
    setFiltering(false);
    setActive(null);
  }

  function close() {
    setOpen(false);
    setFiltering(false);
    setActive(null);
    setText(selectedLabel);
  }

  function handleChange(event: ChangeEvent<HTMLInputElement>) {
    const next = event.target.value;
    // Blank text activates nothing, so Enter can clear the selection instead.
    const firstEnabled =
      next.trim() === "" ? undefined : matchingIndexes(options, next).find((index) => !options[index].disabled);
    setText(next);
    setFiltering(true);
    setOpen(true);
    setActive(firstEnabled ?? null);
  }

  function handleBlur() {
    // Clearing the text and leaving the field clears the selection.
    if (cleared) onChange(null);
    close();
  }

  function handleKeyDown(event: KeyboardEvent<HTMLInputElement>) {
    onKeyDown?.(event);
    switch (event.key) {
      case "ArrowDown":
        event.preventDefault();
        if (!open) {
          setOpen(true);
          setActive(stepActive(enabled, null, 1));
        } else {
          setActive(stepActive(enabled, current, 1));
        }
        break;
      case "ArrowUp":
        if (!open) return;
        event.preventDefault();
        setActive(stepActive(enabled, current, -1));
        break;
      case "Enter":
        if (open && current !== null) {
          event.preventDefault();
          choose(current);
        } else if (cleared) {
          onChange(null);
          close();
        }
        break;
      case "Escape":
        if (!open) return;
        event.preventDefault();
        close();
        break;
    }
  }

  return (
    <div className={className}>
      <label id={labelId} htmlFor={inputId}>
        {label}
      </label>
      <input
        {...rest}
        id={inputId}
        type="text"
        role="combobox"
        autoComplete="off"
        aria-autocomplete="list"
        aria-expanded={open}
        aria-controls={listId}
        aria-activedescendant={open && current !== null ? optionId(current) : undefined}
        value={text}
        onChange={handleChange}
        onClick={(event) => {
          onClick?.(event);
          setOpen(true);
        }}
        onBlur={(event) => {
          onBlur?.(event);
          handleBlur();
        }}
        onKeyDown={handleKeyDown}
      />
      {/* Always rendered so aria-controls resolves; hidden while closed. */}
      <ul id={listId} role="listbox" aria-labelledby={labelId} hidden={!open}>
        {open && matches.length === 0 ? <li role="presentation">No results</li> : null}
        {shown.map((index) => {
          const option = options[index];
          return (
            <li
              key={index}
              id={optionId(index)}
              role="option"
              aria-selected={option.value === value}
              aria-disabled={option.disabled ? true : undefined}
              data-active={current === index ? "true" : undefined}
              onMouseDown={(event) => event.preventDefault()}
              onClick={() => {
                if (!option.disabled) choose(index);
              }}
            >
              {option.label}
            </li>
          );
        })}
      </ul>
    </div>
  );
}

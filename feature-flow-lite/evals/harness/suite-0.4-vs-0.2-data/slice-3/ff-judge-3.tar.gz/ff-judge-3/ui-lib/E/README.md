# @acme/ui

Accessible React components. Typed, style-agnostic (no CSS framework, no inline layout styles), and dependency-free beyond React 19.

Every component passes `className` and native props through to its root element (see each table for where).

```tsx
import { Tabs, TabList, Tab, TabPanel, Dialog, Combobox } from "@acme/ui";
```

## Tabs

Follows the WAI-ARIA tabs pattern. Components: `Tabs`, `TabList`, `Tab`, `TabPanel`.

### Tabs

Root element is a `div`; `className` and native `div` props pass through.

| Prop            | Type                       | Default | Description                                                              |
| --------------- | -------------------------- | ------- | ------------------------------------------------------------------------ |
| `defaultValue`  | `string`                   | none    | Initially selected tab (uncontrolled). Falls back to the first enabled tab if missing or disabled. |
| `value`         | `string`                   | none    | Selected tab (controlled). Selection changes only when the parent updates it. |
| `onValueChange` | `(value: string) => void`  | none    | Called with the requested value when the selection should change. Not called when the target is already selected. |

With neither `defaultValue` nor `value`, the first enabled tab is selected.

### TabList

Renders `role="tablist"`. Requires `aria-label`. Native `div` props pass through.

| Prop         | Type     | Default | Description                       |
| ------------ | -------- | ------- | --------------------------------- |
| `aria-label` | `string` | none    | Accessible name for the tab list (required). |

### Tab

Renders `<button type="button" role="tab">`. Native button props pass through.

| Prop       | Type      | Default | Description                                                        |
| ---------- | --------- | ------- | ------------------------------------------------------------------ |
| `value`    | `string`  | none    | Identifies the tab; matches a `TabPanel` `value`.                  |
| `disabled` | `boolean` | `false` | Disabled tabs cannot be selected by click or keyboard and are skipped by arrow keys. |

### TabPanel

Renders `role="tabpanel"` with `tabIndex={0}`. Non-selected panels are `hidden`. Native `div` props pass through.

| Prop    | Type     | Default | Description                              |
| ------- | -------- | ------- | ---------------------------------------- |
| `value` | `string` | none    | The tab value whose selection shows this panel. |

### Tabs keyboard

| Key                 | Action                                                          |
| ------------------- | --------------------------------------------------------------- |
| `ArrowRight`        | Focus and select the next enabled tab (wraps to the first).     |
| `ArrowLeft`         | Focus and select the previous enabled tab (wraps to the last).  |
| `Home`              | Focus and select the first enabled tab.                         |
| `End`               | Focus and select the last enabled tab.                          |
| `Tab` / `Shift+Tab` | Move focus into and out of the tab list (only the selected tab is in the tab order). |

Selection follows focus. In controlled mode with a `value` that never updates, a key press calls `onValueChange` and moves focus, but the selected tab and panel stay put.

```tsx
<Tabs defaultValue="a">
  <TabList aria-label="Sections">
    <Tab value="a">Alpha</Tab>
    <Tab value="b" disabled>Beta</Tab>
    <Tab value="c">Gamma</Tab>
  </TabList>
  <TabPanel value="a">Alpha content</TabPanel>
  <TabPanel value="b">Beta content</TabPanel>
  <TabPanel value="c">Gamma content</TabPanel>
</Tabs>
```

## Dialog

A modal rendered into `document.body` with a `createPortal`. Renders nothing when `open` is `false`. Root `role="dialog"` element receives `className` and native `div` props.

| Prop            | Type                          | Default | Description                                                       |
| --------------- | ----------------------------- | ------- | ----------------------------------------------------------------- |
| `open`          | `boolean`                     | none    | Whether the dialog is shown (controlled).                         |
| `onOpenChange`  | `(open: boolean) => void`     | none    | Called with `false` on Escape or a backdrop click. The parent decides whether to close. |
| `title`         | `ReactNode`                   | none    | Rendered in an `h2`; labels the dialog.                           |
| `description`   | `ReactNode`                   | none    | Rendered in a `p`; describes the dialog. Omitted from `aria-describedby` when not given. |
| `children`      | `ReactNode`                   | none    | Dialog content.                                                   |

On open, focus moves to the first tabbable element inside the dialog, or to the dialog itself if there is none. When the dialog closes (or unmounts while open), focus returns to the element that had it before opening, if it is still in the document.

### Dialog keyboard and pointer

| Input                          | Action                                                              |
| ------------------------------ | ------------------------------------------------------------------- |
| `Tab` on the last tabbable     | Wraps focus to the first tabbable element.                          |
| `Shift+Tab` on the first tabbable (or on the dialog itself) | Wraps focus to the last tabbable element. |
| `Escape` (from anywhere inside) | Calls `onOpenChange(false)`.                                       |
| Click on the backdrop          | Calls `onOpenChange(false)`. A press that starts inside the dialog does not close it. |

Focus cannot leave the dialog with Tab. Disabled elements, elements with `tabIndex={-1}`, elements inside a `hidden` subtree (such as inactive Tabs panels) and `input type="hidden"` are skipped.

Styling the backdrop: the full-screen backdrop element has a `data-backdrop` attribute and no class name, so style it from CSS with `[data-backdrop] { ... }` (for example a background colour or `position: fixed; inset: 0`). The dialog element itself receives `className` as usual.

```tsx
<Dialog open={open} onOpenChange={setOpen} title="Delete file" description="This cannot be undone.">
  <button onClick={confirm}>Delete</button>
  <button onClick={() => setOpen(false)}>Cancel</button>
</Dialog>
```

## Combobox

A text input with a listbox popup, following the WAI-ARIA combobox pattern. Renders a `<label>`, an `<input role="combobox">` and a `role="listbox"`. The `className` and native `input` props pass through to the input.

| Prop          | Type                                  | Default | Description                                                              |
| ------------- | ------------------------------------- | ------- | ------------------------------------------------------------------------ |
| `label`       | `string`                              | none    | Visible label, associated with the input and naming the listbox.         |
| `options`     | `ComboboxOption[]`                    | none    | `{ value: string; label: string; disabled?: boolean }[]`.                |
| `value`       | `string \| null`                      | none    | Selected option value (controlled). `null`, or a value matching no option, shows an empty input. |
| `onChange`    | `(value: string \| null) => void`     | none    | Called with the chosen option value, or `null` when the input is cleared. |
| `placeholder` | `string`                              | none    | Shown when the input is empty.                                           |

Typing opens the popup and filters options by case-insensitive substring match on the label (the query is trimmed, and special characters are matched literally). When nothing matches, a "No results" message is shown instead of options. The active option is exposed through `aria-activedescendant` and carries `data-active`.

When the user clears the input and then leaves it or presses Enter with no active option, `onChange(null)` is called (only if a value was selected) and the input stays empty.

### Combobox keyboard and pointer

| Input                  | Action                                                                                  |
| ---------------------- | --------------------------------------------------------------------------------------- |
| Typing                 | Opens the popup and filters options. Clears the active option.                          |
| `ArrowDown`            | Opens the popup if closed and moves the active option to the next enabled option (wraps). |
| `ArrowUp`              | Opens the popup if closed and moves the active option to the previous enabled option (wraps). |
| `Enter`                | With an active option: calls `onChange(option.value)`, closes, and shows its label. With no active option and an empty input: clears the selection (see above). Otherwise does nothing. |
| `Escape`               | Closes the popup without calling `onChange` and restores the selected label. When the popup is open, it does not also close an enclosing `Dialog`. |
| Blur (`Tab`, click away) | Closes the popup. With an empty input, clears the selection (see above). Otherwise restores the selected label. |
| Click on an option     | Selects it as `Enter` does. Clicking a disabled option does nothing.                    |

Disabled options are skipped by the arrow keys and cannot be selected. Selection is controlled: the component only displays `value` and never selects on its own.

```tsx
<Combobox
  label="Fruit"
  options={[
    { value: "apple", label: "Apple" },
    { value: "banana", label: "Banana", disabled: true },
  ]}
  value={fruit}
  onChange={setFruit}
  placeholder="Search fruit"
/>
```

## Development

- `pnpm test`: run the Vitest suite (jsdom, Testing Library, user-event).
- `pnpm typecheck`: run `tsc --noEmit`.

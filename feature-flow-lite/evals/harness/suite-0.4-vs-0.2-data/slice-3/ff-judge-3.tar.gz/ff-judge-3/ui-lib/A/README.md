# @acme/ui

Accessible React components. No CSS is shipped; every component accepts `className` and native props so you style it yourself.

Requires React 19. Import everything from the package entry:

```tsx
import { Tabs, TabList, Tab, TabPanel, Dialog, Combobox } from "@acme/ui";
```

Run the checks with `pnpm test` and `pnpm typecheck`.

## Tabs

Follows the WAI-ARIA tabs pattern. `Tabs` is the container; `TabList`, `Tab` and `TabPanel` must be rendered inside it.

### Tabs props

| Prop            | Type                       | Required | Default                                  |
| --------------- | -------------------------- | -------- | ---------------------------------------- |
| `defaultValue`  | `string`                   | No       | First enabled tab                        |
| `value`         | `string`                   | No       | Uncontrolled when omitted                |
| `onValueChange` | `(value: string) => void`  | No       | —                                        |
| (native `div` props) | `HTMLAttributes<HTMLDivElement>` | No | —                                |

Controlled when `value` is set: selection only changes when the parent updates `value`. `onValueChange` fires on every user selection in both modes, except re-selecting the current tab or selecting a disabled tab.

### TabList props

| Prop         | Type     | Required | Default |
| ------------ | -------- | -------- | ------- |
| `aria-label` | `string` | Yes      | —       |
| (native `div` props) | `HTMLAttributes<HTMLDivElement>` | No | — |

### Tab props

| Prop       | Type      | Required | Default |
| ---------- | --------- | -------- | ------- |
| `value`    | `string`  | Yes      | —       |
| `disabled` | `boolean` | No       | `false` |
| (native `button` props) | `ButtonHTMLAttributes<HTMLButtonElement>` | No | — |

Disabled tabs use the native `disabled` attribute, so they are skipped by the keyboard and ignore clicks.

### TabPanel props

| Prop    | Type     | Required | Default |
| ------- | -------- | -------- | ------- |
| `value` | `string` | Yes      | —       |
| (native `div` props) | `HTMLAttributes<HTMLDivElement>` | No | — |

Non-selected panels are rendered with `hidden`.

### Keyboard

| Key                 | Behavior                                                                   |
| ------------------- | -------------------------------------------------------------------------- |
| Tab                 | Moves focus into the tablist on the selected tab (roving tabindex).        |
| ArrowRight / ArrowDown | Focus and select the next enabled tab; wraps from last to first.        |
| ArrowLeft / ArrowUp | Focus and select the previous enabled tab; wraps from first to last.       |
| Home                | Focus and select the first enabled tab.                                    |
| End                 | Focus and select the last enabled tab.                                     |

### Example

```tsx
<Tabs defaultValue="profile">
  <TabList aria-label="Account">
    <Tab value="profile">Profile</Tab>
    <Tab value="billing">Billing</Tab>
    <Tab value="security" disabled>Security</Tab>
  </TabList>
  <TabPanel value="profile">Profile settings</TabPanel>
  <TabPanel value="billing">Billing settings</TabPanel>
  <TabPanel value="security">Security settings</TabPanel>
</Tabs>
```

## Dialog

A modal rendered into `document.body` through a portal, with a backdrop.

### Dialog props

| Prop           | Type                        | Required | Default |
| -------------- | --------------------------- | -------- | ------- |
| `open`         | `boolean`                   | Yes      | —       |
| `onOpenChange` | `(open: boolean) => void`   | Yes      | —       |
| `title`        | `ReactNode`                 | Yes      | —       |
| `description`  | `ReactNode`                 | No       | —       |
| `backdropClassName` | `string`               | No       | —       |
| `children`     | `ReactNode`                 | No       | —       |
| (native `div` props) | `HTMLAttributes<HTMLDivElement>` | No | — |

When open, the dialog has `role="dialog"`, `aria-modal="true"`, and is labelled by its title (an `h2`). It is described by the description only when one is given.

`onOpenChange(false)` is called on Escape and on a click on the backdrop. A click that starts inside the dialog and ends on the backdrop does not close it.

The backdrop is a `div` with a `data-backdrop` attribute, so it can be targeted with `[data-backdrop]` selectors. `backdropClassName` sets its `class` attribute; the dialog element itself takes native props such as `className`.

On open, focus moves to the first tabbable element inside the dialog, or to the dialog itself if there is none. On close or unmount, focus returns to the element that had it before opening, if that element is still in the document.

### Keyboard

| Key           | Behavior                                                                  |
| ------------- | ------------------------------------------------------------------------- |
| Tab           | Moves to the next tabbable element; wraps from last to first.             |
| Shift+Tab     | Moves to the previous tabbable element; wraps from first to last.         |
| Escape        | Calls `onOpenChange(false)`.                                              |

Tabbable elements exclude disabled, hidden and `tabindex="-1"` elements. Focus is trapped inside the dialog.

### Example

```tsx
const [open, setOpen] = useState(false);

<button onClick={() => setOpen(true)}>Delete project</button>
<Dialog
  open={open}
  onOpenChange={setOpen}
  title="Delete project?"
  description="This cannot be undone."
>
  <button onClick={() => setOpen(false)}>Cancel</button>
  <button>Delete</button>
</Dialog>
```

## Combobox

A text input with a listbox popup, following the WAI-ARIA combobox pattern. Controlled only: pass `value` and `onChange`.

### Combobox props

| Prop          | Type                                  | Required | Default |
| ------------- | ------------------------------------- | -------- | ------- |
| `label`       | `string`                              | Yes      | —       |
| `options`     | `ComboboxOption[]`                    | Yes      | —       |
| `value`       | `string \| null`                      | Yes      | —       |
| `onChange`    | `(value: string \| null) => void`     | Yes      | —       |
| `placeholder` | `string`                              | No       | —       |
| (native `input` props, except `value`, `onChange`, `placeholder`, `onKeyDown`, `onBlur`) | `InputHTMLAttributes<HTMLInputElement>` | No | — |

`ComboboxOption` is `{ value: string; label: string; disabled?: boolean }`.

The input shows the selected option's label while not editing. Typing filters options by case-insensitive substring match on the label, and opens the listbox. When nothing matches, a "No results" status message is shown.

Clicking or pressing Enter on an enabled option calls `onChange(option.value)` and closes the popup. Escape closes the popup without calling `onChange`, and restores the selected label.

If the text is cleared to empty, then Enter or blur calls `onChange(null)` once (only when a value was selected) and the input stays empty. Any other blur restores the selected label without calling `onChange`.

### Keyboard

| Key           | Behavior                                                                                  |
| ------------- | ----------------------------------------------------------------------------------------- |
| Click input   | Opens the listbox.                                                                        |
| Typing        | Filters options and opens the listbox. Clears the active option.                          |
| ArrowDown     | Opens the listbox if closed; moves the active option to the next enabled option (wraps).  |
| ArrowUp       | Opens the listbox if closed; moves the active option to the previous enabled option (wraps). |
| Enter         | While open, selects the active option (if any) and closes. With cleared text and no active option, sets the value to `null`. Never submits the form while open. |
| Escape        | While open, closes without selecting and stops the event from reaching an enclosing dialog. |
| Tab / blur    | Closes the listbox. Cleared text sets the value to `null`; otherwise restores the selected label. |

Focus stays on the input; the active option is reported with `aria-activedescendant`.

### Example

```tsx
const [fruit, setFruit] = useState<string | null>(null);

<Combobox
  label="Fruit"
  placeholder="Search fruit"
  options={[
    { value: "apple", label: "Apple" },
    { value: "banana", label: "Banana", disabled: true },
    { value: "cherry", label: "Cherry" },
  ]}
  value={fruit}
  onChange={setFruit}
/>
```

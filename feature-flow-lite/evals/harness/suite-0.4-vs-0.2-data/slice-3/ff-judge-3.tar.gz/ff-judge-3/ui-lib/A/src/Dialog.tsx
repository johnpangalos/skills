import {
  createContext,
  useContext,
  useEffect,
  useId,
  useRef,
  type HTMLAttributes,
  type MouseEvent,
  type ReactNode,
} from "react";
import { createPortal } from "react-dom";

export interface DialogProps extends Omit<HTMLAttributes<HTMLDivElement>, "title"> {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  title: ReactNode;
  description?: ReactNode;
  backdropClassName?: string;
}

type DialogPanelProps = Omit<DialogProps, "open"> & { returnFocusTo?: HTMLElement | null };

const TABBABLE = 'a[href], button, input:not([type="hidden"]), select, textarea, [tabindex]';

interface OpenDialog {
  id: string;
  parentId: string | null;
}

// Id of the dialog whose children are rendered. Context passes through the portal, so a nested dialog reads its parent's id here.
const DialogParent = createContext<string | null>(null);

// Open dialogs, bottom to top. Only the topmost one handles Escape and Tab.
const openDialogs: OpenDialog[] = [];

function isDescendant(entry: OpenDialog, ancestorId: string) {
  let parentId = entry.parentId;
  while (parentId !== null) {
    if (parentId === ancestorId) return true;
    parentId = openDialogs.find((other) => other.id === parentId)?.parentId ?? null;
  }
  return false;
}

// A descendant mounted in the same commit registers first, so the dialog goes just below its lowest open descendant.
// Otherwise it goes on top.
function addOpenDialog(entry: OpenDialog) {
  const below = openDialogs.findIndex((other) => isDescendant(other, entry.id));
  openDialogs.splice(below === -1 ? openDialogs.length : below, 0, entry);
}

// Elements that can receive Tab focus right now. Computed on demand so content added after open is included.
function getTabbables(root: HTMLElement) {
  return Array.from(root.querySelectorAll<HTMLElement>(TABBABLE)).filter(
    (element) => !element.matches(":disabled") && !element.closest("[hidden]") && element.tabIndex >= 0,
  );
}

export function Dialog({ open, ...rest }: DialogProps) {
  // Read focus during render: children with autoFocus or effects that focus move it before any effect of ours runs.
  const trigger = useRef<HTMLElement | null | undefined>(undefined);
  if (!open) {
    trigger.current = undefined;
    return null;
  }
  if (trigger.current === undefined) trigger.current = document.activeElement as HTMLElement | null;
  // The panel mounts only while open, so its effects run on open and restore focus on close or unmount.
  return createPortal(<DialogPanel {...rest} returnFocusTo={trigger.current} />, document.body);
}

function DialogPanel({
  onOpenChange,
  title,
  description,
  backdropClassName,
  returnFocusTo,
  children,
  ...rest
}: DialogPanelProps) {
  const id = useId();
  const parentId = useContext(DialogParent);
  const titleId = `${id}-title`;
  const descriptionId = `${id}-description`;
  const dialogRef = useRef<HTMLDivElement>(null);
  const pressedOnBackdrop = useRef(false);

  // Child effects run before parent effects on a shared mount: the child registers and takes focus, then the parent sees it is not topmost and leaves focus alone.
  useEffect(() => {
    const entry: OpenDialog = { id, parentId };
    addOpenDialog(entry);
    const dialog = dialogRef.current;
    if (dialog && openDialogs[openDialogs.length - 1] === entry) (getTabbables(dialog)[0] ?? dialog).focus();
    return () => {
      openDialogs.splice(openDialogs.indexOf(entry), 1);
    };
  }, [id, parentId]);

  // The panel mounts only while open, so this restores focus on close or unmount.
  useEffect(() => {
    return () => {
      if (returnFocusTo?.isConnected) returnFocusTo.focus();
    };
  }, []);

  useEffect(() => {
    const handleKeyDown = (event: KeyboardEvent) => {
      if (openDialogs[openDialogs.length - 1]?.id !== id) return;
      if (event.key === "Escape") {
        if (!event.defaultPrevented) onOpenChange(false);
        return;
      }
      const dialog = dialogRef.current;
      if (event.key !== "Tab" || !dialog) return;

      event.preventDefault();
      const tabbables = getTabbables(dialog);
      if (tabbables.length === 0) {
        dialog.focus();
        return;
      }
      const last = tabbables.length - 1;
      const index = tabbables.indexOf(document.activeElement as HTMLElement);
      if (event.shiftKey) {
        tabbables[index <= 0 ? last : index - 1].focus();
      } else {
        tabbables[index === -1 || index === last ? 0 : index + 1].focus();
      }
    };
    document.addEventListener("keydown", handleKeyDown);
    return () => document.removeEventListener("keydown", handleKeyDown);
  }, [id, onOpenChange]);

  // A click only counts as a backdrop click when both the press and the click land on the backdrop.
  const handleMouseDown = (event: MouseEvent<HTMLDivElement>) => {
    pressedOnBackdrop.current = event.target === event.currentTarget;
  };

  const handleClick = (event: MouseEvent<HTMLDivElement>) => {
    if (pressedOnBackdrop.current && event.target === event.currentTarget) {
      onOpenChange(false);
    }
  };

  return (
    <div className={backdropClassName} data-backdrop="" onMouseDown={handleMouseDown} onClick={handleClick}>
      <div
        {...rest}
        ref={dialogRef}
        role="dialog"
        aria-modal="true"
        aria-labelledby={titleId}
        aria-describedby={description ? descriptionId : undefined}
        tabIndex={-1}
      >
        <h2 id={titleId}>{title}</h2>
        {description && <p id={descriptionId}>{description}</p>}
        <DialogParent.Provider value={id}>{children}</DialogParent.Provider>
      </div>
    </div>
  );
}

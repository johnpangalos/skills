import { render, screen } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { useState } from "react";
import { Combobox } from "./Combobox";
import { Dialog, type DialogProps } from "./Dialog";

function Content() {
  return (
    <>
      <button>First</button>
      <button disabled>Disabled</button>
      <button tabIndex={-1}>Skipped</button>
      <button hidden>Hidden</button>
      <button>Last</button>
    </>
  );
}

const backdropOf = () => document.querySelector<HTMLElement>("[data-backdrop]");

describe("Dialog", () => {
  it("renders nothing when closed", () => {
    render(<Dialog open={false} onOpenChange={vi.fn()} title="Confirm" />);
    expect(screen.queryByRole("dialog")).not.toBeInTheDocument();
    expect(backdropOf()).toBeNull();
  });

  it("renders a backdrop and modal dialog into document.body", () => {
    render(<Dialog open onOpenChange={vi.fn()} title="Confirm">Body</Dialog>);
    const dialog = screen.getByRole("dialog", { name: "Confirm" });
    expect(dialog).toHaveAttribute("aria-modal", "true");
    expect(screen.getByRole("heading", { level: 2, name: "Confirm" })).toBeInTheDocument();
    expect(backdropOf()?.parentElement).toBe(document.body);
    expect(backdropOf()).toContainElement(dialog);
  });

  it("links the description only when one is given", () => {
    const { unmount } = render(
      <Dialog open onOpenChange={vi.fn()} title="Delete" description="This cannot be undone.">
        Body
      </Dialog>,
    );
    const dialog = screen.getByRole("dialog");
    expect(dialog).toHaveAccessibleDescription("This cannot be undone.");
    expect(dialog.getAttribute("aria-describedby")).toBe(screen.getByText("This cannot be undone.").id);
    unmount();

    render(<Dialog open onOpenChange={vi.fn()} title="Delete">Body</Dialog>);
    expect(screen.getByRole("dialog")).not.toHaveAttribute("aria-describedby");
  });

  it("focuses the first tabbable element on open, skipping disabled, hidden and tabindex=-1 ones", () => {
    render(<Dialog open onOpenChange={vi.fn()} title="Confirm"><Content /></Dialog>);
    expect(screen.getByRole("button", { name: "First" })).toHaveFocus();
  });

  it("focuses the dialog container when nothing inside is tabbable", () => {
    render(<Dialog open onOpenChange={vi.fn()} title="Info">Text only</Dialog>);
    expect(screen.getByRole("dialog")).toHaveFocus();
  });

  it("wraps Tab from the last tabbable to the first and Shift+Tab back", async () => {
    const user = userEvent.setup();
    render(<Dialog open onOpenChange={vi.fn()} title="Confirm"><Content /></Dialog>);

    await user.tab();
    expect(screen.getByRole("button", { name: "Last" })).toHaveFocus();
    await user.tab();
    expect(screen.getByRole("button", { name: "First" })).toHaveFocus();
    await user.tab({ shift: true });
    expect(screen.getByRole("button", { name: "Last" })).toHaveFocus();
  });

  it("keeps focus on the dialog container when there are no tabbables", async () => {
    const user = userEvent.setup();
    render(<Dialog open onOpenChange={vi.fn()} title="Info">Text only</Dialog>);
    await user.tab();
    expect(screen.getByRole("dialog")).toHaveFocus();
    await user.tab({ shift: true });
    expect(screen.getByRole("dialog")).toHaveFocus();
  });

  it("includes content added after opening in the focus cycle", async () => {
    const user = userEvent.setup();
    const { rerender } = render(
      <Dialog open onOpenChange={vi.fn()} title="Confirm"><><button>Ok</button></></Dialog>,
    );
    rerender(
      <Dialog open onOpenChange={vi.fn()} title="Confirm">
        <>
          <button>Ok</button>
          <input aria-label="Extra" />
        </>
      </Dialog>,
    );

    await user.tab();
    expect(screen.getByRole("textbox", { name: "Extra" })).toHaveFocus();
    await user.tab();
    expect(screen.getByRole("button", { name: "Ok" })).toHaveFocus();
  });

  it("calls onOpenChange(false) once on Escape", async () => {
    const user = userEvent.setup();
    const onOpenChange = vi.fn();
    render(<Dialog open onOpenChange={onOpenChange} title="Confirm"><Content /></Dialog>);

    await user.keyboard("{Escape}");
    expect(onOpenChange).toHaveBeenCalledTimes(1);
    expect(onOpenChange).toHaveBeenCalledWith(false);
  });

  it("calls onOpenChange(false) on Escape when focus is on the dialog container", async () => {
    const user = userEvent.setup();
    const onOpenChange = vi.fn();
    render(<Dialog open onOpenChange={onOpenChange} title="Info">Text only</Dialog>);
    expect(screen.getByRole("dialog")).toHaveFocus();

    await user.keyboard("{Escape}");
    expect(onOpenChange).toHaveBeenCalledTimes(1);
    expect(onOpenChange).toHaveBeenCalledWith(false);
  });

  it("closes on a backdrop click", async () => {
    const user = userEvent.setup();
    const onOpenChange = vi.fn();
    render(<Dialog open onOpenChange={onOpenChange} title="Confirm">Body</Dialog>);

    await user.click(backdropOf()!);
    expect(onOpenChange).toHaveBeenCalledTimes(1);
    expect(onOpenChange).toHaveBeenCalledWith(false);
  });

  it("does not close when clicking inside the dialog", async () => {
    const user = userEvent.setup();
    const onOpenChange = vi.fn();
    render(<Dialog open onOpenChange={onOpenChange} title="Confirm">Body text</Dialog>);

    await user.click(screen.getByText("Body text"));
    await user.click(screen.getByRole("heading", { name: "Confirm" }));
    expect(onOpenChange).not.toHaveBeenCalled();
  });

  it("does not close when a drag starts inside and ends on the backdrop", async () => {
    const user = userEvent.setup();
    const onOpenChange = vi.fn();
    render(<Dialog open onOpenChange={onOpenChange} title="Confirm">Body text</Dialog>);

    await user.pointer([
      { keys: "[MouseLeft>]", target: screen.getByText("Body text") },
      { target: backdropOf()! },
      { keys: "[/MouseLeft]", target: backdropOf()! },
    ]);
    expect(onOpenChange).not.toHaveBeenCalled();
  });

  it("returns focus to the previously focused element when closed", async () => {
    const user = userEvent.setup();
    function Harness() {
      const [open, setOpen] = useState(false);
      return (
        <>
          <button onClick={() => setOpen(true)}>Open</button>
          <Dialog open={open} onOpenChange={setOpen} title="Confirm"><Content /></Dialog>
        </>
      );
    }
    render(<Harness />);

    await user.click(screen.getByRole("button", { name: "Open" }));
    expect(screen.getByRole("button", { name: "First" })).toHaveFocus();

    await user.keyboard("{Escape}");
    expect(screen.queryByRole("dialog")).not.toBeInTheDocument();
    expect(screen.getByRole("button", { name: "Open" })).toHaveFocus();
  });

  it("returns focus when unmounted while open", () => {
    render(<button>Trigger</button>);
    const trigger = screen.getByRole("button", { name: "Trigger" });
    trigger.focus();

    const dialog = render(<Dialog open onOpenChange={vi.fn()} title="Confirm">Body</Dialog>);
    expect(screen.getByRole("dialog")).toHaveFocus();
    dialog.unmount();
    expect(trigger).toHaveFocus();
  });

  it("does not throw when the trigger was removed before closing", () => {
    function Harness(props: Pick<DialogProps, "open"> & { showTrigger: boolean }) {
      const { open, showTrigger } = props;
      return (
        <>
          {showTrigger && <button>Trigger</button>}
          <Dialog open={open} onOpenChange={vi.fn()} title="Confirm">Body</Dialog>
        </>
      );
    }
    const { rerender } = render(<Harness open={false} showTrigger />);
    screen.getByRole("button", { name: "Trigger" }).focus();

    rerender(<Harness open showTrigger />);
    rerender(<Harness open={false} showTrigger={false} />);
    expect(screen.queryByRole("dialog")).not.toBeInTheDocument();
    expect(document.body).toHaveFocus();
  });

  it("returns focus to the trigger when a child with autoFocus takes focus on open", async () => {
    const user = userEvent.setup();
    function Harness() {
      const [open, setOpen] = useState(false);
      return (
        <>
          <button onClick={() => setOpen(true)}>Open</button>
          <Dialog open={open} onOpenChange={setOpen} title="Edit">
            <input aria-label="Name" autoFocus />
          </Dialog>
        </>
      );
    }
    render(<Harness />);

    await user.click(screen.getByRole("button", { name: "Open" }));
    expect(screen.getByRole("textbox", { name: "Name" })).toHaveFocus();

    await user.keyboard("{Escape}");
    expect(screen.getByRole("button", { name: "Open" })).toHaveFocus();
  });

  it("closes only the inner dialog on Escape and keeps Tab trapped inside it", async () => {
    const user = userEvent.setup();
    function Nested() {
      const [outer, setOuter] = useState(true);
      const [inner, setInner] = useState(false);
      return (
        <Dialog open={outer} onOpenChange={setOuter} title="Outer">
          <button onClick={() => setInner(true)}>Open inner</button>
          <Dialog open={inner} onOpenChange={setInner} title="Inner">
            <button>Inner first</button>
            <button>Inner last</button>
          </Dialog>
        </Dialog>
      );
    }
    render(<Nested />);

    await user.click(screen.getByRole("button", { name: "Open inner" }));
    expect(screen.getByRole("button", { name: "Inner first" })).toHaveFocus();

    await user.keyboard("{Tab}");
    expect(screen.getByRole("button", { name: "Inner last" })).toHaveFocus();
    await user.keyboard("{Tab}");
    expect(screen.getByRole("button", { name: "Inner first" })).toHaveFocus();

    await user.keyboard("{Escape}");
    expect(screen.queryByRole("dialog", { name: "Inner" })).not.toBeInTheDocument();
    expect(screen.getByRole("dialog", { name: "Outer" })).toBeInTheDocument();

    await user.keyboard("{Escape}");
    expect(screen.queryByRole("dialog", { name: "Outer" })).not.toBeInTheDocument();
  });

  it("treats a nested dialog as topmost when both are open on first mount", async () => {
    const user = userEvent.setup();
    const onOuter = vi.fn();
    const onInner = vi.fn();
    render(
      <Dialog open onOpenChange={onOuter} title="Outer">
        <button>o</button>
        <Dialog open onOpenChange={onInner} title="Inner">
          <button>i</button>
        </Dialog>
      </Dialog>,
    );
    expect(screen.getByRole("button", { name: "i" })).toHaveFocus();

    await user.keyboard("{Escape}");
    expect(onInner).toHaveBeenCalledTimes(1);
    expect(onInner).toHaveBeenCalledWith(false);
    expect(onOuter).not.toHaveBeenCalled();
  });

  it("focuses and closes a top-level dialog opened from inside a nested dialog, leaving the others open", async () => {
    const user = userEvent.setup();
    const onOuter = vi.fn();
    const onInner = vi.fn();
    function Harness() {
      const [c, setC] = useState(false);
      return (
        <>
          <Dialog open onOpenChange={onOuter} title="Outer">
            <Dialog open onOpenChange={onInner} title="Inner">
              <button onClick={() => setC(true)}>Open C</button>
            </Dialog>
          </Dialog>
          <Dialog open={c} onOpenChange={setC} title="C">
            <button>c</button>
          </Dialog>
        </>
      );
    }
    render(<Harness />);

    await user.click(screen.getByRole("button", { name: "Open C" }));
    expect(screen.getByRole("button", { name: "c" })).toHaveFocus();

    await user.keyboard("{Escape}");
    expect(screen.queryByRole("dialog", { name: "C" })).not.toBeInTheDocument();
    expect(screen.getByRole("dialog", { name: "Inner" })).toBeInTheDocument();
    expect(screen.getByRole("dialog", { name: "Outer" })).toBeInTheDocument();
    expect(onInner).not.toHaveBeenCalled();
    expect(onOuter).not.toHaveBeenCalled();
  });

  it("applies backdropClassName to the backdrop only", () => {
    const { unmount } = render(
      <Dialog open onOpenChange={vi.fn()} title="Confirm" backdropClassName="overlay">Body</Dialog>,
    );
    expect(backdropOf()).toHaveClass("overlay");
    expect(screen.getByRole("dialog")).not.toHaveClass("overlay");
    unmount();

    render(<Dialog open onOpenChange={vi.fn()} title="Confirm">Body</Dialog>);
    expect(backdropOf()).not.toHaveAttribute("class");
  });

  it("ignores Escape that a child already prevented", async () => {
    const user = userEvent.setup();
    const onOpenChange = vi.fn();
    render(
      <Dialog open onOpenChange={onOpenChange} title="Confirm">
        <input aria-label="Field" onKeyDown={(event) => event.key === "Escape" && event.preventDefault()} />
      </Dialog>,
    );
    expect(screen.getByRole("textbox", { name: "Field" })).toHaveFocus();

    await user.keyboard("{Escape}");
    expect(onOpenChange).not.toHaveBeenCalled();
  });

  it("closes a combobox popup on Escape without closing the dialog, then closes the dialog on the next Escape", async () => {
    const user = userEvent.setup();
    const onOpenChange = vi.fn();
    function Harness() {
      const [value, setValue] = useState<string | null>(null);
      return (
        <Dialog open onOpenChange={onOpenChange} title="Pick a fruit">
          <Combobox
            label="Fruit"
            options={[
              { value: "apple", label: "Apple" },
              { value: "apricot", label: "Apricot" },
            ]}
            value={value}
            onChange={setValue}
          />
        </Dialog>
      );
    }
    render(<Harness />);
    const combobox = screen.getByRole("combobox", { name: "Fruit" });

    await user.type(combobox, "ap");
    expect(combobox).toHaveAttribute("aria-expanded", "true");

    await user.keyboard("{Escape}");
    expect(combobox).toHaveAttribute("aria-expanded", "false");
    expect(screen.getByRole("dialog", { name: "Pick a fruit" })).toBeInTheDocument();
    expect(onOpenChange).not.toHaveBeenCalled();

    await user.keyboard("{Escape}");
    expect(onOpenChange).toHaveBeenCalledTimes(1);
    expect(onOpenChange).toHaveBeenCalledWith(false);
  });
});

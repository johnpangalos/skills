import { fireEvent, render, screen } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { useState } from "react";
import { Tab, TabList, TabPanel, Tabs, type TabsProps } from "./Tabs";

interface ExampleProps extends Partial<TabsProps> {
  disabled?: string[];
  middle?: boolean;
}

function Example({ disabled = [], middle = false, ...props }: ExampleProps) {
  return (
    <Tabs {...props}>
      <TabList aria-label="Sections">
        <Tab value="a" disabled={disabled.includes("a")}>A</Tab>
        {middle && <Tab value="m">M</Tab>}
        <Tab value="b" disabled={disabled.includes("b")}>B</Tab>
        <Tab value="c" disabled={disabled.includes("c")}>C</Tab>
      </TabList>
      <TabPanel value="a">Panel A</TabPanel>
      <TabPanel value="m">Panel M</TabPanel>
      <TabPanel value="b">Panel B</TabPanel>
      <TabPanel value="c">Panel C</TabPanel>
    </Tabs>
  );
}

function ControlledHarness({ onChange }: { onChange: (value: string) => void }) {
  const [value, setValue] = useState("a");
  return (
    <Example
      value={value}
      onValueChange={(next) => {
        setValue(next);
        onChange(next);
      }}
    />
  );
}

const tab = (name: string) => screen.getByRole("tab", { name });

describe("Tabs", () => {
  it("wires roles, ids and aria attributes", () => {
    render(<Example defaultValue="a" />);
    const list = screen.getByRole("tablist", { name: "Sections" });
    expect(list).toBeInTheDocument();

    const tabA = tab("A");
    const panelA = screen.getByRole("tabpanel");
    expect(tabA).toHaveAttribute("aria-selected", "true");
    expect(tabA).toHaveAttribute("aria-controls", panelA.id);
    expect(panelA).toHaveAttribute("aria-labelledby", tabA.id);
    expect(panelA).toHaveAttribute("tabindex", "0");
    expect(panelA).toHaveTextContent("Panel A");
    expect(tab("B")).toHaveAttribute("aria-selected", "false");
  });

  it("hides non-selected panels instead of showing them", () => {
    render(<Example defaultValue="a" />);
    expect(screen.getByRole("tabpanel", { hidden: true, name: "A" })).toBeVisible();
    expect(screen.getByText("Panel B").closest("[role=tabpanel]")).toHaveAttribute("hidden");
  });

  it("selects the first non-disabled tab when no defaultValue is given", () => {
    render(<Example disabled={["a"]} />);
    expect(tab("B")).toHaveAttribute("aria-selected", "true");
    expect(tab("A")).toHaveAttribute("aria-selected", "false");
  });

  it("uses defaultValue for the initial selection", () => {
    render(<Example defaultValue="c" />);
    expect(tab("C")).toHaveAttribute("aria-selected", "true");
  });

  it("gives each instance unique ids", () => {
    render(
      <>
        <Example defaultValue="a" />
        <Example defaultValue="a" />
      </>,
    );
    const ids = screen.getAllByRole("tab").map((element) => element.id);
    expect(new Set(ids).size).toBe(ids.length);
  });

  it("calls onValueChange on click in uncontrolled mode and not when re-selecting", async () => {
    const user = userEvent.setup();
    const onValueChange = vi.fn();
    render(<Example defaultValue="a" onValueChange={onValueChange} />);

    await user.click(tab("A"));
    expect(onValueChange).not.toHaveBeenCalled();

    await user.click(tab("B"));
    expect(onValueChange).toHaveBeenCalledTimes(1);
    expect(onValueChange).toHaveBeenCalledWith("b");
    expect(tab("B")).toHaveAttribute("aria-selected", "true");
  });

  it("ignores clicks on disabled tabs", async () => {
    const user = userEvent.setup();
    const onValueChange = vi.fn();
    render(<Example defaultValue="a" disabled={["b"]} onValueChange={onValueChange} />);

    await user.click(tab("B"));
    expect(onValueChange).not.toHaveBeenCalled();
    expect(tab("B")).toHaveAttribute("aria-selected", "false");
    expect(tab("B")).toHaveAttribute("disabled");
  });

  it("keeps selection on the prop value when controlled and the parent ignores changes", async () => {
    const user = userEvent.setup();
    const onValueChange = vi.fn();
    render(<Example value="a" onValueChange={onValueChange} />);

    await user.click(tab("B"));
    expect(onValueChange).toHaveBeenCalledWith("b");
    expect(tab("A")).toHaveAttribute("aria-selected", "true");
    expect(tab("A")).toHaveAttribute("tabindex", "0");
    expect(tab("B")).toHaveAttribute("tabindex", "-1");

    fireEvent.keyDown(tab("A"), { key: "ArrowRight" });
    expect(onValueChange).toHaveBeenLastCalledWith("b");
    expect(tab("A")).toHaveAttribute("aria-selected", "true");
  });

  it("follows the controlled value when the parent updates it", async () => {
    const user = userEvent.setup();
    const onChange = vi.fn();
    render(<ControlledHarness onChange={onChange} />);

    await user.click(tab("C"));
    expect(onChange).toHaveBeenCalledWith("c");
    expect(tab("C")).toHaveAttribute("aria-selected", "true");
    expect(screen.getByRole("tabpanel")).toHaveTextContent("Panel C");
  });

  it("puts only the selected tab in the tab order and lands there on Tab", async () => {
    const user = userEvent.setup();
    render(<Example defaultValue="b" />);
    expect(tab("B")).toHaveAttribute("tabindex", "0");
    expect(tab("A")).toHaveAttribute("tabindex", "-1");
    expect(tab("C")).toHaveAttribute("tabindex", "-1");

    await user.tab();
    expect(tab("B")).toHaveFocus();
  });

  it("moves focus and selection with arrow keys, wrapping at the ends", async () => {
    const user = userEvent.setup();
    const onValueChange = vi.fn();
    render(<Example defaultValue="a" onValueChange={onValueChange} />);
    tab("A").focus();

    await user.keyboard("{ArrowRight}");
    expect(tab("B")).toHaveFocus();
    expect(tab("B")).toHaveAttribute("aria-selected", "true");
    expect(onValueChange).toHaveBeenLastCalledWith("b");

    await user.keyboard("{ArrowDown}");
    expect(tab("C")).toHaveFocus();

    await user.keyboard("{ArrowRight}");
    expect(tab("A")).toHaveFocus();

    await user.keyboard("{ArrowLeft}");
    expect(tab("C")).toHaveFocus();

    await user.keyboard("{ArrowUp}");
    expect(tab("B")).toHaveFocus();
    expect(onValueChange).toHaveBeenLastCalledWith("b");
  });

  it("skips disabled tabs when moving with arrow keys", async () => {
    const user = userEvent.setup();
    render(<Example defaultValue="a" disabled={["b"]} />);
    tab("A").focus();

    await user.keyboard("{ArrowRight}");
    expect(tab("C")).toHaveFocus();
  });

  it("jumps to the first and last enabled tab with Home and End", async () => {
    const user = userEvent.setup();
    render(<Example defaultValue="b" disabled={["a"]} />);
    tab("B").focus();

    await user.keyboard("{End}");
    expect(tab("C")).toHaveFocus();
    expect(tab("C")).toHaveAttribute("aria-selected", "true");

    await user.keyboard("{Home}");
    expect(tab("B")).toHaveFocus();
    expect(tab("B")).toHaveAttribute("aria-selected", "true");
  });

  it("skips a disabled last tab when End is pressed", async () => {
    const user = userEvent.setup();
    render(<Example defaultValue="a" disabled={["c"]} />);
    tab("A").focus();

    await user.keyboard("{End}");
    expect(tab("B")).toHaveFocus();
  });

  it("prevents default on handled keys", () => {
    render(<Example defaultValue="a" />);
    expect(fireEvent.keyDown(tab("A"), { key: "ArrowRight" })).toBe(false);
    expect(fireEvent.keyDown(tab("A"), { key: "End" })).toBe(false);
  });

  it("leaves unrelated keys alone", () => {
    render(<Example defaultValue="a" />);
    expect(fireEvent.keyDown(tab("A"), { key: "x" })).toBe(true);
  });

  it("stays put when only one tab is enabled", async () => {
    const user = userEvent.setup();
    const onValueChange = vi.fn();
    render(<Example defaultValue="a" disabled={["b", "c"]} onValueChange={onValueChange} />);
    tab("A").focus();

    await user.keyboard("{ArrowRight}");
    await user.keyboard("{ArrowLeft}");
    await user.keyboard("{End}");
    expect(tab("A")).toHaveFocus();
    expect(onValueChange).not.toHaveBeenCalled();
  });

  it("navigates tabs added by conditional rendering in DOM order", async () => {
    const user = userEvent.setup();
    const { rerender } = render(<Example defaultValue="a" />);
    rerender(<Example defaultValue="a" middle />);
    tab("A").focus();

    await user.keyboard("{ArrowRight}");
    expect(tab("M")).toHaveFocus();
    await user.keyboard("{ArrowRight}");
    expect(tab("B")).toHaveFocus();
  });

  it("falls back to the first enabled tab when defaultValue names a missing or disabled tab", () => {
    const { unmount } = render(<Example defaultValue="zzz" />);
    expect(tab("A")).toHaveAttribute("aria-selected", "true");
    unmount();

    render(<Example defaultValue="a" disabled={["a"]} />);
    expect(tab("A")).toHaveAttribute("aria-selected", "false");
    expect(tab("B")).toHaveAttribute("aria-selected", "true");
    expect(tab("B")).toHaveAttribute("tabindex", "0");
  });

  it("selects the first enabled tab when tabs mount after the TabList", () => {
    function Late({ show }: { show: boolean }) {
      return (
        <Tabs>
          <TabList aria-label="Sections">{show && <Tab value="a">A</Tab>}</TabList>
          <TabPanel value="a">Panel A</TabPanel>
        </Tabs>
      );
    }
    const { rerender } = render(<Late show={false} />);
    rerender(<Late show />);
    expect(tab("A")).toHaveAttribute("aria-selected", "true");
    expect(tab("A")).toHaveAttribute("tabindex", "0");
  });

  it("moves selection to the first enabled tab when the selected tab is removed", async () => {
    const user = userEvent.setup();
    function Removable() {
      const [show, setShow] = useState(true);
      return (
        <Tabs>
          <TabList aria-label="Sections">
            {show && <Tab value="a">A</Tab>}
            <Tab value="b">B</Tab>
          </TabList>
          <TabPanel value="a">Panel A</TabPanel>
          <TabPanel value="b">Panel B</TabPanel>
          <button onClick={() => setShow(false)}>Remove A</button>
        </Tabs>
      );
    }
    render(<Removable />);
    expect(tab("A")).toHaveAttribute("aria-selected", "true");

    await user.click(screen.getByRole("button", { name: "Remove A" }));
    expect(tab("B")).toHaveAttribute("aria-selected", "true");
    expect(tab("B")).toHaveAttribute("tabindex", "0");
    expect(screen.getByRole("tabpanel", { name: "B" })).toBeVisible();
  });

  it("keeps aria-selected on the prop value when controlled and no tab matches, moving only the tab stop", () => {
    render(<Example value="zzz" onValueChange={vi.fn()} />);
    expect(tab("A")).toHaveAttribute("aria-selected", "false");
    expect(tab("A")).toHaveAttribute("tabindex", "0");
    expect(tab("B")).toHaveAttribute("tabindex", "-1");
  });
});

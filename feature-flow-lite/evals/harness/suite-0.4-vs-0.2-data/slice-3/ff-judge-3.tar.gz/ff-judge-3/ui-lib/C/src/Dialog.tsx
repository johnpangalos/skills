import { useEffect, useId, useRef, type HTMLAttributes, type KeyboardEvent } from "react";
import { createPortal } from "react-dom";

export interface DialogProps extends Omit<HTMLAttributes<HTMLDivElement>, "title"> {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  title: string;
  description?: string;
}

const FOCUSABLE =
  'a[href], button, input:not([type="hidden"]), select, textarea, [tabindex], [contenteditable="true"]';

function focusableIn(root: HTMLElement): HTMLElement[] {
  return Array.from(root.querySelectorAll<HTMLElement>(FOCUSABLE)).filter(
    (el) =>
      !el.hasAttribute("disabled") && el.tabIndex >= 0 && !el.closest("[hidden]"),
  );
}

export function Dialog({
  open,
  onOpenChange,
  title,
  description,
  className,
  children,
  onKeyDown,
  ...rest
}: DialogProps) {
  const base = useId();
  const titleId = `${base}-title`;
  const descriptionId = `${base}-description`;
  const panelRef = useRef<HTMLDivElement>(null);
  // Set when a press or release lands inside the panel, so a drag across the edge isn't a backdrop click.
  const pointerInPanel = useRef(false);

  // Move focus into the dialog on open and return it to the previously focused element on close.
  useEffect(() => {
    const panel = panelRef.current;
    if (!open || !panel) return;
    const previous = document.activeElement as HTMLElement | null;
    (focusableIn(panel)[0] ?? panel).focus();
    return () => {
      if (previous?.isConnected) previous.focus();
    };
  }, [open]);

  function handleKeyDown(event: KeyboardEvent<HTMLDivElement>) {
    onKeyDown?.(event);
    // An inner control (such as an open Combobox list) that handled the key has called preventDefault.
    if (event.defaultPrevented) return;
    const panel = event.currentTarget;
    if (event.key === "Escape") {
      // Mark it handled so an enclosing Dialog doesn't close too.
      event.preventDefault();
      onOpenChange(false);
      return;
    }
    if (event.key !== "Tab") return;

    const items = focusableIn(panel);
    if (items.length === 0) {
      event.preventDefault();
      panel.focus();
      return;
    }
    const first = items[0];
    const last = items[items.length - 1];
    const focused = document.activeElement;
    if (event.shiftKey && (focused === first || focused === panel)) {
      event.preventDefault();
      last.focus();
    } else if (!event.shiftKey && focused === last) {
      event.preventDefault();
      first.focus();
    }
  }

  if (!open) return null;

  return createPortal(
    <div
      onMouseDown={(event) => {
        pointerInPanel.current = event.target !== event.currentTarget;
        // Keep focus inside the dialog; the non-focusable backdrop would otherwise move it to document.body.
        if (!pointerInPanel.current) event.preventDefault();
      }}
      onMouseUp={(event) => {
        if (event.target !== event.currentTarget) pointerInPanel.current = true;
      }}
      onClick={(event) => {
        const inPanel = pointerInPanel.current;
        pointerInPanel.current = false;
        if (!inPanel && event.target === event.currentTarget) onOpenChange(false);
      }}
    >
      <div
        {...rest}
        ref={panelRef}
        role="dialog"
        aria-modal="true"
        aria-labelledby={titleId}
        aria-describedby={description ? descriptionId : undefined}
        tabIndex={-1}
        className={className}
        onKeyDown={handleKeyDown}
      >
        <h2 id={titleId}>{title}</h2>
        {description ? <p id={descriptionId}>{description}</p> : null}
        {children}
      </div>
    </div>,
    document.body,
  );
}

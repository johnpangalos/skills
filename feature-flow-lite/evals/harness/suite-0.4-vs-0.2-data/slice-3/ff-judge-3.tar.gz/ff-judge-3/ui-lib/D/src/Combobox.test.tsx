import { render, screen } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { useState } from "react";
import { Combobox, type ComboboxOption } from "./Combobox";
import { Dialog } from "./Dialog";

const fruits: ComboboxOption[] = [
  { value: "apple", label: "Apple" },
  { value: "banana", label: "Banana" },
  { value: "cherry", label: "Cherry", disabled: true },
  { value: "blueberry", label: "Blueberry" },
];

// Keeps value in state so the parent-driven behaviour is exercised.
function Controlled({ initial = null, options = fruits, onChange = vi.fn() }: {
  initial?: string | null;
  options?: ComboboxOption[];
  onChange?: (value: string | null) => void;
}) {
  const [value, setValue] = useState<string | null>(initial);
  return (
    <Combobox
      label="Fruit"
      options={options}
      value={value}
      onChange={(next) => {
        onChange(next);
        setValue(next);
      }}
    />
  );
}

function input() {
  return screen.getByRole("combobox", { name: "Fruit" });
}

describe("Combobox", () => {
  it("associates the label with a combobox that exposes the listbox relationship", () => {
    render(<Controlled />);
    const box = input();
    expect(box).toHaveAttribute("aria-expanded", "false");
    expect(box).toHaveAttribute("aria-autocomplete", "list");
    expect(box).not.toHaveAttribute("aria-activedescendant");
    const listbox = document.getElementById(box.getAttribute("aria-controls") ?? "");
    expect(listbox).toHaveAttribute("role", "listbox");
    expect(listbox).toHaveAttribute("aria-labelledby", screen.getByText("Fruit").id);
  });

  it("opens and filters options by case-insensitive substring when typing", async () => {
    const user = userEvent.setup();
    render(<Controlled />);
    await user.type(input(), "BERRY");
    expect(input()).toHaveAttribute("aria-expanded", "true");
    expect(screen.getAllByRole("option").map((option) => option.textContent)).toEqual(["Blueberry"]);
  });

  it("treats regex metacharacters as plain text", async () => {
    const user = userEvent.setup();
    render(<Controlled />);
    for (const text of ["(", ".", "*"]) {
      await user.clear(input());
      await user.type(input(), text);
      expect(screen.queryAllByRole("option")).toHaveLength(0);
      expect(screen.getByText("No results")).toBeInTheDocument();
    }
  });

  it("shows No results without an option role and without aria-activedescendant", async () => {
    const user = userEvent.setup();
    render(<Controlled />);
    await user.type(input(), "zzz");
    expect(screen.getByText("No results")).toBeInTheDocument();
    expect(screen.queryByRole("option")).toBeNull();
    expect(input()).not.toHaveAttribute("aria-activedescendant");
  });

  it("opens on ArrowDown, wraps and skips disabled options, and sets aria-activedescendant", async () => {
    const user = userEvent.setup();
    render(<Controlled />);
    input().focus();
    await user.keyboard("{ArrowDown}");
    expect(input()).toHaveAttribute("aria-expanded", "true");
    // The first ArrowDown opens the listbox and activates the first enabled option.
    const apple = screen.getByRole("option", { name: "Apple" });
    expect(input()).toHaveAttribute("aria-activedescendant", apple.id);
    await user.keyboard("{ArrowDown}");
    expect(input()).toHaveAttribute("aria-activedescendant", screen.getByRole("option", { name: "Banana" }).id);
    await user.keyboard("{ArrowDown}");
    expect(input()).toHaveAttribute("aria-activedescendant", screen.getByRole("option", { name: "Blueberry" }).id);
    await user.keyboard("{ArrowDown}");
    expect(input()).toHaveAttribute("aria-activedescendant", apple.id);
    await user.keyboard("{ArrowUp}");
    expect(input()).toHaveAttribute("aria-activedescendant", screen.getByRole("option", { name: "Blueberry" }).id);
  });

  it("selects the active option on Enter, closes, and shows its label", async () => {
    const user = userEvent.setup();
    const onChange = vi.fn();
    render(<Controlled onChange={onChange} />);
    input().focus();
    await user.keyboard("{ArrowDown}{ArrowDown}{Enter}");
    expect(onChange).toHaveBeenCalledTimes(1);
    expect(onChange).toHaveBeenCalledWith("banana");
    expect(input()).toHaveValue("Banana");
    expect(input()).toHaveAttribute("aria-expanded", "false");
    expect(screen.queryByRole("listbox")).toBeNull();
  });

  it("does nothing on Enter with no active option", async () => {
    const user = userEvent.setup();
    const onChange = vi.fn();
    render(<Controlled onChange={onChange} />);
    await user.type(input(), "Cherry");
    await user.keyboard("{Enter}");
    expect(onChange).not.toHaveBeenCalled();
  });

  it("selects an enabled option on click and ignores a disabled one", async () => {
    const user = userEvent.setup();
    const onChange = vi.fn();
    render(<Controlled onChange={onChange} />);
    await user.type(input(), "e");
    await user.click(screen.getByRole("option", { name: "Cherry" }));
    expect(onChange).not.toHaveBeenCalled();
    await user.click(screen.getByRole("option", { name: "Blueberry" }));
    expect(onChange).toHaveBeenCalledWith("blueberry");
    expect(input()).toHaveValue("Blueberry");
    expect(screen.queryByRole("listbox")).toBeNull();
  });

  it("marks the current value selected and disabled options aria-disabled", async () => {
    const user = userEvent.setup();
    render(<Controlled initial="apple" />);
    input().focus();
    await user.keyboard("{ArrowDown}");
    expect(screen.getByRole("option", { name: "Apple" })).toHaveAttribute("aria-selected", "true");
    expect(screen.getByRole("option", { name: "Banana" })).toHaveAttribute("aria-selected", "false");
    expect(screen.getByRole("option", { name: "Cherry" })).toHaveAttribute("aria-disabled", "true");
    expect(screen.getByRole("option", { name: "Banana" })).not.toHaveAttribute("aria-disabled");
  });

  it("closes on Escape without calling onChange and restores the selected label", async () => {
    const user = userEvent.setup();
    const onChange = vi.fn();
    render(<Controlled initial="apple" onChange={onChange} />);
    await user.type(input(), "ban");
    expect(input()).toHaveValue("Appleban");
    await user.keyboard("{Escape}");
    expect(onChange).not.toHaveBeenCalled();
    expect(input()).toHaveValue("Apple");
    expect(input()).toHaveAttribute("aria-expanded", "false");
  });

  it("closes when focus leaves the input", async () => {
    const user = userEvent.setup();
    render(<Controlled />);
    await user.type(input(), "a");
    expect(screen.getByRole("listbox")).toBeInTheDocument();
    await user.tab();
    expect(screen.queryByRole("listbox")).toBeNull();
  });

  it("updates the text when the parent changes value, and empties it for null", () => {
    const { rerender } = render(
      <Combobox label="Fruit" options={fruits} value="apple" onChange={vi.fn()} />,
    );
    expect(input()).toHaveValue("Apple");
    rerender(<Combobox label="Fruit" options={fruits} value="banana" onChange={vi.fn()} />);
    expect(input()).toHaveValue("Banana");
    rerender(<Combobox label="Fruit" options={fruits} value={null} onChange={vi.fn()} />);
    expect(input()).toHaveValue("");
  });

  it("shows empty text and does not throw when the value matches no option", () => {
    render(<Combobox label="Fruit" options={fruits} value="kiwi" onChange={vi.fn()} />);
    expect(input()).toHaveValue("");
  });

  it("calls onChange(null) once when the text is cleared from a non-null value, and not when already null", async () => {
    const user = userEvent.setup();
    const onChange = vi.fn();
    const { unmount } = render(<Controlled initial="apple" onChange={onChange} />);
    await user.clear(input());
    expect(onChange).toHaveBeenCalledTimes(1);
    expect(onChange).toHaveBeenCalledWith(null);
    unmount();
    const empty = vi.fn();
    render(<Controlled onChange={empty} />);
    await user.clear(input());
    expect(empty).not.toHaveBeenCalled();
  });

  it("does nothing harmful when every option is disabled", async () => {
    const user = userEvent.setup();
    const onChange = vi.fn();
    const allDisabled = fruits.map((fruit) => ({ ...fruit, disabled: true }));
    render(<Controlled options={allDisabled} onChange={onChange} />);
    input().focus();
    await user.keyboard("{ArrowDown}{ArrowUp}{Enter}");
    expect(input()).not.toHaveAttribute("aria-activedescendant");
    expect(onChange).not.toHaveBeenCalled();
  });

  it("resets the active option when the filter changes so it never points at a hidden option", async () => {
    const user = userEvent.setup();
    render(<Controlled />);
    await user.type(input(), "a");
    await user.keyboard("{ArrowDown}");
    expect(input()).toHaveAttribute("aria-activedescendant", screen.getByRole("option", { name: "Apple" }).id);
    await user.type(input(), "p");
    expect(input()).not.toHaveAttribute("aria-activedescendant");
    await user.keyboard("{ArrowDown}");
    expect(input()).toHaveAttribute("aria-activedescendant", screen.getByRole("option", { name: "Apple" }).id);
  });

  it("selects by value when two options share a label", async () => {
    const user = userEvent.setup();
    const onChange = vi.fn();
    const twins: ComboboxOption[] = [
      { value: "1", label: "Same" },
      { value: "2", label: "Same" },
    ];
    render(<Controlled options={twins} onChange={onChange} />);
    await user.type(input(), "same");
    await user.click(screen.getAllByRole("option")[1]);
    expect(onChange).toHaveBeenCalledWith("2");
  });

  it("uses no duplicate ids when two instances render together", async () => {
    const user = userEvent.setup();
    render(
      <>
        <Controlled />
        <Controlled />
      </>,
    );
    const [first, second] = screen.getAllByRole("combobox");
    await user.type(first, "a");
    const ids = Array.from(document.querySelectorAll("[id]"), (el) => el.id);
    expect(new Set(ids).size).toBe(ids.length);
    expect(first.getAttribute("aria-controls")).not.toBe(second.getAttribute("aria-controls"));
    const listbox = document.getElementById(first.getAttribute("aria-controls") ?? "");
    expect(listbox?.querySelectorAll('[role="option"]')).toHaveLength(2);
  });

  it("closes only the listbox on the first Escape inside a dialog, and the dialog on the second", async () => {
    const user = userEvent.setup();
    const onOpenChange = vi.fn();
    function Harness() {
      const [value, setValue] = useState<string | null>(null);
      return (
        <Dialog open onOpenChange={onOpenChange} title="Pick a fruit">
          <Combobox label="Fruit" options={fruits} value={value} onChange={setValue} />
        </Dialog>
      );
    }
    render(<Harness />);
    const combobox = screen.getByRole("combobox", { name: "Fruit" });
    await user.click(combobox);
    await user.keyboard("{ArrowDown}");
    expect(combobox).toHaveAttribute("aria-expanded", "true");
    await user.keyboard("{Escape}");
    expect(combobox).toHaveAttribute("aria-expanded", "false");
    expect(onOpenChange).not.toHaveBeenCalled();
    await user.keyboard("{Escape}");
    expect(onOpenChange).toHaveBeenCalledTimes(1);
    expect(onOpenChange).toHaveBeenCalledWith(false);
  });
});

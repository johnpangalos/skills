import {
  useEffect,
  useId,
  useState,
  type ChangeEvent,
  type HTMLAttributes,
  type KeyboardEvent,
} from "react";

export type ComboboxOption = {
  value: string;
  label: string;
  disabled?: boolean;
};

export type ComboboxProps = Omit<HTMLAttributes<HTMLDivElement>, "onChange" | "defaultValue"> & {
  label: string;
  options: ComboboxOption[];
  value: string | null;
  onChange: (value: string | null) => void;
  placeholder?: string;
};

export function Combobox({
  label,
  options,
  value,
  onChange,
  placeholder,
  className,
  ...rest
}: ComboboxProps) {
  const baseId = useId();
  const labelId = `${baseId}-label`;
  const inputId = `${baseId}-input`;
  const listboxId = `${baseId}-listbox`;
  const optionId = (index: number) => `${baseId}-option-${index}`;

  // null means the user is not editing, so the input shows the selected label.
  const [query, setQuery] = useState<string | null>(null);
  const [open, setOpen] = useState(false);
  // Stored by value, not index, so an options change cannot leave it pointing past the end.
  const [activeValue, setActiveValue] = useState<string | null>(null);

  const selectedLabel = options.find((option) => option.value === value)?.label ?? "";
  const filterText = (query ?? "").toLowerCase();
  const visible = options.filter((option) => option.label.toLowerCase().includes(filterText));
  // A disabled option that is still stored as active counts as no active option.
  const activeOption = open
    ? visible.find((option) => option.value === activeValue && !option.disabled)
    : undefined;

  // An externally changed value replaces whatever the user was typing.
  useEffect(() => {
    setQuery(null);
  }, [value]);

  function close() {
    setOpen(false);
    setQuery(null);
    setActiveValue(null);
  }

  function choose(option: ComboboxOption) {
    onChange(option.value);
    close();
  }

  function moveActive(direction: 1 | -1): string | null {
    const enabled = visible.filter((option) => !option.disabled);
    if (enabled.length === 0) return null;
    const index = enabled.findIndex((option) => option.value === activeValue);
    if (index === -1) return direction === 1 ? enabled[0].value : enabled[enabled.length - 1].value;
    return enabled[(index + direction + enabled.length) % enabled.length].value;
  }

  function handleInputChange(event: ChangeEvent<HTMLInputElement>) {
    const text = event.target.value;
    setQuery(text);
    setOpen(true);
    setActiveValue(null);
    if (text === "") onChange(null);
  }

  function handleKeyDown(event: KeyboardEvent<HTMLInputElement>) {
    switch (event.key) {
      case "ArrowDown":
        event.preventDefault();
        setOpen(true);
        setActiveValue(moveActive(1));
        return;
      case "ArrowUp":
        event.preventDefault();
        setOpen(true);
        setActiveValue(moveActive(-1));
        return;
      case "Enter":
        if (!activeOption) return;
        event.preventDefault();
        choose(activeOption);
        return;
      case "Escape":
        if (!open) return;
        // Handled here, so an enclosing Dialog must not also close.
        event.preventDefault();
        event.stopPropagation();
        close();
        return;
    }
  }

  return (
    <div {...rest} className={className}>
      <label id={labelId} htmlFor={inputId}>
        {label}
      </label>
      <input
        id={inputId}
        type="text"
        role="combobox"
        autoComplete="off"
        aria-autocomplete="list"
        aria-expanded={open}
        aria-controls={listboxId}
        aria-activedescendant={
          activeOption ? optionId(options.indexOf(activeOption)) : undefined
        }
        placeholder={placeholder}
        value={query ?? selectedLabel}
        onChange={handleInputChange}
        onKeyDown={handleKeyDown}
        onBlur={close}
      />
      {/* Always rendered so aria-controls always points at an element in the DOM. */}
      <ul
        role="listbox"
        id={listboxId}
        aria-labelledby={labelId}
        hidden={!open || visible.length === 0}
      >
        {visible.map((option) => {
          const index = options.indexOf(option);
          return (
            <li
              key={option.value}
              id={optionId(index)}
              role="option"
              aria-selected={option.value === value}
              aria-disabled={option.disabled ? true : undefined}
              // Keeps focus in the input when an option is clicked.
              onMouseDown={(event) => event.preventDefault()}
              onClick={() => {
                if (!option.disabled) choose(option);
              }}
            >
              {option.label}
            </li>
          );
        })}
      </ul>
      {open && visible.length === 0 && <div>No results</div>}
    </div>
  );
}

import { render, screen } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { describe, expect, it, vi } from "vitest";
import { Tab, TabList, TabPanel, Tabs } from "./Tabs";

const NAMES = ["one", "two", "three"];

function renderTabs(
  options: { values?: string[]; disabled?: string[]; defaultValue?: string; value?: string; onValueChange?: (value: string) => void } = {},
) {
  const values = options.values ?? NAMES;
  return render(
    <Tabs defaultValue={options.defaultValue} value={options.value} onValueChange={options.onValueChange}>
      <TabList aria-label="Sections">
        {values.map((value) => (
          <Tab key={value} value={value} disabled={options.disabled?.includes(value)}>
            {value}
          </Tab>
        ))}
      </TabList>
      {values.map((value) => (
        <TabPanel key={value} value={value}>
          Panel {value}
        </TabPanel>
      ))}
    </Tabs>,
  );
}

describe("Tabs", () => {
  it("renders the tablist with orientation and label", () => {
    renderTabs();
    const list = screen.getByRole("tablist", { name: "Sections" });
    expect(list).toHaveAttribute("aria-orientation", "horizontal");
  });

  it("selects the first enabled tab by default and links tab to panel", () => {
    renderTabs({ disabled: ["one"] });
    const tab = screen.getByRole("tab", { name: "two" });
    expect(tab).toHaveAttribute("aria-selected", "true");
    const panel = screen.getByRole("tabpanel");
    expect(panel).toHaveTextContent("Panel two");
    expect(tab).toHaveAttribute("aria-controls", panel.id);
    expect(panel).toHaveAttribute("aria-labelledby", tab.id);
    expect(panel).toHaveAttribute("tabindex", "0");
  });

  it("uses defaultValue for the initial selection", () => {
    renderTabs({ defaultValue: "three" });
    expect(screen.getByRole("tab", { name: "three" })).toHaveAttribute("aria-selected", "true");
    expect(screen.getByRole("tabpanel")).toHaveTextContent("Panel three");
  });

  it("selects on click and reports only real changes", async () => {
    const user = userEvent.setup();
    const onValueChange = vi.fn();
    renderTabs({ onValueChange });
    await user.click(screen.getByRole("tab", { name: "two" }));
    expect(onValueChange).toHaveBeenCalledWith("two");
    expect(screen.getByRole("tab", { name: "two" })).toHaveAttribute("aria-selected", "true");
    await user.click(screen.getByRole("tab", { name: "two" }));
    expect(onValueChange).toHaveBeenCalledTimes(1);
  });

  it("keeps the selection fixed in controlled mode when the parent ignores changes", async () => {
    const user = userEvent.setup();
    const onValueChange = vi.fn();
    renderTabs({ value: "one", onValueChange });
    await user.click(screen.getByRole("tab", { name: "two" }));
    expect(onValueChange).toHaveBeenCalledWith("two");
    expect(screen.getByRole("tab", { name: "one" })).toHaveAttribute("aria-selected", "true");
    expect(screen.getByRole("tab", { name: "two" })).toHaveAttribute("aria-selected", "false");
  });

  it("uses roving tabindex with only the selected tab in the tab order", async () => {
    const user = userEvent.setup();
    renderTabs({ defaultValue: "two" });
    expect(screen.getByRole("tab", { name: "one" })).toHaveAttribute("tabindex", "-1");
    expect(screen.getByRole("tab", { name: "two" })).toHaveAttribute("tabindex", "0");
    await user.tab();
    expect(screen.getByRole("tab", { name: "two" })).toHaveFocus();
  });

  it("falls back to the first enabled tab when the selected value is disabled", async () => {
    const user = userEvent.setup();
    renderTabs({ defaultValue: "two", disabled: ["two"] });
    expect(screen.getByRole("tab", { name: "one" })).toHaveAttribute("tabindex", "0");
    await user.tab();
    expect(screen.getByRole("tab", { name: "one" })).toHaveFocus();
  });

  it("moves focus and selection with ArrowRight and ArrowLeft, wrapping at the ends", async () => {
    const user = userEvent.setup();
    const onValueChange = vi.fn();
    renderTabs({ onValueChange });
    await user.tab();
    await user.keyboard("{ArrowRight}");
    expect(screen.getByRole("tab", { name: "two" })).toHaveFocus();
    expect(screen.getByRole("tab", { name: "two" })).toHaveAttribute("aria-selected", "true");
    await user.keyboard("{ArrowRight}{ArrowRight}");
    expect(screen.getByRole("tab", { name: "one" })).toHaveFocus();
    await user.keyboard("{ArrowLeft}");
    expect(screen.getByRole("tab", { name: "three" })).toHaveFocus();
    expect(onValueChange).toHaveBeenLastCalledWith("three");
  });

  it("moves to first and last enabled tabs with Home and End", async () => {
    const user = userEvent.setup();
    renderTabs({ values: ["a", "b", "c", "d"], disabled: ["a", "d"] });
    await user.tab();
    await user.keyboard("{End}");
    expect(screen.getByRole("tab", { name: "c" })).toHaveFocus();
    await user.keyboard("{Home}");
    expect(screen.getByRole("tab", { name: "b" })).toHaveFocus();
  });

  it("skips disabled tabs when wrapping with arrows", async () => {
    const user = userEvent.setup();
    renderTabs({ values: ["a", "b", "c", "d"], disabled: ["a", "d"] });
    await user.tab();
    await user.keyboard("{ArrowLeft}");
    expect(screen.getByRole("tab", { name: "c" })).toHaveFocus();
    await user.keyboard("{ArrowRight}");
    expect(screen.getByRole("tab", { name: "b" })).toHaveFocus();
  });

  it("keeps focus on the only enabled tab with arrows", async () => {
    const user = userEvent.setup();
    renderTabs({ disabled: ["one", "three"] });
    await user.tab();
    await user.keyboard("{ArrowRight}{ArrowLeft}");
    expect(screen.getByRole("tab", { name: "two" })).toHaveFocus();
    expect(screen.getByRole("tab", { name: "two" })).toHaveAttribute("aria-selected", "true");
  });

  it("does nothing with all tabs disabled", async () => {
    const user = userEvent.setup();
    renderTabs({ disabled: NAMES });
    await user.keyboard("{ArrowRight}{Home}{End}");
    NAMES.forEach((name) => expect(screen.getByRole("tab", { name })).toBeDisabled());
    expect(screen.getByRole("tab", { name: "one" })).toHaveAttribute("aria-selected", "false");
  });

  it("ignores other keys", async () => {
    const user = userEvent.setup();
    const onValueChange = vi.fn();
    renderTabs({ onValueChange });
    await user.tab();
    await user.keyboard("a{Enter} ");
    expect(onValueChange).not.toHaveBeenCalled();
    expect(screen.getByRole("tab", { name: "one" })).toHaveAttribute("aria-selected", "true");
  });

  it("creates unique ids for values with spaces and slashes", () => {
    renderTabs({ values: ["a b", "x/y", "1"] });
    const tabs = screen.getAllByRole("tab");
    const ids = tabs.map((tab) => tab.id);
    expect(new Set(ids).size).toBe(3);
    tabs.forEach((tab) => {
      const panel = document.getElementById(tab.getAttribute("aria-controls") ?? "");
      expect(panel).toHaveAttribute("aria-labelledby", tab.id);
    });
  });

  it("does not move outer focus into nested tabs", async () => {
    const user = userEvent.setup();
    render(
      <Tabs defaultValue="outer1">
        <TabList aria-label="Outer">
          <Tab value="outer1">Outer 1</Tab>
          <Tab value="outer2">Outer 2</Tab>
        </TabList>
        <TabPanel value="outer1">
          <Tabs>
            <TabList aria-label="Inner">
              <Tab value="inner1">Inner 1</Tab>
              <Tab value="inner2">Inner 2</Tab>
            </TabList>
            <TabPanel value="inner1">Inner panel</TabPanel>
          </Tabs>
        </TabPanel>
        <TabPanel value="outer2">Outer panel 2</TabPanel>
      </Tabs>,
    );
    await user.click(screen.getByRole("tab", { name: "Outer 1" }));
    await user.keyboard("{ArrowRight}");
    expect(screen.getByRole("tab", { name: "Outer 2" })).toHaveFocus();
    await user.keyboard("{ArrowLeft}");
    expect(screen.getByRole("tab", { name: "Outer 1" })).toHaveFocus();
    expect(screen.getByRole("tab", { name: "Inner 1" })).toHaveAttribute("aria-selected", "true");
  });

  it("follows DOM order when tabs are added and removed", async () => {
    const user = userEvent.setup();
    const { rerender } = renderTabs({ values: ["a", "c"] });
    rerender(
      <Tabs defaultValue="a">
        <TabList aria-label="Sections">
          <Tab value="a">a</Tab>
          <Tab value="b">b</Tab>
          <Tab value="c">c</Tab>
        </TabList>
      </Tabs>,
    );
    await user.click(screen.getByRole("tab", { name: "a" }));
    await user.keyboard("{ArrowRight}");
    expect(screen.getByRole("tab", { name: "b" })).toHaveFocus();
    rerender(
      <Tabs defaultValue="a">
        <TabList aria-label="Sections">
          <Tab value="a">a</Tab>
          <Tab value="c">c</Tab>
        </TabList>
      </Tabs>,
    );
    await user.click(screen.getByRole("tab", { name: "a" }));
    await user.keyboard("{ArrowRight}");
    expect(screen.getByRole("tab", { name: "c" })).toHaveFocus();
  });
});

import { useEffect, useId, useRef, type HTMLAttributes, type KeyboardEvent, type ReactNode } from "react";
import { createPortal } from "react-dom";

export type DialogProps = Omit<HTMLAttributes<HTMLDivElement>, "title"> & {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  title: ReactNode;
  description?: ReactNode;
  backdropClassName?: string;
};

const TABBABLE =
  'a[href], button, input:not([type="hidden"]), select, textarea, [tabindex], [contenteditable="true"]';

function tabbables(container: HTMLElement): HTMLElement[] {
  return Array.from(container.querySelectorAll<HTMLElement>(TABBABLE)).filter(
    (element) =>
      !element.matches(":disabled") &&
      !element.closest("[hidden]") &&
      Number(element.getAttribute("tabindex") ?? 0) >= 0,
  );
}

export function Dialog({
  open,
  onOpenChange,
  title,
  description,
  backdropClassName,
  className,
  onKeyDown,
  onMouseDown,
  children,
  ...rest
}: DialogProps) {
  const baseId = useId();
  const titleId = `${baseId}-title`;
  const descriptionId = `${baseId}-description`;
  const dialogRef = useRef<HTMLDivElement | null>(null);
  // True while the current pointer press started inside the dialog content.
  const pressStartedInside = useRef(false);
  // Falsy values such as 0 are renderable, so only empty placeholders are skipped.
  const hasDescription = description != null && typeof description !== "boolean" && description !== "";

  useEffect(() => {
    const dialog = dialogRef.current;
    if (!open || !dialog) return;
    const opener = document.activeElement as HTMLElement | null;
    (tabbables(dialog)[0] ?? dialog).focus();
    return () => {
      if (opener?.isConnected) opener.focus();
    };
  }, [open]);

  if (!open) return null;

  function handleKeyDown(event: KeyboardEvent<HTMLDivElement>) {
    onKeyDown?.(event);
    if (event.key === "Escape") {
      // Stop here so an outer dialog does not also close.
      event.stopPropagation();
      onOpenChange(false);
      return;
    }
    if (event.key !== "Tab") return;

    const dialog = event.currentTarget;
    const items = tabbables(dialog);
    const first = items[0] ?? dialog;
    const last = items[items.length - 1] ?? dialog;
    const active = document.activeElement;
    if (event.shiftKey && (active === first || active === dialog)) {
      event.preventDefault();
      last.focus();
    } else if (!event.shiftKey && active === last) {
      event.preventDefault();
      first.focus();
    }
  }

  return createPortal(
    <>
      <div
        data-backdrop=""
        className={backdropClassName}
        onMouseDown={(event) => {
          // Keeps focus inside the dialog when the parent ignores onOpenChange.
          event.preventDefault();
          pressStartedInside.current = false;
        }}
        onClick={() => {
          if (!pressStartedInside.current) onOpenChange(false);
        }}
      />
      <div
        {...rest}
        ref={dialogRef}
        role="dialog"
        aria-modal="true"
        aria-labelledby={titleId}
        aria-describedby={hasDescription ? descriptionId : undefined}
        tabIndex={-1}
        className={className}
        onKeyDown={handleKeyDown}
        onMouseDown={(event) => {
          onMouseDown?.(event);
          pressStartedInside.current = true;
        }}
      >
        <h2 id={titleId}>{title}</h2>
        {hasDescription && <p id={descriptionId}>{description}</p>}
        {children}
      </div>
    </>,
    document.body,
  );
}

import { render, screen } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { useState } from "react";
import { describe, expect, it, vi } from "vitest";
import { Combobox, type ComboboxOption } from "./Combobox";

const FRUITS: ComboboxOption[] = [
  { value: "apple", label: "Apple" },
  { value: "banana", label: "Banana", disabled: true },
  { value: "cherry", label: "Cherry" },
  { value: "pear", label: "Pear (ripe)" },
  { value: "star", label: "Star*Fruit" },
];

/** A parent that accepts changes, with a spy to observe onChange calls. */
function Controlled({
  options = FRUITS,
  initial = null,
  onChange = () => {},
}: {
  options?: ComboboxOption[];
  initial?: string | null;
  onChange?: (value: string | null) => void;
}) {
  const [value, setValue] = useState<string | null>(initial);
  return (
    <Combobox
      label="Fruit"
      placeholder="Search fruit"
      options={options}
      value={value}
      onChange={(next) => {
        setValue(next);
        onChange(next);
      }}
    />
  );
}

function input() {
  return screen.getByRole("combobox", { name: "Fruit" });
}

describe("Combobox", () => {
  it("renders a labelled combobox with ARIA attributes and placeholder", async () => {
    const user = userEvent.setup();
    render(<Controlled />);
    const box = input();
    expect(box).toHaveAttribute("placeholder", "Search fruit");
    expect(box).toHaveAttribute("aria-autocomplete", "list");
    expect(box).toHaveAttribute("aria-expanded", "false");
    expect(screen.getByRole("listbox", { hidden: true })).not.toBeVisible();

    await user.click(box);
    expect(box).toHaveAttribute("aria-expanded", "true");
    const listbox = screen.getByRole("listbox", { name: "Fruit" });
    expect(box).toHaveAttribute("aria-controls", listbox.id);
    expect(screen.getAllByRole("option")).toHaveLength(FRUITS.length);
    expect(screen.getByRole("option", { name: "Banana" })).toHaveAttribute("aria-disabled", "true");
  });

  it("shows the selected label and follows parent value changes", () => {
    const { rerender } = render(
      <Combobox label="Fruit" options={FRUITS} value="cherry" onChange={() => {}} />,
    );
    expect(input()).toHaveValue("Cherry");
    rerender(<Combobox label="Fruit" options={FRUITS} value="apple" onChange={() => {}} />);
    expect(input()).toHaveValue("Apple");
  });

  it("marks the selected option with aria-selected", async () => {
    const user = userEvent.setup();
    render(<Controlled initial="apple" />);
    await user.click(input());
    expect(screen.getByRole("option", { name: "Apple" })).toHaveAttribute("aria-selected", "true");
    expect(screen.getByRole("option", { name: "Cherry" })).toHaveAttribute("aria-selected", "false");
  });

  it("filters by case-insensitive substring and treats regex characters literally", async () => {
    const user = userEvent.setup();
    render(<Controlled />);
    await user.type(input(), "AN");
    expect(screen.queryAllByRole("option")).toHaveLength(1);
    expect(screen.getByRole("option", { name: "Banana" })).toBeInTheDocument();

    await user.clear(input());
    await user.type(input(), "(");
    expect(screen.getByRole("option", { name: "Pear (ripe)" })).toBeInTheDocument();
    expect(screen.getAllByRole("option")).toHaveLength(1);

    await user.clear(input());
    await user.type(input(), "*");
    expect(screen.getByRole("option", { name: "Star*Fruit" })).toBeInTheDocument();
    expect(screen.getAllByRole("option")).toHaveLength(1);

    await user.clear(input());
    await user.type(input(), ".");
    expect(screen.queryByRole("option")).toBeNull();
  });

  it("shows all options again when the text is unchanged", async () => {
    const user = userEvent.setup();
    render(<Controlled initial="apple" />);
    await user.click(input());
    expect(screen.getAllByRole("option")).toHaveLength(FRUITS.length);
  });

  it("shows 'No results' without a selectable option and keeps Enter inert", async () => {
    const user = userEvent.setup();
    const onChange = vi.fn();
    render(<Controlled onChange={onChange} />);
    await user.type(input(), "zzz");
    expect(screen.getByText("No results")).toBeInTheDocument();
    expect(screen.queryByRole("option")).toBeNull();
    expect(input()).not.toHaveAttribute("aria-activedescendant");

    await user.keyboard("{Enter}");
    expect(onChange).not.toHaveBeenCalled();
  });

  it("moves the active option with ArrowDown/ArrowUp, skipping disabled and wrapping", async () => {
    const user = userEvent.setup();
    render(<Controlled />);
    const box = input();
    box.focus();

    await user.keyboard("{ArrowDown}");
    expect(box).toHaveFocus();
    const apple = screen.getByRole("option", { name: "Apple" });
    expect(box).toHaveAttribute("aria-activedescendant", apple.id);
    expect(apple).toHaveAttribute("data-active", "true");

    await user.keyboard("{ArrowDown}");
    const cherry = screen.getByRole("option", { name: "Cherry" });
    expect(box).toHaveAttribute("aria-activedescendant", cherry.id);

    await user.keyboard("{ArrowDown}");
    expect(box).toHaveAttribute("aria-activedescendant", screen.getByRole("option", { name: "Pear (ripe)" }).id);

    await user.keyboard("{ArrowDown}{ArrowDown}");
    expect(box).toHaveAttribute("aria-activedescendant", apple.id);

    await user.keyboard("{ArrowUp}");
    expect(box).toHaveAttribute("aria-activedescendant", screen.getByRole("option", { name: "Star*Fruit" }).id);
  });

  it("removes aria-activedescendant when the list closes", async () => {
    const user = userEvent.setup();
    render(<Controlled />);
    input().focus();
    await user.keyboard("{ArrowDown}");
    expect(input()).toHaveAttribute("aria-activedescendant");
    await user.keyboard("{Escape}");
    expect(input()).not.toHaveAttribute("aria-activedescendant");
    expect(input()).toHaveAttribute("aria-expanded", "false");
  });

  it("selects the active option on Enter and closes the list", async () => {
    const user = userEvent.setup();
    const onChange = vi.fn();
    render(<Controlled onChange={onChange} />);
    input().focus();
    await user.keyboard("{ArrowDown}{ArrowDown}{Enter}");
    expect(onChange).toHaveBeenCalledWith("cherry");
    expect(input()).toHaveValue("Cherry");
    expect(screen.getByRole("listbox", { hidden: true })).not.toBeVisible();
  });

  it("selects on click and ignores clicks on disabled options", async () => {
    const user = userEvent.setup();
    const onChange = vi.fn();
    render(<Controlled onChange={onChange} />);
    await user.click(input());
    await user.click(screen.getByRole("option", { name: "Banana" }));
    expect(onChange).not.toHaveBeenCalled();
    expect(screen.getByRole("listbox")).toBeInTheDocument();

    await user.click(screen.getByRole("option", { name: "Apple" }));
    expect(onChange).toHaveBeenCalledWith("apple");
    expect(input()).toHaveValue("Apple");
    expect(screen.getByRole("listbox", { hidden: true })).not.toBeVisible();
  });

  it("Escape closes without onChange and restores the selected label", async () => {
    const user = userEvent.setup();
    const onChange = vi.fn();
    render(<Controlled initial="apple" onChange={onChange} />);
    await user.click(input());
    await user.clear(input());
    await user.type(input(), "ch");
    await user.keyboard("{Escape}");
    expect(onChange).not.toHaveBeenCalled();
    expect(input()).toHaveValue("Apple");
    expect(screen.getByRole("listbox", { hidden: true })).not.toBeVisible();
  });

  it("Escape with no selection restores an empty input", async () => {
    const user = userEvent.setup();
    const onChange = vi.fn();
    render(<Controlled onChange={onChange} />);
    await user.type(input(), "ch");
    await user.keyboard("{Escape}");
    expect(input()).toHaveValue("");
    expect(onChange).not.toHaveBeenCalled();
  });

  it("blur closes the list and restores the selected label without onChange", async () => {
    const user = userEvent.setup();
    const onChange = vi.fn();
    render(<Controlled initial="apple" onChange={onChange} />);
    await user.click(input());
    await user.type(input(), "x");
    await user.tab();
    expect(onChange).not.toHaveBeenCalled();
    expect(input()).toHaveValue("Apple");
    expect(screen.getByRole("listbox", { hidden: true })).not.toBeVisible();
  });

  it("clearing the text and leaving calls onChange(null) when a value was selected", async () => {
    const user = userEvent.setup();
    const onChange = vi.fn();
    render(<Controlled initial="apple" onChange={onChange} />);
    await user.clear(input());
    await user.keyboard("{Enter}");
    expect(onChange).toHaveBeenLastCalledWith(null);
    expect(input()).toHaveValue("");
  });

  it("clearing the text then blurring calls onChange(null)", async () => {
    const user = userEvent.setup();
    const onChange = vi.fn();
    render(<Controlled initial="apple" onChange={onChange} />);
    await user.clear(input());
    await user.tab();
    expect(onChange).toHaveBeenCalledWith(null);
    expect(input()).toHaveValue("");
  });

  it("does not crash when every option is disabled", async () => {
    const user = userEvent.setup();
    render(
      <Controlled options={[{ value: "a", label: "Alpha", disabled: true }]} />,
    );
    input().focus();
    await user.keyboard("{ArrowDown}{ArrowDown}{Enter}");
    expect(input()).not.toHaveAttribute("aria-activedescendant");
    expect(screen.getByRole("option", { name: "Alpha" })).toHaveAttribute("aria-disabled", "true");
  });

  it("shows 'No results' when options are empty", async () => {
    const user = userEvent.setup();
    render(<Controlled options={[]} />);
    await user.type(input(), "x");
    expect(screen.getByText("No results")).toBeInTheDocument();
  });

  it("selects the right value when labels are duplicated", async () => {
    const user = userEvent.setup();
    const onChange = vi.fn();
    render(
      <Controlled
        options={[
          { value: "1", label: "Same" },
          { value: "2", label: "Same" },
        ]}
        onChange={onChange}
      />,
    );
    await user.click(input());
    await user.click(screen.getAllByRole("option")[1]);
    expect(onChange).toHaveBeenCalledWith("2");
  });

  it("keeps the parent's value when the parent ignores onChange", async () => {
    const user = userEvent.setup();
    const onChange = vi.fn();
    render(
      <Combobox label="Fruit" options={FRUITS} value="apple" onChange={onChange} />,
    );
    await user.click(input());
    await user.clear(input());
    await user.type(input(), "ch");
    await user.keyboard("{Enter}");
    expect(onChange).toHaveBeenCalledWith("cherry");
    await user.tab();
    expect(input()).toHaveValue("Apple");
  });

  it("gives two comboboxes on one page distinct ids", () => {
    render(
      <>
        <Combobox label="First" options={FRUITS} value={null} onChange={() => {}} />
        <Combobox label="Second" options={FRUITS} value={null} onChange={() => {}} />
      </>,
    );
    const first = screen.getByRole("combobox", { name: "First" });
    const second = screen.getByRole("combobox", { name: "Second" });
    expect(first.id).not.toBe(second.id);
    expect(first.getAttribute("aria-controls")).not.toBe(second.getAttribute("aria-controls"));
  });

  it("keeps the listbox in the DOM while closed so aria-controls resolves", async () => {
    const user = userEvent.setup();
    render(<Controlled />);
    const box = input();
    const listbox = document.getElementById(box.getAttribute("aria-controls")!);
    expect(listbox).toHaveAttribute("role", "listbox");
    expect(listbox).toHaveAttribute("hidden");

    await user.click(box);
    expect(listbox).not.toHaveAttribute("hidden");
  });

  it("does not throw when the options shrink under the active option", async () => {
    const user = userEvent.setup();
    const onChange = vi.fn();
    const six: ComboboxOption[] = [1, 2, 3, 4, 5, 6].map((n) => ({ value: `${n}`, label: `Item ${n}` }));
    const { rerender } = render(<Combobox label="Fruit" options={six} value={null} onChange={onChange} />);
    input().focus();
    await user.keyboard("{ArrowDown}{ArrowDown}{ArrowDown}{ArrowDown}{ArrowDown}");
    expect(input()).toHaveAttribute("aria-activedescendant", screen.getByRole("option", { name: "Item 5" }).id);

    rerender(<Combobox label="Fruit" options={six.slice(0, 2)} value={null} onChange={onChange} />);
    expect(input()).not.toHaveAttribute("aria-activedescendant");
    await user.keyboard("{Enter}");
    expect(onChange).not.toHaveBeenCalled();
  });

  it("does not clear a value that matches no option until the user empties the text", async () => {
    const user = userEvent.setup();
    const onChange = vi.fn();
    render(<Combobox label="Fruit" options={FRUITS} value="zzz" onChange={onChange} />);
    await user.click(input());
    await user.tab();
    expect(onChange).not.toHaveBeenCalled();
  });

  it("treats whitespace-only text as empty and clears the value on blur", async () => {
    const user = userEvent.setup();
    const onChange = vi.fn();
    render(<Controlled initial="apple" onChange={onChange} />);
    await user.clear(input());
    await user.type(input(), "   ");
    await user.tab();
    expect(onChange).toHaveBeenLastCalledWith(null);
    expect(input()).toHaveValue("");
  });

  it("runs consumer onClick, onKeyDown and onBlur alongside its own handling", async () => {
    const user = userEvent.setup();
    const onClick = vi.fn();
    const onKeyDown = vi.fn();
    const onBlur = vi.fn();
    render(
      <Combobox
        label="Fruit"
        options={FRUITS}
        value={null}
        onChange={() => {}}
        onClick={onClick}
        onKeyDown={onKeyDown}
        onBlur={onBlur}
      />,
    );
    await user.click(input());
    expect(onClick).toHaveBeenCalledTimes(1);
    expect(input()).toHaveAttribute("aria-expanded", "true");

    await user.keyboard("{ArrowDown}");
    expect(onKeyDown).toHaveBeenCalled();
    expect(input()).toHaveAttribute("aria-activedescendant");

    await user.tab();
    expect(onBlur).toHaveBeenCalledTimes(1);
  });

  it("uses a consumer id for the input so the label still names it", () => {
    render(<Combobox id="fruit-box" label="Fruit" options={FRUITS} value={null} onChange={() => {}} />);
    expect(input()).toHaveAttribute("id", "fruit-box");
  });

  it("forwards className to the root element", () => {
    const { container } = render(
      <Combobox label="Fruit" options={FRUITS} value={null} onChange={() => {}} className="wrap" />,
    );
    expect(container.firstElementChild).toHaveClass("wrap");
  });
});

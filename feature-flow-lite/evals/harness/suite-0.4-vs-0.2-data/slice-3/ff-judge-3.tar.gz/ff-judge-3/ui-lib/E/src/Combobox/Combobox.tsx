import {
  useEffect,
  useId,
  useState,
  type ChangeEvent,
  type ComponentPropsWithoutRef,
  type FocusEvent,
  type KeyboardEvent,
} from "react";

export type ComboboxOption = { value: string; label: string; disabled?: boolean };

export type ComboboxProps = Omit<ComponentPropsWithoutRef<"input">, "value" | "onChange"> & {
  label: string;
  options: ComboboxOption[];
  /** Selected option value, or null for no selection. */
  value: string | null;
  onChange: (value: string | null) => void;
  placeholder?: string;
};

export function Combobox({
  label,
  options,
  value,
  onChange,
  placeholder,
  onKeyDown,
  onBlur,
  ...props
}: ComboboxProps) {
  const baseId = useId();
  const labelId = `${baseId}-label`;
  const inputId = `${baseId}-input`;
  const listboxId = `${baseId}-listbox`;
  const optionId = (index: number) => `${baseId}-option-${index}`;

  const selectedLabel = options.find((option) => option.value === value)?.label ?? "";
  const [text, setText] = useState(selectedLabel);
  const [query, setQuery] = useState("");
  const [open, setOpen] = useState(false);
  const [activeValue, setActiveValue] = useState<string | null>(null);

  // Follow the parent when it changes the selection.
  useEffect(() => {
    setText(selectedLabel);
    setQuery("");
  }, [selectedLabel]);

  const needle = query.trim().toLowerCase();
  const matches = options
    .map((option, index) => ({ option, index }))
    .filter(({ option }) => option.label.toLowerCase().includes(needle));
  const enabledMatches = matches.filter(({ option }) => !option.disabled);
  const listVisible = open && matches.length > 0;
  const activeMatch = listVisible ? enabledMatches.find(({ option }) => option.value === activeValue) : undefined;
  const isEmpty = text.trim() === "";

  // The input text always comes from `value`, so a parent that ignores onChange keeps the old label.
  const close = () => {
    setText(selectedLabel);
    setOpen(false);
    setQuery("");
    setActiveValue(null);
  };

  const choose = (option: ComboboxOption) => {
    onChange(option.value);
    close();
  };

  const clear = () => {
    if (value !== null) onChange(null);
    close();
  };

  const move = (step: 1 | -1) => {
    setOpen(true);
    if (enabledMatches.length === 0) {
      setActiveValue(null);
      return;
    }
    const current = enabledMatches.findIndex(({ option }) => option.value === activeValue);
    const count = enabledMatches.length;
    let next: number;
    if (current === -1) next = step === 1 ? 0 : count - 1;
    else next = (current + step + count) % count;
    setActiveValue(enabledMatches[next].option.value);
  };

  const handleChange = (event: ChangeEvent<HTMLInputElement>) => {
    setText(event.target.value);
    setQuery(event.target.value);
    setOpen(true);
    setActiveValue(null);
  };

  const handleKeyDown = (event: KeyboardEvent<HTMLInputElement>) => {
    onKeyDown?.(event);
    switch (event.key) {
      case "ArrowDown":
        event.preventDefault();
        move(1);
        break;
      case "ArrowUp":
        event.preventDefault();
        move(-1);
        break;
      case "Enter":
        if (activeMatch) {
          event.preventDefault();
          choose(activeMatch.option);
        } else if (isEmpty) {
          clear();
        }
        break;
      case "Escape":
        if (open) event.stopPropagation();
        close();
        break;
    }
  };

  const handleBlur = (event: FocusEvent<HTMLInputElement>) => {
    onBlur?.(event);
    if (isEmpty) clear();
    else close();
  };

  return (
    <div>
      <label id={labelId} htmlFor={inputId}>
        {label}
      </label>
      <input
        {...props}
        id={inputId}
        role="combobox"
        autoComplete="off"
        aria-expanded={listVisible}
        aria-controls={listboxId}
        aria-autocomplete="list"
        aria-activedescendant={activeMatch ? optionId(activeMatch.index) : undefined}
        placeholder={placeholder}
        value={text}
        onChange={handleChange}
        onKeyDown={handleKeyDown}
        onBlur={handleBlur}
      />
      <ul
        id={listboxId}
        role="listbox"
        aria-labelledby={labelId}
        hidden={!listVisible}
        onMouseDown={(event) => event.preventDefault()}
      >
        {matches.map(({ option, index }) => (
          <li
            key={index}
            id={optionId(index)}
            role="option"
            aria-selected={option.value === value}
            aria-disabled={option.disabled}
            data-active={activeMatch?.index === index || undefined}
            onClick={() => {
              if (!option.disabled) choose(option);
            }}
          >
            {option.label}
          </li>
        ))}
      </ul>
      {open && matches.length === 0 && <div role="status">No results</div>}
    </div>
  );
}

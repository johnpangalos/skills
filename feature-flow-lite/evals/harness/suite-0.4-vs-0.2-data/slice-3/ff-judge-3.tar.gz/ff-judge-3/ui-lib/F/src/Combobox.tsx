import {
  useId,
  useState,
  type ChangeEvent,
  type ComponentPropsWithoutRef,
  type FocusEvent,
  type KeyboardEvent,
} from "react";

export type ComboboxOption = {
  value: string;
  label: string;
  disabled?: boolean;
};

export type ComboboxProps = Omit<ComponentPropsWithoutRef<"input">, "value" | "defaultValue" | "onChange" | "role"> & {
  label: string;
  options: ComboboxOption[];
  value: string | null;
  onChange: (value: string | null) => void;
};

function matches(option: ComboboxOption, query: string): boolean {
  return option.label.toLowerCase().includes(query.toLowerCase());
}

export function Combobox({ label, options, value, onChange, onBlur, onKeyDown, ...rest }: ComboboxProps) {
  const baseId = useId();
  const labelId = `${baseId}-label`;
  const inputId = `${baseId}-input`;
  const listboxId = `${baseId}-listbox`;
  const optionId = (index: number) => `${baseId}-option-${index}`;

  // query is the typed text; null means "not typing", so the input shows the selected label.
  const [query, setQuery] = useState<string | null>(null);
  const [open, setOpen] = useState(false);
  // Value of the active option. Tracking the value, not an index, keeps the active option on the same
  // option when `options` change while the listbox is open.
  const [activeValue, setActiveValue] = useState<string | null>(null);

  const selectedIndex = options.findIndex((option) => option.value === value);
  const text = query ?? (selectedIndex === -1 ? "" : options[selectedIndex].label);
  const visible = options.flatMap((option, index) => (matches(option, query ?? "") ? [index] : []));
  const enabled = visible.filter((index) => !options[index].disabled);
  // Index into `options` of the active option. Null when the active value is no longer a visible, enabled option.
  const active = enabled.find((index) => options[index].value === activeValue) ?? null;

  function close() {
    setQuery(null);
    setOpen(false);
    setActiveValue(null);
  }

  function choose(index: number) {
    onChange(options[index].value);
    close();
  }

  // Next enabled visible option in the given direction, wrapping. From no active option,
  // Down picks the first and Up picks the last.
  function step(down: boolean): number | null {
    if (enabled.length === 0) return null;
    const position = active === null ? -1 : enabled.indexOf(active);
    if (position === -1) return down ? enabled[0] : enabled[enabled.length - 1];
    return enabled[(position + (down ? 1 : enabled.length - 1)) % enabled.length];
  }

  function handleChange(event: ChangeEvent<HTMLInputElement>) {
    const next = event.target.value;
    const first = options.findIndex((option) => !option.disabled && matches(option, next));
    setQuery(next);
    setOpen(true);
    setActiveValue(next === "" || first === -1 ? null : options[first].value);
  }

  function handleKeyDown(event: KeyboardEvent<HTMLInputElement>) {
    onKeyDown?.(event);
    switch (event.key) {
      case "ArrowDown":
      case "ArrowUp": {
        event.preventDefault();
        setOpen(true);
        const next = step(event.key === "ArrowDown");
        setActiveValue(next === null ? null : options[next].value);
        return;
      }
      case "Enter":
        if (open) event.preventDefault();
        if (open && active !== null) {
          choose(active);
        } else if (query === "" && value !== null) {
          onChange(null);
          close();
        }
        return;
      case "Escape":
        if (open) event.stopPropagation();
        close();
        return;
      default:
        return;
    }
  }

  function handleBlur(event: FocusEvent<HTMLInputElement>) {
    onBlur?.(event);
    if (query === "" && value !== null) onChange(null);
    close();
  }

  return (
    <div>
      <label id={labelId} htmlFor={inputId}>
        {label}
      </label>
      <input
        {...rest}
        id={inputId}
        type="text"
        role="combobox"
        autoComplete="off"
        aria-autocomplete="list"
        aria-expanded={open}
        aria-controls={listboxId}
        aria-activedescendant={open && active !== null ? optionId(active) : undefined}
        value={text}
        onChange={handleChange}
        onKeyDown={handleKeyDown}
        onBlur={handleBlur}
      />
      <div
        id={listboxId}
        role="listbox"
        aria-labelledby={labelId}
        hidden={!open}
        // Keep focus in the input while the mouse is pressed on an option, so blur does not close it first.
        onMouseDown={(event) => event.preventDefault()}
      >
        {visible.map((index) => {
          const option = options[index];
          return (
            <div
              key={index}
              id={optionId(index)}
              role="option"
              aria-selected={option.value === value}
              aria-disabled={option.disabled === true}
              data-active={index === active ? "" : undefined}
              onClick={option.disabled ? undefined : () => choose(index)}
            >
              {option.label}
            </div>
          );
        })}
        {visible.length === 0 ? <div>No results</div> : null}
      </div>
    </div>
  );
}

import {
  createContext,
  useCallback,
  useContext,
  useId,
  useLayoutEffect,
  useRef,
  useState,
  type ComponentPropsWithoutRef,
  type KeyboardEvent,
} from "react";

export type TabsProps = Omit<ComponentPropsWithoutRef<"div">, "defaultValue"> & {
  defaultValue?: string;
  value?: string;
  onValueChange?: (value: string) => void;
};

export type TabListProps = Omit<ComponentPropsWithoutRef<"div">, "role"> & {
  "aria-label": string;
};

export type TabProps = Omit<ComponentPropsWithoutRef<"button">, "value" | "type" | "role" | "disabled"> & {
  value: string;
  disabled?: boolean;
};

export type TabPanelProps = Omit<ComponentPropsWithoutRef<"div">, "role"> & {
  value: string;
};

type TabsContextValue = {
  baseId: string;
  active: string | undefined;
  select: (value: string) => void;
  refresh: () => void;
};

const TabsContext = createContext<TabsContextValue | null>(null);

function useTabsContext(): TabsContextValue {
  const context = useContext(TabsContext);
  if (!context) {
    throw new Error("Tab, TabList and TabPanel must be rendered inside <Tabs>");
  }
  return context;
}

// encodeURIComponent keeps ids free of spaces (aria-controls is a token list) and distinct per value.
const tabId = (baseId: string, value: string) => `${baseId}-tab-${encodeURIComponent(value)}`;
const panelId = (baseId: string, value: string) => `${baseId}-panel-${encodeURIComponent(value)}`;

export function Tabs({ defaultValue, value, onValueChange, children, ...rest }: TabsProps) {
  const baseId = useId();
  const rootRef = useRef<HTMLDivElement>(null);
  const [internalValue, setInternalValue] = useState(defaultValue);
  const [fallback, setFallback] = useState<string>();
  const [, setVersion] = useState(0);
  // Tabs can mount, unmount or change without Tabs re-rendering (a child component owns them), so they call this.
  const refresh = useCallback(() => setVersion((version) => version + 1), []);

  const controlled = value !== undefined;
  const selected = controlled ? value : internalValue;
  // Trust a requested value on the first commit, so focus logic that runs before the DOM check still sees it.
  const [selectable, setSelectable] = useState(selected !== undefined);
  // The effective selection: the requested value if it names an enabled tab, otherwise the first enabled tab.
  const active = selectable ? selected : fallback;

  // Tabs are read from the DOM after each render, and after every tab mount, unmount or change (see refresh).
  // Setting primitive state to an unchanged value bails out, so this cannot loop.
  useLayoutEffect(() => {
    const tabs = Array.from(rootRef.current?.querySelectorAll<HTMLButtonElement>('[role="tab"]') ?? []);
    const enabled = tabs.filter((tab) => !tab.disabled).map((tab) => tab.dataset.value);
    setFallback(enabled[0]);
    setSelectable(enabled.includes(selected));
  });

  function select(next: string) {
    if (next === active) return;
    if (!controlled) setInternalValue(next);
    onValueChange?.(next);
  }

  return (
    <TabsContext.Provider value={{ baseId, active, select, refresh }}>
      <div {...rest} ref={rootRef}>
        {children}
      </div>
    </TabsContext.Provider>
  );
}

export function TabList({ onKeyDown, children, ...rest }: TabListProps) {
  const { select } = useTabsContext();

  function handleKeyDown(event: KeyboardEvent<HTMLDivElement>) {
    onKeyDown?.(event);
    const tabs = Array.from(event.currentTarget.querySelectorAll<HTMLButtonElement>('[role="tab"]:not(:disabled)'));
    const last = tabs.length - 1;
    const index = tabs.indexOf(event.target as HTMLButtonElement);
    let nextIndex: number;
    switch (event.key) {
      case "ArrowRight":
        nextIndex = index >= last ? 0 : index + 1;
        break;
      case "ArrowLeft":
        nextIndex = index <= 0 ? last : index - 1;
        break;
      case "Home":
        nextIndex = 0;
        break;
      case "End":
        nextIndex = last;
        break;
      default:
        return;
    }
    const next = tabs[nextIndex];
    if (!next) return;
    event.preventDefault();
    next.focus();
    select(next.dataset.value ?? "");
  }

  return (
    <div {...rest} role="tablist" onKeyDown={handleKeyDown}>
      {children}
    </div>
  );
}

export function Tab({ value, disabled = false, onClick, ...rest }: TabProps) {
  const { baseId, active, select, refresh } = useTabsContext();
  const selected = value === active;

  // Re-run the fallback selection when this tab mounts, unmounts, or its value or disabled state changes.
  useLayoutEffect(() => {
    refresh();
    return refresh;
  }, [refresh, value, disabled]);

  return (
    <button
      {...rest}
      type="button"
      role="tab"
      id={tabId(baseId, value)}
      data-value={value}
      aria-selected={selected}
      aria-controls={panelId(baseId, value)}
      tabIndex={selected ? 0 : -1}
      disabled={disabled}
      onClick={(event) => {
        onClick?.(event);
        select(value);
      }}
    />
  );
}

export function TabPanel({ value, ...rest }: TabPanelProps) {
  const { baseId, active } = useTabsContext();

  return (
    <div
      {...rest}
      role="tabpanel"
      id={panelId(baseId, value)}
      aria-labelledby={tabId(baseId, value)}
      tabIndex={0}
      hidden={value !== active}
    />
  );
}

import {
  createContext,
  useContext,
  useId,
  useLayoutEffect,
  useRef,
  useState,
  type ButtonHTMLAttributes,
  type HTMLAttributes,
  type KeyboardEvent,
  type RefObject,
} from "react";

export interface TabsProps extends Omit<HTMLAttributes<HTMLDivElement>, "defaultValue"> {
  defaultValue?: string;
  value?: string;
  onValueChange?: (value: string) => void;
}

export interface TabListProps extends HTMLAttributes<HTMLDivElement> {
  "aria-label": string;
}

export interface TabProps extends ButtonHTMLAttributes<HTMLButtonElement> {
  value: string;
}

export interface TabPanelProps extends HTMLAttributes<HTMLDivElement> {
  value: string;
}

interface RegisteredTab {
  value: string;
  disabled: boolean;
  ref: RefObject<HTMLButtonElement | null>;
}

interface TabsContextValue {
  id: string;
  selected: string | undefined;
  tabStop: string | undefined;
  select: (value: string) => void;
  register: (tab: RegisteredTab) => () => void;
}

const TabsContext = createContext<TabsContextValue | null>(null);

function useTabsContext() {
  const context = useContext(TabsContext);
  if (!context) {
    throw new Error("Tab, TabList and TabPanel must be rendered inside <Tabs>");
  }
  return context;
}

const tabId = (id: string, value: string) => `${id}-tab-${encodeURIComponent(value)}`;
const panelId = (id: string, value: string) => `${id}-panel-${encodeURIComponent(value)}`;

// Enabled tab values in DOM order, so tabs added by conditional rendering keep their place.
function enabledValues(tabs: RegisteredTab[]) {
  return tabs
    .flatMap((tab) => (tab.disabled || !tab.ref.current ? [] : [{ value: tab.value, element: tab.ref.current }]))
    .sort((a, b) => (a.element.compareDocumentPosition(b.element) & Node.DOCUMENT_POSITION_FOLLOWING ? -1 : 1))
    .map((tab) => tab.value);
}

// Enabled tabs of this tablist only, in DOM order. Nested tablists are excluded.
function enabledTabs(list: HTMLElement | null) {
  const tabs = list?.querySelectorAll<HTMLElement>('[role="tab"]:not(:disabled)') ?? [];
  return Array.from(tabs).filter((tab) => tab.closest('[role="tablist"]') === list);
}

export function Tabs({ defaultValue, value, onValueChange, children, ...rest }: TabsProps) {
  const id = useId();
  const [internal, setInternal] = useState(defaultValue);
  const [tabs, setTabs] = useState<RegisteredTab[]>([]);
  const controlled = value !== undefined;
  const enabled = enabledValues(tabs);
  // Uncontrolled: fall back to the first enabled tab when the chosen one is missing, disabled or removed.
  // Controlled: the prop wins for aria-selected; only the tab stop moves to the first enabled tab.
  const selected = controlled ? value : internal !== undefined && enabled.includes(internal) ? internal : (enabled[0] ?? internal);
  const tabStop = selected !== undefined && enabled.includes(selected) ? selected : enabled[0];

  const select = (next: string) => {
    if (next === selected) return;
    if (!controlled) setInternal(next);
    onValueChange?.(next);
  };

  const register = (tab: RegisteredTab) => {
    setTabs((current) => [...current, tab]);
    return () => setTabs((current) => current.filter((item) => item !== tab));
  };

  return (
    <TabsContext.Provider value={{ id, selected, tabStop, select, register }}>
      <div {...rest}>{children}</div>
    </TabsContext.Provider>
  );
}

export function TabList({ onKeyDown, children, ...rest }: TabListProps) {
  const { select } = useTabsContext();
  const listRef = useRef<HTMLDivElement>(null);

  const handleKeyDown = (event: KeyboardEvent<HTMLDivElement>) => {
    onKeyDown?.(event);
    const tabs = enabledTabs(listRef.current);
    const index = tabs.indexOf(event.target as HTMLElement);
    if (index === -1) return;

    const last = tabs.length - 1;
    let next: number;
    switch (event.key) {
      case "ArrowRight":
      case "ArrowDown":
        next = index === last ? 0 : index + 1;
        break;
      case "ArrowLeft":
      case "ArrowUp":
        next = index === 0 ? last : index - 1;
        break;
      case "Home":
        next = 0;
        break;
      case "End":
        next = last;
        break;
      default:
        return;
    }

    event.preventDefault();
    const tab = tabs[next];
    tab.focus();
    const value = tab.dataset.value;
    if (value !== undefined) select(value);
  };

  return (
    <div {...rest} ref={listRef} role="tablist" onKeyDown={handleKeyDown}>
      {children}
    </div>
  );
}

export function Tab({ value, disabled, onClick, children, ...rest }: TabProps) {
  const { id, selected, tabStop, select, register } = useTabsContext();
  const ref = useRef<HTMLButtonElement>(null);

  useLayoutEffect(() => register({ value, disabled: Boolean(disabled), ref }), [value, disabled]);

  return (
    <button
      {...rest}
      ref={ref}
      type="button"
      role="tab"
      id={tabId(id, value)}
      aria-controls={panelId(id, value)}
      aria-selected={selected === value}
      tabIndex={value === tabStop ? 0 : -1}
      disabled={disabled}
      data-value={value}
      onClick={(event) => {
        onClick?.(event);
        select(value);
      }}
    >
      {children}
    </button>
  );
}

export function TabPanel({ value, children, ...rest }: TabPanelProps) {
  const { id, selected } = useTabsContext();

  return (
    <div
      {...rest}
      role="tabpanel"
      id={panelId(id, value)}
      aria-labelledby={tabId(id, value)}
      tabIndex={0}
      hidden={selected !== value}
    >
      {children}
    </div>
  );
}

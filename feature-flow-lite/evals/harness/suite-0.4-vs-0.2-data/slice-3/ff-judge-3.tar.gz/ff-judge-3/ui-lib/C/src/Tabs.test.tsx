import { fireEvent, render, screen } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { describe, expect, it, vi } from "vitest";
import { Tab, TabList, TabPanel, Tabs, type TabsProps } from "./Tabs";

function Fruits(props: TabsProps) {
  return (
    <Tabs {...props}>
      <TabList aria-label="Fruits">
        <Tab value="apple">Apple</Tab>
        <Tab value="banana" disabled>
          Banana
        </Tab>
        <Tab value="cherry">Cherry</Tab>
      </TabList>
      <TabPanel value="apple">Apple panel</TabPanel>
      <TabPanel value="banana">Banana panel</TabPanel>
      <TabPanel value="cherry">Cherry panel</TabPanel>
    </Tabs>
  );
}

describe("Tabs", () => {
  it("renders tablist, tabs and panels with linked ids and roles", () => {
    render(<Fruits />);
    const list = screen.getByRole("tablist", { name: "Fruits" });
    expect(list).toHaveAttribute("aria-orientation", "horizontal");
    const apple = screen.getByRole("tab", { name: "Apple" });
    expect(apple.tagName).toBe("BUTTON");
    expect(apple).toHaveAttribute("type", "button");
    expect(apple).toHaveAttribute("aria-selected", "true");
    expect(screen.getByRole("tab", { name: "Cherry" })).toHaveAttribute("aria-selected", "false");

    const panel = screen.getByRole("tabpanel", { name: "Apple" });
    expect(panel).toHaveAttribute("id", apple.getAttribute("aria-controls"));
    expect(panel).toHaveAttribute("tabindex", "0");
    expect(panel).toHaveTextContent("Apple panel");
    expect(screen.queryByText("Cherry panel")).not.toBeVisible();
  });

  it("gives tabIndex 0 only to the selected tab", () => {
    render(<Fruits defaultValue="cherry" />);
    expect(screen.getByRole("tab", { name: "Cherry" })).toHaveAttribute("tabindex", "0");
    expect(screen.getByRole("tab", { name: "Apple" })).toHaveAttribute("tabindex", "-1");
    expect(screen.getByRole("tab", { name: "Banana" })).toHaveAttribute("tabindex", "-1");
  });

  it("makes the first enabled tab reachable when nothing is selected", () => {
    render(<Fruits defaultValue="nope" />);
    expect(screen.getByRole("tab", { name: "Apple" })).toHaveAttribute("tabindex", "0");
    expect(screen.getByRole("tab", { name: "Apple" })).toHaveAttribute("aria-selected", "true");
  });

  it("moves focus with arrows, skipping disabled tabs and wrapping", async () => {
    const user = userEvent.setup();
    const onValueChange = vi.fn();
    render(<Fruits onValueChange={onValueChange} />);
    screen.getByRole("tab", { name: "Apple" }).focus();

    await user.keyboard("{ArrowRight}");
    expect(screen.getByRole("tab", { name: "Cherry" })).toHaveFocus();
    expect(onValueChange).toHaveBeenLastCalledWith("cherry");
    expect(screen.getByRole("tab", { name: "Cherry" })).toHaveAttribute("aria-selected", "true");

    await user.keyboard("{ArrowRight}");
    expect(screen.getByRole("tab", { name: "Apple" })).toHaveFocus();

    await user.keyboard("{ArrowLeft}");
    expect(screen.getByRole("tab", { name: "Cherry" })).toHaveFocus();
    expect(screen.getByRole("tab", { name: "Cherry" })).toHaveAttribute("aria-selected", "true");
  });

  it("moves to the first and last enabled tab with Home and End", async () => {
    const user = userEvent.setup();
    render(<Fruits />);
    screen.getByRole("tab", { name: "Apple" }).focus();
    await user.keyboard("{End}");
    expect(screen.getByRole("tab", { name: "Cherry" })).toHaveFocus();
    await user.keyboard("{Home}");
    expect(screen.getByRole("tab", { name: "Apple" })).toHaveFocus();
  });

  it("prevents default only for handled keys", () => {
    render(<Fruits />);
    const apple = screen.getByRole("tab", { name: "Apple" });
    expect(fireEvent.keyDown(apple, { key: "ArrowRight" })).toBe(false);
    expect(fireEvent.keyDown(apple, { key: "a" })).toBe(true);
  });

  it("selects on click and ignores clicks on disabled tabs", async () => {
    const user = userEvent.setup();
    const onValueChange = vi.fn();
    render(<Fruits onValueChange={onValueChange} />);
    const banana = screen.getByRole("tab", { name: "Banana" });
    expect(banana).toHaveAttribute("aria-disabled", "true");

    await user.click(banana);
    expect(onValueChange).not.toHaveBeenCalled();
    expect(screen.getByRole("tab", { name: "Apple" })).toHaveAttribute("aria-selected", "true");

    await user.click(screen.getByRole("tab", { name: "Cherry" }));
    expect(onValueChange).toHaveBeenCalledWith("cherry");
    expect(screen.getByRole("tab", { name: "Cherry" })).toHaveAttribute("aria-selected", "true");
    expect(screen.getByRole("tabpanel", { name: "Cherry" })).toHaveTextContent("Cherry panel");
  });

  it("in controlled mode only calls onValueChange and leaves selection to the parent", async () => {
    const user = userEvent.setup();
    const onValueChange = vi.fn();
    render(<Fruits value="apple" onValueChange={onValueChange} />);
    await user.click(screen.getByRole("tab", { name: "Cherry" }));
    expect(onValueChange).toHaveBeenCalledWith("cherry");
    expect(screen.getByRole("tab", { name: "Apple" })).toHaveAttribute("aria-selected", "true");
    expect(screen.getByRole("tab", { name: "Cherry" })).toHaveAttribute("aria-selected", "false");
  });

  it("follows the parent when controlled value changes", () => {
    const { rerender } = render(<Fruits value="apple" />);
    rerender(<Fruits value="cherry" />);
    expect(screen.getByRole("tab", { name: "Cherry" })).toHaveAttribute("aria-selected", "true");
    expect(screen.getByRole("tabpanel", { name: "Cherry" })).toBeVisible();
  });

  it("follows DOM order when tabs are reordered", async () => {
    const user = userEvent.setup();
    const Reorder = ({ reversed }: { reversed: boolean }) => {
      const tabs = [
        <Tab key="apple" value="apple">Apple</Tab>,
        <Tab key="cherry" value="cherry">Cherry</Tab>,
      ];
      return (
        <Tabs defaultValue="apple">
          <TabList aria-label="Fruits">{reversed ? tabs.reverse() : tabs}</TabList>
        </Tabs>
      );
    };
    const { rerender } = render(<Reorder reversed={false} />);
    rerender(<Reorder reversed />);
    screen.getByRole("tab", { name: "Cherry" }).focus();
    await user.keyboard("{ArrowRight}");
    expect(screen.getByRole("tab", { name: "Apple" })).toHaveFocus();
    await user.keyboard("{ArrowRight}");
    expect(screen.getByRole("tab", { name: "Cherry" })).toHaveFocus();
  });

  it("does nothing with arrows when all tabs are disabled", async () => {
    const user = userEvent.setup();
    const onValueChange = vi.fn();
    render(
      <Tabs onValueChange={onValueChange}>
        <TabList aria-label="Off">
          <Tab value="a" disabled>A</Tab>
          <Tab value="b" disabled>B</Tab>
        </TabList>
        <TabPanel value="a">A panel</TabPanel>
      </Tabs>,
    );
    screen.getByRole("tab", { name: "A" }).focus();
    await user.keyboard("{ArrowRight}{Home}{End}");
    expect(screen.getByRole("tab", { name: "A" })).toHaveFocus();
    expect(onValueChange).not.toHaveBeenCalled();
    expect(screen.queryByRole("tabpanel")).toBeNull();
  });

  it("keeps focus on the only enabled tab without repeating onValueChange", async () => {
    const user = userEvent.setup();
    const onValueChange = vi.fn();
    render(
      <Tabs onValueChange={onValueChange}>
        <TabList aria-label="One">
          <Tab value="a">A</Tab>
          <Tab value="b" disabled>B</Tab>
        </TabList>
      </Tabs>,
    );
    screen.getByRole("tab", { name: "A" }).focus();
    await user.keyboard("{ArrowRight}{ArrowLeft}");
    expect(screen.getByRole("tab", { name: "A" })).toHaveFocus();
    expect(onValueChange).not.toHaveBeenCalled();
  });

  it("shows no panel and keeps the first tab reachable when value matches no tab", () => {
    render(<Fruits value="nope" />);
    expect(screen.getByRole("tab", { name: "Apple" })).toHaveAttribute("tabindex", "0");
    expect(screen.queryAllByRole("tab", { selected: true })).toHaveLength(0);
    expect(screen.queryByRole("tabpanel")).toBeNull();
  });

  it("gives two Tabs instances distinct ids and independent keyboard handling", async () => {
    const user = userEvent.setup();
    render(
      <>
        <Fruits />
        <Fruits />
      </>,
    );
    const [first, second] = screen.getAllByRole("tablist");
    const firstApple = first.querySelector<HTMLElement>('[role="tab"]')!;
    const secondApple = second.querySelector<HTMLElement>('[role="tab"]')!;
    expect(firstApple.id).not.toBe(secondApple.id);
    expect(firstApple.getAttribute("aria-controls")).not.toBe(secondApple.getAttribute("aria-controls"));

    firstApple.focus();
    await user.keyboard("{ArrowRight}");
    expect(first.querySelector('[aria-selected="true"]')).toHaveTextContent("Cherry");
    expect(second.querySelector('[aria-selected="true"]')).toHaveTextContent("Apple");
  });

  it("throws a clear error when a Tab is used outside Tabs", () => {
    vi.spyOn(console, "error").mockImplementation(() => {});
    expect(() => render(<Tab value="a">A</Tab>)).toThrow("Tab components must be rendered inside <Tabs>");
    vi.restoreAllMocks();
  });
});

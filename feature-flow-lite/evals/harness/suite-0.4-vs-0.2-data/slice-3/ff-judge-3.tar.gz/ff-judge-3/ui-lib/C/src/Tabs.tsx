import {
  createContext,
  useContext,
  useId,
  useLayoutEffect,
  useRef,
  useState,
  type ButtonHTMLAttributes,
  type Dispatch,
  type HTMLAttributes,
  type KeyboardEvent,
  type SetStateAction,
} from "react";

export interface TabsProps extends Omit<HTMLAttributes<HTMLDivElement>, "defaultValue"> {
  defaultValue?: string;
  value?: string;
  onValueChange?: (value: string) => void;
}

export interface TabListProps extends HTMLAttributes<HTMLDivElement> {
  "aria-label": string;
}

export interface TabProps extends Omit<ButtonHTMLAttributes<HTMLButtonElement>, "value"> {
  value: string;
  disabled?: boolean;
}

export interface TabPanelProps extends HTMLAttributes<HTMLDivElement> {
  value: string;
}

interface TabsContextValue {
  base: string;
  /** The tab shown as selected (null when nothing is selected). */
  active: string | null;
  /** The tab that receives tabIndex 0 (the selected tab, or the first enabled one). */
  focusable: string | null;
  select: (value: string) => void;
  setEnabled: Dispatch<SetStateAction<string[]>>;
}

const TabsContext = createContext<TabsContextValue | null>(null);

function useTabsContext(): TabsContextValue {
  const ctx = useContext(TabsContext);
  if (!ctx) throw new Error("Tab components must be rendered inside <Tabs>");
  return ctx;
}

function tabId(base: string, value: string): string {
  return `${base}-tab-${encodeURIComponent(value)}`;
}

function panelId(base: string, value: string): string {
  return `${base}-panel-${encodeURIComponent(value)}`;
}

function tabsIn(list: Element): HTMLElement[] {
  return Array.from(list.querySelectorAll<HTMLElement>('[role="tab"]'));
}

function isEnabled(tab: HTMLElement): boolean {
  return tab.getAttribute("aria-disabled") !== "true";
}

function reportEnabled(setEnabled: Dispatch<SetStateAction<string[]>>, tabs: HTMLElement[]) {
  const next = tabs.map((tab) => tab.dataset.value ?? "");
  setEnabled((prev) => (prev.join("\n") === next.join("\n") ? prev : next));
}

export function Tabs({ defaultValue, value, onValueChange, children, ...rest }: TabsProps) {
  const base = useId();
  const isControlled = value !== undefined;
  const [internal, setInternal] = useState(defaultValue);
  const [enabled, setEnabled] = useState<string[]>([]);

  const current = isControlled ? value : internal;
  const selected = current !== undefined && enabled.includes(current) ? current : null;
  const first = enabled[0] ?? null;
  const active = selected ?? (isControlled ? null : first);
  const focusable = selected ?? first;

  function select(next: string) {
    if (!isControlled) setInternal(next);
    onValueChange?.(next);
  }

  return (
    <TabsContext.Provider value={{ base, active, focusable, select, setEnabled }}>
      <div {...rest}>{children}</div>
    </TabsContext.Provider>
  );
}

export function TabList({ onKeyDown, children, ...rest }: TabListProps) {
  const ctx = useTabsContext();

  function handleKeyDown(event: KeyboardEvent<HTMLDivElement>) {
    onKeyDown?.(event);
    // Read the DOM at key time so reordered or conditionally rendered tabs are honoured.
    const tabs = tabsIn(event.currentTarget);
    const from = tabs.indexOf(event.target as HTMLElement);
    if (from === -1) return;
    const count = tabs.length;
    let target: HTMLElement | undefined;

    switch (event.key) {
      case "ArrowRight":
      case "ArrowLeft": {
        const step = event.key === "ArrowRight" ? 1 : -1;
        for (let i = 1; i <= count && !target; i++) {
          const candidate = tabs[(from + step * i + count) % count];
          if (isEnabled(candidate)) target = candidate;
        }
        break;
      }
      case "Home":
        target = tabs.find(isEnabled);
        break;
      case "End":
        target = [...tabs].reverse().find(isEnabled);
        break;
      default:
        return;
    }

    event.preventDefault();
    if (!target) return;
    target.focus();
    const next = target.dataset.value ?? "";
    if (next !== ctx.active) ctx.select(next);
  }

  return (
    <div
      {...rest}
      role="tablist"
      aria-orientation="horizontal"
      onKeyDown={handleKeyDown}
    >
      {children}
    </div>
  );
}

export function Tab({ value, disabled = false, onClick, children, ...rest }: TabProps) {
  const ctx = useTabsContext();
  const ref = useRef<HTMLButtonElement>(null);

  // Report the enabled tabs to Tabs after every render, and again without this tab on unmount.
  useLayoutEffect(() => {
    const list = ref.current?.closest('[role="tablist"]');
    if (list) reportEnabled(ctx.setEnabled, tabsIn(list).filter(isEnabled));
  });

  useLayoutEffect(() => {
    const el = ref.current;
    const list = el?.closest('[role="tablist"]');
    return () => {
      if (list && el) reportEnabled(ctx.setEnabled, tabsIn(list).filter((tab) => tab !== el && isEnabled(tab)));
    };
  }, []);

  return (
    <button
      {...rest}
      ref={ref}
      type="button"
      role="tab"
      id={tabId(ctx.base, value)}
      data-value={value}
      aria-selected={ctx.active === value}
      aria-controls={panelId(ctx.base, value)}
      aria-disabled={disabled || undefined}
      tabIndex={ctx.focusable === value ? 0 : -1}
      onClick={(event) => {
        onClick?.(event);
        if (!disabled && ctx.active !== value) ctx.select(value);
      }}
    >
      {children}
    </button>
  );
}

export function TabPanel({ value, children, ...rest }: TabPanelProps) {
  const ctx = useTabsContext();
  return (
    <div
      {...rest}
      role="tabpanel"
      id={panelId(ctx.base, value)}
      aria-labelledby={tabId(ctx.base, value)}
      tabIndex={0}
      hidden={ctx.active !== value}
    >
      {children}
    </div>
  );
}

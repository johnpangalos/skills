import { fireEvent, render, screen } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { useState } from "react";
import { describe, expect, it, vi } from "vitest";
import { Combobox } from "./Combobox";
import { Dialog } from "./Dialog";

function Harness({ initialOpen = false }: { initialOpen?: boolean }) {
  const [open, setOpen] = useState(initialOpen);
  return (
    <>
      <button onClick={() => setOpen(true)}>Open</button>
      <Dialog open={open} onOpenChange={setOpen} title="Edit profile">
        <input aria-label="Name" />
        <button onClick={() => setOpen(false)}>Done</button>
      </Dialog>
    </>
  );
}

describe("Dialog", () => {
  it("renders nothing when closed", () => {
    render(<Dialog open={false} onOpenChange={() => {}} title="Hidden" />);
    expect(screen.queryByRole("dialog")).toBeNull();
    expect(screen.queryByText("Hidden")).toBeNull();
  });

  it("renders a modal dialog labelled by its title in a portal", () => {
    const { container } = render(
      <Dialog open onOpenChange={() => {}} title="Delete item" description="This cannot be undone.">
        <button>Confirm</button>
      </Dialog>,
    );
    const dialog = screen.getByRole("dialog", { name: "Delete item" });
    expect(dialog).toHaveAttribute("aria-modal", "true");
    expect(dialog).toHaveAccessibleDescription("This cannot be undone.");
    expect(dialog.getAttribute("aria-describedby")).not.toBeNull();
    expect(container).not.toContainElement(dialog);
    expect(document.body).toContainElement(dialog);
  });

  it("omits aria-describedby when no description is given", () => {
    render(<Dialog open onOpenChange={() => {}} title="Plain" />);
    expect(screen.getByRole("dialog", { name: "Plain" })).not.toHaveAttribute("aria-describedby");
  });

  it("forwards className to the dialog element", () => {
    render(<Dialog open onOpenChange={() => {}} title="Styled" className="panel" />);
    expect(screen.getByRole("dialog")).toHaveClass("panel");
  });

  it("focuses the first focusable element on open", () => {
    render(
      <Dialog open onOpenChange={() => {}} title="Form">
        <input aria-label="Name" />
        <button>Save</button>
      </Dialog>,
    );
    expect(screen.getByRole("textbox", { name: "Name" })).toHaveFocus();
  });

  it("focuses the dialog itself when it has no focusable content", () => {
    render(<Dialog open onOpenChange={() => {}} title="Notice">Just text</Dialog>);
    expect(screen.getByRole("dialog")).toHaveFocus();
  });

  it("keeps focus on the dialog when Tab is pressed with no focusable content", async () => {
    const user = userEvent.setup();
    render(<Dialog open onOpenChange={() => {}} title="Notice">Just text</Dialog>);
    await user.tab();
    expect(screen.getByRole("dialog")).toHaveFocus();
  });

  it("wraps Tab from the last focusable element to the first, skipping disabled and tabindex -1", async () => {
    const user = userEvent.setup();
    render(
      <Dialog open onOpenChange={() => {}} title="Trap">
        <button>First</button>
        <button disabled>Disabled</button>
        <button tabIndex={-1}>Skipped</button>
        <button>Last</button>
      </Dialog>,
    );
    expect(screen.getByRole("button", { name: "First" })).toHaveFocus();
    await user.tab();
    expect(screen.getByRole("button", { name: "Last" })).toHaveFocus();
    await user.tab();
    expect(screen.getByRole("button", { name: "First" })).toHaveFocus();
  });

  it("wraps Shift+Tab from the first element, and from the dialog itself, to the last", async () => {
    const user = userEvent.setup();
    render(
      <Dialog open onOpenChange={() => {}} title="Trap">
        <button>First</button>
        <button>Last</button>
      </Dialog>,
    );
    await user.tab({ shift: true });
    expect(screen.getByRole("button", { name: "Last" })).toHaveFocus();

    screen.getByRole("dialog").focus();
    await user.tab({ shift: true });
    expect(screen.getByRole("button", { name: "Last" })).toHaveFocus();
  });

  it("calls onOpenChange(false) on Escape pressed inside a nested input", async () => {
    const user = userEvent.setup();
    const onOpenChange = vi.fn();
    render(
      <Dialog open onOpenChange={onOpenChange} title="Search">
        <input aria-label="Query" />
      </Dialog>,
    );
    await user.type(screen.getByRole("textbox", { name: "Query" }), "{Escape}");
    expect(onOpenChange).toHaveBeenCalledTimes(1);
    expect(onOpenChange).toHaveBeenCalledWith(false);
  });

  it("closes on a backdrop click but not on a click inside the panel", async () => {
    const user = userEvent.setup();
    const onOpenChange = vi.fn();
    render(
      <Dialog open onOpenChange={onOpenChange} title="Info">
        <p>Body text</p>
      </Dialog>,
    );
    await user.click(screen.getByText("Body text"));
    await user.click(screen.getByRole("heading", { name: "Info" }));
    expect(onOpenChange).not.toHaveBeenCalled();

    await user.click(screen.getByRole("dialog").parentElement!);
    expect(onOpenChange).toHaveBeenCalledTimes(1);
    expect(onOpenChange).toHaveBeenCalledWith(false);
  });

  it("restores focus to the previously focused element when closed", async () => {
    const user = userEvent.setup();
    render(<Harness />);
    const open = screen.getByRole("button", { name: "Open" });

    for (let cycle = 0; cycle < 2; cycle++) {
      await user.click(open);
      expect(screen.getByRole("textbox", { name: "Name" })).toHaveFocus();
      await user.click(screen.getByRole("button", { name: "Done" }));
      expect(screen.queryByRole("dialog")).toBeNull();
      expect(open).toHaveFocus();
    }
  });

  it("does not throw when the trigger was removed while open", () => {
    const trigger = document.createElement("button");
    document.body.append(trigger);
    trigger.focus();
    const dialog = (open: boolean) => (
      <Dialog open={open} onOpenChange={() => {}} title="Orphan">
        <button>Inside</button>
      </Dialog>
    );
    const { rerender } = render(dialog(true));
    trigger.remove();
    expect(() => rerender(dialog(false))).not.toThrow();
    expect(screen.queryByRole("dialog")).toBeNull();
    expect(document.activeElement).not.toBe(trigger);
  });

  it("stays open when the parent ignores onOpenChange", async () => {
    const user = userEvent.setup();
    const onOpenChange = vi.fn();
    render(
      <Dialog open onOpenChange={onOpenChange} title="Sticky">
        <input aria-label="Field" />
      </Dialog>,
    );
    await user.keyboard("{Escape}");
    await user.click(screen.getByRole("dialog").parentElement!);
    expect(onOpenChange).toHaveBeenCalledTimes(2);
    expect(screen.getByRole("dialog", { name: "Sticky" })).toBeInTheDocument();
  });

  it("does not close when a drag starts on the backdrop and ends inside the panel", () => {
    const onOpenChange = vi.fn();
    render(
      <Dialog open onOpenChange={onOpenChange} title="Drag">
        <p>Body text</p>
      </Dialog>,
    );
    const backdrop = screen.getByRole("dialog").parentElement!;
    fireEvent.mouseDown(backdrop);
    fireEvent.mouseUp(screen.getByText("Body text"));
    fireEvent.click(backdrop);
    expect(onOpenChange).not.toHaveBeenCalled();
  });

  it("keeps focus inside the dialog when the backdrop is pressed", async () => {
    const user = userEvent.setup();
    const onOpenChange = vi.fn();
    render(
      <Dialog open onOpenChange={onOpenChange} title="Focus">
        <input aria-label="Field" />
      </Dialog>,
    );
    const field = screen.getByRole("textbox", { name: "Field" });
    await user.click(screen.getByRole("dialog").parentElement!);
    expect(onOpenChange).toHaveBeenCalledTimes(1);
    expect(field).toHaveFocus();

    await user.keyboard("{Escape}");
    expect(onOpenChange).toHaveBeenCalledTimes(2);
    expect(onOpenChange).toHaveBeenLastCalledWith(false);
  });

  it("lets an open Combobox consume Escape, and closes the dialog only once the list is closed", async () => {
    const user = userEvent.setup();
    const onOpenChange = vi.fn();
    render(
      <Dialog open onOpenChange={onOpenChange} title="Pick">
        <Combobox label="Fruit" options={[{ value: "apple", label: "Apple" }]} value={null} onChange={() => {}} />
      </Dialog>,
    );
    const box = screen.getByRole("combobox", { name: "Fruit" });
    await user.keyboard("{ArrowDown}");
    expect(box).toHaveAttribute("aria-expanded", "true");

    await user.keyboard("{Escape}");
    expect(box).toHaveAttribute("aria-expanded", "false");
    expect(onOpenChange).not.toHaveBeenCalled();

    await user.keyboard("{Escape}");
    expect(onOpenChange).toHaveBeenCalledTimes(1);
    expect(onOpenChange).toHaveBeenCalledWith(false);
  });

  it("calls a consumer onKeyDown before its own Escape handling", async () => {
    const user = userEvent.setup();
    const onKeyDown = vi.fn();
    const onOpenChange = vi.fn();
    render(
      <Dialog open onOpenChange={onOpenChange} title="Chained" onKeyDown={onKeyDown}>
        <input aria-label="Note" />
      </Dialog>,
    );
    await user.keyboard("{Escape}");
    expect(onKeyDown).toHaveBeenCalledTimes(1);
    expect(onOpenChange).toHaveBeenCalledWith(false);
  });

  it("skips its own Escape handling when a consumer onKeyDown prevents default", async () => {
    const user = userEvent.setup();
    const onOpenChange = vi.fn();
    render(
      <Dialog open onOpenChange={onOpenChange} title="Chained" onKeyDown={(event) => event.preventDefault()}>
        <input aria-label="Note" />
      </Dialog>,
    );
    await user.keyboard("{Escape}");
    expect(onOpenChange).not.toHaveBeenCalled();
  });

  it("closes only the innermost dialog on Escape", async () => {
    const user = userEvent.setup();
    const outer = vi.fn();
    const inner = vi.fn();
    render(
      <Dialog open onOpenChange={outer} title="Outer">
        <Dialog open onOpenChange={inner} title="Inner">
          <button>Inner action</button>
        </Dialog>
      </Dialog>,
    );
    screen.getByRole("button", { name: "Inner action" }).focus();
    await user.keyboard("{Escape}");
    expect(inner).toHaveBeenCalledWith(false);
    expect(outer).not.toHaveBeenCalled();
  });

  it("keeps Tab inside when an element has a negative tabindex other than -1", async () => {
    const user = userEvent.setup();
    render(
      <>
        <Dialog open onOpenChange={() => {}} title="Trap">
          <button>First</button>
          <button>Last</button>
          <button tabIndex={-2}>Untabbable</button>
        </Dialog>
        <button>Outside</button>
      </>,
    );
    screen.getByRole("button", { name: "Last" }).focus();
    await user.tab();
    expect(screen.getByRole("button", { name: "First" })).toHaveFocus();
  });

  it("closes on a backdrop click event with no recorded press, and not after a press that started in the panel", () => {
    const onOpenChange = vi.fn();
    render(
      <Dialog open onOpenChange={onOpenChange} title="Backdrop">
        <button>Inside</button>
      </Dialog>,
    );
    const panel = screen.getByRole("dialog");
    const backdrop = panel.parentElement!;
    fireEvent.mouseDown(panel);
    fireEvent.mouseUp(backdrop);
    fireEvent.click(backdrop);
    expect(onOpenChange).not.toHaveBeenCalled();
    fireEvent.click(backdrop);
    expect(onOpenChange).toHaveBeenCalledTimes(1);
    expect(onOpenChange).toHaveBeenCalledWith(false);
  });
});

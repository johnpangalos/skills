import { fireEvent, render, screen } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { Tab, TabList, TabPanel, Tabs, type TabsProps } from "./Tabs";

function ThreeTabs({ disabledValue, ...props }: Omit<TabsProps, "children"> & { disabledValue?: string }) {
  return (
    <Tabs {...props}>
      <TabList aria-label="Sections">
        <Tab value="a" disabled={disabledValue === "a"}>Alpha</Tab>
        <Tab value="b" disabled={disabledValue === "b"}>Beta</Tab>
        <Tab value="c" disabled={disabledValue === "c"}>Gamma</Tab>
      </TabList>
      <TabPanel value="a">Panel A</TabPanel>
      <TabPanel value="b">Panel B</TabPanel>
      <TabPanel value="c">Panel C</TabPanel>
    </Tabs>
  );
}

describe("Tabs", () => {
  describe("selection", () => {
    it("selects the first tab when no defaultValue or value is given", () => {
      render(<ThreeTabs />);
      expect(screen.getByRole("tab", { name: "Alpha" })).toHaveAttribute("aria-selected", "true");
      expect(screen.getByRole("tabpanel")).toHaveTextContent("Panel A");
    });

    it("uncontrolled: defaultValue selects that tab and shows its panel", () => {
      render(<ThreeTabs defaultValue="b" />);
      expect(screen.getByRole("tab", { name: "Beta" })).toHaveAttribute("aria-selected", "true");
      expect(screen.getByRole("tabpanel")).toHaveTextContent("Panel B");
    });

    it("uncontrolled: clicking a tab selects it and calls onValueChange", async () => {
      const user = userEvent.setup();
      const onValueChange = vi.fn();
      render(<ThreeTabs onValueChange={onValueChange} />);
      await user.click(screen.getByRole("tab", { name: "Gamma" }));
      expect(onValueChange).toHaveBeenCalledWith("c");
      expect(screen.getByRole("tab", { name: "Gamma" })).toHaveAttribute("aria-selected", "true");
      expect(screen.getByRole("tabpanel")).toHaveTextContent("Panel C");
    });

    it("uncontrolled: does not call onValueChange when clicking the selected tab", async () => {
      const user = userEvent.setup();
      const onValueChange = vi.fn();
      render(<ThreeTabs defaultValue="a" onValueChange={onValueChange} />);
      await user.click(screen.getByRole("tab", { name: "Alpha" }));
      expect(onValueChange).not.toHaveBeenCalled();
    });

    it("controlled: selection only moves when the parent updates value", async () => {
      const user = userEvent.setup();
      const onValueChange = vi.fn();
      const { rerender } = render(<ThreeTabs value="a" onValueChange={onValueChange} />);

      await user.click(screen.getByRole("tab", { name: "Beta" }));
      expect(onValueChange).toHaveBeenCalledWith("b");
      expect(screen.getByRole("tab", { name: "Alpha" })).toHaveAttribute("aria-selected", "true");
      expect(screen.getByRole("tabpanel")).toHaveTextContent("Panel A");

      rerender(<ThreeTabs value="b" onValueChange={onValueChange} />);
      expect(screen.getByRole("tab", { name: "Beta" })).toHaveAttribute("aria-selected", "true");
      expect(screen.getByRole("tabpanel")).toHaveTextContent("Panel B");
    });

    it("controlled: a keypress calls onValueChange but does not move the panel when value never updates", async () => {
      const user = userEvent.setup();
      const onValueChange = vi.fn();
      render(<ThreeTabs value="a" onValueChange={onValueChange} />);
      screen.getByRole("tab", { name: "Alpha" }).focus();
      await user.keyboard("{ArrowRight}");
      expect(onValueChange).toHaveBeenCalledWith("b");
      expect(screen.getByRole("tab", { name: "Alpha" })).toHaveAttribute("aria-selected", "true");
      expect(screen.getByRole("tabpanel")).toHaveTextContent("Panel A");
    });

    it("controlled: a value naming a missing tab falls back to the first enabled tab", () => {
      render(<ThreeTabs value="zzz" />);
      expect(screen.getByRole("tab", { name: "Alpha" })).toHaveAttribute("aria-selected", "true");
      expect(screen.getByRole("tabpanel")).toHaveTextContent("Panel A");
    });

    it("falls back to the first enabled tab when defaultValue names a disabled tab", () => {
      render(<ThreeTabs defaultValue="a" disabledValue="a" />);
      expect(screen.getByRole("tab", { name: "Beta" })).toHaveAttribute("aria-selected", "true");
      expect(screen.getByRole("tabpanel")).toHaveTextContent("Panel B");
    });

    it("falls back to the first enabled tab when defaultValue names a missing tab", () => {
      render(<ThreeTabs defaultValue="missing" />);
      expect(screen.getByRole("tab", { name: "Alpha" })).toHaveAttribute("aria-selected", "true");
    });

    it("selects the first enabled tab when the first tab is disabled", () => {
      render(<ThreeTabs disabledValue="a" />);
      expect(screen.getByRole("tab", { name: "Beta" })).toHaveAttribute("aria-selected", "true");
      expect(screen.getByRole("tab", { name: "Alpha" })).toHaveAttribute("aria-selected", "false");
    });
  });

  describe("roles and aria", () => {
    it("wires tablist, tab and tabpanel roles, ids and references", () => {
      render(<ThreeTabs defaultValue="b" />);
      const list = screen.getByRole("tablist", { name: "Sections" });
      expect(list).toBeInTheDocument();

      const tab = screen.getByRole("tab", { name: "Beta" });
      expect(tab.tagName).toBe("BUTTON");
      expect(tab).toHaveAttribute("type", "button");
      expect(tab).toHaveAttribute("aria-controls", screen.getByRole("tabpanel").id);

      const panel = screen.getByRole("tabpanel");
      expect(panel).toHaveAttribute("aria-labelledby", tab.id);
      expect(panel).toHaveAttribute("tabindex", "0");
    });

    it("ids stay one valid token for values with spaces or percent signs, and the panel is named by its tab", () => {
      render(
        <Tabs defaultValue="my tab">
          <TabList aria-label="Demo">
            <Tab value="my tab">My tab</Tab>
            <Tab value="100%">Percent</Tab>
          </TabList>
          <TabPanel value="my tab">First body</TabPanel>
          <TabPanel value="100%">Second body</TabPanel>
        </Tabs>,
      );
      const panel = screen.getByRole("tabpanel", { name: "My tab" });
      expect(screen.getByRole("tab", { name: "My tab" })).toHaveAttribute("aria-controls", panel.id);
      expect(panel.id).not.toMatch(/[\s%]/);
    });

    it("hides non-selected panels", () => {
      render(<ThreeTabs defaultValue="b" />);
      expect(screen.getByText("Panel A")).not.toBeVisible();
      expect(screen.getByText("Panel B")).toBeVisible();
      expect(screen.getByText("Panel C")).not.toBeVisible();
    });

    it("two instances on one page have no duplicate ids", () => {
      render(
        <>
          <ThreeTabs />
          <ThreeTabs />
        </>,
      );
      const ids = Array.from(document.querySelectorAll("[id]")).map((element) => element.id);
      expect(new Set(ids).size).toBe(ids.length);
      expect(ids.length).toBeGreaterThan(0);
    });
  });

  describe("roving tabindex", () => {
    it("only the selected tab is in the tab order", () => {
      render(<ThreeTabs defaultValue="b" />);
      expect(screen.getByRole("tab", { name: "Alpha" })).toHaveAttribute("tabindex", "-1");
      expect(screen.getByRole("tab", { name: "Beta" })).toHaveAttribute("tabindex", "0");
      expect(screen.getByRole("tab", { name: "Gamma" })).toHaveAttribute("tabindex", "-1");
    });

    it("makes the first enabled tab tabbable when the selected value matches no enabled tab", () => {
      render(<ThreeTabs value="zzz" />);
      expect(screen.getByRole("tab", { name: "Alpha" })).toHaveAttribute("tabindex", "0");
      expect(screen.getByRole("tab", { name: "Beta" })).toHaveAttribute("tabindex", "-1");
    });
  });

  describe("keyboard", () => {
    it("ArrowRight and ArrowLeft move focus and selection, wrapping at the ends", async () => {
      const user = userEvent.setup();
      render(<ThreeTabs defaultValue="a" />);
      screen.getByRole("tab", { name: "Alpha" }).focus();

      await user.keyboard("{ArrowRight}");
      expect(screen.getByRole("tab", { name: "Beta" })).toHaveFocus();
      expect(screen.getByRole("tab", { name: "Beta" })).toHaveAttribute("aria-selected", "true");

      await user.keyboard("{ArrowRight}{ArrowRight}");
      expect(screen.getByRole("tab", { name: "Alpha" })).toHaveFocus();

      await user.keyboard("{ArrowLeft}");
      expect(screen.getByRole("tab", { name: "Gamma" })).toHaveFocus();
      expect(screen.getByRole("tabpanel")).toHaveTextContent("Panel C");
    });

    it("skips disabled tabs, including one at the wrap point", async () => {
      const user = userEvent.setup();
      render(<ThreeTabs defaultValue="b" disabledValue="c" />);
      screen.getByRole("tab", { name: "Beta" }).focus();
      await user.keyboard("{ArrowRight}");
      expect(screen.getByRole("tab", { name: "Alpha" })).toHaveFocus();
      await user.keyboard("{ArrowLeft}");
      expect(screen.getByRole("tab", { name: "Beta" })).toHaveFocus();
    });

    it("Home and End jump to the first and last enabled tabs", async () => {
      const user = userEvent.setup();
      render(<ThreeTabs defaultValue="b" disabledValue="c" />);
      screen.getByRole("tab", { name: "Beta" }).focus();
      await user.keyboard("{End}");
      expect(screen.getByRole("tab", { name: "Beta" })).toHaveFocus();
      await user.keyboard("{Home}");
      expect(screen.getByRole("tab", { name: "Alpha" })).toHaveFocus();
      expect(screen.getByRole("tabpanel")).toHaveTextContent("Panel A");
    });

    it("arrow keys keep focus in place when all but one tab is disabled", async () => {
      const user = userEvent.setup();
      const onValueChange = vi.fn();
      render(
        <Tabs defaultValue="a" onValueChange={onValueChange}>
          <TabList aria-label="Only">
            <Tab value="a">Alpha</Tab>
            <Tab value="b" disabled>Beta</Tab>
            <Tab value="c" disabled>Gamma</Tab>
          </TabList>
          <TabPanel value="a">Panel A</TabPanel>
        </Tabs>,
      );
      screen.getByRole("tab", { name: "Alpha" }).focus();
      await user.keyboard("{ArrowRight}{ArrowLeft}{Home}{End}");
      expect(screen.getByRole("tab", { name: "Alpha" })).toHaveFocus();
      expect(onValueChange).not.toHaveBeenCalled();
    });

    it("follows DOM order when tabs are added and removed", async () => {
      const user = userEvent.setup();
      const tabs = (withBeta: boolean) => (
        <Tabs defaultValue="a">
          <TabList aria-label="Dynamic">
            <Tab value="a">Alpha</Tab>
            {withBeta && <Tab value="b">Beta</Tab>}
            <Tab value="c">Gamma</Tab>
          </TabList>
        </Tabs>
      );
      const { rerender } = render(tabs(false));
      rerender(tabs(true));
      screen.getByRole("tab", { name: "Alpha" }).focus();
      await user.keyboard("{ArrowRight}");
      expect(screen.getByRole("tab", { name: "Beta" })).toHaveFocus();

      rerender(tabs(false));
      screen.getByRole("tab", { name: "Alpha" }).focus();
      await user.keyboard("{ArrowRight}");
      expect(screen.getByRole("tab", { name: "Gamma" })).toHaveFocus();
    });

    it("prevents default on handled keys", () => {
      render(<ThreeTabs defaultValue="a" />);
      const notPrevented = fireEvent.keyDown(screen.getByRole("tab", { name: "Alpha" }), { key: "ArrowRight" });
      expect(notPrevented).toBe(false);
    });

    it("does not select a disabled tab by click", async () => {
      const user = userEvent.setup();
      const onValueChange = vi.fn();
      render(<ThreeTabs defaultValue="a" disabledValue="b" onValueChange={onValueChange} />);
      await user.click(screen.getByRole("tab", { name: "Beta" }));
      expect(onValueChange).not.toHaveBeenCalled();
      expect(screen.getByRole("tab", { name: "Alpha" })).toHaveAttribute("aria-selected", "true");
    });
  });
});

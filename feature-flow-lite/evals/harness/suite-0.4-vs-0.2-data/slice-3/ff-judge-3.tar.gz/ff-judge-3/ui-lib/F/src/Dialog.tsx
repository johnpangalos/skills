import {
  createContext,
  useContext,
  useEffect,
  useId,
  useInsertionEffect,
  useLayoutEffect,
  useRef,
  useState,
  type ComponentPropsWithoutRef,
  type RefObject,
} from "react";
import { createPortal } from "react-dom";

export type DialogProps = Omit<ComponentPropsWithoutRef<"div">, "title"> & {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  title: string;
  description?: string;
};

type OpenDialog = { ref: RefObject<HTMLDivElement | null>; parent: RefObject<HTMLDivElement | null> | null };

// Open dialogs, bottom to top. Only the last entry handles Escape and focus.
const openDialogs: OpenDialog[] = [];

// The ref of the closest enclosing Dialog, null at the top level.
const DialogParentContext = createContext<RefObject<HTMLDivElement | null> | null>(null);

// True when the entry was opened inside the dialog with this ref, directly or through other open dialogs.
function isDescendantOf(entry: OpenDialog, ref: RefObject<HTMLDivElement | null>): boolean {
  let parent = entry.parent;
  while (parent) {
    if (parent === ref) return true;
    const current = parent;
    parent = openDialogs.find((other) => other.ref === current)?.parent ?? null;
  }
  return false;
}

// Puts a new dialog on top, then sinks it below the open dialogs nested in it. Those can already be open in the
// same commit, because children run their insertion effects before their parent does.
function pushDialog(entry: OpenDialog) {
  const lowestDescendant = openDialogs.findIndex((other) => isDescendantOf(other, entry.ref));
  if (lowestDescendant === -1) openDialogs.push(entry);
  else openDialogs.splice(lowestDescendant, 0, entry);
}

function removeDialog(ref: RefObject<HTMLDivElement | null>) {
  const index = openDialogs.findIndex((entry) => entry.ref === ref);
  if (index !== -1) openDialogs.splice(index, 1);
}

function isTopmost(ref: RefObject<HTMLDivElement | null>): boolean {
  return openDialogs[openDialogs.length - 1]?.ref === ref;
}

// True when focus is inside this dialog or inside a dialog stacked above it.
function focusIsAtOrAbove(ref: RefObject<HTMLDivElement | null>): boolean {
  const index = openDialogs.findIndex((entry) => entry.ref === ref);
  if (index === -1) return false;
  return openDialogs.slice(index).some((entry) => entry.ref.current?.contains(document.activeElement));
}

const TABBABLE = 'a[href], button, input:not([type="hidden"]), select, textarea, [tabindex]';

// Excludes disabled elements, tabindex="-1", and anything inside a [hidden] subtree.
function isTabbable(element: HTMLElement): boolean {
  return !element.matches(":disabled") && element.getAttribute("tabindex") !== "-1" && !element.closest("[hidden]");
}

function tabbables(container: HTMLElement): HTMLElement[] {
  return Array.from(container.querySelectorAll<HTMLElement>(TABBABLE)).filter(isTabbable);
}

export function Dialog({ open, onOpenChange, title, description, children, ...rest }: DialogProps) {
  const titleId = useId();
  const descriptionId = useId();
  const dialogRef = useRef<HTMLDivElement>(null);
  const onOpenChangeRef = useRef(onOpenChange);
  const parent = useContext(DialogParentContext);

  // The element focused before opening. It is captured during render because children with autoFocus
  // take focus in the commit that follows, before any effect runs.
  const [wasOpen, setWasOpen] = useState(false);
  const [opener, setOpener] = useState<HTMLElement | null>(null);
  if (open !== wasOpen) {
    setWasOpen(open);
    if (open) setOpener(document.activeElement as HTMLElement | null);
  }

  useLayoutEffect(() => {
    onOpenChangeRef.current = onOpenChange;
  });

  // Join the stack before children's autoFocus runs. React applies autoFocus in the layout phase, after
  // mutation-phase insertion effects, so a nested dialog's autoFocus input is not pulled back by its parent.
  useInsertionEffect(() => {
    if (!open) return;
    pushDialog({ ref: dialogRef, parent });
    return () => removeDialog(dialogRef);
  }, [open, parent]);

  // Focus management: move focus in on open, keep it inside the topmost dialog, restore it on close.
  useEffect(() => {
    const dialog = dialogRef.current;
    if (!open || !dialog) return;
    if (!focusIsAtOrAbove(dialogRef)) (tabbables(dialog)[0] ?? dialog).focus();

    const pullBack = (event: FocusEvent) => {
      if (isTopmost(dialogRef) && !dialog.contains(event.target as Node)) {
        (tabbables(dialog)[0] ?? dialog).focus();
      }
    };

    document.addEventListener("focusin", pullBack);
    return () => {
      document.removeEventListener("focusin", pullBack);
      // Restore only once the dialog has left the DOM. A StrictMode effect re-run leaves it connected.
      if (!dialog.isConnected && opener?.isConnected) opener.focus();
    };
  }, [open, opener]);

  // Keyboard: Escape closes, Tab wraps at both ends of the dialog. Listening on document catches keys
  // pressed while focus is on body too. Only the topmost dialog reacts, so one Escape closes one dialog.
  useEffect(() => {
    if (!open) return;

    function handleKeyDown(event: KeyboardEvent) {
      if (!isTopmost(dialogRef)) return;
      if (event.key === "Escape") {
        onOpenChangeRef.current(false);
        return;
      }
      const dialog = dialogRef.current;
      if (event.key !== "Tab" || !dialog) return;
      const items = tabbables(dialog);
      if (items.length === 0) {
        event.preventDefault();
        dialog.focus();
        return;
      }
      const first = items[0];
      const last = items[items.length - 1];
      const active = document.activeElement;
      if (event.shiftKey && (active === first || active === dialog)) {
        event.preventDefault();
        last.focus();
      } else if (!event.shiftKey && active === last) {
        event.preventDefault();
        first.focus();
      }
    }

    document.addEventListener("keydown", handleKeyDown);
    return () => document.removeEventListener("keydown", handleKeyDown);
  }, [open]);

  if (!open) return null;

  // The backdrop is a sibling of the dialog, so a drag that starts inside the dialog and ends
  // on the backdrop produces a click on their common ancestor and does not reach the backdrop.
  return createPortal(
    <>
      <div data-backdrop="" aria-hidden="true" onClick={() => onOpenChange(false)} />
      <div
        {...rest}
        ref={dialogRef}
        role="dialog"
        aria-modal="true"
        aria-labelledby={titleId}
        aria-describedby={description ? descriptionId : undefined}
        tabIndex={-1}
      >
        <h2 id={titleId}>{title}</h2>
        {description ? <p id={descriptionId}>{description}</p> : null}
        <DialogParentContext.Provider value={dialogRef}>{children}</DialogParentContext.Provider>
      </div>
    </>,
    document.body,
  );
}

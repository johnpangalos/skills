import { render, screen } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { useState } from "react";
import { describe, expect, it, vi } from "vitest";
import { Combobox, type ComboboxOption } from "./Combobox";

const FRUITS: ComboboxOption[] = [
  { value: "apple", label: "Apple" },
  { value: "banana", label: "Banana", disabled: true },
  { value: "cherry", label: "Cherry" },
];

// Holds the value in state, like a real parent that applies onChange.
function Controlled({ options = FRUITS, onChange = vi.fn(), initial = null }: { options?: ComboboxOption[]; onChange?: (value: string | null) => void; initial?: string | null }) {
  const [value, setValue] = useState<string | null>(initial);
  return (
    <Combobox
      label="Fruit"
      placeholder="Search fruit"
      options={options}
      value={value}
      onChange={(next) => {
        onChange(next);
        setValue(next);
      }}
    />
  );
}

const input = () => screen.getByRole("combobox", { name: "Fruit" });

describe("Combobox", () => {
  it("associates the label and exposes combobox state", () => {
    render(<Controlled />);
    expect(input()).toHaveAttribute("aria-autocomplete", "list");
    expect(input()).toHaveAttribute("aria-expanded", "false");
    expect(input()).toHaveAttribute("placeholder", "Search fruit");
    expect(screen.queryByRole("listbox")).not.toBeInTheDocument();
    expect(input()).not.toHaveAttribute("aria-activedescendant");
  });

  it("opens on typing and filters by case-insensitive substring", async () => {
    const user = userEvent.setup();
    render(<Controlled />);
    await user.type(input(), "AN");
    expect(input()).toHaveAttribute("aria-expanded", "true");
    expect(screen.getByRole("listbox", { name: "Fruit" })).toBeInTheDocument();
    expect(screen.getAllByRole("option").map((o) => o.textContent)).toEqual(["Banana"]);
  });

  it("treats regex metacharacters literally", async () => {
    const user = userEvent.setup();
    render(<Controlled />);
    await user.type(input(), "(.*{[}");
    expect(screen.getByText("No results")).toBeInTheDocument();
    expect(screen.queryByRole("option")).not.toBeInTheDocument();
    expect(input()).not.toHaveAttribute("aria-activedescendant");
  });

  it("opens with ArrowDown and activates the first enabled option", async () => {
    const user = userEvent.setup();
    render(<Controlled />);
    await user.click(input());
    await user.keyboard("{ArrowDown}");
    expect(input()).toHaveAttribute("aria-expanded", "true");
    expect(input()).toHaveAttribute("aria-activedescendant", screen.getByRole("option", { name: "Apple" }).id);
    expect(input()).toHaveFocus();
  });

  it("moves the active option with wrapping and skips disabled options", async () => {
    const user = userEvent.setup();
    render(<Controlled />);
    await user.click(input());
    await user.keyboard("{ArrowDown}{ArrowDown}");
    expect(input()).toHaveAttribute("aria-activedescendant", screen.getByRole("option", { name: "Cherry" }).id);
    await user.keyboard("{ArrowDown}");
    expect(input()).toHaveAttribute("aria-activedescendant", screen.getByRole("option", { name: "Apple" }).id);
    await user.keyboard("{ArrowUp}");
    expect(input()).toHaveAttribute("aria-activedescendant", screen.getByRole("option", { name: "Cherry" }).id);
  });

  it("goes to the last enabled option with ArrowUp from no active option", async () => {
    const user = userEvent.setup();
    render(<Controlled />);
    await user.type(input(), "a");
    await user.keyboard("{ArrowUp}");
    expect(input()).toHaveAttribute("aria-activedescendant", screen.getByRole("option", { name: "Apple" }).id);
  });

  it("selects the active option on Enter and shows its label", async () => {
    const user = userEvent.setup();
    const onChange = vi.fn();
    render(<Controlled onChange={onChange} />);
    await user.click(input());
    await user.keyboard("{ArrowDown}{ArrowDown}{Enter}");
    expect(onChange).toHaveBeenCalledWith("cherry");
    expect(input()).toHaveValue("Cherry");
    expect(screen.queryByRole("listbox")).not.toBeInTheDocument();
  });

  it("does nothing on Enter without an active option", async () => {
    const user = userEvent.setup();
    const onChange = vi.fn();
    render(<Controlled onChange={onChange} />);
    await user.type(input(), "ap");
    await user.keyboard("{Enter}");
    expect(onChange).not.toHaveBeenCalled();
    expect(input()).toHaveValue("ap");
  });

  it("selects on click and keeps focus in the input", async () => {
    const user = userEvent.setup();
    const onChange = vi.fn();
    render(<Controlled onChange={onChange} />);
    await user.type(input(), "a");
    await user.click(screen.getByRole("option", { name: "Apple" }));
    expect(onChange).toHaveBeenCalledWith("apple");
    expect(input()).toHaveValue("Apple");
    expect(input()).toHaveFocus();
  });

  it("does nothing when a disabled option is clicked", async () => {
    const user = userEvent.setup();
    const onChange = vi.fn();
    render(<Controlled onChange={onChange} />);
    await user.type(input(), "an");
    await user.click(screen.getByRole("option", { name: "Banana" }));
    expect(onChange).not.toHaveBeenCalled();
    expect(screen.getByRole("option", { name: "Banana" })).toHaveAttribute("aria-disabled", "true");
  });

  it("closes on Escape without changing the value and restores the label", async () => {
    const user = userEvent.setup();
    const onChange = vi.fn();
    render(<Controlled onChange={onChange} initial="cherry" />);
    await user.type(input(), "ap");
    await user.keyboard("{Escape}");
    expect(onChange).not.toHaveBeenCalled();
    expect(input()).toHaveAttribute("aria-expanded", "false");
    expect(input()).toHaveValue("Cherry");
  });

  it("does not handle Escape when closed, so it propagates", async () => {
    const user = userEvent.setup();
    const onParentKeyDown = vi.fn();
    render(<div onKeyDown={onParentKeyDown}><Controlled /></div>);
    await user.click(input());
    await user.keyboard("{Escape}");
    expect(onParentKeyDown).toHaveBeenCalledTimes(1);
  });

  it("stops Escape from propagating while the popup is open", async () => {
    const user = userEvent.setup();
    const onParentKeyDown = vi.fn();
    render(<div onKeyDown={onParentKeyDown}><Controlled /></div>);
    await user.click(input());
    await user.keyboard("{ArrowDown}{Escape}");
    expect(onParentKeyDown).toHaveBeenCalledTimes(1);
  });

  it("calls onChange(null) when the input is cleared", async () => {
    const user = userEvent.setup();
    const onChange = vi.fn();
    render(<Controlled onChange={onChange} initial="apple" />);
    await user.clear(input());
    expect(onChange).toHaveBeenCalledWith(null);
  });

  it("closes on blur and restores the selected label", async () => {
    const user = userEvent.setup();
    render(<><Controlled initial="apple" /><button>Elsewhere</button></>);
    await user.type(input(), "ch");
    await user.click(screen.getByRole("button", { name: "Elsewhere" }));
    expect(screen.queryByRole("listbox")).not.toBeInTheDocument();
    expect(input()).toHaveValue("Apple");
  });

  it("updates the text when value changes from outside", () => {
    const { rerender } = render(<Combobox label="Fruit" options={FRUITS} value="apple" onChange={vi.fn()} />);
    expect(input()).toHaveValue("Apple");
    rerender(<Combobox label="Fruit" options={FRUITS} value="cherry" onChange={vi.fn()} />);
    expect(input()).toHaveValue("Cherry");
    rerender(<Combobox label="Fruit" options={FRUITS} value={null} onChange={vi.fn()} />);
    expect(input()).toHaveValue("");
  });

  it("shows an empty input when value is not in options", () => {
    render(<Combobox label="Fruit" options={FRUITS} value="kiwi" onChange={vi.fn()} />);
    expect(input()).toHaveValue("");
  });

  it("keeps the shown selection when the parent ignores onChange", async () => {
    const user = userEvent.setup();
    const onChange = vi.fn();
    render(<Combobox label="Fruit" options={FRUITS} value="apple" onChange={onChange} />);
    await user.clear(input());
    await user.type(input(), "ch");
    await user.keyboard("{ArrowDown}{Enter}");
    expect(onChange).toHaveBeenCalledWith("cherry");
    expect(input()).toHaveValue("Apple");
  });

  it("selects by value when labels are duplicated", async () => {
    const user = userEvent.setup();
    const onChange = vi.fn();
    const options = [
      { value: "a1", label: "Same" },
      { value: "a2", label: "Same" },
    ];
    render(<Controlled options={options} onChange={onChange} initial="a1" />);
    await user.click(input());
    await user.keyboard("{ArrowDown}{ArrowDown}{Enter}");
    expect(onChange).toHaveBeenCalledWith("a2");
  });

  it("does nothing with arrows when all options are disabled", async () => {
    const user = userEvent.setup();
    render(<Controlled options={[{ value: "x", label: "X", disabled: true }]} />);
    await user.click(input());
    await user.keyboard("{ArrowDown}{ArrowUp}");
    expect(input()).not.toHaveAttribute("aria-activedescendant");
    expect(screen.getByRole("option", { name: "X" })).toHaveAttribute("aria-disabled", "true");
  });

  it("shows options that match only disabled entries but does not select them", async () => {
    const user = userEvent.setup();
    const onChange = vi.fn();
    render(<Controlled onChange={onChange} />);
    await user.type(input(), "ban");
    expect(screen.getByRole("option", { name: "Banana" })).toBeInTheDocument();
    await user.keyboard("{ArrowDown}{Enter}");
    expect(onChange).not.toHaveBeenCalled();
  });

  it("does not point the active option past the end when options shrink", async () => {
    const user = userEvent.setup();
    const { rerender } = render(<Controlled />);
    await user.click(input());
    await user.keyboard("{ArrowDown}{ArrowDown}");
    rerender(<Controlled options={[FRUITS[0]]} />);
    expect(input()).not.toHaveAttribute("aria-activedescendant");
    await user.keyboard("{ArrowDown}");
    expect(input()).toHaveAttribute("aria-activedescendant", screen.getByRole("option", { name: "Apple" }).id);
  });

  it("creates valid unique option ids for values with special characters", async () => {
    const user = userEvent.setup();
    render(
      <Controlled
        options={[
          { value: "a b", label: "One" },
          { value: "x/y", label: "Two" },
        ]}
      />,
    );
    await user.click(input());
    await user.keyboard("{ArrowDown}");
    const ids = screen.getAllByRole("option").map((option) => option.id);
    expect(new Set(ids).size).toBe(2);
    expect(input()).toHaveAttribute("aria-controls", screen.getByRole("listbox").id);
  });

  it("keeps ids separate between two instances", () => {
    render(<><Controlled /><Controlled /></>);
    const [first, second] = screen.getAllByRole("combobox");
    expect(first.id).not.toBe(second.id);
    expect(first.getAttribute("aria-controls")).not.toBe(second.getAttribute("aria-controls"));
  });

  it("does not select an active option that became disabled after a rerender", async () => {
    const user = userEvent.setup();
    const onChange = vi.fn();
    const { rerender } = render(<Controlled onChange={onChange} />);
    await user.click(input());
    await user.keyboard("{ArrowDown}");
    expect(input()).toHaveAttribute("aria-activedescendant", screen.getByRole("option", { name: "Apple" }).id);
    rerender(<Controlled onChange={onChange} options={[{ ...FRUITS[0], disabled: true }, FRUITS[1], FRUITS[2]]} />);
    expect(input()).not.toHaveAttribute("aria-activedescendant");
    await user.keyboard("{Enter}");
    expect(onChange).not.toHaveBeenCalled();
  });

  it("keeps aria-controls pointing at a listbox in the DOM when closed or empty", async () => {
    const user = userEvent.setup();
    render(<Controlled />);
    const listbox = () => document.getElementById(input().getAttribute("aria-controls") as string);
    expect(listbox()).toHaveAttribute("hidden");
    await user.type(input(), "zzz");
    expect(screen.getByText("No results")).toBeInTheDocument();
    expect(listbox()).toHaveAttribute("hidden");
    expect(listbox()?.contains(screen.getByText("No results"))).toBe(false);
  });

  it("opens and activates the last enabled option with ArrowUp when closed", async () => {
    const user = userEvent.setup();
    render(<Controlled />);
    await user.click(input());
    await user.keyboard("{ArrowUp}");
    expect(input()).toHaveAttribute("aria-expanded", "true");
    expect(input()).toHaveAttribute("aria-activedescendant", screen.getByRole("option", { name: "Cherry" }).id);
  });
});

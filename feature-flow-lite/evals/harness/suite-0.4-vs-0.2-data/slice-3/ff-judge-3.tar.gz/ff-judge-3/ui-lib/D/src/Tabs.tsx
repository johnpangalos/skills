import {
  createContext,
  useContext,
  useCallback,
  useId,
  useLayoutEffect,
  useRef,
  useState,
  type ComponentPropsWithoutRef,
  type KeyboardEvent,
  type RefObject,
} from "react";

type TabsContextValue = {
  baseId: string;
  selected: string | null;
  tabbable: string | null;
  listRef: RefObject<HTMLDivElement | null>;
  select: (value: string) => void;
  moveFocus: (from: HTMLElement, key: string) => void;
  refresh: () => void;
};

const TabsContext = createContext<TabsContextValue | null>(null);

function useTabsContext(): TabsContextValue {
  const context = useContext(TabsContext);
  if (!context) {
    throw new Error("Tab, TabList and TabPanel must be rendered inside Tabs");
  }
  return context;
}

const ENABLED_TABS = '[role="tab"]:not([disabled])';
const NAVIGATION_KEYS = ["ArrowRight", "ArrowLeft", "Home", "End"];

export type TabsProps = Omit<ComponentPropsWithoutRef<"div">, "defaultValue"> & {
  value?: string;
  defaultValue?: string;
  onValueChange?: (value: string) => void;
};

export function Tabs({ value, defaultValue, onValueChange, ...rest }: TabsProps) {
  const baseId = useId();
  const listRef = useRef<HTMLDivElement>(null);
  const [internal, setInternal] = useState(defaultValue);
  const [enabled, setEnabled] = useState<string[]>([]);
  // Tabs mounting, unmounting, or changing disabled/value bump this so the layout effect below re-reads the DOM.
  const [, setVersion] = useState(0);
  const refresh = useCallback(() => setVersion((version) => version + 1), []);

  // Tab order is read from the DOM (not registration order), so tabs added or removed after mount stay in visual order.
  useLayoutEffect(() => {
    const list = listRef.current;
    if (!list) return;
    const next = Array.from(list.querySelectorAll<HTMLElement>(ENABLED_TABS), (tab) => tab.dataset.value ?? "");
    // Without a value or defaultValue, the first enabled tab is adopted once, so later inserted tabs cannot move the selection.
    if (value === undefined && internal === undefined && next.length) setInternal(next[0]);
    setEnabled((prev) => (JSON.stringify(prev) === JSON.stringify(next) ? prev : next));
  });

  const selected = value ?? internal ?? enabled[0] ?? null;
  // The selected tab is the single tab-stop; if it matches no enabled tab, the first enabled tab is.
  const tabbable = selected !== null && enabled.includes(selected) ? selected : (enabled[0] ?? null);

  const select = (next: string) => {
    if (value === undefined) setInternal(next);
    onValueChange?.(next);
  };

  const moveFocus = (from: HTMLElement, key: string) => {
    const list = listRef.current;
    if (!list) return;
    const tabs = Array.from(list.querySelectorAll<HTMLElement>(ENABLED_TABS));
    const index = tabs.indexOf(from);
    if (index < 0) return;
    const count = tabs.length;
    const target =
      key === "Home" ? 0 : key === "End" ? count - 1 : key === "ArrowRight" ? (index + 1) % count : (index - 1 + count) % count;
    tabs[target].focus();
    select(tabs[target].dataset.value ?? "");
  };

  return (
    <TabsContext.Provider value={{ baseId, selected, tabbable, listRef, select, moveFocus, refresh }}>
      <div {...rest} />
    </TabsContext.Provider>
  );
}

export type TabListProps = ComponentPropsWithoutRef<"div"> & {
  "aria-label": string;
};

export function TabList(props: TabListProps) {
  const ctx = useTabsContext();
  return <div {...props} ref={ctx.listRef} role="tablist" aria-orientation="horizontal" />;
}

export type TabProps = Omit<ComponentPropsWithoutRef<"button">, "value"> & {
  value: string;
};

export function Tab({ value, disabled, onClick, onKeyDown, ...rest }: TabProps) {
  const ctx = useTabsContext();
  const { refresh } = ctx;
  const key = encodeURIComponent(value);

  // Tabs re-reads the DOM when this tab mounts, unmounts, or changes disabled or value.
  useLayoutEffect(() => {
    refresh();
    return () => refresh();
  }, [refresh, value, disabled]);

  return (
    <button
      {...rest}
      type="button"
      role="tab"
      disabled={disabled}
      id={`${ctx.baseId}-tab-${key}`}
      data-value={value}
      aria-selected={ctx.selected === value}
      aria-controls={`${ctx.baseId}-panel-${key}`}
      tabIndex={ctx.tabbable === value ? 0 : -1}
      onClick={(event) => {
        onClick?.(event);
        ctx.select(value);
      }}
      onKeyDown={(event: KeyboardEvent<HTMLButtonElement>) => {
        onKeyDown?.(event);
        if (!NAVIGATION_KEYS.includes(event.key)) return;
        event.preventDefault();
        ctx.moveFocus(event.currentTarget, event.key);
      }}
    />
  );
}

export type TabPanelProps = ComponentPropsWithoutRef<"div"> & {
  value: string;
};

export function TabPanel({ value, ...rest }: TabPanelProps) {
  const ctx = useTabsContext();
  const key = encodeURIComponent(value);
  return (
    <div
      {...rest}
      role="tabpanel"
      id={`${ctx.baseId}-panel-${key}`}
      aria-labelledby={`${ctx.baseId}-tab-${key}`}
      tabIndex={0}
      hidden={ctx.selected !== value}
    />
  );
}

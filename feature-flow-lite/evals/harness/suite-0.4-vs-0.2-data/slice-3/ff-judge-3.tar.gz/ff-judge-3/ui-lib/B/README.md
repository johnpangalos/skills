# @acme/ui

Accessible React components. Style-agnostic: no CSS is shipped, and every component accepts `className` and passes other HTML props through.

## Run

```sh
pnpm install
pnpm test        # Vitest + Testing Library
pnpm typecheck   # tsc --noEmit
```

## Tabs

```tsx
import { Tabs, TabList, Tab, TabPanel } from "@acme/ui";

<Tabs defaultValue="profile">
  <TabList aria-label="Settings">
    <Tab value="profile">Profile</Tab>
    <Tab value="billing" disabled>Billing</Tab>
    <Tab value="team">Team</Tab>
  </TabList>
  <TabPanel value="profile">Profile form</TabPanel>
  <TabPanel value="team">Team list</TabPanel>
</Tabs>;
```

### Tabs props

| Prop            | Type                         | Default                      | Notes                                          |
| --------------- | ---------------------------- | ---------------------------- | ---------------------------------------------- |
| `defaultValue`  | `string`                     | first enabled tab            | Initial selection (uncontrolled).              |
| `value`         | `string`                     | —                            | Makes the component controlled when given.     |
| `onValueChange` | `(value: string) => void`    | —                            | Fires when the user selects a different tab.   |
| `className`     | `string`                     | —                            | Plus any other `div` props.                    |

### TabList props

| Prop              | Type     | Notes                                                   |
| ----------------- | -------- | ------------------------------------------------------- |
| `aria-label`      | `string` | Required unless `aria-labelledby` is given.             |
| `aria-labelledby` | `string` | Alternative to `aria-label`.                            |

### Tab props

| Prop       | Type      | Default | Notes                                          |
| ---------- | --------- | ------- | ---------------------------------------------- |
| `value`    | `string`  | —       | Identifies the tab and its panel.              |
| `disabled` | `boolean` | `false` | Skipped by click, arrow, Home and End keys.    |

### TabPanel props

| Prop    | Type     | Notes                                        |
| ------- | -------- | -------------------------------------------- |
| `value` | `string` | Matches the `Tab` with the same value.       |

### Tabs keyboard

| Key                 | Action                                                        |
| ------------------- | ------------------------------------------------------------- |
| Tab                 | Moves focus into the selected tab, then into the panel.       |
| ArrowRight          | Focus and select the next enabled tab (wraps at the end).     |
| ArrowLeft           | Focus and select the previous enabled tab (wraps at the start). |
| Home                | Focus and select the first enabled tab.                       |
| End                 | Focus and select the last enabled tab.                        |

Selection follows focus. Roving tabindex: only the selected tab is in the tab order.

## Dialog

```tsx
import { Dialog } from "@acme/ui";

const [open, setOpen] = useState(false);

<button onClick={() => setOpen(true)}>Delete</button>
<Dialog open={open} onOpenChange={setOpen} title="Delete project" description="This cannot be undone.">
  <button onClick={() => setOpen(false)}>Cancel</button>
</Dialog>;
```

### Dialog props

| Prop            | Type                          | Default | Notes                                                    |
| --------------- | ----------------------------- | ------- | -------------------------------------------------------- |
| `open`          | `boolean`                     | —       | Required. The dialog is fully controlled by this prop.   |
| `onOpenChange`  | `(open: boolean) => void`     | —       | Called with `false` on Escape or backdrop click.         |
| `title`         | `ReactNode`                   | —       | Rendered in an `<h2>` and used as the accessible name.   |
| `description`   | `ReactNode`                   | —       | Optional. Linked with `aria-describedby` when given.     |
| `backdropClassName` | `string`                  | —       | Applied to the backdrop. The consumer styles it, e.g. `position: fixed; inset: 0`. |
| `className`     | `string`                      | —       | Applied to the dialog element. Plus any other `div` props. |

Renders into `document.body` through a portal, with a backdrop element (`data-backdrop`) and a `role="dialog"` element with `aria-modal="true"`.

### Dialog keyboard and focus

| Key / action        | Behavior                                                                   |
| ------------------- | -------------------------------------------------------------------------- |
| Open                | Focus moves to the first tabbable element, or to the dialog if none.       |
| Tab                 | Moves forward; wraps from the last tabbable to the first.                  |
| Shift+Tab           | Moves backward; wraps from the first tabbable to the last.                 |
| Escape              | Calls `onOpenChange(false)`.                                               |
| Backdrop click      | Calls `onOpenChange(false)`. A press that starts inside the dialog does not. Focus stays in the dialog either way. |

On close, focus returns to the element focused before the dialog opened, if it is still in the document.

## Combobox

```tsx
import { Combobox } from "@acme/ui";

const [fruit, setFruit] = useState<string | null>(null);

<Combobox
  label="Fruit"
  placeholder="Search fruit"
  options={[
    { value: "apple", label: "Apple" },
    { value: "pear", label: "Pear", disabled: true },
  ]}
  value={fruit}
  onChange={setFruit}
/>;
```

### Combobox props

| Prop          | Type                                    | Default | Notes                                                            |
| ------------- | --------------------------------------- | ------- | ---------------------------------------------------------------- |
| `label`       | `string`                                | —       | Visible label, associated with the input.                        |
| `options`     | `ComboboxOption[]`                      | —       | `ComboboxOption` is `{ value: string; label: string; disabled?: boolean }`. |
| `value`       | `string \| null`                        | —       | Selected option value. Always controlled.                        |
| `onChange`    | `(value: string \| null) => void`       | —       | Called on selection, or with `null` when the input is cleared.   |
| `placeholder` | `string`                                | —       | Placeholder for the input.                                       |
| `className`   | `string`                                | —       | Applied to the wrapper. Plus any other `div` props.              |

### Combobox keyboard

| Key        | Behavior                                                                                 |
| ---------- | ---------------------------------------------------------------------------------------- |
| Typing     | Opens the popup and filters options by case-insensitive substring. Clears the active option. |
| ArrowDown  | Opens the popup if closed. Moves the active option to the next enabled option (wraps).  |
| ArrowUp    | Opens the popup if closed and activates the last enabled option. Otherwise moves the active option to the previous enabled option (wraps). |
| Enter      | Selects the active option and closes the popup. Does nothing without an active, enabled option. |
| Escape     | Closes the popup and restores the selected label. Not handled when already closed, so it propagates. |
| Blur       | Closes the popup and restores the selected label.                                         |

Clicking an enabled option selects it. Disabled options cannot be selected.

## Controlled and uncontrolled

- **Tabs** is uncontrolled unless `value` is passed. In controlled mode, the selection changes only when the parent updates `value`; `onValueChange` still fires on user selection.
- **Dialog** is always controlled by `open`. It never closes on its own, so the parent must handle `onOpenChange`.
- **Combobox** is always controlled by `value`. The shown selection always reflects `value`, even if the parent ignores `onChange`.

import { render, screen, fireEvent } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { useState } from "react";
import { Tabs, TabList, Tab, TabPanel } from "./Tabs";

function renderTabs(
  props: { value?: string; defaultValue?: string; onValueChange?: (value: string) => void; disabled?: string[] } = {},
) {
  const disabled = props.disabled ?? [];
  return render(
    <Tabs value={props.value} defaultValue={props.defaultValue} onValueChange={props.onValueChange}>
      <TabList aria-label="Settings">
        <Tab value="one" disabled={disabled.includes("one")}>One</Tab>
        <Tab value="two" disabled={disabled.includes("two")}>Two</Tab>
        <Tab value="three" disabled={disabled.includes("three")}>Three</Tab>
      </TabList>
      <TabPanel value="one">Panel one</TabPanel>
      <TabPanel value="two">Panel two</TabPanel>
      <TabPanel value="three">Panel three</TabPanel>
    </Tabs>,
  );
}

describe("Tabs", () => {
  it("renders a tablist with the given label and horizontal orientation", () => {
    renderTabs();
    const list = screen.getByRole("tablist", { name: "Settings" });
    expect(list).toHaveAttribute("aria-orientation", "horizontal");
  });

  it("selects the defaultValue tab uncontrolled and shows only its panel", () => {
    renderTabs({ defaultValue: "two" });
    expect(screen.getByRole("tab", { name: "Two" })).toHaveAttribute("aria-selected", "true");
    expect(screen.getByRole("tab", { name: "One" })).toHaveAttribute("aria-selected", "false");
    expect(screen.getByRole("tabpanel")).toHaveTextContent("Panel two");
  });

  it("selects the first enabled tab when neither value nor defaultValue is given", () => {
    renderTabs({ disabled: ["one"] });
    expect(screen.getByRole("tab", { name: "Two" })).toHaveAttribute("aria-selected", "true");
  });

  it("wires ids: tab aria-controls its panel and panel aria-labelledby its tab", () => {
    renderTabs({ defaultValue: "one" });
    const tab = screen.getByRole("tab", { name: "One" });
    const panel = screen.getByRole("tabpanel", { name: "One" });
    expect(tab).toHaveAttribute("type", "button");
    expect(tab).toHaveAttribute("aria-controls", panel.id);
    expect(panel).toHaveAttribute("aria-labelledby", tab.id);
    expect(panel).toHaveAttribute("tabindex", "0");
  });

  it("gives tabIndex 0 only to the selected tab", () => {
    renderTabs({ defaultValue: "two" });
    expect(screen.getByRole("tab", { name: "Two" })).toHaveAttribute("tabindex", "0");
    expect(screen.getByRole("tab", { name: "One" })).toHaveAttribute("tabindex", "-1");
    expect(screen.getByRole("tab", { name: "Three" })).toHaveAttribute("tabindex", "-1");
  });

  it("selects an enabled tab on click and ignores a disabled tab", async () => {
    const user = userEvent.setup();
    const onValueChange = vi.fn();
    renderTabs({ defaultValue: "one", disabled: ["three"], onValueChange });
    await user.click(screen.getByRole("tab", { name: "Two" }));
    expect(onValueChange).toHaveBeenCalledWith("two");
    expect(screen.getByRole("tab", { name: "Two" })).toHaveAttribute("aria-selected", "true");
    onValueChange.mockClear();
    await user.click(screen.getByRole("tab", { name: "Three" }));
    expect(onValueChange).not.toHaveBeenCalled();
    expect(screen.getByRole("tab", { name: "Three" })).toBeDisabled();
  });

  it("moves focus with ArrowRight and ArrowLeft, wrapping at the ends and selecting", async () => {
    const user = userEvent.setup();
    const onValueChange = vi.fn();
    renderTabs({ defaultValue: "one", onValueChange });
    screen.getByRole("tab", { name: "One" }).focus();
    await user.keyboard("{ArrowRight}");
    expect(screen.getByRole("tab", { name: "Two" })).toHaveFocus();
    expect(onValueChange).toHaveBeenLastCalledWith("two");
    await user.keyboard("{ArrowRight}{ArrowRight}");
    expect(screen.getByRole("tab", { name: "One" })).toHaveFocus();
    await user.keyboard("{ArrowLeft}");
    expect(screen.getByRole("tab", { name: "Three" })).toHaveFocus();
    expect(onValueChange).toHaveBeenLastCalledWith("three");
  });

  it("moves to first and last enabled tabs with Home and End", async () => {
    const user = userEvent.setup();
    renderTabs({ defaultValue: "two" });
    screen.getByRole("tab", { name: "Two" }).focus();
    await user.keyboard("{End}");
    expect(screen.getByRole("tab", { name: "Three" })).toHaveFocus();
    await user.keyboard("{Home}");
    expect(screen.getByRole("tab", { name: "One" })).toHaveFocus();
  });

  it("calls preventDefault on handled navigation keys only", () => {
    renderTabs({ defaultValue: "one" });
    const tab = screen.getByRole("tab", { name: "One" });
    expect(fireEvent.keyDown(tab, { key: "ArrowRight" })).toBe(false);
    expect(fireEvent.keyDown(tab, { key: "a" })).toBe(true);
  });

  it("keeps the selected value unchanged when a controlled parent ignores onValueChange", async () => {
    const user = userEvent.setup();
    const onValueChange = vi.fn();
    renderTabs({ value: "one", onValueChange });
    await user.click(screen.getByRole("tab", { name: "Two" }));
    expect(onValueChange).toHaveBeenCalledWith("two");
    expect(screen.getByRole("tab", { name: "One" })).toHaveAttribute("aria-selected", "true");
    expect(screen.getByRole("tab", { name: "Two" })).toHaveAttribute("aria-selected", "false");
  });

  it("follows a controlled value when the parent updates it", async () => {
    const user = userEvent.setup();
    function Controlled() {
      const [value, setValue] = useState("one");
      return (
        <Tabs value={value} onValueChange={setValue}>
          <TabList aria-label="Controlled">
            <Tab value="one">One</Tab>
            <Tab value="two">Two</Tab>
          </TabList>
          <TabPanel value="one">Panel one</TabPanel>
          <TabPanel value="two">Panel two</TabPanel>
        </Tabs>
      );
    }
    render(<Controlled />);
    await user.click(screen.getByRole("tab", { name: "Two" }));
    expect(screen.getByRole("tabpanel")).toHaveTextContent("Panel two");
  });

  it("wraps past a disabled first tab and lands Home/End on enabled tabs when the ends are disabled", async () => {
    const user = userEvent.setup();
    renderTabs({ defaultValue: "three", disabled: ["one"] });
    screen.getByRole("tab", { name: "Three" }).focus();
    await user.keyboard("{ArrowRight}");
    expect(screen.getByRole("tab", { name: "Two" })).toHaveFocus();
    await user.keyboard("{Home}");
    expect(screen.getByRole("tab", { name: "Two" })).toHaveFocus();
    await user.keyboard("{End}");
    expect(screen.getByRole("tab", { name: "Three" })).toHaveFocus();
  });

  it("stays put with only one enabled tab and does not throw", async () => {
    const user = userEvent.setup();
    const onValueChange = vi.fn();
    renderTabs({ defaultValue: "two", disabled: ["one", "three"], onValueChange });
    screen.getByRole("tab", { name: "Two" }).focus();
    await user.keyboard("{ArrowLeft}{ArrowRight}{End}{Home}");
    expect(screen.getByRole("tab", { name: "Two" })).toHaveFocus();
    expect(screen.getByRole("tab", { name: "Two" })).toHaveAttribute("aria-selected", "true");
  });

  it("makes the first enabled tab the single tab stop when the selected value matches no tab", () => {
    renderTabs({ value: "missing" });
    expect(screen.getByRole("tab", { name: "One" })).toHaveAttribute("tabindex", "0");
    expect(screen.getByRole("tab", { name: "Two" })).toHaveAttribute("tabindex", "-1");
    expect(screen.getByRole("tab", { name: "Three" })).toHaveAttribute("tabindex", "-1");
    expect(screen.getAllByRole("tab").filter((tab) => tab.tabIndex === 0)).toHaveLength(1);
  });

  it("orders keyboard navigation by DOM order when tabs are added or removed after mount", async () => {
    const user = userEvent.setup();
    function Dynamic({ tabs }: { tabs: string[] }) {
      return (
        <Tabs defaultValue="a">
          <TabList aria-label="Dynamic">
            {tabs.map((name) => (
              <Tab key={name} value={name}>{name}</Tab>
            ))}
          </TabList>
        </Tabs>
      );
    }
    const { rerender } = render(<Dynamic tabs={["a", "c"]} />);
    rerender(<Dynamic tabs={["a", "b", "c"]} />);
    screen.getByRole("tab", { name: "a" }).focus();
    await user.keyboard("{ArrowRight}");
    expect(screen.getByRole("tab", { name: "b" })).toHaveFocus();
    rerender(<Dynamic tabs={["a", "c"]} />);
    screen.getByRole("tab", { name: "a" }).focus();
    await user.keyboard("{ArrowRight}");
    expect(screen.getByRole("tab", { name: "c" })).toHaveFocus();
  });

  it("gives two instances unique ids and wires each tab to its own panel", () => {
    renderTabs({ defaultValue: "one" });
    renderTabs({ defaultValue: "one" });
    const ids = Array.from(document.querySelectorAll("[id]"), (el) => el.id);
    expect(new Set(ids).size).toBe(ids.length);
    const tabs = screen.getAllByRole("tab", { name: "One" });
    expect(tabs).toHaveLength(2);
    for (const tab of tabs) {
      const panel = document.getElementById(tab.getAttribute("aria-controls") ?? "");
      expect(panel).toHaveAttribute("aria-labelledby", tab.id);
    }
  });

  it("makes a tab tabbable when a child adds tabs without Tabs re-rendering", async () => {
    const user = userEvent.setup();
    function Child() {
      const [ready, setReady] = useState(false);
      return (
        <>
          <button onClick={() => setReady(true)}>Ready</button>
          <TabList aria-label="Settings">
            {ready && (
              <>
                <Tab value="x">X</Tab>
                <Tab value="y">Y</Tab>
              </>
            )}
          </TabList>
        </>
      );
    }
    render(
      <Tabs defaultValue="x">
        <Child />
      </Tabs>,
    );
    await user.click(screen.getByRole("button", { name: "Ready" }));
    expect(screen.getByRole("tab", { name: "X" })).toHaveAttribute("tabindex", "0");
    expect(screen.getByRole("tab", { name: "Y" })).toHaveAttribute("tabindex", "-1");
  });

  it("moves the single tab stop to the next enabled tab when a child removes the selected tab", async () => {
    const user = userEvent.setup();
    function Child() {
      const [showA, setShowA] = useState(true);
      return (
        <>
          <button onClick={() => setShowA(false)}>Remove A</button>
          <TabList aria-label="Settings">
            {showA && <Tab value="a">A</Tab>}
            <Tab value="b">B</Tab>
          </TabList>
        </>
      );
    }
    render(
      <Tabs defaultValue="a">
        <Child />
      </Tabs>,
    );
    await user.click(screen.getByRole("button", { name: "Remove A" }));
    expect(screen.queryByRole("tab", { name: "A" })).toBeNull();
    expect(screen.getByRole("tab", { name: "B" })).toHaveAttribute("tabindex", "0");
  });

  it("keeps the implicit first tab selected when a tab is inserted before it, without calling onValueChange", async () => {
    const user = userEvent.setup();
    const onValueChange = vi.fn();
    function Child() {
      const [showZ, setShowZ] = useState(false);
      return (
        <>
          <button onClick={() => setShowZ(true)}>Add Z</button>
          <TabList aria-label="Implicit">
            {showZ && <Tab value="z">Z</Tab>}
            <Tab value="a">A</Tab>
            <Tab value="b">B</Tab>
          </TabList>
        </>
      );
    }
    render(
      <Tabs onValueChange={onValueChange}>
        <Child />
      </Tabs>,
    );
    expect(screen.getByRole("tab", { name: "A" })).toHaveAttribute("aria-selected", "true");
    await user.click(screen.getByRole("button", { name: "Add Z" }));
    expect(screen.getByRole("tab", { name: "Z" })).toHaveAttribute("aria-selected", "false");
    expect(screen.getByRole("tab", { name: "A" })).toHaveAttribute("aria-selected", "true");
    expect(onValueChange).not.toHaveBeenCalled();
  });
});

import {
  useEffect,
  useId,
  useState,
  type ChangeEvent,
  type ComponentPropsWithoutRef,
  type FocusEvent,
  type KeyboardEvent,
} from "react";

export type ComboboxOption = {
  value: string;
  label: string;
  disabled?: boolean;
};

export type ComboboxProps = Omit<ComponentPropsWithoutRef<"input">, "value" | "defaultValue" | "onChange" | "role"> & {
  label: string;
  options: ComboboxOption[];
  value: string | null;
  onChange: (value: string | null) => void;
  placeholder?: string;
};

export function Combobox({ label, options, value, onChange, onKeyDown, onBlur, ...rest }: ComboboxProps) {
  const baseId = useId();
  const inputId = `${baseId}-input`;
  const labelId = `${baseId}-label`;
  const listboxId = `${baseId}-listbox`;

  // query is null while the user is not editing; the input then shows the selected option's label.
  const [query, setQuery] = useState<string | null>(null);
  const [open, setOpen] = useState(false);
  const [activeValue, setActiveValue] = useState<string | null>(null);

  // When the parent changes value, drop any typed text so the input shows the new label.
  useEffect(() => {
    setQuery(null);
  }, [value]);

  const selectedLabel = options.find((option) => option.value === value)?.label ?? "";
  const search = (query ?? "").toLowerCase();
  // Ids come from the option's index in `options`, so they stay stable while the filter changes.
  const visible = options
    .map((option, index) => ({ option, id: `${baseId}-option-${index}` }))
    .filter(({ option }) => option.label.toLowerCase().includes(search));
  const enabled = visible.filter(({ option }) => !option.disabled);
  const active = open ? enabled.find(({ option }) => option.value === activeValue) : undefined;

  // Both wrap at the ends. With no active option, ArrowDown starts at the first and ArrowUp at the last.
  const moveDown = () => {
    if (enabled.length === 0) {
      setActiveValue(null);
      return;
    }
    const current = enabled.findIndex(({ option }) => option.value === activeValue);
    const index = current < 0 ? 0 : (current + 1) % enabled.length;
    setActiveValue(enabled[index].option.value);
  };

  const moveUp = () => {
    if (enabled.length === 0) {
      setActiveValue(null);
      return;
    }
    const count = enabled.length;
    const current = enabled.findIndex(({ option }) => option.value === activeValue);
    const index = current < 0 ? count - 1 : (current - 1 + count) % count;
    setActiveValue(enabled[index].option.value);
  };

  const close = () => {
    setOpen(false);
    setQuery(null);
    setActiveValue(null);
  };

  const select = (option: ComboboxOption) => {
    onChange(option.value);
    close();
  };

  const handleChange = (event: ChangeEvent<HTMLInputElement>) => {
    const next = event.target.value;
    setQuery(next);
    setOpen(true);
    setActiveValue(null);
    // Clearing the text clears the value, once, only if there was a value.
    if (next === "" && value !== null) onChange(null);
  };

  const handleKeyDown = (event: KeyboardEvent<HTMLInputElement>) => {
    onKeyDown?.(event);
    if (event.key === "ArrowDown") {
      event.preventDefault();
      setOpen(true);
      moveDown();
    } else if (event.key === "ArrowUp") {
      event.preventDefault();
      setOpen(true);
      moveUp();
    } else if (event.key === "Enter" && active) {
      event.preventDefault();
      select(active.option);
    } else if (event.key === "Escape" && (open || query !== null)) {
      // Handled here, so an enclosing dialog does not also close. With nothing open or typed, Escape propagates.
      event.preventDefault();
      event.stopPropagation();
      close();
    }
  };

  const handleBlur = (event: FocusEvent<HTMLInputElement>) => {
    onBlur?.(event);
    close();
  };

  return (
    <>
      <label id={labelId} htmlFor={inputId}>
        {label}
      </label>
      <input
        {...rest}
        id={inputId}
        type="text"
        role="combobox"
        autoComplete="off"
        value={query ?? selectedLabel}
        aria-expanded={open}
        aria-controls={listboxId}
        aria-autocomplete="list"
        aria-activedescendant={active?.id}
        onChange={handleChange}
        onKeyDown={handleKeyDown}
        onBlur={handleBlur}
      />
      <ul id={listboxId} role="listbox" aria-labelledby={labelId} hidden={!open}>
        {open &&
          visible.map(({ option, id }) => (
            <li
              key={id}
              id={id}
              role="option"
              aria-selected={option.value === value}
              aria-disabled={option.disabled ? true : undefined}
              data-active={active?.id === id ? "" : undefined}
              // Keeps focus in the input when an option is clicked.
              onMouseDown={(event) => event.preventDefault()}
              onClick={() => {
                if (!option.disabled) select(option);
              }}
            >
              {option.label}
            </li>
          ))}
      </ul>
      {open && visible.length === 0 && <div>No results</div>}
    </>
  );
}

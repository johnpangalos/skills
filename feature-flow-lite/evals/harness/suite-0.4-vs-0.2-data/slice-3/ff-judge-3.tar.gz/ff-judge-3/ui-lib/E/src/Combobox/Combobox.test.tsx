import { render, screen } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { useState } from "react";
import { Combobox, type ComboboxOption } from "./Combobox";
import { Dialog } from "../Dialog/Dialog";

const options: ComboboxOption[] = [
  { value: "apple", label: "Apple" },
  { value: "banana", label: "Banana", disabled: true },
  { value: "cherry", label: "Cherry" },
  { value: "apricot", label: "Apricot" },
];

function Controlled({ initial = null, onChange, items = options }: { initial?: string | null; onChange: (value: string | null) => void; items?: ComboboxOption[] }) {
  const [value, setValue] = useState<string | null>(initial);
  return (
    <Combobox
      label="Fruit"
      options={items}
      value={value}
      onChange={(next) => {
        onChange(next);
        setValue(next);
      }}
      placeholder="Pick a fruit"
    />
  );
}

const input = () => screen.getByRole("combobox", { name: "Fruit" });

describe("Combobox", () => {
  describe("rendering and aria", () => {
    it("labels the input with a visible label and wires aria attributes", () => {
      render(<Combobox label="Fruit" options={options} value={null} onChange={vi.fn()} />);
      const field = input();
      expect(field).toHaveAttribute("aria-expanded", "false");
      expect(field).toHaveAttribute("aria-autocomplete", "list");
      expect(field).not.toHaveAttribute("aria-activedescendant");
      expect(field.getAttribute("aria-controls")).toBe(screen.getByRole("listbox", { hidden: true }).id);
    });

    it("listbox is hidden until the user types or uses ArrowDown", async () => {
      const user = userEvent.setup();
      render(<Controlled onChange={vi.fn()} />);
      expect(screen.queryByRole("listbox")).not.toBeInTheDocument();
      await user.click(input());
      await user.keyboard("a");
      expect(screen.getByRole("listbox", { name: "Fruit" })).toBeVisible();
      expect(input()).toHaveAttribute("aria-expanded", "true");
    });

    it("options carry aria-selected for the selected value and aria-disabled when disabled", async () => {
      const user = userEvent.setup();
      render(<Combobox label="Fruit" options={options} value="cherry" onChange={vi.fn()} />);
      await user.clear(input());
      expect(screen.getByRole("option", { name: "Cherry" })).toHaveAttribute("aria-selected", "true");
      expect(screen.getByRole("option", { name: "Apple" })).toHaveAttribute("aria-selected", "false");
      expect(screen.getByRole("option", { name: "Banana" })).toHaveAttribute("aria-disabled", "true");
      expect(screen.getByRole("option", { name: "Apple" })).not.toHaveAttribute("aria-disabled");
    });

    it("two instances on one page have no duplicate ids", () => {
      render(
        <>
          <Combobox label="One" options={options} value={null} onChange={vi.fn()} />
          <Combobox label="Two" options={options} value={null} onChange={vi.fn()} />
        </>,
      );
      const ids = Array.from(document.querySelectorAll("[id]")).map((element) => element.id);
      expect(new Set(ids).size).toBe(ids.length);
    });
  });

  describe("filtering", () => {
    it("typing opens the popup and filters case-insensitively by substring", async () => {
      const user = userEvent.setup();
      render(<Controlled onChange={vi.fn()} />);
      await user.type(input(), "AP");
      const names = screen.getAllByRole("option").map((option) => option.textContent);
      expect(names).toEqual(["Apple", "Apricot"]);
    });

    it("shows a No results message, not an option, and unsets aria-activedescendant", async () => {
      const user = userEvent.setup();
      render(<Controlled onChange={vi.fn()} />);
      await user.type(input(), "zzz");
      expect(screen.queryByRole("option")).not.toBeInTheDocument();
      expect(screen.getByRole("status")).toHaveTextContent("No results");
      expect(input()).not.toHaveAttribute("aria-activedescendant");
    });

    it("treats regex metacharacters literally", async () => {
      const user = userEvent.setup();
      render(<Controlled onChange={vi.fn()} />);
      await user.type(input(), "(");
      expect(screen.getByRole("status")).toHaveTextContent("No results");
      await user.clear(input());
      await user.type(input(), ".");
      expect(screen.queryByRole("option")).not.toBeInTheDocument();
    });

    it("a whitespace-only query is trimmed and shows all options", async () => {
      const user = userEvent.setup();
      render(<Controlled onChange={vi.fn()} />);
      await user.type(input(), "   ");
      expect(screen.getAllByRole("option")).toHaveLength(4);
    });
  });

  describe("keyboard", () => {
    it("ArrowDown opens the popup and moves the active option, skipping disabled ones", async () => {
      const user = userEvent.setup();
      render(<Controlled onChange={vi.fn()} />);
      input().focus();
      await user.keyboard("{ArrowDown}");
      expect(input()).toHaveAttribute("aria-expanded", "true");
      expect(input()).toHaveAttribute("aria-activedescendant", screen.getByRole("option", { name: "Apple" }).id);

      await user.keyboard("{ArrowDown}");
      expect(input()).toHaveAttribute("aria-activedescendant", screen.getByRole("option", { name: "Cherry" }).id);
    });

    it("ArrowDown and ArrowUp wrap at the ends", async () => {
      const user = userEvent.setup();
      render(<Controlled onChange={vi.fn()} />);
      input().focus();
      await user.keyboard("{ArrowUp}");
      expect(input()).toHaveAttribute("aria-activedescendant", screen.getByRole("option", { name: "Apricot" }).id);
      await user.keyboard("{ArrowDown}");
      expect(input()).toHaveAttribute("aria-activedescendant", screen.getByRole("option", { name: "Apple" }).id);
    });

    it("Enter with an active option selects it, closes, and shows its label", async () => {
      const user = userEvent.setup();
      const onChange = vi.fn();
      render(<Controlled onChange={onChange} />);
      input().focus();
      await user.keyboard("{ArrowDown}{ArrowDown}{Enter}");
      expect(onChange).toHaveBeenCalledWith("cherry");
      expect(input()).toHaveValue("Cherry");
      expect(input()).toHaveAttribute("aria-expanded", "false");
      expect(screen.getByRole("option", { name: "Cherry", hidden: true })).toHaveAttribute("aria-selected", "true");
    });

    it("Enter with no active option does not call onChange", async () => {
      const user = userEvent.setup();
      const onChange = vi.fn();
      render(<Controlled onChange={onChange} />);
      await user.type(input(), "ch");
      await user.keyboard("{Enter}");
      expect(onChange).not.toHaveBeenCalled();
      expect(input()).toHaveValue("ch");
    });

    it("Enter while closed does nothing harmful", async () => {
      const user = userEvent.setup();
      const onChange = vi.fn();
      render(<Controlled initial="apple" onChange={onChange} />);
      input().focus();
      await user.keyboard("{Enter}");
      expect(onChange).not.toHaveBeenCalled();
      expect(input()).toHaveValue("Apple");
    });

    it("all options disabled: ArrowDown sets no active descendant", async () => {
      const user = userEvent.setup();
      const items: ComboboxOption[] = [{ value: "x", label: "Xylo", disabled: true }];
      render(<Controlled items={items} onChange={vi.fn()} />);
      input().focus();
      await user.keyboard("{ArrowDown}");
      expect(input()).not.toHaveAttribute("aria-activedescendant");
    });

    it("when filtering removes the active option, the active option resets", async () => {
      const user = userEvent.setup();
      render(<Controlled onChange={vi.fn()} />);
      input().focus();
      await user.keyboard("{ArrowDown}");
      expect(input()).toHaveAttribute("aria-activedescendant");
      await user.type(input(), "ch");
      expect(input()).not.toHaveAttribute("aria-activedescendant");
    });

    it("Escape closes without calling onChange and restores the selected label", async () => {
      const user = userEvent.setup();
      const onChange = vi.fn();
      render(<Controlled initial="apple" onChange={onChange} />);
      await user.click(input());
      await user.clear(input());
      await user.type(input(), "ch");
      await user.keyboard("{Escape}");
      expect(onChange).not.toHaveBeenCalled();
      expect(input()).toHaveValue("Apple");
      expect(input()).toHaveAttribute("aria-expanded", "false");
    });
  });

  describe("mouse", () => {
    it("clicking an enabled option selects it", async () => {
      const user = userEvent.setup();
      const onChange = vi.fn();
      render(<Controlled onChange={onChange} />);
      await user.type(input(), "ap");
      await user.click(screen.getByRole("option", { name: "Apricot" }));
      expect(onChange).toHaveBeenCalledWith("apricot");
      expect(input()).toHaveValue("Apricot");
    });

    it("clicking a disabled option does nothing", async () => {
      const user = userEvent.setup();
      const onChange = vi.fn();
      render(<Controlled onChange={onChange} />);
      await user.type(input(), "ban");
      await user.click(screen.getByRole("option", { name: "Banana" }));
      expect(onChange).not.toHaveBeenCalled();
      expect(input()).toHaveValue("ban");
    });
  });

  describe("clearing and blur", () => {
    it("emptying the input and blurring calls onChange(null) when a value was selected", async () => {
      const user = userEvent.setup();
      const onChange = vi.fn();
      render(<Controlled initial="apple" onChange={onChange} />);
      await user.click(input());
      await user.clear(input());
      await user.tab();
      expect(onChange).toHaveBeenCalledWith(null);
      expect(input()).toHaveValue("");
    });

    it("emptying the input and pressing Enter calls onChange(null) and leaves the input empty", async () => {
      const user = userEvent.setup();
      const onChange = vi.fn();
      render(<Controlled initial="apple" onChange={onChange} />);
      await user.click(input());
      await user.clear(input());
      await user.keyboard("{Enter}");
      expect(onChange).toHaveBeenCalledWith(null);
      expect(input()).toHaveValue("");
    });

    it("emptying the input when nothing was selected does not call onChange", async () => {
      const user = userEvent.setup();
      const onChange = vi.fn();
      render(<Controlled onChange={onChange} />);
      await user.type(input(), "a");
      await user.clear(input());
      await user.tab();
      expect(onChange).not.toHaveBeenCalled();
    });

    it("blurring with text restores the selected label and closes", async () => {
      const user = userEvent.setup();
      const onChange = vi.fn();
      render(<Controlled initial="cherry" onChange={onChange} />);
      await user.click(input());
      await user.type(input(), "ap");
      await user.tab();
      expect(onChange).not.toHaveBeenCalled();
      expect(input()).toHaveValue("Cherry");
      expect(screen.queryByRole("listbox")).toBeNull();
      expect(input()).toHaveAttribute("aria-expanded", "false");
    });
  });

  describe("controlled value", () => {
    it("with a parent that ignores onChange, selecting shows the label of the still-selected value", async () => {
      const user = userEvent.setup();
      render(<Combobox label="Fruit" options={options} value="apple" onChange={vi.fn()} />);
      await user.click(input());
      await user.clear(input());
      await user.type(input(), "ch");
      await user.keyboard("{ArrowDown}{Enter}");
      expect(input()).toHaveValue("Apple");
    });

    it("with value null and a parent that ignores onChange, selecting leaves the input empty", async () => {
      const user = userEvent.setup();
      render(<Combobox label="Fruit" options={options} value={null} onChange={vi.fn()} />);
      await user.click(input());
      await user.type(input(), "ch");
      await user.keyboard("{ArrowDown}{Enter}");
      expect(input()).toHaveValue("");
    });

    it("clearing and blurring with a parent that ignores onChange shows the old label again", async () => {
      const user = userEvent.setup();
      const onChange = vi.fn();
      render(<Combobox label="Fruit" options={options} value="apple" onChange={onChange} />);
      await user.click(input());
      await user.clear(input());
      await user.tab();
      expect(onChange).toHaveBeenCalledWith(null);
      expect(input()).toHaveValue("Apple");
    });

    it("inside an open Dialog, the first Escape closes only the popup", async () => {
      const user = userEvent.setup();
      const onOpenChange = vi.fn();
      render(
        <Dialog open title="Pick" onOpenChange={onOpenChange}>
          <Controlled onChange={vi.fn()} />
        </Dialog>,
      );
      await user.click(input());
      await user.type(input(), "ch");
      expect(input()).toHaveAttribute("aria-expanded", "true");
      await user.keyboard("{Escape}");
      expect(input()).toHaveAttribute("aria-expanded", "false");
      expect(onOpenChange).not.toHaveBeenCalled();
      await user.keyboard("{Escape}");
      expect(onOpenChange).toHaveBeenCalledWith(false);
    });

    it("value null, or a value matching no option, shows an empty input and the placeholder", () => {
      const { unmount } = render(<Combobox label="Fruit" options={options} value={null} onChange={vi.fn()} placeholder="Pick" />);
      expect(input()).toHaveValue("");
      expect(input()).toHaveAttribute("placeholder", "Pick");
      unmount();
      render(<Combobox label="Fruit" options={options} value="nope" onChange={vi.fn()} placeholder="Pick" />);
      expect(input()).toHaveValue("");
    });

    it("the displayed selection comes from value; selecting without a parent update does not change it", async () => {
      const user = userEvent.setup();
      const onChange = vi.fn();
      const { rerender } = render(<Combobox label="Fruit" options={options} value="apple" onChange={onChange} />);
      await user.click(input());
      await user.clear(input());
      await user.type(input(), "ch");
      await user.keyboard("{ArrowDown}{Enter}");
      expect(onChange).toHaveBeenCalledWith("cherry");
      await user.tab();
      expect(input()).toHaveValue("Apple");

      rerender(<Combobox label="Fruit" options={options} value="cherry" onChange={onChange} />);
      expect(input()).toHaveValue("Cherry");
    });
  });
});

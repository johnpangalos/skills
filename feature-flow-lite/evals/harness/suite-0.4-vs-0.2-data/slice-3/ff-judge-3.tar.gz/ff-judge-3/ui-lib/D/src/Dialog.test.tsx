import { fireEvent, render, screen } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { useState, type ReactNode } from "react";
import { Dialog } from "./Dialog";

function renderDialog({
  open = true,
  description,
  onOpenChange = vi.fn(),
  children = (
    <>
      <button>First</button>
      <button>Second</button>
    </>
  ),
}: { open?: boolean; description?: ReactNode; onOpenChange?: (open: boolean) => void; children?: ReactNode } = {}) {
  const result = render(
    <Dialog open={open} onOpenChange={onOpenChange} title="Confirm" description={description}>
      {children}
    </Dialog>,
  );
  return { ...result, onOpenChange };
}

// Opens and closes through a real parent so focus restoration is exercised end to end.
function Harness({ children }: { children?: ReactNode }) {
  const [open, setOpen] = useState(false);
  return (
    <>
      <button onClick={() => setOpen(true)}>Open</button>
      <Dialog open={open} onOpenChange={setOpen} title="Confirm">
        {children ?? <input aria-label="Name" />}
      </Dialog>
    </>
  );
}

describe("Dialog", () => {
  it("renders nothing when closed", () => {
    renderDialog({ open: false });
    expect(screen.queryByRole("dialog")).toBeNull();
    expect(document.querySelector("[data-backdrop]")).toBeNull();
  });

  it("portals a backdrop and the dialog into document.body", () => {
    const { container } = renderDialog();
    expect(container).toBeEmptyDOMElement();
    expect(document.querySelector("[data-backdrop]")?.parentElement).toBe(document.body);
    expect(screen.getByRole("dialog").parentElement).toBe(document.body);
  });

  it("sets aria-modal and labels the dialog by its title, describing it only when a description is given", () => {
    const { unmount } = renderDialog();
    const dialog = screen.getByRole("dialog", { name: "Confirm" });
    expect(dialog).toHaveAttribute("aria-modal", "true");
    expect(dialog).not.toHaveAttribute("aria-describedby");
    unmount();
    renderDialog({ description: "This cannot be undone." });
    const described = screen.getByRole("dialog", { name: "Confirm" });
    expect(described).toHaveAccessibleDescription("This cannot be undone.");
    expect(document.getElementById(described.getAttribute("aria-describedby") ?? "")).toHaveTextContent("This cannot be undone.");
  });

  it("focuses the first focusable element on open, or the container when there is none", () => {
    const { unmount } = renderDialog();
    expect(screen.getByRole("button", { name: "First" })).toHaveFocus();
    unmount();
    renderDialog({ children: <p>No controls</p> });
    expect(screen.getByRole("dialog")).toHaveFocus();
    expect(screen.getByRole("dialog")).toHaveAttribute("tabindex", "-1");
  });

  it("wraps Tab from the last focusable to the first", async () => {
    const user = userEvent.setup();
    renderDialog();
    screen.getByRole("button", { name: "Second" }).focus();
    await user.tab();
    expect(screen.getByRole("button", { name: "First" })).toHaveFocus();
  });

  it("wraps Shift+Tab from the first focusable, and from the container, to the last", async () => {
    const user = userEvent.setup();
    renderDialog();
    await user.tab({ shift: true });
    expect(screen.getByRole("button", { name: "Second" })).toHaveFocus();
    screen.getByRole("dialog").focus();
    await user.tab({ shift: true });
    expect(screen.getByRole("button", { name: "Second" })).toHaveFocus();
  });

  it("keeps focus on the container when there are no focusables", async () => {
    const user = userEvent.setup();
    renderDialog({ children: <p>Text only</p> });
    await user.tab();
    expect(screen.getByRole("dialog")).toHaveFocus();
    await user.tab({ shift: true });
    expect(screen.getByRole("dialog")).toHaveFocus();
  });

  it("calls onOpenChange(false) on Escape, including from a nested input", async () => {
    const user = userEvent.setup();
    const { onOpenChange } = renderDialog({ children: <input aria-label="Name" /> });
    expect(onOpenChange).not.toHaveBeenCalled();
    await user.keyboard("{Escape}");
    expect(onOpenChange).toHaveBeenCalledTimes(1);
    expect(onOpenChange).toHaveBeenCalledWith(false);
    expect(onOpenChange).not.toHaveBeenCalledWith(true);
  });

  it("calls onOpenChange(false) on backdrop click but not on clicks inside the content", async () => {
    const user = userEvent.setup();
    const { onOpenChange } = renderDialog();
    await user.click(screen.getByRole("button", { name: "First" }));
    await user.click(screen.getByRole("dialog"));
    expect(onOpenChange).not.toHaveBeenCalled();
    await user.click(document.querySelector("[data-backdrop]") as HTMLElement);
    expect(onOpenChange).toHaveBeenCalledTimes(1);
    expect(onOpenChange).toHaveBeenCalledWith(false);
  });

  it("restores focus to the previously focused element when the dialog closes", async () => {
    const user = userEvent.setup();
    render(<Harness />);
    await user.click(screen.getByRole("button", { name: "Open" }));
    expect(screen.getByRole("textbox", { name: "Name" })).toHaveFocus();
    await user.keyboard("{Escape}");
    expect(screen.queryByRole("dialog")).toBeNull();
    expect(screen.getByRole("button", { name: "Open" })).toHaveFocus();
  });

  it("restores focus when the dialog unmounts while open", () => {
    render(<button>Trigger</button>);
    screen.getByRole("button", { name: "Trigger" }).focus();
    const { unmount } = renderDialog();
    expect(screen.getByRole("button", { name: "First" })).toHaveFocus();
    unmount();
    expect(screen.getByRole("button", { name: "Trigger" })).toHaveFocus();
  });

  it("does not throw when the element that had focus was removed before close", () => {
    function RemovingHarness() {
      const [open, setOpen] = useState(false);
      const [showInput, setShowInput] = useState(true);
      return (
        <>
          <button onClick={() => setOpen(true)}>Open</button>
          <Dialog open={open} onOpenChange={setOpen} title="Confirm">
            {showInput && <input aria-label="Name" />}
            <button onClick={() => setShowInput(false)}>Remove input</button>
          </Dialog>
        </>
      );
    }
    render(<RemovingHarness />);
    screen.getByRole("button", { name: "Open" }).focus();
    fireEvent.click(screen.getByRole("button", { name: "Open" }));
    screen.getByRole("textbox", { name: "Name" }).focus();
    fireEvent.click(screen.getByRole("button", { name: "Remove input" }));
    expect(screen.queryByRole("textbox", { name: "Name" })).toBeNull();
    fireEvent.keyDown(screen.getByRole("dialog"), { key: "Escape" });
    expect(screen.queryByRole("dialog")).toBeNull();
    expect(screen.getByRole("button", { name: "Open" })).toHaveFocus();
  });

  it("covers elements added while open in the focus trap", async () => {
    const user = userEvent.setup();
    const { rerender, onOpenChange } = renderDialog();
    rerender(
      <Dialog open onOpenChange={onOpenChange} title="Confirm">
        <button>First</button>
        <button>Second</button>
        <button>Late</button>
      </Dialog>,
    );
    screen.getByRole("button", { name: "Late" }).focus();
    await user.tab();
    expect(screen.getByRole("button", { name: "First" })).toHaveFocus();
  });

  it("skips disabled, tabIndex -1 and hidden elements in the trap", async () => {
    const user = userEvent.setup();
    renderDialog({
      children: (
        <>
          <button disabled>Disabled</button>
          <button tabIndex={-1}>Skipped</button>
          <button hidden>Hidden</button>
          <button>Real</button>
        </>
      ),
    });
    expect(screen.getByRole("button", { name: "Real" })).toHaveFocus();
    await user.tab();
    expect(screen.getByRole("button", { name: "Real" })).toHaveFocus();
    await user.tab({ shift: true });
    expect(screen.getByRole("button", { name: "Real" })).toHaveFocus();
  });

  it("uses no duplicate ids when two instances render together", () => {
    const { unmount } = renderDialog({ description: "One" });
    unmount();
    renderDialog({ description: "Two" });
    renderDialog({ description: "Three" });
    const ids = Array.from(document.querySelectorAll("[id]"), (el) => el.id);
    expect(new Set(ids).size).toBe(ids.length);
  });

  it("focuses a contenteditable element with no tabindex as its only focusable child", () => {
    renderDialog({
      children: <div aria-label="Notes" contentEditable suppressContentEditableWarning />,
    });
    expect(screen.getByLabelText("Notes")).toHaveFocus();
  });

  it("closes only the inner dialog on Escape in a nested dialog", async () => {
    const user = userEvent.setup();
    const onOuter = vi.fn();
    const onInner = vi.fn();
    render(
      <Dialog open onOpenChange={onOuter} title="Outer">
        <Dialog open onOpenChange={onInner} title="Inner">
          <button>Inner action</button>
        </Dialog>
      </Dialog>,
    );
    screen.getByRole("button", { name: "Inner action" }).focus();
    await user.keyboard("{Escape}");
    expect(onInner).toHaveBeenCalledTimes(1);
    expect(onInner).toHaveBeenCalledWith(false);
    expect(onOuter).not.toHaveBeenCalled();
  });

  it("keeps Tab inside an inner dialog and does not move focus to the outer dialog", async () => {
    const user = userEvent.setup();
    render(
      <Dialog open onOpenChange={vi.fn()} title="Outer">
        <p>no focusables</p>
        <Dialog open onOpenChange={vi.fn()} title="Inner">
          <button>inner-only</button>
        </Dialog>
      </Dialog>,
    );
    screen.getByRole("button", { name: "inner-only" }).focus();
    await user.tab();
    expect(screen.getByRole("button", { name: "inner-only" })).toHaveFocus();
    expect(screen.getByRole("dialog", { name: "Outer" })).not.toHaveFocus();
  });

  it("keeps Tab and Shift+Tab inside the dialog when a tabIndex -1 element has focus", async () => {
    const user = userEvent.setup();
    render(
      <>
        <button>outside</button>
        <Dialog open onOpenChange={vi.fn()} title="Confirm">
          <button>in</button>
          <div tabIndex={-1}>neg</div>
        </Dialog>
      </>,
    );
    screen.getByText("neg").focus();
    await user.tab();
    expect(screen.getByRole("button", { name: "in" })).toHaveFocus();
    screen.getByText("neg").focus();
    await user.tab({ shift: true });
    expect(screen.getByRole("button", { name: "in" })).toHaveFocus();
  });
});

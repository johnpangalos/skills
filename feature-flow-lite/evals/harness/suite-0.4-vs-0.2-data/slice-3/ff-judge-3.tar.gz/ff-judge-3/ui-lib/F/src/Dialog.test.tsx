import { render, screen } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { describe, expect, it, vi } from "vitest";
import { StrictMode, useState } from "react";
import { Dialog, type DialogProps } from "./Dialog";
import { Tab, TabList, TabPanel, Tabs } from "./Tabs";

function ui(open: boolean, onOpenChange: (open: boolean) => void, extra: Partial<DialogProps> = {}) {
  return (
    <>
      <button>Opener</button>
      <Dialog open={open} onOpenChange={onOpenChange} title="Confirm" {...extra}>
        <button>First</button>
        <button>Second</button>
      </Dialog>
    </>
  );
}

const backdrop = () => document.querySelector("[data-backdrop]") as HTMLElement;

describe("Dialog rendering", () => {
  it("renders a portal with a backdrop and a labelled modal dialog", () => {
    render(ui(true, vi.fn()));
    const dialog = screen.getByRole("dialog", { name: "Confirm" });
    expect(dialog).toHaveAttribute("aria-modal", "true");
    expect(dialog.parentElement).toBe(document.body);
    expect(backdrop()).toBeInTheDocument();
    expect(document.getElementById(dialog.getAttribute("aria-labelledby") ?? "")?.tagName).toBe("H2");
  });

  it("links the description only when one is given", () => {
    const { unmount } = render(ui(true, vi.fn(), { description: "This cannot be undone." }));
    const dialog = screen.getByRole("dialog");
    const description = document.getElementById(dialog.getAttribute("aria-describedby") ?? "");
    expect(description).toHaveTextContent("This cannot be undone.");
    unmount();

    render(ui(true, vi.fn()));
    expect(screen.getByRole("dialog")).not.toHaveAttribute("aria-describedby");
  });

  it("renders nothing when closed", () => {
    render(ui(false, vi.fn()));
    expect(screen.queryByRole("dialog")).toBeNull();
    expect(backdrop()).toBeNull();
  });
});

describe("Dialog focus", () => {
  it("moves focus to the first tabbable element on open", () => {
    render(ui(true, vi.fn()));
    expect(screen.getByRole("button", { name: "First" })).toHaveFocus();
  });

  it("focuses the dialog itself when nothing inside is tabbable", () => {
    render(
      <Dialog open title="Notice" onOpenChange={vi.fn()}>
        plain text
      </Dialog>,
    );
    expect(screen.getByRole("dialog")).toHaveFocus();
    expect(screen.getByRole("dialog")).toHaveAttribute("tabindex", "-1");
  });

  it("wraps Tab from the last tabbable element to the first", async () => {
    const user = userEvent.setup();
    render(ui(true, vi.fn()));
    await user.keyboard("{Tab}");
    expect(screen.getByRole("button", { name: "Second" })).toHaveFocus();
    await user.keyboard("{Tab}");
    expect(screen.getByRole("button", { name: "First" })).toHaveFocus();
  });

  it("wraps Shift+Tab from the first tabbable element to the last", async () => {
    const user = userEvent.setup();
    render(ui(true, vi.fn()));
    await user.keyboard("{Shift>}{Tab}{/Shift}");
    expect(screen.getByRole("button", { name: "Second" })).toHaveFocus();
  });

  it("keeps focus on the dialog when there are no tabbables", async () => {
    const user = userEvent.setup();
    render(
      <Dialog open title="Notice" onOpenChange={vi.fn()}>
        plain text
      </Dialog>,
    );
    await user.keyboard("{Tab}");
    expect(screen.getByRole("dialog")).toHaveFocus();
    await user.keyboard("{Shift>}{Tab}{/Shift}");
    expect(screen.getByRole("dialog")).toHaveFocus();
  });

  it("pulls focus back when it escapes to an element outside the dialog", () => {
    render(ui(true, vi.fn()));
    screen.getByRole("button", { name: "Opener" }).focus();
    expect(screen.getByRole("button", { name: "First" })).toHaveFocus();
  });
});

describe("Dialog closing", () => {
  it("calls onOpenChange(false) on Escape", async () => {
    const user = userEvent.setup();
    const onOpenChange = vi.fn();
    render(ui(true, onOpenChange));
    await user.keyboard("{Escape}");
    expect(onOpenChange).toHaveBeenCalledTimes(1);
    expect(onOpenChange).toHaveBeenCalledWith(false);
  });

  it("calls onOpenChange(false) on Escape pressed inside a nested input", async () => {
    const user = userEvent.setup();
    const onOpenChange = vi.fn();
    render(
      <Dialog open title="Search" onOpenChange={onOpenChange}>
        <input aria-label="Query" />
      </Dialog>,
    );
    await user.click(screen.getByRole("textbox", { name: "Query" }));
    await user.keyboard("{Escape}");
    expect(onOpenChange).toHaveBeenCalledWith(false);
  });

  it("calls onOpenChange(false) on a backdrop click", async () => {
    const user = userEvent.setup();
    const onOpenChange = vi.fn();
    render(ui(true, onOpenChange));
    await user.click(backdrop());
    expect(onOpenChange).toHaveBeenCalledTimes(1);
    expect(onOpenChange).toHaveBeenCalledWith(false);
  });

  it("does not close when clicking inside the dialog", async () => {
    const user = userEvent.setup();
    const onOpenChange = vi.fn();
    render(ui(true, onOpenChange));
    await user.click(screen.getByText("Confirm"));
    await user.click(screen.getByRole("button", { name: "First" }));
    await user.click(screen.getByRole("dialog"));
    expect(onOpenChange).not.toHaveBeenCalled();
  });

  it("does not close when a press starts inside the dialog and ends on the backdrop", async () => {
    const user = userEvent.setup();
    const onOpenChange = vi.fn();
    render(ui(true, onOpenChange));
    await user.pointer([
      { keys: "[MouseLeft>]", target: screen.getByRole("button", { name: "First" }) },
      { target: backdrop() },
      { keys: "[/MouseLeft]", target: backdrop() },
    ]);
    expect(onOpenChange).not.toHaveBeenCalled();
  });

  it("returns focus to the previously focused element on close", async () => {
    const user = userEvent.setup();
    const { rerender } = render(ui(false, vi.fn()));
    await user.click(screen.getByRole("button", { name: "Opener" }));
    rerender(ui(true, vi.fn()));
    expect(screen.getByRole("button", { name: "First" })).toHaveFocus();
    rerender(ui(false, vi.fn()));
    expect(screen.getByRole("button", { name: "Opener" })).toHaveFocus();
  });

  it("returns focus to the previously focused element on unmount", async () => {
    const user = userEvent.setup();
    render(<button>Opener</button>);
    const opener = screen.getByRole("button", { name: "Opener" });
    await user.click(opener);
    const dialog = render(
      <Dialog open title="Confirm" onOpenChange={vi.fn()}>
        <button>First</button>
      </Dialog>,
    );
    expect(screen.getByRole("button", { name: "First" })).toHaveFocus();
    dialog.unmount();
    expect(opener).toHaveFocus();
  });

  it("does not throw when it closes with focus on body", () => {
    const { rerender } = render(ui(true, vi.fn()));
    (document.activeElement as HTMLElement).blur();
    expect(document.activeElement).toBe(document.body);
    expect(() => rerender(ui(false, vi.fn()))).not.toThrow();
    expect(screen.queryByRole("dialog")).toBeNull();
  });

  it("renders one portal and still restores focus after rapid open/close toggles", async () => {
    const user = userEvent.setup();
    const { rerender } = render(ui(false, vi.fn()));
    await user.click(screen.getByRole("button", { name: "Opener" }));
    rerender(ui(true, vi.fn()));
    rerender(ui(false, vi.fn()));
    rerender(ui(true, vi.fn()));
    expect(document.querySelectorAll('[role="dialog"]')).toHaveLength(1);
    expect(document.querySelectorAll("[data-backdrop]")).toHaveLength(1);
    rerender(ui(false, vi.fn()));
    expect(screen.getByRole("button", { name: "Opener" })).toHaveFocus();
  });
});

// Opens from the trigger; the input inside takes focus with autoFocus.
function AutoFocusHost() {
  const [open, setOpen] = useState(false);
  return (
    <>
      <button onClick={() => setOpen(true)}>Trigger</button>
      <Dialog open={open} onOpenChange={setOpen} title="Search">
        <button>first</button>
        <input autoFocus aria-label="Query" />
      </Dialog>
    </>
  );
}

// Outer dialog holds the button that opens the inner one.
function NestedHost({ onOuterChange, onInnerChange }: { onOuterChange: (open: boolean) => void; onInnerChange: (open: boolean) => void }) {
  const [outer, setOuter] = useState(false);
  const [inner, setInner] = useState(false);
  return (
    <>
      <button onClick={() => setOuter(true)}>Open outer</button>
      <Dialog
        open={outer}
        onOpenChange={(next) => {
          onOuterChange(next);
          setOuter(next);
        }}
        title="Outer"
      >
        <button onClick={() => setInner(true)}>Open inner</button>
      </Dialog>
      <Dialog
        open={inner}
        onOpenChange={(next) => {
          onInnerChange(next);
          setInner(next);
        }}
        title="Inner"
      >
        <button>Inner action</button>
      </Dialog>
    </>
  );
}

// The inner dialog's first focus target is an autoFocus input, which takes focus during the commit.
function NestedAutoFocusHost({ onOuterChange, onInnerChange }: { onOuterChange: (open: boolean) => void; onInnerChange: (open: boolean) => void }) {
  const [outer, setOuter] = useState(false);
  const [inner, setInner] = useState(false);
  return (
    <>
      <button onClick={() => setOuter(true)}>Open outer</button>
      <Dialog
        open={outer}
        onOpenChange={(next) => {
          onOuterChange(next);
          setOuter(next);
        }}
        title="Outer"
      >
        <button onClick={() => setInner(true)}>Open inner</button>
        <Dialog
          open={inner}
          onOpenChange={(next) => {
            onInnerChange(next);
            setInner(next);
          }}
          title="Inner"
        >
          <button>first</button>
          <input autoFocus aria-label="Query" />
        </Dialog>
      </Dialog>
    </>
  );
}

describe("Dialog tabbable elements", () => {
  it("focuses the selected tab, and Shift+Tab never reaches a hidden tabpanel", async () => {
    const user = userEvent.setup();
    render(
      <Dialog open onOpenChange={vi.fn()} title="Tabs">
        <Tabs defaultValue="b">
          <TabList aria-label="Sections">
            <Tab value="a">A</Tab>
            <Tab value="b">B</Tab>
          </TabList>
          <TabPanel value="a">Panel A</TabPanel>
          <TabPanel value="b">Panel B</TabPanel>
        </Tabs>
      </Dialog>,
    );
    expect(screen.getByRole("tab", { name: "B" })).toHaveFocus();
    await user.keyboard("{Shift>}{Tab}{/Shift}");
    expect(screen.getByRole("tabpanel")).toHaveFocus();
    expect(screen.getByText("Panel A")).not.toHaveFocus();
  });

  it("skips a type=hidden input so the first real control gets focus", () => {
    render(
      <Dialog open onOpenChange={vi.fn()} title="Hidden input">
        <input type="hidden" name="token" />
        <button>ok</button>
      </Dialog>,
    );
    expect(screen.getByRole("button", { name: "ok" })).toHaveFocus();
  });

  it("skips disabled, tabindex=-1 and hidden elements when choosing the initial focus", () => {
    render(
      <Dialog open onOpenChange={vi.fn()} title="Skips">
        <button disabled>off</button>
        <button tabIndex={-1}>skipped</button>
        <div hidden>
          <button>inside hidden</button>
        </div>
        <button>ok</button>
      </Dialog>,
    );
    expect(screen.getByRole("button", { name: "ok" })).toHaveFocus();
  });
});

describe("Dialog focus restoration", () => {
  it("keeps focus on an autoFocus child and returns it to the trigger on Escape", async () => {
    const user = userEvent.setup();
    render(<AutoFocusHost />);
    await user.click(screen.getByRole("button", { name: "Trigger" }));
    expect(screen.getByRole("textbox", { name: "Query" })).toHaveFocus();
    await user.keyboard("{Escape}");
    expect(screen.getByRole("button", { name: "Trigger" })).toHaveFocus();
  });
});

describe("Nested dialogs", () => {
  it("focuses the inner dialog and lets one Escape close only the inner one", async () => {
    const user = userEvent.setup();
    const onOuterChange = vi.fn();
    const onInnerChange = vi.fn();
    render(<NestedHost onOuterChange={onOuterChange} onInnerChange={onInnerChange} />);
    await user.click(screen.getByRole("button", { name: "Open outer" }));
    await user.click(screen.getByRole("button", { name: "Open inner" }));
    expect(screen.getByRole("button", { name: "Inner action" })).toHaveFocus();

    await user.keyboard("{Escape}");
    expect(onInnerChange).toHaveBeenCalledTimes(1);
    expect(onInnerChange).toHaveBeenCalledWith(false);
    expect(onOuterChange).not.toHaveBeenCalled();
    expect(screen.getByRole("dialog", { name: "Outer" })).toBeInTheDocument();
    expect(screen.getByRole("button", { name: "Open inner" })).toHaveFocus();
  });

  it("pulls focus back into the topmost dialog without recursing", async () => {
    const user = userEvent.setup();
    render(<NestedHost onOuterChange={vi.fn()} onInnerChange={vi.fn()} />);
    await user.click(screen.getByRole("button", { name: "Open outer" }));
    await user.click(screen.getByRole("button", { name: "Open inner" }));
    screen.getByRole("button", { name: "Open inner" }).focus();
    expect(screen.getByRole("button", { name: "Inner action" })).toHaveFocus();
  });

  it("keeps focus on an autoFocus input in the inner dialog and returns it to the opener on Escape", async () => {
    const user = userEvent.setup();
    const onOuterChange = vi.fn();
    const onInnerChange = vi.fn();
    render(<NestedAutoFocusHost onOuterChange={onOuterChange} onInnerChange={onInnerChange} />);
    await user.click(screen.getByRole("button", { name: "Open outer" }));
    await user.click(screen.getByRole("button", { name: "Open inner" }));
    expect(screen.getByRole("textbox", { name: "Query" })).toHaveFocus();

    await user.keyboard("{Escape}");
    expect(onInnerChange).toHaveBeenCalledTimes(1);
    expect(onInnerChange).toHaveBeenCalledWith(false);
    expect(onOuterChange).not.toHaveBeenCalled();
    expect(screen.queryByRole("dialog", { name: "Inner" })).toBeNull();
    expect(screen.getByRole("dialog", { name: "Outer" })).toBeInTheDocument();
    expect(screen.getByRole("button", { name: "Open inner" })).toHaveFocus();
  });
});

// One click opens the outer and inner dialogs in the same commit. The inner one is nested in the outer one.
function SameCommitHost({ onOuterChange, onInnerChange }: { onOuterChange: (open: boolean) => void; onInnerChange: (open: boolean) => void }) {
  const [outer, setOuter] = useState(false);
  const [inner, setInner] = useState(false);
  return (
    <>
      <button
        onClick={() => {
          setOuter(true);
          setInner(true);
        }}
      >
        Open both
      </button>
      <Dialog
        open={outer}
        onOpenChange={(next) => {
          onOuterChange(next);
          setOuter(next);
        }}
        title="Outer"
      >
        <Dialog
          open={inner}
          onOpenChange={(next) => {
            onInnerChange(next);
            setInner(next);
          }}
          title="Inner"
        >
          <button>first</button>
          <input autoFocus aria-label="Query" />
        </Dialog>
      </Dialog>
    </>
  );
}

describe("Nested dialogs opened in the same commit", () => {
  it.each([false, true])("stacks the inner dialog above the outer when one click opens both (StrictMode: %s)", async (strict) => {
    const user = userEvent.setup();
    const onOuterChange = vi.fn();
    const onInnerChange = vi.fn();
    const host = <SameCommitHost onOuterChange={onOuterChange} onInnerChange={onInnerChange} />;
    render(strict ? <StrictMode>{host}</StrictMode> : host);
    await user.click(screen.getByRole("button", { name: "Open both" }));
    expect(screen.getByRole("textbox", { name: "Query" })).toHaveFocus();

    await user.keyboard("{Escape}");
    expect(onInnerChange).toHaveBeenCalledTimes(1);
    expect(onInnerChange).toHaveBeenCalledWith(false);
    expect(onOuterChange).not.toHaveBeenCalled();
    expect(screen.getByRole("dialog", { name: "Outer" })).toBeInTheDocument();
  });

  it.each([false, true])("stacks the inner dialog above the outer when both are mounted open (StrictMode: %s)", async (strict) => {
    const user = userEvent.setup();
    const onOuterChange = vi.fn();
    const onInnerChange = vi.fn();
    const host = (
      <Dialog open title="Outer" onOpenChange={onOuterChange}>
        <Dialog open title="Inner" onOpenChange={onInnerChange}>
          <button>first</button>
          <input autoFocus aria-label="Query" />
        </Dialog>
      </Dialog>
    );
    render(strict ? <StrictMode>{host}</StrictMode> : host);
    expect(screen.getByRole("textbox", { name: "Query" })).toHaveFocus();

    await user.keyboard("{Escape}");
    expect(onInnerChange).toHaveBeenCalledTimes(1);
    expect(onInnerChange).toHaveBeenCalledWith(false);
    expect(onOuterChange).not.toHaveBeenCalled();
  });
});

// Dialog A holds A2, which holds the button that opens the unrelated top-level dialog B.
function UnrelatedDialogHost({ onAChange, onBChange }: { onAChange: (open: boolean) => void; onBChange: (open: boolean) => void }) {
  const [a, setA] = useState(true);
  const [b, setB] = useState(false);
  return (
    <>
      <Dialog
        open={a}
        onOpenChange={(next) => {
          onAChange(next);
          setA(next);
        }}
        title="A"
      >
        <Dialog open title="A2" onOpenChange={() => {}}>
          <button onClick={() => setB(true)}>openB</button>
        </Dialog>
      </Dialog>
      <Dialog
        open={b}
        onOpenChange={(next) => {
          onBChange(next);
          setB(next);
        }}
        title="B"
      >
        <button>b-action</button>
      </Dialog>
    </>
  );
}

describe("Dialog opened from a nested dialog", () => {
  it.each([false, true])("keeps an unrelated dialog above the dialogs it was opened from (StrictMode: %s)", async (strict) => {
    const user = userEvent.setup();
    const onAChange = vi.fn();
    const onBChange = vi.fn();
    const host = <UnrelatedDialogHost onAChange={onAChange} onBChange={onBChange} />;
    render(strict ? <StrictMode>{host}</StrictMode> : host);
    await user.click(screen.getByRole("button", { name: "openB" }));
    expect(screen.getByRole("button", { name: "b-action" })).toHaveFocus();

    await user.keyboard("{Escape}");
    expect(onBChange).toHaveBeenCalledTimes(1);
    expect(onBChange).toHaveBeenCalledWith(false);
    expect(onAChange).not.toHaveBeenCalled();
    expect(screen.queryByRole("dialog", { name: "B" })).toBeNull();
    expect(screen.getByRole("dialog", { name: "A2" })).toBeInTheDocument();
  });
});

describe("Dialog ids and forwarding", () => {
  it("gives two open dialogs distinct label and description ids", () => {
    render(
      <>
        <Dialog open onOpenChange={vi.fn()} title="One" description="First">
          <button>a</button>
        </Dialog>
        <Dialog open onOpenChange={vi.fn()} title="Two" description="Second">
          <button>b</button>
        </Dialog>
      </>,
    );
    const [one, two] = screen.getAllByRole("dialog");
    expect(one.getAttribute("aria-labelledby")).not.toBe(two.getAttribute("aria-labelledby"));
    expect(one).toHaveAccessibleName("One");
    expect(two).toHaveAccessibleName("Two");
    expect(one).toHaveAccessibleDescription("First");
    expect(two).toHaveAccessibleDescription("Second");
  });

  it("forwards className and HTML props to the dialog element", () => {
    render(
      <Dialog open onOpenChange={vi.fn()} title="Props" className="sheet" id="custom" data-testid="sheet">
        <button>ok</button>
      </Dialog>,
    );
    const dialog = screen.getByRole("dialog");
    expect(dialog).toHaveClass("sheet");
    expect(dialog).toHaveAttribute("id", "custom");
    expect(dialog).toHaveAttribute("data-testid", "sheet");
  });
});

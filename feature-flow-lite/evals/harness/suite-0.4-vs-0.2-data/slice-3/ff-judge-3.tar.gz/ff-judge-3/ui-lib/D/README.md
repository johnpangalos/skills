# @acme/ui

Accessible, style-agnostic React 19 components: `Tabs`, `Dialog`, and `Combobox`. They follow the WAI-ARIA Authoring Practices patterns. They ship no CSS and no runtime dependencies beyond React and React DOM. Each component forwards `className` and other native props to its main element (listed per component below), and every id comes from `useId`, so multiple instances can share a page.

## Scripts

- `pnpm test` runs the Vitest suite.
- `pnpm typecheck` runs `tsc --noEmit`.

## Tabs

```tsx
import { Tabs, TabList, Tab, TabPanel } from "@acme/ui";

<Tabs defaultValue="profile">
  <TabList aria-label="Account">
    <Tab value="profile">Profile</Tab>
    <Tab value="billing">Billing</Tab>
    <Tab value="security" disabled>Security</Tab>
  </TabList>
  <TabPanel value="profile">Profile settings</TabPanel>
  <TabPanel value="billing">Billing settings</TabPanel>
  <TabPanel value="security">Security settings</TabPanel>
</Tabs>;
```

Uncontrolled use passes `defaultValue`. Controlled use passes `value` and `onValueChange`; if the parent does not update `value`, the selected tab does not change. With neither prop, the first enabled tab is selected. Tab order follows DOM order, so tabs added or removed later keep the correct sequence. A selected value that matches no tab leaves the first enabled tab as the single tab stop.

### Tabs props

| Name | Type | Required / default | Description |
| --- | --- | --- | --- |
| `value` | `string` | optional | Selected tab value for controlled use. |
| `defaultValue` | `string` | optional; first enabled tab | Initially selected tab value for uncontrolled use. |
| `onValueChange` | `(value: string) => void` | optional | Called with the new value when a tab is clicked, or when focus is moved to it with the arrow, Home, or End keys. |

Tabs also accepts any `div` props, which are forwarded to the wrapper element.

### TabList props

| Name | Type | Required / default | Description |
| --- | --- | --- | --- |
| `aria-label` | `string` | required | Accessible name for the tablist. |

Renders `role="tablist"` with `aria-orientation="horizontal"`. Accepts any `div` props.

### Tab props

| Name | Type | Required / default | Description |
| --- | --- | --- | --- |
| `value` | `string` | required | Identifies the tab and links it to its `TabPanel`. |
| `disabled` | `boolean` | optional; `false` | Disabled tabs cannot be clicked or reached with arrow, Home, or End keys. |

Renders a `<button type="button" role="tab">`. Accepts any `button` props except `value`.

### TabPanel props

| Name | Type | Required / default | Description |
| --- | --- | --- | --- |
| `value` | `string` | required | The tab value this panel belongs to. |

Renders `role="tabpanel"` with `tabIndex={0}`. Panels other than the selected one are rendered with the `hidden` attribute. Accepts any `div` props.

### Tabs keyboard

| Key | Behavior |
| --- | --- |
| `ArrowRight` | Moves focus to the next enabled tab and selects it. Wraps from the last tab to the first. |
| `ArrowLeft` | Moves focus to the previous enabled tab and selects it. Wraps from the first tab to the last. |
| `Home` | Moves focus to the first enabled tab and selects it. |
| `End` | Moves focus to the last enabled tab and selects it. |

## Dialog

```tsx
import { useState } from "react";
import { Dialog } from "@acme/ui";

function DeleteButton() {
  const [open, setOpen] = useState(false);
  return (
    <>
      <button onClick={() => setOpen(true)}>Delete</button>
      <Dialog open={open} onOpenChange={setOpen} title="Delete project?" description="This cannot be undone.">
        <button onClick={() => setOpen(false)}>Cancel</button>
        <button>Delete</button>
      </Dialog>
    </>
  );
}
```

`Dialog` is fully controlled and renders nothing while `open` is false. When it renders, it portals a backdrop and a `role="dialog"` element into `document.body`. Focus moves to the first focusable element inside the dialog, or to the dialog itself if there is none. Tab and Shift+Tab stay inside the dialog and wrap at both ends. When the dialog closes or unmounts, focus returns to the element that was focused before it opened. Clicking the backdrop calls `onOpenChange(false)`; clicks inside the dialog do not.

### Dialog props

| Name | Type | Required / default | Description |
| --- | --- | --- | --- |
| `open` | `boolean` | required | Whether the dialog is shown. |
| `onOpenChange` | `(open: boolean) => void` | required | Called with `false` on Escape or a backdrop click. It is never called with `true`. |
| `title` | `ReactNode` | required | Rendered as an `h2`; labels the dialog. |
| `description` | `ReactNode` | optional | Rendered as a `p`; describes the dialog. When omitted, the dialog has no `aria-describedby`. |

Accepts any `div` props except `title`, which are applied to the dialog element.

### Dialog keyboard

| Key | Behavior |
| --- | --- |
| `Escape` | Calls `onOpenChange(false)`. Works from any element inside the dialog, including a nested input. In a dialog nested inside another, closes only the innermost dialog. An open Combobox inside the dialog handles Escape first, so it closes only its listbox. |
| `Tab` | Moves to the next focusable element. Wraps from the last to the first. |
| `Shift+Tab` | Moves to the previous focusable element. Wraps from the first (or the dialog itself) to the last. |

Focusable elements that are disabled, have `tabIndex={-1}`, or sit inside a `hidden` element are skipped.

## Combobox

```tsx
import { useState } from "react";
import { Combobox, type ComboboxOption } from "@acme/ui";

const fruits: ComboboxOption[] = [
  { value: "apple", label: "Apple" },
  { value: "banana", label: "Banana" },
  { value: "cherry", label: "Cherry", disabled: true },
];

function FruitPicker() {
  const [fruit, setFruit] = useState<string | null>(null);
  return <Combobox label="Fruit" options={fruits} value={fruit} onChange={setFruit} placeholder="Type to search" />;
}
```

`Combobox` is controlled by `value` and `onChange`. The input shows the selected option's label while the user is not typing. Typing opens the listbox and shows options whose label contains the text, ignoring case. Focus stays in the input; the active option is announced through `aria-activedescendant`. Arrow keys wrap around at both ends and skip disabled options. Clearing the text calls `onChange(null)` once, but only when the value was not already `null`. Options are matched by `value`, so options can share a label.

### Combobox props

| Name | Type | Required / default | Description |
| --- | --- | --- | --- |
| `label` | `string` | required | Text of the `<label>` associated with the input. |
| `options` | `ComboboxOption[]` | required | Each option has `value`, `label`, and an optional `disabled`. |
| `value` | `string \| null` | required | The selected option's value, or `null` for none. Values that match no option show empty text. |
| `onChange` | `(value: string \| null) => void` | required | Called when an option is chosen, or with `null` when the text is cleared from a selected value. |
| `placeholder` | `string` | optional | Placeholder for the input. |

Accepts any `input` props except `value`, `defaultValue`, `onChange`, and `role`; these are forwarded to the input element.

The listbox is always in the DOM and is `hidden` while closed. The "No results" message appears when the listbox is open and no option matches.

### Combobox keyboard

| Key | Behavior |
| --- | --- |
| Typing | Opens the listbox and filters options by substring. |
| `ArrowDown` | Opens the listbox if closed, then moves the active option to the next enabled option. Wraps from the last to the first. |
| `ArrowUp` | Opens the listbox if closed, then moves the active option to the previous enabled option. Wraps from the first to the last. |
| `Enter` | Selects the active option, closes the listbox, and shows its label. Does nothing when no option is active. |
| `Escape` | When the listbox is open or text has been typed, closes the listbox without calling `onChange`, restores the selected option's label, and stops the event so an enclosing dialog stays open. When nothing is open or typed, Escape is not handled here and reaches an enclosing dialog, which closes. |

Clicking an enabled option selects it. Clicking a disabled option does nothing. Leaving the input closes the listbox and restores the selected label.

## Usage notes

Components render unstyled elements. Apply styles with `className`, and use the `data-` and `aria-` attributes that the components set (for example, `aria-selected` on tabs and options) as selectors. The backdrop carries `data-backdrop`, and the active Combobox option carries `data-active`.

import {
  useId,
  useState,
  type InputHTMLAttributes,
  type KeyboardEvent,
} from "react";

export interface ComboboxOption {
  value: string;
  label: string;
  disabled?: boolean;
}

export interface ComboboxProps
  extends Omit<InputHTMLAttributes<HTMLInputElement>, "value" | "onChange" | "placeholder" | "onKeyDown" | "onBlur"> {
  label: string;
  options: ComboboxOption[];
  value: string | null;
  onChange: (value: string | null) => void;
  placeholder?: string;
}

export function Combobox({ label, options, value, onChange, placeholder, onClick, ...rest }: ComboboxProps) {
  const id = useId();
  const inputId = `${id}-input`;
  const labelId = `${id}-label`;
  const listboxId = `${id}-listbox`;
  // query is the typed text while editing; null means the input shows the selected label.
  const [query, setQuery] = useState<string | null>(null);
  const [open, setOpen] = useState(false);
  const [activeIndex, setActiveIndex] = useState<number | null>(null);

  const selectedLabel = options.find((option) => option.value === value)?.label ?? "";
  const matches = options
    .map((option, index) => ({ option, index }))
    .filter(({ option }) => !query || option.label.toLowerCase().includes(query.toLowerCase()));
  const enabled = matches.filter(({ option }) => !option.disabled).map(({ index }) => index);
  // Derived so an active option that is filtered out or closed is never reported.
  const active = open && activeIndex !== null && enabled.includes(activeIndex) ? activeIndex : null;

  const close = () => {
    setOpen(false);
    setQuery(null);
    setActiveIndex(null);
  };

  const choose = (option: ComboboxOption) => {
    onChange(option.value);
    close();
  };

  // Empty text commits an empty selection. Closing resets the text, so a later blur does not repeat the call.
  const clear = () => {
    if (value !== null) onChange(null);
    close();
  };

  const move = (step: 1 | -1) => {
    setOpen(true);
    if (enabled.length === 0) {
      setActiveIndex(null);
      return;
    }
    const current = active === null ? (step === 1 ? -1 : 0) : enabled.indexOf(active);
    setActiveIndex(enabled[(current + step + enabled.length) % enabled.length]);
  };

  const handleKeyDown = (event: KeyboardEvent<HTMLInputElement>) => {
    switch (event.key) {
      case "ArrowDown":
        event.preventDefault();
        move(1);
        break;
      case "ArrowUp":
        event.preventDefault();
        move(-1);
        break;
      case "Enter":
        // While the popup is open, Enter belongs to the combobox and must not submit a form.
        if (!open) break;
        event.preventDefault();
        if (active !== null) choose(options[active]);
        else if (query === "") clear();
        break;
      case "Escape":
        if (!open) break;
        // Stop here so an enclosing dialog stays open.
        event.preventDefault();
        event.stopPropagation();
        close();
        break;
    }
  };

  return (
    <>
      <label id={labelId} htmlFor={inputId}>
        {label}
      </label>
      <input
        {...rest}
        id={inputId}
        type="text"
        role="combobox"
        autoComplete="off"
        placeholder={placeholder}
        value={query ?? selectedLabel}
        aria-expanded={open}
        aria-controls={listboxId}
        aria-autocomplete="list"
        aria-activedescendant={active !== null ? `${id}-option-${active}` : undefined}
        onChange={(event) => {
          setQuery(event.target.value);
          setOpen(true);
          setActiveIndex(null);
        }}
        onClick={(event) => {
          onClick?.(event);
          setOpen(true);
        }}
        onKeyDown={handleKeyDown}
        onBlur={() => (query === "" ? clear() : close())}
      />
      <ul id={listboxId} role="listbox" aria-labelledby={labelId} hidden={!open}>
        {matches.map(({ option, index }) => (
          <li
            key={index}
            id={`${id}-option-${index}`}
            role="option"
            aria-selected={option.value === value}
            aria-disabled={option.disabled ? "true" : undefined}
            // Keep focus on the input so the blur handler does not close the popup before the click lands.
            onMouseDown={(event) => event.preventDefault()}
            onClick={() => {
              if (!option.disabled) choose(option);
            }}
          >
            {option.label}
          </li>
        ))}
      </ul>
      {open && matches.length === 0 && <div role="status">No results</div>}
    </>
  );
}

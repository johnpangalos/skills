import { fireEvent, render, screen } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { describe, expect, it, vi } from "vitest";
import { useState } from "react";
import { Tab, TabList, TabPanel, Tabs, type TabsProps } from "./Tabs";

type Options = Omit<TabsProps, "children"> & { disabled?: string[] };

function ui({ disabled = [], ...props }: Options = {}) {
  return (
    <Tabs {...props}>
      <TabList aria-label="Sections">
        <Tab value="a" disabled={disabled.includes("a")}>A</Tab>
        <Tab value="b" disabled={disabled.includes("b")}>B</Tab>
        <Tab value="c" disabled={disabled.includes("c")}>C</Tab>
      </TabList>
      <TabPanel value="a">Panel A</TabPanel>
      <TabPanel value="b">Panel B</TabPanel>
      <TabPanel value="c">Panel C</TabPanel>
    </Tabs>
  );
}

const tab = (name: string) => screen.getByRole("tab", { name });

describe("Tabs roles", () => {
  it("labels the tablist and wires each tab to its panel", () => {
    render(ui({ defaultValue: "a" }));
    expect(screen.getByRole("tablist", { name: "Sections" })).toBeInTheDocument();

    const b = tab("B");
    expect(b.tagName).toBe("BUTTON");
    expect(b).toHaveAttribute("type", "button");
    const panel = document.getElementById(b.getAttribute("aria-controls") ?? "");
    expect(panel).toHaveTextContent("Panel B");
    expect(panel).toHaveAttribute("role", "tabpanel");
    expect(panel).toHaveAttribute("aria-labelledby", b.id);
    expect(panel).toHaveAttribute("tabindex", "0");
  });

  it("hides unselected panels", () => {
    render(ui({ defaultValue: "a" }));
    expect(screen.getByText("Panel A")).not.toHaveAttribute("hidden");
    expect(screen.getByText("Panel B")).toHaveAttribute("hidden");
    expect(screen.getByText("Panel C")).toHaveAttribute("hidden");
  });

  it("gives every instance on a page distinct ids", () => {
    render(
      <>
        {ui({ defaultValue: "a" })}
        {ui({ defaultValue: "a" })}
      </>,
    );
    const ids = screen.getAllByRole("tab", { name: "A" }).map((element) => element.id);
    expect(new Set(ids).size).toBe(2);
  });
});

describe("Tabs selection", () => {
  it("selects defaultValue initially", () => {
    render(ui({ defaultValue: "b" }));
    expect(tab("B")).toHaveAttribute("aria-selected", "true");
    expect(tab("A")).toHaveAttribute("aria-selected", "false");
  });

  it("selects the first enabled tab when defaultValue is absent", () => {
    render(ui());
    expect(tab("A")).toHaveAttribute("aria-selected", "true");
  });

  it("lets value win over defaultValue", () => {
    render(ui({ value: "c", defaultValue: "a" }));
    expect(tab("C")).toHaveAttribute("aria-selected", "true");
    expect(tab("A")).toHaveAttribute("aria-selected", "false");
  });

  it("in controlled mode calls onValueChange but keeps the selection until the parent updates value", async () => {
    const user = userEvent.setup();
    const onValueChange = vi.fn();
    const { rerender } = render(ui({ value: "a", onValueChange }));

    await user.click(tab("B"));
    expect(onValueChange).toHaveBeenCalledTimes(1);
    expect(onValueChange).toHaveBeenCalledWith("b");
    expect(tab("A")).toHaveAttribute("aria-selected", "true");

    rerender(ui({ value: "b", onValueChange }));
    expect(tab("B")).toHaveAttribute("aria-selected", "true");
  });

  it("calls onValueChange in uncontrolled mode when a different tab is clicked", async () => {
    const user = userEvent.setup();
    const onValueChange = vi.fn();
    render(ui({ defaultValue: "a", onValueChange }));

    await user.click(tab("B"));
    expect(onValueChange).toHaveBeenCalledTimes(1);
    expect(onValueChange).toHaveBeenCalledWith("b");
    expect(tab("B")).toHaveAttribute("aria-selected", "true");
  });

  it("does not call onValueChange when the selected tab is re-selected", async () => {
    const user = userEvent.setup();
    const onValueChange = vi.fn();
    render(ui({ defaultValue: "a", onValueChange }));

    await user.click(tab("A"));
    expect(onValueChange).not.toHaveBeenCalled();
  });
});

describe("Tabs roving tabindex", () => {
  it("gives tabIndex 0 only to the selected tab", () => {
    render(ui({ defaultValue: "b" }));
    expect(tab("A")).toHaveAttribute("tabindex", "-1");
    expect(tab("B")).toHaveAttribute("tabindex", "0");
    expect(tab("C")).toHaveAttribute("tabindex", "-1");
  });

  it("gives tabIndex 0 to the first enabled tab when the selected value matches no tab", () => {
    render(ui({ value: "zzz" }));
    expect(tab("A")).toHaveAttribute("tabindex", "0");
    expect(tab("B")).toHaveAttribute("tabindex", "-1");
    expect(tab("C")).toHaveAttribute("tabindex", "-1");
  });
});

describe("Tabs keyboard", () => {
  it("ArrowRight moves focus to the next tab and selects it", async () => {
    const user = userEvent.setup();
    const onValueChange = vi.fn();
    render(ui({ defaultValue: "a", onValueChange }));

    await user.tab();
    expect(tab("A")).toHaveFocus();
    await user.keyboard("{ArrowRight}");
    expect(tab("B")).toHaveFocus();
    expect(tab("B")).toHaveAttribute("aria-selected", "true");
    expect(onValueChange).toHaveBeenCalledWith("b");
  });

  it("ArrowLeft and ArrowRight wrap around", async () => {
    const user = userEvent.setup();
    render(ui({ defaultValue: "a" }));

    await user.tab();
    await user.keyboard("{ArrowLeft}");
    expect(tab("C")).toHaveFocus();
    await user.keyboard("{ArrowRight}");
    expect(tab("A")).toHaveFocus();
  });

  it("skips disabled tabs", async () => {
    const user = userEvent.setup();
    render(ui({ defaultValue: "a", disabled: ["b"] }));

    await user.tab();
    await user.keyboard("{ArrowRight}");
    expect(tab("C")).toHaveFocus();
    expect(tab("B")).toHaveAttribute("aria-selected", "false");
  });

  it("Home and End jump to the first and last enabled tabs", async () => {
    const user = userEvent.setup();
    render(ui({ defaultValue: "b" }));

    await user.tab();
    await user.keyboard("{End}");
    expect(tab("C")).toHaveFocus();
    expect(tab("C")).toHaveAttribute("aria-selected", "true");
    await user.keyboard("{Home}");
    expect(tab("A")).toHaveFocus();
    expect(tab("A")).toHaveAttribute("aria-selected", "true");
  });

  it("calls preventDefault on handled keys and ignores other keys", async () => {
    const onValueChange = vi.fn();
    render(ui({ defaultValue: "a", onValueChange }));

    expect(fireEvent.keyDown(tab("A"), { key: "ArrowRight" })).toBe(false);
    expect(fireEvent.keyDown(tab("B"), { key: "x" })).toBe(true);
    expect(onValueChange).toHaveBeenCalledTimes(1);
    expect(onValueChange).toHaveBeenCalledWith("b");
  });
});

describe("Tabs disabled tabs", () => {
  it("renders a disabled tab that cannot be clicked into selection", async () => {
    const user = userEvent.setup();
    const onValueChange = vi.fn();
    render(ui({ defaultValue: "a", disabled: ["b"], onValueChange }));

    expect(tab("B")).toBeDisabled();
    await user.click(tab("B"));
    expect(tab("B")).toHaveAttribute("aria-selected", "false");
    expect(onValueChange).not.toHaveBeenCalled();
  });

  it("selects the first enabled tab when the first tab is disabled and defaultValue is absent", () => {
    render(ui({ disabled: ["a"] }));
    expect(tab("A")).toBeDisabled();
    expect(tab("B")).toHaveAttribute("aria-selected", "true");
    expect(tab("B")).toHaveAttribute("tabindex", "0");
  });

  it("keeps arrow navigation on the only enabled tab", async () => {
    const user = userEvent.setup();
    const onValueChange = vi.fn();
    render(ui({ disabled: ["a", "c"], onValueChange }));

    await user.tab();
    expect(tab("B")).toHaveFocus();
    await user.keyboard("{ArrowRight}");
    expect(tab("B")).toHaveFocus();
    await user.keyboard("{ArrowLeft}{Home}{End}");
    expect(tab("B")).toHaveFocus();
    expect(onValueChange).not.toHaveBeenCalled();
  });

  it("moves focus but keeps the controlled selection when the parent never updates value", async () => {
    const user = userEvent.setup();
    const onValueChange = vi.fn();
    render(ui({ value: "a", onValueChange }));

    await user.tab();
    await user.keyboard("{ArrowRight}");
    expect(tab("B")).toHaveFocus();
    expect(onValueChange).toHaveBeenCalledWith("b");
    expect(tab("A")).toHaveAttribute("aria-selected", "true");
  });
});

// Owns its tab, so removing it re-renders only this component, not <Tabs>.
function RemovableTab({ value }: { value: string }) {
  const [shown, setShown] = useState(true);
  return (
    <>
      <button onClick={() => setShown(false)}>Remove {value}</button>
      {shown ? <Tab value={value}>{value.toUpperCase()}</Tab> : null}
    </>
  );
}

// Adds its tab after mount, without re-rendering <Tabs>.
function LateTab({ value }: { value: string }) {
  const [shown, setShown] = useState(false);
  return (
    <>
      <button onClick={() => setShown(true)}>Add {value}</button>
      {shown ? <Tab value={value}>{value.toUpperCase()}</Tab> : null}
    </>
  );
}

describe("Tabs fallback selection", () => {
  it("selects the first enabled tab when a child removes the selected tab", async () => {
    const user = userEvent.setup();
    render(
      <Tabs defaultValue="b">
        <TabList aria-label="Sections">
          <Tab value="a">A</Tab>
          <RemovableTab value="b" />
          <Tab value="c">C</Tab>
        </TabList>
      </Tabs>,
    );
    await user.click(screen.getByRole("button", { name: "Remove b" }));
    expect(screen.queryByRole("tab", { name: "B" })).toBeNull();
    expect(tab("A")).toHaveAttribute("aria-selected", "true");
    expect(tab("A")).toHaveAttribute("tabindex", "0");
    expect(tab("C")).toHaveAttribute("tabindex", "-1");
    expect(screen.getAllByRole("tab").filter((item) => item.tabIndex === 0)).toHaveLength(1);
  });

  it("selects the first tab added after mount when there is no defaultValue", async () => {
    const user = userEvent.setup();
    render(
      <Tabs>
        <TabList aria-label="Sections">
          <LateTab value="a" />
          <Tab value="b">B</Tab>
        </TabList>
      </Tabs>,
    );
    expect(tab("B")).toHaveAttribute("aria-selected", "true");
    await user.click(screen.getByRole("button", { name: "Add a" }));
    expect(tab("A")).toHaveAttribute("aria-selected", "true");
    expect(tab("A")).toHaveAttribute("tabindex", "0");
    expect(tab("B")).toHaveAttribute("tabindex", "-1");
  });
});

describe("Tabs forwarding", () => {
  it("forwards className and HTML props to each component's root element", () => {
    render(
      <Tabs className="tabs" data-testid="root" defaultValue="a">
        <TabList aria-label="Sections" className="list" data-testid="list">
          <Tab value="a" className="tab" data-testid="tab">
            A
          </Tab>
        </TabList>
        <TabPanel value="a" className="panel" data-testid="panel">
          Panel A
        </TabPanel>
      </Tabs>,
    );
    expect(screen.getByTestId("root")).toHaveClass("tabs");
    expect(screen.getByTestId("list")).toHaveClass("list");
    expect(screen.getByTestId("tab")).toHaveClass("tab");
    expect(screen.getByTestId("tab")).toHaveAttribute("type", "button");
    expect(screen.getByTestId("panel")).toHaveClass("panel");
  });
});

import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useId,
  useLayoutEffect,
  useRef,
  useState,
  type ButtonHTMLAttributes,
  type HTMLAttributes,
  type KeyboardEvent,
  type RefObject,
} from "react";

export type TabsProps = Omit<HTMLAttributes<HTMLDivElement>, "defaultValue"> & {
  defaultValue?: string;
  value?: string;
  onValueChange?: (value: string) => void;
};

export type TabListProps = HTMLAttributes<HTMLDivElement>;

export type TabProps = Omit<ButtonHTMLAttributes<HTMLButtonElement>, "value"> & {
  value: string;
  disabled?: boolean;
};

export type TabPanelProps = HTMLAttributes<HTMLDivElement> & {
  value: string;
};

type TabsContextValue = {
  baseId: string;
  selected: string | undefined;
  enabledValues: string[];
  listRef: RefObject<HTMLDivElement | null>;
  select: (value: string) => void;
  syncEnabled: () => void;
};

const TabsContext = createContext<TabsContextValue | null>(null);

function useTabsContext(): TabsContextValue {
  const context = useContext(TabsContext);
  if (!context) {
    throw new Error("Tab, TabList and TabPanel must be rendered inside <Tabs>");
  }
  return context;
}

// URI-encoding keeps ids unique and free of spaces or slashes for any value.
const tabId = (baseId: string, value: string) => `${baseId}-tab-${encodeURIComponent(value)}`;
const panelId = (baseId: string, value: string) => `${baseId}-panel-${encodeURIComponent(value)}`;

const ENABLED_TABS = '[role="tab"]:not(:disabled)';

function enabledTabs(list: HTMLElement | null): HTMLElement[] {
  return Array.from(list?.querySelectorAll<HTMLElement>(ENABLED_TABS) ?? []);
}

export function Tabs({ defaultValue, value, onValueChange, children, ...rest }: TabsProps) {
  const baseId = useId();
  const listRef = useRef<HTMLDivElement | null>(null);
  const [internalValue, setInternalValue] = useState(defaultValue);
  const [enabledValues, setEnabledValues] = useState<string[]>([]);
  const selected = value ?? internalValue ?? enabledValues[0];

  // Keeps the enabled tab values in DOM order so the roving tabindex and the
  // arrow keys follow the rendered order, including tabs added or removed later.
  const syncEnabled = useCallback(() => {
    const values = enabledTabs(listRef.current).map((tab) => tab.dataset.value ?? "");
    setEnabledValues((previous) =>
      JSON.stringify(previous) === JSON.stringify(values) ? previous : values,
    );
  }, []);

  const select = (next: string) => {
    if (next === selected) return;
    if (value === undefined) setInternalValue(next);
    onValueChange?.(next);
  };

  const context: TabsContextValue = { baseId, selected, enabledValues, listRef, select, syncEnabled };

  return (
    <TabsContext.Provider value={context}>
      <div {...rest}>{children}</div>
    </TabsContext.Provider>
  );
}

export function TabList({ onKeyDown, ...rest }: TabListProps) {
  const { listRef, select, syncEnabled } = useTabsContext();

  useLayoutEffect(() => {
    syncEnabled();
  });

  function handleKeyDown(event: KeyboardEvent<HTMLDivElement>) {
    onKeyDown?.(event);
    const tabs = enabledTabs(listRef.current);
    const index = tabs.indexOf(event.target as HTMLElement);
    if (index === -1) return;

    let nextIndex: number;
    switch (event.key) {
      case "ArrowRight":
        nextIndex = (index + 1) % tabs.length;
        break;
      case "ArrowLeft":
        nextIndex = (index - 1 + tabs.length) % tabs.length;
        break;
      case "Home":
        nextIndex = 0;
        break;
      case "End":
        nextIndex = tabs.length - 1;
        break;
      default:
        return;
    }

    event.preventDefault();
    const next = tabs[nextIndex];
    next.focus();
    select(next.dataset.value ?? "");
  }

  return (
    <div {...rest} role="tablist" aria-orientation="horizontal" ref={listRef} onKeyDown={handleKeyDown} />
  );
}

export function Tab({ value, disabled = false, onClick, ...rest }: TabProps) {
  const { baseId, selected, enabledValues, select, syncEnabled } = useTabsContext();

  useLayoutEffect(() => {
    syncEnabled();
  });

  // A tab that unmounts must drop out of the enabled list too.
  useEffect(() => () => syncEnabled(), [syncEnabled]);

  const isSelected = value === selected;
  const focusValue = selected !== undefined && enabledValues.includes(selected) ? selected : enabledValues[0];

  return (
    <button
      {...rest}
      type="button"
      role="tab"
      id={tabId(baseId, value)}
      aria-selected={isSelected}
      aria-controls={panelId(baseId, value)}
      tabIndex={value === focusValue ? 0 : -1}
      disabled={disabled}
      data-value={value}
      onClick={(event) => {
        onClick?.(event);
        select(value);
      }}
    />
  );
}

export function TabPanel({ value, ...rest }: TabPanelProps) {
  const { baseId, selected } = useTabsContext();

  return (
    <div
      {...rest}
      role="tabpanel"
      id={panelId(baseId, value)}
      aria-labelledby={tabId(baseId, value)}
      tabIndex={0}
      hidden={value !== selected}
    />
  );
}

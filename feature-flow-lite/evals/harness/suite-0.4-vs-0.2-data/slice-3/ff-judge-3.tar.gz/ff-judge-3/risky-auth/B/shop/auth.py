"""Password-reset tokens (in-memory store)."""

import secrets
import time

TOKEN_TTL_SECONDS = 1800  # 30 minutes

_TOKENS = {}  # token -> {"username", "issued_at", "used"}


class InvalidToken(Exception):
    pass


class TokenExpired(InvalidToken):
    pass


class TokenUsed(InvalidToken):
    pass


def issue_reset_token(username, now=None):
    """Create a reset token for username, issued at now (Unix seconds)."""
    if now is None:
        now = time.time()
    token = secrets.token_urlsafe(16)
    _TOKENS[token] = {"username": username, "issued_at": now, "used": False}
    return token


def redeem_reset_token(token, now=None):
    """Return the username a token was issued for, consuming the token.

    Raises InvalidToken for unknown tokens, TokenUsed if the token was already
    redeemed, and TokenExpired if more than TOKEN_TTL_SECONDS have passed
    since it was issued.
    """
    if now is None:
        now = time.time()
    entry = _TOKENS.get(token)
    if entry is None:
        raise InvalidToken("unknown token")
    if entry["used"]:
        raise TokenUsed("token already used")
    if now - entry["issued_at"] > TOKEN_TTL_SECONDS:
        raise TokenExpired("token expired")
    entry["used"] = True
    return entry["username"]

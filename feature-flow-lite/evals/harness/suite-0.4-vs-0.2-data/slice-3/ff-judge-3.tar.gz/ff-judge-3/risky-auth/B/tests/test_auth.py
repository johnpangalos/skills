import unittest

from shop.auth import (
    InvalidToken,
    TokenExpired,
    TokenUsed,
    issue_reset_token,
    redeem_reset_token,
)


class ResetTokenTest(unittest.TestCase):
    def test_round_trip(self):
        token = issue_reset_token("ada")
        self.assertEqual(redeem_reset_token(token), "ada")

    def test_unknown_token(self):
        with self.assertRaises(InvalidToken):
            redeem_reset_token("not-a-token")


class ResetTokenLifetimeTest(unittest.TestCase):
    def test_redeem_at_exactly_ttl_is_allowed(self):
        token = issue_reset_token("ada", now=1000)
        self.assertEqual(redeem_reset_token(token, now=1000 + 1800), "ada")

    def test_redeem_after_ttl_raises_expired(self):
        token = issue_reset_token("ada", now=1000)
        with self.assertRaises(TokenExpired):
            redeem_reset_token(token, now=1000 + 1800.001)

    def test_second_redeem_raises_used(self):
        token = issue_reset_token("ada", now=1000)
        redeem_reset_token(token, now=1001)
        with self.assertRaises(TokenUsed):
            redeem_reset_token(token, now=1002)

    def test_expired_attempt_does_not_consume_or_revive(self):
        token = issue_reset_token("ada", now=1000)
        for _ in range(2):
            with self.assertRaises(TokenExpired):
                redeem_reset_token(token, now=5000)

    def test_errors_subclass_invalid_token(self):
        self.assertTrue(issubclass(TokenExpired, InvalidToken))
        self.assertTrue(issubclass(TokenUsed, InvalidToken))

    def test_now_defaults_to_current_time(self):
        token = issue_reset_token("ada")
        self.assertEqual(redeem_reset_token(token), "ada")
        with self.assertRaises(TokenUsed):
            redeem_reset_token(token)

    def test_tokens_are_independent(self):
        a = issue_reset_token("ada", now=0)
        b = issue_reset_token("bob", now=0)
        self.assertEqual(redeem_reset_token(a, now=1), "ada")
        self.assertEqual(redeem_reset_token(b, now=1), "bob")

    def test_used_token_reports_used_even_after_ttl(self):
        token = issue_reset_token("ada", now=1000)
        redeem_reset_token(token, now=1001)
        with self.assertRaises(TokenUsed):
            redeem_reset_token(token, now=1000 + 1801)

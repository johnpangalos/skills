"""Password-reset tokens (in-memory store)."""

import secrets
import threading
import time

RESET_TOKEN_TTL = 1800  # seconds

_TOKENS = {}  # token -> {"username", "issued_at", "used"}
_LOCK = threading.Lock()


class InvalidToken(Exception):
    pass


class TokenExpired(InvalidToken):
    pass


class TokenUsed(InvalidToken):
    pass


def issue_reset_token(username, now=None):
    """Create a reset token for username, valid for RESET_TOKEN_TTL seconds."""
    if now is None:
        now = time.time()
    token = secrets.token_urlsafe(16)
    _TOKENS[token] = {"username": username, "issued_at": now, "used": False}
    return token


def redeem_reset_token(token, now=None):
    """Return the username a token was issued for and mark the token used."""
    if now is None:
        now = time.time()
    with _LOCK:
        entry = _TOKENS.get(token)
        if entry is None:
            raise InvalidToken("unknown token")
        if entry["used"]:
            raise TokenUsed("token already used")
        # Written as "not <=" so a NaN timestamp counts as expired.
        if not now - entry["issued_at"] <= RESET_TOKEN_TTL:
            raise TokenExpired("token expired")
        entry["used"] = True
        return entry["username"]

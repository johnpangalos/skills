import unittest
from unittest import mock

from shop.auth import (
    InvalidToken,
    TokenExpired,
    TokenUsed,
    issue_reset_token,
    redeem_reset_token,
)


class ResetTokenTest(unittest.TestCase):
    def test_round_trip(self):
        token = issue_reset_token("ada")
        self.assertEqual(redeem_reset_token(token), "ada")

    def test_unknown_token(self):
        with self.assertRaises(InvalidToken):
            redeem_reset_token("not-a-token")

    def test_unknown_token_is_plain_invalid_token(self):
        with self.assertRaises(InvalidToken) as ctx:
            redeem_reset_token("not-a-token", now=0)
        self.assertIs(type(ctx.exception), InvalidToken)
        self.assertEqual(str(ctx.exception), "unknown token")

    def test_empty_and_none_tokens_are_invalid(self):
        for bad in ("", None):
            with self.subTest(token=bad):
                with self.assertRaises(InvalidToken) as ctx:
                    redeem_reset_token(bad, now=0)
                self.assertIs(type(ctx.exception), InvalidToken)

    def test_exactly_ttl_is_valid(self):
        token = issue_reset_token("ada", now=1000)
        self.assertEqual(redeem_reset_token(token, now=2800), "ada")

    def test_one_second_past_ttl_is_expired(self):
        token = issue_reset_token("ada", now=1000)
        with self.assertRaises(TokenExpired):
            redeem_reset_token(token, now=2801)

    def test_fractional_past_ttl_is_expired(self):
        for late in (2800.001, 2800.5):
            with self.subTest(now=late):
                token = issue_reset_token("ada", now=1000)
                with self.assertRaises(TokenExpired):
                    redeem_reset_token(token, now=late)

    def test_issued_at_zero_is_a_real_timestamp(self):
        ok = issue_reset_token("ada", now=0)
        self.assertEqual(redeem_reset_token(ok, now=1800), "ada")
        late = issue_reset_token("ada", now=0)
        with self.assertRaises(TokenExpired):
            redeem_reset_token(late, now=1801)

    def test_reuse_raises_token_used(self):
        token = issue_reset_token("ada", now=1000)
        self.assertEqual(redeem_reset_token(token, now=1000), "ada")
        with self.assertRaises(TokenUsed):
            redeem_reset_token(token, now=1000)

    def test_reuse_after_expiry_window_is_token_used(self):
        token = issue_reset_token("ada", now=1000)
        redeem_reset_token(token, now=1500)
        with self.assertRaises(TokenUsed):
            redeem_reset_token(token, now=2801)

    def test_expired_redeemed_twice_stays_expired(self):
        token = issue_reset_token("ada", now=1000)
        with self.assertRaises(TokenExpired):
            redeem_reset_token(token, now=2801)
        with self.assertRaises(TokenExpired) as ctx:
            redeem_reset_token(token, now=2801)
        self.assertIs(type(ctx.exception), TokenExpired)

    def test_failed_redeem_does_not_affect_other_tokens(self):
        expired = issue_reset_token("ada", now=0)
        fresh = issue_reset_token("ada", now=1000)
        with self.assertRaises(TokenExpired):
            redeem_reset_token(expired, now=1801)
        self.assertEqual(redeem_reset_token(fresh, now=1801), "ada")

    def test_clock_skew_before_issue_is_not_expired(self):
        token = issue_reset_token("ada", now=1000)
        self.assertEqual(redeem_reset_token(token, now=500), "ada")

    def test_subclasses_of_invalid_token(self):
        self.assertTrue(issubclass(TokenExpired, InvalidToken))
        self.assertTrue(issubclass(TokenUsed, InvalidToken))

    def test_issued_and_redeemed_at_zero_succeeds(self):
        token = issue_reset_token("ada", now=0)
        self.assertEqual(redeem_reset_token(token, now=0), "ada")

    def test_clock_skew_far_before_issue_is_not_expired(self):
        token = issue_reset_token("ada", now=5000)
        self.assertEqual(redeem_reset_token(token, now=1000), "ada")

    def test_nan_now_at_redeem_is_expired(self):
        token = issue_reset_token("ada", now=1000)
        with self.assertRaises(TokenExpired):
            redeem_reset_token(token, now=float("nan"))

    def test_nan_issued_at_is_expired_on_redeem(self):
        token = issue_reset_token("ada", now=float("nan"))
        with self.assertRaises(TokenExpired):
            redeem_reset_token(token, now=1000)

    def test_default_now_is_evaluated_at_call_time(self):
        with mock.patch("shop.auth.time.time", return_value=1000.0):
            token = issue_reset_token("ada")
        with mock.patch("shop.auth.time.time", return_value=2801.0):
            with self.assertRaises(TokenExpired):
                redeem_reset_token(token)

    def test_default_now_redeems_within_ttl_at_later_time(self):
        with mock.patch("shop.auth.time.time", return_value=1000.0):
            token = issue_reset_token("ada")
        with mock.patch("shop.auth.time.time", return_value=1500.0):
            self.assertEqual(redeem_reset_token(token), "ada")

"""Password-reset tokens (in-memory store)."""

import secrets
import time

TOKEN_LIFETIME_SECONDS = 1800

_TOKENS = {}  # token -> {"username", "issued_at", "used"}


class InvalidToken(Exception):
    pass


class TokenExpired(InvalidToken):
    pass


class TokenUsed(InvalidToken):
    pass


def issue_reset_token(username, now=None):
    """Create a reset token for username, issued at now (Unix seconds)."""
    if now is None:
        now = time.time()
    token = secrets.token_urlsafe(16)
    _TOKENS[token] = {"username": username, "issued_at": now, "used": False}
    return token


def redeem_reset_token(token, now=None):
    """Return the username a token was issued for, consuming the token.

    Raises TokenUsed if the token was already redeemed (checked first), and
    TokenExpired if more than TOKEN_LIFETIME_SECONDS passed since issue.
    A failed redeem leaves the token unchanged.
    """
    if now is None:
        now = time.time()
    record = _TOKENS.get(token)
    if record is None:
        raise InvalidToken("unknown token")
    if record["used"]:
        raise TokenUsed("token already used")
    if now - record["issued_at"] > TOKEN_LIFETIME_SECONDS:
        raise TokenExpired("token expired")
    record["used"] = True
    return record["username"]

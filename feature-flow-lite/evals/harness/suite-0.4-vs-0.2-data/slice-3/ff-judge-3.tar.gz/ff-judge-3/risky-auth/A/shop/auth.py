"""Password-reset tokens (in-memory store).

Tokens expire TOKEN_TTL seconds after they are issued and are single-use.
"""

import secrets
import threading
import time

TOKEN_TTL = 1800  # seconds (30 minutes)

_TOKENS = {}  # token -> {"username": str, "issued_at": float, "used": bool}
_LOCK = threading.Lock()


class InvalidToken(Exception):
    pass


class TokenExpired(InvalidToken):
    pass


class TokenUsed(InvalidToken):
    pass


def issue_reset_token(username, now=None):
    """Create a reset token for username, issued at now (Unix seconds)."""
    if now is None:
        now = time.time()
    token = secrets.token_urlsafe(16)
    with _LOCK:
        _TOKENS[token] = {"username": username, "issued_at": now, "used": False}
    return token


def redeem_reset_token(token, now=None):
    """Return the username a token was issued for and mark it used.

    Raises InvalidToken for unknown tokens, TokenUsed if it was already
    redeemed, and TokenExpired if redeemed more than TOKEN_TTL seconds
    after it was issued.
    """
    if now is None:
        now = time.time()
    with _LOCK:
        entry = _TOKENS.get(token)
        if entry is None:
            raise InvalidToken("unknown token")
        if entry["used"]:
            raise TokenUsed("token already used")
        if now - entry["issued_at"] > TOKEN_TTL:
            raise TokenExpired("token expired")
        entry["used"] = True
        return entry["username"]

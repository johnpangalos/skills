import unittest

from shop.auth import (
    RESET_TOKEN_TTL,
    InvalidToken,
    TokenExpired,
    TokenUsed,
    issue_reset_token,
    redeem_reset_token,
)


class ResetTokenTest(unittest.TestCase):
    def test_round_trip(self):
        token = issue_reset_token("ada")
        self.assertEqual(redeem_reset_token(token), "ada")

    def test_unknown_token(self):
        with self.assertRaises(InvalidToken):
            redeem_reset_token("not-a-token")


class ResetTokenLifetimeTest(unittest.TestCase):
    def test_redeem_at_exact_ttl_succeeds(self):
        token = issue_reset_token("ada", now=1000)
        self.assertEqual(redeem_reset_token(token, now=1000 + RESET_TOKEN_TTL), "ada")

    def test_redeem_one_second_past_ttl_expires(self):
        token = issue_reset_token("ada", now=1000)
        with self.assertRaises(TokenExpired) as cm:
            redeem_reset_token(token, now=1000 + RESET_TOKEN_TTL + 1)
        self.assertEqual(str(cm.exception), "token expired")

    def test_float_timestamp_past_ttl_expires(self):
        token = issue_reset_token("ada", now=1000)
        with self.assertRaises(TokenExpired):
            redeem_reset_token(token, now=1000 + RESET_TOKEN_TTL + 0.5)

    def test_second_redeem_raises_used(self):
        token = issue_reset_token("ada", now=1000)
        self.assertEqual(redeem_reset_token(token, now=1000), "ada")
        with self.assertRaises(TokenUsed) as cm:
            redeem_reset_token(token, now=1001)
        self.assertEqual(str(cm.exception), "token already used")

    def test_used_then_expired_raises_used(self):
        token = issue_reset_token("ada", now=1000)
        redeem_reset_token(token, now=1000)
        with self.assertRaises(TokenUsed):
            redeem_reset_token(token, now=1000 + 10 * RESET_TOKEN_TTL)

    def test_expired_attempt_does_not_consume(self):
        token = issue_reset_token("ada", now=1000)
        with self.assertRaises(TokenExpired):
            redeem_reset_token(token, now=1000 + RESET_TOKEN_TTL + 1)
        with self.assertRaises(TokenExpired):
            redeem_reset_token(token, now=1000 + RESET_TOKEN_TTL + 2)

    def test_expired_and_used_are_invalid_token(self):
        self.assertTrue(issubclass(TokenExpired, InvalidToken))
        self.assertTrue(issubclass(TokenUsed, InvalidToken))
        token = issue_reset_token("ada", now=1000)
        with self.assertRaises(InvalidToken):
            redeem_reset_token(token, now=1000 + RESET_TOKEN_TTL + 1)
        token = issue_reset_token("ada", now=1000)
        redeem_reset_token(token, now=1000)
        with self.assertRaises(InvalidToken):
            redeem_reset_token(token, now=1000)

    def test_empty_and_none_tokens_are_unknown(self):
        for bad in ("", None):
            with self.assertRaises(InvalidToken) as cm:
                redeem_reset_token(bad)
            self.assertIs(type(cm.exception), InvalidToken)
            self.assertEqual(str(cm.exception), "unknown token")

    def test_issue_at_zero_is_honored(self):
        token = issue_reset_token("ada", now=0)
        self.assertEqual(redeem_reset_token(token, now=RESET_TOKEN_TTL), "ada")
        other = issue_reset_token("ada", now=0)
        with self.assertRaises(TokenExpired):
            redeem_reset_token(other, now=RESET_TOKEN_TTL + 1)

    def test_nan_timestamp_counts_as_expired(self):
        token = issue_reset_token("ada", now=1000)
        with self.assertRaises(TokenExpired):
            redeem_reset_token(token, now=float("nan"))
        token = issue_reset_token("ada", now=float("nan"))
        with self.assertRaises(TokenExpired):
            redeem_reset_token(token, now=1000)

    def test_redeem_before_issue_is_accepted(self):
        token = issue_reset_token("ada", now=1000)
        self.assertEqual(redeem_reset_token(token, now=500), "ada")

    def test_two_tokens_same_user_are_independent(self):
        first = issue_reset_token("ada", now=1000)
        second = issue_reset_token("ada", now=1000)
        self.assertNotEqual(first, second)
        self.assertEqual(redeem_reset_token(first, now=1000), "ada")
        self.assertEqual(redeem_reset_token(second, now=1000), "ada")
        with self.assertRaises(TokenUsed):
            redeem_reset_token(first, now=1000)

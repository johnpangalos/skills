import time
import unittest

from shop.auth import (
    InvalidToken,
    TokenExpired,
    TokenUsed,
    issue_reset_token,
    redeem_reset_token,
)


class ResetTokenTest(unittest.TestCase):
    def test_round_trip(self):
        token = issue_reset_token("ada")
        self.assertEqual(redeem_reset_token(token), "ada")

    def test_unknown_token(self):
        with self.assertRaises(InvalidToken):
            redeem_reset_token("not-a-token")

    def test_single_use(self):
        token = issue_reset_token("ada", now=1000)
        self.assertEqual(redeem_reset_token(token, now=1001), "ada")
        with self.assertRaises(TokenUsed):
            redeem_reset_token(token, now=1002)

    def test_second_redeem_after_expiry_is_used(self):
        token = issue_reset_token("ada", now=1000)
        redeem_reset_token(token, now=1001)
        with self.assertRaises(TokenUsed):
            redeem_reset_token(token, now=1000 + 86400)

    def test_valid_at_exactly_ttl(self):
        token = issue_reset_token("ada", now=1000)
        self.assertEqual(redeem_reset_token(token, now=2800), "ada")

    def test_expired_after_ttl(self):
        token = issue_reset_token("ada", now=1000)
        with self.assertRaises(TokenExpired):
            redeem_reset_token(token, now=2800.001)
        with self.assertRaises(TokenExpired):
            redeem_reset_token(token, now=1000 + 86400)

    def test_now_zero_is_honoured(self):
        token = issue_reset_token("ada", now=0)
        with self.assertRaises(TokenExpired):
            redeem_reset_token(token, now=1801)

    def test_defaults_to_current_time(self):
        token = issue_reset_token("ada")
        with self.assertRaises(TokenExpired):
            redeem_reset_token(token, now=time.time() + 1801)
        token = issue_reset_token("bob", now=time.time() - 1801)
        with self.assertRaises(TokenExpired):
            redeem_reset_token(token)

    def test_unknown_token_is_not_a_subclass_error(self):
        with self.assertRaises(InvalidToken) as ctx:
            redeem_reset_token("nope")
        self.assertIs(type(ctx.exception), InvalidToken)

    def test_subclasses(self):
        self.assertTrue(issubclass(TokenExpired, InvalidToken))
        self.assertTrue(issubclass(TokenUsed, InvalidToken))

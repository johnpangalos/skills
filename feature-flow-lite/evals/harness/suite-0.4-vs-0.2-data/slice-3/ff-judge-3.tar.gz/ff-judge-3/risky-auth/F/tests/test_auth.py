import unittest
from unittest.mock import patch

from shop.auth import (
    InvalidToken,
    TokenExpired,
    TokenUsed,
    issue_reset_token,
    redeem_reset_token,
)


class ResetTokenTest(unittest.TestCase):
    def test_round_trip(self):
        token = issue_reset_token("ada")
        self.assertEqual(redeem_reset_token(token), "ada")

    def test_unknown_token(self):
        with self.assertRaises(InvalidToken) as cm:
            redeem_reset_token("not-a-token")
        self.assertIs(type(cm.exception), InvalidToken)
        self.assertEqual(str(cm.exception), "unknown token")

    def test_empty_string_token_is_unknown(self):
        with self.assertRaises(InvalidToken) as cm:
            redeem_reset_token("")
        self.assertIs(type(cm.exception), InvalidToken)

    def test_none_token_is_unknown(self):
        with self.assertRaises(InvalidToken) as cm:
            redeem_reset_token(None)
        self.assertIs(type(cm.exception), InvalidToken)

    def test_redeem_within_lifetime(self):
        token = issue_reset_token("ada", now=1000.0)
        self.assertEqual(redeem_reset_token(token, now=2000.0), "ada")

    def test_redeem_at_exactly_1800_seconds_is_valid(self):
        token = issue_reset_token("ada", now=1000.0)
        self.assertEqual(redeem_reset_token(token, now=2800.0), "ada")

    def test_redeem_after_1800_seconds_is_expired(self):
        token = issue_reset_token("ada", now=1000.0)
        with self.assertRaises(TokenExpired):
            redeem_reset_token(token, now=2800.5)

    def test_fractional_seconds_are_honored(self):
        token = issue_reset_token("ada", now=1000.25)
        self.assertEqual(redeem_reset_token(token, now=2800.25), "ada")
        token = issue_reset_token("bob", now=1000.25)
        with self.assertRaises(TokenExpired):
            redeem_reset_token(token, now=2800.26)

    def test_now_defaults_to_time_time_at_call_time(self):
        with patch("shop.auth.time.time", return_value=1000.0):
            token = issue_reset_token("ada")
        with patch("shop.auth.time.time", return_value=2800.0):
            self.assertEqual(redeem_reset_token(token), "ada")
        with patch("shop.auth.time.time", return_value=1000.0):
            token = issue_reset_token("bob")
        with patch("shop.auth.time.time", return_value=2800.5):
            with self.assertRaises(TokenExpired):
                redeem_reset_token(token)

    def test_second_redeem_raises_token_used(self):
        token = issue_reset_token("ada", now=1000.0)
        self.assertEqual(redeem_reset_token(token, now=1001.0), "ada")
        with self.assertRaises(TokenUsed):
            redeem_reset_token(token, now=1002.0)

    def test_used_takes_precedence_over_expiry(self):
        token = issue_reset_token("ada", now=0.0)
        self.assertEqual(redeem_reset_token(token, now=100.0), "ada")
        with self.assertRaises(TokenUsed):
            redeem_reset_token(token, now=5000.0)

    def test_expired_redeem_does_not_consume_token(self):
        token = issue_reset_token("ada", now=0.0)
        with self.assertRaises(TokenExpired):
            redeem_reset_token(token, now=2000.0)
        with self.assertRaises(TokenExpired):
            redeem_reset_token(token, now=2001.0)

    def test_token_expired_and_used_are_invalid_token(self):
        self.assertTrue(issubclass(TokenExpired, InvalidToken))
        self.assertTrue(issubclass(TokenUsed, InvalidToken))

    def test_except_invalid_token_catches_all_failures(self):
        expired = issue_reset_token("ada", now=0.0)
        used = issue_reset_token("bob", now=0.0)
        redeem_reset_token(used, now=1.0)
        for token, now in ((expired, 2000.0), (used, 2.0), ("nope", 2.0)):
            with self.subTest(token=token):
                with self.assertRaises(InvalidToken):
                    redeem_reset_token(token, now=now)

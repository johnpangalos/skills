import unittest

from shop.auth import (
    InvalidToken,
    TokenExpired,
    TokenUsed,
    issue_reset_token,
    redeem_reset_token,
)


class ResetTokenTest(unittest.TestCase):
    def test_round_trip(self):
        token = issue_reset_token("ada")
        self.assertEqual(redeem_reset_token(token), "ada")

    def test_unknown_token(self):
        with self.assertRaises(InvalidToken):
            redeem_reset_token("not-a-token")

    def test_unknown_tokens_raise_plain_invalid_token(self):
        for token in ("", None, "never-issued"):
            with self.subTest(token=token):
                with self.assertRaises(InvalidToken) as cm:
                    redeem_reset_token(token, now=1000)
                self.assertIs(type(cm.exception), InvalidToken)
                self.assertEqual(str(cm.exception), "unknown token")

    def test_zero_now_is_honored(self):
        token = issue_reset_token("ada", now=0)
        self.assertEqual(redeem_reset_token(token, now=1800), "ada")

    def test_redeem_past_lifetime_raises_expired(self):
        token = issue_reset_token("ada", now=0)
        with self.assertRaises(TokenExpired) as cm:
            redeem_reset_token(token, now=1801)
        self.assertEqual(str(cm.exception), "token expired")

    def test_exactly_lifetime_after_issue_succeeds(self):
        token = issue_reset_token("ada", now=1000)
        self.assertEqual(redeem_reset_token(token, now=2800), "ada")

    def test_fractions_just_past_lifetime_raise_expired(self):
        for now in (2800.5, 2800.001):
            with self.subTest(now=now):
                token = issue_reset_token("ada", now=1000)
                with self.assertRaises(TokenExpired):
                    redeem_reset_token(token, now=now)

    def test_redeem_before_issue_time_does_not_expire(self):
        token = issue_reset_token("ada", now=1000)
        self.assertEqual(redeem_reset_token(token, now=0), "ada")

    def test_second_redeem_raises_used(self):
        token = issue_reset_token("ada", now=1000)
        redeem_reset_token(token, now=1000)
        with self.assertRaises(TokenUsed) as cm:
            redeem_reset_token(token, now=1001)
        self.assertEqual(str(cm.exception), "token already used")

    def test_used_takes_precedence_over_expired(self):
        token = issue_reset_token("ada", now=1000)
        redeem_reset_token(token, now=1000)
        with self.assertRaises(TokenUsed):
            redeem_reset_token(token, now=5000)

    def test_expired_redeem_repeats_expired(self):
        token = issue_reset_token("ada", now=0)
        for _ in range(2):
            with self.assertRaises(TokenExpired):
                redeem_reset_token(token, now=1801)

    def test_failed_redeem_does_not_mark_token_used(self):
        token = issue_reset_token("ada", now=0)
        with self.assertRaises(TokenExpired):
            redeem_reset_token(token, now=1801)
        self.assertEqual(redeem_reset_token(token, now=0), "ada")

    def test_token_errors_are_invalid_token(self):
        self.assertTrue(issubclass(TokenExpired, InvalidToken))
        self.assertTrue(issubclass(TokenUsed, InvalidToken))

    def test_tokens_for_same_user_are_independent_on_use(self):
        first = issue_reset_token("ada", now=1000)
        second = issue_reset_token("ada", now=1000)
        self.assertEqual(redeem_reset_token(first, now=1000), "ada")
        self.assertEqual(redeem_reset_token(second, now=1000), "ada")

    def test_tokens_for_same_user_are_independent_on_expiry(self):
        old = issue_reset_token("ada", now=0)
        recent = issue_reset_token("ada", now=1000)
        with self.assertRaises(TokenExpired):
            redeem_reset_token(old, now=1801)
        self.assertEqual(redeem_reset_token(recent, now=1801), "ada")

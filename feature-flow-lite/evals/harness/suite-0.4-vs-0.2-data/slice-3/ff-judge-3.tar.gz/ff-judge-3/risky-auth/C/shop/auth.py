"""Password-reset tokens (in-memory store)."""

import secrets
import time

TOKEN_TTL = 1800  # seconds a reset token stays redeemable after issue

_TOKENS = {}  # token -> (username, issued_at)
_USED = set()  # tokens that have been redeemed successfully


class InvalidToken(Exception):
    pass


class TokenExpired(InvalidToken):
    pass


class TokenUsed(InvalidToken):
    pass


def issue_reset_token(username, now=None):
    """Create a reset token for username."""
    if now is None:
        now = time.time()
    token = secrets.token_urlsafe(16)
    _TOKENS[token] = (username, now)
    return token


def redeem_reset_token(token, now=None):
    """Return the username a token was issued for; each token works once."""
    if now is None:
        now = time.time()
    record = _TOKENS.get(token)
    if record is None:
        raise InvalidToken("unknown token")
    username, issued_at = record
    if token in _USED:
        raise TokenUsed("token already used")
    # Written as "not <=" so a NaN now or issued_at counts as expired.
    if not now - issued_at <= TOKEN_TTL:
        raise TokenExpired("token expired")
    _USED.add(token)
    return username

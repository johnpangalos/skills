/*
 * Copyright 2020 Adobe. All rights reserved.
 * This file is licensed to you under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License. You may obtain a copy
 * of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software distributed under
 * the License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR REPRESENTATIONS
 * OF ANY KIND, either express or implied. See the License for the specific language
 * governing permissions and limitations under the License.
 */

import {act, render, waitFor} from '@react-spectrum/test-utils-internal';
import {ariaHideOutside} from '../src';
import {enableShadowDOM} from '@react-stately/flags';
import React, {useRef, useState} from 'react';

describe('ariaHideOutside', function () {
  it('should hide everything except the provided element [button]', function () {
    let {getByRole, getAllByRole} = render(
      <>
        <input type="checkbox" />
        <button>Button</button>
        <input type="checkbox" />
      </>
    );

    let checkboxes = getAllByRole('checkbox');
    let button = getByRole('button');

    let revert = ariaHideOutside([button]);

    expect(checkboxes[0]).toHaveAttribute('aria-hidden', 'true');
    expect(checkboxes[1]).toHaveAttribute('aria-hidden', 'true');
    expect(button).not.toHaveAttribute('aria-hidden');

    expect(() => getAllByRole('checkbox')).toThrow();
    expect(() => getByRole('button')).not.toThrow();

    revert();

    expect(checkboxes[0]).not.toHaveAttribute('aria-hidden');
    expect(checkboxes[1]).not.toHaveAttribute('aria-hidden');
    expect(button).not.toHaveAttribute('aria-hidden');

    expect(() => getAllByRole('checkbox')).not.toThrow();
    expect(() => getByRole('button')).not.toThrow();
  });

  it('should hide everything except multiple elements', function () {
    let {getByRole, getAllByRole, queryByRole, queryAllByRole} = render(
      <>
        <input type="checkbox" />
        <button>Button</button>
        <input type="checkbox" />
      </>
    );

    let checkboxes = getAllByRole('checkbox');
    let button = getByRole('button');

    let revert = ariaHideOutside(checkboxes);

    expect(checkboxes[0]).not.toHaveAttribute('aria-hidden', 'true');
    expect(checkboxes[1]).not.toHaveAttribute('aria-hidden', 'true');
    expect(button).toHaveAttribute('aria-hidden');

    expect(queryAllByRole('checkbox')).not.toBeNull();
    expect(queryByRole('button')).toBeNull();

    revert();

    expect(checkboxes[0]).not.toHaveAttribute('aria-hidden');
    expect(checkboxes[1]).not.toHaveAttribute('aria-hidden');
    expect(button).not.toHaveAttribute('aria-hidden');

    expect(() => getAllByRole('checkbox')).not.toThrow();
    expect(() => getByRole('button')).not.toThrow();
  });

  it('should not traverse into an already hidden container', function () {
    let {getByRole, getAllByRole} = render(
      <>
        <div>
          <input type="checkbox" />
        </div>
        <button>Button</button>
        <input type="checkbox" />
      </>
    );

    let checkboxes = getAllByRole('checkbox');
    let button = getByRole('button');

    let revert = ariaHideOutside([button]);

    expect(checkboxes[0].parentElement).toHaveAttribute('aria-hidden', 'true');
    expect(checkboxes[1]).toHaveAttribute('aria-hidden', 'true');
    expect(button).not.toHaveAttribute('aria-hidden');

    expect(() => getAllByRole('checkbox')).toThrow();
    expect(() => getByRole('button')).not.toThrow();

    revert();

    expect(checkboxes[0].parentElement).not.toHaveAttribute('aria-hidden');
    expect(checkboxes[1]).not.toHaveAttribute('aria-hidden');
    expect(button).not.toHaveAttribute('aria-hidden');

    expect(() => getAllByRole('checkbox')).not.toThrow();
    expect(() => getByRole('button')).not.toThrow();
  });

  it('should not overwrite an existing aria-hidden prop', function () {
    let {getByRole, getAllByRole} = render(
      <>
        <input type="checkbox" aria-hidden="true" />
        <button>Button</button>
        <input type="checkbox" />
      </>
    );

    let checkboxes = getAllByRole('checkbox');
    let button = getByRole('button');

    let revert = ariaHideOutside([button]);

    expect(checkboxes).toHaveLength(1);
    expect(checkboxes[0]).toHaveAttribute('aria-hidden', 'true');
    expect(button).not.toHaveAttribute('aria-hidden');

    expect(() => getAllByRole('checkbox')).toThrow();
    expect(() => getByRole('button')).not.toThrow();

    revert();

    checkboxes = getAllByRole('checkbox');
    expect(checkboxes).toHaveLength(1);
    expect(checkboxes[0]).not.toHaveAttribute('aria-hidden');
    expect(button).not.toHaveAttribute('aria-hidden');

    expect(() => getAllByRole('checkbox')).not.toThrow();
    expect(() => getByRole('button')).not.toThrow();
  });

  it('should handle when a new element is added outside while active', async function () {
    let Test = props => (
      <>
        {props.show && <input type="checkbox" />}
        <button>Button</button>
        {props.show && <input type="checkbox" />}
      </>
    );

    let {getByRole, getAllByRole, rerender} = render(<Test />);

    let button = getByRole('button');
    expect(() => getAllByRole('checkbox')).toThrow();

    let revert = ariaHideOutside([button]);

    rerender(<Test show />);

    // MutationObserver is async
    await waitFor(() => expect(() => getAllByRole('checkbox')).toThrow());
    expect(() => getByRole('button')).not.toThrow();

    revert();

    expect(getAllByRole('checkbox')).toHaveLength(2);
  });

  it('should handle when a new element is added to an already hidden container', async function () {
    let Test = props => (
      <>
        <div data-testid="test">
          {props.show && <input type="checkbox" />}
        </div>
        <button>Button</button>
        {props.show && <input type="checkbox" />}
      </>
    );

    let {getByRole, getAllByRole, getByTestId, rerender} = render(<Test />);

    let button = getByRole('button');
    let test = getByTestId('test');
    expect(() => getAllByRole('checkbox')).toThrow();

    let revert = ariaHideOutside([button]);

    expect(test).toHaveAttribute('aria-hidden');

    rerender(<Test show />);

    // MutationObserver is async
    await waitFor(() => expect(() => getAllByRole('checkbox')).toThrow());
    expect(() => getByRole('button')).not.toThrow();

    let checkboxes = getAllByRole('checkbox', {hidden: true});
    expect(test).toHaveAttribute('aria-hidden');
    expect(checkboxes[0]).not.toHaveAttribute('aria-hidden');
    expect(checkboxes[1]).toHaveAttribute('aria-hidden', 'true');

    revert();

    expect(getAllByRole('checkbox')).toHaveLength(2);
  });

  it('should handle when a new element is added along with a top layer element', async function () {
    let Test = props => (
      <>
        <button>Button</button>
        {props.show && <div>
          <div role="alert" data-react-aria-top-layer="true">Top layer</div>
          <input type="checkbox" />
        </div>}
      </>
    );

    let {getByRole, queryByRole, getAllByRole, rerender} = render(<Test />);

    let button = getByRole('button');
    expect(queryByRole('checkbox')).toBeNull();

    let revert = ariaHideOutside([button]);

    rerender(<Test show />);

    // MutationObserver is async
    await waitFor(() => queryByRole('checkbox') == null);
    expect(queryByRole('button')).not.toBeNull();
    expect(getByRole('alert')).toHaveTextContent('Top layer');

    revert();

    expect(getAllByRole('checkbox')).toHaveLength(1);
  });

  it('should handle when a new element is added inside a target element', async function () {
    let Test = props => (
      <>
        <input type="checkbox" />
        <div data-testid="test">
          <button>Button</button>
          {props.show && <input type="radio" />}
        </div>
        <input type="checkbox" />
      </>
    );

    let {queryByRole, getByRole, getAllByRole, getByTestId, rerender} = render(<Test />);

    let test = getByTestId('test');
    let revert = ariaHideOutside([test]);

    expect(() => getAllByRole('checkbox')).toThrow();
    expect(queryByRole('radio')).toBeNull();
    expect(queryByRole('button')).not.toBeNull();
    expect(() => getByTestId('test')).not.toThrow();

    rerender(<Test show />);

    // Wait for mutation observer tick
    await Promise.resolve();
    expect(() => getAllByRole('checkbox')).toThrow();
    expect(() => getByRole('radio')).not.toThrow();
    expect(() => getByRole('button')).not.toThrow();
    expect(() => getByTestId('test')).not.toThrow();

    revert();

    expect(() => getAllByRole('checkbox')).not.toThrow();
    expect(() => getByRole('radio')).not.toThrow();
    expect(() => getByRole('button')).not.toThrow();
    expect(() => getByTestId('test')).not.toThrow();
  });

  it('should handle when a new element is added and then reparented', async function () {

    let Test = () => {
      const ref = useRef(null);
      const mutate = () => {
        let parent = document.createElement('ul');
        let child = document.createElement('li');
        ref.current.append(parent);
        parent.appendChild(child);
        parent.remove(); // this results in a mutation record for a disconnected ul with a connected li (through the new ul parent) in `addedNodes`
        let newParent = document.createElement('ul');
        newParent.appendChild(child);
        ref.current.append(newParent);
      };

      return (
        <>
          <div data-testid="test" ref={ref}>
            <button onClick={mutate}>Mutate</button>
          </div>
        </>
      );
    };

    let {queryByRole, getAllByRole, getByTestId} = render(<Test />);

    ariaHideOutside([getByTestId('test')]);

    queryByRole('button').click();
    await Promise.resolve(); // Wait for mutation observer tick

    expect(getAllByRole('listitem')).toHaveLength(1);
  });

  it('should handle when a new element is added and then reparented to a hidden container', async function () {

    let Test = () => {
      const ref = useRef(null);
      const mutate = () => {
        let parent = document.createElement('ul');
        let child = document.createElement('li');
        ref.current.append(parent);
        parent.appendChild(child);
        parent.remove(); // this results in a mutation record for a disconnected ul with a connected li (through the new ul parent) in `addedNodes`
        let newParent = document.createElement('ul');
        newParent.appendChild(child);
        ref.current.append(newParent);
      };

      return (
        <>
          <div data-testid="test">
            <button onClick={mutate}>Mutate</button>
          </div>
          <div data-testid="sibling" ref={ref} />
        </>
      );
    };

    let {queryByRole, queryAllByRole, getByTestId} = render(<Test />);

    ariaHideOutside([getByTestId('test')]);

    queryByRole('button').click();
    await Promise.resolve(); // Wait for mutation observer tick

    expect(queryAllByRole('listitem')).toHaveLength(0);
  });


  it('work when called multiple times', function () {
    let {getByRole, getAllByRole} = render(
      <>
        <input type="checkbox" />
        <input type="radio" />
        <button>Button</button>
        <input type="radio" />
        <input type="checkbox" />
      </>
    );

    let radios = getAllByRole('radio');
    let button = getByRole('button');

    let revert1 = ariaHideOutside([button, ...radios]);

    expect(() => getAllByRole('checkbox')).toThrow();
    expect(() => getAllByRole('radio')).not.toThrow();
    expect(() => getByRole('button')).not.toThrow();

    let revert2 = ariaHideOutside([button]);

    expect(() => getAllByRole('checkbox')).toThrow();
    expect(() => getAllByRole('radio')).toThrow();
    expect(() => getByRole('button')).not.toThrow();

    revert2();

    expect(() => getAllByRole('checkbox')).toThrow();
    expect(() => getAllByRole('radio')).not.toThrow();
    expect(() => getByRole('button')).not.toThrow();

    revert1();

    expect(() => getAllByRole('checkbox')).not.toThrow();
    expect(() => getAllByRole('radio')).not.toThrow();
    expect(() => getByRole('button')).not.toThrow();
  });

  it('work when called multiple times and restored out of order', function () {
    let {getByRole, getAllByRole} = render(
      <>
        <input type="checkbox" />
        <input type="radio" />
        <button>Button</button>
        <input type="radio" />
        <input type="checkbox" />
      </>
    );

    let radios = getAllByRole('radio');
    let button = getByRole('button');

    let revert1 = ariaHideOutside([button, ...radios]);

    expect(() => getAllByRole('checkbox')).toThrow();
    expect(() => getAllByRole('radio')).not.toThrow();
    expect(() => getByRole('button')).not.toThrow();

    let revert2 = ariaHideOutside([button]);

    expect(() => getAllByRole('checkbox')).toThrow();
    expect(() => getAllByRole('radio')).toThrow();
    expect(() => getByRole('button')).not.toThrow();

    revert1();

    expect(() => getAllByRole('checkbox')).toThrow();
    expect(() => getAllByRole('radio')).toThrow();
    expect(() => getByRole('button')).not.toThrow();

    revert2();

    expect(() => getAllByRole('checkbox')).not.toThrow();
    expect(() => getAllByRole('radio')).not.toThrow();
    expect(() => getByRole('button')).not.toThrow();
  });

  it('should hide everything except the provided element [row]', function () {
    let {getAllByRole, getByTestId} = render(
      <div role="grid">
        <div role="row">
          <div role="gridcell">
            <span data-testid="test-span">
              Cell 1
            </span></div>
        </div>
        <div role="row">
          <div role="gridcell">Cell 2</div>
        </div>
      </div>
    );

    let cells = getAllByRole('gridcell');
    let rows = getAllByRole('row');
    let span = getByTestId('test-span');

    let revert = ariaHideOutside([rows[1]]);

    // Applies aria-hidden to the row and cell despite recursive nature of aria-hidden
    // for https://bugs.webkit.org/show_bug.cgi?id=222623
    expect(rows[0]).toHaveAttribute('aria-hidden', 'true');
    expect(cells[0]).toHaveAttribute('aria-hidden', 'true');
    expect(span).not.toHaveAttribute('aria-hidden');
    expect(rows[1]).not.toHaveAttribute('aria-hidden', 'true');
    expect(cells[1]).not.toHaveAttribute('aria-hidden', 'true');

    revert();

    expect(rows[0]).not.toHaveAttribute('aria-hidden', 'true');
    expect(cells[0]).not.toHaveAttribute('aria-hidden', 'true');
    expect(rows[1]).not.toHaveAttribute('aria-hidden', 'true');
    expect(cells[1]).not.toHaveAttribute('aria-hidden', 'true');
    expect(span).not.toHaveAttribute('aria-hidden');
  });

  it('should unhide after item reorder', async function () {
    function Item(props) {
      return (
        <div role="presentation">
          <div data-testid={props.testid} role="row">
            <div role="gridcell" />
          </div>
        </div>
      );
    }

    function Test() {
      let [count, setCount] = useState(0);
      let items = ['row1', 'row2', 'row3', 'row4', 'row5'];
      if (count === 1) {
        items = ['row2', 'row1', 'row3', 'row4', 'row5'];
      } else if (count === 2) {
        items = ['row2', 'row3', 'row1', 'row4', 'row5'];
      }

      return (
        <>
          <button onClick={() => setCount((old) => old + 1)}>press</button>
          {items.map((item) => <Item testid={item} key={item} />)}
        </>

      );
    }

    let {getByRole, getByTestId} = render(
      <Test />
    );

    let button = getByRole('button');
    let row = getByTestId('row1');
    let revert = ariaHideOutside([button]);

    act(() => button.click());
    await Promise.resolve();
    act(() => button.click());
    await Promise.resolve();
    revert();
    expect(row.parentElement).not.toHaveAttribute('aria-hidden', 'true');
  });

  it('does not hide anything inside a shadow root when shadow DOM is disabled', function () {
    let outside = document.createElement('button');
    let host = document.createElement('div');
    document.body.append(outside, host);
    let shadowRoot = host.attachShadow({mode: 'open'});
    let sibling = document.createElement('input');
    let target = document.createElement('button');
    shadowRoot.append(sibling, target);

    let revert = ariaHideOutside([target]);

    // The target is not in the light DOM, so the body does not contain it and is hidden as a whole.
    expect(document.body).toHaveAttribute('aria-hidden', 'true');
    expect(sibling).not.toHaveAttribute('aria-hidden');
    expect(target).not.toHaveAttribute('aria-hidden');

    revert();
    expect(document.body).not.toHaveAttribute('aria-hidden');
    host.remove();
    outside.remove();
  });
});

describe('ariaHideOutside with Shadow DOM', function () {
  let created = [];

  beforeAll(() => {
    enableShadowDOM();
  });

  afterEach(() => {
    for (let node of created) {
      node.remove();
    }
    created = [];
  });

  // Creates an element with attributes and text. It is not attached to the document.
  function createElement(tag, attributes = {}, text = '') {
    let element = document.createElement(tag);
    for (let [name, value] of Object.entries(attributes)) {
      element.setAttribute(name, value);
    }
    element.textContent = text;
    return element;
  }

  // Creates an open shadow host under the parent. The host is removed after each test.
  function createHost(parent = document.body) {
    let host = document.createElement('div');
    parent.appendChild(host);
    created.push(host);
    return {host, shadowRoot: host.attachShadow({mode: 'open'})};
  }

  // Adds an element to the body. The element is removed after each test.
  function addToBody(element) {
    document.body.appendChild(element);
    created.push(element);
    return element;
  }

  it('hides light DOM siblings of the host and siblings of the target inside its shadow root', function () {
    let outside = addToBody(createElement('button', {}, 'Outside'));
    let {host, shadowRoot} = createHost();
    let sibling = createElement('input', {type: 'checkbox'});
    let target = createElement('button', {}, 'Target');
    let content = createElement('span', {}, 'Content');
    target.appendChild(content);
    shadowRoot.append(sibling, target);

    let revert = ariaHideOutside([target]);

    expect(outside).toHaveAttribute('aria-hidden', 'true');
    expect(host).not.toHaveAttribute('aria-hidden');
    expect(sibling).toHaveAttribute('aria-hidden', 'true');
    expect(target).not.toHaveAttribute('aria-hidden');
    expect(content).not.toHaveAttribute('aria-hidden');

    revert();

    expect(outside).not.toHaveAttribute('aria-hidden');
    expect(sibling).not.toHaveAttribute('aria-hidden');
    expect(target).not.toHaveAttribute('aria-hidden');
  });

  it('hides siblings at every level of nested shadow roots', function () {
    let outside = addToBody(createElement('button', {}, 'Outside'));
    let outer = createHost();
    let siblingA = createElement('input', {type: 'checkbox'});
    let inner = createHost(outer.shadowRoot);
    let siblingB = createElement('input', {type: 'radio'});
    let target = createElement('button', {}, 'Target');
    inner.shadowRoot.append(siblingB, target);
    outer.shadowRoot.append(siblingA);

    let revert = ariaHideOutside([target]);

    expect(outside).toHaveAttribute('aria-hidden', 'true');
    expect(siblingA).toHaveAttribute('aria-hidden', 'true');
    expect(siblingB).toHaveAttribute('aria-hidden', 'true');
    expect(outer.host).not.toHaveAttribute('aria-hidden');
    expect(inner.host).not.toHaveAttribute('aria-hidden');
    expect(target).not.toHaveAttribute('aria-hidden');

    revert();

    expect(outside).not.toHaveAttribute('aria-hidden');
    expect(siblingA).not.toHaveAttribute('aria-hidden');
    expect(siblingB).not.toHaveAttribute('aria-hidden');
  });

  it('hides elements added later to the shadow root of the target', async function () {
    let {shadowRoot} = createHost();
    let target = createElement('button', {}, 'Target');
    shadowRoot.append(target);

    let revert = ariaHideOutside([target]);

    let added = createElement('input', {type: 'checkbox'});
    shadowRoot.append(added);
    await Promise.resolve();

    expect(added).toHaveAttribute('aria-hidden', 'true');
    expect(target).not.toHaveAttribute('aria-hidden');

    revert();
  });

  it('hides elements added later to a container inside the shadow root of the target', async function () {
    let {shadowRoot} = createHost();
    let container = createElement('div');
    let target = createElement('button', {}, 'Target');
    container.appendChild(target);
    shadowRoot.append(container);

    let revert = ariaHideOutside([target]);

    let added = createElement('input', {type: 'checkbox'});
    container.appendChild(added);
    await Promise.resolve();

    expect(added).toHaveAttribute('aria-hidden', 'true');
    expect(container).not.toHaveAttribute('aria-hidden');
    expect(target).not.toHaveAttribute('aria-hidden');

    revert();
  });

  it('hides elements added later to an enclosing shadow root', async function () {
    let outer = createHost();
    let inner = createHost(outer.shadowRoot);
    let target = createElement('button', {}, 'Target');
    inner.shadowRoot.append(target);

    let revert = ariaHideOutside([target]);

    let added = createElement('button', {}, 'Added');
    outer.shadowRoot.append(added);
    await Promise.resolve();

    expect(added).toHaveAttribute('aria-hidden', 'true');
    expect(inner.host).not.toHaveAttribute('aria-hidden');

    revert();
  });

  it('does not hide elements added inside a target in a shadow root', async function () {
    let {shadowRoot} = createHost();
    let target = createElement('div');
    shadowRoot.append(target);

    let revert = ariaHideOutside([target]);

    let added = createElement('input', {type: 'checkbox'});
    target.appendChild(added);
    await Promise.resolve();

    expect(added).not.toHaveAttribute('aria-hidden');
    expect(target).not.toHaveAttribute('aria-hidden');

    revert();
  });

  it('does not hide elements added inside an already hidden node in a shadow root', async function () {
    let {shadowRoot} = createHost();
    let hiddenContainer = createElement('div');
    let target = createElement('button', {}, 'Target');
    shadowRoot.append(hiddenContainer, target);

    let revert = ariaHideOutside([target]);
    expect(hiddenContainer).toHaveAttribute('aria-hidden', 'true');

    let added = createElement('input', {type: 'checkbox'});
    hiddenContainer.appendChild(added);
    await Promise.resolve();

    expect(added).not.toHaveAttribute('aria-hidden');

    revert();
  });

  it('does not hide live announcers and top layer elements in a shadow root', async function () {
    let {shadowRoot} = createHost();
    let target = createElement('button', {}, 'Target');
    let sibling = createElement('input', {type: 'checkbox'});
    let announcer = createElement('div', {'data-live-announcer': 'true'}, 'Announcement');
    let topLayer = createElement('div', {'data-react-aria-top-layer': 'true'}, 'Toast');
    shadowRoot.append(target, sibling, announcer, topLayer);

    let revert = ariaHideOutside([target]);

    expect(sibling).toHaveAttribute('aria-hidden', 'true');
    expect(announcer).not.toHaveAttribute('aria-hidden');
    expect(topLayer).not.toHaveAttribute('aria-hidden');

    let laterAnnouncer = createElement('div', {'data-live-announcer': 'true'}, 'Later');
    let laterTopLayer = createElement('div', {'data-react-aria-top-layer': 'true'}, 'Later toast');
    let laterSibling = createElement('input', {type: 'checkbox'});
    shadowRoot.append(laterAnnouncer, laterTopLayer, laterSibling);
    await Promise.resolve();

    expect(laterSibling).toHaveAttribute('aria-hidden', 'true');
    expect(laterAnnouncer).not.toHaveAttribute('aria-hidden');
    expect(laterTopLayer).not.toHaveAttribute('aria-hidden');

    revert();
  });

  it('hides outside content for targets in different shadow roots, including later additions', async function () {
    let outside = addToBody(createElement('button', {}, 'Outside'));
    let hostA = createHost();
    let inputA = createElement('input', {type: 'text'});
    let siblingA = createElement('input', {type: 'checkbox'});
    hostA.shadowRoot.append(siblingA, inputA);
    let hostB = createHost();
    let popover = createElement('div', {}, 'Popover');
    let siblingB = createElement('button', {}, 'Sibling');
    hostB.shadowRoot.append(popover, siblingB);

    let revert = ariaHideOutside([inputA, popover]);

    expect(hostA.host).not.toHaveAttribute('aria-hidden');
    expect(hostB.host).not.toHaveAttribute('aria-hidden');
    expect(inputA).not.toHaveAttribute('aria-hidden');
    expect(popover).not.toHaveAttribute('aria-hidden');
    expect(outside).toHaveAttribute('aria-hidden', 'true');
    expect(siblingA).toHaveAttribute('aria-hidden', 'true');
    expect(siblingB).toHaveAttribute('aria-hidden', 'true');

    let addedA = createElement('button', {}, 'Added A');
    let addedB = createElement('button', {}, 'Added B');
    hostA.shadowRoot.append(addedA);
    hostB.shadowRoot.append(addedB);
    await Promise.resolve();

    expect(addedA).toHaveAttribute('aria-hidden', 'true');
    expect(addedB).toHaveAttribute('aria-hidden', 'true');
    expect(inputA).not.toHaveAttribute('aria-hidden');
    expect(popover).not.toHaveAttribute('aria-hidden');

    revert();
  });

  it('does not hide anything inside a target that is a shadow host containing another target', async function () {
    let outside = addToBody(createElement('button', {}, 'Outside'));
    let {host, shadowRoot} = createHost();
    let nestedTarget = createElement('button', {}, 'Nested target');
    let other = createElement('input', {type: 'checkbox'});
    shadowRoot.append(nestedTarget, other);

    let revert = ariaHideOutside([host, nestedTarget]);

    expect(outside).toHaveAttribute('aria-hidden', 'true');
    expect(host).not.toHaveAttribute('aria-hidden');
    expect(nestedTarget).not.toHaveAttribute('aria-hidden');
    expect(other).not.toHaveAttribute('aria-hidden');

    let added = createElement('input', {type: 'radio'});
    shadowRoot.append(added);
    await Promise.resolve();

    expect(added).not.toHaveAttribute('aria-hidden');

    revert();
  });

  it('does not hide the shadow content of a target that is a shadow host', function () {
    let outside = addToBody(createElement('button', {}, 'Outside'));
    let {host, shadowRoot} = createHost();
    let content = createElement('input', {type: 'checkbox'});
    shadowRoot.append(content);

    let revert = ariaHideOutside([host]);

    expect(outside).toHaveAttribute('aria-hidden', 'true');
    expect(host).not.toHaveAttribute('aria-hidden');
    expect(content).not.toHaveAttribute('aria-hidden');

    revert();
  });

  it('removes the aria-hidden it added in shadow roots, keeps existing ones, and stops observing', async function () {
    let outside = addToBody(createElement('button', {}, 'Outside'));
    let {shadowRoot} = createHost();
    let sibling = createElement('input', {type: 'checkbox'});
    let existing = createElement('input', {type: 'radio', 'aria-hidden': 'true'});
    let target = createElement('button', {}, 'Target');
    shadowRoot.append(sibling, existing, target);

    let revert = ariaHideOutside([target]);
    expect(sibling).toHaveAttribute('aria-hidden', 'true');

    revert();

    expect(outside).not.toHaveAttribute('aria-hidden');
    expect(sibling).not.toHaveAttribute('aria-hidden');
    expect(existing).toHaveAttribute('aria-hidden', 'true');
    expect(target).not.toHaveAttribute('aria-hidden');

    let added = createElement('button', {}, 'Added');
    shadowRoot.append(added);
    await Promise.resolve();

    expect(added).not.toHaveAttribute('aria-hidden');
  });

  it('re-observes the shadow roots of the first call when the second call is restored', async function () {
    let outside = addToBody(createElement('button', {}, 'Outside'));
    let {shadowRoot} = createHost();
    let target = createElement('button', {}, 'Target');
    shadowRoot.append(target);

    let revert1 = ariaHideOutside([target]);
    let revert2 = ariaHideOutside([outside]);

    let addedWhileNested = createElement('button', {}, 'Nested');
    shadowRoot.append(addedWhileNested);
    await Promise.resolve();
    expect(addedWhileNested).not.toHaveAttribute('aria-hidden');

    revert2();

    let addedAfterRestore = createElement('button', {}, 'Restored');
    shadowRoot.append(addedAfterRestore);
    await Promise.resolve();
    expect(addedAfterRestore).toHaveAttribute('aria-hidden', 'true');
    // The first call still hides the outside button, since it is not one of its targets.
    expect(outside).toHaveAttribute('aria-hidden', 'true');

    revert1();

    expect(outside).not.toHaveAttribute('aria-hidden');
    expect(addedWhileNested).not.toHaveAttribute('aria-hidden');
    expect(addedAfterRestore).not.toHaveAttribute('aria-hidden');
  });

  it('keeps the shadow roots of the first call observed when a middle call is restored first', async function () {
    let {shadowRoot} = createHost();
    let target = createElement('button', {}, 'Target');
    shadowRoot.append(target);
    let outside1 = addToBody(createElement('button', {}, 'Outside 1'));
    let outside2 = addToBody(createElement('button', {}, 'Outside 2'));

    let revert1 = ariaHideOutside([target]);
    let revert2 = ariaHideOutside([outside1]);
    let revert3 = ariaHideOutside([outside2]);

    revert2();

    let addedWhileNested = createElement('button', {}, 'Nested');
    shadowRoot.append(addedWhileNested);
    await Promise.resolve();
    expect(addedWhileNested).not.toHaveAttribute('aria-hidden');

    revert3();

    let addedAfterRestore = createElement('button', {}, 'Restored');
    shadowRoot.append(addedAfterRestore);
    await Promise.resolve();
    expect(addedAfterRestore).toHaveAttribute('aria-hidden', 'true');

    revert1();
    expect(addedAfterRestore).not.toHaveAttribute('aria-hidden');
  });

  it('stops observing the shadow roots of the first call when it is restored first', async function () {
    let outside = addToBody(createElement('button', {}, 'Outside'));
    let {shadowRoot} = createHost();
    let target = createElement('button', {}, 'Target');
    shadowRoot.append(target);

    let revert1 = ariaHideOutside([target]);
    let revert2 = ariaHideOutside([outside]);

    revert1();

    let added = createElement('button', {}, 'Added');
    shadowRoot.append(added);
    await Promise.resolve();
    expect(added).not.toHaveAttribute('aria-hidden');

    revert2();

    expect(outside).not.toHaveAttribute('aria-hidden');
    expect(target).not.toHaveAttribute('aria-hidden');
  });

  it('uses inert for shadow root content when shouldUseInert is set', function () {
    // jsdom does not implement inert, so provide the property and load a fresh copy of the module,
    // since the module checks for inert support when it is loaded.
    HTMLElement.prototype.inert = false;
    let ariaHideOutsideWithInert;
    jest.isolateModules(() => {
      require('@react-stately/flags').enableShadowDOM();
      ariaHideOutsideWithInert = require('../src/ariaHideOutside').ariaHideOutside;
    });

    let outside = addToBody(createElement('button', {}, 'Outside'));
    let {host, shadowRoot} = createHost();
    let sibling = createElement('input', {type: 'checkbox'});
    let target = createElement('button', {}, 'Target');
    shadowRoot.append(sibling, target);

    let revert = ariaHideOutsideWithInert([target], {shouldUseInert: true});

    expect(outside.inert).toBe(true);
    expect(sibling.inert).toBe(true);
    expect(host.inert).toBe(false);
    expect(target.inert).toBe(false);

    revert();

    expect(outside.inert).toBe(false);
    expect(sibling.inert).toBe(false);
    delete HTMLElement.prototype.inert;
  });

  it('does not throw for closed shadow roots or hosts without a shadow root', function () {
    let outside = addToBody(createElement('button', {}, 'Outside'));
    let closedHost = document.createElement('div');
    document.body.appendChild(closedHost);
    created.push(closedHost);
    let closedShadowRoot = closedHost.attachShadow({mode: 'closed'});
    let closedTarget = createElement('button', {}, 'Closed target');
    closedShadowRoot.append(closedTarget);
    let plain = addToBody(createElement('div', {}, 'Plain'));
    let lightTarget = createElement('button', {}, 'Light target');
    plain.appendChild(lightTarget);

    let revert;
    expect(() => {
      revert = ariaHideOutside([closedTarget, lightTarget]);
    }).not.toThrow();

    expect(outside).toHaveAttribute('aria-hidden', 'true');
    expect(closedHost).not.toHaveAttribute('aria-hidden');
    expect(plain).not.toHaveAttribute('aria-hidden');

    revert();
  });

  it('does not hide outside the root option when the root is inside a shadow root', async function () {
    let outside = addToBody(createElement('button', {}, 'Outside'));
    let {host, shadowRoot} = createHost();
    let siblingOutsideRoot = createElement('input', {type: 'checkbox'});
    let root = createElement('div');
    let target = createElement('button', {}, 'Target');
    let siblingInsideRoot = createElement('input', {type: 'radio'});
    root.append(target, siblingInsideRoot);
    shadowRoot.append(siblingOutsideRoot, root);

    let revert = ariaHideOutside([target], {root});

    expect(siblingInsideRoot).toHaveAttribute('aria-hidden', 'true');
    expect(siblingOutsideRoot).not.toHaveAttribute('aria-hidden');
    expect(outside).not.toHaveAttribute('aria-hidden');
    expect(host).not.toHaveAttribute('aria-hidden');
    expect(root).not.toHaveAttribute('aria-hidden');

    let addedOutsideRoot = createElement('button', {}, 'Added outside root');
    shadowRoot.append(addedOutsideRoot);
    await Promise.resolve();
    expect(addedOutsideRoot).not.toHaveAttribute('aria-hidden');

    revert();
  });

  it('does not hide a shadow root child that is added and then moved into a target', async function () {
    let {shadowRoot} = createHost();
    let target = createElement('div', {}, 'Target');
    shadowRoot.append(target);

    let revert = ariaHideOutside([target]);

    let child = createElement('span', {}, 'Moved');
    shadowRoot.append(child);
    target.appendChild(child);
    await Promise.resolve();

    expect(child).not.toHaveAttribute('aria-hidden');
    expect(target).not.toHaveAttribute('aria-hidden');

    revert();
  });

  it('hides light DOM children of a host on the path to a target', function () {
    let {host, shadowRoot} = createHost();
    let slotted = createElement('button', {}, 'Slotted');
    host.appendChild(slotted);
    let slot = createElement('slot');
    let target = createElement('button', {}, 'Target');
    shadowRoot.append(slot, target);

    let revert = ariaHideOutside([target]);

    expect(slotted).toHaveAttribute('aria-hidden', 'true');
    expect(slot).toHaveAttribute('aria-hidden', 'true');
    expect(host).not.toHaveAttribute('aria-hidden');
    expect(target).not.toHaveAttribute('aria-hidden');

    revert();
  });

  it('hides outside content when the target is the only child of a shadow root', function () {
    let outside = addToBody(createElement('button', {}, 'Outside'));
    let {host, shadowRoot} = createHost();
    let target = createElement('button', {}, 'Target');
    shadowRoot.append(target);

    let revert = ariaHideOutside([target]);

    expect(outside).toHaveAttribute('aria-hidden', 'true');
    expect(host).not.toHaveAttribute('aria-hidden');
    expect(target).not.toHaveAttribute('aria-hidden');

    revert();

    expect(outside).not.toHaveAttribute('aria-hidden');
  });
});

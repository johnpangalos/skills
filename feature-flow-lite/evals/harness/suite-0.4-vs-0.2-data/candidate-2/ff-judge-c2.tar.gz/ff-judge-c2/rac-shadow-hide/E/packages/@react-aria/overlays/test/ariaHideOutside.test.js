/*
 * Copyright 2020 Adobe. All rights reserved.
 * This file is licensed to you under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License. You may obtain a copy
 * of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software distributed under
 * the License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR REPRESENTATIONS
 * OF ANY KIND, either express or implied. See the License for the specific language
 * governing permissions and limitations under the License.
 */

import {act, createShadowRoot, render, waitFor} from '@react-spectrum/test-utils-internal';
import {ariaHideOutside} from '../src';
import {enableShadowDOM} from '@react-stately/flags';
import fc from 'fast-check';
import {keepVisible} from '../src/ariaHideOutside';
import React, {useRef, useState} from 'react';

describe('ariaHideOutside', function () {
  it('should hide everything except the provided element [button]', function () {
    let {getByRole, getAllByRole} = render(
      <>
        <input type="checkbox" />
        <button>Button</button>
        <input type="checkbox" />
      </>
    );

    let checkboxes = getAllByRole('checkbox');
    let button = getByRole('button');

    let revert = ariaHideOutside([button]);

    expect(checkboxes[0]).toHaveAttribute('aria-hidden', 'true');
    expect(checkboxes[1]).toHaveAttribute('aria-hidden', 'true');
    expect(button).not.toHaveAttribute('aria-hidden');

    expect(() => getAllByRole('checkbox')).toThrow();
    expect(() => getByRole('button')).not.toThrow();

    revert();

    expect(checkboxes[0]).not.toHaveAttribute('aria-hidden');
    expect(checkboxes[1]).not.toHaveAttribute('aria-hidden');
    expect(button).not.toHaveAttribute('aria-hidden');

    expect(() => getAllByRole('checkbox')).not.toThrow();
    expect(() => getByRole('button')).not.toThrow();
  });

  it('should hide everything except multiple elements', function () {
    let {getByRole, getAllByRole, queryByRole, queryAllByRole} = render(
      <>
        <input type="checkbox" />
        <button>Button</button>
        <input type="checkbox" />
      </>
    );

    let checkboxes = getAllByRole('checkbox');
    let button = getByRole('button');

    let revert = ariaHideOutside(checkboxes);

    expect(checkboxes[0]).not.toHaveAttribute('aria-hidden', 'true');
    expect(checkboxes[1]).not.toHaveAttribute('aria-hidden', 'true');
    expect(button).toHaveAttribute('aria-hidden');

    expect(queryAllByRole('checkbox')).not.toBeNull();
    expect(queryByRole('button')).toBeNull();

    revert();

    expect(checkboxes[0]).not.toHaveAttribute('aria-hidden');
    expect(checkboxes[1]).not.toHaveAttribute('aria-hidden');
    expect(button).not.toHaveAttribute('aria-hidden');

    expect(() => getAllByRole('checkbox')).not.toThrow();
    expect(() => getByRole('button')).not.toThrow();
  });

  it('should not traverse into an already hidden container', function () {
    let {getByRole, getAllByRole} = render(
      <>
        <div>
          <input type="checkbox" />
        </div>
        <button>Button</button>
        <input type="checkbox" />
      </>
    );

    let checkboxes = getAllByRole('checkbox');
    let button = getByRole('button');

    let revert = ariaHideOutside([button]);

    expect(checkboxes[0].parentElement).toHaveAttribute('aria-hidden', 'true');
    expect(checkboxes[1]).toHaveAttribute('aria-hidden', 'true');
    expect(button).not.toHaveAttribute('aria-hidden');

    expect(() => getAllByRole('checkbox')).toThrow();
    expect(() => getByRole('button')).not.toThrow();

    revert();

    expect(checkboxes[0].parentElement).not.toHaveAttribute('aria-hidden');
    expect(checkboxes[1]).not.toHaveAttribute('aria-hidden');
    expect(button).not.toHaveAttribute('aria-hidden');

    expect(() => getAllByRole('checkbox')).not.toThrow();
    expect(() => getByRole('button')).not.toThrow();
  });

  it('should not overwrite an existing aria-hidden prop', function () {
    let {getByRole, getAllByRole} = render(
      <>
        <input type="checkbox" aria-hidden="true" />
        <button>Button</button>
        <input type="checkbox" />
      </>
    );

    let checkboxes = getAllByRole('checkbox');
    let button = getByRole('button');

    let revert = ariaHideOutside([button]);

    expect(checkboxes).toHaveLength(1);
    expect(checkboxes[0]).toHaveAttribute('aria-hidden', 'true');
    expect(button).not.toHaveAttribute('aria-hidden');

    expect(() => getAllByRole('checkbox')).toThrow();
    expect(() => getByRole('button')).not.toThrow();

    revert();

    checkboxes = getAllByRole('checkbox');
    expect(checkboxes).toHaveLength(1);
    expect(checkboxes[0]).not.toHaveAttribute('aria-hidden');
    expect(button).not.toHaveAttribute('aria-hidden');

    expect(() => getAllByRole('checkbox')).not.toThrow();
    expect(() => getByRole('button')).not.toThrow();
  });

  it('should handle when a new element is added outside while active', async function () {
    let Test = props => (
      <>
        {props.show && <input type="checkbox" />}
        <button>Button</button>
        {props.show && <input type="checkbox" />}
      </>
    );

    let {getByRole, getAllByRole, rerender} = render(<Test />);

    let button = getByRole('button');
    expect(() => getAllByRole('checkbox')).toThrow();

    let revert = ariaHideOutside([button]);

    rerender(<Test show />);

    // MutationObserver is async
    await waitFor(() => expect(() => getAllByRole('checkbox')).toThrow());
    expect(() => getByRole('button')).not.toThrow();

    revert();

    expect(getAllByRole('checkbox')).toHaveLength(2);
  });

  it('should handle when a new element is added to an already hidden container', async function () {
    let Test = props => (
      <>
        <div data-testid="test">
          {props.show && <input type="checkbox" />}
        </div>
        <button>Button</button>
        {props.show && <input type="checkbox" />}
      </>
    );

    let {getByRole, getAllByRole, getByTestId, rerender} = render(<Test />);

    let button = getByRole('button');
    let test = getByTestId('test');
    expect(() => getAllByRole('checkbox')).toThrow();

    let revert = ariaHideOutside([button]);

    expect(test).toHaveAttribute('aria-hidden');

    rerender(<Test show />);

    // MutationObserver is async
    await waitFor(() => expect(() => getAllByRole('checkbox')).toThrow());
    expect(() => getByRole('button')).not.toThrow();

    let checkboxes = getAllByRole('checkbox', {hidden: true});
    expect(test).toHaveAttribute('aria-hidden');
    expect(checkboxes[0]).not.toHaveAttribute('aria-hidden');
    expect(checkboxes[1]).toHaveAttribute('aria-hidden', 'true');

    revert();

    expect(getAllByRole('checkbox')).toHaveLength(2);
  });

  it('should handle when a new element is added along with a top layer element', async function () {
    let Test = props => (
      <>
        <button>Button</button>
        {props.show && <div>
          <div role="alert" data-react-aria-top-layer="true">Top layer</div>
          <input type="checkbox" />
        </div>}
      </>
    );

    let {getByRole, queryByRole, getAllByRole, rerender} = render(<Test />);

    let button = getByRole('button');
    expect(queryByRole('checkbox')).toBeNull();

    let revert = ariaHideOutside([button]);

    rerender(<Test show />);

    // MutationObserver is async
    await waitFor(() => queryByRole('checkbox') == null);
    expect(queryByRole('button')).not.toBeNull();
    expect(getByRole('alert')).toHaveTextContent('Top layer');

    revert();

    expect(getAllByRole('checkbox')).toHaveLength(1);
  });

  it('should handle when a new element is added inside a target element', async function () {
    let Test = props => (
      <>
        <input type="checkbox" />
        <div data-testid="test">
          <button>Button</button>
          {props.show && <input type="radio" />}
        </div>
        <input type="checkbox" />
      </>
    );

    let {queryByRole, getByRole, getAllByRole, getByTestId, rerender} = render(<Test />);

    let test = getByTestId('test');
    let revert = ariaHideOutside([test]);

    expect(() => getAllByRole('checkbox')).toThrow();
    expect(queryByRole('radio')).toBeNull();
    expect(queryByRole('button')).not.toBeNull();
    expect(() => getByTestId('test')).not.toThrow();

    rerender(<Test show />);

    // Wait for mutation observer tick
    await Promise.resolve();
    expect(() => getAllByRole('checkbox')).toThrow();
    expect(() => getByRole('radio')).not.toThrow();
    expect(() => getByRole('button')).not.toThrow();
    expect(() => getByTestId('test')).not.toThrow();

    revert();

    expect(() => getAllByRole('checkbox')).not.toThrow();
    expect(() => getByRole('radio')).not.toThrow();
    expect(() => getByRole('button')).not.toThrow();
    expect(() => getByTestId('test')).not.toThrow();
  });

  it('should handle when a new element is added and then reparented', async function () {

    let Test = () => {
      const ref = useRef(null);
      const mutate = () => {
        let parent = document.createElement('ul');
        let child = document.createElement('li');
        ref.current.append(parent);
        parent.appendChild(child);
        parent.remove(); // this results in a mutation record for a disconnected ul with a connected li (through the new ul parent) in `addedNodes`
        let newParent = document.createElement('ul');
        newParent.appendChild(child);
        ref.current.append(newParent);
      };

      return (
        <>
          <div data-testid="test" ref={ref}>
            <button onClick={mutate}>Mutate</button>
          </div>
        </>
      );
    };

    let {queryByRole, getAllByRole, getByTestId} = render(<Test />);

    ariaHideOutside([getByTestId('test')]);

    queryByRole('button').click();
    await Promise.resolve(); // Wait for mutation observer tick

    expect(getAllByRole('listitem')).toHaveLength(1);
  });

  it('should handle when a new element is added and then reparented to a hidden container', async function () {

    let Test = () => {
      const ref = useRef(null);
      const mutate = () => {
        let parent = document.createElement('ul');
        let child = document.createElement('li');
        ref.current.append(parent);
        parent.appendChild(child);
        parent.remove(); // this results in a mutation record for a disconnected ul with a connected li (through the new ul parent) in `addedNodes`
        let newParent = document.createElement('ul');
        newParent.appendChild(child);
        ref.current.append(newParent);
      };

      return (
        <>
          <div data-testid="test">
            <button onClick={mutate}>Mutate</button>
          </div>
          <div data-testid="sibling" ref={ref} />
        </>
      );
    };

    let {queryByRole, queryAllByRole, getByTestId} = render(<Test />);

    ariaHideOutside([getByTestId('test')]);

    queryByRole('button').click();
    await Promise.resolve(); // Wait for mutation observer tick

    expect(queryAllByRole('listitem')).toHaveLength(0);
  });


  it('work when called multiple times', function () {
    let {getByRole, getAllByRole} = render(
      <>
        <input type="checkbox" />
        <input type="radio" />
        <button>Button</button>
        <input type="radio" />
        <input type="checkbox" />
      </>
    );

    let radios = getAllByRole('radio');
    let button = getByRole('button');

    let revert1 = ariaHideOutside([button, ...radios]);

    expect(() => getAllByRole('checkbox')).toThrow();
    expect(() => getAllByRole('radio')).not.toThrow();
    expect(() => getByRole('button')).not.toThrow();

    let revert2 = ariaHideOutside([button]);

    expect(() => getAllByRole('checkbox')).toThrow();
    expect(() => getAllByRole('radio')).toThrow();
    expect(() => getByRole('button')).not.toThrow();

    revert2();

    expect(() => getAllByRole('checkbox')).toThrow();
    expect(() => getAllByRole('radio')).not.toThrow();
    expect(() => getByRole('button')).not.toThrow();

    revert1();

    expect(() => getAllByRole('checkbox')).not.toThrow();
    expect(() => getAllByRole('radio')).not.toThrow();
    expect(() => getByRole('button')).not.toThrow();
  });

  it('work when called multiple times and restored out of order', function () {
    let {getByRole, getAllByRole} = render(
      <>
        <input type="checkbox" />
        <input type="radio" />
        <button>Button</button>
        <input type="radio" />
        <input type="checkbox" />
      </>
    );

    let radios = getAllByRole('radio');
    let button = getByRole('button');

    let revert1 = ariaHideOutside([button, ...radios]);

    expect(() => getAllByRole('checkbox')).toThrow();
    expect(() => getAllByRole('radio')).not.toThrow();
    expect(() => getByRole('button')).not.toThrow();

    let revert2 = ariaHideOutside([button]);

    expect(() => getAllByRole('checkbox')).toThrow();
    expect(() => getAllByRole('radio')).toThrow();
    expect(() => getByRole('button')).not.toThrow();

    revert1();

    expect(() => getAllByRole('checkbox')).toThrow();
    expect(() => getAllByRole('radio')).toThrow();
    expect(() => getByRole('button')).not.toThrow();

    revert2();

    expect(() => getAllByRole('checkbox')).not.toThrow();
    expect(() => getAllByRole('radio')).not.toThrow();
    expect(() => getByRole('button')).not.toThrow();
  });

  it('should hide everything except the provided element [row]', function () {
    let {getAllByRole, getByTestId} = render(
      <div role="grid">
        <div role="row">
          <div role="gridcell">
            <span data-testid="test-span">
              Cell 1
            </span></div>
        </div>
        <div role="row">
          <div role="gridcell">Cell 2</div>
        </div>
      </div>
    );

    let cells = getAllByRole('gridcell');
    let rows = getAllByRole('row');
    let span = getByTestId('test-span');

    let revert = ariaHideOutside([rows[1]]);

    // Applies aria-hidden to the row and cell despite recursive nature of aria-hidden
    // for https://bugs.webkit.org/show_bug.cgi?id=222623
    expect(rows[0]).toHaveAttribute('aria-hidden', 'true');
    expect(cells[0]).toHaveAttribute('aria-hidden', 'true');
    expect(span).not.toHaveAttribute('aria-hidden');
    expect(rows[1]).not.toHaveAttribute('aria-hidden', 'true');
    expect(cells[1]).not.toHaveAttribute('aria-hidden', 'true');

    revert();

    expect(rows[0]).not.toHaveAttribute('aria-hidden', 'true');
    expect(cells[0]).not.toHaveAttribute('aria-hidden', 'true');
    expect(rows[1]).not.toHaveAttribute('aria-hidden', 'true');
    expect(cells[1]).not.toHaveAttribute('aria-hidden', 'true');
    expect(span).not.toHaveAttribute('aria-hidden');
  });

  it('should unhide after item reorder', async function () {
    function Item(props) {
      return (
        <div role="presentation">
          <div data-testid={props.testid} role="row">
            <div role="gridcell" />
          </div>
        </div>
      );
    }

    function Test() {
      let [count, setCount] = useState(0);
      let items = ['row1', 'row2', 'row3', 'row4', 'row5'];
      if (count === 1) {
        items = ['row2', 'row1', 'row3', 'row4', 'row5'];
      } else if (count === 2) {
        items = ['row2', 'row3', 'row1', 'row4', 'row5'];
      }

      return (
        <>
          <button onClick={() => setCount((old) => old + 1)}>press</button>
          {items.map((item) => <Item testid={item} key={item} />)}
        </>

      );
    }

    let {getByRole, getByTestId} = render(
      <Test />
    );

    let button = getByRole('button');
    let row = getByTestId('row1');
    let revert = ariaHideOutside([button]);

    act(() => button.click());
    await Promise.resolve();
    act(() => button.click());
    await Promise.resolve();
    revert();
    expect(row.parentElement).not.toHaveAttribute('aria-hidden', 'true');
  });

  it('does not walk or observe shadow roots when shadow DOM is disabled', async function () {
    let {shadowHost, shadowRoot, cleanup} = createShadowRoot();
    let lightSibling = document.createElement('input');
    document.body.appendChild(lightSibling);
    let target = shadowRoot.appendChild(document.createElement('button'));
    let sibling = shadowRoot.appendChild(document.createElement('input'));

    let revert = ariaHideOutside([target]);

    // Without shadow DOM support the target is not seen as inside its host, so the body is hidden as a whole,
    // which hides everything in the light DOM. Shadow roots are not walked, so their content is not marked.
    expect(document.body).toHaveAttribute('aria-hidden', 'true');
    expect(shadowHost).not.toHaveAttribute('aria-hidden');
    expect(lightSibling).not.toHaveAttribute('aria-hidden');
    expect(sibling).not.toHaveAttribute('aria-hidden');
    expect(target).not.toHaveAttribute('aria-hidden');

    let added = shadowRoot.appendChild(document.createElement('span'));
    // MutationObserver is async
    await Promise.resolve();
    expect(added).not.toHaveAttribute('aria-hidden');

    revert();
    expect(document.body).not.toHaveAttribute('aria-hidden');
    cleanup();
    lightSibling.remove();
  });
});

describe('ariaHideOutside with Shadow DOM', function () {
  // Each test builds its DOM in a container appended to <html> and passes it as the root. The earlier tests in
  // this file never restore, so their observers stay connected to document.body and would react to these changes.
  let container;
  let hideOutside = targets => ariaHideOutside(targets, container);

  beforeAll(() => {
    enableShadowDOM();
  });

  beforeEach(() => {
    container = document.createElement('div');
    document.documentElement.appendChild(container);
  });

  afterEach(() => {
    container.remove();
  });

  let create = (tag, attributes = {}) => {
    let element = document.createElement(tag);
    for (let name of Object.keys(attributes)) {
      element.setAttribute(name, attributes[name]);
    }
    return element;
  };

  // Adds an element to the light DOM of the test container.
  let addLight = (element) => {
    container.appendChild(element);
    return element;
  };

  // Mounts a shadow host in the test container, or inside the given shadow root.
  let mountShadow = (parent = container) => createShadowRoot(parent);

  // MutationObserver callbacks run asynchronously.
  let flush = () => new Promise(resolve => setTimeout(resolve));

  // Seeded PRNG (mulberry32) so every generated tree can be reproduced from its seed.
  let mulberry32 = seed => () => {
    seed = (seed + 0x6D2B79F5) | 0;
    let t = Math.imul(seed ^ (seed >>> 15), seed | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };

  // Body > [lightSibling, outer host > shadow: [outerSibling, inner host > shadow: [innerSibling, target]]]
  let buildNested = () => {
    let lightSibling = addLight(create('button'));
    let outer = mountShadow();
    let outerSibling = outer.shadowRoot.appendChild(create('span'));
    let inner = mountShadow(outer.shadowRoot);
    let innerSibling = inner.shadowRoot.appendChild(create('input'));
    let target = inner.shadowRoot.appendChild(create('button'));
    return {lightSibling, outer, outerSibling, inner, innerSibling, target};
  };

  it('hides siblings at every shadow level and in the light DOM, but not the hosts or the target', function () {
    let {lightSibling, outer, outerSibling, inner, innerSibling, target} = buildNested();

    let revert = hideOutside([target]);

    expect(lightSibling).toHaveAttribute('aria-hidden', 'true');
    expect(outerSibling).toHaveAttribute('aria-hidden', 'true');
    expect(innerSibling).toHaveAttribute('aria-hidden', 'true');
    expect(outer.shadowHost).not.toHaveAttribute('aria-hidden');
    expect(inner.shadowHost).not.toHaveAttribute('aria-hidden');
    expect(target).not.toHaveAttribute('aria-hidden');

    revert();
  });

  it('hides a host that does not contain a target as a whole, without marking its shadow content', function () {
    let target = addLight(create('button'));
    let other = mountShadow();
    let otherContent = other.shadowRoot.appendChild(create('button'));

    let revert = hideOutside([target]);

    expect(other.shadowHost).toHaveAttribute('aria-hidden', 'true');
    expect(otherContent).not.toHaveAttribute('aria-hidden');
    expect(target).not.toHaveAttribute('aria-hidden');

    revert();
  });

  it('leaves an existing aria-hidden in a shadow root as it was, before and after restore', function () {
    let {innerSibling, inner, target} = buildNested();
    let existing = inner.shadowRoot.appendChild(create('input', {'aria-hidden': 'true'}));

    let revert = hideOutside([target]);

    expect(existing).toHaveAttribute('aria-hidden', 'true');
    expect(innerSibling).toHaveAttribute('aria-hidden', 'true');

    revert();

    expect(existing).toHaveAttribute('aria-hidden', 'true');
    expect(innerSibling).not.toHaveAttribute('aria-hidden');
  });

  it('keeps a slot that a target is assigned to visible, and hides the other slot and its fallback', function () {
    let lightSibling = addLight(create('button'));
    let host = mountShadow();
    let target = host.shadowHost.appendChild(create('button', {slot: 'a'}));
    let lightUnslotted = host.shadowHost.appendChild(create('span'));
    let wrapper = host.shadowRoot.appendChild(create('div'));
    let slotA = wrapper.appendChild(create('slot', {name: 'a'}));
    let slotB = host.shadowRoot.appendChild(create('slot', {name: 'b'}));
    let fallback = slotB.appendChild(create('span'));
    let shadowSibling = host.shadowRoot.appendChild(create('span'));

    let revert = hideOutside([target]);

    expect(host.shadowHost).not.toHaveAttribute('aria-hidden');
    expect(wrapper).not.toHaveAttribute('aria-hidden');
    expect(slotA).not.toHaveAttribute('aria-hidden');
    expect(target).not.toHaveAttribute('aria-hidden');
    expect(slotB).toHaveAttribute('aria-hidden', 'true');
    expect(fallback).not.toHaveAttribute('aria-hidden');
    expect(shadowSibling).toHaveAttribute('aria-hidden', 'true');
    expect(lightUnslotted).toHaveAttribute('aria-hidden', 'true');
    expect(lightSibling).toHaveAttribute('aria-hidden', 'true');

    revert();
  });

  it('hides an element added to the shadow root of a target after the call', async function () {
    let {inner, target} = buildNested();

    let revert = hideOutside([target]);
    let added = inner.shadowRoot.appendChild(create('span'));
    await flush();

    expect(added).toHaveAttribute('aria-hidden', 'true');
    expect(target).not.toHaveAttribute('aria-hidden');

    revert();
  });

  it('does not hide an element added inside a target', async function () {
    let {inner, target} = buildNested();

    let revert = hideOutside([target]);
    let added = target.appendChild(create('span'));
    let control = inner.shadowRoot.appendChild(create('span'));
    await flush();

    expect(added).not.toHaveAttribute('aria-hidden');
    expect(control).toHaveAttribute('aria-hidden', 'true');

    revert();
  });

  it('hides an element added to a shadow root two levels up after the call', async function () {
    let {outer, target} = buildNested();

    let revert = hideOutside([target]);
    let added = outer.shadowRoot.appendChild(create('span'));
    await flush();

    expect(added).toHaveAttribute('aria-hidden', 'true');
    expect(target).not.toHaveAttribute('aria-hidden');

    revert();
  });

  it('keeps live announcers and top layer elements added to a shadow root visible', async function () {
    let {outer, inner, target} = buildNested();

    let revert = hideOutside([target]);
    let liveAnnouncer = inner.shadowRoot.appendChild(create('div', {'data-live-announcer': 'true'}));
    let topLayer = outer.shadowRoot.appendChild(create('div', {'data-react-aria-top-layer': 'true'}));
    let control = inner.shadowRoot.appendChild(create('span'));
    await flush();

    expect(liveAnnouncer).not.toHaveAttribute('aria-hidden');
    expect(topLayer).not.toHaveAttribute('aria-hidden');
    expect(control).toHaveAttribute('aria-hidden', 'true');

    revert();
  });

  it('keeps live announcers and top layer elements present at call time in a shadow root visible', function () {
    let {outer, inner, innerSibling, target} = buildNested();
    let liveAnnouncer = inner.shadowRoot.appendChild(create('div', {'data-live-announcer': 'true'}));
    let topLayer = outer.shadowRoot.appendChild(create('div', {'data-react-aria-top-layer': 'true'}));

    let revert = hideOutside([target]);

    expect(innerSibling).toHaveAttribute('aria-hidden', 'true');
    expect(liveAnnouncer).not.toHaveAttribute('aria-hidden');
    expect(topLayer).not.toHaveAttribute('aria-hidden');

    revert();
  });

  it('does not separately mark an element added inside a hidden shadow root sibling', async function () {
    let {outerSibling, outer, target} = buildNested();

    let revert = hideOutside([target]);
    let added = outerSibling.appendChild(create('span'));
    let control = outer.shadowRoot.appendChild(create('span'));
    await flush();

    expect(outerSibling).toHaveAttribute('aria-hidden', 'true');
    expect(added).not.toHaveAttribute('aria-hidden');
    expect(control).toHaveAttribute('aria-hidden', 'true');

    revert();
  });

  it('hides everything outside multiple targets in sibling shadow roots, including later additions', async function () {
    let lightSibling = addLight(create('button'));
    let first = mountShadow();
    let second = mountShadow();
    let firstTarget = first.shadowRoot.appendChild(create('input'));
    let secondTarget = second.shadowRoot.appendChild(create('div'));
    let firstSibling = first.shadowRoot.appendChild(create('button'));
    let secondSibling = second.shadowRoot.appendChild(create('button'));

    let revert = hideOutside([firstTarget, secondTarget]);

    expect(first.shadowHost).not.toHaveAttribute('aria-hidden');
    expect(second.shadowHost).not.toHaveAttribute('aria-hidden');
    expect(firstTarget).not.toHaveAttribute('aria-hidden');
    expect(secondTarget).not.toHaveAttribute('aria-hidden');
    expect(firstSibling).toHaveAttribute('aria-hidden', 'true');
    expect(secondSibling).toHaveAttribute('aria-hidden', 'true');
    expect(lightSibling).toHaveAttribute('aria-hidden', 'true');

    let lateFirst = first.shadowRoot.appendChild(create('span'));
    let lateSecond = second.shadowRoot.appendChild(create('span'));
    await flush();

    expect(lateFirst).toHaveAttribute('aria-hidden', 'true');
    expect(lateSecond).toHaveAttribute('aria-hidden', 'true');
    expect(firstTarget).not.toHaveAttribute('aria-hidden');
    expect(secondTarget).not.toHaveAttribute('aria-hidden');

    revert();
  });

  it('handles a target shadow root nested inside another target shadow root', async function () {
    let host = mountShadow();
    let firstTarget = host.shadowRoot.appendChild(create('input'));
    let sibling = host.shadowRoot.appendChild(create('button'));
    let popover = mountShadow(host.shadowRoot);
    let secondTarget = popover.shadowRoot.appendChild(create('div'));
    let popoverSibling = popover.shadowRoot.appendChild(create('button'));
    let lightSibling = addLight(create('button'));

    let revert = hideOutside([firstTarget, secondTarget]);

    expect(host.shadowHost).not.toHaveAttribute('aria-hidden');
    expect(popover.shadowHost).not.toHaveAttribute('aria-hidden');
    expect(firstTarget).not.toHaveAttribute('aria-hidden');
    expect(secondTarget).not.toHaveAttribute('aria-hidden');
    expect(sibling).toHaveAttribute('aria-hidden', 'true');
    expect(popoverSibling).toHaveAttribute('aria-hidden', 'true');
    expect(lightSibling).toHaveAttribute('aria-hidden', 'true');

    let late = popover.shadowRoot.appendChild(create('span'));
    await flush();
    expect(late).toHaveAttribute('aria-hidden', 'true');

    revert();
  });

  it('does not hide anything inside an outer target, including its shadow root', async function () {
    let outer = mountShadow();
    let outerSibling = outer.shadowRoot.appendChild(create('span'));
    let innerTarget = outer.shadowRoot.appendChild(create('button'));
    let lightSibling = addLight(create('button'));

    let revert = hideOutside([outer.shadowHost, innerTarget]);

    expect(outer.shadowHost).not.toHaveAttribute('aria-hidden');
    expect(innerTarget).not.toHaveAttribute('aria-hidden');
    expect(outerSibling).not.toHaveAttribute('aria-hidden');
    expect(lightSibling).toHaveAttribute('aria-hidden', 'true');

    let lateInside = outer.shadowRoot.appendChild(create('span'));
    let lateLight = addLight(create('span'));
    await flush();

    expect(lateInside).not.toHaveAttribute('aria-hidden');
    expect(lateLight).toHaveAttribute('aria-hidden', 'true');

    revert();
  });

  it('removes every attribute it added and disconnects its observers on restore', async function () {
    let {lightSibling, outer, outerSibling, inner, innerSibling, target} = buildNested();

    let revert = hideOutside([target]);
    let beforeRestore = inner.shadowRoot.appendChild(create('span'));
    await flush();
    expect(beforeRestore).toHaveAttribute('aria-hidden', 'true');

    revert();

    expect(lightSibling).not.toHaveAttribute('aria-hidden');
    expect(outerSibling).not.toHaveAttribute('aria-hidden');
    expect(innerSibling).not.toHaveAttribute('aria-hidden');
    expect(beforeRestore).not.toHaveAttribute('aria-hidden');
    expect(outer.shadowHost).not.toHaveAttribute('aria-hidden');
    expect(inner.shadowHost).not.toHaveAttribute('aria-hidden');

    let lateInner = inner.shadowRoot.appendChild(create('span'));
    let lateOuter = outer.shadowRoot.appendChild(create('span'));
    let lateLight = addLight(create('span'));
    await flush();

    expect(lateInner).not.toHaveAttribute('aria-hidden');
    expect(lateOuter).not.toHaveAttribute('aria-hidden');
    expect(lateLight).not.toHaveAttribute('aria-hidden');
  });

  it('resumes the first call observers on every shadow root when the second call is restored', async function () {
    let {inner, innerSibling, target} = buildNested();

    let revert1 = hideOutside([target]);
    let revert2 = hideOutside([target]);
    revert2();

    expect(innerSibling).toHaveAttribute('aria-hidden', 'true');
    let added = inner.shadowRoot.appendChild(create('span'));
    await flush();
    expect(added).toHaveAttribute('aria-hidden', 'true');

    revert1();

    expect(innerSibling).not.toHaveAttribute('aria-hidden');
    expect(added).not.toHaveAttribute('aria-hidden');
  });

  it('works when calls are restored out of order', async function () {
    let {lightSibling, inner, innerSibling, target} = buildNested();

    let revert1 = hideOutside([target]);
    let revert2 = hideOutside([target]);
    revert1();

    expect(innerSibling).toHaveAttribute('aria-hidden', 'true');
    let added = inner.shadowRoot.appendChild(create('span'));
    await flush();
    expect(added).toHaveAttribute('aria-hidden', 'true');

    revert2();

    expect(lightSibling).not.toHaveAttribute('aria-hidden');
    expect(innerSibling).not.toHaveAttribute('aria-hidden');
    expect(added).not.toHaveAttribute('aria-hidden');

    let late = inner.shadowRoot.appendChild(create('span'));
    await flush();
    expect(late).not.toHaveAttribute('aria-hidden');
  });

  it('hides and keeps visible the elements added to a shadow root while a later call was active, once it is restored', async function () {
    let host = mountShadow();
    let target = host.shadowRoot.appendChild(create('button'));
    let lightDomButton = addLight(create('button'));

    let revert1 = hideOutside([target]);
    let revert2 = hideOutside([lightDomButton]);
    let added = host.shadowRoot.appendChild(create('i'));
    let announcer = host.shadowRoot.appendChild(create('div', {'data-live-announcer': 'true'}));
    await flush();

    revert2();

    expect(added).toHaveAttribute('aria-hidden', 'true');
    expect(announcer).not.toHaveAttribute('aria-hidden');
    expect(target).not.toHaveAttribute('aria-hidden');
    expect(host.shadowHost).not.toHaveAttribute('aria-hidden');

    revert1();

    expect(added).not.toHaveAttribute('aria-hidden');
    expect(announcer).not.toHaveAttribute('aria-hidden');
    expect(target).not.toHaveAttribute('aria-hidden');
    expect(lightDomButton).not.toHaveAttribute('aria-hidden');
    expect(host.shadowHost).not.toHaveAttribute('aria-hidden');
    expect([...container.querySelectorAll('[aria-hidden]'), ...host.shadowRoot.querySelectorAll('[aria-hidden]')]).toHaveLength(0);
  });

  it('keeps an element kept visible with keepVisible visible when it is added to a shadow root', async function () {
    let {inner, target} = buildNested();

    let revert = hideOutside([target]);
    let kept = create('span');
    let release = keepVisible(kept);
    inner.shadowRoot.appendChild(kept);
    let control = inner.shadowRoot.appendChild(create('span'));
    await flush();

    expect(kept).not.toHaveAttribute('aria-hidden');
    expect(control).toHaveAttribute('aria-hidden', 'true');

    release();
    revert();
  });

  it('restores the outer state when a dialog inside a dialog closes', function () {
    let lightSibling = addLight(create('button'));
    let outerDialog = mountShadow();
    let innerDialog = outerDialog.shadowRoot.appendChild(create('div'));
    let innerSibling = outerDialog.shadowRoot.appendChild(create('span'));

    let revert1 = hideOutside([outerDialog.shadowHost]);

    expect(lightSibling).toHaveAttribute('aria-hidden', 'true');
    expect(innerDialog).not.toHaveAttribute('aria-hidden');
    expect(innerSibling).not.toHaveAttribute('aria-hidden');

    let revert2 = hideOutside([innerDialog]);

    expect(lightSibling).toHaveAttribute('aria-hidden', 'true');
    expect(outerDialog.shadowHost).not.toHaveAttribute('aria-hidden');
    expect(innerDialog).not.toHaveAttribute('aria-hidden');
    expect(innerSibling).toHaveAttribute('aria-hidden', 'true');

    revert2();

    expect(innerSibling).not.toHaveAttribute('aria-hidden');
    expect(lightSibling).toHaveAttribute('aria-hidden', 'true');

    revert1();

    expect(lightSibling).not.toHaveAttribute('aria-hidden');
  });

  // Fills a light DOM element or shadow root with random divs, some of them hosts and some announcers.
  let populate = (parent, random, depth, elements) => {
    let count = 1 + Math.floor(random() * 3);
    for (let i = 0; i < count; i++) {
      let element = create('div');
      if (random() < 0.2) {
        element.setAttribute('aria-hidden', 'true');
      }
      if (random() < 0.1) {
        element.setAttribute('data-live-announcer', 'true');
      }
      parent.appendChild(element);
      elements.push(element);
      if (depth < 3 && random() < 0.4) {
        element.attachShadow({mode: 'open'});
        populate(element.shadowRoot, random, depth + 1, elements);
      }
      if (depth < 3 && random() < 0.3) {
        populate(element, random, depth + 1, elements);
      }
    }
  };

  // Light DOM and shadow DOM ancestors of an element, nearest first.
  let ancestorsOf = (element) => {
    let result = [];
    let node = element.parentNode;
    while (node) {
      if (node instanceof Element) {
        result.push(node);
      }
      node = node instanceof ShadowRoot ? node.host : node.parentNode;
    }
    return result;
  };

  // Targets and their ancestors that were visible before the call must still be visible during it.
  let expectVisibleAround = (targets, elements, before) => {
    for (let target of targets) {
      for (let element of [target, ...ancestorsOf(target)]) {
        let index = elements.indexOf(element);
        if (index >= 0 && before[index] === null) {
          expect(element).not.toHaveAttribute('aria-hidden');
        }
      }
    }
  };

  it('restores every aria-hidden exactly after hiding, for random shadow trees and target choices', function () {
    fc.assert(fc.property(fc.integer(), seed => {
      let random = mulberry32(seed);
      try {
        let elements = [];
        populate(container, random, 0, elements);
        let targets = elements.filter(() => random() < 0.15);
        if (!targets.length) {
          targets.push(elements[Math.floor(random() * elements.length)]);
        }
        let before = elements.map(element => element.getAttribute('aria-hidden'));

        let revert = hideOutside(targets);

        expectVisibleAround(targets, elements, before);

        revert();

        expect(elements.map(element => element.getAttribute('aria-hidden'))).toEqual(before);
      } finally {
        container.replaceChildren();
      }
    }), {numRuns: 1000, seed: 42});
  });
});

/*
 * Copyright 2020 Adobe. All rights reserved.
 * This file is licensed to you under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License. You may obtain a copy
 * of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software distributed under
 * the License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR REPRESENTATIONS
 * OF ANY KIND, either express or implied. See the License for the specific language
 * governing permissions and limitations under the License.
 */

import {act, render, waitFor} from '@react-spectrum/test-utils-internal';
import {ariaHideOutside, keepVisible} from '../src/ariaHideOutside';
import {enableShadowDOM} from '@react-stately/flags';
import React, {useRef, useState} from 'react';

describe('ariaHideOutside', function () {
  it('should hide everything except the provided element [button]', function () {
    let {getByRole, getAllByRole} = render(
      <>
        <input type="checkbox" />
        <button>Button</button>
        <input type="checkbox" />
      </>
    );

    let checkboxes = getAllByRole('checkbox');
    let button = getByRole('button');

    let revert = ariaHideOutside([button]);

    expect(checkboxes[0]).toHaveAttribute('aria-hidden', 'true');
    expect(checkboxes[1]).toHaveAttribute('aria-hidden', 'true');
    expect(button).not.toHaveAttribute('aria-hidden');

    expect(() => getAllByRole('checkbox')).toThrow();
    expect(() => getByRole('button')).not.toThrow();

    revert();

    expect(checkboxes[0]).not.toHaveAttribute('aria-hidden');
    expect(checkboxes[1]).not.toHaveAttribute('aria-hidden');
    expect(button).not.toHaveAttribute('aria-hidden');

    expect(() => getAllByRole('checkbox')).not.toThrow();
    expect(() => getByRole('button')).not.toThrow();
  });

  it('should hide everything except multiple elements', function () {
    let {getByRole, getAllByRole, queryByRole, queryAllByRole} = render(
      <>
        <input type="checkbox" />
        <button>Button</button>
        <input type="checkbox" />
      </>
    );

    let checkboxes = getAllByRole('checkbox');
    let button = getByRole('button');

    let revert = ariaHideOutside(checkboxes);

    expect(checkboxes[0]).not.toHaveAttribute('aria-hidden', 'true');
    expect(checkboxes[1]).not.toHaveAttribute('aria-hidden', 'true');
    expect(button).toHaveAttribute('aria-hidden');

    expect(queryAllByRole('checkbox')).not.toBeNull();
    expect(queryByRole('button')).toBeNull();

    revert();

    expect(checkboxes[0]).not.toHaveAttribute('aria-hidden');
    expect(checkboxes[1]).not.toHaveAttribute('aria-hidden');
    expect(button).not.toHaveAttribute('aria-hidden');

    expect(() => getAllByRole('checkbox')).not.toThrow();
    expect(() => getByRole('button')).not.toThrow();
  });

  it('should not traverse into an already hidden container', function () {
    let {getByRole, getAllByRole} = render(
      <>
        <div>
          <input type="checkbox" />
        </div>
        <button>Button</button>
        <input type="checkbox" />
      </>
    );

    let checkboxes = getAllByRole('checkbox');
    let button = getByRole('button');

    let revert = ariaHideOutside([button]);

    expect(checkboxes[0].parentElement).toHaveAttribute('aria-hidden', 'true');
    expect(checkboxes[1]).toHaveAttribute('aria-hidden', 'true');
    expect(button).not.toHaveAttribute('aria-hidden');

    expect(() => getAllByRole('checkbox')).toThrow();
    expect(() => getByRole('button')).not.toThrow();

    revert();

    expect(checkboxes[0].parentElement).not.toHaveAttribute('aria-hidden');
    expect(checkboxes[1]).not.toHaveAttribute('aria-hidden');
    expect(button).not.toHaveAttribute('aria-hidden');

    expect(() => getAllByRole('checkbox')).not.toThrow();
    expect(() => getByRole('button')).not.toThrow();
  });

  it('should not overwrite an existing aria-hidden prop', function () {
    let {getByRole, getAllByRole} = render(
      <>
        <input type="checkbox" aria-hidden="true" />
        <button>Button</button>
        <input type="checkbox" />
      </>
    );

    let checkboxes = getAllByRole('checkbox');
    let button = getByRole('button');

    let revert = ariaHideOutside([button]);

    expect(checkboxes).toHaveLength(1);
    expect(checkboxes[0]).toHaveAttribute('aria-hidden', 'true');
    expect(button).not.toHaveAttribute('aria-hidden');

    expect(() => getAllByRole('checkbox')).toThrow();
    expect(() => getByRole('button')).not.toThrow();

    revert();

    checkboxes = getAllByRole('checkbox');
    expect(checkboxes).toHaveLength(1);
    expect(checkboxes[0]).not.toHaveAttribute('aria-hidden');
    expect(button).not.toHaveAttribute('aria-hidden');

    expect(() => getAllByRole('checkbox')).not.toThrow();
    expect(() => getByRole('button')).not.toThrow();
  });

  it('should handle when a new element is added outside while active', async function () {
    let Test = props => (
      <>
        {props.show && <input type="checkbox" />}
        <button>Button</button>
        {props.show && <input type="checkbox" />}
      </>
    );

    let {getByRole, getAllByRole, rerender} = render(<Test />);

    let button = getByRole('button');
    expect(() => getAllByRole('checkbox')).toThrow();

    let revert = ariaHideOutside([button]);

    rerender(<Test show />);

    // MutationObserver is async
    await waitFor(() => expect(() => getAllByRole('checkbox')).toThrow());
    expect(() => getByRole('button')).not.toThrow();

    revert();

    expect(getAllByRole('checkbox')).toHaveLength(2);
  });

  it('should handle when a new element is added to an already hidden container', async function () {
    let Test = props => (
      <>
        <div data-testid="test">
          {props.show && <input type="checkbox" />}
        </div>
        <button>Button</button>
        {props.show && <input type="checkbox" />}
      </>
    );

    let {getByRole, getAllByRole, getByTestId, rerender} = render(<Test />);

    let button = getByRole('button');
    let test = getByTestId('test');
    expect(() => getAllByRole('checkbox')).toThrow();

    let revert = ariaHideOutside([button]);

    expect(test).toHaveAttribute('aria-hidden');

    rerender(<Test show />);

    // MutationObserver is async
    await waitFor(() => expect(() => getAllByRole('checkbox')).toThrow());
    expect(() => getByRole('button')).not.toThrow();

    let checkboxes = getAllByRole('checkbox', {hidden: true});
    expect(test).toHaveAttribute('aria-hidden');
    expect(checkboxes[0]).not.toHaveAttribute('aria-hidden');
    expect(checkboxes[1]).toHaveAttribute('aria-hidden', 'true');

    revert();

    expect(getAllByRole('checkbox')).toHaveLength(2);
  });

  it('should handle when a new element is added along with a top layer element', async function () {
    let Test = props => (
      <>
        <button>Button</button>
        {props.show && <div>
          <div role="alert" data-react-aria-top-layer="true">Top layer</div>
          <input type="checkbox" />
        </div>}
      </>
    );

    let {getByRole, queryByRole, getAllByRole, rerender} = render(<Test />);

    let button = getByRole('button');
    expect(queryByRole('checkbox')).toBeNull();

    let revert = ariaHideOutside([button]);

    rerender(<Test show />);

    // MutationObserver is async
    await waitFor(() => queryByRole('checkbox') == null);
    expect(queryByRole('button')).not.toBeNull();
    expect(getByRole('alert')).toHaveTextContent('Top layer');

    revert();

    expect(getAllByRole('checkbox')).toHaveLength(1);
  });

  it('should handle when a new element is added inside a target element', async function () {
    let Test = props => (
      <>
        <input type="checkbox" />
        <div data-testid="test">
          <button>Button</button>
          {props.show && <input type="radio" />}
        </div>
        <input type="checkbox" />
      </>
    );

    let {queryByRole, getByRole, getAllByRole, getByTestId, rerender} = render(<Test />);

    let test = getByTestId('test');
    let revert = ariaHideOutside([test]);

    expect(() => getAllByRole('checkbox')).toThrow();
    expect(queryByRole('radio')).toBeNull();
    expect(queryByRole('button')).not.toBeNull();
    expect(() => getByTestId('test')).not.toThrow();

    rerender(<Test show />);

    // Wait for mutation observer tick
    await Promise.resolve();
    expect(() => getAllByRole('checkbox')).toThrow();
    expect(() => getByRole('radio')).not.toThrow();
    expect(() => getByRole('button')).not.toThrow();
    expect(() => getByTestId('test')).not.toThrow();

    revert();

    expect(() => getAllByRole('checkbox')).not.toThrow();
    expect(() => getByRole('radio')).not.toThrow();
    expect(() => getByRole('button')).not.toThrow();
    expect(() => getByTestId('test')).not.toThrow();
  });

  it('should handle when a new element is added and then reparented', async function () {

    let Test = () => {
      const ref = useRef(null);
      const mutate = () => {
        let parent = document.createElement('ul');
        let child = document.createElement('li');
        ref.current.append(parent);
        parent.appendChild(child);
        parent.remove(); // this results in a mutation record for a disconnected ul with a connected li (through the new ul parent) in `addedNodes`
        let newParent = document.createElement('ul');
        newParent.appendChild(child);
        ref.current.append(newParent);
      };

      return (
        <>
          <div data-testid="test" ref={ref}>
            <button onClick={mutate}>Mutate</button>
          </div>
        </>
      );
    };

    let {queryByRole, getAllByRole, getByTestId} = render(<Test />);

    ariaHideOutside([getByTestId('test')]);

    queryByRole('button').click();
    await Promise.resolve(); // Wait for mutation observer tick

    expect(getAllByRole('listitem')).toHaveLength(1);
  });

  it('should handle when a new element is added and then reparented to a hidden container', async function () {

    let Test = () => {
      const ref = useRef(null);
      const mutate = () => {
        let parent = document.createElement('ul');
        let child = document.createElement('li');
        ref.current.append(parent);
        parent.appendChild(child);
        parent.remove(); // this results in a mutation record for a disconnected ul with a connected li (through the new ul parent) in `addedNodes`
        let newParent = document.createElement('ul');
        newParent.appendChild(child);
        ref.current.append(newParent);
      };

      return (
        <>
          <div data-testid="test">
            <button onClick={mutate}>Mutate</button>
          </div>
          <div data-testid="sibling" ref={ref} />
        </>
      );
    };

    let {queryByRole, queryAllByRole, getByTestId} = render(<Test />);

    ariaHideOutside([getByTestId('test')]);

    queryByRole('button').click();
    await Promise.resolve(); // Wait for mutation observer tick

    expect(queryAllByRole('listitem')).toHaveLength(0);
  });


  it('work when called multiple times', function () {
    let {getByRole, getAllByRole} = render(
      <>
        <input type="checkbox" />
        <input type="radio" />
        <button>Button</button>
        <input type="radio" />
        <input type="checkbox" />
      </>
    );

    let radios = getAllByRole('radio');
    let button = getByRole('button');

    let revert1 = ariaHideOutside([button, ...radios]);

    expect(() => getAllByRole('checkbox')).toThrow();
    expect(() => getAllByRole('radio')).not.toThrow();
    expect(() => getByRole('button')).not.toThrow();

    let revert2 = ariaHideOutside([button]);

    expect(() => getAllByRole('checkbox')).toThrow();
    expect(() => getAllByRole('radio')).toThrow();
    expect(() => getByRole('button')).not.toThrow();

    revert2();

    expect(() => getAllByRole('checkbox')).toThrow();
    expect(() => getAllByRole('radio')).not.toThrow();
    expect(() => getByRole('button')).not.toThrow();

    revert1();

    expect(() => getAllByRole('checkbox')).not.toThrow();
    expect(() => getAllByRole('radio')).not.toThrow();
    expect(() => getByRole('button')).not.toThrow();
  });

  it('work when called multiple times and restored out of order', function () {
    let {getByRole, getAllByRole} = render(
      <>
        <input type="checkbox" />
        <input type="radio" />
        <button>Button</button>
        <input type="radio" />
        <input type="checkbox" />
      </>
    );

    let radios = getAllByRole('radio');
    let button = getByRole('button');

    let revert1 = ariaHideOutside([button, ...radios]);

    expect(() => getAllByRole('checkbox')).toThrow();
    expect(() => getAllByRole('radio')).not.toThrow();
    expect(() => getByRole('button')).not.toThrow();

    let revert2 = ariaHideOutside([button]);

    expect(() => getAllByRole('checkbox')).toThrow();
    expect(() => getAllByRole('radio')).toThrow();
    expect(() => getByRole('button')).not.toThrow();

    revert1();

    expect(() => getAllByRole('checkbox')).toThrow();
    expect(() => getAllByRole('radio')).toThrow();
    expect(() => getByRole('button')).not.toThrow();

    revert2();

    expect(() => getAllByRole('checkbox')).not.toThrow();
    expect(() => getAllByRole('radio')).not.toThrow();
    expect(() => getByRole('button')).not.toThrow();
  });

  it('should hide everything except the provided element [row]', function () {
    let {getAllByRole, getByTestId} = render(
      <div role="grid">
        <div role="row">
          <div role="gridcell">
            <span data-testid="test-span">
              Cell 1
            </span></div>
        </div>
        <div role="row">
          <div role="gridcell">Cell 2</div>
        </div>
      </div>
    );

    let cells = getAllByRole('gridcell');
    let rows = getAllByRole('row');
    let span = getByTestId('test-span');

    let revert = ariaHideOutside([rows[1]]);

    // Applies aria-hidden to the row and cell despite recursive nature of aria-hidden
    // for https://bugs.webkit.org/show_bug.cgi?id=222623
    expect(rows[0]).toHaveAttribute('aria-hidden', 'true');
    expect(cells[0]).toHaveAttribute('aria-hidden', 'true');
    expect(span).not.toHaveAttribute('aria-hidden');
    expect(rows[1]).not.toHaveAttribute('aria-hidden', 'true');
    expect(cells[1]).not.toHaveAttribute('aria-hidden', 'true');

    revert();

    expect(rows[0]).not.toHaveAttribute('aria-hidden', 'true');
    expect(cells[0]).not.toHaveAttribute('aria-hidden', 'true');
    expect(rows[1]).not.toHaveAttribute('aria-hidden', 'true');
    expect(cells[1]).not.toHaveAttribute('aria-hidden', 'true');
    expect(span).not.toHaveAttribute('aria-hidden');
  });

  it('should unhide after item reorder', async function () {
    function Item(props) {
      return (
        <div role="presentation">
          <div data-testid={props.testid} role="row">
            <div role="gridcell" />
          </div>
        </div>
      );
    }

    function Test() {
      let [count, setCount] = useState(0);
      let items = ['row1', 'row2', 'row3', 'row4', 'row5'];
      if (count === 1) {
        items = ['row2', 'row1', 'row3', 'row4', 'row5'];
      } else if (count === 2) {
        items = ['row2', 'row3', 'row1', 'row4', 'row5'];
      }

      return (
        <>
          <button onClick={() => setCount((old) => old + 1)}>press</button>
          {items.map((item) => <Item testid={item} key={item} />)}
        </>

      );
    }

    let {getByRole, getByTestId} = render(
      <Test />
    );

    let button = getByRole('button');
    let row = getByTestId('row1');
    let revert = ariaHideOutside([button]);

    act(() => button.click());
    await Promise.resolve();
    act(() => button.click());
    await Promise.resolve();
    revert();
    expect(row.parentElement).not.toHaveAttribute('aria-hidden', 'true');
  });

  it('does not walk into shadow roots when shadowDOM is off', function () {
    let host = document.createElement('div');
    document.body.appendChild(host);
    let shadowRoot = host.attachShadow({mode: 'open'});
    let shadowSibling = document.createElement('button');
    shadowRoot.appendChild(shadowSibling);
    let button = document.createElement('button');
    document.body.appendChild(button);

    let revert = ariaHideOutside([button]);

    expect(host).toHaveAttribute('aria-hidden', 'true');
    expect(shadowSibling).not.toHaveAttribute('aria-hidden');

    revert();
    host.remove();
    button.remove();
  });

  it('hides a root element that is a child of a target when shadowDOM is off', function () {
    let target = document.createElement('div');
    document.body.appendChild(target);
    let child = document.createElement('button');
    target.appendChild(child);

    let revert = ariaHideOutside([target], {root: child});

    expect(child).toHaveAttribute('aria-hidden', 'true');
    expect(target).not.toHaveAttribute('aria-hidden');

    revert();
    expect(child).not.toHaveAttribute('aria-hidden');
    target.remove();
  });
});

describe('shadow DOM', function () {
  let undos = [];
  let nodes = [];

  beforeAll(function () {
    enableShadowDOM();
  });

  afterEach(function () {
    for (let undo of undos.reverse()) {
      undo();
    }
    undos = [];
    for (let node of nodes) {
      node.remove();
    }
    nodes = [];
  });

  // Wraps ariaHideOutside so that undoing twice is safe and cleanup always runs.
  function hide(targets, options) {
    let revert = ariaHideOutside(targets, options);
    let undone = false;
    let undo = () => {
      if (!undone) {
        undone = true;
        revert();
      }
    };
    undos.push(undo);
    return undo;
  }

  function createHost(parent = document.body) {
    let host = document.createElement('div');
    parent.appendChild(host);
    nodes.push(host);
    return {host, shadowRoot: host.attachShadow({mode: 'open'})};
  }

  function createButton(label, parent) {
    let button = document.createElement('button');
    button.textContent = label;
    parent.appendChild(button);
    nodes.push(button);
    return button;
  }

  it('hides siblings at every shadow level but not the hosts on the path to the target', function () {
    let outer = createButton('outer', document.body);
    let {host: hostA, shadowRoot: shadowA} = createHost();
    let siblingA = createButton('sibling-a', shadowA);
    let {host: hostB, shadowRoot: shadowB} = createHost(shadowA);
    let siblingB = createButton('sibling-b', shadowB);
    let target = createButton('target', shadowB);

    hide([target]);

    expect(outer).toHaveAttribute('aria-hidden', 'true');
    expect(siblingA).toHaveAttribute('aria-hidden', 'true');
    expect(siblingB).toHaveAttribute('aria-hidden', 'true');
    expect(hostA).not.toHaveAttribute('aria-hidden');
    expect(hostB).not.toHaveAttribute('aria-hidden');
    expect(target).not.toHaveAttribute('aria-hidden');
  });

  it('hides a sibling that is a shadow host without descending into it', function () {
    let {host: otherHost, shadowRoot: otherShadow} = createHost();
    createButton('inside-other', otherShadow);
    let {shadowRoot} = createHost();
    let target = createButton('target', shadowRoot);

    hide([target]);

    expect(otherHost).toHaveAttribute('aria-hidden', 'true');
    expect(target).not.toHaveAttribute('aria-hidden');
  });

  it('hides light DOM siblings of the host of a target inside a shadow root', function () {
    let {host, shadowRoot} = createHost();
    let lightSibling = createButton('light-sibling', document.body);
    let target = createButton('target', shadowRoot);

    hide([target]);

    expect(lightSibling).toHaveAttribute('aria-hidden', 'true');
    expect(host).not.toHaveAttribute('aria-hidden');
    expect(target).not.toHaveAttribute('aria-hidden');
  });

  it('hides nodes added to enclosing shadow roots but keeps targets and live announcers visible', async function () {
    let {host, shadowRoot} = createHost();
    let container = document.createElement('div');
    shadowRoot.appendChild(container);
    let target = createButton('target', container);
    let existingAnnouncer = document.createElement('div');
    existingAnnouncer.dataset.liveAnnouncer = 'true';
    shadowRoot.appendChild(existingAnnouncer);

    hide([target]);

    expect(existingAnnouncer).not.toHaveAttribute('aria-hidden');

    let addedToRoot = createButton('added-root', shadowRoot);
    let addedToContainer = createButton('added-container', container);
    let addedToTarget = createButton('added-target', target);
    let announcer = document.createElement('div');
    announcer.dataset.liveAnnouncer = 'true';
    shadowRoot.appendChild(announcer);
    let topLayer = document.createElement('div');
    topLayer.dataset.reactAriaTopLayer = 'true';
    container.appendChild(topLayer);

    await Promise.resolve();

    expect(addedToRoot).toHaveAttribute('aria-hidden', 'true');
    expect(addedToContainer).toHaveAttribute('aria-hidden', 'true');
    expect(addedToTarget).not.toHaveAttribute('aria-hidden');
    expect(announcer).not.toHaveAttribute('aria-hidden');
    expect(topLayer).not.toHaveAttribute('aria-hidden');
    expect(target).not.toHaveAttribute('aria-hidden');
    expect(host).not.toHaveAttribute('aria-hidden');
  });

  it('keeps targets in different roots visible and hides siblings and later additions in both', async function () {
    let {host: hostA, shadowRoot: shadowA} = createHost();
    let input = createButton('input', shadowA);
    let siblingA = createButton('sibling-a', shadowA);
    let {host: hostB, shadowRoot: shadowB} = createHost();
    let popover = createButton('popover', shadowB);
    let siblingB = createButton('sibling-b', shadowB);
    let lightTarget = createButton('light-target', document.body);
    let lightSibling = createButton('light-sibling', document.body);

    hide([input, popover, lightTarget]);

    expect(input).not.toHaveAttribute('aria-hidden');
    expect(popover).not.toHaveAttribute('aria-hidden');
    expect(lightTarget).not.toHaveAttribute('aria-hidden');
    expect(hostA).not.toHaveAttribute('aria-hidden');
    expect(hostB).not.toHaveAttribute('aria-hidden');
    expect(siblingA).toHaveAttribute('aria-hidden', 'true');
    expect(siblingB).toHaveAttribute('aria-hidden', 'true');
    expect(lightSibling).toHaveAttribute('aria-hidden', 'true');

    let laterA = createButton('later-a', shadowA);
    let laterB = createButton('later-b', shadowB);

    await Promise.resolve();

    expect(laterA).toHaveAttribute('aria-hidden', 'true');
    expect(laterB).toHaveAttribute('aria-hidden', 'true');
    expect(input).not.toHaveAttribute('aria-hidden');
    expect(popover).not.toHaveAttribute('aria-hidden');
  });

  it('keeps a target inside another target shadow root visible when both are active', function () {
    let {host: outerHost, shadowRoot} = createHost();
    let innerTarget = createButton('inner-target', shadowRoot);
    let bodySibling = createButton('body-sibling', document.body);

    let undoOuter = hide([outerHost]);

    expect(outerHost).not.toHaveAttribute('aria-hidden');
    expect(innerTarget).not.toHaveAttribute('aria-hidden');
    expect(bodySibling).toHaveAttribute('aria-hidden', 'true');

    let undoInner = hide([innerTarget]);

    expect(outerHost).not.toHaveAttribute('aria-hidden');
    expect(innerTarget).not.toHaveAttribute('aria-hidden');
    expect(bodySibling).toHaveAttribute('aria-hidden', 'true');

    undoInner();

    expect(outerHost).not.toHaveAttribute('aria-hidden');
    expect(innerTarget).not.toHaveAttribute('aria-hidden');
    expect(bodySibling).toHaveAttribute('aria-hidden', 'true');

    undoOuter();

    expect(bodySibling).not.toHaveAttribute('aria-hidden');
    expect(innerTarget).not.toHaveAttribute('aria-hidden');
  });

  it('restores shadow root elements and stops observing them on undo', async function () {
    let {shadowRoot} = createHost();
    let target = createButton('target', shadowRoot);
    let existingHidden = createButton('existing-hidden', shadowRoot);
    existingHidden.setAttribute('aria-hidden', 'true');
    let sibling = createButton('sibling', shadowRoot);

    let undo = hide([target]);

    expect(sibling).toHaveAttribute('aria-hidden', 'true');

    undo();

    expect(sibling).not.toHaveAttribute('aria-hidden');
    expect(existingHidden).toHaveAttribute('aria-hidden', 'true');

    let added = createButton('added', shadowRoot);

    await Promise.resolve();

    expect(added).not.toHaveAttribute('aria-hidden');
  });

  it('resumes observing the outer shadow root when the inner call is undone', async function () {
    let {shadowRoot: shadowA} = createHost();
    let targetA = createButton('target-a', shadowA);
    let {shadowRoot: shadowB} = createHost();
    let targetB = createButton('target-b', shadowB);

    let undoOuter = hide([targetA]);
    let undoInner = hide([targetB]);
    undoInner();

    let added = createButton('added', shadowA);

    await Promise.resolve();

    expect(added).toHaveAttribute('aria-hidden', 'true');
    expect(targetA).not.toHaveAttribute('aria-hidden');

    undoOuter();
  });

  it('keeps observing the inner shadow root when the outer call is undone first', async function () {
    let {host: hostA, shadowRoot: shadowA} = createHost();
    let targetA = createButton('target-a', shadowA);
    let {shadowRoot: shadowB} = createHost();
    let targetB = createButton('target-b', shadowB);

    let undoOuter = hide([targetA]);
    let undoInner = hide([targetB]);
    undoOuter();

    let added = createButton('added', shadowB);

    await Promise.resolve();

    expect(added).toHaveAttribute('aria-hidden', 'true');
    expect(targetB).not.toHaveAttribute('aria-hidden');
    expect(hostA).toHaveAttribute('aria-hidden', 'true');

    undoInner();

    expect(hostA).not.toHaveAttribute('aria-hidden');
    expect(added).not.toHaveAttribute('aria-hidden');
  });

  it('keeps an element hidden by two calls hidden until both are undone', function () {
    let {shadowRoot: shadowA} = createHost();
    let targetA = createButton('target-a', shadowA);
    let shared = createButton('shared', shadowA);
    let {shadowRoot: shadowB} = createHost();
    let targetB = createButton('target-b', shadowB);

    let undoOuter = hide([targetA]);
    let undoInner = hide([targetB]);

    expect(shared).toHaveAttribute('aria-hidden', 'true');

    undoInner();

    expect(shared).toHaveAttribute('aria-hidden', 'true');

    undoOuter();

    expect(shared).not.toHaveAttribute('aria-hidden');
  });

  it('does not hide an element passed to keepVisible when it is added to a shadow root', async function () {
    let {shadowRoot} = createHost();
    let container = document.createElement('div');
    shadowRoot.appendChild(container);
    let target = createButton('target', container);

    hide([target]);

    let popover = document.createElement('button');
    keepVisible(popover);
    container.appendChild(popover);

    await Promise.resolve();

    expect(popover).not.toHaveAttribute('aria-hidden');
    expect(target).not.toHaveAttribute('aria-hidden');
  });

  // Adds a <section> containing a <slot>, plus a sibling <span>, to the shadow root.
  function createSlotContainer(shadowRoot) {
    let section = document.createElement('section');
    let slot = document.createElement('slot');
    section.appendChild(slot);
    shadowRoot.appendChild(section);
    let sibling = document.createElement('span');
    shadowRoot.appendChild(sibling);
    return {section, slot, sibling};
  }

  it('does not hide a target slotted into a shadow root, or the slot and container on its flat tree path', function () {
    let {host, shadowRoot} = createHost();
    let {section, slot, sibling} = createSlotContainer(shadowRoot);
    let target = createButton('target', host);

    hide([target]);

    expect(section).not.toHaveAttribute('aria-hidden');
    expect(slot).not.toHaveAttribute('aria-hidden');
    expect(sibling).toHaveAttribute('aria-hidden', 'true');
    expect(host).not.toHaveAttribute('aria-hidden');
    expect(target).not.toHaveAttribute('aria-hidden');
  });

  it('does not hide a target nested inside a slotted element', function () {
    let {host, shadowRoot} = createHost();
    let {section, slot, sibling} = createSlotContainer(shadowRoot);
    let slotted = document.createElement('div');
    host.appendChild(slotted);
    let target = createButton('target', slotted);

    hide([target]);

    expect(section).not.toHaveAttribute('aria-hidden');
    expect(slot).not.toHaveAttribute('aria-hidden');
    expect(sibling).toHaveAttribute('aria-hidden', 'true');
    expect(slotted).not.toHaveAttribute('aria-hidden');
    expect(host).not.toHaveAttribute('aria-hidden');
    expect(target).not.toHaveAttribute('aria-hidden');
  });

  it('hides nodes added to a shadow root that a slotted target is assigned to', async function () {
    let {host, shadowRoot} = createHost();
    let section = document.createElement('section');
    section.appendChild(document.createElement('slot'));
    shadowRoot.appendChild(section);
    let target = createButton('target', host);

    hide([target]);

    let added = document.createElement('i');
    shadowRoot.appendChild(added);

    await Promise.resolve();

    expect(added).toHaveAttribute('aria-hidden', 'true');
    expect(target).not.toHaveAttribute('aria-hidden');
    expect(host).not.toHaveAttribute('aria-hidden');
  });

  it('does not hide light DOM or shadow children of a shadow host target', function () {
    let {host, shadowRoot} = createHost();
    let lightChild = createButton('light-child', host);
    let shadowChild = createButton('shadow-child', shadowRoot);
    let otherTarget = createButton('other-target', document.body);

    hide([host, otherTarget]);

    expect(host).not.toHaveAttribute('aria-hidden');
    expect(lightChild).not.toHaveAttribute('aria-hidden');
    expect(shadowChild).not.toHaveAttribute('aria-hidden');
    expect(otherTarget).not.toHaveAttribute('aria-hidden');
  });

  it('does not hide content added to a shadow root that encloses the root option', async function () {
    let {host, shadowRoot} = createHost();
    let container = document.createElement('div');
    shadowRoot.appendChild(container);
    let target = createButton('target', container);

    hide([target], {root: container});

    let later = createButton('later', shadowRoot);
    shadowRoot.insertBefore(later, container);

    await Promise.resolve();

    expect(later).not.toHaveAttribute('aria-hidden');
    expect(target).not.toHaveAttribute('aria-hidden');
    expect(host).not.toHaveAttribute('aria-hidden');
  });

  it('keeps live announcers in the shadow root of the root option visible', function () {
    let {host, shadowRoot} = createHost();
    let target = createButton('target', shadowRoot);
    let announcer = document.createElement('div');
    announcer.dataset.liveAnnouncer = 'true';
    shadowRoot.appendChild(announcer);

    hide([target], {root: host});

    expect(announcer).not.toHaveAttribute('aria-hidden');
    expect(target).not.toHaveAttribute('aria-hidden');
  });

  it('does not hide a target slotted through two shadow hosts', function () {
    let {host: outerHost, shadowRoot: outerShadow} = createHost();
    let outer = createSlotContainer(outerShadow);
    let innerHost = document.createElement('div');
    outerHost.appendChild(innerHost);
    nodes.push(innerHost);
    let innerShadow = innerHost.attachShadow({mode: 'open'});
    let inner = createSlotContainer(innerShadow);
    let target = createButton('target', innerHost);

    hide([target]);

    expect(outer.section).not.toHaveAttribute('aria-hidden');
    expect(outer.slot).not.toHaveAttribute('aria-hidden');
    expect(outer.sibling).toHaveAttribute('aria-hidden', 'true');
    expect(innerHost).not.toHaveAttribute('aria-hidden');
    expect(inner.section).not.toHaveAttribute('aria-hidden');
    expect(inner.slot).not.toHaveAttribute('aria-hidden');
    expect(inner.sibling).toHaveAttribute('aria-hidden', 'true');
    expect(outerHost).not.toHaveAttribute('aria-hidden');
    expect(target).not.toHaveAttribute('aria-hidden');
  });
});

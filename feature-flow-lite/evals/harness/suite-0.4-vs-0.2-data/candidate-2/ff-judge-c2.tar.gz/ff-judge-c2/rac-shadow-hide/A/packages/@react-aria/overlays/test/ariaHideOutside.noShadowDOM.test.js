/*
 * Copyright 2026 Adobe. All rights reserved.
 * This file is licensed to you under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License. You may obtain a copy
 * of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software distributed under
 * the License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR REPRESENTATIONS
 * OF ANY KIND, either express or implied. See the License for the specific language
 * governing permissions and limitations under the License.
 */

import {ariaHideOutside} from '../src';
import {shadowDOM} from '@react-stately/flags';

// Shadow DOM is off in this file (the flag is module-global and never enabled here).
// With the flag off, shadow roots are neither walked nor observed.

// Creates an element with an id and appends it to parent.
function make(parent, id, tag = 'div') {
  let el = document.createElement(tag);
  el.id = id;
  parent.appendChild(el);
  return el;
}

describe('ariaHideOutside without Shadow DOM', function () {
  afterEach(() => {
    document.body.innerHTML = '';
  });

  it('does not walk or observe shadow roots', async function () {
    expect(shadowDOM()).toBe(false);

    let outside = make(document.body, 'outside', 'button');
    let host = make(document.body, 'host');
    let shadow = host.attachShadow({mode: 'open'});
    let shadowSibling = make(shadow, 'shadow-sibling', 'input');
    let target = make(shadow, 'target', 'button');

    let revert = ariaHideOutside([target]);

    // Old light-DOM behavior: contains() does not cross the shadow boundary, so the root itself
    // is hidden, and nothing inside the shadow root is walked or hidden on its own.
    expect(document.body).toHaveAttribute('aria-hidden', 'true');
    expect(outside).not.toHaveAttribute('aria-hidden');
    expect(host).not.toHaveAttribute('aria-hidden');
    expect(shadowSibling).not.toHaveAttribute('aria-hidden');

    let added = make(shadow, 'added', 'input');
    // MutationObserver is async
    await Promise.resolve();
    expect(added).not.toHaveAttribute('aria-hidden');

    revert();

    expect(document.body).not.toHaveAttribute('aria-hidden');
    expect(outside).not.toHaveAttribute('aria-hidden');
    expect(host).not.toHaveAttribute('aria-hidden');
  });
});

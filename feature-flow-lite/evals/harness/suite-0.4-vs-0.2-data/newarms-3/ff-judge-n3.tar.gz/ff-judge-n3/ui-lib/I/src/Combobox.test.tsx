import { render, screen } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { useState } from "react";
import { describe, expect, it, vi } from "vitest";
import { Combobox, type ComboboxOption } from "./Combobox";

const fruits: ComboboxOption[] = [
  { value: "apple", label: "Apple" },
  { value: "apricot", label: "Apricot", disabled: true },
  { value: "banana", label: "Banana" },
  { value: "blueberry", label: "Blueberry" },
];

function Controlled({
  options = fruits,
  initial = null,
  onChange,
}: {
  options?: ComboboxOption[];
  initial?: string | null;
  onChange?: (value: string | null) => void;
}) {
  const [value, setValue] = useState<string | null>(initial);
  return (
    <Combobox
      label="Fruit"
      placeholder="Search fruit"
      options={options}
      value={value}
      onChange={(next) => {
        setValue(next);
        onChange?.(next);
      }}
    />
  );
}

const input = () => screen.getByRole("combobox", { name: "Fruit" });
const option = (name: string) => screen.getByRole("option", { name });
const optionNames = () => screen.getAllByRole("option").map((element) => element.textContent);

describe("Combobox", () => {
  it("is labelled by its label, passes the placeholder through and starts closed", () => {
    render(<Controlled />);
    expect(input()).toHaveAttribute("aria-expanded", "false");
    expect(input()).toHaveAttribute("aria-autocomplete", "list");
    expect(input()).toHaveAttribute("placeholder", "Search fruit");
    expect(input()).toHaveValue("");
    expect(screen.queryAllByRole("option")).toHaveLength(0);
  });

  it("wires the listbox: aria-controls, accessible name and option states", async () => {
    const user = userEvent.setup();
    render(<Controlled initial="banana" />);
    await user.click(input());
    await user.keyboard("{ArrowDown}");
    const listbox = document.querySelector<HTMLElement>('[role="listbox"]');
    expect(listbox).not.toBeNull();
    expect(input()).toHaveAttribute("aria-controls", listbox?.id);
    expect(listbox).toHaveAttribute("aria-labelledby", screen.getByText("Fruit").id);
    expect(option("Banana")).toHaveAttribute("aria-selected", "true");
    expect(option("Apple")).toHaveAttribute("aria-selected", "false");
    expect(option("Apricot")).toHaveAttribute("aria-disabled", "true");
  });

  it("filters options case-insensitively as the user types, and clearing shows all", async () => {
    const user = userEvent.setup();
    render(<Controlled />);
    await user.type(input(), "BLU");
    expect(optionNames()).toEqual(["Blueberry"]);
    await user.clear(input());
    expect(optionNames()).toEqual(["Apple", "Apricot", "Banana", "Blueberry"]);
    await user.type(input(), "ap");
    expect(optionNames()).toEqual(["Apple", "Apricot"]);
  });

  it("treats regex metacharacters literally and shows No results when nothing matches", async () => {
    const user = userEvent.setup();
    render(<Controlled />);
    await user.type(input(), "(.*");
    expect(screen.queryAllByRole("option")).toHaveLength(0);
    expect(screen.getByRole("status")).toHaveTextContent("No results");
    await user.clear(input());
    expect(screen.queryByRole("status")).not.toBeInTheDocument();
  });

  it("shows No results when there are no options at all, and Enter does nothing", async () => {
    const user = userEvent.setup();
    const onChange = vi.fn();
    render(<Controlled options={[]} onChange={onChange} />);
    await user.click(input());
    await user.keyboard("{ArrowDown}");
    expect(screen.getByRole("status")).toHaveTextContent("No results");
    await user.keyboard("{Enter}");
    expect(onChange).not.toHaveBeenCalled();
  });

  it("opens with ArrowDown and moves the active option via aria-activedescendant, skipping disabled options and wrapping", async () => {
    const user = userEvent.setup();
    render(<Controlled />);
    await user.click(input());
    expect(input()).not.toHaveAttribute("aria-activedescendant");
    await user.keyboard("{ArrowDown}");
    expect(input()).toHaveAttribute("aria-expanded", "true");
    expect(input()).toHaveAttribute("aria-activedescendant", option("Apple").id);
    expect(input()).toHaveFocus();
    await user.keyboard("{ArrowDown}");
    expect(input()).toHaveAttribute("aria-activedescendant", option("Banana").id);
    await user.keyboard("{ArrowDown}");
    expect(input()).toHaveAttribute("aria-activedescendant", option("Blueberry").id);
    await user.keyboard("{ArrowDown}");
    expect(input()).toHaveAttribute("aria-activedescendant", option("Apple").id);
    await user.keyboard("{ArrowUp}");
    expect(input()).toHaveAttribute("aria-activedescendant", option("Blueberry").id);
  });

  it("selects the active option with Enter, sets the text, and closes", async () => {
    const user = userEvent.setup();
    const onChange = vi.fn();
    render(<Controlled onChange={onChange} />);
    await user.click(input());
    await user.keyboard("{ArrowDown}{ArrowDown}{Enter}");
    expect(onChange).toHaveBeenCalledTimes(1);
    expect(onChange).toHaveBeenCalledWith("banana");
    expect(input()).toHaveValue("Banana");
    expect(input()).toHaveAttribute("aria-expanded", "false");
  });

  it("does nothing on Enter when no option is active", async () => {
    const user = userEvent.setup();
    const onChange = vi.fn();
    render(<Controlled onChange={onChange} />);
    await user.type(input(), "ban");
    await user.keyboard("{Enter}");
    expect(onChange).not.toHaveBeenCalled();
    expect(input()).toHaveValue("ban");
  });

  it("resets the active option when the filter changes", async () => {
    const user = userEvent.setup();
    render(<Controlled />);
    await user.click(input());
    await user.keyboard("{ArrowDown}{ArrowDown}");
    expect(input()).toHaveAttribute("aria-activedescendant", option("Banana").id);
    await user.type(input(), "e");
    expect(input()).not.toHaveAttribute("aria-activedescendant");
  });

  it("selects an option on click", async () => {
    const user = userEvent.setup();
    const onChange = vi.fn();
    render(<Controlled onChange={onChange} />);
    await user.type(input(), "blue");
    await user.click(option("Blueberry"));
    expect(onChange).toHaveBeenCalledWith("blueberry");
    expect(input()).toHaveValue("Blueberry");
    expect(input()).toHaveAttribute("aria-expanded", "false");
  });

  it("does nothing when a disabled option is clicked", async () => {
    const user = userEvent.setup();
    const onChange = vi.fn();
    render(<Controlled onChange={onChange} />);
    await user.type(input(), "apr");
    await user.click(option("Apricot"));
    expect(onChange).not.toHaveBeenCalled();
    expect(input()).toHaveValue("apr");
    expect(input()).toHaveAttribute("aria-expanded", "true");
  });

  it("closes on Escape without selecting and leaves the value unchanged", async () => {
    const user = userEvent.setup();
    const onChange = vi.fn();
    render(<Controlled initial="apple" onChange={onChange} />);
    await user.clear(input());
    await user.type(input(), "ban");
    await user.keyboard("{Escape}");
    expect(onChange).not.toHaveBeenCalled();
    expect(input()).toHaveAttribute("aria-expanded", "false");
    expect(input()).toHaveValue("Apple");
  });

  it("stops Escape from reaching ancestors only while the listbox is open", async () => {
    const user = userEvent.setup();
    const onKeyDown = vi.fn();
    const escapes = () => onKeyDown.mock.calls.filter(([event]) => event.key === "Escape").length;
    render(
      <div onKeyDown={onKeyDown}>
        <Controlled />
      </div>,
    );
    await user.click(input());
    await user.keyboard("{Escape}");
    expect(escapes()).toBe(1);
    await user.keyboard("{ArrowDown}");
    await user.keyboard("{Escape}");
    expect(escapes()).toBe(1);
  });

  it("closes on blur and reverts the text to the selected label", async () => {
    const user = userEvent.setup();
    render(<Controlled initial="apple" />);
    await user.type(input(), "ban");
    await user.tab();
    expect(input()).toHaveAttribute("aria-expanded", "false");
    expect(input()).toHaveValue("Apple");
  });

  it("clears the value once when the text is emptied and the input is blurred", async () => {
    const user = userEvent.setup();
    const onChange = vi.fn();
    render(<Controlled initial="apple" onChange={onChange} />);
    expect(input()).toHaveValue("Apple");
    await user.clear(input());
    expect(onChange).not.toHaveBeenCalled();
    await user.tab();
    expect(onChange).toHaveBeenCalledTimes(1);
    expect(onChange).toHaveBeenCalledWith(null);
    expect(input()).toHaveValue("");
  });

  it("clears the value once when Enter is pressed on empty text with no active option", async () => {
    const user = userEvent.setup();
    const onChange = vi.fn();
    render(<Controlled initial="apple" onChange={onChange} />);
    await user.clear(input());
    await user.keyboard("{Enter}");
    expect(onChange).toHaveBeenCalledTimes(1);
    expect(onChange).toHaveBeenCalledWith(null);
    expect(input()).toHaveValue("");
  });

  it("keeps the displayed label when the parent ignores onChange", async () => {
    const user = userEvent.setup();
    const onChange = vi.fn();
    render(<Combobox label="Fruit" options={fruits} value="apple" onChange={onChange} />);
    await user.clear(input());
    await user.type(input(), "ban");
    await user.click(option("Banana"));
    expect(onChange).toHaveBeenCalledWith("banana");
    expect(input()).toHaveValue("Apple");
  });

  it("shows the label of a value changed from outside, including to null", async () => {
    const { rerender } = render(<Combobox label="Fruit" options={fruits} value="apple" onChange={() => {}} />);
    expect(input()).toHaveValue("Apple");
    rerender(<Combobox label="Fruit" options={fruits} value="banana" onChange={() => {}} />);
    expect(input()).toHaveValue("Banana");
    rerender(<Combobox label="Fruit" options={fruits} value={null} onChange={() => {}} />);
    expect(input()).toHaveValue("");
  });

  it("drops typed text when value changes from outside while the listbox is open", async () => {
    const user = userEvent.setup();
    const { rerender } = render(<Combobox label="Fruit" options={fruits} value={null} onChange={() => {}} />);
    await user.type(input(), "ban");
    await user.keyboard("{ArrowDown}");
    rerender(<Combobox label="Fruit" options={fruits} value="apple" onChange={() => {}} />);
    expect(input()).toHaveValue("Apple");
    expect(input()).not.toHaveAttribute("aria-activedescendant");
  });

  it("shows a value that is not in options as empty text without throwing", () => {
    render(<Combobox label="Fruit" options={fruits} value="missing" onChange={() => {}} />);
    expect(input()).toHaveValue("");
  });

  it("does not select anything when every option is disabled", async () => {
    const user = userEvent.setup();
    const onChange = vi.fn();
    const allOff = fruits.map((item) => ({ ...item, disabled: true }));
    render(<Controlled options={allOff} onChange={onChange} />);
    await user.click(input());
    await user.keyboard("{ArrowDown}{ArrowUp}{Enter}");
    expect(input()).not.toHaveAttribute("aria-activedescendant");
    expect(onChange).not.toHaveBeenCalled();
  });

  it("handles a long list without issue", async () => {
    const user = userEvent.setup();
    const many = Array.from({ length: 2000 }, (_, index) => ({ value: `v${index}`, label: `Item ${index}` }));
    render(<Controlled options={many} />);
    await user.type(input(), "Item 1999");
    expect(optionNames()).toEqual(["Item 1999"]);
  });

  it("selects options whose labels are duplicated, by their distinct values", async () => {
    const user = userEvent.setup();
    const onChange = vi.fn();
    const dupes: ComboboxOption[] = [
      { value: "a", label: "Same" },
      { value: "b", label: "Same" },
    ];
    render(<Controlled options={dupes} onChange={onChange} />);
    await user.type(input(), "same");
    const [first, second] = screen.getAllByRole("option");
    expect(first.id).not.toBe(second.id);
    await user.click(second);
    expect(onChange).toHaveBeenCalledWith("b");
  });

  it("builds valid ids for option values with spaces and colons", async () => {
    const user = userEvent.setup();
    const spaced: ComboboxOption[] = [{ value: "New York:city", label: "New York" }];
    render(<Combobox label="City" options={spaced} value={null} onChange={() => {}} />);
    const cityInput = screen.getByRole("combobox", { name: "City" });
    await user.click(cityInput);
    await user.keyboard("{ArrowDown}");
    const newYork = screen.getByRole("option", { name: "New York" });
    expect(newYork.id).not.toMatch(/\s/);
    expect(cityInput).toHaveAttribute("aria-activedescendant", newYork.id);
  });

  it("gives two comboboxes on one page unique ids", () => {
    render(
      <>
        <Combobox label="A" options={fruits} value={null} onChange={() => {}} />
        <Combobox label="B" options={fruits} value={null} onChange={() => {}} />
      </>,
    );
    const ids = Array.from(document.querySelectorAll("[id]"), (element) => element.id);
    expect(ids.length).toBeGreaterThan(0);
    expect(new Set(ids).size).toBe(ids.length);
  });

  it("drops the active option when it is removed from options, so Enter selects nothing", async () => {
    const user = userEvent.setup();
    const onChange = vi.fn();
    const withCherry: ComboboxOption[] = [
      { value: "apple", label: "Apple" },
      { value: "cherry", label: "Cherry" },
    ];
    const { rerender } = render(
      <Combobox label="Fruit" options={withCherry} value={null} onChange={onChange} />,
    );
    input().focus();
    await user.keyboard("{ArrowDown}{ArrowDown}");
    expect(input()).toHaveAttribute("aria-activedescendant", screen.getByRole("option", { name: "Cherry" }).id);
    rerender(
      <Combobox label="Fruit" options={[withCherry[0]]} value={null} onChange={onChange} />,
    );
    expect(input()).not.toHaveAttribute("aria-activedescendant");
    await user.keyboard("{Enter}");
    expect(onChange).not.toHaveBeenCalled();
  });

  it("lets a surrounding form submit on Enter when no option is active", async () => {
    const user = userEvent.setup();
    const onSubmit = vi.fn();
    render(
      <form
        onSubmit={(event) => {
          event.preventDefault();
          onSubmit();
        }}
      >
        <Combobox label="Fruit" options={fruits} value={null} onChange={() => {}} />
      </form>,
    );
    await user.type(input(), "ap");
    await user.keyboard("{Enter}");
    expect(onSubmit).toHaveBeenCalledTimes(1);
  });

  it("forwards className and data attributes to the input without overriding the ARIA wiring", () => {
    render(
      <Combobox label="Fruit" options={fruits} value={null} onChange={() => {}} className="search" data-kind="fruit" aria-controls="custom" />,
    );
    expect(input()).toHaveClass("search");
    expect(input()).toHaveAttribute("data-kind", "fruit");
    expect(input()).not.toHaveAttribute("aria-controls", "custom");
  });
});

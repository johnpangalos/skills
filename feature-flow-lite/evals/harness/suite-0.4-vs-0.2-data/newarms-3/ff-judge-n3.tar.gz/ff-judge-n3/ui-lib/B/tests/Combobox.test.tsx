import type { FormEvent } from "react";
import { fireEvent, render, screen } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { Combobox, type ComboboxOption, type ComboboxProps } from "../src/index";

const fruits: ComboboxOption[] = [
  { value: "apple", label: "Apple" },
  { value: "banana", label: "Banana", disabled: true },
  { value: "grape", label: "Grape" },
  { value: "cherry", label: "Cherry" },
];

function renderCombobox(props: Partial<ComboboxProps> = {}) {
  const onChange = vi.fn();
  const utils = render(<Combobox label="Fruit" options={fruits} onChange={onChange} {...props} />);
  return { onChange, ...utils };
}

const input = () => screen.getByRole("combobox", { name: "Fruit" });
const option = (name: string) => screen.getByRole("option", { name });
const optionNames = () => screen.queryAllByRole("option").map((o) => o.textContent);

function activeOption(): HTMLElement | null {
  const id = input().getAttribute("aria-activedescendant");
  return id ? document.getElementById(id) : null;
}

describe("Combobox value modes (C1)", () => {
  it("is controlled by value and reports changes through onChange", async () => {
    const user = userEvent.setup();
    const { onChange } = renderCombobox({ value: "apple" });
    expect(input()).toHaveValue("Apple");
    await user.click(input());
    await user.keyboard("{ArrowDown}{ArrowDown}{ArrowDown}{Enter}");
    expect(onChange).toHaveBeenCalledWith("cherry");
    expect(input()).toHaveValue("Apple");
  });

  it("is uncontrolled with defaultValue when value is undefined", async () => {
    const user = userEvent.setup();
    const { onChange } = renderCombobox({ defaultValue: "grape" });
    expect(input()).toHaveValue("Grape");
    await user.click(input());
    await user.keyboard("{ArrowDown}{ArrowDown}{ArrowDown}{Enter}");
    expect(onChange).toHaveBeenCalledWith("cherry");
    expect(input()).toHaveValue("Cherry");
  });
});

describe("Combobox markup (C2)", () => {
  it("labels the input and wires aria-controls to a labelled listbox even when closed", async () => {
    const user = userEvent.setup();
    renderCombobox();
    expect(input()).toHaveAttribute("aria-autocomplete", "list");
    expect(input()).toHaveAttribute("aria-expanded", "false");
    const closedListbox = document.getElementById(input().getAttribute("aria-controls") ?? "");
    expect(closedListbox).not.toBeNull();
    await user.click(input());
    await user.keyboard("{ArrowDown}");
    expect(input()).toHaveAttribute("aria-expanded", "true");
    const listbox = screen.getByRole("listbox", { name: "Fruit" });
    expect(listbox).toBe(document.getElementById(input().getAttribute("aria-controls") ?? ""));
  });

  it("renders options with unique ids, selected and disabled state", async () => {
    const user = userEvent.setup();
    renderCombobox({ value: "apple" });
    await user.click(input());
    await user.keyboard("{ArrowDown}");
    const options = screen.getAllByRole("option");
    expect(options).toHaveLength(4);
    expect(new Set(options.map((o) => o.id)).size).toBe(4);
    for (const o of options) expect(o.id).toMatch(/^\S+$/);
    expect(option("Apple")).toHaveAttribute("aria-selected", "true");
    expect(option("Grape")).toHaveAttribute("aria-selected", "false");
    expect(option("Banana")).toHaveAttribute("aria-disabled", "true");
  });

  it("passes placeholder to the input", () => {
    renderCombobox({ placeholder: "Pick a fruit" });
    expect(input()).toHaveAttribute("placeholder", "Pick a fruit");
  });
});

describe("Combobox filtering (C3)", () => {
  it("shows the selected label when closed and filters case-insensitively when typing", async () => {
    const user = userEvent.setup();
    renderCombobox({ value: "cherry" });
    expect(input()).toHaveValue("Cherry");
    await user.clear(input());
    expect(optionNames()).toEqual(["Apple", "Banana", "Grape", "Cherry"]);
    await user.type(input(), "AP");
    expect(optionNames()).toEqual(["Apple", "Grape"]);
    expect(input()).toHaveAttribute("aria-expanded", "true");
  });
});

describe("Combobox keyboard (C4)", () => {
  it("ArrowDown opens, then moves the active option skipping disabled, wrapping, with focus on the input", async () => {
    const user = userEvent.setup();
    renderCombobox();
    await user.click(input());
    await user.keyboard("{ArrowDown}");
    expect(input()).toHaveAttribute("aria-expanded", "true");
    expect(activeOption()).toBe(option("Apple"));
    await user.keyboard("{ArrowDown}");
    expect(activeOption()).toBe(option("Grape"));
    await user.keyboard("{ArrowDown}");
    expect(activeOption()).toBe(option("Cherry"));
    await user.keyboard("{ArrowDown}");
    expect(activeOption()).toBe(option("Apple"));
    await user.keyboard("{ArrowUp}");
    expect(activeOption()).toBe(option("Cherry"));
    expect(input()).toHaveFocus();
  });

  it("resets the active option to the first enabled match when the filter changes", async () => {
    const user = userEvent.setup();
    renderCombobox();
    await user.type(input(), "a");
    expect(activeOption()).toBe(option("Apple"));
    await user.keyboard("{ArrowDown}");
    expect(activeOption()).toBe(option("Grape"));
    await user.clear(input());
    await user.type(input(), "ch");
    expect(activeOption()).toBe(option("Cherry"));
  });
});

describe("Combobox selection (C5)", () => {
  it("Enter on the active option selects it, closes the popup and sets the text", async () => {
    const user = userEvent.setup();
    const { onChange } = renderCombobox();
    await user.click(input());
    await user.keyboard("{ArrowDown}{ArrowDown}{Enter}");
    expect(onChange).toHaveBeenCalledWith("grape");
    expect(input()).toHaveAttribute("aria-expanded", "false");
    expect(input()).toHaveValue("Grape");
  });

  it("Enter with no active option does nothing", async () => {
    const user = userEvent.setup();
    const { onChange } = renderCombobox();
    await user.type(input(), "zz");
    await user.keyboard("{Enter}");
    expect(onChange).not.toHaveBeenCalled();
  });

  it("Enter while the popup is open does not submit the surrounding form", async () => {
    const user = userEvent.setup();
    const onSubmit = vi.fn((e: FormEvent) => e.preventDefault());
    const onChange = vi.fn();
    render(
      <form onSubmit={onSubmit}>
        <Combobox label="Fruit" options={fruits} onChange={onChange} />
      </form>,
    );
    await user.type(input(), "zz");
    await user.keyboard("{Enter}");
    expect(onSubmit).not.toHaveBeenCalled();
    await user.keyboard("{Escape}{ArrowDown}{Enter}");
    expect(onChange).toHaveBeenCalledWith("apple");
    expect(onSubmit).not.toHaveBeenCalled();
  });

  it("clicking an enabled option selects it and keeps focus on the input", async () => {
    const user = userEvent.setup();
    const { onChange } = renderCombobox();
    await user.click(input());
    await user.keyboard("{ArrowDown}");
    await user.click(option("Cherry"));
    expect(onChange).toHaveBeenCalledWith("cherry");
    expect(input()).toHaveAttribute("aria-expanded", "false");
    expect(input()).toHaveValue("Cherry");
    expect(input()).toHaveFocus();
  });

  it("clicking a disabled option does nothing", async () => {
    const user = userEvent.setup();
    const { onChange } = renderCombobox();
    await user.click(input());
    await user.keyboard("{ArrowDown}");
    await user.click(option("Banana"));
    expect(onChange).not.toHaveBeenCalled();
    expect(input()).toHaveAttribute("aria-expanded", "true");
  });
});

describe("Combobox dismissal (C6, C8)", () => {
  it("Escape closes without onChange and restores the selected label", async () => {
    const user = userEvent.setup();
    const { onChange } = renderCombobox({ value: "apple" });
    await user.clear(input());
    await user.type(input(), "ch");
    await user.keyboard("{Escape}");
    expect(onChange).not.toHaveBeenCalled();
    expect(input()).toHaveValue("Apple");
    expect(input()).toHaveAttribute("aria-expanded", "false");
    expect(input()).not.toHaveAttribute("aria-activedescendant");
  });

  it("blur closes the popup and restores the selected label", async () => {
    const user = userEvent.setup();
    const { onChange } = renderCombobox({ value: "apple" });
    await user.clear(input());
    await user.type(input(), "ch");
    await user.tab();
    expect(input()).not.toHaveFocus();
    expect(input()).toHaveAttribute("aria-expanded", "false");
    expect(input()).toHaveValue("Apple");
    expect(onChange).not.toHaveBeenCalled();
  });
});

describe("Combobox no results (C7)", () => {
  it("shows No results and no options when nothing matches", async () => {
    const user = userEvent.setup();
    renderCombobox();
    await user.type(input(), "zzz");
    expect(screen.getByRole("status")).toHaveTextContent("No results");
    expect(screen.queryAllByRole("option")).toHaveLength(0);
  });
});

describe("Combobox hostile inputs (C9)", () => {
  it("ArrowDown sets no active option when all options are disabled", async () => {
    const user = userEvent.setup();
    renderCombobox({
      options: [
        { value: "a", label: "A", disabled: true },
        { value: "b", label: "B", disabled: true },
      ],
    });
    await user.click(input());
    await user.keyboard("{ArrowDown}{ArrowDown}{ArrowUp}");
    expect(input()).toHaveAttribute("aria-expanded", "true");
    expect(input()).not.toHaveAttribute("aria-activedescendant");
  });

  it("shows No results when opened with an empty options array", async () => {
    const user = userEvent.setup();
    renderCombobox({ options: [] });
    await user.click(input());
    await user.keyboard("{ArrowDown}");
    expect(screen.getByRole("status")).toHaveTextContent("No results");
  });

  it("gives valid unique ids to option values with spaces and special characters", async () => {
    const user = userEvent.setup();
    renderCombobox({
      options: [
        { value: "a b", label: "A B" },
        { value: "x/y", label: "X/Y" },
        { value: 'q"<>', label: "Quote" },
      ],
    });
    await user.click(input());
    await user.keyboard("{ArrowDown}");
    const ids = screen.getAllByRole("option").map((o) => o.id);
    expect(new Set(ids).size).toBe(3);
    for (const id of ids) expect(id).toMatch(/^\S+$/);
    expect(input()).toHaveAttribute("aria-activedescendant", ids[0]);
  });

  it("does not throw on regex metacharacters and treats them as plain text", () => {
    renderCombobox();
    for (const text of ["(", ".", "["]) {
      expect(() => fireEvent.change(input(), { target: { value: text } })).not.toThrow();
      expect(screen.getByRole("status")).toHaveTextContent("No results");
    }
  });

  it("shows an empty input when the value matches no option", () => {
    renderCombobox({ value: "nope" });
    expect(input()).toHaveValue("");
  });

  it("updates displayed text when the controlled value changes externally", () => {
    const { rerender, onChange } = renderCombobox({ value: "apple" });
    rerender(<Combobox label="Fruit" options={fruits} value="cherry" onChange={onChange} />);
    expect(input()).toHaveValue("Cherry");
  });

  it("matches labels case- and whitespace-insensitively", async () => {
    const user = userEvent.setup();
    renderCombobox({ options: [{ value: "ny", label: "  New   York " }] });
    await user.type(input(), "NEW   york");
    expect(screen.getAllByRole("option")).toHaveLength(1);
  });
});

describe("Combobox pass-through props (G2)", () => {
  it("applies className and extra attributes to the input and still calls user handlers", async () => {
    const user = userEvent.setup();
    const onKeyDown = vi.fn();
    render(
      <Combobox
        label="Fruit"
        options={fruits}
        onChange={() => {}}
        className="field"
        data-testid="fruit"
        onKeyDown={onKeyDown}
      />,
    );
    expect(screen.getByTestId("fruit")).toBe(input());
    expect(input()).toHaveClass("field");
    await user.click(input());
    await user.keyboard("{ArrowDown}");
    expect(onKeyDown).toHaveBeenCalled();
    expect(input()).toHaveAttribute("aria-expanded", "true");
  });
});

describe("Combobox clearing to null (C5, C8)", () => {
  it("Enter with empty text and no active option clears the value", async () => {
    const user = userEvent.setup();
    const { onChange } = renderCombobox({ value: "apple" });
    await user.clear(input());
    expect(activeOption()).toBeNull();
    await user.keyboard("{Enter}");
    expect(onChange).toHaveBeenCalledTimes(1);
    expect(onChange).toHaveBeenCalledWith(null);
  });

  it("Enter with empty text selects the active option when one is active", async () => {
    const user = userEvent.setup();
    const { onChange } = renderCombobox({ value: "apple" });
    await user.clear(input());
    await user.keyboard("{ArrowDown}{Enter}");
    expect(onChange).toHaveBeenCalledTimes(1);
    expect(onChange).toHaveBeenCalledWith("apple");
  });

  it("blur with empty text clears the value", async () => {
    const user = userEvent.setup();
    const { onChange } = renderCombobox({ value: "apple" });
    await user.clear(input());
    await user.tab();
    expect(onChange).toHaveBeenCalledTimes(1);
    expect(onChange).toHaveBeenCalledWith(null);
    expect(input()).toHaveAttribute("aria-expanded", "false");
  });

  it("clears the internal value when uncontrolled", async () => {
    const user = userEvent.setup();
    const { onChange } = renderCombobox({ defaultValue: "apple" });
    await user.clear(input());
    await user.keyboard("{Enter}");
    expect(onChange).toHaveBeenCalledWith(null);
    expect(input()).toHaveValue("");
  });

  it("does not call onChange for a clear when the value is already null", async () => {
    const user = userEvent.setup();
    const { onChange } = renderCombobox({ value: null });
    await user.type(input(), "x{Backspace}");
    await user.keyboard("{Enter}");
    await user.type(input(), "x{Backspace}");
    await user.tab();
    expect(onChange).not.toHaveBeenCalled();
  });
});

import {
  createContext,
  useContext,
  useEffect,
  useId,
  useRef,
  type ComponentPropsWithoutRef,
  type KeyboardEvent,
} from "react";
import { createPortal } from "react-dom";

export type DialogProps = Omit<ComponentPropsWithoutRef<"div">, "title"> & {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  title: string;
  description?: string;
};

const FOCUSABLE_SELECTOR = [
  "a[href]",
  "button:not([disabled])",
  "input:not([disabled]):not([type='hidden'])",
  "select:not([disabled])",
  "textarea:not([disabled])",
  "[tabindex]:not([disabled])",
].join(", ");

function focusableWithin(container: HTMLElement): HTMLElement[] {
  return Array.from(container.querySelectorAll<HTMLElement>(FOCUSABLE_SELECTOR)).filter(
    (element) => element.tabIndex >= 0,
  );
}

// Each dialog's depth is one more than its parent dialog's, so nested dialogs know they are nested.
const DialogDepth = createContext(0);

// Open dialogs, oldest first. Only the topmost one responds to Escape.
const openDialogs: { token: symbol; depth: number }[] = [];

// The topmost dialog is the deepest one; among equal depths, the most recently opened.
function isTopmost(token: symbol): boolean {
  let top = openDialogs[0];
  for (const dialog of openDialogs) {
    if (dialog.depth >= top.depth) top = dialog;
  }
  return top.token === token;
}

// React events bubble through portals, so a nested dialog's keys also reach the outer dialog.
function isOwnKey(event: KeyboardEvent<HTMLElement>): boolean {
  const target = event.target;
  return target instanceof Element && target.closest('[role="dialog"]') === event.currentTarget;
}

function trapTab(event: KeyboardEvent<HTMLElement>, dialog: HTMLElement) {
  const items = focusableWithin(dialog);
  if (items.length === 0) {
    event.preventDefault();
    dialog.focus();
    return;
  }
  const first = items[0];
  const last = items[items.length - 1];
  const active = document.activeElement;
  if (event.shiftKey && (active === first || active === dialog)) {
    event.preventDefault();
    last.focus();
  } else if (!event.shiftKey && active === last) {
    event.preventDefault();
    first.focus();
  }
}

export function Dialog({
  open,
  onOpenChange,
  title,
  description,
  onKeyDown,
  children,
  ...rest
}: DialogProps) {
  const baseId = useId();
  const dialogRef = useRef<HTMLDivElement>(null);
  const pressedOnBackdrop = useRef(false);
  const releasedOnBackdrop = useRef(false);
  const onOpenChangeRef = useRef(onOpenChange);
  const depth = useContext(DialogDepth) + 1;

  useEffect(() => {
    onOpenChangeRef.current = onOpenChange;
  });

  // Moves focus into the dialog on open and returns it to the opener on close.
  useEffect(() => {
    const dialog = dialogRef.current;
    if (!open || !dialog) return;
    const previous = document.activeElement as HTMLElement | null;
    (focusableWithin(dialog)[0] ?? dialog).focus();
    return () => {
      if (previous?.isConnected) previous.focus();
    };
  }, [open]);

  // Listens on the document so Escape still closes when focus has dropped to the body.
  useEffect(() => {
    if (!open) return;
    const entry = { token: Symbol("dialog"), depth };
    openDialogs.push(entry);
    const onEscape = (event: globalThis.KeyboardEvent) => {
      if (event.key !== "Escape" || event.defaultPrevented) return;
      if (!isTopmost(entry.token)) return;
      event.preventDefault();
      onOpenChangeRef.current(false);
    };
    document.addEventListener("keydown", onEscape);
    return () => {
      document.removeEventListener("keydown", onEscape);
      openDialogs.splice(openDialogs.indexOf(entry), 1);
    };
  }, [open, depth]);

  if (!open) return null;

  const titleId = `${baseId}-title`;
  const descriptionId = `${baseId}-description`;

  return createPortal(
    <div
      onMouseDown={(event) => {
        pressedOnBackdrop.current = event.target === event.currentTarget && event.button === 0;
        releasedOnBackdrop.current = false;
      }}
      onMouseUp={(event) => {
        releasedOnBackdrop.current = event.target === event.currentTarget && event.button === 0;
      }}
      onClick={(event) => {
        // The click fires on the nearest common ancestor of press and release, so both must be on the backdrop.
        // A click that targets a child (Enter on a button inside) is never a backdrop click.
        const dismiss =
          event.target === event.currentTarget && pressedOnBackdrop.current && releasedOnBackdrop.current;
        pressedOnBackdrop.current = false;
        releasedOnBackdrop.current = false;
        if (dismiss) onOpenChange(false);
      }}
    >
      <div
        {...rest}
        ref={dialogRef}
        role="dialog"
        aria-modal="true"
        aria-labelledby={titleId}
        aria-describedby={description ? descriptionId : undefined}
        tabIndex={-1}
        onKeyDown={(event) => {
          onKeyDown?.(event);
          if (event.key === "Tab" && !event.defaultPrevented && isOwnKey(event)) {
            trapTab(event, event.currentTarget);
          }
        }}
      >
        <h2 id={titleId}>{title}</h2>
        {description ? <p id={descriptionId}>{description}</p> : null}
        <DialogDepth value={depth}>{children}</DialogDepth>
      </div>
    </div>,
    document.body,
  );
}

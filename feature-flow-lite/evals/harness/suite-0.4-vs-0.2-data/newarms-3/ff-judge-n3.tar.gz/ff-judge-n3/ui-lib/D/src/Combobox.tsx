import {
  useId,
  useState,
  type ComponentPropsWithoutRef,
  type KeyboardEvent,
} from "react";

export type ComboboxOption = {
  value: string;
  label: string;
  disabled?: boolean;
};

export type ComboboxProps = Omit<
  ComponentPropsWithoutRef<"input">,
  "value" | "onChange" | "role" | "onKeyDown" | "onBlur" | "defaultValue"
> & {
  label: string;
  options: ComboboxOption[];
  value: string | null;
  onChange: (value: string | null) => void;
  placeholder?: string;
};

// Next enabled option index in a direction, wrapping at both ends.
function stepActive(enabled: number[], current: number | null, step: 1 | -1): number | null {
  if (enabled.length === 0) return null;
  const last = enabled.length - 1;
  const position = current === null ? -1 : enabled.indexOf(current);
  if (step === 1) return enabled[position >= last ? 0 : position + 1];
  return enabled[position <= 0 ? last : position - 1];
}

export function Combobox({ label, options, value, onChange, placeholder, ...props }: ComboboxProps) {
  const baseId = useId();
  const labelId = `${baseId}-label`;
  const inputId = `${baseId}-input`;
  const listboxId = `${baseId}-listbox`;
  const optionId = (index: number) => `${baseId}-option-${index}`;

  const [open, setOpen] = useState(false);
  // null means "not editing": the input shows the selected label.
  const [query, setQuery] = useState<string | null>(null);
  const [activeIndex, setActiveIndex] = useState<number | null>(null);
  // Reset typed text when the parent changes value.
  const [previousValue, setPreviousValue] = useState(value);
  if (value !== previousValue) {
    setPreviousValue(value);
    setQuery(null);
  }

  const selectedLabel = options.find((option) => option.value === value)?.label ?? "";
  const needle = (query ?? "").trim().toLowerCase();
  const visible = options.flatMap((option, index) =>
    option.label.toLowerCase().includes(needle) ? [index] : [],
  );
  const enabled = visible.filter((index) => !options[index].disabled);
  // Derived so a stale index can never point at an option that is filtered out.
  const active = activeIndex !== null && enabled.includes(activeIndex) ? activeIndex : null;
  const expanded = open && visible.length > 0;

  function close() {
    setOpen(false);
    setQuery(null);
    setActiveIndex(null);
  }

  function choose(index: number) {
    onChange(options[index].value);
    close();
  }

  function handleKeyDown(event: KeyboardEvent<HTMLInputElement>) {
    switch (event.key) {
      case "ArrowDown":
      case "ArrowUp": {
        event.preventDefault();
        const step = event.key === "ArrowDown" ? 1 : -1;
        if (event.altKey) {
          setOpen(true);
        } else if (!open) {
          setOpen(true);
          setActiveIndex(stepActive(enabled, null, step));
        } else {
          setActiveIndex(stepActive(enabled, active, step));
        }
        return;
      }
      case "Enter":
        if (open && active !== null) {
          event.preventDefault();
          choose(active);
        }
        return;
      case "Escape":
        if (open) {
          // Stop here so an enclosing Dialog does not also close.
          event.preventDefault();
          event.stopPropagation();
          close();
        }
        return;
    }
  }

  return (
    <>
      <label id={labelId} htmlFor={inputId}>
        {label}
      </label>
      <input
        {...props}
        id={inputId}
        type="text"
        role="combobox"
        autoComplete="off"
        placeholder={placeholder}
        aria-autocomplete="list"
        aria-expanded={expanded}
        aria-controls={listboxId}
        aria-activedescendant={active === null ? undefined : optionId(active)}
        value={query ?? selectedLabel}
        onChange={(event) => {
          setQuery(event.target.value);
          setOpen(true);
          setActiveIndex(null);
        }}
        onKeyDown={handleKeyDown}
        onBlur={close}
      />
      <ul id={listboxId} role="listbox" aria-labelledby={labelId} hidden={!expanded}>
        {expanded &&
          visible.map((index) => {
            const option = options[index];
            return (
              <li
                key={index}
                id={optionId(index)}
                role="option"
                aria-selected={option.value === value}
                aria-disabled={option.disabled ? true : undefined}
                data-active={index === active ? true : undefined}
                onMouseDown={(event) => event.preventDefault()}
                onClick={() => {
                  if (!option.disabled) choose(index);
                }}
              >
                {option.label}
              </li>
            );
          })}
      </ul>
      {open && visible.length === 0 && <div role="status">No results</div>}
    </>
  );
}

import { useState, type ReactNode } from "react";
import { fireEvent, render, screen } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { Dialog } from "../src/index";

function Harness({
  onOpenChange = () => {},
  description,
  children,
}: {
  onOpenChange?: (open: boolean) => void;
  description?: string;
  children?: ReactNode;
}) {
  const [open, setOpen] = useState(false);
  return (
    <>
      <button onClick={() => setOpen(true)}>Open</button>
      <Dialog
        open={open}
        onOpenChange={(next) => {
          onOpenChange(next);
          setOpen(next);
        }}
        title="Confirm"
        description={description}
      >
        {children ?? (
          <>
            <button>Cancel</button>
            <button>OK</button>
          </>
        )}
      </Dialog>
    </>
  );
}

describe("Dialog", () => {
  it("renders nothing when closed", () => {
    render(<Dialog open={false} onOpenChange={() => {}} title="Confirm" />);
    expect(screen.queryByRole("dialog")).not.toBeInTheDocument();
  });

  it("renders into document.body with the expected aria wiring", () => {
    render(<Dialog open onOpenChange={() => {}} title="Confirm" description="Are you sure?" />);
    const dialog = screen.getByRole("dialog");
    expect(dialog.parentElement?.parentElement).toBe(document.body);
    expect(dialog).toHaveAttribute("aria-modal", "true");
    expect(screen.getByRole("heading", { level: 2, name: "Confirm" })).toHaveAttribute(
      "id",
      dialog.getAttribute("aria-labelledby"),
    );
    expect(screen.getByText("Are you sure?")).toHaveAttribute("id", dialog.getAttribute("aria-describedby"));
  });

  it("omits aria-describedby when no description is given", () => {
    render(<Dialog open onOpenChange={() => {}} title="Confirm" />);
    expect(screen.getByRole("dialog")).not.toHaveAttribute("aria-describedby");
  });

  it("moves focus to the first tabbable element on open", async () => {
    const user = userEvent.setup();
    render(<Harness />);
    await user.click(screen.getByRole("button", { name: "Open" }));
    expect(screen.getByRole("button", { name: "Cancel" })).toHaveFocus();
  });

  it("focuses the dialog itself when it has no tabbable elements", async () => {
    const user = userEvent.setup();
    render(<Harness>{<p>Just text</p>}</Harness>);
    await user.click(screen.getByRole("button", { name: "Open" }));
    expect(screen.getByRole("dialog")).toHaveFocus();
    expect(screen.getByRole("dialog")).toHaveAttribute("tabindex", "-1");
  });

  it("skips disabled, hidden and tabindex=-1 elements when finding focus targets", async () => {
    const user = userEvent.setup();
    render(
      <Harness>
        <button disabled>Disabled</button>
        <button hidden>Hidden</button>
        <div tabIndex={-1}>Not tabbable</div>
        <button>Real</button>
      </Harness>,
    );
    await user.click(screen.getByRole("button", { name: "Open" }));
    expect(screen.getByRole("button", { name: "Real" })).toHaveFocus();
  });

  it("wraps Tab from the last tabbable element to the first", async () => {
    const user = userEvent.setup();
    render(<Harness />);
    await user.click(screen.getByRole("button", { name: "Open" }));
    await user.keyboard("{Tab}");
    expect(screen.getByRole("button", { name: "OK" })).toHaveFocus();
    await user.keyboard("{Tab}");
    expect(screen.getByRole("button", { name: "Cancel" })).toHaveFocus();
  });

  it("wraps Shift+Tab from the first tabbable element to the last", async () => {
    const user = userEvent.setup();
    render(<Harness />);
    await user.click(screen.getByRole("button", { name: "Open" }));
    await user.keyboard("{Shift>}{Tab}{/Shift}");
    expect(screen.getByRole("button", { name: "OK" })).toHaveFocus();
  });

  it("keeps focus on the dialog when Tab is pressed with no tabbable elements", async () => {
    const user = userEvent.setup();
    render(<Harness>{<p>Just text</p>}</Harness>);
    await user.click(screen.getByRole("button", { name: "Open" }));
    await user.keyboard("{Tab}{Shift>}{Tab}{/Shift}");
    expect(screen.getByRole("dialog")).toHaveFocus();
  });

  it("calls onOpenChange(false) on Escape, and again on a second Escape", async () => {
    const user = userEvent.setup();
    const onOpenChange = vi.fn();
    render(<Dialog open onOpenChange={onOpenChange} title="Confirm"><button>OK</button></Dialog>);
    await user.keyboard("{Escape}");
    expect(onOpenChange).toHaveBeenCalledTimes(1);
    expect(onOpenChange).toHaveBeenLastCalledWith(false);
    await user.keyboard("{Escape}");
    expect(onOpenChange).toHaveBeenCalledTimes(2);
    expect(screen.getByRole("dialog")).toBeInTheDocument();
  });

  it("calls onOpenChange(false) when the backdrop is clicked", async () => {
    const user = userEvent.setup();
    const onOpenChange = vi.fn();
    render(<Dialog open onOpenChange={onOpenChange} title="Confirm">Body</Dialog>);
    await user.click(screen.getByRole("dialog").parentElement as HTMLElement);
    expect(onOpenChange).toHaveBeenCalledWith(false);
  });

  it("does not call onOpenChange when content inside the dialog is clicked", async () => {
    const user = userEvent.setup();
    const onOpenChange = vi.fn();
    render(<Dialog open onOpenChange={onOpenChange} title="Confirm">Body</Dialog>);
    await user.click(screen.getByText("Body"));
    await user.click(screen.getByRole("heading"));
    expect(onOpenChange).not.toHaveBeenCalled();
  });

  it("does not close when a press starts inside the dialog and ends on the backdrop", () => {
    const onOpenChange = vi.fn();
    render(<Dialog open onOpenChange={onOpenChange} title="Confirm">Body</Dialog>);
    fireEvent.mouseDown(screen.getByText("Body"));
    fireEvent.click(screen.getByRole("dialog").parentElement as HTMLElement);
    expect(onOpenChange).not.toHaveBeenCalled();
  });

  it("is controlled only: it does not close itself", async () => {
    const user = userEvent.setup();
    const onOpenChange = vi.fn();
    render(<Dialog open onOpenChange={onOpenChange} title="Confirm">Body</Dialog>);
    await user.keyboard("{Escape}");
    expect(screen.getByRole("dialog")).toBeInTheDocument();
  });

  it("returns focus to the previously focused element when closed", async () => {
    const user = userEvent.setup();
    render(<Harness />);
    const opener = screen.getByRole("button", { name: "Open" });
    await user.click(opener);
    await user.keyboard("{Escape}");
    expect(screen.queryByRole("dialog")).not.toBeInTheDocument();
    expect(opener).toHaveFocus();
  });

  it("returns focus when the dialog unmounts while open", () => {
    const opener = document.createElement("button");
    document.body.appendChild(opener);
    opener.focus();
    const { unmount } = render(<Dialog open onOpenChange={() => {}} title="Confirm">Body</Dialog>);
    expect(screen.getByRole("dialog")).toHaveFocus();
    unmount();
    expect(opener).toHaveFocus();
    opener.remove();
  });

  it("does not throw on close when nothing was focused before opening", () => {
    const { rerender } = render(<Dialog open={false} onOpenChange={() => {}} title="Confirm" />);
    (document.activeElement as HTMLElement | null)?.blur();
    rerender(<Dialog open onOpenChange={() => {}} title="Confirm" />);
    expect(() => rerender(<Dialog open={false} onOpenChange={() => {}} title="Confirm" />)).not.toThrow();
    expect(screen.queryByRole("dialog")).not.toBeInTheDocument();
  });

  it("does not move focus to a previously focused element that was removed while open", () => {
    const opener = document.createElement("button");
    document.body.appendChild(opener);
    opener.focus();
    const { rerender } = render(<Dialog open onOpenChange={() => {}} title="Confirm">Body</Dialog>);
    opener.remove();
    expect(() => rerender(<Dialog open={false} onOpenChange={() => {}} title="Confirm" />)).not.toThrow();
    expect(document.activeElement).toBe(document.body);
  });

  it("restores focus again on every reopen", async () => {
    const user = userEvent.setup();
    render(<Harness />);
    const opener = screen.getByRole("button", { name: "Open" });
    await user.click(opener);
    await user.keyboard("{Escape}");
    expect(opener).toHaveFocus();
    await user.click(opener);
    expect(screen.getByRole("button", { name: "Cancel" })).toHaveFocus();
    await user.keyboard("{Escape}");
    expect(opener).toHaveFocus();
  });

  it("closes only the innermost dialog on Escape when dialogs are nested", async () => {
    const user = userEvent.setup();
    const outer = vi.fn();
    const inner = vi.fn();
    render(
      <Dialog open onOpenChange={outer} title="Outer">
        <Dialog open onOpenChange={inner} title="Inner">
          <button>Inner action</button>
        </Dialog>
      </Dialog>,
    );
    expect(screen.getByRole("button", { name: "Inner action" })).toHaveFocus();
    await user.keyboard("{Escape}");
    expect(inner).toHaveBeenCalledTimes(1);
    expect(inner).toHaveBeenCalledWith(false);
    expect(outer).not.toHaveBeenCalled();
  });

  it("ignores hidden inputs when finding the initial focus target", async () => {
    const user = userEvent.setup();
    render(
      <Harness>
        <form>
          <input type="hidden" name="csrf" value="x" />
          <button type="button">one</button>
          <button type="button">two</button>
        </form>
      </Harness>,
    );
    await user.click(screen.getByRole("button", { name: "Open" }));
    expect(screen.getByRole("button", { name: "one" })).toHaveFocus();
  });

  it("wraps Tab past a trailing hidden input back to the first tabbable element", async () => {
    const user = userEvent.setup();
    render(
      <Harness>
        <form>
          <button type="button">one</button>
          <button type="button">two</button>
          <input type="hidden" name="csrf" value="x" />
        </form>
      </Harness>,
    );
    await user.click(screen.getByRole("button", { name: "Open" }));
    await user.click(screen.getByRole("button", { name: "two" }));
    await user.keyboard("{Tab}");
    expect(screen.getByRole("button", { name: "one" })).toHaveFocus();
  });

  it("applies backdropClassName and a data-dialog-backdrop hook to the backdrop", () => {
    render(
      <Dialog open onOpenChange={() => {}} title="Confirm" backdropClassName="scrim">
        <button>OK</button>
      </Dialog>,
    );
    const backdrop = screen.getByRole("dialog").parentElement;
    expect(backdrop).toHaveAttribute("data-dialog-backdrop", "");
    expect(backdrop).toHaveClass("scrim");
  });

  it("moves focus into a dialog opened sequentially from a button inside another dialog", async () => {
    const user = userEvent.setup();
    const outer = vi.fn();
    const inner = vi.fn();
    function Sequential() {
      const [outerOpen, setOuterOpen] = useState(true);
      const [innerOpen, setInnerOpen] = useState(false);
      return (
        <Dialog
          open={outerOpen}
          onOpenChange={(next) => {
            outer(next);
            setOuterOpen(next);
          }}
          title="Outer"
        >
          <button onClick={() => setInnerOpen(true)}>Open inner</button>
          <Dialog
            open={innerOpen}
            onOpenChange={(next) => {
              inner(next);
              setInnerOpen(next);
            }}
            title="Inner"
          >
            <button>Inner first</button>
            <button>Inner second</button>
          </Dialog>
        </Dialog>
      );
    }
    render(<Sequential />);
    const opener = screen.getByRole("button", { name: "Open inner" });
    await user.click(opener);
    expect(screen.getByRole("button", { name: "Inner first" })).toHaveFocus();
    await user.keyboard("{Escape}");
    expect(inner).toHaveBeenCalledTimes(1);
    expect(inner).toHaveBeenCalledWith(false);
    expect(outer).not.toHaveBeenCalled();
    expect(screen.queryByRole("heading", { name: "Inner" })).not.toBeInTheDocument();
    expect(opener).toHaveFocus();
  });
});

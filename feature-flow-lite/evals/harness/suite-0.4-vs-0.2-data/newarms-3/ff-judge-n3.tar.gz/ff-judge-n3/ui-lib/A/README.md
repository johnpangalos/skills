# @acme/ui

Accessible React 19 components: `Tabs`, `Dialog` and `Combobox`. No runtime dependencies beyond React, no CSS. Each component forwards `className` and other HTML props to its main element, and generates its ids with `React.useId`, so two instances on one page never collide.

## Running

```sh
pnpm install
pnpm test        # Vitest + jsdom + Testing Library
pnpm typecheck   # tsc --noEmit
```

## Tabs

`Tabs` is uncontrolled unless `value` is passed. Its main element is a `div`. `TabList` renders `role="tablist"`, `Tab` renders a `<button type="button" role="tab">`, and `TabPanel` renders `role="tabpanel"`. Non-selected panels are rendered with `hidden`.

### Tabs props

| Name | Type | Default | Description |
| --- | --- | --- | --- |
| `value` | `string` | none | Selected tab value. When set, the component is controlled: selection changes only when the parent updates `value`. |
| `defaultValue` | `string` | first enabled tab | Initial selection when uncontrolled. |
| `onValueChange` | `(value: string) => void` | none | Called with the new value when the user selects a tab by click or keyboard. |

### TabList props

Any `div` attributes. Pass `aria-label` to name the tablist.

### Tab props

| Name | Type | Default | Description |
| --- | --- | --- | --- |
| `value` | `string` | required | Identifies the tab and its panel. |
| `disabled` | `boolean` | `false` | Disables the button. Disabled tabs cannot be clicked or reached by the keyboard. |

### TabPanel props

| Name | Type | Default | Description |
| --- | --- | --- | --- |
| `value` | `string` | required | The tab whose selection shows this panel. |

### Tabs keyboard

Keys are handled on the tablist only, so they have no effect when focus is inside a panel.

| Key | Action |
| --- | --- |
| `ArrowRight` / `ArrowLeft` | Focus and select the next / previous enabled tab, wrapping at both ends. |
| `Home` / `End` | Focus and select the first / last enabled tab. |
| Any other key | No effect. |

Tab order follows the DOM order of the tabs, and stays in sync when tabs are added, removed, or change `value` or `disabled`. The selected tab is the only one with `tabIndex=0`. If `value` or `defaultValue` names no rendered tab, the first enabled tab is selected, its panel is shown, and it takes `tabIndex=0`. If it names a disabled tab, that tab stays `aria-selected` and the first enabled tab takes `tabIndex=0`.

### Tabs example

```tsx
import { Tab, TabList, TabPanel, Tabs } from "@acme/ui";

<Tabs defaultValue="account" onValueChange={(value) => console.log(value)}>
  <TabList aria-label="Settings">
    <Tab value="account">Account</Tab>
    <Tab value="billing" disabled>Billing</Tab>
    <Tab value="contact">Contact</Tab>
  </TabList>
  <TabPanel value="account">Account settings</TabPanel>
  <TabPanel value="billing">Billing settings</TabPanel>
  <TabPanel value="contact">Contact settings</TabPanel>
</Tabs>;
```

## Dialog

`Dialog` is controlled: it is shown when `open` is `true`, and it never closes itself. It renders into `document.body` through a portal: a backdrop element, which is a sibling of the dialog and carries `data-backdrop` for styling, and a `role="dialog"` element with `aria-modal="true"`. The title renders as an `h2`.

### Dialog props

| Name | Type | Default | Description |
| --- | --- | --- | --- |
| `open` | `boolean` | required | Whether the dialog is shown. Nothing is rendered when `false`. |
| `onOpenChange` | `(open: boolean) => void` | required | Called with `false` on Escape or a click on the backdrop. The parent must set `open` to close the dialog. |
| `title` | `ReactNode` | required | Rendered in an `h2`; names the dialog through `aria-labelledby`. |
| `description` | `ReactNode` | none | Rendered in a `p`; describes the dialog through `aria-describedby`. Omitted when not given. |

### Dialog keyboard

| Key | Action |
| --- | --- |
| `Tab` | Moves to the next tabbable element; from the last one, wraps to the first. |
| `Shift+Tab` | Moves to the previous tabbable element; from the first one, wraps to the last. |
| `Escape` | Calls `onOpenChange(false)` on the most recently opened dialog. With stacked dialogs, the ones beneath ignore Escape and the Tab trap until the ones above close. |

Tabbable elements are recomputed on every Tab press. Disabled elements, elements with `tabindex="-1"` and hidden elements are skipped. If there are none, focus stays on the dialog. On open, focus moves to the first tabbable element (or the dialog itself). On close or unmount, focus returns to the element that had focus before opening, if it is still in the document.

A click on the backdrop closes the dialog only when the press and the release both happen on the backdrop, so a drag that starts inside the content does not close it.

### Dialog example

```tsx
import { useState } from "react";
import { Dialog } from "@acme/ui";

function DeleteButton() {
  const [open, setOpen] = useState(false);
  return (
    <>
      <button onClick={() => setOpen(true)}>Delete</button>
      <Dialog open={open} onOpenChange={setOpen} title="Delete file" description="This cannot be undone.">
        <button onClick={() => setOpen(false)}>Confirm</button>
      </Dialog>
    </>
  );
}
```

## Combobox

`Combobox` is controlled through `value`. It renders a `<label>` linked to an `<input role="combobox">`. While the list is open, the popup is a `role="listbox"` of `role="option"` elements. Each option has a unique id, `aria-selected` for the selected value, and `aria-disabled="true"` when disabled.

### Combobox props

| Name | Type | Default | Description |
| --- | --- | --- | --- |
| `label` | `string` | required | Visible label linked to the input. |
| `options` | `ComboboxOption[]` | required | Each option is `{ value: string; label: string; disabled?: boolean }`. |
| `value` | `string \| null` | required | Value of the selected option. `null`, or a value not in `options`, shows an empty input. |
| `onChange` | `(value: string \| null) => void` | required | Called with the chosen option's value. Called with `null` when the text is cleared (empty after trimming) and then committed with Enter or blur, if `value` was not already `null`. |
| `placeholder` | `string` | none | Forwarded to the input. |

Filtering is a case-insensitive substring match on the option label, after trimming the typed text. The text is never treated as a regular expression. When nothing matches, the popup shows "No results" instead of options.

### Combobox keyboard

| Key | Action |
| --- | --- |
| `ArrowDown` / `Alt+ArrowDown` | Opens the list if closed, with the first enabled match active. When open, moves the active option to the next enabled option, wrapping. |
| `ArrowUp` | When open, moves the active option to the previous enabled option, wrapping. |
| `Enter` | When an option is active, selects it, closes the list and shows its label. Otherwise, when the text is cleared, closes the list and calls `onChange(null)` if `value` is set. Otherwise does nothing. |
| `Escape` | When open, closes the list without changing the value and restores the selected label. Does nothing when closed, so an enclosing `Dialog` can handle it. |
| Typing | Opens the list, filters the options and makes the first enabled match active. Text that is empty after trimming lists every option with none active. |
| Blur | Closes the list and restores the selected label. When the text is cleared, closes the list and calls `onChange(null)` if `value` is set. |

Clicking an enabled option selects it, closes the list and keeps focus in the input. Clicking a disabled option does nothing.

### Combobox example

```tsx
import { useState } from "react";
import { Combobox } from "@acme/ui";

const fruits = [
  { value: "apple", label: "Apple" },
  { value: "banana", label: "Banana" },
  { value: "grape", label: "Grape", disabled: true },
];

function FruitPicker() {
  const [value, setValue] = useState<string | null>(null);
  return <Combobox label="Fruit" placeholder="Search fruit" options={fruits} value={value} onChange={setValue} />;
}
```

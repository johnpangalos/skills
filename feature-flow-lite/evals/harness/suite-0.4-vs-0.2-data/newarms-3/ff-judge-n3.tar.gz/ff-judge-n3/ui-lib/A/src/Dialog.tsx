import { useEffect, useId, useRef, type HTMLAttributes, type ReactNode } from "react";
import { createPortal } from "react-dom";

export interface DialogProps extends Omit<HTMLAttributes<HTMLDivElement>, "title"> {
  /** Whether the dialog is shown. The component never changes it on its own. */
  open: boolean;
  /** Called with `false` when the user presses Escape or clicks the backdrop. */
  onOpenChange: (open: boolean) => void;
  title: ReactNode;
  description?: ReactNode;
}

const TABBABLE_SELECTOR = 'a[href], button, input, select, textarea, [tabindex], [contenteditable="true"]';

function isHidden(element: HTMLElement): boolean {
  for (let node: HTMLElement | null = element; node; node = node.parentElement) {
    if (node.hidden || window.getComputedStyle(node).display === "none") return true;
  }
  return false;
}

// Computed at keydown time so the trap always reflects the dialog's current content.
function getTabbables(dialog: HTMLElement): HTMLElement[] {
  return Array.from(dialog.querySelectorAll<HTMLElement>(TABBABLE_SELECTOR)).filter(
    (element) => !element.matches(":disabled") && element.tabIndex >= 0 && !isHidden(element),
  );
}

function keepFocusInside(dialog: HTMLElement, event: KeyboardEvent) {
  const tabbables = getTabbables(dialog);
  if (tabbables.length === 0) {
    event.preventDefault();
    dialog.focus();
    return;
  }
  const index = tabbables.indexOf(document.activeElement as HTMLElement);
  if (event.shiftKey && index <= 0) {
    event.preventDefault();
    tabbables[tabbables.length - 1].focus();
  } else if (!event.shiftKey && (index === -1 || index === tabbables.length - 1)) {
    event.preventDefault();
    tabbables[0].focus();
  }
}

// Open dialogs in the order they opened. Only the last one handles Escape and the Tab trap.
const openDialogs: HTMLElement[] = [];

export function Dialog({ open, onOpenChange, title, description, children, ...rest }: DialogProps) {
  const id = useId();
  const titleId = `${id}-title`;
  const descriptionId = `${id}-description`;
  const dialogRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const dialog = dialogRef.current;
    if (!open || !dialog) return;
    openDialogs.push(dialog);
    return () => {
      openDialogs.splice(openDialogs.indexOf(dialog), 1);
    };
  }, [open]);

  // Moves focus in on open and restores it to the previously focused element on close or unmount.
  useEffect(() => {
    if (!open) return;
    const previous = document.activeElement;
    const dialog = dialogRef.current;
    if (dialog) {
      const [first] = getTabbables(dialog);
      (first ?? dialog).focus();
    }
    return () => {
      if (previous instanceof HTMLElement && previous.isConnected) previous.focus();
    };
  }, [open]);

  useEffect(() => {
    if (!open) return;
    function handleKeyDown(event: KeyboardEvent) {
      const dialog = dialogRef.current;
      if (!dialog || openDialogs[openDialogs.length - 1] !== dialog) return;
      if (event.key === "Escape") {
        onOpenChange(false);
      } else if (event.key === "Tab") {
        keepFocusInside(dialog, event);
      }
    }
    document.addEventListener("keydown", handleKeyDown);
    return () => document.removeEventListener("keydown", handleKeyDown);
  }, [open, onOpenChange]);

  if (!open) return null;

  return createPortal(
    <>
      <div
        data-backdrop
        aria-hidden="true"
        onClick={(event) => {
          if (event.target === event.currentTarget) onOpenChange(false);
        }}
      />
      <div
        {...rest}
        ref={dialogRef}
        role="dialog"
        aria-modal="true"
        aria-labelledby={titleId}
        aria-describedby={description != null ? descriptionId : undefined}
        tabIndex={-1}
      >
        <h2 id={titleId}>{title}</h2>
        {description != null && <p id={descriptionId}>{description}</p>}
        {children}
      </div>
    </>,
    document.body,
  );
}

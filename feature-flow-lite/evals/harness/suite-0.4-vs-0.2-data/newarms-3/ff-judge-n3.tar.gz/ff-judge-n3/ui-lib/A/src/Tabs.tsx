import {
  createContext,
  useContext,
  useId,
  useLayoutEffect,
  useReducer,
  useRef,
  useState,
  type ButtonHTMLAttributes,
  type HTMLAttributes,
  type KeyboardEvent,
} from "react";

export interface TabsProps extends Omit<HTMLAttributes<HTMLDivElement>, "defaultValue"> {
  /** Selected tab value. When set, the component is controlled. */
  value?: string;
  /** Initially selected tab value when uncontrolled. Defaults to the first enabled tab. */
  defaultValue?: string;
  /** Called with the new value when the user selects a tab (click or keyboard). */
  onValueChange?: (value: string) => void;
}

export type TabListProps = HTMLAttributes<HTMLDivElement>;

export interface TabProps extends Omit<ButtonHTMLAttributes<HTMLButtonElement>, "value"> {
  value: string;
  disabled?: boolean;
}

export interface TabPanelProps extends HTMLAttributes<HTMLDivElement> {
  value: string;
}

interface TabsContextValue {
  baseId: string;
  selected: string | undefined;
  activeValue: string | null;
  tabStop: string | null;
  setActiveValue: (value: string | null) => void;
  setTabStop: (value: string | null) => void;
  notifyTabsChanged: () => void;
  select: (value: string) => void;
}

const TabsContext = createContext<TabsContextValue | null>(null);

function useTabsContext(): TabsContextValue {
  const context = useContext(TabsContext);
  if (!context) throw new Error("Tab, TabList and TabPanel must be rendered inside <Tabs>");
  return context;
}

function tabId(baseId: string, value: string): string {
  return `${baseId}-tab-${encodeURIComponent(value)}`;
}

function panelId(baseId: string, value: string): string {
  return `${baseId}-panel-${encodeURIComponent(value)}`;
}

function allTabs(list: HTMLElement | null): HTMLElement[] {
  if (!list) return [];
  return Array.from(list.querySelectorAll<HTMLElement>('[role="tab"]'));
}

function enabledTabs(list: HTMLElement | null): HTMLElement[] {
  return allTabs(list).filter((tab) => !tab.hasAttribute("disabled"));
}

function targetIndex(key: string, current: number, count: number): number | null {
  switch (key) {
    case "ArrowRight":
      return (current + 1) % count;
    case "ArrowLeft":
      return (current - 1 + count) % count;
    case "Home":
      return 0;
    case "End":
      return count - 1;
    default:
      return null;
  }
}

export function Tabs({ value, defaultValue, onValueChange, children, ...rest }: TabsProps) {
  const baseId = useId();
  const [uncontrolled, setUncontrolled] = useState(defaultValue);
  // Resolved by TabList from the rendered tabs: the selected tab, or the first enabled tab when the selection names none.
  const [activeValue, setActiveValue] = useState<string | null>(null);
  const [tabStop, setTabStop] = useState<string | null>(null);
  // Bumped when a Tab mounts, unmounts or changes, so TabList re-syncs with the DOM.
  const [, notifyTabsChanged] = useReducer((count: number) => count + 1, 0);
  const selected = value ?? uncontrolled;

  const select = (next: string) => {
    if (next === activeValue) return;
    if (value === undefined) setUncontrolled(next);
    onValueChange?.(next);
  };

  return (
    <TabsContext.Provider
      value={{ baseId, selected, activeValue, tabStop, setActiveValue, setTabStop, notifyTabsChanged, select }}
    >
      <div {...rest}>{children}</div>
    </TabsContext.Provider>
  );
}

export function TabList({ onKeyDown, children, ...rest }: TabListProps) {
  const { selected, setActiveValue, setTabStop, select } = useTabsContext();
  const listRef = useRef<HTMLDivElement>(null);

  // Runs after every render so the selection and tab stop follow the DOM, including tabs added or removed later.
  useLayoutEffect(() => {
    const all = allTabs(listRef.current).map((tab) => tab.dataset.value ?? "");
    const enabled = enabledTabs(listRef.current).map((tab) => tab.dataset.value ?? "");
    const first = enabled[0] ?? null;
    setActiveValue(selected !== undefined && all.includes(selected) ? selected : first);
    setTabStop(selected !== undefined && enabled.includes(selected) ? selected : first);
  });

  function handleKeyDown(event: KeyboardEvent<HTMLDivElement>) {
    onKeyDown?.(event);
    const tabs = enabledTabs(listRef.current);
    const current = tabs.indexOf(event.target as HTMLElement);
    if (current === -1) return;
    const next = targetIndex(event.key, current, tabs.length);
    if (next === null) return;
    event.preventDefault();
    tabs[next].focus();
    select(tabs[next].dataset.value ?? "");
  }

  return (
    <div {...rest} ref={listRef} role="tablist" onKeyDown={handleKeyDown}>
      {children}
    </div>
  );
}

export function Tab({ value, disabled, onClick, children, ...rest }: TabProps) {
  const { baseId, activeValue, tabStop, notifyTabsChanged, select } = useTabsContext();

  useLayoutEffect(() => {
    notifyTabsChanged();
    return notifyTabsChanged;
  }, [notifyTabsChanged, value, disabled]);

  return (
    <button
      type="button"
      {...rest}
      role="tab"
      id={tabId(baseId, value)}
      data-value={value}
      aria-controls={panelId(baseId, value)}
      aria-selected={activeValue === value}
      tabIndex={tabStop === value ? 0 : -1}
      disabled={disabled}
      onClick={(event) => {
        onClick?.(event);
        select(value);
      }}
    >
      {children}
    </button>
  );
}

export function TabPanel({ value, children, ...rest }: TabPanelProps) {
  const { baseId, activeValue } = useTabsContext();
  const selectedPanel = activeValue === value;
  return (
    <div
      {...rest}
      role="tabpanel"
      id={panelId(baseId, value)}
      aria-labelledby={tabId(baseId, value)}
      hidden={!selectedPanel}
      tabIndex={selectedPanel ? 0 : -1}
    >
      {children}
    </div>
  );
}

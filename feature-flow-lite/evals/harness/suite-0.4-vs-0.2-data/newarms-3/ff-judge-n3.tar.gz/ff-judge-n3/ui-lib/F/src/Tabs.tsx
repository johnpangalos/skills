import {
  createContext,
  useCallback,
  useContext,
  useId,
  useLayoutEffect,
  useRef,
  useState,
  type ComponentPropsWithoutRef,
  type KeyboardEvent,
} from "react";

// Each Tab registers itself, so tabs rendered by any child (even after mount) are known to Tabs.
type TabRegistration = {
  value: string;
  disabled: boolean;
  element: HTMLButtonElement;
};

type TabsContextValue = {
  baseId: string;
  selected: string | null;
  select: (value: string) => void;
  register: (registration: TabRegistration) => void;
  unregister: (registration: TabRegistration) => void;
};

const TabsContext = createContext<TabsContextValue | null>(null);

function useTabsContext(component: string): TabsContextValue {
  const context = useContext(TabsContext);
  if (context === null) {
    throw new Error(`${component} must be rendered inside <Tabs>`);
  }
  return context;
}

const tabId = (baseId: string, value: string) => `${baseId}-tab-${encodeURIComponent(value)}`;
const panelId = (baseId: string, value: string) => `${baseId}-panel-${encodeURIComponent(value)}`;

// Read at call time so the order always follows the DOM, even after re-renders.
function getEnabledTabs(tablist: HTMLElement | null): HTMLElement[] {
  return Array.from(tablist?.querySelectorAll<HTMLElement>('[role="tab"]:not([disabled])') ?? []);
}

export type TabsProps = ComponentPropsWithoutRef<"div"> & {
  value?: string;
  defaultValue?: string;
  onValueChange?: (value: string) => void;
};

export function Tabs({ value, defaultValue, onValueChange, ...props }: TabsProps) {
  const baseId = useId();
  const [uncontrolledValue, setUncontrolledValue] = useState<string | null>(defaultValue ?? null);
  const [registrations, setRegistrations] = useState<TabRegistration[]>([]);

  // Enabled values in DOM order, so the order follows the DOM even when tabs are inserted or moved.
  const enabledValues = registrations
    .filter((registration) => !registration.disabled)
    .sort((a, b) => (a.element.compareDocumentPosition(b.element) & Node.DOCUMENT_POSITION_FOLLOWING ? -1 : 1))
    .map((registration) => registration.value);

  // Falls back to the first enabled tab when nothing is selected or the selection is missing/disabled.
  const current = value ?? uncontrolledValue;
  const selected = current !== null && enabledValues.includes(current) ? current : (enabledValues[0] ?? null);

  const select = (next: string) => {
    // Controlled: skip only the parent's real value, so a fallback-shown tab still reports.
    // Uncontrolled: skip whatever is shown, including the first-enabled fallback.
    if (next === (value !== undefined ? value : selected)) return;
    if (value === undefined) setUncontrolledValue(next);
    onValueChange?.(next);
  };

  // Stable identities so a Tab's layout effect only re-runs when its own value or disabled changes.
  const register = useCallback((registration: TabRegistration) => {
    setRegistrations((previous) => [...previous, registration]);
  }, []);

  const unregister = useCallback((registration: TabRegistration) => {
    setRegistrations((previous) => previous.filter((item) => item !== registration));
  }, []);

  return (
    <TabsContext.Provider value={{ baseId, selected, select, register, unregister }}>
      <div {...props} />
    </TabsContext.Provider>
  );
}

export type TabListProps = ComponentPropsWithoutRef<"div"> & { "aria-label": string };

export function TabList({ onKeyDown, ...props }: TabListProps) {
  const { select } = useTabsContext("TabList");
  const ref = useRef<HTMLDivElement>(null);

  function handleKeyDown(event: KeyboardEvent<HTMLDivElement>) {
    onKeyDown?.(event);
    const tabs = getEnabledTabs(ref.current);
    const index = tabs.indexOf(event.target as HTMLElement);
    if (index === -1) return;

    let next: number;
    switch (event.key) {
      case "ArrowRight":
        next = (index + 1) % tabs.length;
        break;
      case "ArrowLeft":
        next = (index - 1 + tabs.length) % tabs.length;
        break;
      case "Home":
        next = 0;
        break;
      case "End":
        next = tabs.length - 1;
        break;
      default:
        return;
    }
    event.preventDefault();
    tabs[next].focus();
    select(tabs[next].dataset.value ?? "");
  }

  return <div {...props} ref={ref} role="tablist" onKeyDown={handleKeyDown} />;
}

export type TabProps = ComponentPropsWithoutRef<"button"> & { value: string };

export function Tab({ value, disabled, onClick, ...props }: TabProps) {
  const { baseId, selected, select, register, unregister } = useTabsContext("Tab");
  const ref = useRef<HTMLButtonElement>(null);
  const isSelected = selected === value;

  useLayoutEffect(() => {
    const element = ref.current;
    if (element === null) return;
    const registration = { value, disabled: Boolean(disabled), element };
    register(registration);
    return () => unregister(registration);
  }, [value, disabled, register, unregister]);

  return (
    <button
      {...props}
      ref={ref}
      type="button"
      role="tab"
      id={tabId(baseId, value)}
      data-value={value}
      aria-selected={isSelected}
      aria-controls={panelId(baseId, value)}
      aria-disabled={disabled || undefined}
      disabled={disabled}
      tabIndex={isSelected ? 0 : -1}
      onClick={(event) => {
        onClick?.(event);
        select(value);
      }}
    />
  );
}

export type TabPanelProps = ComponentPropsWithoutRef<"div"> & { value: string };

export function TabPanel({ value, ...props }: TabPanelProps) {
  const { baseId, selected } = useTabsContext("TabPanel");

  return (
    <div
      {...props}
      role="tabpanel"
      id={panelId(baseId, value)}
      aria-labelledby={tabId(baseId, value)}
      tabIndex={0}
      hidden={selected !== value}
    />
  );
}

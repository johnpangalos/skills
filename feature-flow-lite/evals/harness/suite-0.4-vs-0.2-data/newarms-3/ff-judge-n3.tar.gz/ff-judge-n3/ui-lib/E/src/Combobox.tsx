import * as React from "react";

export type ComboboxOption = {
  value: string;
  label: string;
  disabled?: boolean;
};

export type ComboboxProps = {
  label: string;
  options: ComboboxOption[];
  value: string | null;
  onChange: (value: string | null) => void;
  placeholder?: string;
  className?: string;
};

// Case-insensitive literal substring match. An empty query matches every option.
function filterOptions(options: ComboboxOption[], query: string): ComboboxOption[] {
  const needle = query.toLowerCase();
  return options.filter((option) => option.label.toLowerCase().includes(needle));
}

// Steps from `from` in direction `step`, wrapping and skipping disabled options. Returns -1 if none is enabled.
function stepEnabled(options: ComboboxOption[], from: number, step: 1 | -1): number {
  const count = options.length;
  for (let k = 1; k <= count; k++) {
    const index = (((from + step * k) % count) + count) % count;
    if (!options[index].disabled) return index;
  }
  return -1;
}

export function Combobox({ label, options, value, onChange, placeholder, className }: ComboboxProps) {
  const baseId = React.useId();
  const inputId = `${baseId}-input`;
  const labelId = `${baseId}-label`;
  const listboxId = `${baseId}-listbox`;
  const optionId = (index: number) => `${baseId}-option-${index}`;

  // `query` is null while the input is not being edited; the input then shows the selected label.
  const [query, setQuery] = React.useState<string | null>(null);
  const [open, setOpen] = React.useState(false);
  const [active, setActive] = React.useState(-1);

  const selected = options.find((option) => option.value === value);
  const visible = filterOptions(options, query ?? "");
  const activeIndex = open && active < visible.length ? active : -1;
  const activeOption = activeIndex >= 0 ? visible[activeIndex] : undefined;
  const text = query ?? selected?.label ?? "";
  // True when the user has edited the text down to nothing (whitespace counts as nothing).
  const cleared = query !== null && query.trim() === "";

  // Closing also reverts the input text to the selected label.
  function close() {
    setOpen(false);
    setQuery(null);
    setActive(-1);
  }

  function choose(option: ComboboxOption) {
    onChange(option.value);
    close();
  }

  // Clears the value when the user emptied the text, then closes.
  function clear() {
    if (value !== null) onChange(null);
    close();
  }

  // Editing activates the first enabled match. With empty text nothing is active, so Enter clears instead.
  function handleInput(event: React.ChangeEvent<HTMLInputElement>) {
    const next = event.target.value;
    setQuery(next);
    setOpen(true);
    setActive(next.trim() === "" ? -1 : stepEnabled(filterOptions(options, next), -1, 1));
  }

  function handleBlur() {
    if (cleared) clear();
    else close();
  }

  function handleKeyDown(event: React.KeyboardEvent<HTMLInputElement>) {
    switch (event.key) {
      case "ArrowDown":
      case "ArrowUp": {
        event.preventDefault();
        const step = event.key === "ArrowDown" ? 1 : -1;
        // The index just before the first option (ArrowDown) or just after the last (ArrowUp), so stepping lands on an end.
        const edge = step === 1 ? -1 : visible.length;
        if (!open) {
          // Opening activates the selected option if it is enabled and visible, else the first (or last) enabled one.
          const selectedIndex = visible.findIndex((option) => option.value === value && !option.disabled);
          setActive(selectedIndex >= 0 ? selectedIndex : stepEnabled(visible, edge, step));
          setOpen(true);
          return;
        }
        setActive(stepEnabled(visible, activeIndex === -1 ? edge : activeIndex, step));
        return;
      }
      case "Enter":
        if (!open) return;
        event.preventDefault();
        if (activeOption && !activeOption.disabled) choose(activeOption);
        else if (cleared) clear();
        return;
      case "Escape":
        if (!open) return;
        event.preventDefault();
        event.stopPropagation();
        close();
        return;
      default:
        return;
    }
  }

  return (
    <div className={className}>
      <label id={labelId} htmlFor={inputId}>
        {label}
      </label>
      <input
        id={inputId}
        type="text"
        role="combobox"
        autoComplete="off"
        placeholder={placeholder}
        value={text}
        aria-autocomplete="list"
        aria-expanded={open}
        aria-controls={listboxId}
        aria-activedescendant={activeIndex >= 0 ? optionId(activeIndex) : undefined}
        onChange={handleInput}
        onKeyDown={handleKeyDown}
        onBlur={handleBlur}
      />
      <ul id={listboxId} role="listbox" aria-labelledby={labelId} hidden={!open}>
        {open &&
          visible.map((option, index) => (
            <li
              key={index}
              id={optionId(index)}
              role="option"
              aria-selected={option.value === value}
              aria-disabled={option.disabled ? "true" : undefined}
              data-active={index === activeIndex ? "true" : undefined}
              onMouseDown={(event) => event.preventDefault()}
              onClick={() => {
                if (!option.disabled) choose(option);
              }}
            >
              {option.label}
            </li>
          ))}
      </ul>
      {open && visible.length === 0 && <div role="status">No results</div>}
    </div>
  );
}

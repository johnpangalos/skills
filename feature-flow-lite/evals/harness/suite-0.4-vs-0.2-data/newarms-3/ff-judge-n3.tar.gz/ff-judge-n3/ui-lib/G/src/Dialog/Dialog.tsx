import {
  createContext,
  useContext,
  useId,
  useLayoutEffect,
  useRef,
  type ComponentPropsWithoutRef,
  type MouseEvent,
  type ReactNode,
} from "react";
import { createPortal } from "react-dom";

export type DialogProps = Omit<ComponentPropsWithoutRef<"div">, "title"> & {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  title: ReactNode;
  description?: ReactNode;
};

const FOCUSABLE_SELECTOR = [
  "a[href]",
  "area[href]",
  "button",
  "input",
  "select",
  "textarea",
  "iframe",
  "[contenteditable='true']",
  "[tabindex]",
].join(", ");

function getTabbables(container: HTMLElement): HTMLElement[] {
  return Array.from(container.querySelectorAll<HTMLElement>(FOCUSABLE_SELECTOR)).filter(
    (element) =>
      !element.matches(":disabled") &&
      element.tabIndex >= 0 &&
      !(element instanceof HTMLInputElement && element.type === "hidden"),
  );
}

type DialogToken = { depth: number };

// Open dialogs ordered by depth, outermost first. Only the last one handles Escape, Tab and focus containment.
const openDialogs: DialogToken[] = [];

// Nesting depth of the enclosing Dialog. The -1 default makes a top-level dialog depth 0.
const DialogDepthContext = createContext(-1);

// Inserts before the first deeper dialog, so a later dialog at the same depth sits above earlier ones.
function insertOpenDialog(token: DialogToken) {
  const index = openDialogs.findIndex((other) => other.depth > token.depth);
  openDialogs.splice(index === -1 ? openDialogs.length : index, 0, token);
}

export function Dialog({ open, onOpenChange, title, description, children, ...rest }: DialogProps) {
  const baseId = useId();
  const depth = useContext(DialogDepthContext) + 1;
  const titleId = `${baseId}-title`;
  const descriptionId = `${baseId}-description`;
  const dialogRef = useRef<HTMLDivElement>(null);
  const onOpenChangeRef = useRef(onOpenChange);
  const pressedOnBackdrop = useRef(false);
  const releasedOnBackdrop = useRef(false);

  // The document listeners below outlive renders, so they call the latest callback through this ref.
  useLayoutEffect(() => {
    onOpenChangeRef.current = onOpenChange;
  });

  // Focus moves in on open and returns to the previously focused element on close or unmount.
  useLayoutEffect(() => {
    const dialog = dialogRef.current;
    if (!open || !dialog) return;
    const token = { depth };
    const previous = document.activeElement;
    insertOpenDialog(token);
    const isTop = () => openDialogs[openDialogs.length - 1] === token;

    // Document-level so it works whatever has focus, including the body after a focused element is removed.
    const handleKeyDown = (event: KeyboardEvent) => {
      if (!isTop()) return;
      if (event.key === "Escape") {
        // An inner component that handled Escape (such as an open Combobox) has already called preventDefault.
        if (!event.defaultPrevented) onOpenChangeRef.current(false);
        return;
      }
      if (event.key !== "Tab") return;

      // Computed on each keypress so tabbables added after open are included.
      const items = getTabbables(dialog);
      if (items.length === 0) {
        event.preventDefault();
        dialog.focus();
        return;
      }
      // The index is -1 when focus is outside the dialog or on the container itself.
      const index = items.indexOf(document.activeElement as HTMLElement);
      const last = items.length - 1;
      if (event.shiftKey ? index <= 0 : index === -1 || index === last) {
        event.preventDefault();
        items[event.shiftKey ? last : 0].focus();
      }
    };

    const handleFocusIn = (event: FocusEvent) => {
      if (!isTop() || dialog.contains(event.target as Node)) return;
      (getTabbables(dialog)[0] ?? dialog).focus();
    };

    // Only the top-most dialog takes focus, so an outer dialog mounting alongside its open child leaves focus alone.
    if (isTop()) (getTabbables(dialog)[0] ?? dialog).focus();
    document.addEventListener("keydown", handleKeyDown);
    document.addEventListener("focusin", handleFocusIn);
    return () => {
      document.removeEventListener("keydown", handleKeyDown);
      document.removeEventListener("focusin", handleFocusIn);
      openDialogs.splice(openDialogs.indexOf(token), 1);
      if (previous instanceof HTMLElement && previous.isConnected) previous.focus();
    };
  }, [open, depth]);

  if (!open) return null;

  // A click dismisses only when both the press and the release happened on the backdrop itself.
  const handleBackdropMouseDown = (event: MouseEvent<HTMLDivElement>) => {
    pressedOnBackdrop.current = event.target === event.currentTarget;
    releasedOnBackdrop.current = false;
  };

  const handleBackdropMouseUp = (event: MouseEvent<HTMLDivElement>) => {
    releasedOnBackdrop.current = event.target === event.currentTarget;
  };

  const handleBackdropClick = () => {
    const dismiss = pressedOnBackdrop.current && releasedOnBackdrop.current;
    pressedOnBackdrop.current = false;
    releasedOnBackdrop.current = false;
    if (dismiss) onOpenChange(false);
  };

  return createPortal(
    <DialogDepthContext.Provider value={depth}>
      <div
        data-backdrop=""
        onMouseDown={handleBackdropMouseDown}
        onMouseUp={handleBackdropMouseUp}
        onClick={handleBackdropClick}
      >
        <div
          {...rest}
          ref={dialogRef}
          role="dialog"
          aria-modal="true"
          aria-labelledby={titleId}
          aria-describedby={description == null ? undefined : descriptionId}
          tabIndex={-1}
        >
          <h2 id={titleId}>{title}</h2>
          {description == null ? null : <p id={descriptionId}>{description}</p>}
          {children}
        </div>
      </div>
    </DialogDepthContext.Provider>,
    document.body,
  );
}

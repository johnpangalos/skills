import {
  createContext,
  useCallback,
  useContext,
  useId,
  useLayoutEffect,
  useRef,
  useState,
  type ButtonHTMLAttributes,
  type HTMLAttributes,
  type KeyboardEvent,
} from "react";

export interface TabsProps extends Omit<HTMLAttributes<HTMLDivElement>, "defaultValue"> {
  value?: string;
  defaultValue?: string;
  onValueChange?: (value: string) => void;
}

export interface TabListProps extends HTMLAttributes<HTMLDivElement> {
  "aria-label": string;
}

export interface TabProps extends Omit<ButtonHTMLAttributes<HTMLButtonElement>, "value"> {
  value: string;
  disabled?: boolean;
}

export interface TabPanelProps extends HTMLAttributes<HTMLDivElement> {
  value: string;
}

interface TabsContextValue {
  baseId: string;
  // Explicitly selected value, or null when Tabs has no value and no defaultValue.
  selected: string | null;
  // The one tab with tabIndex 0 (the selected enabled tab, or the first enabled tab).
  activeId: string | null;
  setActiveId: (id: string | null) => void;
  select: (value: string) => void;
  // Called when a Tab mounts, unmounts or changes disabled or value, so TabList recomputes activeId.
  notify: () => void;
}

const TabsContext = createContext<TabsContextValue | null>(null);

function useTabsContext(): TabsContextValue {
  const context = useContext(TabsContext);
  if (context === null) {
    throw new Error("Tab components must be rendered inside <Tabs>");
  }
  return context;
}

function tabIdFor(baseId: string, value: string): string {
  return `${baseId}-tab-${encodeURIComponent(value)}`;
}

function panelIdFor(baseId: string, value: string): string {
  return `${baseId}-panel-${encodeURIComponent(value)}`;
}

function isTabSelected(context: TabsContextValue, value: string): boolean {
  if (context.selected === null) {
    return tabIdFor(context.baseId, value) === context.activeId;
  }
  return context.selected === value;
}

function isEnabledTab(tab: HTMLElement): boolean {
  return tab.getAttribute("aria-disabled") !== "true";
}

function enabledTabs(tablist: HTMLElement): HTMLElement[] {
  return Array.from(tablist.querySelectorAll<HTMLElement>('[role="tab"]')).filter(isEnabledTab);
}

// The tab an arrow, Home or End key moves to. Starts from the focused tab even if it is disabled.
function keyboardTarget(tabs: HTMLElement[], index: number, key: string): HTMLElement | undefined {
  if (key === "Home") return tabs.filter(isEnabledTab)[0];
  if (key === "End") {
    const enabled = tabs.filter(isEnabledTab);
    return enabled[enabled.length - 1];
  }
  if (key !== "ArrowRight" && key !== "ArrowLeft") return undefined;
  const step = key === "ArrowRight" ? 1 : -1;
  for (let offset = 1; offset <= tabs.length; offset++) {
    const candidate = tabs[(((index + step * offset) % tabs.length) + tabs.length) % tabs.length];
    if (isEnabledTab(candidate)) return candidate;
  }
  return undefined;
}

export function Tabs({ value, defaultValue, onValueChange, ...rest }: TabsProps) {
  const baseId = useId();
  const [internal, setInternal] = useState<string | null>(defaultValue ?? null);
  const [activeId, setActiveId] = useState<string | null>(null);
  const [, setVersion] = useState(0);
  const notify = useCallback(() => setVersion((version) => version + 1), []);
  const selected = value ?? internal;

  const select = (next: string) => {
    if (next === selected) return;
    if (value === undefined) setInternal(next);
    onValueChange?.(next);
  };

  return (
    <TabsContext value={{ baseId, selected, activeId, setActiveId, select, notify }}>
      <div {...rest} />
    </TabsContext>
  );
}

export function TabList({ onKeyDown, ...rest }: TabListProps) {
  const context = useTabsContext();
  const listRef = useRef<HTMLDivElement>(null);

  // Runs after every render so the DOM-derived active tab follows added, removed and disabled tabs.
  useLayoutEffect(() => {
    if (listRef.current === null) return;
    const tabs = enabledTabs(listRef.current);
    const selectedId = context.selected === null ? null : tabIdFor(context.baseId, context.selected);
    const active = tabs.find((tab) => tab.id === selectedId) ?? tabs[0];
    context.setActiveId(active?.id ?? null);
  });

  const handleKeyDown = (event: KeyboardEvent<HTMLDivElement>) => {
    onKeyDown?.(event);
    const tabs = Array.from(event.currentTarget.querySelectorAll<HTMLElement>('[role="tab"]'));
    const index = tabs.indexOf(event.target as HTMLElement);
    const target = index === -1 ? undefined : keyboardTarget(tabs, index, event.key);
    if (target === undefined) return;
    event.preventDefault();
    target.focus();
  };

  return (
    <div
      {...rest}
      ref={listRef}
      role="tablist"
      aria-orientation="horizontal"
      onKeyDown={handleKeyDown}
    />
  );
}

export function Tab({ value, disabled = false, onFocus, onClick, ...rest }: TabProps) {
  const context = useTabsContext();
  const id = tabIdFor(context.baseId, value);
  const selected = isTabSelected(context, value);
  const { notify } = context;

  useLayoutEffect(() => {
    notify();
    return () => notify();
  }, [disabled, notify, value]);

  // Before TabList has measured the DOM, the selected enabled tab is the tab stop.
  const isTabStop = context.activeId === null ? selected && !disabled : id === context.activeId;

  // Selection follows focus; clicks also select in case the tab already had focus.
  const select = () => {
    if (!disabled && !selected) context.select(value);
  };

  return (
    <button
      {...rest}
      type="button"
      role="tab"
      id={id}
      aria-selected={selected}
      aria-controls={panelIdFor(context.baseId, value)}
      aria-disabled={disabled || undefined}
      tabIndex={isTabStop ? 0 : -1}
      onFocus={(event) => {
        onFocus?.(event);
        select();
      }}
      onClick={(event) => {
        onClick?.(event);
        select();
      }}
    />
  );
}

export function TabPanel({ value, ...rest }: TabPanelProps) {
  const context = useTabsContext();
  return (
    <div
      {...rest}
      role="tabpanel"
      id={panelIdFor(context.baseId, value)}
      aria-labelledby={tabIdFor(context.baseId, value)}
      tabIndex={0}
      hidden={!isTabSelected(context, value)}
    />
  );
}

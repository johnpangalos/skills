import { render, screen } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { useState } from "react";
import { describe, expect, it, vi } from "vitest";
import { Dialog } from "./Dialog";

// The inner dialog is opened from inside the outer one, the way nested dialogs are used in practice.
function Nested({ onOuter, onInner }: { onOuter: (open: boolean) => void; onInner: (open: boolean) => void }) {
  const [innerOpen, setInnerOpen] = useState(false);
  return (
    <Dialog open onOpenChange={onOuter} title="Outer">
      <button onClick={() => setInnerOpen(true)}>Open inner</button>
      {innerOpen && (
        <Dialog
          open
          onOpenChange={(next) => {
            onInner(next);
            setInnerOpen(next);
          }}
          title="Inner"
        >
          <button>Inner A</button>
          <button>Inner B</button>
        </Dialog>
      )}
    </Dialog>
  );
}

type PageProps = { open: boolean; onOpenChange?: (open: boolean) => void };

function Page({ open, onOpenChange = () => {} }: PageProps) {
  return (
    <>
      <button>Open</button>
      <button>Outside</button>
      <Dialog open={open} onOpenChange={onOpenChange} title="Delete file" description="This cannot be undone.">
        <button>Cancel</button>
        <button>Delete</button>
      </Dialog>
    </>
  );
}

function Host({ mounted }: { mounted: boolean }) {
  return (
    <>
      <button>Open</button>
      {mounted && (
        <Dialog open onOpenChange={() => {}} title="Notice">
          <button>Got it</button>
        </Dialog>
      )}
    </>
  );
}

describe("Dialog", () => {
  it("renders nothing while closed", () => {
    render(<Page open={false} />);
    expect(screen.queryByRole("dialog")).not.toBeInTheDocument();
  });

  it("renders a labelled modal into document.body with a backdrop", () => {
    const { container } = render(<Page open />);
    const dialog = screen.getByRole("dialog", { name: "Delete file" });
    expect(dialog).toHaveAttribute("aria-modal", "true");
    expect(dialog).toHaveAccessibleDescription("This cannot be undone.");
    expect(container.contains(dialog)).toBe(false);
    const backdrop = dialog.parentElement as HTMLElement;
    expect(backdrop.parentElement).toBe(document.body);
  });

  it("omits aria-describedby when there is no description", () => {
    render(
      <Dialog open onOpenChange={() => {}} title="Notice">
        Text
      </Dialog>,
    );
    const dialog = screen.getByRole("dialog", { name: "Notice" });
    expect(dialog).not.toHaveAttribute("aria-describedby");
  });

  it("accepts a ReactNode title", () => {
    render(
      <Dialog open onOpenChange={() => {}} title={<span>Delete <em>now</em></span>}>
        Body
      </Dialog>,
    );
    expect(screen.getByRole("dialog", { name: "Delete now" })).toBeInTheDocument();
  });

  it("moves focus to the first focusable element when it opens", () => {
    render(<Page open />);
    expect(screen.getByRole("button", { name: "Cancel" })).toHaveFocus();
  });

  it("focuses the dialog itself when it has nothing focusable", () => {
    render(
      <Dialog open onOpenChange={() => {}} title="Notice">
        Just text
      </Dialog>,
    );
    expect(screen.getByRole("dialog")).toHaveFocus();
  });

  it("skips disabled, hidden and tabindex=-1 elements when choosing the first focus target", () => {
    render(
      <Dialog open onOpenChange={() => {}} title="Notice">
        <button disabled>Disabled</button>
        <div hidden>
          <button>Hidden</button>
        </div>
        <span tabIndex={-1}>Not a stop</span>
        <button>Real</button>
      </Dialog>,
    );
    expect(screen.getByRole("button", { name: "Real" })).toHaveFocus();
  });

  it("wraps Tab from the last focusable element to the first", async () => {
    const user = userEvent.setup();
    render(<Page open />);
    const cancel = screen.getByRole("button", { name: "Cancel" });
    await user.tab();
    expect(screen.getByRole("button", { name: "Delete" })).toHaveFocus();
    await user.tab();
    expect(cancel).toHaveFocus();
  });

  it("wraps Shift+Tab from the first focusable element to the last", async () => {
    const user = userEvent.setup();
    render(<Page open />);
    await user.tab({ shift: true });
    expect(screen.getByRole("button", { name: "Delete" })).toHaveFocus();
  });

  it("keeps Tab on the dialog when it has no focusable elements", async () => {
    const user = userEvent.setup();
    render(
      <Dialog open onOpenChange={() => {}} title="Notice">
        Just text
      </Dialog>,
    );
    await user.tab();
    expect(screen.getByRole("dialog")).toHaveFocus();
  });

  it("pulls focus back when something outside the dialog is focused", async () => {
    const user = userEvent.setup();
    const onOpenChange = vi.fn();
    render(<Page open onOpenChange={onOpenChange} />);
    await user.click(screen.getByRole("button", { name: "Outside" }));
    expect(screen.getByRole("button", { name: "Cancel" })).toHaveFocus();
    expect(onOpenChange).not.toHaveBeenCalled();
  });

  it("calls onOpenChange(false) on Escape", async () => {
    const user = userEvent.setup();
    const onOpenChange = vi.fn();
    render(<Page open onOpenChange={onOpenChange} />);
    await user.keyboard("{Escape}");
    expect(onOpenChange).toHaveBeenCalledTimes(1);
    expect(onOpenChange).toHaveBeenCalledWith(false);
  });

  it("calls onOpenChange(false) on a backdrop click, but not on a click inside the dialog", async () => {
    const user = userEvent.setup();
    const onOpenChange = vi.fn();
    render(<Page open onOpenChange={onOpenChange} />);
    const dialog = screen.getByRole("dialog");
    await user.click(screen.getByText("Delete file"));
    expect(onOpenChange).not.toHaveBeenCalled();
    await user.click(dialog.parentElement as HTMLElement);
    expect(onOpenChange).toHaveBeenCalledTimes(1);
    expect(onOpenChange).toHaveBeenCalledWith(false);
  });

  it("does not reuse an earlier backdrop press for a later click with no press", async () => {
    const user = userEvent.setup();
    const onOpenChange = vi.fn();
    render(<Page open onOpenChange={onOpenChange} />);
    const backdrop = screen.getByRole("dialog").parentElement as HTMLElement;
    await user.click(backdrop);
    expect(onOpenChange).toHaveBeenCalledTimes(1);
    backdrop.dispatchEvent(new MouseEvent("click", { bubbles: true }));
    expect(onOpenChange).toHaveBeenCalledTimes(1);
  });

  it("does not close when a press starts inside the dialog and ends on the backdrop", async () => {
    const onOpenChange = vi.fn();
    render(<Page open onOpenChange={onOpenChange} />);
    const backdrop = screen.getByRole("dialog").parentElement as HTMLElement;
    // A drag that starts inside: mousedown fires on the dialog, mouseup/click on the backdrop.
    screen.getByRole("dialog").dispatchEvent(new MouseEvent("mousedown", { bubbles: true }));
    backdrop.dispatchEvent(new MouseEvent("mouseup", { bubbles: true }));
    backdrop.dispatchEvent(new MouseEvent("click", { bubbles: true }));
    expect(onOpenChange).not.toHaveBeenCalled();
  });

  it("does not close itself: with open kept true the dialog stays open", async () => {
    const user = userEvent.setup();
    const onOpenChange = vi.fn();
    render(<Page open onOpenChange={onOpenChange} />);
    await user.keyboard("{Escape}");
    expect(onOpenChange).toHaveBeenCalledWith(false);
    expect(screen.getByRole("dialog")).toBeInTheDocument();
  });

  it("closes only the topmost of two nested dialogs on Escape", async () => {
    const user = userEvent.setup();
    const outer = vi.fn();
    const inner = vi.fn();
    render(<Nested onOuter={outer} onInner={inner} />);
    await user.click(screen.getByRole("button", { name: "Open inner" }));
    expect(screen.getByRole("button", { name: "Inner A" })).toHaveFocus();
    await user.keyboard("{Escape}");
    expect(inner).toHaveBeenCalledWith(false);
    expect(outer).not.toHaveBeenCalled();
  });

  it("keeps Tab inside the topmost of two nested dialogs", async () => {
    const user = userEvent.setup();
    render(<Nested onOuter={() => {}} onInner={() => {}} />);
    await user.click(screen.getByRole("button", { name: "Open inner" }));
    expect(screen.getByRole("button", { name: "Inner A" })).toHaveFocus();
    await user.tab();
    expect(screen.getByRole("button", { name: "Inner B" })).toHaveFocus();
    await user.tab();
    expect(screen.getByRole("button", { name: "Inner A" })).toHaveFocus();
  });

  it("returns focus to the opener when it closes", async () => {
    const user = userEvent.setup();
    const { rerender } = render(<Page open={false} />);
    const opener = screen.getByRole("button", { name: "Open" });
    await user.click(opener);
    expect(opener).toHaveFocus();
    rerender(<Page open />);
    expect(screen.getByRole("button", { name: "Cancel" })).toHaveFocus();
    rerender(<Page open={false} />);
    expect(opener).toHaveFocus();
  });

  it("returns focus to the opener when unmounted while open", async () => {
    const user = userEvent.setup();
    const { rerender } = render(<Host mounted={false} />);
    const opener = screen.getByRole("button", { name: "Open" });
    await user.click(opener);
    rerender(<Host mounted />);
    expect(screen.getByRole("button", { name: "Got it" })).toHaveFocus();
    rerender(<Host mounted={false} />);
    expect(opener).toHaveFocus();
  });

  it("does not throw on close when the opener was removed while open", () => {
    function Removable({ showOpener }: { showOpener: boolean }) {
      return (
        <>
          {showOpener && <button>Open</button>}
          <Dialog open onOpenChange={() => {}} title="Notice">
            <button>Got it</button>
          </Dialog>
        </>
      );
    }
    const { rerender } = render(<Removable showOpener />);
    rerender(<Removable showOpener={false} />);
    expect(screen.queryByRole("button", { name: "Open" })).not.toBeInTheDocument();
  });

  it("re-opens cleanly after a rapid open, close and open", async () => {
    const user = userEvent.setup();
    const { rerender } = render(<Host mounted={false} />);
    await user.click(screen.getByRole("button", { name: "Open" }));
    rerender(<Host mounted />);
    rerender(<Host mounted={false} />);
    rerender(<Host mounted />);
    expect(screen.getByRole("button", { name: "Got it" })).toHaveFocus();
  });

  it("gives two open dialogs unique ids", () => {
    render(
      <>
        <Dialog open onOpenChange={() => {}} title="First">
          <button>A</button>
        </Dialog>
        <Dialog open onOpenChange={() => {}} title="Second">
          <button>B</button>
        </Dialog>
      </>,
    );
    const ids = Array.from(document.querySelectorAll("[id]"), (element) => element.id);
    expect(ids.length).toBeGreaterThan(0);
    expect(new Set(ids).size).toBe(ids.length);
  });

  it("skips hidden inputs and tabindex=-1 elements when trapping focus", async () => {
    const user = userEvent.setup();
    render(
      <Dialog open onOpenChange={() => {}} title="Trap">
        <input type="hidden" name="token" />
        <button tabIndex={-1}>Skip</button>
        <button>B1</button>
        <button>B2</button>
      </Dialog>,
    );
    expect(screen.getByRole("button", { name: "B1" })).toHaveFocus();
    await user.tab();
    expect(screen.getByRole("button", { name: "B2" })).toHaveFocus();
    await user.tab();
    expect(screen.getByRole("button", { name: "B1" })).toHaveFocus();
    await user.tab({ shift: true });
    expect(screen.getByRole("button", { name: "B2" })).toHaveFocus();
  });

  it("does not close when a press starts on the backdrop and ends inside the dialog", async () => {
    const user = userEvent.setup();
    const onOpenChange = vi.fn();
    render(
      <Dialog open onOpenChange={onOpenChange} title="Notice">
        Body
      </Dialog>,
    );
    const dialog = screen.getByRole("dialog");
    const backdrop = dialog.parentElement as HTMLElement;
    await user.pointer([{ keys: "[MouseLeft>]", target: backdrop }, { target: dialog }, { keys: "[/MouseLeft]" }]);
    expect(onOpenChange).not.toHaveBeenCalled();
  });

  it("renders a block description in a div without a nesting warning", () => {
    const consoleError = vi.spyOn(console, "error").mockImplementation(() => {});
    render(<Dialog open onOpenChange={() => {}} title="Notice" description={<div>Block text</div>} />);
    expect(screen.getByRole("dialog")).toHaveAccessibleDescription("Block text");
    expect(consoleError).not.toHaveBeenCalled();
    consoleError.mockRestore();
  });

  it("forwards className and data attributes to the dialog element without overriding the ARIA wiring", () => {
    render(
      <Dialog open onOpenChange={() => {}} title="Notice" className="modal" data-kind="confirm" aria-labelledby="custom">
        Body
      </Dialog>,
    );
    const dialog = screen.getByRole("dialog", { name: "Notice" });
    expect(dialog).toHaveClass("modal");
    expect(dialog).toHaveAttribute("data-kind", "confirm");
    expect(dialog).not.toHaveAttribute("aria-labelledby", "custom");
  });
});

# @acme/ui

Accessible React 19 components: `Tabs`, `Dialog` and `Combobox`. They follow the WAI-ARIA Authoring Practices patterns for roles, states and keyboard behavior.

The components are **unstyled**. They ship no CSS and render plain elements. Pass `className` and other native props to the main element of each component and style them yourself.

## Install and use

Requires React and React DOM 19 as peer dependencies. There are no runtime dependencies.

```tsx
import { useState } from "react";
import { Tabs, TabList, Tab, TabPanel, Dialog, Combobox } from "@acme/ui";

export function Example() {
  const [open, setOpen] = useState(false);
  const [fruit, setFruit] = useState<string | null>(null);

  return (
    <>
      <Tabs defaultValue="one">
        <TabList aria-label="Sections">
          <Tab value="one">One</Tab>
          <Tab value="two">Two</Tab>
        </TabList>
        <TabPanel value="one">First panel</TabPanel>
        <TabPanel value="two">Second panel</TabPanel>
      </Tabs>

      <button type="button" onClick={() => setOpen(true)}>Open</button>
      <Dialog open={open} onOpenChange={setOpen} title="Confirm" description="This cannot be undone.">
        <button type="button" onClick={() => setOpen(false)}>Close</button>
      </Dialog>

      <Combobox
        label="Fruit"
        options={[
          { value: "apple", label: "Apple" },
          { value: "pear", label: "Pear", disabled: true },
        ]}
        value={fruit}
        onChange={setFruit}
      />
    </>
  );
}
```

## Development

- `pnpm test` runs the Vitest suite (jsdom with Testing Library).
- `pnpm typecheck` runs `tsc --noEmit`.

## Tabs

`Tabs` holds the state. `TabList` renders the `tablist`, `Tab` renders each `tab` button, and `TabPanel` renders each panel. Tabs can be uncontrolled (`defaultValue`) or controlled (`value`). In controlled mode the component displays `value` and changes it only when the parent does.

Uncontrolled tabs start on `defaultValue`. If `defaultValue` is missing or names no enabled tab, they start on the first enabled tab. Only one tab is in the tab order at a time: the selected enabled tab, or the first enabled tab when no selected tab is enabled.

### Tabs props

| Name | Type | Required / default | Description |
| --- | --- | --- | --- |
| `defaultValue` | `string` | optional, first enabled tab | Initial value for uncontrolled use. |
| `value` | `string` | optional | Selected value for controlled use. |
| `onValueChange` | `(value: string) => void` | optional | Called when the user selects a tab, in both modes. |
| `children` | `ReactNode` | optional | `TabList` and `TabPanel` elements. |

### TabList props

| Name | Type | Required / default | Description |
| --- | --- | --- | --- |
| `aria-label` | `string` | required | Accessible name for the tablist. |
| `...div props` | `HTMLAttributes<HTMLDivElement>` | optional | Passed to the `div role="tablist"`, including `className`. |

### Tab props

| Name | Type | Required / default | Description |
| --- | --- | --- | --- |
| `value` | `string` | required | Identifies the tab and its panel. |
| `disabled` | `boolean` | optional, `false` | Disables the tab. Disabled tabs are skipped by keyboard and cannot be clicked. |
| `...button props` | `ButtonHTMLAttributes<HTMLButtonElement>` | optional | Passed to the `button`, including `className`. `onClick` is called before selection. |

### TabPanel props

| Name | Type | Required / default | Description |
| --- | --- | --- | --- |
| `value` | `string` | required | The `Tab` value this panel belongs to. Only the selected panel is visible. |
| `...div props` | `HTMLAttributes<HTMLDivElement>` | optional | Passed to the `div role="tabpanel"`, including `className`. |

### Tabs keyboard

Keys apply to the focused tab. Selection follows focus.

| Key | Behavior |
| --- | --- |
| `ArrowRight` | Moves focus to and selects the next enabled tab. Wraps from the last tab to the first. |
| `ArrowLeft` | Moves focus to and selects the previous enabled tab. Wraps from the first tab to the last. |
| `Home` | Moves focus to and selects the first enabled tab. |
| `End` | Moves focus to and selects the last enabled tab. |

Other keys do nothing. The handled keys call `preventDefault`. Disabled tabs are skipped. With no enabled tabs, no key does anything.

## Dialog

`Dialog` is controlled only: the parent owns `open` and handles `onOpenChange`. When `open` is `false`, nothing is rendered. When open, it renders through a portal into `document.body`: a backdrop element and a `role="dialog"` element with `aria-modal="true"`. The title is an `h2`. `aria-describedby` is set only when `description` is given. An empty string counts as no description.

On open, focus moves to the first tabbable element in the dialog, or to the dialog itself if there is none. On close, focus returns to the element that had focus before the dialog opened, if it is still in the document.

A click on the backdrop closes the dialog. The press and the click must both start on the backdrop, so a drag that starts inside the dialog does not close it.

### Dialog props

| Name | Type | Required / default | Description |
| --- | --- | --- | --- |
| `open` | `boolean` | required | Whether the dialog is shown. |
| `onOpenChange` | `(open: boolean) => void` | required | Called with `false` on Escape or a backdrop click. The parent must set `open`. |
| `title` | `ReactNode` | required | Rendered in an `h2` and used as the accessible name. |
| `description` | `ReactNode` | optional | Rendered below the title and used as the accessible description. |
| `children` | `ReactNode` | optional | Dialog content. |
| `...div props` | `HTMLAttributes<HTMLDivElement>` | optional | Passed to the `div role="dialog"`, including `className`. `onKeyDown` is not accepted. |

### Dialog keyboard

| Key | Behavior |
| --- | --- |
| `Escape` | Calls `onOpenChange(false)`, then calls `preventDefault` and `stopPropagation` so an enclosing `Dialog` stays open. Ignored if an element inside already called `preventDefault` on the event, for example an open `Combobox`. |
| `Tab` | Moves to the next tabbable element. Wraps from the last to the first. With no tabbable elements, focus stays on the dialog. |
| `Shift+Tab` | Moves to the previous tabbable element. Wraps from the first to the last. |

Tabbable elements are enabled `a[href]`, `button`, `input`, `select`, `textarea`, and elements with `tabindex` or `contenteditable`, excluding `tabindex="-1"` and anything inside a `hidden` element.

## Combobox

`Combobox` renders a `label`, an `input role="combobox"`, and a `listbox` of options. The input shows the selected option's label. Typing opens the popup and filters options by a case-insensitive substring match on the trimmed text. Typing does not call `onChange`. Selecting an option calls `onChange(option.value)`.

Filtering uses `includes`, so regex characters in the text are matched literally. When nothing matches, the popup shows a "No results" status.

### Combobox props

| Name | Type | Required / default | Description |
| --- | --- | --- | --- |
| `label` | `string` | required | Visible label for the input. |
| `options` | `ComboboxOption[]` | required | Options, where `ComboboxOption` is `{ value: string; label: string; disabled?: boolean }`. |
| `value` | `string \| null` | required | Selected option value, or `null` for none. Input text updates when it changes. |
| `onChange` | `(value: string \| null) => void` | required | Called when the user selects an enabled option. |
| `placeholder` | `string` | optional | Placeholder for the input. |
| `...input props` | `InputHTMLAttributes<HTMLInputElement>` | optional | Passed to the input, including `className`. `onKeyDown` and `onBlur` are not accepted. |

### Combobox keyboard

| Key | Behavior |
| --- | --- |
| `ArrowDown` | If closed, opens and activates the first enabled option. If open, activates the next enabled option. Wraps from the last option to the first. |
| `ArrowUp` | If closed, opens and activates the last enabled option. If open, activates the previous enabled option. Wraps from the first option to the last. |
| `Alt+ArrowDown` / `Alt+ArrowUp` | Opens the popup without moving the active option. |
| `Enter` | If an option is active, selects it, closes the popup and shows its label. Otherwise does nothing. |
| `Escape` | If open, closes the popup without calling `onChange`, restores the selected label, and stops the event from propagating (so an enclosing `Dialog` stays open). If closed, the event is not handled. |
| Typing | Opens the popup and filters the options. Clears the active option. |

Keys that are handled call `preventDefault`. Disabled options are skipped. Clicking an enabled option selects it and keeps focus in the input. Clicking a disabled option does nothing. Blurring the input closes the popup and restores the selected label without calling `onChange`.

import { describe, expect, it } from "vitest";
import readme from "../README.md?raw";
import indexSource from "../src/index.ts?raw";
import comboboxSource from "../src/Combobox.tsx?raw";
import dialogSource from "../src/Dialog.tsx?raw";
import tabsSource from "../src/Tabs.tsx?raw";
import * as library from "../src/index";
import type {
  ComboboxOption,
  ComboboxProps,
  DialogProps,
  TabListProps,
  TabPanelProps,
  TabProps,
  TabsProps,
} from "../src/index";

describe("package exports (P1)", () => {
  it("exports every component", () => {
    for (const name of ["Tabs", "TabList", "Tab", "TabPanel", "Dialog", "Combobox"] as const) {
      expect(typeof library[name]).toBe("function");
    }
  });

  it("exports prop types, checked at compile time by pnpm typecheck", () => {
    type ExportedTypes = [
      TabsProps,
      TabListProps,
      TabProps,
      TabPanelProps,
      DialogProps,
      ComboboxProps,
      ComboboxOption,
    ];
    const types: ExportedTypes | null = null;
    expect(types).toBeNull();
  });

  it("imports no stylesheets from any source file", () => {
    for (const source of [indexSource, comboboxSource, dialogSource, tabsSource]) {
      expect(source).not.toMatch(/\.css["']/);
    }
  });
});

describe("README (P2)", () => {
  const sections = readme.split(/^## /m).slice(1);

  it.each(["Tabs", "Dialog", "Combobox"])("documents %s with usage, props and keyboard tables", (name) => {
    const section = sections.find((text) => text.startsWith(`${name}\n`));
    expect(section).toBeDefined();
    expect(section).toContain("```tsx");
    expect(section).toContain("| Prop |");
    expect(section).toContain("| Key |");
  });
});

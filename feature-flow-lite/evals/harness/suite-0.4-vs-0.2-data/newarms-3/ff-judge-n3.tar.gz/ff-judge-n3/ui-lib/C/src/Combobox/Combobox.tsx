import {
  useId,
  useState,
  type ChangeEvent,
  type FocusEvent,
  type InputHTMLAttributes,
  type KeyboardEvent,
  type MouseEvent,
} from "react";

export interface ComboboxOption {
  value: string;
  label: string;
  disabled?: boolean;
}

export interface ComboboxProps
  extends Omit<InputHTMLAttributes<HTMLInputElement>, "value" | "defaultValue" | "onChange"> {
  label: string;
  options: ComboboxOption[];
  value: string | null;
  onChange: (value: string | null) => void;
}

function optionIdFor(baseId: string, value: string): string {
  return `${baseId}-option-${encodeURIComponent(value)}`;
}

export function Combobox({
  label,
  options,
  value,
  onChange,
  className,
  onKeyDown,
  onBlur,
  onClick,
  ...rest
}: ComboboxProps) {
  const baseId = useId();
  const [open, setOpen] = useState(false);
  // null means "not editing": the input shows the selected option's label.
  const [query, setQuery] = useState<string | null>(null);
  const [activeValue, setActiveValue] = useState<string | null>(null);

  const inputId = `${baseId}-input`;
  const labelId = `${baseId}-label`;
  const listboxId = `${baseId}-listbox`;
  const selectedLabel = options.find((option) => option.value === value)?.label ?? "";
  const text = query ?? selectedLabel;
  const needle = (query ?? "").toLowerCase();
  const filtered = options.filter((option) => option.label.toLowerCase().includes(needle));
  // activeValue is cleared whenever the listbox closes, so no open check is needed here.
  const activeOption =
    filtered.find((option) => option.value === activeValue && !option.disabled) ?? null;

  const close = () => {
    setOpen(false);
    setQuery(null);
    setActiveValue(null);
  };

  const choose = (option: ComboboxOption) => {
    onChange(option.value);
    close();
  };

  const clearValue = () => {
    if (value !== null) onChange(null);
    close();
  };

  const handleInputChange = (event: ChangeEvent<HTMLInputElement>) => {
    setQuery(event.target.value);
    setOpen(true);
    setActiveValue(null);
  };

  const handleKeyDown = (event: KeyboardEvent<HTMLInputElement>) => {
    onKeyDown?.(event);
    if (event.key === "ArrowDown" || event.key === "ArrowUp") {
      event.preventDefault();
      setOpen(true);
      // Step through enabled options only, wrapping at both ends.
      const enabled = filtered.filter((option) => !option.disabled);
      const count = enabled.length;
      const step = event.key === "ArrowDown" ? 1 : -1;
      const index = enabled.findIndex((option) => option.value === activeValue);
      // With no active option, ArrowDown starts at the first and ArrowUp at the last.
      const next = index === -1 ? (step === 1 ? 0 : count - 1) : (index + step + count) % count;
      setActiveValue(count === 0 ? null : enabled[next].value);
    } else if (event.key === "Enter") {
      if (activeOption !== null) {
        event.preventDefault();
        choose(activeOption);
      } else if (query === "") {
        clearValue();
      }
    } else if (event.key === "Escape" && open) {
      // Closing only the listbox; the event must not also close an enclosing dialog.
      event.stopPropagation();
      close();
    }
  };

  const handleBlur = (event: FocusEvent<HTMLInputElement>) => {
    onBlur?.(event);
    if (query === "") {
      clearValue();
    } else {
      close();
    }
  };

  const handleClick = (event: MouseEvent<HTMLInputElement>) => {
    onClick?.(event);
    setOpen(true);
  };

  return (
    <>
      <label id={labelId} htmlFor={inputId}>
        {label}
      </label>
      <input
        {...rest}
        id={inputId}
        type="text"
        role="combobox"
        className={className}
        autoComplete="off"
        value={text}
        aria-autocomplete="list"
        aria-expanded={open}
        aria-controls={listboxId}
        aria-activedescendant={activeOption ? optionIdFor(baseId, activeOption.value) : undefined}
        onChange={handleInputChange}
        onKeyDown={handleKeyDown}
        onBlur={handleBlur}
        onClick={handleClick}
      />
      <ul id={listboxId} role="listbox" aria-labelledby={labelId} hidden={!open}>
        {open &&
          filtered.map((option) => (
            <li
              key={option.value}
              id={optionIdFor(baseId, option.value)}
              role="option"
              aria-selected={option.value === value}
              aria-disabled={option.disabled ? true : undefined}
              // Keeps focus in the input so the blur handler does not close before the click lands.
              onMouseDown={(event) => event.preventDefault()}
              onClick={() => {
                if (!option.disabled) choose(option);
              }}
            >
              {option.label}
            </li>
          ))}
      </ul>
      <div role="status">{open && filtered.length === 0 ? "No results" : null}</div>
    </>
  );
}

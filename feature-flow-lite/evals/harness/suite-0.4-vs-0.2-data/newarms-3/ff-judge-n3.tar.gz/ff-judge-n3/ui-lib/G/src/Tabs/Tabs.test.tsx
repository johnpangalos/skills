import "@testing-library/jest-dom/vitest";
import { fireEvent, render, screen, within } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { memo, useState } from "react";
import { Tab, TabList, TabPanel, Tabs, type TabsProps } from "./Tabs";

type BasicProps = Partial<TabsProps> & { disabled?: string[] };

function Basic({ disabled = [], ...props }: BasicProps) {
  return (
    <Tabs {...props}>
      <TabList aria-label="Sections">
        <Tab value="a" disabled={disabled.includes("a")}>
          A
        </Tab>
        <Tab value="b" disabled={disabled.includes("b")}>
          B
        </Tab>
        <Tab value="c" disabled={disabled.includes("c")}>
          C
        </Tab>
      </TabList>
      <TabPanel value="a">Panel A</TabPanel>
      <TabPanel value="b">Panel B</TabPanel>
      <TabPanel value="c">Panel C</TabPanel>
    </Tabs>
  );
}

function Dynamic({ values }: { values: string[] }) {
  return (
    <Tabs defaultValue="a">
      <TabList aria-label="Dynamic">
        {values.map((value) => (
          <Tab key={value} value={value}>
            {value.toUpperCase()}
          </Tab>
        ))}
      </TabList>
      {values.map((value) => (
        <TabPanel key={value} value={value}>
          Panel {value}
        </TabPanel>
      ))}
    </Tabs>
  );
}

function Controlled({ onValueChange }: { onValueChange: (value: string) => void }) {
  const [value, setValue] = useState("a");
  return (
    <Basic
      value={value}
      onValueChange={(next) => {
        onValueChange(next);
        setValue(next);
      }}
    />
  );
}

// Memoized, so only its own state change re-renders it; the Tab inside disables or removes itself.
const SelfDisabling = memo(function SelfDisabling() {
  const [off, setOff] = useState(false);
  return (
    <>
      <Tab value="a" disabled={off}>
        A
      </Tab>
      <button type="button" onClick={() => setOff(true)}>
        Disable A
      </button>
    </>
  );
});

const SelfRemoving = memo(function SelfRemoving() {
  const [removed, setRemoved] = useState(false);
  return (
    <>
      {!removed && <Tab value="a">A</Tab>}
      <button type="button" onClick={() => setRemoved(true)}>
        Remove A
      </button>
    </>
  );
});

describe("Tabs", () => {
  it("links tablist, tabs and panel with ARIA attributes", () => {
    render(<Basic defaultValue="a" />);
    const tab = screen.getByRole("tab", { name: "A" });
    const panel = screen.getByRole("tabpanel");

    expect(screen.getByRole("tablist", { name: "Sections" })).toBeInTheDocument();
    expect(tab).toHaveAttribute("type", "button");
    expect(tab).toHaveAttribute("aria-selected", "true");
    expect(tab).toHaveAttribute("aria-controls", panel.id);
    expect(panel).toHaveAttribute("aria-labelledby", tab.id);
    expect(panel).toHaveAttribute("tabindex", "0");
  });

  it("accepts aria-labelledby on TabList", () => {
    render(
      <Tabs>
        <h2 id="heading">Settings</h2>
        <TabList aria-labelledby="heading">
          <Tab value="a">A</Tab>
        </TabList>
        <TabPanel value="a">Panel A</TabPanel>
      </Tabs>,
    );
    expect(screen.getByRole("tablist", { name: "Settings" })).toBeInTheDocument();
  });

  it("shows only the selected panel", () => {
    render(<Basic defaultValue="b" />);
    expect(screen.getByText("Panel B")).toBeVisible();
    expect(screen.getByText("Panel A")).not.toBeVisible();
    expect(screen.getByText("Panel C")).not.toBeVisible();
  });

  it("selects the defaultValue tab initially", () => {
    render(<Basic defaultValue="c" />);
    expect(screen.getByRole("tab", { name: "C" })).toHaveAttribute("aria-selected", "true");
  });

  it("selects the first enabled tab when there is no defaultValue", () => {
    render(<Basic disabled={["a"]} />);
    expect(screen.getByRole("tab", { name: "B" })).toHaveAttribute("aria-selected", "true");
    expect(screen.getByRole("tab", { name: "B" })).toHaveAttribute("tabindex", "0");
  });

  it("uses value over defaultValue in controlled mode and reports user selection", async () => {
    const user = userEvent.setup();
    const onValueChange = vi.fn();
    render(<Basic value="a" defaultValue="c" onValueChange={onValueChange} />);

    expect(screen.getByRole("tab", { name: "A" })).toHaveAttribute("aria-selected", "true");
    await user.click(screen.getByRole("tab", { name: "B" }));

    expect(onValueChange).toHaveBeenCalledTimes(1);
    expect(onValueChange).toHaveBeenCalledWith("b");
  });

  it("keeps the old selection when a controlled parent ignores onValueChange", async () => {
    const user = userEvent.setup();
    render(<Basic value="a" onValueChange={vi.fn()} />);
    await user.click(screen.getByRole("tab", { name: "C" }));

    expect(screen.getByRole("tab", { name: "A" })).toHaveAttribute("aria-selected", "true");
    expect(screen.getByRole("tab", { name: "C" })).toHaveAttribute("aria-selected", "false");
  });

  it("follows a controlled parent that updates its state", async () => {
    const user = userEvent.setup();
    const onValueChange = vi.fn();
    render(<Controlled onValueChange={onValueChange} />);
    await user.click(screen.getByRole("tab", { name: "B" }));

    expect(screen.getByRole("tab", { name: "B" })).toHaveAttribute("aria-selected", "true");
    expect(screen.getByText("Panel B")).toBeVisible();
    expect(onValueChange).toHaveBeenCalledWith("b");
  });

  it("does not call onValueChange when re-selecting the selected tab", async () => {
    const user = userEvent.setup();
    const onValueChange = vi.fn();
    render(<Basic defaultValue="a" onValueChange={onValueChange} />);
    await user.click(screen.getByRole("tab", { name: "A" }));

    expect(onValueChange).not.toHaveBeenCalled();
  });

  it("gives only the selected tab a tabIndex of 0 and Tab moves into the selected panel", async () => {
    const user = userEvent.setup();
    render(<Basic defaultValue="b" />);

    expect(screen.getByRole("tab", { name: "A" })).toHaveAttribute("tabindex", "-1");
    expect(screen.getByRole("tab", { name: "B" })).toHaveAttribute("tabindex", "0");
    expect(screen.getByRole("tab", { name: "C" })).toHaveAttribute("tabindex", "-1");

    await user.tab();
    expect(screen.getByRole("tab", { name: "B" })).toHaveFocus();
    await user.tab();
    expect(screen.getByRole("tabpanel")).toHaveFocus();
  });

  it("moves focus and selection with ArrowRight and ArrowLeft, wrapping at the ends", async () => {
    const user = userEvent.setup();
    const onValueChange = vi.fn();
    render(<Basic defaultValue="a" onValueChange={onValueChange} />);
    await user.tab();

    await user.keyboard("{ArrowRight}");
    expect(screen.getByRole("tab", { name: "B" })).toHaveFocus();
    expect(screen.getByRole("tab", { name: "B" })).toHaveAttribute("aria-selected", "true");
    expect(onValueChange).toHaveBeenLastCalledWith("b");

    await user.keyboard("{ArrowRight}{ArrowRight}");
    expect(screen.getByRole("tab", { name: "A" })).toHaveFocus();

    await user.keyboard("{ArrowLeft}");
    expect(screen.getByRole("tab", { name: "C" })).toHaveFocus();
    expect(screen.getByRole("tab", { name: "C" })).toHaveAttribute("aria-selected", "true");
  });

  it("skips disabled tabs with the arrow keys", async () => {
    const user = userEvent.setup();
    render(<Basic defaultValue="a" disabled={["b"]} />);
    await user.tab();

    await user.keyboard("{ArrowRight}");
    expect(screen.getByRole("tab", { name: "C" })).toHaveFocus();

    await user.keyboard("{ArrowLeft}");
    expect(screen.getByRole("tab", { name: "A" })).toHaveFocus();
  });

  it("moves to the first and last enabled tab with Home and End", async () => {
    const user = userEvent.setup();
    render(<Basic defaultValue="b" disabled={["a"]} />);
    await user.tab();

    await user.keyboard("{End}");
    expect(screen.getByRole("tab", { name: "C" })).toHaveFocus();
    expect(screen.getByRole("tab", { name: "C" })).toHaveAttribute("aria-selected", "true");

    await user.keyboard("{Home}");
    expect(screen.getByRole("tab", { name: "B" })).toHaveFocus();
    expect(screen.getByRole("tab", { name: "B" })).toHaveAttribute("aria-selected", "true");
  });

  it("calls preventDefault on handled keys", () => {
    render(<Basic defaultValue="a" />);
    const tab = screen.getByRole("tab", { name: "A" });

    expect(fireEvent.keyDown(tab, { key: "ArrowRight" })).toBe(false);
    expect(fireEvent.keyDown(tab, { key: "End" })).toBe(false);
    expect(fireEvent.keyDown(tab, { key: "x" })).toBe(true);
  });

  it("cannot select a disabled tab by click", async () => {
    const user = userEvent.setup();
    const onValueChange = vi.fn();
    render(<Basic defaultValue="a" disabled={["b"]} onValueChange={onValueChange} />);
    const disabledTab = screen.getByRole("tab", { name: "B" });

    expect(disabledTab).toBeDisabled();
    await user.click(disabledTab);
    expect(disabledTab).toHaveAttribute("aria-selected", "false");
    expect(onValueChange).not.toHaveBeenCalled();
  });

  it("selects an enabled tab on click", async () => {
    const user = userEvent.setup();
    render(<Basic defaultValue="a" />);
    await user.click(screen.getByRole("tab", { name: "C" }));

    expect(screen.getByRole("tab", { name: "C" })).toHaveAttribute("aria-selected", "true");
    expect(screen.getByText("Panel C")).toBeVisible();
  });

  it("keeps focus on the only enabled tab when arrows and Home/End are pressed", async () => {
    const user = userEvent.setup();
    const onValueChange = vi.fn();
    render(<Basic defaultValue="a" disabled={["b", "c"]} onValueChange={onValueChange} />);
    await user.tab();

    await user.keyboard("{ArrowRight}{ArrowLeft}{End}{Home}");
    expect(screen.getByRole("tab", { name: "A" })).toHaveFocus();
    expect(onValueChange).not.toHaveBeenCalled();
  });

  it("renders without a tab stop when every tab is disabled", async () => {
    const user = userEvent.setup();
    render(<Basic disabled={["a", "b", "c"]} />);

    for (const tab of screen.getAllByRole("tab")) {
      expect(tab).toHaveAttribute("aria-selected", "false");
      expect(tab).toHaveAttribute("tabindex", "-1");
    }
    await user.tab();
    expect(screen.queryByRole("tab", { selected: true })).toBeNull();
    expect(document.activeElement).toBe(document.body);
  });

  it("falls back to the first enabled tab when defaultValue names a disabled tab", async () => {
    const user = userEvent.setup();
    render(<Basic defaultValue="a" disabled={["a"]} />);
    await user.tab();

    expect(screen.getByRole("tab", { name: "B" })).toHaveFocus();
    expect(screen.getByRole("tab", { name: "B" })).toHaveAttribute("aria-selected", "true");
  });

  it("falls back to the first enabled tab when defaultValue names a nonexistent tab", () => {
    render(<Basic defaultValue="zzz" />);
    expect(screen.getByRole("tab", { name: "A" })).toHaveAttribute("tabindex", "0");
    expect(screen.getByRole("tab", { name: "A" })).toHaveAttribute("aria-selected", "true");
  });

  it("orders keyboard navigation by DOM order as tabs are added and removed", async () => {
    const user = userEvent.setup();
    const { rerender } = render(<Dynamic values={["a", "c"]} />);
    await user.tab();

    rerender(<Dynamic values={["a", "b", "c"]} />);
    await user.keyboard("{ArrowRight}");
    expect(screen.getByRole("tab", { name: "B" })).toHaveFocus();

    rerender(<Dynamic values={["a", "c"]} />);
    screen.getByRole("tab", { name: "A" }).focus();
    await user.keyboard("{ArrowRight}");
    expect(screen.getByRole("tab", { name: "C" })).toHaveFocus();
  });

  it("keeps two instances' ids unique and their keyboard handling isolated", async () => {
    const user = userEvent.setup();
    const { container } = render(
      <>
        <Basic />
        <Basic />
      </>,
    );
    const ids = Array.from(container.querySelectorAll("[id]")).map((element) => element.id);
    expect(new Set(ids).size).toBe(ids.length);

    const [first, second] = screen.getAllByRole("tablist").map((list) => within(list));
    await user.click(first.getByRole("tab", { name: "A" }));
    await user.keyboard("{ArrowRight}");

    expect(first.getByRole("tab", { name: "B" })).toHaveAttribute("aria-selected", "true");
    expect(second.getByRole("tab", { name: "A" })).toHaveAttribute("aria-selected", "true");
  });

  it("treats aria-disabled=\"true\" as disabled for click, keys and the fallback", async () => {
    const user = userEvent.setup();
    const onValueChange = vi.fn();
    render(
      <Tabs defaultValue="a" onValueChange={onValueChange}>
        <TabList aria-label="Sections">
          <Tab value="a">A</Tab>
          <Tab value="b" aria-disabled="true">
            B
          </Tab>
          <Tab value="c">C</Tab>
        </TabList>
        <TabPanel value="a">Panel A</TabPanel>
      </Tabs>,
    );
    const tabB = screen.getByRole("tab", { name: "B" });

    await user.click(tabB);
    expect(tabB).toHaveAttribute("aria-selected", "false");
    expect(onValueChange).not.toHaveBeenCalled();

    screen.getByRole("tab", { name: "A" }).focus();
    await user.keyboard("{ArrowRight}");
    expect(screen.getByRole("tab", { name: "C" })).toHaveFocus();
    expect(onValueChange).toHaveBeenCalledTimes(1);
    expect(onValueChange).toHaveBeenCalledWith("c");
  });

  it("falls back to the first enabled tab when defaultValue names an aria-disabled tab", () => {
    render(
      <Tabs defaultValue="b">
        <TabList aria-label="Sections">
          <Tab value="a">A</Tab>
          <Tab value="b" aria-disabled="true">
            B
          </Tab>
        </TabList>
        <TabPanel value="a">Panel A</TabPanel>
      </Tabs>,
    );
    expect(screen.getByRole("tab", { name: "A" })).toHaveAttribute("aria-selected", "true");
    expect(screen.getByRole("tab", { name: "A" })).toHaveAttribute("tabindex", "0");
  });

  it("moves the tab stop when a memoized child disables the selected tab itself", async () => {
    const user = userEvent.setup();
    render(
      <Tabs defaultValue="a">
        <TabList aria-label="Sections">
          <SelfDisabling />
          <Tab value="b">B</Tab>
        </TabList>
        <TabPanel value="a">Panel A</TabPanel>
        <TabPanel value="b">Panel B</TabPanel>
      </Tabs>,
    );
    expect(screen.getByRole("tab", { name: "A" })).toHaveAttribute("aria-selected", "true");

    await user.click(screen.getByRole("button", { name: "Disable A" }));
    expect(screen.getByRole("tab", { name: "B" })).toHaveAttribute("aria-selected", "true");
    expect(screen.getByRole("tab", { name: "B" })).toHaveAttribute("tabindex", "0");
  });

  it("moves the tab stop when a memoized child removes the selected tab itself", async () => {
    const user = userEvent.setup();
    render(
      <Tabs defaultValue="a">
        <TabList aria-label="Sections">
          <SelfRemoving />
          <Tab value="b">B</Tab>
        </TabList>
        <TabPanel value="a">Panel A</TabPanel>
        <TabPanel value="b">Panel B</TabPanel>
      </Tabs>,
    );

    await user.click(screen.getByRole("button", { name: "Remove A" }));
    expect(screen.queryByRole("tab", { name: "A" })).toBeNull();
    expect(screen.getByRole("tab", { name: "B" })).toHaveAttribute("aria-selected", "true");
    expect(screen.getByRole("tab", { name: "B" })).toHaveAttribute("tabindex", "0");
  });

  it("throws when Tab is rendered outside Tabs", () => {
    expect(() => render(<Tab value="a">A</Tab>)).toThrow("Tab must be rendered inside <Tabs>.");
  });
});

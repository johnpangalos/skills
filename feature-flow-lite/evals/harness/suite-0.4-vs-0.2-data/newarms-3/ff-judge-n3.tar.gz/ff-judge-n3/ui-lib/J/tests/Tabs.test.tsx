import { fireEvent, render, screen } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { describe, expect, it, vi } from "vitest";
import { Tab, TabList, TabPanel, Tabs, type TabsProps } from "../src/Tabs";

type ExampleProps = Partial<TabsProps> & { values?: string[]; disabled?: string[] };

function Example({ values = ["one", "two", "three", "four"], disabled = [], ...props }: ExampleProps) {
  return (
    <Tabs {...props}>
      <TabList aria-label="Sections">
        {values.map((value) => (
          <Tab key={value} value={value} disabled={disabled.includes(value)}>
            {value}
          </Tab>
        ))}
      </TabList>
      {values.map((value) => (
        <TabPanel key={value} value={value}>
          Panel {value}
        </TabPanel>
      ))}
    </Tabs>
  );
}

const tab = (name: string) => screen.getByRole("tab", { name });

describe("Tabs ARIA structure (T1)", () => {
  it("renders role=tablist with the given aria-label and no aria-orientation", () => {
    render(<Example />);
    const list = screen.getByRole("tablist", { name: "Sections" });
    expect(list).not.toHaveAttribute("aria-orientation");
  });

  it("renders each Tab as a button type=button role=tab wired to its panel", () => {
    render(<Example defaultValue="two" />);
    const two = tab("two");
    expect(two.tagName).toBe("BUTTON");
    expect(two).toHaveAttribute("type", "button");
    expect(two).toHaveAttribute("aria-selected", "true");
    const panel = document.getElementById(two.getAttribute("aria-controls") ?? "");
    expect(panel).toHaveAttribute("role", "tabpanel");
    expect(panel).toHaveAttribute("aria-labelledby", two.id);
  });

  it("renders TabPanel with tabIndex=0, hidden only when not selected, and kept in the DOM", () => {
    render(<Example defaultValue="one" />);
    const one = document.getElementById(tab("one").getAttribute("aria-controls") ?? "");
    const two = document.getElementById(tab("two").getAttribute("aria-controls") ?? "");
    expect(one).not.toHaveAttribute("hidden");
    expect(one).toHaveAttribute("tabindex", "0");
    expect(two).not.toBeNull();
    expect(two).toHaveAttribute("hidden");
  });
});

describe("Tabs selection (T2)", () => {
  it("selects defaultValue initially", () => {
    render(<Example defaultValue="three" />);
    expect(tab("three")).toHaveAttribute("aria-selected", "true");
    expect(tab("one")).toHaveAttribute("aria-selected", "false");
  });

  it("selects the first non-disabled tab when defaultValue is omitted", () => {
    render(<Example disabled={["one"]} />);
    expect(tab("two")).toHaveAttribute("aria-selected", "true");
    expect(tab("one")).toHaveAttribute("aria-selected", "false");
  });

  it("controlled value wins: a click reports onValueChange but keeps selection", async () => {
    const user = userEvent.setup();
    const onValueChange = vi.fn();
    render(<Example value="two" onValueChange={onValueChange} />);
    await user.click(tab("three"));
    expect(onValueChange).toHaveBeenCalledExactlyOnceWith("three");
    expect(tab("two")).toHaveAttribute("aria-selected", "true");
    expect(tab("three")).toHaveAttribute("aria-selected", "false");
  });

  it("uncontrolled click calls onValueChange and switches the selection", async () => {
    const user = userEvent.setup();
    const onValueChange = vi.fn();
    render(<Example defaultValue="one" onValueChange={onValueChange} />);
    await user.click(tab("three"));
    expect(onValueChange).toHaveBeenCalledExactlyOnceWith("three");
    expect(tab("three")).toHaveAttribute("aria-selected", "true");
    expect(screen.getByText("Panel three")).toBeVisible();
  });

  it("does not call onValueChange when re-selecting the selected tab", async () => {
    const user = userEvent.setup();
    const onValueChange = vi.fn();
    render(<Example defaultValue="one" onValueChange={onValueChange} />);
    await user.click(tab("one"));
    expect(onValueChange).not.toHaveBeenCalled();
  });
});

describe("Tabs roving tabindex (T3)", () => {
  it("gives tabIndex=0 to the selected tab and -1 to the others", () => {
    render(<Example defaultValue="two" />);
    expect(tab("two")).toHaveAttribute("tabindex", "0");
    for (const name of ["one", "three", "four"]) {
      expect(tab(name)).toHaveAttribute("tabindex", "-1");
    }
  });

  it("gives tabIndex=0 to the first enabled tab when defaultValue is a disabled tab", async () => {
    const user = userEvent.setup();
    render(<Example defaultValue="two" disabled={["two"]} />);
    expect(tab("one")).toHaveAttribute("tabindex", "0");
    expect(tab("two")).toHaveAttribute("tabindex", "-1");
    await user.tab();
    expect(tab("one")).toHaveFocus();
  });

  it("gives tabIndex=0 to the first enabled tab when defaultValue matches no tab", () => {
    render(<Example defaultValue="missing" />);
    expect(tab("one")).toHaveAttribute("tabindex", "0");
    expect(tab("two")).toHaveAttribute("tabindex", "-1");
  });
});

describe("Tabs keyboard (T4)", () => {
  it("ArrowRight moves focus to the next tab, selects it and calls onValueChange", async () => {
    const user = userEvent.setup();
    const onValueChange = vi.fn();
    render(<Example defaultValue="one" onValueChange={onValueChange} />);
    tab("one").focus();
    await user.keyboard("{ArrowRight}");
    expect(tab("two")).toHaveFocus();
    expect(tab("two")).toHaveAttribute("aria-selected", "true");
    expect(screen.getByText("Panel two")).toBeVisible();
    expect(onValueChange).toHaveBeenCalledExactlyOnceWith("two");
  });

  it("ArrowLeft moves focus to the previous tab", async () => {
    const user = userEvent.setup();
    render(<Example defaultValue="two" />);
    tab("two").focus();
    await user.keyboard("{ArrowLeft}");
    expect(tab("one")).toHaveFocus();
    expect(tab("one")).toHaveAttribute("aria-selected", "true");
  });

  it("wraps at both ends", async () => {
    const user = userEvent.setup();
    render(<Example defaultValue="four" />);
    tab("four").focus();
    await user.keyboard("{ArrowRight}");
    expect(tab("one")).toHaveFocus();
    await user.keyboard("{ArrowLeft}");
    expect(tab("four")).toHaveFocus();
  });

  it("Home and End go to the first and last enabled tab", async () => {
    const user = userEvent.setup();
    render(<Example defaultValue="two" />);
    tab("two").focus();
    await user.keyboard("{End}");
    expect(tab("four")).toHaveFocus();
    await user.keyboard("{Home}");
    expect(tab("one")).toHaveFocus();
  });

  it("prevents the default action for handled keys", () => {
    render(<Example defaultValue="one" />);
    const notPrevented = fireEvent.keyDown(tab("one"), { key: "ArrowRight" });
    expect(notPrevented).toBe(false);
  });

  it("ignores other keys", () => {
    const onValueChange = vi.fn();
    render(<Example defaultValue="one" onValueChange={onValueChange} />);
    const notPrevented = fireEvent.keyDown(tab("one"), { key: "a" });
    expect(notPrevented).toBe(true);
    expect(onValueChange).not.toHaveBeenCalled();
    expect(tab("one")).toHaveAttribute("aria-selected", "true");
  });

  it("controlled arrows call onValueChange but do not change the selection", async () => {
    const user = userEvent.setup();
    const onValueChange = vi.fn();
    render(<Example value="one" onValueChange={onValueChange} />);
    tab("one").focus();
    await user.keyboard("{ArrowRight}");
    expect(onValueChange).toHaveBeenCalledExactlyOnceWith("two");
    expect(tab("one")).toHaveAttribute("aria-selected", "true");
  });
});

describe("Tabs disabled tabs (T5)", () => {
  it("a click on a disabled tab does not select it", async () => {
    const user = userEvent.setup();
    const onValueChange = vi.fn();
    render(<Example defaultValue="one" disabled={["two"]} onValueChange={onValueChange} />);
    await user.click(tab("two"));
    expect(onValueChange).not.toHaveBeenCalled();
    expect(tab("two")).toHaveAttribute("aria-selected", "false");
  });

  it("keyboard navigation skips disabled tabs", async () => {
    const user = userEvent.setup();
    render(<Example defaultValue="one" disabled={["two"]} />);
    tab("one").focus();
    await user.keyboard("{ArrowRight}");
    expect(tab("three")).toHaveFocus();
  });

  it("with all but one tab disabled, arrows stay on the enabled tab", async () => {
    const user = userEvent.setup();
    const onValueChange = vi.fn();
    render(<Example defaultValue="three" disabled={["one", "two", "four"]} onValueChange={onValueChange} />);
    tab("three").focus();
    await user.keyboard("{ArrowRight}");
    await user.keyboard("{ArrowLeft}");
    expect(tab("three")).toHaveFocus();
    expect(onValueChange).not.toHaveBeenCalled();
  });

  it("with first and last tabs disabled, Home and End land on the nearest enabled tab", async () => {
    const user = userEvent.setup();
    render(<Example defaultValue="three" disabled={["one", "four"]} />);
    tab("three").focus();
    await user.keyboard("{Home}");
    expect(tab("two")).toHaveFocus();
    await user.keyboard("{End}");
    expect(tab("three")).toHaveFocus();
  });

  it("navigation follows DOM order after tabs are reordered", async () => {
    const user = userEvent.setup();
    const { rerender } = render(<Example defaultValue="one" />);
    rerender(<Example defaultValue="one" values={["one", "three", "two"]} />);
    tab("one").focus();
    await user.keyboard("{ArrowRight}");
    expect(tab("three")).toHaveFocus();
  });

  it("navigation skips a tab that was removed after mount", async () => {
    const user = userEvent.setup();
    const { rerender } = render(<Example defaultValue="one" />);
    rerender(<Example defaultValue="one" values={["one", "three"]} />);
    tab("one").focus();
    await user.keyboard("{ArrowRight}");
    expect(tab("three")).toHaveFocus();
  });

  it("with every tab disabled, keys do nothing and nothing throws", () => {
    const onValueChange = vi.fn();
    render(<Example disabled={["one", "two", "three", "four"]} onValueChange={onValueChange} />);
    for (const name of ["one", "two", "three", "four"]) {
      expect(tab(name)).toBeDisabled();
    }
    const list = screen.getByRole("tablist");
    expect(() => fireEvent.keyDown(list, { key: "ArrowRight" })).not.toThrow();
    expect(() => fireEvent.keyDown(list, { key: "End" })).not.toThrow();
    expect(onValueChange).not.toHaveBeenCalled();
  });
});

describe("Tabs props and ids", () => {
  it("passes className through to TabList, Tab and TabPanel", () => {
    render(
      <Tabs defaultValue="one">
        <TabList aria-label="Sections" className="list">
          <Tab value="one" className="tab">
            one
          </Tab>
        </TabList>
        <TabPanel value="one" className="panel">
          Panel
        </TabPanel>
      </Tabs>,
    );
    expect(screen.getByRole("tablist")).toHaveClass("list");
    expect(tab("one")).toHaveClass("tab");
    expect(screen.getByRole("tabpanel")).toHaveClass("panel");
  });

  it("two Tabs instances rendered side by side have distinct ids and their own wiring", () => {
    render(
      <>
        <Example defaultValue="one" />
        <Example defaultValue="one" />
      </>,
    );
    const tabs = screen.getAllByRole("tab", { name: "one" });
    expect(tabs).toHaveLength(2);
    expect(tabs[0].id).not.toBe(tabs[1].id);
    for (const current of tabs) {
      const panel = document.getElementById(current.getAttribute("aria-controls") ?? "");
      expect(panel).toHaveAttribute("aria-labelledby", current.id);
    }
  });

  it("throws when Tab is rendered outside Tabs", () => {
    const consoleError = vi.spyOn(console, "error").mockImplementation(() => {});
    expect(() => render(<Tab value="x">X</Tab>)).toThrowError(
      /^Tab, TabList and TabPanel must be rendered inside <Tabs>$/,
    );
    consoleError.mockRestore();
  });
});

import { render, screen } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { useState } from "react";
import { describe, expect, it, vi } from "vitest";
import { Dialog } from "./Dialog";

function backdrop(): HTMLElement {
  return document.querySelector<HTMLElement>("[data-backdrop]") as HTMLElement;
}

// Trigger outside the dialog; the dialog mounts only while `show` is true.
function Host({ show, withTrigger = true }: { show: boolean; withTrigger?: boolean }) {
  return (
    <>
      {withTrigger && <button type="button">Trigger</button>}
      {show && (
        <Dialog open onOpenChange={() => {}} title="Host dialog">
          <button type="button">Inner</button>
        </Dialog>
      )}
    </>
  );
}

function Stateful() {
  const [open, setOpen] = useState(false);
  return (
    <>
      <button type="button" onClick={() => setOpen(true)}>
        Open
      </button>
      <Dialog open={open} onOpenChange={setOpen} title="Confirm" description="Are you sure?">
        <button type="button">Yes</button>
        <button type="button">No</button>
      </Dialog>
    </>
  );
}

function Nested() {
  const [outer, setOuter] = useState(true);
  const [inner, setInner] = useState(false);
  return (
    <Dialog open={outer} onOpenChange={setOuter} title="Outer">
      <button type="button" onClick={() => setInner(true)}>
        Open inner
      </button>
      <Dialog open={inner} onOpenChange={setInner} title="Inner">
        <button type="button">Inner action</button>
      </Dialog>
    </Dialog>
  );
}

function Growing() {
  const [showLate, setShowLate] = useState(false);
  return (
    <Dialog open onOpenChange={() => {}} title="Growing">
      <button type="button" onClick={() => setShowLate(true)}>
        Add
      </button>
      {showLate && <button type="button">Late</button>}
    </Dialog>
  );
}

// Dialog stays open even when the parent ignores onOpenChange, so tests can pin focus inside it.
function Pinned() {
  return (
    <>
      <button type="button">Outside</button>
      <Dialog open onOpenChange={() => {}} title="Pinned">
        <button type="button">Inside</button>
      </Dialog>
    </>
  );
}

describe("Dialog", () => {
  it("renders nothing when closed", () => {
    render(<Dialog open={false} onOpenChange={() => {}} title="Hidden" />);
    expect(screen.queryByRole("dialog")).toBeNull();
    expect(document.querySelector("[data-backdrop]")).toBeNull();
  });

  it("renders into document.body with backdrop, modal dialog, heading and description", () => {
    render(<Dialog open onOpenChange={() => {}} title="Confirm" description="Are you sure?" />);
    const dialog = screen.getByRole("dialog", { name: "Confirm" });
    expect(dialog.parentElement).toBe(document.body);
    expect(dialog).toHaveAttribute("aria-modal", "true");
    expect(screen.getByRole("heading", { level: 2, name: "Confirm" })).toBeInTheDocument();
    expect(dialog).toHaveAccessibleDescription("Are you sure?");
    expect(backdrop()).toBeInTheDocument();
  });

  it("omits aria-describedby when no description is given", () => {
    render(<Dialog open onOpenChange={() => {}} title="Plain" />);
    expect(screen.getByRole("dialog")).not.toHaveAttribute("aria-describedby");
  });

  it("focuses the first focusable element on open", () => {
    render(<Stateful />);
    screen.getByRole("button", { name: "Open" }).focus();
    expect(screen.getByRole("button", { name: "Open" })).toHaveFocus();
  });

  it("focuses the first focusable element inside the dialog on open", () => {
    render(
      <Dialog open onOpenChange={() => {}} title="Two">
        <button type="button">First</button>
        <button type="button">Second</button>
      </Dialog>,
    );
    expect(screen.getByRole("button", { name: "First" })).toHaveFocus();
  });

  it("focuses the dialog element itself when it has no focusable content", () => {
    render(<Dialog open onOpenChange={() => {}} title="Text only">Just text</Dialog>);
    expect(screen.getByRole("dialog")).toHaveFocus();
    expect(screen.getByRole("dialog")).toHaveAttribute("tabindex", "-1");
  });

  it("Tab from the last focusable wraps to the first, Shift+Tab from the first wraps to the last", async () => {
    const user = userEvent.setup();
    render(<Stateful />);
    await user.click(screen.getByRole("button", { name: "Open" }));
    expect(screen.getByRole("button", { name: "Yes" })).toHaveFocus();
    await user.tab();
    expect(screen.getByRole("button", { name: "No" })).toHaveFocus();
    await user.tab();
    expect(screen.getByRole("button", { name: "Yes" })).toHaveFocus();
    await user.tab({ shift: true });
    expect(screen.getByRole("button", { name: "No" })).toHaveFocus();
  });

  it("with zero focusables, Tab keeps focus on the dialog", async () => {
    const user = userEvent.setup();
    render(<Dialog open onOpenChange={() => {}} title="Empty">Text</Dialog>);
    await user.tab();
    expect(screen.getByRole("dialog")).toHaveFocus();
  });

  it("skips disabled, tabindex=-1, hidden and type=hidden elements in the trap", async () => {
    const user = userEvent.setup();
    render(
      <Dialog open onOpenChange={() => {}} title="Skips">
        <input type="text" aria-label="Name" />
        <button type="button" disabled>
          Off
        </button>
        <button type="button" tabIndex={-1}>
          Skip
        </button>
        <input type="hidden" name="token" />
        <button type="button">Last</button>
      </Dialog>,
    );
    expect(screen.getByRole("textbox", { name: "Name" })).toHaveFocus();
    await user.tab({ shift: true });
    expect(screen.getByRole("button", { name: "Last" })).toHaveFocus();
    await user.tab();
    expect(screen.getByRole("textbox", { name: "Name" })).toHaveFocus();
  });

  it("the trap uses focusables present at keypress time", async () => {
    const user = userEvent.setup();
    render(<Growing />);
    await user.click(screen.getByRole("button", { name: "Add" }));
    await user.tab();
    expect(screen.getByRole("button", { name: "Late" })).toHaveFocus();
    await user.tab();
    expect(screen.getByRole("button", { name: "Add" })).toHaveFocus();
  });

  it("Escape calls onOpenChange(false)", async () => {
    const user = userEvent.setup();
    const onOpenChange = vi.fn();
    render(
      <Dialog open onOpenChange={onOpenChange} title="Esc">
        <button type="button">Action</button>
      </Dialog>,
    );
    await user.keyboard("{Escape}");
    expect(onOpenChange).toHaveBeenCalledExactlyOnceWith(false);
  });

  it("clicking the backdrop calls onOpenChange(false)", async () => {
    const user = userEvent.setup();
    const onOpenChange = vi.fn();
    render(<Dialog open onOpenChange={onOpenChange} title="Backdrop" />);
    await user.click(backdrop());
    expect(onOpenChange).toHaveBeenCalledExactlyOnceWith(false);
  });

  it("clicking inside the content does not close", async () => {
    const user = userEvent.setup();
    const onOpenChange = vi.fn();
    render(
      <Dialog open onOpenChange={onOpenChange} title="Inside">
        <button type="button">Action</button>
      </Dialog>,
    );
    await user.click(screen.getByRole("button", { name: "Action" }));
    await user.click(screen.getByRole("dialog"));
    expect(onOpenChange).not.toHaveBeenCalled();
  });

  it("a drag that starts inside the content and ends on the backdrop does not close", async () => {
    const user = userEvent.setup();
    const onOpenChange = vi.fn();
    render(
      <Dialog open onOpenChange={onOpenChange} title="Drag">
        <button type="button">Action</button>
      </Dialog>,
    );
    await user.pointer([
      { keys: "[MouseLeft>]", target: screen.getByRole("dialog") },
      { target: backdrop() },
      { keys: "[/MouseLeft]", target: backdrop() },
    ]);
    expect(onOpenChange).not.toHaveBeenCalled();
  });

  it("focus returns to the trigger when open goes false", async () => {
    const user = userEvent.setup();
    render(<Stateful />);
    await user.click(screen.getByRole("button", { name: "Open" }));
    expect(screen.getByRole("button", { name: "Yes" })).toHaveFocus();
    await user.keyboard("{Escape}");
    expect(screen.queryByRole("dialog")).toBeNull();
    expect(screen.getByRole("button", { name: "Open" })).toHaveFocus();
  });

  it("focus returns to the trigger when the Dialog unmounts", () => {
    const { rerender } = render(<Host show={false} />);
    screen.getByRole("button", { name: "Trigger" }).focus();
    rerender(<Host show />);
    expect(screen.getByRole("button", { name: "Inner" })).toHaveFocus();
    rerender(<Host show={false} />);
    expect(screen.getByRole("button", { name: "Trigger" })).toHaveFocus();
  });

  it("closing when the trigger was removed while open does not throw", () => {
    const { rerender } = render(<Host show={false} />);
    screen.getByRole("button", { name: "Trigger" }).focus();
    rerender(<Host show />);
    rerender(<Host show withTrigger={false} />);
    expect(() => rerender(<Host show={false} withTrigger={false} />)).not.toThrow();
    expect(document.activeElement).toBe(document.body);
  });

  it("controlled only: if the parent ignores onOpenChange(false), it stays open", async () => {
    const user = userEvent.setup();
    const onOpenChange = vi.fn();
    render(
      <Dialog open onOpenChange={onOpenChange} title="Sticky">
        <button type="button">Action</button>
      </Dialog>,
    );
    await user.keyboard("{Escape}");
    await user.click(backdrop());
    expect(onOpenChange).toHaveBeenCalledWith(false);
    expect(screen.getByRole("dialog", { name: "Sticky" })).toBeInTheDocument();
  });

  it("nested dialogs: Escape closes only the topmost and focus returns to the trigger in the outer dialog", async () => {
    const user = userEvent.setup();
    render(<Nested />);
    await user.click(screen.getByRole("button", { name: "Open inner" }));
    expect(screen.getByRole("button", { name: "Inner action" })).toHaveFocus();
    await user.keyboard("{Escape}");
    expect(screen.queryByRole("dialog", { name: "Inner" })).toBeNull();
    expect(screen.getByRole("dialog", { name: "Outer" })).toBeInTheDocument();
    expect(screen.getByRole("button", { name: "Open inner" })).toHaveFocus();
    await user.keyboard("{Escape}");
    expect(screen.queryByRole("dialog", { name: "Outer" })).toBeNull();
  });

  it("Tab with focus lost to body enters the dialog and wraps; Escape with focus on body closes it", async () => {
    const user = userEvent.setup();
    render(<Stateful />);
    await user.click(screen.getByRole("button", { name: "Open" }));
    (document.activeElement as HTMLElement).blur();
    expect(document.body).toHaveFocus();
    await user.tab();
    expect(screen.getByRole("button", { name: "Yes" })).toHaveFocus();
    (document.activeElement as HTMLElement).blur();
    await user.keyboard("{Escape}");
    expect(screen.queryByRole("dialog", { name: "Confirm" })).toBeNull();
    expect(screen.getByRole("button", { name: "Open" })).toHaveFocus();
  });

  it("focus that moves outside the dialog is pulled back to the first focusable", async () => {
    const user = userEvent.setup();
    render(<Pinned />);
    expect(screen.getByRole("button", { name: "Inside" })).toHaveFocus();
    await user.click(screen.getByRole("button", { name: "Outside" }));
    expect(screen.getByRole("button", { name: "Inside" })).toHaveFocus();
  });

  it("a backdrop click while the parent ignores onOpenChange keeps focus inside the dialog", async () => {
    const user = userEvent.setup();
    render(<Pinned />);
    await user.click(backdrop());
    expect(screen.getByRole("button", { name: "Inside" })).toHaveFocus();
    expect(screen.getByRole("dialog", { name: "Pinned" })).toBeInTheDocument();
  });

  it("passes className and extra props to the content element", () => {
    render(
      <Dialog open onOpenChange={() => {}} title="Props" className="modal" data-testid="dlg">
        Body
      </Dialog>,
    );
    expect(screen.getByTestId("dlg")).toHaveClass("modal");
    expect(screen.getByTestId("dlg")).toHaveAttribute("role", "dialog");
  });

  it("two dialogs on one page have unique ids", () => {
    render(
      <>
        <Dialog open onOpenChange={() => {}} title="First" description="One" />
        <Dialog open onOpenChange={() => {}} title="Second" description="Two" />
      </>,
    );
    const ids = Array.from(document.querySelectorAll("[id]")).map((element) => element.id);
    expect(new Set(ids).size).toBe(ids.length);
    expect(screen.getByRole("dialog", { name: "Second" })).toHaveAccessibleDescription("Two");
  });
});

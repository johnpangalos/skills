import { render, screen } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { StrictMode, useState } from "react";
import { describe, expect, it, vi } from "vitest";
import { Tab, TabList, TabPanel, Tabs } from "./Tabs";

type ExampleProps = {
  defaultValue?: string;
  value?: string;
  onValueChange?: (value: string) => void;
  disabledBanana?: boolean;
};

function Example({ defaultValue, value, onValueChange, disabledBanana = false }: ExampleProps) {
  return (
    <Tabs defaultValue={defaultValue} value={value} onValueChange={onValueChange}>
      <TabList aria-label="Fruit">
        <Tab value="apple">Apple</Tab>
        <Tab value="banana" disabled={disabledBanana}>
          Banana
        </Tab>
        <Tab value="cherry">Cherry</Tab>
      </TabList>
      <TabPanel value="apple">Apple panel</TabPanel>
      <TabPanel value="banana">Banana panel</TabPanel>
      <TabPanel value="cherry">Cherry panel</TabPanel>
    </Tabs>
  );
}

const tab = (name: string) => screen.getByRole("tab", { name });

describe("Tabs", () => {
  it("selects the defaultValue and puts only the selected tab in the tab order", () => {
    render(<Example defaultValue="banana" />);
    expect(screen.getByRole("tablist", { name: "Fruit" })).toHaveAttribute("aria-orientation", "horizontal");
    expect(tab("Banana")).toHaveAttribute("aria-selected", "true");
    expect(tab("Apple")).toHaveAttribute("aria-selected", "false");
    expect(tab("Banana")).toHaveAttribute("tabindex", "0");
    expect(tab("Apple")).toHaveAttribute("tabindex", "-1");
    expect(tab("Cherry")).toHaveAttribute("tabindex", "-1");
    expect(screen.getByText("Banana panel")).toBeVisible();
    expect(screen.getByText("Apple panel")).not.toBeVisible();
  });

  it("selects the first enabled tab when neither value nor defaultValue is given", () => {
    const onValueChange = vi.fn();
    render(<Example onValueChange={onValueChange} disabledBanana />);
    expect(tab("Apple")).toHaveAttribute("aria-selected", "true");
    expect(tab("Apple")).toHaveAttribute("tabindex", "0");
    // The implicit first selection is not a user change.
    expect(onValueChange).not.toHaveBeenCalled();
  });

  it("does not call onValueChange on mount under StrictMode", () => {
    const onValueChange = vi.fn();
    render(
      <StrictMode>
        <Example onValueChange={onValueChange} />
      </StrictMode>,
    );
    expect(tab("Apple")).toHaveAttribute("aria-selected", "true");
    expect(onValueChange).not.toHaveBeenCalled();
  });

  it("makes the first enabled tab the tab stop when defaultValue names a disabled tab", () => {
    render(<Example defaultValue="banana" disabledBanana />);
    expect(tab("Apple")).toHaveAttribute("tabindex", "0");
    expect(tab("Cherry")).toHaveAttribute("tabindex", "-1");
  });

  it("makes the first enabled tab the tab stop when defaultValue names no tab", () => {
    render(<Example defaultValue="missing" />);
    expect(tab("Apple")).toHaveAttribute("tabindex", "0");
  });

  it("selects a tab on click and reports the change once", async () => {
    const user = userEvent.setup();
    const onValueChange = vi.fn();
    render(<Example defaultValue="apple" onValueChange={onValueChange} />);
    await user.click(tab("Cherry"));
    expect(onValueChange).toHaveBeenCalledTimes(1);
    expect(onValueChange).toHaveBeenCalledWith("cherry");
    expect(tab("Cherry")).toHaveAttribute("aria-selected", "true");
    expect(screen.getByText("Cherry panel")).toBeVisible();
  });

  it("does not report a change when the selected tab is clicked again", async () => {
    const user = userEvent.setup();
    const onValueChange = vi.fn();
    render(<Example defaultValue="apple" onValueChange={onValueChange} />);
    await user.click(tab("Apple"));
    expect(onValueChange).not.toHaveBeenCalled();
  });

  it("does not select a disabled tab on click", async () => {
    const user = userEvent.setup();
    const onValueChange = vi.fn();
    render(<Example defaultValue="apple" onValueChange={onValueChange} disabledBanana />);
    expect(tab("Banana")).toHaveAttribute("disabled");
    await user.click(tab("Banana"));
    expect(onValueChange).not.toHaveBeenCalled();
    expect(tab("Apple")).toHaveAttribute("aria-selected", "true");
  });

  it("moves focus and selection with ArrowRight and ArrowLeft, wrapping at the ends", async () => {
    const user = userEvent.setup();
    const onValueChange = vi.fn();
    render(<Example defaultValue="apple" onValueChange={onValueChange} />);
    await user.tab();
    expect(tab("Apple")).toHaveFocus();
    await user.keyboard("{ArrowRight}");
    expect(tab("Banana")).toHaveFocus();
    expect(tab("Banana")).toHaveAttribute("aria-selected", "true");
    await user.keyboard("{ArrowRight}");
    expect(tab("Cherry")).toHaveFocus();
    await user.keyboard("{ArrowRight}");
    expect(tab("Apple")).toHaveFocus();
    await user.keyboard("{ArrowLeft}");
    expect(tab("Cherry")).toHaveFocus();
    expect(onValueChange).toHaveBeenLastCalledWith("cherry");
  });

  it("skips disabled tabs with the arrow keys", async () => {
    const user = userEvent.setup();
    render(<Example defaultValue="apple" disabledBanana />);
    await user.tab();
    await user.keyboard("{ArrowRight}");
    expect(tab("Cherry")).toHaveFocus();
    await user.keyboard("{ArrowLeft}");
    expect(tab("Apple")).toHaveFocus();
  });

  it("jumps to the first and last enabled tab with Home and End", async () => {
    const user = userEvent.setup();
    render(<Example defaultValue="banana" disabledBanana />);
    await user.tab();
    expect(tab("Apple")).toHaveFocus();
    await user.keyboard("{End}");
    expect(tab("Cherry")).toHaveFocus();
    await user.keyboard("{Home}");
    expect(tab("Apple")).toHaveFocus();
  });

  it("ignores ArrowUp, ArrowDown and other keys", async () => {
    const user = userEvent.setup();
    const onValueChange = vi.fn();
    render(<Example defaultValue="apple" onValueChange={onValueChange} />);
    await user.tab();
    await user.keyboard("{ArrowDown}{ArrowUp}a");
    expect(tab("Apple")).toHaveFocus();
    expect(onValueChange).not.toHaveBeenCalled();
  });

  it("does nothing with the arrow keys when every tab is disabled", async () => {
    const user = userEvent.setup();
    const onValueChange = vi.fn();
    render(
      <Tabs defaultValue="a" onValueChange={onValueChange}>
        <TabList aria-label="Off">
          <Tab value="a" disabled>
            A
          </Tab>
          <Tab value="b" disabled>
            B
          </Tab>
        </TabList>
      </Tabs>,
    );
    expect(tab("A")).not.toHaveAttribute("tabindex", "0");
    await user.keyboard("{ArrowRight}{Home}{End}");
    expect(onValueChange).not.toHaveBeenCalled();
  });

  it("keeps focus on the only enabled tab when arrows are pressed", async () => {
    const user = userEvent.setup();
    render(
      <Tabs defaultValue="a">
        <TabList aria-label="Solo">
          <Tab value="a">A</Tab>
          <Tab value="b" disabled>
            B
          </Tab>
        </TabList>
      </Tabs>,
    );
    await user.tab();
    await user.keyboard("{ArrowRight}{ArrowLeft}");
    expect(tab("A")).toHaveFocus();
    expect(tab("A")).toHaveAttribute("aria-selected", "true");
  });

  it("follows the DOM order when tabs are conditionally rendered", async () => {
    const user = userEvent.setup();
    function Conditional({ showMiddle }: { showMiddle: boolean }) {
      return (
        <Tabs defaultValue="a">
          <TabList aria-label="Cond">
            <Tab value="a">A</Tab>
            {showMiddle && <Tab value="m">M</Tab>}
            <Tab value="z">Z</Tab>
          </TabList>
        </Tabs>
      );
    }
    const { rerender } = render(<Conditional showMiddle={false} />);
    await user.tab();
    await user.keyboard("{ArrowRight}");
    expect(tab("Z")).toHaveFocus();
    rerender(<Conditional showMiddle />);
    await user.keyboard("{ArrowLeft}");
    expect(tab("M")).toHaveFocus();
  });

  it("moves the tab stop to the first enabled tab when the selected tab is removed", () => {
    function Removable({ showApple }: { showApple: boolean }) {
      return (
        <Tabs defaultValue="apple">
          <TabList aria-label="Removable">
            {showApple && <Tab value="apple">Apple</Tab>}
            <Tab value="cherry">Cherry</Tab>
          </TabList>
        </Tabs>
      );
    }
    const { rerender } = render(<Removable showApple />);
    expect(tab("Apple")).toHaveAttribute("tabindex", "0");
    rerender(<Removable showApple={false} />);
    expect(tab("Cherry")).toHaveAttribute("tabindex", "0");
  });

  it("links each tab to its panel in both directions", () => {
    render(<Example defaultValue="apple" />);
    const cherry = tab("Cherry");
    const panel = document.getElementById(cherry.getAttribute("aria-controls") ?? "");
    expect(panel).toHaveAttribute("role", "tabpanel");
    expect(panel).toHaveAttribute("aria-labelledby", cherry.id);
    expect(panel).toHaveAttribute("tabindex", "0");
  });

  it("keeps the selection when the parent ignores onValueChange, and follows value changes", async () => {
    const user = userEvent.setup();
    const onValueChange = vi.fn();
    const { rerender } = render(<Example value="apple" onValueChange={onValueChange} />);
    await user.click(tab("Cherry"));
    expect(onValueChange).toHaveBeenCalledWith("cherry");
    expect(tab("Apple")).toHaveAttribute("aria-selected", "true");
    expect(tab("Cherry")).toHaveAttribute("aria-selected", "false");
    rerender(<Example value="cherry" onValueChange={onValueChange} />);
    expect(tab("Cherry")).toHaveAttribute("aria-selected", "true");
  });

  it("forwards className and data attributes without overriding the ARIA wiring", () => {
    render(
      <Tabs defaultValue="apple" className="root" data-testid="root">
        <TabList aria-label="Fruit" className="list">
          <Tab value="apple" className="tab" data-kind="fruit" id="custom" role="presentation">
            Apple
          </Tab>
        </TabList>
        <TabPanel value="apple" className="panel">
          Apple panel
        </TabPanel>
      </Tabs>,
    );
    expect(screen.getByTestId("root")).toHaveClass("root");
    expect(screen.getByRole("tablist")).toHaveClass("list");
    expect(tab("Apple")).toHaveClass("tab");
    expect(tab("Apple")).toHaveAttribute("data-kind", "fruit");
    expect(tab("Apple")).not.toHaveAttribute("id", "custom");
    expect(screen.getByRole("tabpanel")).toHaveClass("panel");
  });

  it("gives two Tabs on one page unique ids", () => {
    render(
      <>
        <Example defaultValue="apple" />
        <Example defaultValue="apple" />
      </>,
    );
    const ids = Array.from(document.querySelectorAll("[id]"), (element) => element.id);
    expect(ids.length).toBeGreaterThan(0);
    expect(new Set(ids).size).toBe(ids.length);
  });

  it("builds valid, linked ids for values with spaces, colons and quotes", async () => {
    const user = userEvent.setup();
    const value = 'a b x:y "c"';
    render(
      <Tabs defaultValue={value}>
        <TabList aria-label="Odd">
          <Tab value={value}>Odd</Tab>
        </TabList>
        <TabPanel value={value}>Odd panel</TabPanel>
      </Tabs>,
    );
    const oddTab = tab("Odd");
    const panel = screen.getByRole("tabpanel", { name: "Odd" });
    expect(oddTab.id).not.toMatch(/\s/);
    expect(panel.id).not.toMatch(/\s/);
    expect(oddTab).toHaveAttribute("aria-controls", panel.id);
    expect(panel).toHaveAttribute("aria-labelledby", oddTab.id);
    expect(panel).toBeVisible();
    await user.tab();
    expect(oddTab).toHaveFocus();
  });

  it("moves the tab stop when a stateful child removes the selected tab", async () => {
    const user = userEvent.setup();
    function Dyn() {
      const [gone, setGone] = useState(false);
      return (
        <>
          {!gone && <Tab value="b">B</Tab>}
          <button onClick={() => setGone(true)}>Remove B</button>
        </>
      );
    }
    render(
      <Tabs defaultValue="b">
        <TabList aria-label="x">
          <Tab value="a">A</Tab>
          <Dyn />
        </TabList>
      </Tabs>,
    );
    expect(tab("B")).toHaveAttribute("tabindex", "0");
    await user.click(screen.getByRole("button", { name: "Remove B" }));
    expect(tab("A")).toHaveAttribute("tabindex", "0");
  });

  it("moves the tab stop when a stateful child disables the selected tab", async () => {
    const user = userEvent.setup();
    function Dyn() {
      const [disabled, setDisabled] = useState(false);
      return (
        <>
          <Tab value="b" disabled={disabled}>
            B
          </Tab>
          <button onClick={() => setDisabled(true)}>Disable B</button>
        </>
      );
    }
    render(
      <Tabs defaultValue="b">
        <TabList aria-label="x">
          <Tab value="a">A</Tab>
          <Dyn />
        </TabList>
      </Tabs>,
    );
    expect(tab("B")).toHaveAttribute("tabindex", "0");
    await user.click(screen.getByRole("button", { name: "Disable B" }));
    expect(tab("B")).toBeDisabled();
    expect(tab("A")).toHaveAttribute("tabindex", "0");
  });

  it("throws when Tab is rendered outside Tabs", () => {
    const consoleError = vi.spyOn(console, "error").mockImplementation(() => {});
    expect(() => render(<Tab value="apple">Apple</Tab>)).toThrow(
      "Tab, TabList and TabPanel must be rendered inside Tabs",
    );
    consoleError.mockRestore();
  });
});

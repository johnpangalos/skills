import {
  createContext,
  useCallback,
  useContext,
  useId,
  useLayoutEffect,
  useRef,
  useState,
  type ComponentPropsWithoutRef,
  type KeyboardEvent,
} from "react";

type TabsContextValue = {
  baseId: string;
  requested: string | undefined;
  selected: string | undefined;
  select: (value: string) => void;
  setSelected: (value: string | undefined) => void;
  // Called by a Tab when it mounts, unmounts or changes availability, so TabList recomputes the tab stop.
  notify: () => void;
};

const TabsContext = createContext<TabsContextValue | null>(null);

function useTabsContext(component: string): TabsContextValue {
  const context = useContext(TabsContext);
  if (context === null) {
    throw new Error(`${component} must be rendered inside <Tabs>.`);
  }
  return context;
}

function tabId(baseId: string, value: string): string {
  return `${baseId}-tab-${encodeURIComponent(value)}`;
}

function panelId(baseId: string, value: string): string {
  return `${baseId}-panel-${encodeURIComponent(value)}`;
}

function getTabs(list: HTMLElement): HTMLElement[] {
  return Array.from(list.querySelectorAll<HTMLElement>('[role="tab"]'));
}

function isEnabledTab(tab: HTMLElement): boolean {
  return !tab.hasAttribute("disabled") && tab.getAttribute("aria-disabled") !== "true";
}

export type TabsProps = Omit<ComponentPropsWithoutRef<"div">, "defaultValue"> & {
  defaultValue?: string;
  value?: string;
  onValueChange?: (value: string) => void;
};

export function Tabs({ defaultValue, value, onValueChange, children, ...rest }: TabsProps) {
  const baseId = useId();
  const [internal, setInternal] = useState(defaultValue);
  // The tab that is actually selected: the requested value when it names an enabled tab, else the first enabled tab.
  const [selected, setSelected] = useState<string>();
  const [, setVersion] = useState(0);
  const notify = useCallback(() => setVersion((version) => version + 1), []);
  const requested = value ?? internal;

  const select = (next: string) => {
    if (next === selected) return;
    if (value === undefined) setInternal(next);
    onValueChange?.(next);
  };

  return (
    <div {...rest}>
      <TabsContext value={{ baseId, requested, selected, select, setSelected, notify }}>{children}</TabsContext>
    </div>
  );
}

export type TabListProps = ComponentPropsWithoutRef<"div"> &
  ({ "aria-label": string } | { "aria-labelledby": string });

export function TabList({ onKeyDown, ...rest }: TabListProps) {
  const { requested, setSelected, select } = useTabsContext("TabList");
  const ref = useRef<HTMLDivElement>(null);

  // Runs after every render so tabs added, removed or disabled later are picked up. Tab order is DOM order.
  useLayoutEffect(() => {
    const list = ref.current;
    if (!list) return;
    const enabled = getTabs(list)
      .filter(isEnabledTab)
      .map((tab) => tab.dataset.value ?? "");
    setSelected(requested !== undefined && enabled.includes(requested) ? requested : enabled[0]);
  });

  const handleKeyDown = (event: KeyboardEvent<HTMLDivElement>) => {
    onKeyDown?.(event);
    const tabs = getTabs(event.currentTarget).filter(isEnabledTab);
    const index = tabs.indexOf(event.target as HTMLElement);
    if (index === -1) return;

    let nextIndex: number;
    switch (event.key) {
      case "ArrowRight":
        nextIndex = (index + 1) % tabs.length;
        break;
      case "ArrowLeft":
        nextIndex = (index - 1 + tabs.length) % tabs.length;
        break;
      case "Home":
        nextIndex = 0;
        break;
      case "End":
        nextIndex = tabs.length - 1;
        break;
      default:
        return;
    }
    event.preventDefault();
    const tab = tabs[nextIndex];
    tab.focus();
    select(tab.dataset.value ?? "");
  };

  return <div {...rest} role="tablist" ref={ref} onKeyDown={handleKeyDown} />;
}

export type TabProps = Omit<ComponentPropsWithoutRef<"button">, "value"> & {
  value: string;
  disabled?: boolean;
};

export function Tab({ value, disabled = false, onClick, ...rest }: TabProps) {
  const { baseId, selected, select, notify } = useTabsContext("Tab");
  const isSelected = selected === value;
  const isDisabled = disabled || rest["aria-disabled"] === true || rest["aria-disabled"] === "true";

  useLayoutEffect(() => {
    notify();
    return () => notify();
  }, [value, isDisabled, notify]);

  return (
    <button
      type="button"
      {...rest}
      role="tab"
      id={tabId(baseId, value)}
      aria-selected={isSelected}
      aria-controls={panelId(baseId, value)}
      tabIndex={isSelected ? 0 : -1}
      disabled={disabled}
      data-value={value}
      onClick={(event) => {
        onClick?.(event);
        if (!isDisabled) select(value);
      }}
    />
  );
}

export type TabPanelProps = ComponentPropsWithoutRef<"div"> & {
  value: string;
};

export function TabPanel({ value, ...rest }: TabPanelProps) {
  const { baseId, selected } = useTabsContext("TabPanel");

  return (
    <div
      {...rest}
      role="tabpanel"
      id={panelId(baseId, value)}
      aria-labelledby={tabId(baseId, value)}
      tabIndex={0}
      hidden={selected !== value}
    />
  );
}

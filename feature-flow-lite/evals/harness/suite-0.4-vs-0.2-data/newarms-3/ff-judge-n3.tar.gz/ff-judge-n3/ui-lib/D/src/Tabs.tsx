import {
  createContext,
  useCallback,
  useContext,
  useId,
  useLayoutEffect,
  useMemo,
  useRef,
  useState,
  type ComponentPropsWithoutRef,
  type KeyboardEvent,
  type ReactNode,
} from "react";

export type TabsProps = {
  defaultValue?: string;
  value?: string;
  onValueChange?: (value: string) => void;
  children?: ReactNode;
};

type TabsContextValue = {
  baseId: string;
  selected: string | null;
  tabStop: string | null;
  select: (value: string) => void;
  syncTabs: (enabledValues: string[]) => void;
};

const TabsContext = createContext<TabsContextValue | null>(null);

function useTabsContext(): TabsContextValue {
  const context = useContext(TabsContext);
  if (context === null) {
    throw new Error("Tab, TabList and TabPanel must be rendered inside Tabs");
  }
  return context;
}

const tabId = (baseId: string, value: string) => `${baseId}-tab-${encodeURIComponent(value)}`;
const panelId = (baseId: string, value: string) => `${baseId}-panel-${encodeURIComponent(value)}`;

export function Tabs({ defaultValue, value, onValueChange, children }: TabsProps) {
  const baseId = useId();
  const [internalValue, setInternalValue] = useState<string | null>(defaultValue ?? null);
  const [tabStop, setTabStop] = useState<string | null>(null);
  const initialized = useRef(false);
  const isControlled = value !== undefined;
  const selected = (isControlled ? value : internalValue) ?? null;

  const select = useCallback(
    (next: string) => {
      if (next === selected) return;
      if (!isControlled) setInternalValue(next);
      onValueChange?.(next);
    },
    [isControlled, onValueChange, selected],
  );

  const syncTabs = useCallback(
    (enabledValues: string[]) => {
      const selectable = selected !== null && enabledValues.includes(selected);
      setTabStop(selectable ? selected : (enabledValues[0] ?? null));
      // Once tabs exist: an uncontrolled Tabs must start on an enabled tab.
      if (!initialized.current && enabledValues.length > 0) {
        initialized.current = true;
        if (!isControlled && !selectable) setInternalValue(enabledValues[0]);
      }
    },
    [isControlled, selected],
  );

  const context = useMemo(
    () => ({ baseId, selected, tabStop, select, syncTabs }),
    [baseId, selected, tabStop, select, syncTabs],
  );

  return <TabsContext.Provider value={context}>{children}</TabsContext.Provider>;
}

export type TabListProps = Omit<
  ComponentPropsWithoutRef<"div">,
  "role" | "aria-orientation" | "aria-label" | "onKeyDown"
> & {
  "aria-label": string;
};

function enabledTabs(list: HTMLElement | null): HTMLButtonElement[] {
  if (list === null) return [];
  return Array.from(list.querySelectorAll<HTMLButtonElement>('[role="tab"]:not(:disabled)'));
}

function nextTabIndex(key: string, index: number, count: number): number | null {
  switch (key) {
    case "ArrowRight":
      return (index + 1) % count;
    case "ArrowLeft":
      return (index - 1 + count) % count;
    case "Home":
      return 0;
    case "End":
      return count - 1;
    default:
      return null;
  }
}

export function TabList({ children, ...props }: TabListProps) {
  const { select, syncTabs } = useTabsContext();
  const listRef = useRef<HTMLDivElement>(null);

  // Runs after every render so the tab stop follows tabs that were added or removed.
  useLayoutEffect(() => {
    syncTabs(enabledTabs(listRef.current).map((tab) => tab.dataset.value ?? ""));
  });

  function handleKeyDown(event: KeyboardEvent<HTMLDivElement>) {
    const tabs = enabledTabs(listRef.current);
    const index = tabs.indexOf(event.target as HTMLButtonElement);
    if (index === -1) return;
    const next = nextTabIndex(event.key, index, tabs.length);
    if (next === null) return;
    event.preventDefault();
    const target = tabs[next];
    target.focus();
    select(target.dataset.value ?? "");
  }

  return (
    <div
      {...props}
      ref={listRef}
      role="tablist"
      aria-orientation="horizontal"
      onKeyDown={handleKeyDown}
    >
      {children}
    </div>
  );
}

export type TabProps = Omit<ComponentPropsWithoutRef<"button">, "role" | "type" | "value"> & {
  value: string;
};

export function Tab({ value, disabled = false, onClick, children, ...props }: TabProps) {
  const { baseId, selected, tabStop, select } = useTabsContext();
  return (
    <button
      {...props}
      type="button"
      role="tab"
      id={tabId(baseId, value)}
      data-value={value}
      aria-selected={selected === value}
      aria-controls={panelId(baseId, value)}
      aria-disabled={disabled ? true : undefined}
      disabled={disabled}
      tabIndex={value === tabStop ? 0 : -1}
      onClick={(event) => {
        onClick?.(event);
        if (!disabled) select(value);
      }}
    >
      {children}
    </button>
  );
}

export type TabPanelProps = Omit<ComponentPropsWithoutRef<"div">, "role" | "aria-labelledby"> & {
  value: string;
};

export function TabPanel({ value, children, ...props }: TabPanelProps) {
  const { baseId, selected } = useTabsContext();
  return (
    <div
      {...props}
      role="tabpanel"
      id={panelId(baseId, value)}
      aria-labelledby={tabId(baseId, value)}
      tabIndex={0}
      hidden={selected !== value}
    >
      {children}
    </div>
  );
}

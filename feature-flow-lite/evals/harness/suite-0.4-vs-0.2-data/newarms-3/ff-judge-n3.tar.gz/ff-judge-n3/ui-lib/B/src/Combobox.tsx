import {
  useId,
  useState,
  type ChangeEvent,
  type ComponentPropsWithoutRef,
  type FocusEvent,
  type KeyboardEvent,
} from "react";

export type ComboboxOption = { value: string; label: string; disabled?: boolean };

export type ComboboxProps = Omit<
  ComponentPropsWithoutRef<"input">,
  "value" | "defaultValue" | "onChange" | "role"
> & {
  label: string;
  options: ComboboxOption[];
  value?: string | null;
  defaultValue?: string | null;
  onChange?: (value: string | null) => void;
};

type Match = { option: ComboboxOption; index: number };

const normalize = (text: string) => text.trim().replace(/\s+/g, " ").toLowerCase();

// Plain substring match, so regex metacharacters in the query are just text.
function matchOptions(options: ComboboxOption[], query: string | null): Match[] {
  const needle = query === null ? "" : normalize(query);
  return options.flatMap((option, index) =>
    normalize(option.label).includes(needle) ? [{ option, index }] : [],
  );
}

// Moves to the next enabled match, wrapping at the end and skipping disabled options.
function nextActive(matches: Match[], current: number | null): number | null {
  const enabled = matches.filter((match) => !match.option.disabled);
  if (enabled.length === 0) return null;
  const position = enabled.findIndex((match) => match.index === current);
  return position === -1 ? enabled[0].index : enabled[(position + 1) % enabled.length].index;
}

// Moves to the previous enabled match, wrapping at the start and skipping disabled options.
function prevActive(matches: Match[], current: number | null): number | null {
  const enabled = matches.filter((match) => !match.option.disabled);
  if (enabled.length === 0) return null;
  const position = enabled.findIndex((match) => match.index === current);
  return position === -1
    ? enabled[enabled.length - 1].index
    : enabled[(position - 1 + enabled.length) % enabled.length].index;
}

export function Combobox({
  label,
  options,
  value,
  defaultValue = null,
  onChange,
  onKeyDown,
  onBlur,
  ...rest
}: ComboboxProps) {
  const baseId = useId();
  const labelId = `${baseId}-label`;
  const inputId = `${baseId}-input`;
  const listboxId = `${baseId}-listbox`;
  const optionId = (index: number) => `${baseId}-option-${index}`;

  const [internal, setInternal] = useState<string | null>(defaultValue);
  const [open, setOpen] = useState(false);
  // null means "not filtering": the input shows the selected label.
  const [query, setQuery] = useState<string | null>(null);
  const [active, setActive] = useState<number | null>(null);

  const current = value === undefined ? internal : value;
  const selected = options.find((option) => option.value === current);
  const matches = matchOptions(options, query);
  const activeIndex = open && matches.some((match) => match.index === active) ? active : null;

  const close = () => {
    setOpen(false);
    setQuery(null);
    setActive(null);
  };

  const openWith = (nextQuery: string | null) => {
    setOpen(true);
    setQuery(nextQuery);
    // Empty text leaves no option active, so Enter on it clears the value.
    const first = matchOptions(options, nextQuery).find((match) => !match.option.disabled);
    setActive(nextQuery === "" ? null : (first?.index ?? null));
  };

  const select = (option: ComboboxOption) => {
    if (option.disabled) return;
    if (value === undefined) setInternal(option.value);
    onChange?.(option.value);
    close();
  };

  // Emptied text confirmed by Enter or blur clears the value to null.
  const clear = () => {
    close();
    if (current === null) return;
    if (value === undefined) setInternal(null);
    onChange?.(null);
  };

  const handleKeyDown = (event: KeyboardEvent<HTMLInputElement>) => {
    onKeyDown?.(event);
    if (event.key === "ArrowDown") {
      event.preventDefault();
      if (open) setActive(nextActive(matches, activeIndex));
      else openWith(null);
    } else if (event.key === "ArrowUp") {
      event.preventDefault();
      if (open) setActive(prevActive(matches, activeIndex));
    } else if (event.key === "Enter") {
      if (!open) return;
      event.preventDefault();
      const option = activeIndex === null ? undefined : options[activeIndex];
      if (option) select(option);
      else if (query === "") clear();
    } else if (event.key === "Escape") {
      if (!open) return;
      // Stop here so an enclosing Dialog does not also close.
      event.preventDefault();
      event.stopPropagation();
      close();
    }
  };

  const handleBlur = (event: FocusEvent<HTMLInputElement>) => {
    onBlur?.(event);
    if (query === "") clear();
    else close();
  };

  return (
    <>
      <label id={labelId} htmlFor={inputId}>
        {label}
      </label>
      <input
        autoComplete="off"
        {...rest}
        id={inputId}
        role="combobox"
        aria-autocomplete="list"
        aria-expanded={open}
        aria-haspopup="listbox"
        aria-controls={listboxId}
        aria-activedescendant={activeIndex === null ? undefined : optionId(activeIndex)}
        value={query ?? selected?.label ?? ""}
        onChange={(event: ChangeEvent<HTMLInputElement>) => openWith(event.target.value)}
        onKeyDown={handleKeyDown}
        onBlur={handleBlur}
      />
      <div id={listboxId} role="listbox" aria-labelledby={labelId} hidden={!open}>
        {open
          ? matches.map(({ option, index }) => (
              <div
                key={index}
                id={optionId(index)}
                role="option"
                aria-selected={option.value === current}
                aria-disabled={option.disabled ? true : undefined}
                data-active={index === activeIndex ? "true" : undefined}
                onMouseDown={(event) => event.preventDefault()}
                onClick={() => select(option)}
              >
                {option.label}
              </div>
            ))
          : null}
      </div>
      {open && matches.length === 0 ? <div role="status">No results</div> : null}
    </>
  );
}

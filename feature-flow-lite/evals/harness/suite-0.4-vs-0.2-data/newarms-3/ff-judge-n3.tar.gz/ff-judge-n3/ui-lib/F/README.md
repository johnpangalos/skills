# @acme/ui

Accessible React 19 components. No CSS is shipped: every component renders semantic markup and forwards unknown DOM props (`className`, `style`, `id`, `data-*`) to its root element, so you style it however you like.

Scripts: `pnpm test` (Vitest + Testing Library), `pnpm typecheck` (`tsc --noEmit`).

## Tabs

```tsx
import { Tabs, TabList, Tab, TabPanel } from "@acme/ui";

<Tabs defaultValue="profile">
  <TabList aria-label="Account">
    <Tab value="profile">Profile</Tab>
    <Tab value="billing">Billing</Tab>
    <Tab value="security" disabled>Security</Tab>
  </TabList>
  <TabPanel value="profile">Profile settings</TabPanel>
  <TabPanel value="billing">Billing settings</TabPanel>
  <TabPanel value="security">Security settings</TabPanel>
</Tabs>;
```

Uncontrolled: pass `defaultValue`. Controlled: pass `value` and `onValueChange`. With neither, the first enabled tab is selected. If `value` matches no enabled tab, the first enabled tab is shown and focusable.

### Tabs props

| Name | Type | Required / default | Description |
| --- | --- | --- | --- |
| `value` | `string` | optional | Controlled selected tab value. |
| `defaultValue` | `string` | optional | Initially selected tab in uncontrolled mode. |
| `onValueChange` | `(value: string) => void` | optional | Called when the user selects a different enabled tab. Selecting the current tab does not call it. |
| `...div props` | `ComponentPropsWithoutRef<"div">` | optional | Forwarded to the root `div`. |

### TabList props

| Name | Type | Required / default | Description |
| --- | --- | --- | --- |
| `aria-label` | `string` | required | Accessible name for the `tablist`. |
| `...div props` | `ComponentPropsWithoutRef<"div">` | optional | Forwarded to the `role="tablist"` element. |

### Tab props

| Name | Type | Required / default | Description |
| --- | --- | --- | --- |
| `value` | `string` | required | Identifies the tab; must match a `TabPanel` `value`. |
| `disabled` | `boolean` | `false` | Disables the tab: it is skipped by keyboard navigation and clicks do nothing. |
| `...button props` | `ComponentPropsWithoutRef<"button">` | optional | Forwarded to the `<button role="tab">`. `id`, `aria-selected`, `aria-controls` and `tabIndex` are generated. |

### TabPanel props

| Name | Type | Required / default | Description |
| --- | --- | --- | --- |
| `value` | `string` | required | The tab this panel belongs to. Non-selected panels are `hidden`. |
| `...div props` | `ComponentPropsWithoutRef<"div">` | optional | Forwarded to the `role="tabpanel"` element. |

### Tabs keyboard

| Key | Action |
| --- | --- |
| `Tab` | Moves focus into the selected tab, then into the panel. Leaves the tablist. |
| `ArrowRight` | Moves to the next enabled tab (wraps) and selects it. |
| `ArrowLeft` | Moves to the previous enabled tab (wraps) and selects it. |
| `Home` | Moves to the first enabled tab and selects it. |
| `End` | Moves to the last enabled tab and selects it. |

Other keys do nothing and are not prevented.

## Dialog

```tsx
import { Dialog } from "@acme/ui";

<Dialog
  open={isOpen}
  onOpenChange={setIsOpen}
  title="Delete file"
  description="This cannot be undone."
>
  <button onClick={() => setIsOpen(false)}>Cancel</button>
  <button onClick={handleDelete}>Delete</button>
</Dialog>;
```

Renders nothing when `open` is false. When open, it is portaled to `document.body` with a backdrop element and a `role="dialog"` element (`aria-modal="true"`). Focus moves to the first focusable element inside (or the dialog itself), and returns to the previously focused element when the dialog closes. The dialog never closes itself: `onOpenChange(false)` is the only close request.

### Dialog props

| Name | Type | Required / default | Description |
| --- | --- | --- | --- |
| `open` | `boolean` | required | Whether the dialog is shown. |
| `onOpenChange` | `(open: boolean) => void` | required | Called with `false` on Escape or a backdrop click. |
| `title` | `string` | required | Rendered in an `h2` and used as the accessible name. |
| `description` | `string` | optional | Rendered below the title and used as `aria-describedby`. Omitted when not given. |
| `...div props` | `ComponentPropsWithoutRef<"div">` | optional | Forwarded to the `role="dialog"` element. |

### Dialog keyboard

| Key | Action |
| --- | --- |
| `Tab` | Moves to the next focusable element inside the dialog, wrapping from last to first. Focus never leaves the dialog. |
| `Shift+Tab` | Moves to the previous focusable element inside the dialog, wrapping from first to last. |
| `Escape` | Calls `onOpenChange(false)`, even when focus is in a nested input. If an open Combobox popup is inside the dialog, the first Escape only closes that popup. |

With nested dialogs, only the most recently opened one handles Escape and Tab. Focusable elements are computed on each Tab press, so elements added after opening are included. Disabled elements and `tabindex="-1"` elements are skipped. A backdrop click closes the dialog only when the press and the release both happen on the backdrop, so a text selection dragged out of the dialog does not close it.

## Combobox

```tsx
import { Combobox, type ComboboxOption } from "@acme/ui";

const fruits: ComboboxOption<string>[] = [
  { value: "apple", label: "Apple" },
  { value: "banana", label: "Banana", disabled: true },
];

function FruitPicker() {
  const [value, setValue] = useState<string | null>(null);
  return <Combobox label="Fruit" options={fruits} value={value} onChange={setValue} />;
}
```

Fully controlled: `value` and `onChange` are both required. `Combobox` is generic over the option value type `T` (`string | number`, defaulting to both), so `useState<string | null>` setters can be passed straight to `onChange`. The input shows the selected option's label while closed. Typing opens the list and filters options by a case-insensitive substring of `label`, treated as plain text.

`onChange` is called only when the user chooses an option, either with Enter on the active option or by clicking an enabled option. Clearing the text and blurring keep the current value: `onChange` is not called and the input goes back to the selected label. Escape closes the list and restores the selected label without calling `onChange`.

### Combobox props

| Name | Type | Required / default | Description |
| --- | --- | --- | --- |
| `label` | `string` | required | Text of the `<label>` tied to the input. |
| `options` | `ComboboxOption<T>[]` | required | Options to show. `ComboboxOption<T>` is `{ value: T; label: string; disabled?: boolean }`, where `T extends string \| number` (default `string \| number`). |
| `value` | `T \| null` | required | The selected option's `value`, or `null` for no selection. Falsy values such as `0` and `""` are real selections. |
| `onChange` | `(value: T \| null) => void` | required | Called with the chosen option's `value`. Typed to accept `useState<T \| null>` setters. |
| `placeholder` | `string` | optional | Placeholder for the input. |
| `...div props` | `ComponentPropsWithoutRef<"div">` | optional | Forwarded to the root `div`. |

### Combobox keyboard

| Key | Action |
| --- | --- |
| Typing | Opens the list, filters options, and makes the first enabled match active. |
| `ArrowDown` | If closed, opens the list and makes the first enabled option active (one press does both). If open, moves the active option to the next enabled option (wraps). |
| `ArrowUp` | If closed, opens the list and makes the last enabled option active (one press does both). If open, moves the active option to the previous enabled option (wraps). |
| `Enter` | With the list open, chooses the active option, closes the list, and shows its label; with no active option it does nothing. With the list open it never submits a surrounding form. With the list closed it is not handled, so a surrounding form submits as usual. |
| `Escape` | Closes the list and restores the selected label without calling `onChange`. Stops propagation so an enclosing Dialog stays open. |
| `Tab` / blur | Closes the list and restores the selected label without calling `onChange`. |

Mouse: clicking an enabled option chooses it; clicking a disabled option does nothing.

import type { ComponentProps } from "react";
import { useState } from "react";
import { describe, expect, it, vi } from "vitest";
import { fireEvent, render, screen } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { Tab, TabList, TabPanel, Tabs } from "../src/Tabs";

type TabsRootProps = ComponentProps<typeof Tabs>;

function Example({ disabled = [], ...props }: TabsRootProps & { disabled?: string[] }) {
  return (
    <Tabs {...props}>
      <TabList aria-label="Sections">
        <Tab value="one" disabled={disabled.includes("one")}>
          One
        </Tab>
        <Tab value="two" disabled={disabled.includes("two")}>
          Two
        </Tab>
        <Tab value="three" disabled={disabled.includes("three")}>
          Three
        </Tab>
      </TabList>
      <TabPanel value="one">Panel one</TabPanel>
      <TabPanel value="two">Panel two</TabPanel>
      <TabPanel value="three">Panel three</TabPanel>
    </Tabs>
  );
}

function ControlledExample() {
  const [value, setValue] = useState("one");
  return <Example value={value} onValueChange={setValue} />;
}

function Reorderable({ values }: { values: string[] }) {
  return (
    <Tabs defaultValue={values[0]}>
      <TabList aria-label="Reorder">
        {values.map((value) => (
          <Tab key={value} value={value}>
            {value}
          </Tab>
        ))}
      </TabList>
    </Tabs>
  );
}

const tab = (name: string) => screen.getByRole("tab", { name });

describe("Tabs", () => {
  describe("structure (T1)", () => {
    it("renders a labelled tablist of button tabs with aria-selected", () => {
      render(<Example />);
      const list = screen.getByRole("tablist", { name: "Sections" });
      expect(list).toContainElement(tab("One"));
      expect(tab("One").tagName).toBe("BUTTON");
      expect(tab("One")).toHaveAttribute("type", "button");
      expect(tab("One")).toHaveAttribute("aria-selected", "true");
      expect(tab("Two")).toHaveAttribute("aria-selected", "false");
    });

    it("links each tab to its panel and each panel back to its tab", () => {
      render(<Example />);
      const panel = document.getElementById(tab("One").getAttribute("aria-controls") ?? "");
      expect(panel).toHaveAttribute("role", "tabpanel");
      expect(panel).toHaveAttribute("aria-labelledby", tab("One").id);
      expect(panel).toHaveAttribute("tabindex", "0");
      expect(panel).toBeVisible();
    });

    it("hides panels that are not selected", () => {
      render(<Example />);
      const hidden = document.getElementById(tab("Two").getAttribute("aria-controls") ?? "");
      expect(hidden).toHaveAttribute("hidden");
      expect(screen.getAllByRole("tabpanel")).toHaveLength(1);
    });

    it("does not share ids between two Tabs instances", () => {
      render(
        <>
          <Example />
          <Example />
        </>,
      );
      const ids = Array.from(document.querySelectorAll("[id]"), (element) => element.id);
      expect(ids).toHaveLength(12);
      expect(new Set(ids).size).toBe(12);
    });

    it("keeps generated ids free of whitespace when a value contains spaces", () => {
      render(
        <Tabs defaultValue="a b">
          <TabList aria-label="Spaced">
            <Tab value="a b">A</Tab>
          </TabList>
          <TabPanel value="a b">P</TabPanel>
        </Tabs>,
      );
      expect(tab("A").id).not.toMatch(/\s/);
      expect(screen.getByRole("tabpanel")).toHaveAttribute("aria-labelledby", tab("A").id);
    });
  });

  describe("roving tabindex (T2)", () => {
    it("gives tabIndex 0 to the selected tab and -1 to the others", () => {
      render(<Example defaultValue="two" />);
      expect(tab("Two")).toHaveAttribute("tabindex", "0");
      expect(tab("One")).toHaveAttribute("tabindex", "-1");
      expect(tab("Three")).toHaveAttribute("tabindex", "-1");
    });

    it("gives the first enabled tab tabIndex 0 when no tab matches value", () => {
      render(<Example value="nope" />);
      expect(tab("One")).toHaveAttribute("tabindex", "0");
      expect(tab("Two")).toHaveAttribute("tabindex", "-1");
    });

    it("skips disabled tabs when choosing the fallback tab stop", () => {
      render(<Example value="nope" disabled={["one"]} />);
      expect(tab("One")).toHaveAttribute("tabindex", "-1");
      expect(tab("Two")).toHaveAttribute("tabindex", "0");
    });
  });

  describe("keyboard navigation (T3)", () => {
    it("ArrowRight and ArrowLeft move focus and select the adjacent tab", async () => {
      const user = userEvent.setup();
      const onValueChange = vi.fn();
      render(<Example onValueChange={onValueChange} />);
      tab("One").focus();
      await user.keyboard("{ArrowRight}");
      expect(tab("Two")).toHaveFocus();
      expect(onValueChange).toHaveBeenLastCalledWith("two");
      expect(tab("Two")).toHaveAttribute("aria-selected", "true");
      expect(screen.getByRole("tabpanel")).toHaveTextContent("Panel two");
      await user.keyboard("{ArrowLeft}");
      expect(tab("One")).toHaveFocus();
      expect(onValueChange).toHaveBeenLastCalledWith("one");
    });

    it("wraps from the last tab to the first and from the first to the last", async () => {
      const user = userEvent.setup();
      render(<Example />);
      tab("Three").focus();
      await user.keyboard("{ArrowRight}");
      expect(tab("One")).toHaveFocus();
      await user.keyboard("{ArrowLeft}");
      expect(tab("Three")).toHaveFocus();
    });

    it("skips disabled tabs when moving with the arrow keys", async () => {
      const user = userEvent.setup();
      render(<Example disabled={["two"]} />);
      tab("One").focus();
      await user.keyboard("{ArrowRight}");
      expect(tab("Three")).toHaveFocus();
    });

    it("Home and End go to the first and last enabled tab", async () => {
      const user = userEvent.setup();
      render(<Example disabled={["one"]} />);
      tab("Three").focus();
      await user.keyboard("{Home}");
      expect(tab("Two")).toHaveFocus();
      await user.keyboard("{End}");
      expect(tab("Three")).toHaveFocus();
    });

    it("calls preventDefault on arrow, Home and End keys but not on other keys", () => {
      render(<Example />);
      for (const key of ["ArrowRight", "ArrowLeft", "Home", "End"]) {
        expect(fireEvent.keyDown(tab("One"), { key })).toBe(false);
      }
      expect(fireEvent.keyDown(tab("One"), { key: "a" })).toBe(true);
    });
  });

  describe("mouse and disabled tabs (T4)", () => {
    it("selects an enabled tab on click", async () => {
      const user = userEvent.setup();
      const onValueChange = vi.fn();
      render(<Example onValueChange={onValueChange} />);
      await user.click(tab("Two"));
      expect(tab("Two")).toHaveAttribute("aria-selected", "true");
      expect(onValueChange).toHaveBeenCalledWith("two");
    });

    it("marks disabled tabs with aria-disabled and ignores clicks on them", async () => {
      const user = userEvent.setup();
      const onValueChange = vi.fn();
      render(<Example disabled={["two"]} onValueChange={onValueChange} />);
      expect(tab("Two")).toHaveAttribute("aria-disabled", "true");
      await user.click(tab("Two"));
      expect(tab("Two")).toHaveAttribute("aria-selected", "false");
      expect(tab("One")).toHaveAttribute("aria-selected", "true");
      expect(onValueChange).not.toHaveBeenCalled();
    });
  });

  describe("value and defaultValue (T5)", () => {
    it("uses defaultValue as the initial tab", () => {
      render(<Example defaultValue="three" />);
      expect(tab("Three")).toHaveAttribute("aria-selected", "true");
      expect(screen.getByRole("tabpanel")).toHaveTextContent("Panel three");
    });

    it("selects the first enabled tab when neither value nor defaultValue is given", () => {
      render(<Example disabled={["one"]} />);
      expect(tab("Two")).toHaveAttribute("aria-selected", "true");
      expect(tab("One")).toHaveAttribute("aria-selected", "false");
    });

    it("lets value win over defaultValue", () => {
      render(<Example value="two" defaultValue="three" />);
      expect(tab("Two")).toHaveAttribute("aria-selected", "true");
      expect(screen.getByRole("tabpanel")).toHaveTextContent("Panel two");
    });

    it("reports changes but keeps the selection when the parent ignores them", async () => {
      const user = userEvent.setup();
      const onValueChange = vi.fn();
      render(<Example value="one" onValueChange={onValueChange} />);
      await user.click(tab("Two"));
      expect(onValueChange).toHaveBeenCalledWith("two");
      expect(tab("One")).toHaveAttribute("aria-selected", "true");
      expect(tab("Two")).toHaveAttribute("aria-selected", "false");
      expect(screen.getByRole("tabpanel")).toHaveTextContent("Panel one");
    });

    it("follows the value prop when the parent updates it", async () => {
      const user = userEvent.setup();
      render(<ControlledExample />);
      await user.click(tab("Two"));
      expect(tab("Two")).toHaveAttribute("aria-selected", "true");
      expect(screen.getByRole("tabpanel")).toHaveTextContent("Panel two");
    });
  });

  describe("selection happens on click and keys, not on focus (T5, T6)", () => {
    it("clicking a tab in a controlled tablist that ignores updates calls onValueChange once", async () => {
      const user = userEvent.setup();
      const onValueChange = vi.fn();
      render(<Example value="one" onValueChange={onValueChange} />);
      await user.click(tab("Two"));
      expect(onValueChange).toHaveBeenCalledTimes(1);
      expect(onValueChange).toHaveBeenCalledWith("two");
    });

    it("tabbing into a tablist whose value matches no tab calls nothing and focuses the first enabled tab", async () => {
      const user = userEvent.setup();
      const onValueChange = vi.fn();
      render(<Example value="nope" onValueChange={onValueChange} />);
      await user.tab();
      expect(tab("One")).toHaveFocus();
      expect(onValueChange).not.toHaveBeenCalled();
    });

    it("arrow and End keys report the target value when the parent ignores updates", async () => {
      const user = userEvent.setup();
      const onValueChange = vi.fn();
      render(<Example value="one" onValueChange={onValueChange} />);
      tab("One").focus();
      await user.keyboard("{ArrowRight}");
      expect(tab("Two")).toHaveFocus();
      expect(onValueChange).toHaveBeenLastCalledWith("two");
      await user.keyboard("{End}");
      expect(tab("Three")).toHaveFocus();
      expect(onValueChange).toHaveBeenLastCalledWith("three");
      expect(tab("One")).toHaveAttribute("aria-selected", "true");
    });

    it("Home and End select the first and last tab in uncontrolled mode", async () => {
      const user = userEvent.setup();
      const onValueChange = vi.fn();
      render(<Example defaultValue="two" onValueChange={onValueChange} />);
      tab("Two").focus();
      await user.keyboard("{End}");
      expect(onValueChange).toHaveBeenLastCalledWith("three");
      expect(tab("Three")).toHaveAttribute("aria-selected", "true");
      await user.keyboard("{Home}");
      expect(onValueChange).toHaveBeenLastCalledWith("one");
      expect(tab("One")).toHaveAttribute("aria-selected", "true");
    });
  });

  describe("hostile input (T6)", () => {
    it("does nothing and does not throw when every tab is disabled", async () => {
      const user = userEvent.setup();
      const onValueChange = vi.fn();
      render(<Example disabled={["one", "two", "three"]} onValueChange={onValueChange} />);
      tab("One").focus();
      await user.keyboard("{ArrowRight}{ArrowLeft}{Home}{End}");
      expect(tab("One")).toHaveFocus();
      expect(onValueChange).not.toHaveBeenCalled();
    });

    it("keeps focus on a single tab when ArrowRight is pressed", async () => {
      const user = userEvent.setup();
      const onValueChange = vi.fn();
      render(
        <Tabs defaultValue="only" onValueChange={onValueChange}>
          <TabList aria-label="Single">
            <Tab value="only">Only</Tab>
          </TabList>
          <TabPanel value="only">P</TabPanel>
        </Tabs>,
      );
      tab("Only").focus();
      await user.keyboard("{ArrowRight}");
      expect(tab("Only")).toHaveFocus();
      expect(onValueChange).not.toHaveBeenCalled();
    });

    it("navigates in DOM order after tabs are reordered", async () => {
      const user = userEvent.setup();
      const { rerender } = render(<Reorderable values={["a", "b", "c"]} />);
      rerender(<Reorderable values={["c", "b", "a"]} />);
      tab("c").focus();
      await user.keyboard("{ArrowRight}");
      expect(tab("b")).toHaveFocus();
    });

    it("navigates in DOM order after a tab is removed", async () => {
      const user = userEvent.setup();
      const { rerender } = render(<Reorderable values={["a", "b", "c"]} />);
      rerender(<Reorderable values={["a", "c"]} />);
      tab("a").focus();
      await user.keyboard("{ArrowRight}");
      expect(tab("c")).toHaveFocus();
    });

    it("does not call onValueChange when re-selecting the selected tab", async () => {
      const user = userEvent.setup();
      const onValueChange = vi.fn();
      render(<Example onValueChange={onValueChange} />);
      await user.click(tab("One"));
      expect(onValueChange).not.toHaveBeenCalled();
    });
  });
});

import { render, screen } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { useState } from "react";
import { Dialog, type DialogProps } from "./Dialog";

function Example({ open = true, onOpenChange = () => {}, children, ...props }: Partial<DialogProps>) {
  return (
    <Dialog open={open} onOpenChange={onOpenChange} title="Delete file" description="This cannot be undone." {...props}>
      {children ?? <button>Confirm</button>}
    </Dialog>
  );
}

function Controlled({ onOpenChange }: { onOpenChange: (open: boolean) => void }) {
  const [open, setOpen] = useState(false);
  return (
    <>
      <button onClick={() => setOpen(true)}>Open</button>
      <Dialog
        open={open}
        onOpenChange={(next) => {
          setOpen(next);
          onOpenChange(next);
        }}
        title="Edit"
      >
        <button>Save</button>
      </Dialog>
    </>
  );
}

function WithOpener({ showOpener, open }: { showOpener: boolean; open: boolean }) {
  return (
    <>
      {showOpener && <button>Opener</button>}
      <Example open={open} />
    </>
  );
}

describe("Dialog", () => {
  it("renders nothing when closed", () => {
    render(<Example open={false} />);
    expect(screen.queryByRole("dialog")).toBeNull();
    expect(document.querySelector("[data-backdrop]")).toBeNull();
  });

  it("renders a modal dialog with a backdrop in document.body and labelled by its title", () => {
    render(<Example />);
    const dialog = screen.getByRole("dialog", { name: "Delete file" });
    expect(dialog).toHaveAttribute("aria-modal", "true");
    expect(dialog.parentElement).toBe(document.body);
    expect(document.querySelector("[data-backdrop]")).not.toBeNull();
    expect(dialog).toHaveAttribute("aria-describedby");
    expect(document.getElementById(dialog.getAttribute("aria-describedby") ?? "")).toHaveTextContent(
      "This cannot be undone.",
    );
  });

  it("omits aria-describedby when there is no description", () => {
    render(<Example description={undefined} />);
    expect(screen.getByRole("dialog")).not.toHaveAttribute("aria-describedby");
  });

  it("moves focus to the first focusable element on open", () => {
    render(<Example>
      <input aria-label="Name" />
      <button>Confirm</button>
    </Example>);
    expect(screen.getByRole("textbox", { name: "Name" })).toHaveFocus();
  });

  it("focuses the dialog itself when it has no focusable content", () => {
    render(<Example>just text</Example>);
    expect(screen.getByRole("dialog")).toHaveFocus();
  });

  it("cycles Tab and Shift+Tab within the dialog", async () => {
    const user = userEvent.setup();
    render(
      <>
        <button>Outside</button>
        <Example>
          <button>First</button>
          <button>Last</button>
        </Example>
      </>,
    );
    expect(screen.getByRole("button", { name: "First" })).toHaveFocus();
    await user.tab();
    expect(screen.getByRole("button", { name: "Last" })).toHaveFocus();
    await user.tab();
    expect(screen.getByRole("button", { name: "First" })).toHaveFocus();
    await user.tab({ shift: true });
    expect(screen.getByRole("button", { name: "Last" })).toHaveFocus();
  });

  it("keeps focus on the dialog when there is no focusable content", async () => {
    const user = userEvent.setup();
    render(<Example>just text</Example>);
    await user.tab();
    expect(screen.getByRole("dialog")).toHaveFocus();
  });

  it("ignores disabled and tabindex=-1 elements when trapping focus", async () => {
    const user = userEvent.setup();
    render(<Example>
      <button disabled>Disabled</button>
      <button tabIndex={-1}>Skipped</button>
      <button>Real</button>
    </Example>);
    expect(screen.getByRole("button", { name: "Real" })).toHaveFocus();
    await user.tab();
    expect(screen.getByRole("button", { name: "Real" })).toHaveFocus();
  });

  it("includes focusable elements added after open in the trap", async () => {
    const user = userEvent.setup();
    const { rerender } = render(
      <Example>
        <button>First</button>
        {null}
      </Example>,
    );
    rerender(
      <Example>
        <button>First</button>
        <button>Added</button>
      </Example>,
    );
    await user.tab();
    expect(screen.getByRole("button", { name: "Added" })).toHaveFocus();
    await user.tab();
    expect(screen.getByRole("button", { name: "First" })).toHaveFocus();
  });

  it("calls onOpenChange(false) once on Escape, including from a nested input", async () => {
    const user = userEvent.setup();
    const onOpenChange = vi.fn();
    render(<Example onOpenChange={onOpenChange}><input aria-label="Name" /></Example>);
    await user.keyboard("{Escape}");
    expect(onOpenChange).toHaveBeenCalledTimes(1);
    expect(onOpenChange).toHaveBeenCalledWith(false);
  });

  it("closes on a backdrop click but not on a click inside the content", async () => {
    const user = userEvent.setup();
    const onOpenChange = vi.fn();
    render(<Example onOpenChange={onOpenChange} />);
    await user.click(screen.getByText("This cannot be undone."));
    expect(onOpenChange).not.toHaveBeenCalled();
    await user.click(document.querySelector("[data-backdrop]") as HTMLElement);
    expect(onOpenChange).toHaveBeenCalledWith(false);
    expect(onOpenChange).toHaveBeenCalledTimes(1);
  });

  it("does not close when a drag starts inside the dialog and ends on the backdrop", async () => {
    const user = userEvent.setup();
    const onOpenChange = vi.fn();
    render(<Example onOpenChange={onOpenChange} />);
    const backdrop = document.querySelector("[data-backdrop]") as HTMLElement;
    await user.pointer([
      { keys: "[MouseLeft>]", target: screen.getByText("This cannot be undone.") },
      { target: backdrop },
      { keys: "[/MouseLeft]", target: backdrop },
    ]);
    expect(onOpenChange).not.toHaveBeenCalled();
  });

  it("restores focus to the opener when closed", async () => {
    const user = userEvent.setup();
    render(<Controlled onOpenChange={() => {}} />);
    await user.click(screen.getByRole("button", { name: "Open" }));
    expect(screen.getByRole("button", { name: "Save" })).toHaveFocus();
    await user.keyboard("{Escape}");
    expect(screen.queryByRole("dialog")).toBeNull();
    expect(screen.getByRole("button", { name: "Open" })).toHaveFocus();
  });

  it("does not throw on close when the opener was removed while open", async () => {
    const user = userEvent.setup();
    const { rerender } = render(<WithOpener showOpener open={false} />);
    await user.click(screen.getByRole("button", { name: "Opener" }));
    rerender(<WithOpener showOpener open />);
    rerender(<WithOpener showOpener={false} open />);
    expect(screen.queryByRole("button", { name: "Opener" })).toBeNull();
    expect(() => rerender(<WithOpener showOpener={false} open={false} />)).not.toThrow();
    expect(screen.queryByRole("dialog")).toBeNull();
  });

  it("keeps Tab inside an inner dialog opened from an outer dialog", async () => {
    const user = userEvent.setup();
    function Nested() {
      const [innerOpen, setInnerOpen] = useState(false);
      return (
        <Example>
          <button onClick={() => setInnerOpen(true)}>Open inner</button>
          <Dialog open={innerOpen} onOpenChange={setInnerOpen} title="Inner">
            <button>Inner first</button>
            <button>Inner last</button>
          </Dialog>
        </Example>
      );
    }
    render(<Nested />);
    await user.click(screen.getByRole("button", { name: "Open inner" }));
    expect(screen.getByRole("button", { name: "Inner first" })).toHaveFocus();
    await user.tab();
    expect(screen.getByRole("button", { name: "Inner last" })).toHaveFocus();
    await user.tab();
    expect(screen.getByRole("button", { name: "Inner first" })).toHaveFocus();
  });

  it("closes only the inner dialog on one Escape and returns focus to its opener in the outer", async () => {
    const user = userEvent.setup();
    const onOuterOpenChange = vi.fn();
    const onInnerOpenChange = vi.fn();
    function Nested() {
      const [outerOpen, setOuterOpen] = useState(true);
      const [innerOpen, setInnerOpen] = useState(false);
      return (
        <Example
          open={outerOpen}
          title="Outer"
          onOpenChange={(next) => {
            setOuterOpen(next);
            onOuterOpenChange(next);
          }}
        >
          <button onClick={() => setInnerOpen(true)}>Open inner</button>
          <Dialog
            open={innerOpen}
            onOpenChange={(next) => {
              setInnerOpen(next);
              onInnerOpenChange(next);
            }}
            title="Inner"
          >
            <button>Inner action</button>
          </Dialog>
        </Example>
      );
    }
    render(<Nested />);
    await user.click(screen.getByRole("button", { name: "Open inner" }));
    await user.keyboard("{Escape}");
    expect(onInnerOpenChange).toHaveBeenCalledTimes(1);
    expect(onInnerOpenChange).toHaveBeenCalledWith(false);
    expect(onOuterOpenChange).not.toHaveBeenCalled();
    expect(screen.queryByRole("dialog", { name: "Inner" })).toBeNull();
    expect(screen.getByRole("dialog", { name: "Outer" })).toBeInTheDocument();
    expect(screen.getByRole("button", { name: "Open inner" })).toHaveFocus();
  });

  it("closes only the inner dialog on one Escape when both open in the same click", async () => {
    const user = userEvent.setup();
    const onOuterOpenChange = vi.fn();
    const onInnerOpenChange = vi.fn();
    function Nested() {
      const [outerOpen, setOuterOpen] = useState(false);
      const [innerOpen, setInnerOpen] = useState(false);
      return (
        <>
          <button
            onClick={() => {
              setOuterOpen(true);
              setInnerOpen(true);
            }}
          >
            Open both
          </button>
          <Example
            open={outerOpen}
            title="Outer"
            onOpenChange={(next) => {
              setOuterOpen(next);
              onOuterOpenChange(next);
            }}
          >
            <Dialog
              open={innerOpen}
              onOpenChange={(next) => {
                setInnerOpen(next);
                onInnerOpenChange(next);
              }}
              title="Inner"
            >
              <button>Inner action</button>
            </Dialog>
          </Example>
        </>
      );
    }
    render(<Nested />);
    await user.click(screen.getByRole("button", { name: "Open both" }));
    expect(screen.getByRole("button", { name: "Inner action" })).toHaveFocus();
    await user.keyboard("{Escape}");
    expect(onInnerOpenChange).toHaveBeenCalledTimes(1);
    expect(onInnerOpenChange).toHaveBeenCalledWith(false);
    expect(onOuterOpenChange).not.toHaveBeenCalled();
    expect(screen.getByRole("dialog", { name: "Outer" })).toBeInTheDocument();
  });

  it("closes only the inner dialog on one Escape when both are open at mount", async () => {
    const user = userEvent.setup();
    const onOuterOpenChange = vi.fn();
    const onInnerOpenChange = vi.fn();
    render(
      <Example title="Outer" onOpenChange={onOuterOpenChange}>
        <Dialog open title="Inner" onOpenChange={onInnerOpenChange}>
          <button>Inner action</button>
        </Dialog>
      </Example>,
    );
    expect(screen.getByRole("button", { name: "Inner action" })).toHaveFocus();
    await user.tab();
    expect(screen.getByRole("button", { name: "Inner action" })).toHaveFocus();
    await user.keyboard("{Escape}");
    expect(onInnerOpenChange).toHaveBeenCalledTimes(1);
    expect(onInnerOpenChange).toHaveBeenCalledWith(false);
    expect(onOuterOpenChange).not.toHaveBeenCalled();
  });

  it("forwards className and data attributes to the dialog element", () => {
    render(<Example className="sheet" data-testid="dialog" />);
    expect(screen.getByTestId("dialog")).toHaveClass("sheet");
    expect(screen.getByTestId("dialog")).toHaveAttribute("role", "dialog");
  });
});

import { fireEvent, render, screen } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { useState } from "react";
import { describe, expect, it, vi } from "vitest";
import { Combobox } from "../src/Combobox";
import { Dialog } from "../src/Dialog";

function Harness({ onOpenChange }: { onOpenChange: (open: boolean) => void }) {
  const [open, setOpen] = useState(false);
  return (
    <>
      <button onClick={() => setOpen(true)}>Open</button>
      <Dialog
        open={open}
        onOpenChange={(next) => {
          onOpenChange(next);
          setOpen(next);
        }}
        title="Confirm"
        description="Are you sure?"
      >
        <button>Ok</button>
      </Dialog>
    </>
  );
}

function Nested({
  onOuter,
  onInner,
}: {
  onOuter: (open: boolean) => void;
  onInner: (open: boolean) => void;
}) {
  const [outerOpen, setOuterOpen] = useState(true);
  const [innerOpen, setInnerOpen] = useState(false);
  return (
    <Dialog
      open={outerOpen}
      onOpenChange={(next) => {
        onOuter(next);
        setOuterOpen(next);
      }}
      title="Outer"
    >
      <button onClick={() => setInnerOpen(true)}>Open inner</button>
      <Dialog
        open={innerOpen}
        onOpenChange={(next) => {
          onInner(next);
          setInnerOpen(next);
        }}
        title="Inner"
      >
        <button>First</button>
        <button>Second</button>
      </Dialog>
    </Dialog>
  );
}

describe("Dialog rendering (D1)", () => {
  it("renders nothing when closed", () => {
    render(
      <Dialog open={false} onOpenChange={() => {}} title="Confirm">
        <button>Ok</button>
      </Dialog>,
    );
    expect(screen.queryByRole("dialog")).toBeNull();
    expect(document.querySelector("[data-backdrop]")).toBeNull();
  });

  it("portals a backdrop and a modal dialog labelled by the h2 title and described by the paragraph", () => {
    const { container } = render(
      <Dialog open onOpenChange={() => {}} title="Confirm" description="Are you sure?">
        <button>Ok</button>
      </Dialog>,
    );
    const dialog = screen.getByRole("dialog");
    expect(container).not.toContainElement(dialog);
    expect(document.body).toContainElement(dialog);
    expect(document.querySelector("[data-backdrop]")).toContainElement(dialog);
    expect(dialog).toHaveAttribute("aria-modal", "true");
    expect(screen.getByRole("heading", { level: 2, name: "Confirm" })).toBeInTheDocument();
    expect(dialog).toHaveAccessibleName("Confirm");
    expect(dialog).toHaveAccessibleDescription("Are you sure?");
    expect(screen.getByText("Are you sure?").tagName).toBe("P");
  });

  it("renders a description of 0 and describes the dialog with it", () => {
    render(
      <Dialog open onOpenChange={() => {}} title="Count" description={0}>
        <button>Ok</button>
      </Dialog>,
    );
    expect(screen.getByRole("dialog")).toHaveAccessibleDescription("0");
  });

  it("renders no description and no aria-describedby when description is false", () => {
    render(
      <Dialog open onOpenChange={() => {}} title="Confirm" description={false}>
        <button>Ok</button>
      </Dialog>,
    );
    expect(screen.getByRole("dialog")).not.toHaveAttribute("aria-describedby");
    expect(document.querySelector("[data-backdrop] p")).toBeNull();
  });

  it("has no aria-describedby when description is omitted", () => {
    render(
      <Dialog open onOpenChange={() => {}} title="Confirm">
        <button>Ok</button>
      </Dialog>,
    );
    expect(screen.getByRole("dialog")).not.toHaveAttribute("aria-describedby");
  });

  it("passes className through to the dialog element", () => {
    render(
      <Dialog open onOpenChange={() => {}} title="Confirm" className="sheet">
        <button>Ok</button>
      </Dialog>,
    );
    expect(screen.getByRole("dialog")).toHaveClass("sheet");
  });

  it("accepts a ReactNode title and names the dialog from its text", () => {
    render(
      <Dialog open onOpenChange={() => {}} title={<span>Delete <em>file</em></span>}>
        <button>Ok</button>
      </Dialog>,
    );
    expect(screen.getByRole("dialog")).toHaveAccessibleName("Delete file");
  });

  it("two dialogs rendered together have distinct ids and their own title wiring", () => {
    render(
      <>
        <Dialog open onOpenChange={() => {}} title="First">
          <button>A</button>
        </Dialog>
        <Dialog open onOpenChange={() => {}} title="Second">
          <button>B</button>
        </Dialog>
      </>,
    );
    const [first, second] = screen.getAllByRole("dialog");
    expect(first.getAttribute("aria-labelledby")).not.toBe(second.getAttribute("aria-labelledby"));
    expect(first).toHaveAccessibleName("First");
    expect(second).toHaveAccessibleName("Second");
  });
});

describe("Dialog initial focus (D2)", () => {
  it("moves focus to the first tabbable element inside the dialog", () => {
    render(
      <Dialog open onOpenChange={() => {}} title="Confirm">
        <button>First</button>
        <button>Second</button>
      </Dialog>,
    );
    expect(screen.getByRole("button", { name: "First" })).toHaveFocus();
  });

  it("focuses the dialog container when it has no tabbable element", () => {
    render(
      <Dialog open onOpenChange={() => {}} title="Confirm">
        <p>Read only</p>
      </Dialog>,
    );
    expect(screen.getByRole("dialog")).toHaveFocus();
    expect(screen.getByRole("dialog")).toHaveAttribute("tabindex", "-1");
  });
});

describe("Dialog focus trap (D3)", () => {
  it("Tab from the last tabbable element wraps to the first", async () => {
    const user = userEvent.setup();
    render(
      <Dialog open onOpenChange={() => {}} title="Confirm">
        <button>First</button>
        <button>Second</button>
      </Dialog>,
    );
    screen.getByRole("button", { name: "Second" }).focus();
    await user.tab();
    expect(screen.getByRole("button", { name: "First" })).toHaveFocus();
  });

  it("Shift+Tab from the first tabbable element wraps to the last", async () => {
    const user = userEvent.setup();
    render(
      <Dialog open onOpenChange={() => {}} title="Confirm">
        <button>First</button>
        <button>Second</button>
      </Dialog>,
    );
    await user.tab({ shift: true });
    expect(screen.getByRole("button", { name: "Second" })).toHaveFocus();
  });

  it("with zero tabbable elements, Tab keeps focus on the dialog", async () => {
    const user = userEvent.setup();
    render(
      <Dialog open onOpenChange={() => {}} title="Confirm">
        <p>Read only</p>
      </Dialog>,
    );
    await user.tab();
    expect(screen.getByRole("dialog")).toHaveFocus();
    await user.tab({ shift: true });
    expect(screen.getByRole("dialog")).toHaveFocus();
  });

  it("excludes disabled, hidden and tabindex=-1 elements from the tabbables", async () => {
    const user = userEvent.setup();
    render(
      <Dialog open onOpenChange={() => {}} title="Confirm">
        <button disabled>Disabled</button>
        <div hidden>
          <button>Hidden</button>
        </div>
        <button tabIndex={-1}>Skipped</button>
        <button>Only</button>
      </Dialog>,
    );
    expect(screen.getByRole("button", { name: "Only" })).toHaveFocus();
    await user.tab();
    expect(screen.getByRole("button", { name: "Only" })).toHaveFocus();
    await user.tab({ shift: true });
    expect(screen.getByRole("button", { name: "Only" })).toHaveFocus();
  });
});

describe("Dialog closing (D4)", () => {
  it("Escape calls onOpenChange(false)", async () => {
    const user = userEvent.setup();
    const onOpenChange = vi.fn();
    render(
      <Dialog open onOpenChange={onOpenChange} title="Confirm">
        <button>Ok</button>
      </Dialog>,
    );
    await user.keyboard("{Escape}");
    expect(onOpenChange).toHaveBeenCalledExactlyOnceWith(false);
  });

  it("clicking the backdrop calls onOpenChange(false)", async () => {
    const user = userEvent.setup();
    const onOpenChange = vi.fn();
    render(
      <Dialog open onOpenChange={onOpenChange} title="Confirm">
        <button>Ok</button>
      </Dialog>,
    );
    await user.click(document.querySelector("[data-backdrop]") as HTMLElement);
    expect(onOpenChange).toHaveBeenCalledExactlyOnceWith(false);
  });

  it("clicking inside the dialog content does not close", async () => {
    const user = userEvent.setup();
    const onOpenChange = vi.fn();
    render(
      <Dialog open onOpenChange={onOpenChange} title="Confirm" description="Are you sure?">
        <button>Ok</button>
      </Dialog>,
    );
    await user.click(screen.getByText("Are you sure?"));
    await user.click(screen.getByRole("button", { name: "Ok" }));
    expect(onOpenChange).not.toHaveBeenCalled();
  });

  it("a mousedown inside that ends on the backdrop does not close", () => {
    const onOpenChange = vi.fn();
    render(
      <Dialog open onOpenChange={onOpenChange} title="Confirm">
        <button>Ok</button>
      </Dialog>,
    );
    fireEvent.mouseDown(screen.getByRole("button", { name: "Ok" }));
    fireEvent.click(document.querySelector("[data-backdrop]") as HTMLElement);
    expect(onOpenChange).not.toHaveBeenCalled();
  });
});

describe("Dialog focus restore (D5)", () => {
  it("returns focus to the trigger when open becomes false", async () => {
    const user = userEvent.setup();
    render(<Harness onOpenChange={() => {}} />);
    await user.click(screen.getByRole("button", { name: "Open" }));
    expect(screen.getByRole("button", { name: "Ok" })).toHaveFocus();
    await user.keyboard("{Escape}");
    expect(screen.queryByRole("dialog")).toBeNull();
    expect(screen.getByRole("button", { name: "Open" })).toHaveFocus();
  });

  it("returns focus to the previously focused element when unmounted while open", () => {
    const trigger = document.createElement("button");
    document.body.append(trigger);
    trigger.focus();
    const { unmount } = render(
      <Dialog open onOpenChange={() => {}} title="Confirm">
        <button>Ok</button>
      </Dialog>,
    );
    expect(screen.getByRole("button", { name: "Ok" })).toHaveFocus();
    unmount();
    expect(trigger).toHaveFocus();
    trigger.remove();
  });

  it("opened on initial mount, focus returns to body on close", () => {
    const { rerender } = render(
      <Dialog open onOpenChange={() => {}} title="Confirm">
        <button>Ok</button>
      </Dialog>,
    );
    expect(screen.getByRole("button", { name: "Ok" })).toHaveFocus();
    rerender(
      <Dialog open={false} onOpenChange={() => {}} title="Confirm">
        <button>Ok</button>
      </Dialog>,
    );
    expect(document.activeElement).toBe(document.body);
  });

  it("does not throw on close when the trigger was removed from the DOM", () => {
    const trigger = document.createElement("button");
    document.body.append(trigger);
    trigger.focus();
    const { rerender } = render(
      <Dialog open onOpenChange={() => {}} title="Confirm">
        <button>Ok</button>
      </Dialog>,
    );
    trigger.remove();
    expect(() =>
      rerender(
        <Dialog open={false} onOpenChange={() => {}} title="Confirm">
          <button>Ok</button>
        </Dialog>,
      ),
    ).not.toThrow();
    expect(document.activeElement).toBe(document.body);
  });

  it("Escape inside an open nested Combobox closes only the listbox, then the dialog", async () => {
    const user = userEvent.setup();
    const onOpenChange = vi.fn();
    render(
      <Dialog open onOpenChange={onOpenChange} title="Pick">
        <Combobox
          label="Fruit"
          options={[{ value: "apple", label: "Apple" }]}
          value={null}
          onChange={() => {}}
        />
      </Dialog>,
    );
    const input = screen.getByRole("combobox", { name: "Fruit" });
    await user.type(input, "a");
    expect(input).toHaveAttribute("aria-expanded", "true");
    await user.keyboard("{Escape}");
    expect(input).toHaveAttribute("aria-expanded", "false");
    expect(onOpenChange).not.toHaveBeenCalled();
    await user.keyboard("{Escape}");
    expect(onOpenChange).toHaveBeenCalledExactlyOnceWith(false);
  });
});

describe("Nested dialogs", () => {
  it("Escape closes only the inner dialog when both render open in the same commit", async () => {
    const user = userEvent.setup();
    const onOuter = vi.fn();
    const onInner = vi.fn();
    render(
      <Dialog open onOpenChange={onOuter} title="Outer">
        <Dialog open onOpenChange={onInner} title="Inner">
          <button>inner button</button>
        </Dialog>
      </Dialog>,
    );
    await user.keyboard("{Escape}");
    expect(onInner).toHaveBeenCalledWith(false);
    expect(onOuter).not.toHaveBeenCalled();
  });

  it("Escape closes only the topmost dialog", async () => {
    const user = userEvent.setup();
    const onOuter = vi.fn();
    const onInner = vi.fn();
    render(<Nested onOuter={onOuter} onInner={onInner} />);
    await user.click(screen.getByRole("button", { name: "Open inner" }));
    await user.keyboard("{Escape}");
    expect(onInner).toHaveBeenCalledExactlyOnceWith(false);
    expect(onOuter).not.toHaveBeenCalled();
  });

  it("after the inner dialog closes, Escape closes the outer one", async () => {
    const user = userEvent.setup();
    const onOuter = vi.fn();
    const onInner = vi.fn();
    render(<Nested onOuter={onOuter} onInner={onInner} />);
    await user.click(screen.getByRole("button", { name: "Open inner" }));
    await user.keyboard("{Escape}");
    expect(screen.queryByRole("dialog", { name: "Inner" })).toBeNull();
    await user.keyboard("{Escape}");
    expect(onOuter).toHaveBeenCalledExactlyOnceWith(false);
    expect(onInner).toHaveBeenCalledExactlyOnceWith(false);
  });

  it("Tab and Shift+Tab cycle inside the topmost dialog only", async () => {
    const user = userEvent.setup();
    render(<Nested onOuter={() => {}} onInner={() => {}} />);
    await user.click(screen.getByRole("button", { name: "Open inner" }));
    expect(screen.getByRole("button", { name: "First" })).toHaveFocus();
    await user.tab();
    expect(screen.getByRole("button", { name: "Second" })).toHaveFocus();
    await user.tab();
    expect(screen.getByRole("button", { name: "First" })).toHaveFocus();
    await user.tab({ shift: true });
    expect(screen.getByRole("button", { name: "Second" })).toHaveFocus();
  });
});

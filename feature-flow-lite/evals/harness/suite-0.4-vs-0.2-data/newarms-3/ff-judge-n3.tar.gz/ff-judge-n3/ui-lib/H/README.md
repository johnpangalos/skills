# @acme/ui

Accessible React components: `Tabs`, `Dialog` and `Combobox`. No CSS is shipped; every component forwards extra HTML props (`className`, `id`, `data-*`) to its root element so you can style it yourself.

Run the checks with `pnpm test` and `pnpm typecheck`.

## Tabs

```tsx
import { Tabs, TabList, Tab, TabPanel } from "@acme/ui";

<Tabs defaultValue="one">
  <TabList aria-label="Sections">
    <Tab value="one">One</Tab>
    <Tab value="two">Two</Tab>
  </TabList>
  <TabPanel value="one">Panel one</TabPanel>
  <TabPanel value="two">Panel two</TabPanel>
</Tabs>;
```

`Tabs` renders a wrapper `div`, `TabList` a `div role="tablist"`, `Tab` a `button role="tab"` and `TabPanel` a `div role="tabpanel"`. Tab and panel ids are generated from `useId`, so `id` is not forwarded on `Tab` and `TabPanel`: the ARIA wiring depends on those ids.

| Prop | Type | Required / default | Description |
| --- | --- | --- | --- |
| `Tabs.value` | `string` | optional; controlled when set | Selected tab value. |
| `Tabs.defaultValue` | `string` | optional; first enabled tab | Initial selection when uncontrolled. |
| `Tabs.onValueChange` | `(value: string) => void` | optional | Called when the user selects a different tab. |
| `TabList["aria-label"]` | `string` | required | Accessible name of the tablist. |
| `Tab.value` | `string` | required | Value this tab selects. |
| `Tab.disabled` | `boolean` | optional; `false` | Sets `aria-disabled="true"`; clicks and arrow keys skip it. |
| `TabPanel.value` | `string` | required | Value of the tab that controls this panel; hidden unless selected. |

| Key | Action |
| --- | --- |
| `ArrowRight` / `ArrowLeft` | Move focus to the next / previous enabled tab, wrapping, and select it. |
| `Home` / `End` | Move focus to the first / last enabled tab and select it. |
| `Tab` | Enters or leaves the tablist. Only the selected tab (or the first enabled tab if none matches) is in the tab order. Focusing a tab does not select it, so tabbing in never calls `onValueChange`. |

## Dialog

```tsx
import { useState } from "react";
import { Dialog } from "@acme/ui";

const [open, setOpen] = useState(false);

<Dialog open={open} onOpenChange={setOpen} title="Delete file" description="This cannot be undone.">
  <button type="button" onClick={() => setOpen(false)}>Cancel</button>
</Dialog>;
```

`Dialog` renders nothing when `open` is false. When open it portals a backdrop into `document.body` containing the `role="dialog"` element, which receives the extra props. Focus moves to the first enabled focusable element (or the dialog itself), is trapped inside while open, and returns to the previously focused element on close. A mousedown on the backdrop keeps focus where it was, so focus cannot leave the dialog that way. Nested dialogs are independent: a key is handled by the innermost dialog that contains its target, or by the topmost open dialog when focus is outside every dialog (for example after the focused element was removed).

| Prop | Type | Required / default | Description |
| --- | --- | --- | --- |
| `open` | `boolean` | required | Whether the dialog is shown. Fully controlled. |
| `onOpenChange` | `(open: boolean) => void` | required | Called with `false` on Escape or a click on the backdrop. Clicks that start inside the dialog do not count. |
| `title` | `ReactNode` | required | Rendered in an `h2`; labels the dialog. |
| `description` | `ReactNode` | optional | Rendered in a `p`; describes the dialog. Omitted when not given. |

| Key | Action |
| --- | --- |
| `Escape` | Calls `onOpenChange(false)` unless the event's default was already prevented (for example by an open Combobox). |
| `Tab` / `Shift+Tab` | Moves through focusable elements inside the dialog and wraps at the edges. Focus stays on the dialog when nothing inside is focusable. |

## Combobox

```tsx
import { useState } from "react";
import { Combobox } from "@acme/ui";

const [fruit, setFruit] = useState<string | null>(null);

<Combobox
  label="Fruit"
  placeholder="Type to search"
  options={[
    { value: "apple", label: "Apple" },
    { value: "cherry", label: "Cherry", disabled: true },
  ]}
  value={fruit}
  onChange={setFruit}
/>;
```

`Combobox` renders a `label`, an `input role="combobox"` (which receives the extra props) and a `ul role="listbox"` that is always in the DOM and `hidden` while closed. Typing filters options by case-insensitive substring. Clearing the text calls `onChange(null)`. When the list closes without a selection the text returns to the label of `value`.

| Prop | Type | Required / default | Description |
| --- | --- | --- | --- |
| `label` | `string` | required | Text of the `label` for the input. |
| `options` | `ComboboxOption[]` | required | `{ value: string; label: string; disabled?: boolean }` entries. |
| `value` | `string \| null` | required | Selected option value; the input shows its label. Controlled. |
| `onChange` | `(value: string \| null) => void` | required | Called on selection (Enter or click) and when the text is cleared (`null`). |
| `placeholder` | `string` | optional | Passed to the input. |

| Key | Action |
| --- | --- |
| `ArrowDown` / `ArrowUp` | Opens the list if closed (activating the first / last enabled option), otherwise moves the active option to the next / previous enabled option, wrapping. Exposed through `aria-activedescendant`. |
| `Enter` | With an active option: selects it, closes the list. Otherwise does nothing and is not prevented, so a surrounding form can submit. |
| `Escape` | While open: closes the list without selecting, restores the label, and stops propagation. While closed: does nothing. |
| `Tab` / blur | Closes the list without selecting and restores the label. Tab's default is not prevented. |
| Typing | Opens the list and filters options; the active option is cleared until an arrow key is pressed. |

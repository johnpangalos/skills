import { fireEvent, render, screen } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { useState } from "react";
import { describe, expect, it, vi } from "vitest";
import { Combobox, type ComboboxOption } from "../src/Combobox";

const fruits: ComboboxOption[] = [
  { value: "apple", label: "Apple" },
  { value: "banana", label: "Banana" },
  { value: "cherry", label: "Cherry", disabled: true },
  { value: "date", label: "Date" },
];

function Harness({
  initial = null,
  options = fruits,
  onChange = () => {},
}: {
  initial?: string | null;
  options?: ComboboxOption[];
  onChange?: (value: string | null) => void;
}) {
  const [value, setValue] = useState<string | null>(initial);
  return (
    <Combobox
      label="Fruit"
      options={options}
      value={value}
      placeholder="Pick a fruit"
      onChange={(next) => {
        onChange(next);
        setValue(next);
      }}
    />
  );
}

const input = () => screen.getByRole("combobox", { name: "Fruit" });
const option = (name: string) => screen.getByRole("option", { name });

describe("Combobox ARIA structure (C1)", () => {
  it("renders a labelled input with combobox ARIA attributes pointing at the listbox", () => {
    render(<Harness />);
    const field = input();
    expect(field).toHaveAttribute("aria-expanded", "false");
    expect(field).toHaveAttribute("aria-autocomplete", "list");
    expect(field).not.toHaveAttribute("aria-activedescendant");
    const listbox = document.getElementById(field.getAttribute("aria-controls") ?? "");
    expect(listbox).toHaveAttribute("role", "listbox");
    expect(listbox).toHaveAttribute("aria-labelledby", screen.getByText("Fruit").id);
  });

  it("names the listbox after the label and renders options with unique ids, aria-selected and aria-disabled", async () => {
    const user = userEvent.setup();
    render(<Harness initial="banana" />);
    await user.click(input());
    await user.keyboard("{ArrowDown}");
    expect(screen.getByRole("listbox", { name: "Fruit" })).toBeInTheDocument();
    const options = screen.getAllByRole("option");
    expect(options).toHaveLength(4);
    expect(new Set(options.map((el) => el.id)).size).toBe(4);
    expect(option("Banana")).toHaveAttribute("aria-selected", "true");
    expect(option("Apple")).toHaveAttribute("aria-selected", "false");
    expect(option("Cherry")).toHaveAttribute("aria-disabled", "true");
    expect(option("Apple")).not.toHaveAttribute("aria-disabled");
  });
});

describe("Combobox input text (C2)", () => {
  it("shows the selected label, and placeholder passes through", () => {
    const { unmount } = render(<Harness initial="banana" />);
    expect(input()).toHaveValue("Banana");
    unmount();
    render(<Harness />);
    expect(input()).toHaveValue("");
    expect(input()).toHaveAttribute("placeholder", "Pick a fruit");
  });

  it("typing opens the listbox and filters by case-insensitive substring", async () => {
    const user = userEvent.setup();
    render(<Harness />);
    await user.type(input(), "AN");
    expect(input()).toHaveAttribute("aria-expanded", "true");
    expect(screen.getAllByRole("option")).toHaveLength(1);
    expect(option("Banana")).toBeInTheDocument();
  });

  it("typing does not change value; blur reverts the text to the selected label", async () => {
    const user = userEvent.setup();
    const onChange = vi.fn();
    render(<Harness initial="banana" onChange={onChange} />);
    await user.type(input(), "ap");
    expect(input()).toHaveValue("Bananaap");
    await user.tab();
    expect(input()).toHaveValue("Banana");
    expect(input()).toHaveAttribute("aria-expanded", "false");
    expect(onChange).not.toHaveBeenCalled();
  });
});

describe("Combobox keyboard navigation (C3)", () => {
  it("ArrowDown opens the listbox, activates the first enabled option and keeps focus on the input", async () => {
    const user = userEvent.setup();
    render(<Harness />);
    await user.click(input());
    await user.keyboard("{ArrowDown}");
    expect(input()).toHaveAttribute("aria-expanded", "true");
    expect(input()).toHaveFocus();
    expect(input()).toHaveAttribute("aria-activedescendant", option("Apple").id);
    expect(option("Apple")).toHaveAttribute("data-active", "true");
  });

  it("opening with ArrowDown activates the selected option", async () => {
    const user = userEvent.setup();
    render(<Harness initial="banana" />);
    await user.click(input());
    await user.keyboard("{ArrowDown}");
    expect(input()).toHaveAttribute("aria-activedescendant", option("Banana").id);
  });

  it("ArrowDown moves to the next enabled option, skipping disabled ones", async () => {
    const user = userEvent.setup();
    render(<Harness />);
    await user.click(input());
    await user.keyboard("{ArrowDown}{ArrowDown}");
    expect(option("Banana")).toHaveAttribute("data-active", "true");
    await user.keyboard("{ArrowDown}");
    expect(option("Date")).toHaveAttribute("data-active", "true");
    expect(option("Banana")).not.toHaveAttribute("data-active");
  });

  it("wraps at both ends, skipping disabled options", async () => {
    const user = userEvent.setup();
    render(<Harness />);
    await user.click(input());
    await user.keyboard("{ArrowDown}");
    expect(option("Apple")).toHaveAttribute("data-active", "true");
    await user.keyboard("{ArrowUp}");
    expect(option("Date")).toHaveAttribute("data-active", "true");
    await user.keyboard("{ArrowDown}");
    expect(option("Apple")).toHaveAttribute("data-active", "true");
  });

  it("ArrowUp moves to the previous enabled option", async () => {
    const user = userEvent.setup();
    render(<Harness />);
    await user.click(input());
    await user.keyboard("{ArrowDown}{ArrowDown}{ArrowDown}");
    expect(option("Date")).toHaveAttribute("data-active", "true");
    await user.keyboard("{ArrowUp}");
    expect(option("Banana")).toHaveAttribute("data-active", "true");
  });
});

describe("Combobox selection (C4)", () => {
  it("Enter selects the active option, sets the text and closes the listbox", async () => {
    const user = userEvent.setup();
    const onChange = vi.fn();
    render(<Harness onChange={onChange} />);
    await user.click(input());
    await user.keyboard("{ArrowDown}{ArrowDown}{Enter}");
    expect(onChange).toHaveBeenCalledExactlyOnceWith("banana");
    expect(input()).toHaveValue("Banana");
    expect(input()).toHaveAttribute("aria-expanded", "false");
  });

  it("Enter with no active option does nothing", async () => {
    const user = userEvent.setup();
    const onChange = vi.fn();
    render(<Harness onChange={onChange} />);
    await user.click(input());
    await user.keyboard("{Enter}");
    await user.type(input(), "zzz");
    await user.keyboard("{Enter}");
    expect(onChange).not.toHaveBeenCalled();
  });

  it("Enter does not submit a surrounding form while the listbox is open", async () => {
    const user = userEvent.setup();
    const onSubmit = vi.fn();
    render(
      <form
        onSubmit={(event) => {
          event.preventDefault();
          onSubmit();
        }}
      >
        <Harness />
      </form>,
    );
    await user.type(input(), "zzz");
    await user.keyboard("{Enter}");
    expect(onSubmit).not.toHaveBeenCalled();
  });

  it("a click on an enabled option selects it", async () => {
    const user = userEvent.setup();
    const onChange = vi.fn();
    render(<Harness onChange={onChange} />);
    await user.click(input());
    await user.keyboard("{ArrowDown}");
    await user.click(option("Date"));
    expect(onChange).toHaveBeenCalledExactlyOnceWith("date");
    expect(input()).toHaveValue("Date");
    expect(input()).toHaveAttribute("aria-expanded", "false");
  });

  it("a click on a disabled option does nothing", async () => {
    const user = userEvent.setup();
    const onChange = vi.fn();
    render(<Harness onChange={onChange} />);
    await user.click(input());
    await user.keyboard("{ArrowDown}");
    await user.click(option("Cherry"));
    expect(onChange).not.toHaveBeenCalled();
    expect(input()).toHaveAttribute("aria-expanded", "true");
  });

  it("mousedown on an option is prevented so focus stays on the input", async () => {
    const user = userEvent.setup();
    render(<Harness />);
    await user.click(input());
    await user.keyboard("{ArrowDown}");
    expect(fireEvent.mouseDown(option("Date"))).toBe(false);
  });
});

describe("Combobox Escape (C5)", () => {
  it("Escape closes the listbox without onChange, keeps the value and reverts the text", async () => {
    const user = userEvent.setup();
    const onChange = vi.fn();
    render(<Harness initial="banana" onChange={onChange} />);
    await user.type(input(), "ch");
    expect(input()).toHaveAttribute("aria-expanded", "true");
    await user.keyboard("{Escape}");
    expect(input()).toHaveAttribute("aria-expanded", "false");
    expect(input()).toHaveValue("Banana");
    expect(onChange).not.toHaveBeenCalled();
  });
});

describe("Combobox no results (C6)", () => {
  it("shows No results without options, drops aria-activedescendant and Enter does nothing", async () => {
    const user = userEvent.setup();
    const onChange = vi.fn();
    render(<Harness onChange={onChange} />);
    await user.type(input(), "zzz");
    expect(screen.getByText("No results")).toBeInTheDocument();
    expect(screen.queryAllByRole("option")).toHaveLength(0);
    expect(input()).not.toHaveAttribute("aria-activedescendant");
    await user.keyboard("{Enter}");
    expect(onChange).not.toHaveBeenCalled();
  });
});

describe("Combobox controlled value (C7)", () => {
  it("the value prop drives the displayed label", () => {
    const { rerender } = render(
      <Combobox label="Fruit" options={fruits} value="apple" onChange={() => {}} />,
    );
    expect(input()).toHaveValue("Apple");
    rerender(<Combobox label="Fruit" options={fruits} value="date" onChange={() => {}} />);
    expect(input()).toHaveValue("Date");
  });

  it("a selection calls onChange but the text only follows value", async () => {
    const user = userEvent.setup();
    const onChange = vi.fn();
    render(<Combobox label="Fruit" options={fruits} value="apple" onChange={onChange} />);
    await user.click(input());
    await user.keyboard("{ArrowDown}");
    await user.click(option("Date"));
    expect(onChange).toHaveBeenCalledExactlyOnceWith("date");
    expect(input()).toHaveValue("Apple");
  });

  it("a value that is not in options shows empty text without throwing", () => {
    render(<Combobox label="Fruit" options={fruits} value="kiwi" onChange={() => {}} />);
    expect(input()).toHaveValue("");
  });

  it("filter text with regex metacharacters is matched literally", async () => {
    const user = userEvent.setup();
    const options = [
      { value: "red", label: "Apple (red)" },
      { value: "banana", label: "Banana" },
    ];
    render(<Combobox label="Fruit" options={options} value={null} onChange={() => {}} />);
    await user.type(input(), "(");
    expect(screen.getAllByRole("option")).toHaveLength(1);
    expect(option("Apple (red)")).toBeInTheDocument();
    await user.clear(input());
    await user.type(input(), ".*");
    expect(screen.getByText("No results")).toBeInTheDocument();
  });

  it("option values with spaces, colons and unicode yield index-based ids that resolve", async () => {
    const user = userEvent.setup();
    const onChange = vi.fn();
    const options = [
      { value: "a b", label: "Spaced" },
      { value: "x:y", label: "Colon" },
      { value: "ünï", label: "Unicode" },
    ];
    render(<Combobox label="Fruit" options={options} value={null} onChange={onChange} />);
    await user.click(input());
    await user.keyboard("{ArrowDown}{ArrowDown}");
    const activeId = input().getAttribute("aria-activedescendant") ?? "";
    expect(activeId).not.toMatch(/[\s:ü]/);
    expect(document.getElementById(activeId)).toHaveTextContent("Colon");
    await user.click(option("Unicode"));
    expect(onChange).toHaveBeenCalledExactlyOnceWith("ünï");
  });

  it("with every option disabled, ArrowDown does nothing and does not loop", async () => {
    const user = userEvent.setup();
    const options = [
      { value: "a", label: "A", disabled: true },
      { value: "b", label: "B", disabled: true },
    ];
    render(<Combobox label="Fruit" options={options} value={null} onChange={() => {}} />);
    await user.click(input());
    await user.keyboard("{ArrowDown}");
    expect(input()).not.toHaveAttribute("aria-activedescendant");
    expect(document.querySelector("[data-active]")).toBeNull();
  });

  it("when options shrink while open, the active index resets instead of crashing", async () => {
    const user = userEvent.setup();
    const onChange = vi.fn();
    const { rerender } = render(
      <Combobox label="Fruit" options={fruits} value={null} onChange={onChange} />,
    );
    await user.click(input());
    await user.keyboard("{ArrowDown}{ArrowDown}{ArrowDown}");
    expect(option("Date")).toHaveAttribute("data-active", "true");
    rerender(
      <Combobox label="Fruit" options={fruits.slice(0, 2)} value={null} onChange={onChange} />,
    );
    expect(input()).not.toHaveAttribute("aria-activedescendant");
    expect(document.querySelector("[data-active]")).toBeNull();
    await user.keyboard("{Enter}");
    expect(onChange).not.toHaveBeenCalled();
  });

  it("duplicate labels select the option that was clicked", async () => {
    const user = userEvent.setup();
    const onChange = vi.fn();
    const options = [
      { value: "1", label: "Apple" },
      { value: "2", label: "Apple" },
    ];
    render(<Combobox label="Fruit" options={options} value={null} onChange={onChange} />);
    await user.click(input());
    await user.keyboard("{ArrowDown}");
    await user.click(screen.getAllByRole("option")[1]);
    expect(onChange).toHaveBeenCalledExactlyOnceWith("2");
  });

  it("two comboboxes side by side have distinct ids and their own wiring", async () => {
    const user = userEvent.setup();
    render(
      <>
        <Combobox label="First" options={fruits} value={null} onChange={() => {}} />
        <Combobox label="Second" options={fruits} value={null} onChange={() => {}} />
      </>,
    );
    const [first, second] = screen.getAllByRole("combobox");
    expect(first.getAttribute("aria-controls")).not.toBe(second.getAttribute("aria-controls"));
    await user.click(first);
    await user.keyboard("{ArrowDown}");
    expect(first).toHaveAttribute("aria-activedescendant");
    expect(second).not.toHaveAttribute("aria-activedescendant");
    expect(screen.getByRole("listbox", { name: "First" })).toBeInTheDocument();
  });

  it("a new options array with the same options keeps the active option", async () => {
    const user = userEvent.setup();
    const onChange = vi.fn();
    const { rerender } = render(
      <Combobox label="Fruit" options={fruits} value={null} onChange={onChange} />,
    );
    await user.click(input());
    await user.keyboard("{ArrowDown}");
    rerender(<Combobox label="Fruit" options={[...fruits]} value={null} onChange={onChange} />);
    expect(input()).toHaveAttribute("aria-activedescendant", option("Apple").id);
  });

  it("options swapped while open drop the active option, so Enter does not select another", async () => {
    const user = userEvent.setup();
    const onChange = vi.fn();
    const { rerender } = render(
      <Combobox label="Fruit" options={fruits} value={null} onChange={onChange} />,
    );
    await user.click(input());
    await user.keyboard("{ArrowDown}");
    expect(input()).toHaveAttribute("aria-activedescendant", option("Apple").id);
    rerender(
      <Combobox
        label="Fruit"
        options={[{ value: "z", label: "Zucchini" }, { value: "y", label: "Yam" }]}
        value={null}
        onChange={onChange}
      />,
    );
    expect(input()).not.toHaveAttribute("aria-activedescendant");
    expect(document.querySelector("[data-active]")).toBeNull();
    await user.keyboard("{Enter}");
    expect(onChange).not.toHaveBeenCalled();
  });
});

describe("Combobox clearing (C2, onChange null)", () => {
  it("blurring with empty text clears the selection", async () => {
    const user = userEvent.setup();
    const onChange = vi.fn();
    render(<Harness initial="banana" onChange={onChange} />);
    await user.clear(input());
    await user.tab();
    expect(onChange).toHaveBeenCalledExactlyOnceWith(null);
    expect(input()).toHaveValue("");
    expect(input()).toHaveAttribute("aria-expanded", "false");
  });

  it("Enter with empty text and no active option clears the selection and closes the listbox", async () => {
    const user = userEvent.setup();
    const onChange = vi.fn();
    render(<Harness initial="banana" onChange={onChange} />);
    await user.clear(input());
    await user.keyboard("{Enter}");
    expect(onChange).toHaveBeenCalledExactlyOnceWith(null);
    expect(input()).toHaveValue("");
    expect(input()).toHaveAttribute("aria-expanded", "false");
  });

  it("Escape after clearing reverts the text without calling onChange", async () => {
    const user = userEvent.setup();
    const onChange = vi.fn();
    render(<Harness initial="banana" onChange={onChange} />);
    await user.clear(input());
    await user.keyboard("{Escape}");
    expect(onChange).not.toHaveBeenCalled();
    expect(input()).toHaveValue("Banana");
  });

  it("blurring with empty text does not call onChange when nothing is selected", async () => {
    const user = userEvent.setup();
    const onChange = vi.fn();
    render(<Harness onChange={onChange} />);
    await user.click(input());
    await user.tab();
    expect(onChange).not.toHaveBeenCalled();
  });
});

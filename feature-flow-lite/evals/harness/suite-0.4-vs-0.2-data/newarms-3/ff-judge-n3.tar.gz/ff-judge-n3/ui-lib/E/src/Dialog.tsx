import * as React from "react";
import { createPortal } from "react-dom";

export type DialogProps = {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  title: React.ReactNode;
  description?: React.ReactNode;
  children?: React.ReactNode;
  className?: string;
  backdropClassName?: string;
};

type DialogContentProps = Omit<DialogProps, "open">;

// Refs to the dialogs enclosing the current one, outermost first, so a dialog can tell its ancestors from unrelated dialogs.
const DialogAncestorsContext = React.createContext<React.RefObject<HTMLDivElement | null>[]>([]);

const TABBABLE =
  'a[href], button, input:not([type="hidden"]), select, textarea, [tabindex]:not([tabindex="-1"])';

function getTabbables(container: HTMLElement): HTMLElement[] {
  return Array.from(container.querySelectorAll<HTMLElement>(TABBABLE)).filter(
    (element) => !element.hasAttribute("disabled") && element.closest("[hidden]") === null,
  );
}

export function Dialog({ open, ...rest }: DialogProps) {
  if (!open) return null;
  return createPortal(<DialogContent {...rest} />, document.body);
}

// Mounted only while the dialog is open, so its effects run on open and clean up on close.
function DialogContent({
  onOpenChange,
  title,
  description,
  children,
  className,
  backdropClassName,
}: DialogContentProps) {
  const baseId = React.useId();
  const titleId = `${baseId}-title`;
  const descriptionId = `${baseId}-description`;
  const hasDescription = description !== undefined && description !== null && description !== false;
  const ancestors = React.useContext(DialogAncestorsContext);
  const dialogRef = React.useRef<HTMLDivElement>(null);
  const chain = React.useMemo(() => [...ancestors, dialogRef], [ancestors]);
  const pressedOnBackdrop = React.useRef(false);

  React.useEffect(() => {
    const dialog = dialogRef.current;
    if (!dialog) return;
    const previous = document.activeElement as HTMLElement | null;
    const [first] = getTabbables(dialog);
    // A nested dialog can mount first and focus itself. Skip only when focus sits in a dialog that is neither this one nor an ancestor.
    const owner = document.activeElement?.closest('[role="dialog"]') ?? null;
    const unrelated = owner !== null && owner !== dialog && !ancestors.some((ref) => ref.current === owner);
    if (!unrelated) (first ?? dialog).focus();
    return () => {
      if (previous?.isConnected) previous.focus();
    };
  }, []);

  function handleKeyDown(event: React.KeyboardEvent<HTMLDivElement>) {
    if (event.key === "Escape") {
      event.preventDefault();
      // Portal events bubble through React, so stop here or an outer dialog would close too.
      event.stopPropagation();
      onOpenChange(false);
      return;
    }
    if (event.key !== "Tab") return;

    const dialog = dialogRef.current;
    if (!dialog) return;
    const tabbables = getTabbables(dialog);
    if (tabbables.length === 0) {
      event.preventDefault();
      dialog.focus();
      return;
    }

    const first = tabbables[0];
    const last = tabbables[tabbables.length - 1];
    const active = document.activeElement;
    if (event.shiftKey && (active === first || active === dialog)) {
      event.preventDefault();
      last.focus();
    } else if (!event.shiftKey && active === last) {
      event.preventDefault();
      first.focus();
    }
  }

  return (
    <DialogAncestorsContext.Provider value={chain}>
      <div
        data-dialog-backdrop=""
        className={backdropClassName}
        onKeyDown={handleKeyDown}
        onMouseDown={(event) => {
          pressedOnBackdrop.current = event.target === event.currentTarget;
        }}
        onClick={(event) => {
          const closes = pressedOnBackdrop.current && event.target === event.currentTarget;
          pressedOnBackdrop.current = false;
          if (closes) onOpenChange(false);
        }}
      >
        <div
          ref={dialogRef}
          role="dialog"
          aria-modal="true"
          aria-labelledby={titleId}
          aria-describedby={hasDescription ? descriptionId : undefined}
          tabIndex={-1}
          className={className}
        >
          <h2 id={titleId}>{title}</h2>
          {hasDescription && <p id={descriptionId}>{description}</p>}
          {children}
        </div>
      </div>
    </DialogAncestorsContext.Provider>
  );
}

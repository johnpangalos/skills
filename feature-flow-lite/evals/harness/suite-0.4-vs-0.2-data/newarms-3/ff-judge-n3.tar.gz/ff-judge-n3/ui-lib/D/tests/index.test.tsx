import { expectTypeOf } from "vitest";
import * as ui from "../src/index";
import type {
  ComboboxOption,
  ComboboxProps,
  DialogProps,
  TabListProps,
  TabPanelProps,
  TabProps,
  TabsProps,
} from "../src/index";

describe("package exports", () => {
  it("G1: exports the components", () => {
    expect(Object.keys(ui).sort()).toEqual(["Combobox", "Dialog", "Tab", "TabList", "TabPanel", "Tabs"]);
  });

  it("G1: exports the prop types", () => {
    expectTypeOf<ComboboxOption>().toEqualTypeOf<{ value: string; label: string; disabled?: boolean }>();
    expectTypeOf<TabsProps>().toHaveProperty("onValueChange");
    expectTypeOf<TabListProps>().toHaveProperty("aria-label");
    expectTypeOf<TabProps>().toHaveProperty("value");
    expectTypeOf<TabPanelProps>().toHaveProperty("value");
    expectTypeOf<DialogProps>().toHaveProperty("onOpenChange");
    expectTypeOf<ComboboxProps>().toHaveProperty("onChange");
  });
});

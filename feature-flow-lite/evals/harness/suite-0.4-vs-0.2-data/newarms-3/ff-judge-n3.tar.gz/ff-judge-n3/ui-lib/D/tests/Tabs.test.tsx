import { fireEvent, render, screen } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { Tab, TabList, TabPanel, Tabs, type TabsProps } from "../src/index";

function Basic({ disabled = [], ...props }: Partial<TabsProps> & { disabled?: string[] }) {
  return (
    <Tabs {...props}>
      <TabList aria-label="Sections">
        <Tab value="a" disabled={disabled.includes("a")}>Alpha</Tab>
        <Tab value="b" disabled={disabled.includes("b")}>Beta</Tab>
        <Tab value="c" disabled={disabled.includes("c")}>Gamma</Tab>
      </TabList>
      <TabPanel value="a">Panel A</TabPanel>
      <TabPanel value="b">Panel B</TabPanel>
      <TabPanel value="c">Panel C</TabPanel>
    </Tabs>
  );
}

function Dynamic({ values }: { values: string[] }) {
  return (
    <Tabs defaultValue="a">
      <TabList aria-label="Dynamic">
        {values.map((value) => (
          <Tab key={value} value={value}>{value.toUpperCase()}</Tab>
        ))}
      </TabList>
    </Tabs>
  );
}

function Late({
  tabs,
  disabled = [],
  defaultValue,
}: {
  tabs: string[];
  disabled?: string[];
  defaultValue?: string;
}) {
  return (
    <Tabs defaultValue={defaultValue}>
      <TabList aria-label="Late">
        {tabs.map((value) => (
          <Tab key={value} value={value} disabled={disabled.includes(value)}>{value}</Tab>
        ))}
      </TabList>
      {tabs.map((value) => (
        <TabPanel key={value} value={value}>Panel {value}</TabPanel>
      ))}
    </Tabs>
  );
}

const tab = (name: string) => screen.getByRole("tab", { name });

describe("Tabs", () => {
  it("T1: uncontrolled starts at defaultValue", () => {
    render(<Basic defaultValue="c" />);
    expect(tab("Gamma")).toHaveAttribute("aria-selected", "true");
    expect(tab("Alpha")).toHaveAttribute("aria-selected", "false");
  });

  it("T1: uncontrolled starts at the first non-disabled tab when there is no defaultValue", () => {
    render(<Basic disabled={["a"]} />);
    expect(tab("Beta")).toHaveAttribute("aria-selected", "true");
  });

  it("T1: controlled displays value and changes only when the parent changes it", async () => {
    const user = userEvent.setup();
    const onValueChange = vi.fn();
    const { rerender } = render(<Basic value="a" onValueChange={onValueChange} />);
    await user.click(tab("Gamma"));
    expect(onValueChange).toHaveBeenCalledWith("c");
    expect(tab("Alpha")).toHaveAttribute("aria-selected", "true");
    expect(tab("Gamma")).toHaveAttribute("aria-selected", "false");
    rerender(<Basic value="c" onValueChange={onValueChange} />);
    expect(tab("Gamma")).toHaveAttribute("aria-selected", "true");
  });

  it("T1: uncontrolled onValueChange is called on user selection", async () => {
    const user = userEvent.setup();
    const onValueChange = vi.fn();
    render(<Basic defaultValue="c" onValueChange={onValueChange} />);
    await user.click(tab("Beta"));
    expect(onValueChange).toHaveBeenCalledWith("b");
    expect(tab("Beta")).toHaveAttribute("aria-selected", "true");
  });

  it("T2: TabList is a horizontal tablist with its aria-label", () => {
    render(<Basic />);
    const list = screen.getByRole("tablist", { name: "Sections" });
    expect(list).toHaveAttribute("aria-orientation", "horizontal");
  });

  it("T2: aria-label is required by the TabList type", () => {
    // @ts-expect-error aria-label is required
    const missingLabel = <TabList><Tab value="a">Alpha</Tab></TabList>;
    expect(missingLabel).toBeTruthy();
  });

  it("T3: Tab is a type=button role=tab with an id and aria-controls pointing at its panel", () => {
    render(<Basic />);
    const alpha = tab("Alpha");
    expect(alpha.tagName).toBe("BUTTON");
    expect(alpha).toHaveAttribute("type", "button");
    expect(alpha.id).not.toBe("");
    const panel = document.getElementById(alpha.getAttribute("aria-controls") ?? "");
    expect(panel).toHaveAttribute("role", "tabpanel");
  });

  it("T3: disabled tab has aria-disabled, is disabled and cannot be clicked", async () => {
    const user = userEvent.setup();
    const onValueChange = vi.fn();
    render(<Basic disabled={["b"]} onValueChange={onValueChange} />);
    const beta = tab("Beta");
    expect(beta).toBeDisabled();
    expect(beta).toHaveAttribute("aria-disabled", "true");
    await user.click(beta);
    expect(beta).toHaveAttribute("aria-selected", "false");
    expect(onValueChange).not.toHaveBeenCalled();
  });

  it("T4: only the selected panel is shown, and it is labelled by its tab", () => {
    render(<Basic defaultValue="b" />);
    const panel = screen.getByRole("tabpanel");
    expect(panel).toHaveTextContent("Panel B");
    expect(panel).toHaveAttribute("aria-labelledby", tab("Beta").id);
    expect(panel).toHaveAttribute("tabindex", "0");
    const hiddenPanel = document.getElementById(tab("Alpha").getAttribute("aria-controls") ?? "");
    expect(hiddenPanel).toHaveAttribute("hidden");
  });

  it("T5: only the selected tab has tabIndex 0", () => {
    render(<Basic defaultValue="b" />);
    expect(tab("Alpha")).toHaveAttribute("tabindex", "-1");
    expect(tab("Beta")).toHaveAttribute("tabindex", "0");
    expect(tab("Gamma")).toHaveAttribute("tabindex", "-1");
  });

  it("T5: with a controlled value matching no tab, the first enabled tab is the tab stop", () => {
    render(<Basic value="zzz" />);
    expect(tab("Alpha")).toHaveAttribute("tabindex", "0");
    expect(tab("Beta")).toHaveAttribute("tabindex", "-1");
    expect(tab("Gamma")).toHaveAttribute("tabindex", "-1");
  });

  it("T5: with the selected tab disabled, the first enabled tab is the tab stop", () => {
    render(<Basic value="b" disabled={["a", "b"]} />);
    expect(tab("Gamma")).toHaveAttribute("tabindex", "0");
    expect(tab("Beta")).toHaveAttribute("tabindex", "-1");
  });

  it("T6: ArrowRight and ArrowLeft move focus and selection, wrapping at both ends", async () => {
    const user = userEvent.setup();
    const onValueChange = vi.fn();
    render(<Basic onValueChange={onValueChange} />);
    await user.tab();
    expect(tab("Alpha")).toHaveFocus();
    await user.keyboard("{ArrowRight}");
    expect(tab("Beta")).toHaveFocus();
    expect(tab("Beta")).toHaveAttribute("aria-selected", "true");
    expect(onValueChange).toHaveBeenLastCalledWith("b");
    await user.keyboard("{ArrowRight}{ArrowRight}");
    expect(tab("Alpha")).toHaveFocus();
    await user.keyboard("{ArrowLeft}");
    expect(tab("Gamma")).toHaveFocus();
    expect(onValueChange).toHaveBeenLastCalledWith("c");
  });

  it("T6: ArrowRight and ArrowLeft skip disabled tabs", async () => {
    const user = userEvent.setup();
    render(<Basic disabled={["b"]} />);
    await user.tab();
    await user.keyboard("{ArrowRight}");
    expect(tab("Gamma")).toHaveFocus();
    await user.keyboard("{ArrowLeft}");
    expect(tab("Alpha")).toHaveFocus();
  });

  it("T6: Home and End go to the first and last enabled tab", async () => {
    const user = userEvent.setup();
    render(<Basic disabled={["c"]} />);
    await user.tab();
    await user.keyboard("{End}");
    expect(tab("Beta")).toHaveFocus();
    expect(tab("Beta")).toHaveAttribute("aria-selected", "true");
    await user.keyboard("{Home}");
    expect(tab("Alpha")).toHaveFocus();
  });

  it("T6: handled keys call preventDefault and other keys do nothing", async () => {
    const user = userEvent.setup();
    const onValueChange = vi.fn();
    render(<Basic onValueChange={onValueChange} />);
    await user.tab();
    expect(fireEvent.keyDown(tab("Alpha"), { key: "ArrowRight" })).toBe(false);
    expect(fireEvent.keyDown(tab("Beta"), { key: "Home" })).toBe(false);
    expect(fireEvent.keyDown(tab("Alpha"), { key: "ArrowDown" })).toBe(true);
    expect(fireEvent.keyDown(tab("Alpha"), { key: "x" })).toBe(true);
    expect(tab("Alpha")).toHaveAttribute("aria-selected", "true");
    expect(onValueChange).toHaveBeenCalledTimes(2);
  });

  it("T7: clicking an enabled tab selects it", async () => {
    const user = userEvent.setup();
    render(<Basic />);
    await user.click(tab("Gamma"));
    expect(tab("Gamma")).toHaveAttribute("aria-selected", "true");
    expect(tab("Alpha")).toHaveAttribute("aria-selected", "false");
  });

  it("T8: keyboard order follows the DOM order of rendered tabs as they change", async () => {
    const user = userEvent.setup();
    const { rerender } = render(<Dynamic values={["a", "b", "c"]} />);
    rerender(<Dynamic values={["a", "c", "d"]} />);
    await user.tab();
    expect(tab("A")).toHaveFocus();
    await user.keyboard("{ArrowRight}");
    expect(tab("C")).toHaveFocus();
    await user.keyboard("{ArrowRight}");
    expect(tab("D")).toHaveFocus();
  });

  it("hostile: all tabs disabled - arrows, Home and End do nothing and nothing is selected", () => {
    const onValueChange = vi.fn();
    render(<Basic disabled={["a", "b", "c"]} onValueChange={onValueChange} />);
    fireEvent.keyDown(tab("Alpha"), { key: "ArrowRight" });
    fireEvent.keyDown(screen.getByRole("tablist"), { key: "End" });
    expect(onValueChange).not.toHaveBeenCalled();
    expect(screen.getAllByRole("tab").every((t) => t.getAttribute("aria-selected") === "false")).toBe(true);
  });

  it("hostile: a single enabled tab - arrows keep focus and selection on it", async () => {
    const user = userEvent.setup();
    const onValueChange = vi.fn();
    render(<Basic disabled={["a", "c"]} onValueChange={onValueChange} />);
    await user.tab();
    expect(tab("Beta")).toHaveFocus();
    await user.keyboard("{ArrowRight}{ArrowLeft}{Home}{End}");
    expect(tab("Beta")).toHaveFocus();
    expect(tab("Beta")).toHaveAttribute("aria-selected", "true");
    expect(onValueChange).not.toHaveBeenCalled();
  });

  it("hostile: defaultValue naming a disabled tab starts on the first enabled tab", async () => {
    const user = userEvent.setup();
    render(<Basic defaultValue="b" disabled={["b"]} />);
    expect(tab("Alpha")).toHaveAttribute("aria-selected", "true");
    await user.tab();
    expect(tab("Alpha")).toHaveFocus();
  });

  it("hostile: defaultValue naming no tab starts on the first enabled tab", () => {
    render(<Basic defaultValue="zzz" />);
    expect(tab("Alpha")).toHaveAttribute("aria-selected", "true");
    expect(tab("Alpha")).toHaveAttribute("tabindex", "0");
  });

  it("hostile: controlled parent that ignores onValueChange keeps aria-selected on value", async () => {
    const user = userEvent.setup();
    const onValueChange = vi.fn();
    render(<Basic value="a" onValueChange={onValueChange} />);
    await user.tab();
    await user.keyboard("{ArrowRight}");
    expect(tab("Beta")).toHaveFocus();
    expect(onValueChange).toHaveBeenCalledWith("b");
    expect(tab("Alpha")).toHaveAttribute("aria-selected", "true");
    expect(tab("Beta")).toHaveAttribute("aria-selected", "false");
  });

  it("hostile: two Tabs instances on one page do not share ids", () => {
    render(
      <>
        <Basic />
        <Basic />
      </>,
    );
    const tabIds = screen.getAllByRole("tab").map((t) => t.id);
    const panelIds = Array.from(document.querySelectorAll('[role="tabpanel"]')).map((p) => p.id);
    expect(new Set([...tabIds, ...panelIds]).size).toBe(tabIds.length + panelIds.length);
    expect(panelIds).toHaveLength(6);
  });

  it("T1: uncontrolled with no defaultValue selects the first enabled tab once tabs mount after the first render", () => {
    const { rerender } = render(<Late tabs={[]} />);
    rerender(<Late tabs={["a", "b"]} />);
    expect(tab("a")).toHaveAttribute("aria-selected", "true");
    expect(tab("b")).toHaveAttribute("aria-selected", "false");
    expect(tab("a")).toHaveAttribute("tabindex", "0");
    expect(document.getElementById(tab("a").getAttribute("aria-controls") ?? "")).toBeVisible();
  });

  it("T1: late-mounted tabs auto-select the first enabled tab, skipping a disabled first tab", () => {
    const { rerender } = render(<Late tabs={[]} />);
    rerender(<Late tabs={["a", "b"]} disabled={["a"]} />);
    expect(tab("b")).toHaveAttribute("aria-selected", "true");
    expect(tab("a")).toHaveAttribute("aria-selected", "false");
  });

  it("T1: a defaultValue naming a tab that mounts later is kept, not replaced", () => {
    const { rerender } = render(<Late tabs={[]} defaultValue="b" />);
    rerender(<Late tabs={["a", "b"]} defaultValue="b" />);
    expect(tab("b")).toHaveAttribute("aria-selected", "true");
    expect(tab("a")).toHaveAttribute("aria-selected", "false");
  });
});

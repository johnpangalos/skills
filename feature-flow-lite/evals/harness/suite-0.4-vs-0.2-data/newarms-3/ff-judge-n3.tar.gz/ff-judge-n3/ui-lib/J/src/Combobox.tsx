import { useId, useState, type KeyboardEvent } from "react";

export type ComboboxOption<T extends string = string> = {
  value: T;
  label: string;
  disabled?: boolean;
};

export type ComboboxProps<T extends string = string> = {
  label: string;
  options: ComboboxOption<T>[];
  value: T | null;
  onChange: (value: T | null) => void;
  placeholder?: string;
};

// Next enabled index after `from` in direction `step`, wrapping at the ends. Null if none is enabled.
function stepToEnabled<T extends string>(
  options: ComboboxOption<T>[],
  from: number,
  step: 1 | -1,
): number | null {
  const count = options.length;
  for (let i = 1; i <= count; i++) {
    const index = (((from + step * i) % count) + count) % count;
    if (!options[index].disabled) return index;
  }
  return null;
}

// The selected option if it is enabled, otherwise the first enabled option.
function startIndex<T extends string>(options: ComboboxOption<T>[], value: T | null): number | null {
  const selected = options.findIndex((option) => option.value === value);
  if (selected !== -1 && !options[selected].disabled) return selected;
  return stepToEnabled(options, -1, 1);
}

export function Combobox<T extends string = string>({
  label,
  options,
  value,
  onChange,
  placeholder,
}: ComboboxProps<T>) {
  const baseId = useId();
  const labelId = `${baseId}-label`;
  const inputId = `${baseId}-input`;
  const listboxId = `${baseId}-listbox`;
  const [open, setOpen] = useState(false);
  // The text the user typed; null when not typing, in which case the input shows the selected label.
  const [query, setQuery] = useState<string | null>(null);
  // The active option's value; it drops out when that option is filtered away or removed.
  const [active, setActive] = useState<T | null>(null);

  const selectedLabel = options.find((option) => option.value === value)?.label ?? "";
  const needle = (query ?? "").toLowerCase();
  const visible = options.filter((option) => option.label.toLowerCase().includes(needle));
  const found = active === null ? -1 : visible.findIndex((option) => option.value === active);
  const activeIndex = found !== -1 && !visible[found].disabled ? found : null;
  // Empty text means the user cleared the input; blur or Enter then clears the selection.
  const canClear = query === "" && value !== null;

  const optionId = (index: number) => `${baseId}-option-${index}`;

  function activate(index: number | null) {
    setActive(index === null ? null : visible[index].value);
  }

  function closeListbox() {
    setOpen(false);
    setQuery(null);
    setActive(null);
  }

  function choose(option: ComboboxOption<T>) {
    onChange(option.value);
    closeListbox();
  }

  function handleBlur() {
    if (canClear) onChange(null);
    closeListbox();
  }

  function handleKeyDown(event: KeyboardEvent<HTMLInputElement>) {
    switch (event.key) {
      case "ArrowDown":
      case "ArrowUp": {
        event.preventDefault();
        const step = event.key === "ArrowDown" ? 1 : -1;
        if (!open) {
          setOpen(true);
          activate(startIndex(visible, value));
        } else {
          activate(stepToEnabled(visible, activeIndex ?? (step === 1 ? -1 : visible.length), step));
        }
        return;
      }
      case "Enter":
        if (!open) return;
        // Enter belongs to the listbox while it is open, so it never submits a surrounding form.
        event.preventDefault();
        if (activeIndex !== null) {
          choose(visible[activeIndex]);
        } else if (canClear) {
          onChange(null);
          closeListbox();
        }
        return;
      case "Escape":
        if (!open) return;
        // Escape closes only the listbox; the event stops here so an enclosing dialog stays open.
        event.stopPropagation();
        closeListbox();
        return;
      default:
        return;
    }
  }

  return (
    <>
      <label id={labelId} htmlFor={inputId}>
        {label}
      </label>
      <input
        id={inputId}
        type="text"
        role="combobox"
        autoComplete="off"
        placeholder={placeholder}
        value={query ?? selectedLabel}
        aria-expanded={open}
        aria-controls={listboxId}
        aria-autocomplete="list"
        aria-activedescendant={activeIndex !== null ? optionId(activeIndex) : undefined}
        onChange={(event) => {
          setQuery(event.target.value);
          setOpen(true);
          setActive(null);
        }}
        onKeyDown={handleKeyDown}
        onBlur={handleBlur}
      />
      <ul id={listboxId} role="listbox" aria-labelledby={labelId} hidden={!open}>
        {open && visible.length === 0 ? <li role="presentation">No results</li> : null}
        {open &&
          visible.map((option, index) => (
            <li
              key={index}
              id={optionId(index)}
              role="option"
              aria-selected={option.value === value}
              aria-disabled={option.disabled || undefined}
              data-active={index === activeIndex ? "true" : undefined}
              onMouseDown={(event) => event.preventDefault()}
              onClick={() => {
                if (!option.disabled) choose(option);
              }}
            >
              {option.label}
            </li>
          ))}
      </ul>
    </>
  );
}

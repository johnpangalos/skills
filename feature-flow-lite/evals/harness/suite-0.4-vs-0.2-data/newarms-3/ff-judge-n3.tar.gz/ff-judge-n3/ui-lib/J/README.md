# @acme/ui

Accessible React components that follow the WAI-ARIA Authoring Practices patterns for Tabs, Dialog and Combobox. There is no CSS: style the elements yourself. Ids come from `useId()`, so several instances can share a page.

Run the tests and type check with `pnpm test` and `pnpm typecheck`.

## Usage

```tsx
import { Combobox, Dialog, TabList, Tab, TabPanel, Tabs } from "@acme/ui";
import { useState } from "react";

function Example() {
  const [fruit, setFruit] = useState<string | null>(null);
  const [open, setOpen] = useState(false);
  return (
    <>
      <Tabs defaultValue="plans">
        <TabList aria-label="Settings">
          <Tab value="plans">Plans</Tab>
          <Tab value="billing" disabled>Billing</Tab>
        </TabList>
        <TabPanel value="plans">Choose a plan.</TabPanel>
        <TabPanel value="billing">Not available.</TabPanel>
      </Tabs>
      <Combobox
        label="Fruit"
        options={[{ value: "apple", label: "Apple" }, { value: "pear", label: "Pear", disabled: true }]}
        value={fruit}
        onChange={setFruit}
        placeholder="Pick a fruit"
      />
      <button onClick={() => setOpen(true)}>Delete</button>
      <Dialog open={open} onOpenChange={setOpen} title="Delete file" description="This cannot be undone.">
        <button onClick={() => setOpen(false)}>Confirm</button>
      </Dialog>
    </>
  );
}
```

## Tabs

`Tabs` has no DOM of its own. Put one `TabList`, one `Tab` per tab and one `TabPanel` per tab value inside it. Refs are not forwarded to the rendered elements.

### Tabs

| Prop | Type | Required / default | Description |
| --- | --- | --- | --- |
| `defaultValue` | `string` | optional; first enabled tab | Initially selected tab value when uncontrolled. |
| `value` | `string` | optional | Selected tab value when controlled. Wins over `defaultValue`. |
| `onValueChange` | `(value: string) => void` | optional | Called with the new value on a user selection. Not called when the selected tab is chosen again. |
| `children` | `ReactNode` | optional | `TabList` and `TabPanel` elements. |

### TabList

| Prop | Type | Required / default | Description |
| --- | --- | --- | --- |
| `aria-label` | `string` | required | Accessible name of the `tablist`. |
| `...rest` | `ComponentPropsWithoutRef<"div">` | optional | Passed to the `div role="tablist"`. |

### Tab

| Prop | Type | Required / default | Description |
| --- | --- | --- | --- |
| `value` | `string` | required | Value this tab selects. |
| `disabled` | `boolean` | optional; `false` | Disabled tabs cannot be clicked or reached with the arrow keys. |
| `...rest` | `ComponentPropsWithoutRef<"button">` | optional | Passed to the `button role="tab"`. |

### TabPanel

| Prop | Type | Required / default | Description |
| --- | --- | --- | --- |
| `value` | `string` | required | Tab value this panel belongs to. Panels for other values stay in the DOM with `hidden`. |
| `...rest` | `ComponentPropsWithoutRef<"div">` | optional | Passed to the `div role="tabpanel"`. |

### Tabs keyboard

| Key | Action |
| --- | --- |
| Tab | Moves focus into the tablist (to the selected tab) and out of it. |
| ArrowRight | Focuses and selects the next enabled tab; wraps from last to first. |
| ArrowLeft | Focuses and selects the previous enabled tab; wraps from first to last. |
| Home | Focuses and selects the first enabled tab. |
| End | Focuses and selects the last enabled tab. |

## Dialog

A modal `role="dialog"` rendered into `document.body` through a portal, with a backdrop. Nothing is rendered while `open` is false.

On open, focus moves to the first tabbable element inside the dialog, or to the dialog itself when there is none. Tab and Shift+Tab are kept inside the dialog. On close or unmount, focus returns to the element that was focused before opening, if it is still in the document.

When dialogs are nested, only the topmost one handles Escape and Tab: the most deeply nested open dialog, or among equally nested ones the most recently opened. Closing the inner dialog hands these keys back to the outer one.

### Dialog props

| Prop | Type | Required / default | Description |
| --- | --- | --- | --- |
| `open` | `boolean` | required | Whether the dialog is shown. |
| `onOpenChange` | `(open: boolean) => void` | required | Called with `false` on Escape or a backdrop click. |
| `title` | `ReactNode` | required | Rendered in an `h2`; names the dialog. |
| `description` | `ReactNode` | optional | Rendered in a `p` unless it is `null`, `undefined` or `false` (so `0` shows); describes the dialog. Only then is `aria-describedby` set. |
| `children` | `ReactNode` | optional | Dialog content. |
| `...rest` | `ComponentPropsWithoutRef<"div">` minus `title` | optional | Passed to the `div role="dialog"`. |

A backdrop click closes the dialog only when the mouse went down on the backdrop too, so a text selection that starts inside the dialog does not close it.

### Dialog keyboard

| Key | Action |
| --- | --- |
| Tab | Moves to the next tabbable element inside the topmost dialog; wraps from last to first. Disabled, hidden and `tabindex="-1"` elements are skipped. |
| Shift+Tab | Moves to the previous tabbable element inside the topmost dialog; wraps from first to last. |
| Escape | Calls `onOpenChange(false)` on the topmost dialog only. A nested Combobox with an open listbox consumes Escape first and closes only the listbox. |

## Combobox

A text input with `role="combobox"` and a filterable listbox, labelled by `label`. Typing filters the options by case-insensitive substring match on the label. The listbox is always in the DOM and is `hidden` while closed.

Keyboard arrows wrap at both ends and skip disabled options. The active option is exposed through `aria-activedescendant` and carries `data-active="true"`. Focus never leaves the input. Option ids are index-based, so option values can contain any characters.

The active option is tracked by its value: it is kept when a new `options` array still contains it, dropped when the option is removed or filtered away, and reset when typing changes the filter. Option values should be unique.

### Combobox props

| Prop | Type | Required / default | Description |
| --- | --- | --- | --- |
| `label` | `string` | required | Visible label; names the input and the listbox. |
| `options` | `ComboboxOption<T>[]` | required | Options, each `{ value: T; label: string; disabled?: boolean }`. `T` extends `string` and defaults to `string`. |
| `value` | `T \| null` | required | Selected option value, or `null` for none. The input text follows this prop, and typing never changes it. An unknown value shows empty text. |
| `onChange` | `(value: T \| null) => void` | required | Called with the option value when an enabled option is chosen with Enter or a click. Called with `null` when the user has emptied the input and then blurs, or presses Enter with no active option, and `value` is not `null`. Clearing and then pressing Escape does not call it. |
| `placeholder` | `string` | optional | Placeholder of the input. |

### Combobox keyboard

| Key | Action |
| --- | --- |
| ArrowDown | Opens the listbox if closed, activating the selected option or the first enabled option. When open, activates the next enabled option. |
| ArrowUp | Same as ArrowDown, moving to the previous enabled option. |
| Enter | While open with an active option, selects it and closes the listbox. While open with no active option and empty text, clears the selection (`onChange(null)`) and closes the listbox. While open, never submits a surrounding form. |
| Escape | While the listbox is open, closes it and reverts the text to the selected label, without calling `onChange`. |
| Typing | Opens the listbox and filters the options. |
| Blur | Closes the listbox and reverts the text to the selected label. With empty text and a selected value, calls `onChange(null)` first to clear the selection. |

import {
  createContext,
  useContext,
  useEffect,
  useId,
  useRef,
  useState,
  type ComponentPropsWithoutRef,
  type MouseEvent,
  type ReactNode,
  type RefObject,
} from "react";
import { createPortal } from "react-dom";

export type DialogProps = Omit<ComponentPropsWithoutRef<"div">, "title"> & {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  title: ReactNode;
  description?: ReactNode;
};

const FOCUSABLE = [
  "button:not([disabled])",
  "a[href]",
  "input:not([disabled]):not([type='hidden'])",
  "select:not([disabled])",
  "textarea:not([disabled])",
  "[tabindex]:not([tabindex='-1'])",
  "[contenteditable]:not([contenteditable='false'])",
].join(",");

function getFocusable(container: HTMLElement): HTMLElement[] {
  return Array.from(container.querySelectorAll<HTMLElement>(FOCUSABLE));
}

type OpenDialog = { element: HTMLElement; parent: HTMLElement | null };

// Open dialogs from bottom to top. The top one owns keys when focus is outside every dialog.
const openDialogs: OpenDialog[] = [];

// Lets a dialog rendered inside another one record its parent.
const ParentDialogContext = createContext<RefObject<HTMLElement | null> | null>(null);

function topDialog(): HTMLElement | undefined {
  return openDialogs[openDialogs.length - 1]?.element;
}

// The innermost open dialog that contains the target, or the top dialog when the target is outside all of them.
function ownerOf(target: EventTarget | null): HTMLElement | undefined {
  const containing = openDialogs.find((entry) => entry.element.contains(target as Node | null));
  return containing?.element ?? topDialog();
}

// Removes the dialog, and any dialog that has already left the document.
function forgetDialog(dialog: HTMLElement) {
  const remaining = openDialogs.filter((entry) => entry.element !== dialog && entry.element.isConnected);
  openDialogs.splice(0, openDialogs.length, ...remaining);
}

// Returns focus to the opener when no dialog is left or it sits inside the top dialog; otherwise focuses the top dialog.
function restoreFocus(previous: HTMLElement | null) {
  const top = topDialog();
  if (previous?.isConnected && (!top || top.contains(previous))) {
    previous.focus();
  } else if (top) {
    (getFocusable(top)[0] ?? top).focus();
  }
}

// Wraps Tab and Shift+Tab inside the dialog. Keys that do not cross the edges are left to the browser.
function keepTabWithin(event: KeyboardEvent, dialog: HTMLElement) {
  const focusable = getFocusable(dialog);
  const first = focusable[0] ?? dialog;
  const last = focusable[focusable.length - 1] ?? dialog;
  const active = document.activeElement;
  const outside = !dialog.contains(active);
  if (event.shiftKey) {
    if (outside || active === first || active === dialog) {
      event.preventDefault();
      last.focus();
    }
  } else if (outside || active === last || active === dialog) {
    event.preventDefault();
    first.focus();
  }
}

export function Dialog({ open, ...props }: DialogProps) {
  if (!open) return null;
  return createPortal(<DialogSurface {...props} />, document.body);
}

// Mounted only while open, so its effects run once per opening and focus is restored on close.
function DialogSurface({ onOpenChange, title, description, children, ...rest }: Omit<DialogProps, "open">) {
  const titleId = useId();
  const descriptionId = useId();
  const dialogRef = useRef<HTMLDivElement>(null);
  const parentRef = useContext(ParentDialogContext);
  const pressStartedOnBackdrop = useRef(false);
  // Read during the first render, before any child effect moves focus, so nested dialogs both record the real opener.
  const [previous] = useState(() => document.activeElement as HTMLElement | null);
  const onOpenChangeRef = useRef(onOpenChange);

  useEffect(() => {
    onOpenChangeRef.current = onOpenChange;
  });

  useEffect(() => {
    const dialog = dialogRef.current;
    if (!dialog) return;
    const entry = { element: dialog, parent: parentRef?.current ?? null };
    const active = document.activeElement;
    const child = openDialogs.find((open) => open.element.contains(active));
    if (child && child.parent === dialog) {
      // A nested dialog mounted in this same commit already took focus, so this one goes beneath it.
      openDialogs.splice(openDialogs.indexOf(child), 0, entry);
    } else {
      openDialogs.push(entry);
      (getFocusable(dialog)[0] ?? dialog).focus();
    }
    return () => {
      forgetDialog(dialog);
      restoreFocus(previous);
    };
  }, []);

  // A document listener, not React's onKeyDown: focus can be on <body> after the focused element unmounts.
  useEffect(() => {
    const dialog = dialogRef.current;
    if (!dialog) return;
    const handleDocumentKeyDown = (event: KeyboardEvent) => {
      if (ownerOf(event.target) !== dialog) return;
      if (event.key === "Escape") {
        if (!event.defaultPrevented) onOpenChangeRef.current(false);
      } else if (event.key === "Tab") {
        keepTabWithin(event, dialog);
      }
    };
    document.addEventListener("keydown", handleDocumentKeyDown);
    return () => document.removeEventListener("keydown", handleDocumentKeyDown);
  }, []);

  // Keeping focus where it is stops a backdrop press from moving focus to <body>, where Tab would escape.
  const handleBackdropMouseDown = (event: MouseEvent<HTMLDivElement>) => {
    pressStartedOnBackdrop.current = event.target === event.currentTarget;
    if (pressStartedOnBackdrop.current) event.preventDefault();
  };

  const handleBackdropClick = (event: MouseEvent<HTMLDivElement>) => {
    if (pressStartedOnBackdrop.current && event.target === event.currentTarget) {
      onOpenChange(false);
    }
  };

  return (
    <div onMouseDown={handleBackdropMouseDown} onClick={handleBackdropClick}>
      <div
        {...rest}
        ref={dialogRef}
        role="dialog"
        aria-modal="true"
        aria-labelledby={titleId}
        aria-describedby={description != null ? descriptionId : undefined}
        tabIndex={-1}
      >
        <h2 id={titleId}>{title}</h2>
        {description != null && <p id={descriptionId}>{description}</p>}
        <ParentDialogContext.Provider value={dialogRef}>{children}</ParentDialogContext.Provider>
      </div>
    </div>
  );
}

import {
  useEffect,
  useId,
  useRef,
  type ComponentPropsWithoutRef,
  type KeyboardEvent,
  type ReactNode,
} from "react";
import { createPortal } from "react-dom";

export type DialogProps = Omit<ComponentPropsWithoutRef<"div">, "title" | "onKeyDown"> & {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  title: ReactNode;
  description?: ReactNode;
};

const TABBABLE =
  "a[href]:not([disabled]), button:not([disabled]), input:not([disabled]), select:not([disabled]), textarea:not([disabled]), [tabindex]:not([disabled]), [contenteditable]:not([disabled])";

function tabbableIn(container: HTMLElement): HTMLElement[] {
  return Array.from(container.querySelectorAll<HTMLElement>(TABBABLE)).filter(
    (element) => element.tabIndex >= 0 && element.closest("[hidden]") === null,
  );
}

function keepFocusInside(event: KeyboardEvent<HTMLDivElement>, dialog: HTMLDivElement) {
  const items = tabbableIn(dialog);
  if (items.length === 0) {
    event.preventDefault();
    dialog.focus();
    return;
  }
  const first = items[0];
  const last = items[items.length - 1];
  const active = document.activeElement;
  if (event.shiftKey && (active === first || active === dialog)) {
    event.preventDefault();
    last.focus();
  } else if (!event.shiftKey && active === last) {
    event.preventDefault();
    first.focus();
  }
}

export function Dialog({ open, ...props }: DialogProps) {
  if (!open) return null;
  return createPortal(<DialogBody {...props} />, document.body);
}

function DialogBody({ onOpenChange, title, description, children, ...props }: Omit<DialogProps, "open">) {
  const titleId = useId();
  const descriptionId = useId();
  const dialogRef = useRef<HTMLDivElement>(null);
  const pressedOnBackdrop = useRef(false);
  const hasDescription = description !== undefined && description !== null && description !== "";

  // Mounted only while open: focus moves in on mount and returns on unmount.
  useEffect(() => {
    const previous = document.activeElement as HTMLElement | null;
    const dialog = dialogRef.current;
    if (dialog === null) return;
    (tabbableIn(dialog)[0] ?? dialog).focus();
    return () => {
      if (previous !== null && previous.isConnected) previous.focus();
    };
  }, []);

  function handleKeyDown(event: KeyboardEvent<HTMLDivElement>) {
    if (event.key === "Escape" && !event.defaultPrevented) {
      // Stop here: React events bubble through portals, so an enclosing Dialog must not also close.
      event.preventDefault();
      event.stopPropagation();
      onOpenChange(false);
      return;
    }
    const dialog = dialogRef.current;
    if (event.key !== "Tab" || event.defaultPrevented || dialog === null) return;
    // Ignore Tab from a nested dialog, which is portaled outside this one's DOM.
    if (!dialog.contains(event.target as Node)) return;
    keepFocusInside(event, dialog);
  }

  return (
    <>
      <div
        data-backdrop=""
        aria-hidden="true"
        onMouseDown={(event) => {
          pressedOnBackdrop.current = event.target === event.currentTarget;
        }}
        onClick={(event) => {
          if (pressedOnBackdrop.current && event.target === event.currentTarget) {
            onOpenChange(false);
          }
        }}
      />
      <div
        {...props}
        ref={dialogRef}
        role="dialog"
        aria-modal="true"
        aria-labelledby={titleId}
        aria-describedby={hasDescription ? descriptionId : undefined}
        tabIndex={-1}
        onKeyDown={handleKeyDown}
      >
        <h2 id={titleId}>{title}</h2>
        {hasDescription && <p id={descriptionId}>{description}</p>}
        {children}
      </div>
    </>
  );
}

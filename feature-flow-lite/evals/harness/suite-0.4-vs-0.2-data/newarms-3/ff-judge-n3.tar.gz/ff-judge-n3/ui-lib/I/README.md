# @acme/ui

Accessible, style-agnostic React 19 components: `Tabs`, `Dialog` and `Combobox`. No CSS is shipped; style the rendered elements with `className`, or target the ARIA attributes and `data-*` hooks.

## Development

```sh
pnpm install
pnpm test       # Vitest + Testing Library (jsdom)
pnpm typecheck
```

All components are exported from `src/index.ts`. Extra props such as `className` and `data-*` go to the main element; ARIA ids come from `useId`, so several instances can share a page.

## Tabs

Follows the WAI-ARIA tabs pattern. Only the selected tab is in the tab order.

```tsx
<Tabs defaultValue="apple">
  <TabList aria-label="Fruit">
    <Tab value="apple">Apple</Tab>
    <Tab value="banana" disabled>Banana</Tab>
    <Tab value="cherry">Cherry</Tab>
  </TabList>
  <TabPanel value="apple">…</TabPanel>
  <TabPanel value="cherry">…</TabPanel>
</Tabs>
```

| Component | Prop | Type | Default | Description |
| --- | --- | --- | --- | --- |
| `Tabs` | `defaultValue` | `string` | none | Initially selected tab, uncontrolled. With neither prop, the first enabled tab is selected (without calling `onValueChange`). |
| `Tabs` | `value` | `string` | none | Selected tab, controlled. A parent that ignores `onValueChange` keeps the old selection. |
| `Tabs` | `onValueChange` | `(value: string) => void` | none | Called with the new value only when it differs from the current one. |
| `TabList` | `aria-label` | `string` | required | Accessible name of the `tablist`. |
| `Tab` | `value` | `string` | required | Identifies the tab and links it to its panel. |
| `Tab` | `disabled` | `boolean` | `false` | Skipped by the arrow keys and cannot be clicked. |
| `TabPanel` | `value` | `string` | required | The panel for the tab with the same value. Hidden unless selected. |

If the selected tab is disabled or missing, the first enabled tab is the tab stop. If every tab is disabled, arrow keys do nothing.

| Key | Action |
| --- | --- |
| `ArrowRight` / `ArrowLeft` | Move focus to the next or previous enabled tab, wrapping at the ends. Selection follows focus. |
| `Home` / `End` | Move focus to the first or last enabled tab. Selection follows focus. |
| Click | Selects the tab. |

`ArrowUp` and `ArrowDown` do nothing because the list is horizontal.

## Dialog

A modal `role="dialog"` rendered into `document.body` through a portal. It is labelled by `title` and described by `description`.

```tsx
<Dialog open={open} onOpenChange={setOpen} title="Delete file" description="This cannot be undone.">
  <button onClick={() => setOpen(false)}>Cancel</button>
</Dialog>
```

| Prop | Type | Default | Description |
| --- | --- | --- | --- |
| `open` | `boolean` | required | Whether the dialog is shown. Nothing renders while `false`. |
| `onOpenChange` | `(open: boolean) => void` | required | Called with `false` on Escape or a backdrop click. The dialog never closes itself. |
| `title` | `ReactNode` | required | Rendered in an `h2` that names the dialog. |
| `description` | `ReactNode` | none | Rendered in a `div` that describes the dialog. Omitted from `aria-describedby` when absent. |

On open, focus moves to the first focusable element, or to the dialog if there is none. Focus is kept inside, and when the dialog closes or unmounts, focus returns to the element that had it before opening (if it is still in the document). A dialog opened inside another one traps focus and handles Escape itself, so only the topmost closes. Two dialogs that mount in the same render may give focus to the outer one; open the inner one afterwards.

| Key / pointer | Action |
| --- | --- |
| `Tab` / `Shift+Tab` | Moves through the dialog's focusable elements, wrapping at the ends. |
| `Escape` | Calls `onOpenChange(false)`. |
| Click on backdrop | Calls `onOpenChange(false)` when the press starts and ends on the backdrop. A press that starts inside the dialog or ends inside it does not close it. |

## Combobox

A text input with a `listbox` popup following the WAI-ARIA combobox pattern. Controlled only: `value` and `onChange` are required, and the value is an option's `value` or `null`.

```tsx
<Combobox label="Fruit" options={options} value={fruit} onChange={setFruit} placeholder="Search" />
```

| Prop | Type | Default | Description |
| --- | --- | --- | --- |
| `label` | `string` | required | Rendered in a `label` for the input and names the listbox. |
| `options` | `{ value: string; label: string; disabled?: boolean }[]` | required | Filtered by label, case-insensitively, as a substring match. |
| `value` | `string \| null` | required | Selected option's `value`, or `null` for none. The input shows that option's label. |
| `onChange` | `(value: string \| null) => void` | required | Called on selection. Called with `null` when the text is cleared and the input is blurred, or Enter is pressed on empty text with no active option. |

Other input props, such as `placeholder`, `className` and `data-*`, go to the `input`. Rendering `value` changes from outside replaces any typed text. The listbox shows "No results" when nothing matches.

| Key / pointer | Action |
| --- | --- |
| Typing | Opens the listbox and filters the options. |
| `ArrowDown` / `ArrowUp` | Opens the listbox if closed, then moves the active option, skipping disabled ones. Wraps at both ends. Focus stays in the input. |
| `Enter` | Selects the active option and closes. With no active option, nothing is selected. |
| `Escape` | Closes the listbox without selecting. Stops propagation while the listbox is open. |
| Click an enabled option | Selects it. Clicking a disabled option does nothing. |
| Blur | Closes the listbox and reverts the text to the selected label. |

import "@testing-library/jest-dom/vitest";
import { render, screen, within } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { Combobox, type ComboboxOption } from "./Combobox";

const fruits: ComboboxOption[] = [
  { value: "apple", label: "Apple" },
  { value: "banana", label: "Banana", disabled: true },
  { value: "cherry", label: "Cherry" },
  { value: "grape", label: "Grape" },
];

function getInput(): HTMLElement {
  return screen.getByRole("combobox", { name: "Fruit" });
}

describe("Combobox", () => {
  it("links the label, input, listbox and options with ARIA attributes", async () => {
    const user = userEvent.setup();
    render(<Combobox label="Fruit" options={fruits} />);
    const input = getInput();

    expect(input).toHaveAttribute("aria-expanded", "false");
    expect(input).toHaveAttribute("aria-autocomplete", "list");
    expect(input).not.toHaveAttribute("aria-activedescendant");
    expect(screen.queryByRole("listbox")).toBeNull();
    expect(document.getElementById(input.getAttribute("aria-controls") ?? "")).toHaveAttribute(
      "role",
      "listbox",
    );

    await user.type(input, "a");
    const listbox = screen.getByRole("listbox", { name: "Fruit" });
    expect(input).toHaveAttribute("aria-expanded", "true");
    expect(input.getAttribute("aria-controls")).toBe(listbox.id);

    const options = within(listbox).getAllByRole("option");
    expect(options.map((option) => option.textContent)).toEqual(["Apple", "Banana", "Grape"]);
    expect(new Set(options.map((option) => option.id)).size).toBe(options.length);
    expect(options[1]).toHaveAttribute("aria-disabled", "true");
    expect(options[0]).toHaveAttribute("aria-selected", "false");
  });

  it("shows the selected label and passes placeholder through", () => {
    render(<Combobox label="Fruit" options={fruits} defaultValue="cherry" placeholder="Pick one" />);
    expect(getInput()).toHaveValue("Cherry");
    expect(getInput()).toHaveAttribute("placeholder", "Pick one");
  });

  it("filters options by case-insensitive substring and treats regex characters literally", async () => {
    const user = userEvent.setup();
    render(<Combobox label="Fruit" options={fruits} />);
    const input = getInput();

    await user.type(input, "AN");
    expect(screen.getByRole("listbox")).toHaveTextContent(/^Banana$/);
    expect(screen.getAllByRole("option")).toHaveLength(1);

    await user.clear(input);
    await user.type(input, "(");
    expect(screen.queryByRole("option")).toBeNull();
    expect(screen.getByRole("status")).toHaveTextContent("No results");

    await user.clear(input);
    await user.type(input, ".*");
    expect(screen.queryByRole("option")).toBeNull();
  });

  it("shows all options for a whitespace-only query", async () => {
    const user = userEvent.setup();
    render(<Combobox label="Fruit" options={fruits} />);
    await user.type(getInput(), "   ");

    expect(screen.getAllByRole("option")).toHaveLength(4);
  });

  it("opens with ArrowDown and moves the active option, skipping disabled options and wrapping", async () => {
    const user = userEvent.setup();
    render(<Combobox label="Fruit" options={fruits} />);
    const input = getInput();
    await user.click(input);

    await user.keyboard("{ArrowDown}");
    expect(input).toHaveAttribute("aria-expanded", "true");
    expect(input).toHaveFocus();
    expect(input).toHaveAttribute("aria-activedescendant", screen.getByRole("option", { name: "Apple" }).id);

    await user.keyboard("{ArrowDown}");
    expect(input).toHaveAttribute("aria-activedescendant", screen.getByRole("option", { name: "Cherry" }).id);

    await user.keyboard("{ArrowDown}");
    expect(input).toHaveAttribute("aria-activedescendant", screen.getByRole("option", { name: "Grape" }).id);

    await user.keyboard("{ArrowDown}");
    expect(input).toHaveAttribute("aria-activedescendant", screen.getByRole("option", { name: "Apple" }).id);

    await user.keyboard("{ArrowUp}");
    expect(input).toHaveAttribute("aria-activedescendant", screen.getByRole("option", { name: "Grape" }).id);
    expect(input).toHaveFocus();
  });

  it("resets the active option to the first enabled match when the filter changes", async () => {
    const user = userEvent.setup();
    render(<Combobox label="Fruit" options={fruits} />);
    const input = getInput();
    await user.type(input, "a");
    await user.keyboard("{ArrowDown}");
    expect(input).toHaveAttribute("aria-activedescendant", screen.getByRole("option", { name: "Grape" }).id);

    await user.type(input, "p");
    expect(input).toHaveAttribute("aria-activedescendant", screen.getByRole("option", { name: "Apple" }).id);
  });

  it("selects the active option on Enter, closes the list and shows its label", async () => {
    const user = userEvent.setup();
    const onChange = vi.fn();
    render(<Combobox label="Fruit" options={fruits} onChange={onChange} />);
    const input = getInput();
    await user.type(input, "ch");
    await user.keyboard("{Enter}");

    expect(onChange).toHaveBeenCalledTimes(1);
    expect(onChange).toHaveBeenCalledWith("cherry");
    expect(input).toHaveValue("Cherry");
    expect(input).toHaveAttribute("aria-expanded", "false");
    expect(input).not.toHaveAttribute("aria-activedescendant");
  });

  it("does nothing on Enter when no option is active", async () => {
    const user = userEvent.setup();
    const onChange = vi.fn();
    render(<Combobox label="Fruit" options={fruits} onChange={onChange} />);
    await user.type(getInput(), "zz{Enter}");

    expect(onChange).not.toHaveBeenCalled();
  });

  it("selects an enabled option on click and keeps focus on the input", async () => {
    const user = userEvent.setup();
    const onChange = vi.fn();
    render(<Combobox label="Fruit" options={fruits} onChange={onChange} />);
    await user.type(getInput(), "e");
    await user.click(screen.getByRole("option", { name: "Grape" }));

    expect(onChange).toHaveBeenCalledWith("grape");
    expect(getInput()).toHaveValue("Grape");
    expect(getInput()).toHaveFocus();
  });

  it("ignores a click on a disabled option and leaves the list open", async () => {
    const user = userEvent.setup();
    const onChange = vi.fn();
    render(<Combobox label="Fruit" options={fruits} onChange={onChange} />);
    await user.type(getInput(), "an");
    await user.click(screen.getByRole("option", { name: "Banana" }));

    expect(onChange).not.toHaveBeenCalled();
    expect(screen.getByRole("listbox")).toBeVisible();
  });

  it("closes on Escape without selecting and restores the selected label", async () => {
    const user = userEvent.setup();
    const onChange = vi.fn();
    render(<Combobox label="Fruit" options={fruits} defaultValue="apple" onChange={onChange} />);
    const input = getInput();
    await user.clear(input);
    await user.type(input, "ch");
    await user.keyboard("{Escape}");

    expect(onChange).not.toHaveBeenCalled();
    expect(input).toHaveAttribute("aria-expanded", "false");
    expect(input).toHaveValue("Apple");
  });

  it("stops Escape from propagating while the list is open", async () => {
    const user = userEvent.setup();
    const onKeyDown = vi.fn();
    render(
      <div onKeyDown={onKeyDown}>
        <Combobox label="Fruit" options={fruits} />
      </div>,
    );
    await user.type(getInput(), "a");
    await user.keyboard("{Escape}");
    expect(onKeyDown).not.toHaveBeenCalledWith(expect.objectContaining({ key: "Escape" }));

    await user.keyboard("{Escape}");
    expect(onKeyDown).toHaveBeenCalledWith(expect.objectContaining({ key: "Escape" }));
  });

  it("shows No results and no active descendant when nothing matches", async () => {
    const user = userEvent.setup();
    const onChange = vi.fn();
    render(<Combobox label="Fruit" options={fruits} onChange={onChange} />);
    const input = getInput();
    await user.type(input, "zzz");

    expect(screen.getByRole("status")).toHaveTextContent("No results");
    expect(screen.queryByRole("option")).toBeNull();
    expect(input).not.toHaveAttribute("aria-activedescendant");
    await user.keyboard("{Enter}");
    expect(onChange).not.toHaveBeenCalled();
  });

  it("restores the selected label on blur without calling onChange", async () => {
    const user = userEvent.setup();
    const onChange = vi.fn();
    render(<Combobox label="Fruit" options={fruits} defaultValue="apple" onChange={onChange} />);
    await user.type(getInput(), "ch");
    await user.tab();

    expect(getInput()).toHaveValue("Apple");
    expect(getInput()).toHaveAttribute("aria-expanded", "false");
    expect(onChange).not.toHaveBeenCalled();
  });

  it("calls onChange(null) when the text is cleared and the input is blurred", async () => {
    const user = userEvent.setup();
    const onChange = vi.fn();
    render(<Combobox label="Fruit" options={fruits} defaultValue="apple" onChange={onChange} />);
    await user.clear(getInput());
    await user.tab();

    expect(onChange).toHaveBeenCalledTimes(1);
    expect(onChange).toHaveBeenCalledWith(null);
    expect(getInput()).toHaveValue("");
  });

  it("calls onChange(null) on Enter with cleared text", async () => {
    const user = userEvent.setup();
    const onChange = vi.fn();
    render(<Combobox label="Fruit" options={fruits} defaultValue="apple" onChange={onChange} />);
    await user.clear(getInput());
    await user.keyboard("{Enter}");

    expect(onChange).toHaveBeenCalledWith(null);
  });

  it("updates the input text when a controlled parent changes value", () => {
    const { rerender } = render(<Combobox label="Fruit" options={fruits} value="apple" />);
    expect(getInput()).toHaveValue("Apple");

    rerender(<Combobox label="Fruit" options={fruits} value="cherry" />);
    expect(getInput()).toHaveValue("Cherry");
  });

  it("keeps the old value when a controlled parent ignores onChange", async () => {
    const user = userEvent.setup();
    const onChange = vi.fn();
    render(<Combobox label="Fruit" options={fruits} value="apple" onChange={onChange} />);
    await user.clear(getInput());
    await user.type(getInput(), "gr{Enter}");

    expect(onChange).toHaveBeenCalledWith("grape");
    expect(getInput()).toHaveValue("Apple");
  });

  it("uses defaultValue and internal state for uncontrolled selection", async () => {
    const user = userEvent.setup();
    const onChange = vi.fn();
    render(<Combobox label="Fruit" options={fruits} defaultValue="apple" onChange={onChange} />);
    expect(getInput()).toHaveValue("Apple");

    await user.clear(getInput());
    await user.type(getInput(), "ch{Enter}");
    expect(onChange).toHaveBeenCalledWith("cherry");
    expect(getInput()).toHaveValue("Cherry");
  });

  it("treats 0 as a real value for numeric options", async () => {
    const user = userEvent.setup();
    const onChange = vi.fn();
    const numbered: ComboboxOption<number>[] = [
      { value: 0, label: "Zero" },
      { value: 1, label: "One" },
    ];
    render(<Combobox<number> label="Count" options={numbered} value={0} onChange={onChange} />);
    expect(screen.getByRole("combobox", { name: "Count" })).toHaveValue("Zero");

    await user.clear(screen.getByRole("combobox", { name: "Count" }));
    await user.type(screen.getByRole("combobox", { name: "Count" }), "on{Enter}");
    expect(onChange).toHaveBeenCalledWith(1);
  });

  it("keeps options with the same label distinct by value", async () => {
    const user = userEvent.setup();
    const duplicates: ComboboxOption[] = [
      { value: "a", label: "Same" },
      { value: "b", label: "Same" },
    ];
    render(<Combobox label="Fruit" options={duplicates} value="b" />);
    await user.click(getInput());
    await user.keyboard("{ArrowDown}");

    const options = screen.getAllByRole("option");
    expect(options[0]).toHaveAttribute("aria-selected", "false");
    expect(options[1]).toHaveAttribute("aria-selected", "true");
  });

  it("shows empty text when value is not among the options", () => {
    render(<Combobox label="Fruit" options={fruits} value="missing" />);
    expect(getInput()).toHaveValue("");
  });

  it("leaves no active option when every option is disabled", async () => {
    const user = userEvent.setup();
    const onChange = vi.fn();
    const allDisabled = fruits.map((fruit) => ({ ...fruit, disabled: true }));
    render(<Combobox label="Fruit" options={allDisabled} onChange={onChange} />);
    await user.click(getInput());
    await user.keyboard("{ArrowDown}{Enter}");

    expect(getInput()).not.toHaveAttribute("aria-activedescendant");
    expect(onChange).not.toHaveBeenCalled();
  });

  it("shows No results when open with an empty options array", async () => {
    const user = userEvent.setup();
    render(<Combobox label="Fruit" options={[]} />);
    await user.click(getInput());
    await user.keyboard("{ArrowDown}");

    expect(screen.getByRole("status")).toHaveTextContent("No results");
    expect(screen.queryByRole("option")).toBeNull();
  });

  it("keeps two instances' ids unique and their keyboard handling isolated", async () => {
    const user = userEvent.setup();
    const { container } = render(
      <>
        <Combobox label="First" options={fruits} />
        <Combobox label="Second" options={fruits} />
      </>,
    );
    const ids = Array.from(container.querySelectorAll("[id]")).map((element) => element.id);
    expect(new Set(ids).size).toBe(ids.length);

    const [first, second] = screen.getAllByRole("combobox");
    await user.type(first, "ch{Enter}");

    expect(first).toHaveValue("Cherry");
    expect(second).toHaveValue("");
    expect(second).toHaveAttribute("aria-expanded", "false");
  });
});

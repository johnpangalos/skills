# @acme/ui

Accessible React 19 components: `Tabs`, `Dialog`, `Combobox`. No CSS is shipped; style through `className` and any other HTML props, which pass through to the main element of each part.

## Run

```sh
pnpm install
pnpm test        # vitest (jsdom + Testing Library)
pnpm typecheck   # tsc --noEmit
```

## Tabs

```tsx
import { Tabs, TabList, Tab, TabPanel } from "@acme/ui";

<Tabs defaultValue="profile">
  <TabList aria-label="Account">
    <Tab value="profile">Profile</Tab>
    <Tab value="billing">Billing</Tab>
    <Tab value="security" disabled>Security</Tab>
  </TabList>
  <TabPanel value="profile">Profile settings</TabPanel>
  <TabPanel value="billing">Billing settings</TabPanel>
  <TabPanel value="security">Security settings</TabPanel>
</Tabs>;
```

Non-selected panels are rendered with the `hidden` attribute, so every panel stays in the DOM and `aria-controls` always resolves. Tabs are roving-tabindex: only the selected enabled tab has `tabIndex=0`. If the value names no enabled tab, the first enabled tab gets `tabIndex=0`. With no `value` or `defaultValue`, the first enabled tab is selected.

With a controlled `value` and a parent that ignores `onValueChange`, arrow keys and `Home`/`End` still move focus to the other tab, but the selection and `tabIndex=0` stay on the selected tab. `onValueChange` is still called for each focus move.

### Tabs props

| Name | Type | Default | Description |
| --- | --- | --- | --- |
| `value` | `string` | none | Controlled selected tab value. Selection changes only when the parent updates it. |
| `defaultValue` | `string` | first enabled tab | Initial value when uncontrolled. |
| `onValueChange` | `(value: string) => void` | none | Called when the user selects a tab (by focus, arrow key or click), in controlled and uncontrolled mode. |
| `...rest` | `HTMLAttributes<HTMLDivElement>` | | Passed to the root `div`. |

### TabList props

| Name | Type | Default | Description |
| --- | --- | --- | --- |
| `aria-label` | `string` | required | Accessible name of the `tablist`. |
| `...rest` | `HTMLAttributes<HTMLDivElement>` | | Passed to the `div role="tablist"`. `aria-orientation` is always `horizontal`. |

### Tab props

| Name | Type | Default | Description |
| --- | --- | --- | --- |
| `value` | `string` | required | Identifies the tab and its panel. |
| `disabled` | `boolean` | `false` | Sets `aria-disabled="true"`. Disabled tabs cannot be selected and are skipped by arrow keys. |
| `...rest` | `ButtonHTMLAttributes<HTMLButtonElement>` | | Passed to the `button type="button" role="tab"`. |

### TabPanel props

| Name | Type | Default | Description |
| --- | --- | --- | --- |
| `value` | `string` | required | Matches the `Tab` with the same value. |
| `...rest` | `HTMLAttributes<HTMLDivElement>` | | Passed to the `div role="tabpanel"`, which has `tabIndex=0`. |

### Tabs keyboard

| Key | Action |
| --- | --- |
| `Tab` | Moves into the tablist on the selected tab; the next `Tab` leaves it for the panel. |
| `ArrowRight` / `ArrowLeft` | Focus and select the next / previous enabled tab. Wraps at both ends. Starts from the focused tab even if it is disabled. |
| `Home` / `End` | Focus and select the first / last enabled tab. |

Other keys do nothing. If every tab is disabled, none is reachable by keyboard.

## Dialog

```tsx
import { Dialog } from "@acme/ui";

const [open, setOpen] = useState(false);

<Dialog open={open} onOpenChange={setOpen} title="Delete project" description="This cannot be undone.">
  <button type="button" onClick={() => setOpen(false)}>Cancel</button>
</Dialog>;
```

Renders nothing when `open` is false. When open, it portals into `document.body` a `div[data-backdrop]` and the `div role="dialog" aria-modal="true"` content element. The dialog is controlled only: it closes only when the parent sets `open` to false in response to `onOpenChange`. There is no body scroll lock.

### Dialog props

| Name | Type | Default | Description |
| --- | --- | --- | --- |
| `open` | `boolean` | required | Whether the dialog is shown. |
| `onOpenChange` | `(open: boolean) => void` | required | Called with `false` on Escape or a backdrop click. |
| `title` | `string` | required | Rendered as an `h2` and used as the dialog's accessible name. |
| `description` | `string` | none | Rendered as a `p`. When omitted, the dialog has no `aria-describedby`. |
| `...rest` | `HTMLAttributes<HTMLDivElement>` | | Passed to the content element. `tabIndex` is always `-1`. |

### Dialog behavior

- On open, focus moves to the first focusable element in the content, or to the content element if there is none.
- Tab and Shift+Tab wrap inside the dialog. Disabled, `tabindex="-1"`, `hidden` and `type="hidden"` elements are skipped. The focusable set is read at keypress time.
- Focus that moves outside the dialog, for example to an element behind the backdrop, is pulled back to the first focusable element. If focus is lost to `body`, Tab enters the dialog and Escape still closes it.
- On close or unmount, focus returns to the element focused before opening, if it is still in the document.
- Nested dialogs: Escape closes only the innermost dialog, because its handler stops propagation.

### Dialog keyboard

| Key | Action |
| --- | --- |
| `Tab` / `Shift+Tab` | Move focus within the dialog, wrapping at the ends. |
| `Escape` | Calls `onOpenChange(false)`. |

A click on the backdrop calls `onOpenChange(false)`. A click inside the content does not. A drag that starts inside the content and ends on the backdrop does not, because the browser's click target is their common ancestor. Pressing the mouse on the backdrop does not move focus, so a backdrop click leaves focus inside the dialog even when the parent ignores `onOpenChange`.

## Combobox

```tsx
import { Combobox } from "@acme/ui";

const [fruit, setFruit] = useState<string | null>(null);

<Combobox
  label="Fruit"
  placeholder="Type to search"
  options={[
    { value: "apple", label: "Apple" },
    { value: "pear", label: "Pear", disabled: true },
  ]}
  value={fruit}
  onChange={setFruit}
/>;
```

The component is controlled for `value`: the input shows the selected option's label, or is empty when `value` is `null` or matches no option. Renders a visible `label`, the `input role="combobox"`, a `ul role="listbox"` (hidden while closed) and a `role="status"` region that shows "No results".

### Combobox props

| Name | Type | Default | Description |
| --- | --- | --- | --- |
| `label` | `string` | required | Visible label, associated with the input and used as the listbox name. |
| `options` | `ComboboxOption[]` | required | `{ value: string; label: string; disabled?: boolean }`. Values must be unique. |
| `value` | `string \| null` | required | Selected option value. |
| `onChange` | `(value: string \| null) => void` | required | Called with the chosen option's value, or `null` when the text is cleared and committed. |
| `placeholder` | `string` | none | Passed to the input. |
| `...rest` | `InputHTMLAttributes<HTMLInputElement>` | | Passed to the input. |

Filtering is a case-insensitive substring match on `label`. Typing opens the listbox. Clicking the input also opens it. Active option state resets whenever the text changes.

### Combobox keyboard

| Key | Action |
| --- | --- |
| `ArrowDown` / `ArrowUp` | Opens the listbox if closed, then moves the active option to the next / previous enabled option. Wraps at both ends. Disabled options are skipped. |
| `Enter` | With an active option: selects it, closes the listbox, and shows its label. With no active option and cleared text: calls `onChange(null)`. Otherwise does nothing. |
| `Escape` | Closes the listbox without calling `onChange` and restores the selected label. Does nothing when the listbox is already closed. Stops propagation only while the listbox is open. |
| `Tab` / blur | Closes the listbox and restores the selected label. If the text was cleared, calls `onChange(null)` first. |

Clicking an enabled option selects it. Clicking a disabled option does nothing. Options use `onMouseDown` `preventDefault` so the input keeps focus until the click lands.

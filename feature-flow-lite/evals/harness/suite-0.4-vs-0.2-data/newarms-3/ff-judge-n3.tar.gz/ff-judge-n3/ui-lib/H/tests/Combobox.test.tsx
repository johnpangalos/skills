import { useState } from "react";
import { describe, expect, it, vi } from "vitest";
import { fireEvent, render, screen, within } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { Combobox, type ComboboxOption } from "../src/Combobox";

const fruits: ComboboxOption[] = [
  { value: "apple", label: "Apple" },
  { value: "banana", label: "Banana" },
  { value: "cherry", label: "Cherry", disabled: true },
  { value: "grape", label: "Grape" },
];

function Controlled({
  onChange,
  options = fruits,
  initial = null,
}: {
  onChange?: (value: string | null) => void;
  options?: ComboboxOption[];
  initial?: string | null;
}) {
  const [value, setValue] = useState<string | null>(initial);
  return (
    <>
      <Combobox
        label="Fruit"
        options={options}
        value={value}
        onChange={(next) => {
          onChange?.(next);
          setValue(next);
        }}
      />
      <button type="button">After</button>
    </>
  );
}

const input = () => screen.getByRole("combobox", { name: "Fruit" });
const optionId = (label: string) => screen.getByRole("option", { name: label }).id;
const activeOption = () => input().getAttribute("aria-activedescendant");

describe("Combobox", () => {
  describe("structure (C1)", () => {
    it("renders a label, a combobox input and a listbox of options", () => {
      render(<Combobox label="Fruit" options={fruits} value="banana" onChange={() => {}} />);
      const field = input();
      expect(field.tagName).toBe("INPUT");
      expect(field).toHaveAttribute("aria-autocomplete", "list");
      expect(field).toHaveAttribute("aria-expanded", "false");
      expect(screen.getByLabelText("Fruit", { selector: "input" })).toBe(field);
      const listbox = document.getElementById(field.getAttribute("aria-controls") ?? "");
      expect(listbox).toHaveAttribute("role", "listbox");
      expect(document.getElementById(listbox?.getAttribute("aria-labelledby") ?? "")).toHaveTextContent("Fruit");
      expect(listbox).toHaveAttribute("hidden");
      expect(within(listbox as HTMLElement).getAllByRole("option", { hidden: true })).toHaveLength(4);
    });

    it("marks only the option matching value as selected and disabled options as aria-disabled", () => {
      render(<Combobox label="Fruit" options={fruits} value="banana" onChange={() => {}} />);
      expect(screen.getByRole("option", { name: "Banana", hidden: true })).toHaveAttribute("aria-selected", "true");
      expect(screen.getByRole("option", { name: "Apple", hidden: true })).toHaveAttribute("aria-selected", "false");
      expect(screen.getByRole("option", { name: "Cherry", hidden: true })).toHaveAttribute("aria-disabled", "true");
    });

    it("passes placeholder to the input", () => {
      render(<Combobox label="Fruit" options={fruits} value={null} placeholder="Pick one" onChange={() => {}} />);
      expect(input()).toHaveAttribute("placeholder", "Pick one");
    });
  });

  describe("displayed value (C2)", () => {
    it("shows the label of the option matching value", () => {
      render(<Combobox label="Fruit" options={fruits} value="banana" onChange={() => {}} />);
      expect(input()).toHaveValue("Banana");
    });

    it("shows an empty string when value is null or matches nothing", () => {
      const { rerender } = render(<Combobox label="Fruit" options={fruits} value={null} onChange={() => {}} />);
      expect(input()).toHaveValue("");
      rerender(<Combobox label="Fruit" options={fruits} value="zzz" onChange={() => {}} />);
      expect(input()).toHaveValue("");
    });

    it("updates when value changes from outside", () => {
      const { rerender } = render(<Combobox label="Fruit" options={fruits} value="apple" onChange={() => {}} />);
      rerender(<Combobox label="Fruit" options={fruits} value="grape" onChange={() => {}} />);
      expect(input()).toHaveValue("Grape");
    });
  });

  describe("filtering and opening (C3)", () => {
    it("typing opens the listbox and shows case-insensitive substring matches", async () => {
      const user = userEvent.setup();
      render(<Controlled />);
      await user.type(input(), "AN");
      expect(input()).toHaveAttribute("aria-expanded", "true");
      const listbox = screen.getByRole("listbox");
      expect(within(listbox).getAllByRole("option").map((option) => option.textContent)).toEqual(["Banana"]);
    });

    it("ArrowDown without typing shows all options even when the selected label is shown", async () => {
      const user = userEvent.setup();
      render(<Controlled initial="banana" />);
      await user.click(input());
      await user.keyboard("{ArrowDown}");
      expect(within(screen.getByRole("listbox")).getAllByRole("option")).toHaveLength(4);
    });

    it("treats regex characters in the typed text literally", async () => {
      const user = userEvent.setup();
      render(<Controlled />);
      await user.type(input(), "(.");
      expect(screen.queryAllByRole("option")).toHaveLength(0);
      expect(screen.getByRole("status")).toHaveTextContent("No results");
    });
  });

  describe("active option (C4)", () => {
    const trio: ComboboxOption[] = [
      { value: "apple", label: "Apple" },
      { value: "banana", label: "Banana" },
      { value: "grape", label: "Grape" },
    ];

    it("drops the active option when the options shrink, and Enter does not throw", async () => {
      const user = userEvent.setup();
      const onChange = vi.fn();
      const { rerender } = render(<Combobox label="Fruit" options={trio} value={null} onChange={onChange} />);
      await user.click(input());
      await user.keyboard("{ArrowDown}{ArrowDown}{ArrowDown}");
      expect(activeOption()).toBe(optionId("Grape"));
      rerender(<Combobox label="Fruit" options={trio.slice(0, 1)} value={null} onChange={onChange} />);
      expect(activeOption()).toBeNull();
      await user.keyboard("{Enter}");
      expect(onChange).not.toHaveBeenCalled();
    });

    it("drops the active option when it becomes disabled, and Enter does not select it", async () => {
      const user = userEvent.setup();
      const onChange = vi.fn();
      const { rerender } = render(<Combobox label="Fruit" options={trio} value={null} onChange={onChange} />);
      await user.click(input());
      await user.keyboard("{ArrowDown}{ArrowDown}");
      expect(activeOption()).toBe(optionId("Banana"));
      const disabledBanana = trio.map((option) => (option.value === "banana" ? { ...option, disabled: true } : option));
      rerender(<Combobox label="Fruit" options={disabledBanana} value={null} onChange={onChange} />);
      expect(activeOption()).toBeNull();
      await user.keyboard("{Enter}");
      expect(onChange).not.toHaveBeenCalled();
    });

    it("ArrowDown when closed opens the listbox and activates the first enabled option", async () => {
      const user = userEvent.setup();
      render(<Controlled />);
      await user.click(input());
      await user.keyboard("{ArrowDown}");
      expect(input()).toHaveAttribute("aria-expanded", "true");
      expect(activeOption()).toBe(optionId("Apple"));
    });

    it("ArrowUp when closed opens the listbox and activates the last enabled option", async () => {
      const user = userEvent.setup();
      render(<Controlled />);
      await user.click(input());
      await user.keyboard("{ArrowUp}");
      expect(activeOption()).toBe(optionId("Grape"));
    });

    it("moves the active option through enabled options, skipping disabled ones and wrapping", async () => {
      const user = userEvent.setup();
      render(<Controlled />);
      await user.click(input());
      await user.keyboard("{ArrowDown}");
      expect(activeOption()).toBe(optionId("Apple"));
      await user.keyboard("{ArrowDown}");
      expect(activeOption()).toBe(optionId("Banana"));
      await user.keyboard("{ArrowDown}");
      expect(activeOption()).toBe(optionId("Grape"));
      await user.keyboard("{ArrowDown}");
      expect(activeOption()).toBe(optionId("Apple"));
      await user.keyboard("{ArrowUp}");
      expect(activeOption()).toBe(optionId("Grape"));
    });

    it("keeps focus on the input while the active option changes", async () => {
      const user = userEvent.setup();
      render(<Controlled />);
      await user.click(input());
      await user.keyboard("{ArrowDown}{ArrowDown}");
      expect(input()).toHaveFocus();
    });

    it("has no aria-activedescendant until an arrow key activates an option", async () => {
      const user = userEvent.setup();
      render(<Controlled />);
      await user.click(input());
      expect(input()).not.toHaveAttribute("aria-activedescendant");
      await user.type(input(), "a");
      expect(input()).not.toHaveAttribute("aria-activedescendant");
    });

    it("leaves nothing active and does not throw when every visible option is disabled", async () => {
      const user = userEvent.setup();
      render(<Controlled options={[{ value: "x", label: "X", disabled: true }]} />);
      await user.click(input());
      await user.keyboard("{ArrowDown}{ArrowUp}");
      expect(input()).not.toHaveAttribute("aria-activedescendant");
    });

    it("calls preventDefault on arrow keys", () => {
      render(<Controlled />);
      expect(fireEvent.keyDown(input(), { key: "ArrowDown" })).toBe(false);
      expect(fireEvent.keyDown(input(), { key: "ArrowUp" })).toBe(false);
    });
  });

  describe("selecting (C5)", () => {
    it("Enter with an active option selects it, closes the listbox and shows its label", async () => {
      const user = userEvent.setup();
      const onChange = vi.fn();
      render(<Controlled onChange={onChange} />);
      await user.click(input());
      await user.keyboard("{ArrowDown}{ArrowDown}{Enter}");
      expect(onChange).toHaveBeenCalledTimes(1);
      expect(onChange).toHaveBeenCalledWith("banana");
      expect(input()).toHaveAttribute("aria-expanded", "false");
      expect(input()).toHaveValue("Banana");
    });

    it("Enter while closed does not select and does not preventDefault", async () => {
      const user = userEvent.setup();
      const onChange = vi.fn();
      render(<Controlled onChange={onChange} />);
      await user.click(input());
      expect(fireEvent.keyDown(input(), { key: "Enter" })).toBe(true);
      expect(onChange).not.toHaveBeenCalled();
    });

    it("Enter while open with no active option does not select and does not preventDefault", async () => {
      const user = userEvent.setup();
      const onChange = vi.fn();
      render(<Controlled onChange={onChange} />);
      await user.type(input(), "ap");
      expect(fireEvent.keyDown(input(), { key: "Enter" })).toBe(true);
      expect(onChange).not.toHaveBeenCalled();
      expect(input()).toHaveAttribute("aria-expanded", "true");
    });

    it("clicking an enabled option selects it and keeps focus on the input", async () => {
      const user = userEvent.setup();
      const onChange = vi.fn();
      render(<Controlled onChange={onChange} />);
      await user.click(input());
      await user.keyboard("{ArrowDown}");
      expect(fireEvent.mouseDown(screen.getByRole("option", { name: "Grape" }))).toBe(false);
      await user.click(screen.getByRole("option", { name: "Grape" }));
      expect(onChange).toHaveBeenCalledWith("grape");
      expect(input()).toHaveValue("Grape");
    });

    it("clicking a disabled option does nothing and keeps the listbox open", async () => {
      const user = userEvent.setup();
      const onChange = vi.fn();
      render(<Controlled onChange={onChange} />);
      await user.click(input());
      await user.keyboard("{ArrowDown}");
      await user.click(screen.getByRole("option", { name: "Cherry" }));
      expect(onChange).not.toHaveBeenCalled();
      expect(input()).toHaveAttribute("aria-expanded", "true");
    });
  });

  describe("escape, blur and tab (C6)", () => {
    it("Escape while open closes without selecting and restores the label", async () => {
      const user = userEvent.setup();
      const onChange = vi.fn();
      render(<Controlled initial="banana" onChange={onChange} />);
      await user.type(input(), "zz");
      expect(fireEvent.keyDown(input(), { key: "Escape" })).toBe(false);
      expect(input()).toHaveAttribute("aria-expanded", "false");
      expect(input()).toHaveValue("Banana");
      expect(onChange).not.toHaveBeenCalled();
    });

    it("Escape while open stops the event from reaching ancestors", async () => {
      const user = userEvent.setup();
      const ancestorKeyDown = vi.fn();
      render(
        <div onKeyDown={ancestorKeyDown}>
          <Controlled />
        </div>,
      );
      await user.type(input(), "a");
      ancestorKeyDown.mockClear();
      fireEvent.keyDown(input(), { key: "Escape" });
      expect(ancestorKeyDown).not.toHaveBeenCalled();
    });

    it("Escape while closed does nothing and lets the event propagate", () => {
      const ancestorKeyDown = vi.fn();
      render(
        <div onKeyDown={ancestorKeyDown}>
          <Controlled />
        </div>,
      );
      expect(fireEvent.keyDown(input(), { key: "Escape" })).toBe(true);
      expect(ancestorKeyDown).toHaveBeenCalledTimes(1);
    });

    it("Tab closes the listbox without selecting, restores the label and does not prevent Tab", async () => {
      const user = userEvent.setup();
      const onChange = vi.fn();
      render(<Controlled initial="banana" onChange={onChange} />);
      await user.type(input(), "zz");
      expect(fireEvent.keyDown(input(), { key: "Tab" })).toBe(true);
      await user.tab();
      expect(screen.getByRole("button", { name: "After" })).toHaveFocus();
      expect(input()).toHaveAttribute("aria-expanded", "false");
      expect(input()).toHaveValue("Banana");
      expect(onChange).not.toHaveBeenCalled();
    });
  });

  describe("no results (C7)", () => {
    it("shows 'No results' with no options while open and nothing matches", async () => {
      const user = userEvent.setup();
      render(<Controlled />);
      await user.type(input(), "zz");
      expect(screen.getByRole("status").textContent).toBe("No results");
      expect(within(screen.getByRole("listbox")).queryAllByRole("option")).toHaveLength(0);
    });

    it("hides 'No results' when closed or when there are matches", async () => {
      const user = userEvent.setup();
      render(<Controlled />);
      expect(screen.queryByRole("status")).toBeNull();
      await user.type(input(), "an");
      expect(screen.queryByRole("status")).toBeNull();
    });

    it("shows 'No results' for an empty options array after ArrowDown without throwing", async () => {
      const user = userEvent.setup();
      render(<Controlled options={[]} />);
      await user.click(input());
      await user.keyboard("{ArrowDown}");
      expect(screen.getByRole("status").textContent).toBe("No results");
    });
  });

  describe("clearing (C8)", () => {
    it("clearing the text calls onChange(null)", async () => {
      const user = userEvent.setup();
      const onChange = vi.fn();
      render(<Controlled initial="banana" onChange={onChange} />);
      await user.clear(input());
      expect(onChange).toHaveBeenCalledWith(null);
    });

    it("reverts to the value's label once closed when the parent ignores onChange", async () => {
      const user = userEvent.setup();
      const onChange = vi.fn();
      render(
        <>
          <Combobox label="Fruit" options={fruits} value="banana" onChange={onChange} />
          <button type="button">After</button>
        </>,
      );
      await user.clear(input());
      expect(onChange).toHaveBeenCalledWith(null);
      expect(input()).toHaveValue("");
      await user.tab();
      expect(input()).toHaveValue("Banana");
    });
  });

  describe("multiple instances (C9)", () => {
    it("gives two comboboxes distinct input, listbox and option ids", () => {
      render(
        <>
          <Combobox label="First" options={fruits} value={null} onChange={() => {}} />
          <Combobox label="Second" options={fruits} value={null} onChange={() => {}} />
        </>,
      );
      const [first, second] = screen.getAllByRole("combobox", { hidden: true });
      expect(first.id).not.toBe(second.id);
      const ids = Array.from(document.querySelectorAll("[id]"), (element) => element.id);
      expect(new Set(ids).size).toBe(ids.length);
      // per instance: label, input, listbox and 4 options
      expect(ids).toHaveLength(14);
    });
  });
});

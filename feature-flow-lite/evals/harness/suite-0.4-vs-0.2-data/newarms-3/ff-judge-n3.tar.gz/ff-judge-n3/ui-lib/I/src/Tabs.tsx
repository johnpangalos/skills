import {
  createContext,
  useCallback,
  useContext,
  useId,
  useLayoutEffect,
  useRef,
  useState,
  type ComponentPropsWithoutRef,
  type KeyboardEvent,
} from "react";

type TabsContextValue = {
  baseId: string;
  selected: string | undefined;
  select: (value: string) => void;
  selectInitial: (value: string) => void;
  // The one tab that is in the tab order: the selected tab if it is enabled, otherwise the first enabled tab.
  stop: string | undefined;
  setStop: (value: string | undefined) => void;
  // Called by a Tab when it mounts, unmounts or changes, so the tab stop is recomputed.
  refresh: () => void;
};

const TabsContext = createContext<TabsContextValue | null>(null);

function useTabsContext(): TabsContextValue {
  const context = useContext(TabsContext);
  if (context === null) {
    throw new Error("Tab, TabList and TabPanel must be rendered inside Tabs");
  }
  return context;
}

// Values are encoded so any string (spaces, quotes, colons) yields a valid id and a single aria-controls token.
function tabId(baseId: string, value: string): string {
  return `${baseId}-tab-${encodeURIComponent(value)}`;
}

function panelId(baseId: string, value: string): string {
  return `${baseId}-panel-${encodeURIComponent(value)}`;
}

// Read from the DOM so the order always matches what is rendered, even after conditional rendering or reordering.
function enabledTabs(list: HTMLElement): HTMLElement[] {
  return Array.from(list.querySelectorAll<HTMLElement>('[role="tab"]:not(:disabled)'));
}

export type TabsProps = Omit<ComponentPropsWithoutRef<"div">, "defaultValue"> & {
  defaultValue?: string;
  value?: string;
  onValueChange?: (value: string) => void;
};

export function Tabs({ defaultValue, value, onValueChange, children, ...rest }: TabsProps) {
  const baseId = useId();
  const [uncontrolled, setUncontrolled] = useState(defaultValue);
  const [stop, setStop] = useState<string>();
  const [, setVersion] = useState(0);
  // Re-rendering Tabs also re-renders TabList through context, so its layout effect re-reads the DOM.
  const refresh = useCallback(() => setVersion((version) => version + 1), []);
  const isControlled = value !== undefined;
  const selected = isControlled ? value : uncontrolled;

  function select(next: string) {
    if (next === selected) return;
    if (!isControlled) setUncontrolled(next);
    onValueChange?.(next);
  }

  return (
    <TabsContext.Provider
      value={{ baseId, selected, select, selectInitial: setUncontrolled, stop, setStop, refresh }}
    >
      <div {...rest}>{children}</div>
    </TabsContext.Provider>
  );
}

export type TabListProps = Omit<ComponentPropsWithoutRef<"div">, "onKeyDown"> & {
  "aria-label": string;
};

export function TabList({ children, ...rest }: TabListProps) {
  const { selected, select, selectInitial, setStop } = useTabsContext();
  const listRef = useRef<HTMLDivElement>(null);

  // Runs after every render so the tab stop follows removals, disabling and reordering.
  useLayoutEffect(() => {
    const list = listRef.current;
    if (list === null) return;
    const tabs = enabledTabs(list);
    const first = tabs[0]?.dataset.value;
    const selectedIsEnabled = tabs.some((tab) => tab.dataset.value === selected);
    setStop(selectedIsEnabled ? selected : first);
    // The implicit first selection is not a user change, so it doesn't call onValueChange.
    if (selected === undefined && first !== undefined) selectInitial(first);
  });

  function handleKeyDown(event: KeyboardEvent<HTMLDivElement>) {
    const tabs = enabledTabs(event.currentTarget);
    const index = tabs.indexOf(event.target as HTMLElement);
    if (index === -1) return;
    const last = tabs.length - 1;
    let next: number;
    switch (event.key) {
      case "ArrowRight":
        next = index === last ? 0 : index + 1;
        break;
      case "ArrowLeft":
        next = index === 0 ? last : index - 1;
        break;
      case "Home":
        next = 0;
        break;
      case "End":
        next = last;
        break;
      default:
        return;
    }
    event.preventDefault();
    const tab = tabs[next];
    tab.focus();
    const value = tab.dataset.value;
    if (value !== undefined) select(value);
  }

  return (
    <div
      {...rest}
      ref={listRef}
      role="tablist"
      aria-orientation="horizontal"
      onKeyDown={handleKeyDown}
    >
      {children}
    </div>
  );
}

export type TabProps = Omit<ComponentPropsWithoutRef<"button">, "value" | "onClick"> & {
  value: string;
};

export function Tab({ value, disabled, children, ...rest }: TabProps) {
  const { baseId, selected, select, stop, refresh } = useTabsContext();
  const isSelected = selected === value;

  // A Tab that is removed or disabled inside a stateful child does not re-render TabList, so it reports itself.
  useLayoutEffect(() => {
    refresh();
    return () => refresh();
  }, [value, disabled, refresh]);

  return (
    <button
      {...rest}
      type="button"
      role="tab"
      id={tabId(baseId, value)}
      data-value={value}
      aria-selected={isSelected}
      aria-controls={panelId(baseId, value)}
      tabIndex={value === stop ? 0 : -1}
      disabled={disabled}
      onClick={() => select(value)}
    >
      {children}
    </button>
  );
}

export type TabPanelProps = ComponentPropsWithoutRef<"div"> & {
  value: string;
};

export function TabPanel({ value, children, ...rest }: TabPanelProps) {
  const { baseId, selected } = useTabsContext();

  return (
    <div
      {...rest}
      role="tabpanel"
      id={panelId(baseId, value)}
      aria-labelledby={tabId(baseId, value)}
      tabIndex={0}
      hidden={selected !== value}
    >
      {children}
    </div>
  );
}

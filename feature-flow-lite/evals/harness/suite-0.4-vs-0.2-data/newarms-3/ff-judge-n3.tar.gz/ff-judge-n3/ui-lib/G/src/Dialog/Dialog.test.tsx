import "@testing-library/jest-dom/vitest";
import { render, screen } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { useState, type ReactNode } from "react";
import { Combobox } from "../Combobox/Combobox";
import { Dialog, type DialogProps } from "./Dialog";

type PageProps = {
  open: boolean;
  onOpenChange?: (open: boolean) => void;
  description?: DialogProps["description"];
  children?: ReactNode;
};

function Page({ open, onOpenChange = vi.fn(), description, children }: PageProps) {
  return (
    <>
      <button type="button">Outside</button>
      <Dialog open={open} onOpenChange={onOpenChange} title="Confirm" description={description}>
        {children ?? (
          <>
            <input aria-label="Name" />
            <button type="button">Save</button>
          </>
        )}
      </Dialog>
    </>
  );
}

function Stateful() {
  const [open, setOpen] = useState(false);
  return (
    <>
      <button type="button" onClick={() => setOpen(true)}>
        Open
      </button>
      <Dialog open={open} onOpenChange={setOpen} title="Confirm">
        <input aria-label="Name" />
      </Dialog>
    </>
  );
}

function Mountable({ show }: { show: boolean }) {
  return (
    <>
      <button type="button">Outside</button>
      {show && (
        <Dialog open onOpenChange={vi.fn()} title="Confirm">
          <input aria-label="Name" />
        </Dialog>
      )}
    </>
  );
}

function getBackdrop(): HTMLElement {
  const backdrop = document.querySelector<HTMLElement>("[data-backdrop]");
  if (!backdrop) throw new Error("backdrop not rendered");
  return backdrop;
}

function Nested({ onOuterChange = vi.fn() }: { onOuterChange?: (open: boolean) => void }) {
  const [innerOpen, setInnerOpen] = useState(false);
  return (
    <Dialog open onOpenChange={onOuterChange} title="Outer">
      <button type="button" onClick={() => setInnerOpen(true)}>
        Open inner
      </button>
      <Dialog open={innerOpen} onOpenChange={setInnerOpen} title="Inner">
        <input aria-label="Inner name" />
        <button type="button">Inner save</button>
      </Dialog>
    </Dialog>
  );
}

function NestedOpenAtMount({
  innerOpen,
  onOuterChange,
  onInnerChange,
}: {
  innerOpen: boolean;
  onOuterChange: (open: boolean) => void;
  onInnerChange: (open: boolean) => void;
}) {
  return (
    <Dialog open onOpenChange={onOuterChange} title="Outer">
      <button type="button">ob</button>
      <button type="button">o2</button>
      <Dialog open={innerOpen} onOpenChange={onInnerChange} title="Inner">
        <button type="button">i1</button>
      </Dialog>
    </Dialog>
  );
}

describe("Dialog", () => {
  it("renders nothing while closed", () => {
    render(<Page open={false} />);
    expect(screen.queryByRole("dialog")).toBeNull();
    expect(document.querySelector("[data-backdrop]")).toBeNull();
  });

  it("renders a backdrop and a modal dialog labelled by its title in a portal on document.body", () => {
    const { container } = render(<Page open description="This cannot be undone." />);
    const dialog = screen.getByRole("dialog", { name: "Confirm" });

    expect(container.querySelector("[role='dialog']")).toBeNull();
    expect(getBackdrop()).toContainElement(dialog);
    expect(getBackdrop().parentElement).toBe(document.body);
    expect(dialog).toHaveAttribute("aria-modal", "true");
    expect(screen.getByRole("heading", { name: "Confirm" })).toBeInTheDocument();
    expect(dialog).toHaveAttribute("aria-describedby", screen.getByText("This cannot be undone.").id);
  });

  it("omits aria-describedby when no description is given", () => {
    render(<Page open />);
    expect(screen.getByRole("dialog")).not.toHaveAttribute("aria-describedby");
  });

  it("moves focus to the first tabbable element on open", () => {
    render(<Page open />);
    expect(screen.getByRole("textbox", { name: "Name" })).toHaveFocus();
  });

  it("moves focus to the dialog container when nothing inside is tabbable", () => {
    render(
      <Page open>
        <p>Just text</p>
      </Page>,
    );
    expect(screen.getByRole("dialog")).toHaveFocus();
  });

  it("wraps Tab from the last tabbable to the first and Shift+Tab from the first to the last", async () => {
    const user = userEvent.setup();
    render(<Page open />);
    const name = screen.getByRole("textbox", { name: "Name" });
    const save = screen.getByRole("button", { name: "Save" });

    await user.tab();
    expect(save).toHaveFocus();
    await user.tab();
    expect(name).toHaveFocus();
    await user.tab({ shift: true });
    expect(save).toHaveFocus();
  });

  it("skips disabled elements, tabindex=-1 elements and hidden inputs when trapping focus", async () => {
    const user = userEvent.setup();
    render(
      <Page open>
        <button type="button" disabled>
          Off
        </button>
        <button type="button" tabIndex={-1}>
          Skip
        </button>
        <input type="hidden" name="token" />
        <input aria-label="Name" />
        <button type="button">Save</button>
      </Page>,
    );

    await user.tab();
    expect(screen.getByRole("button", { name: "Save" })).toHaveFocus();
    await user.tab();
    expect(screen.getByRole("textbox", { name: "Name" })).toHaveFocus();
  });

  it("keeps focus on the dialog when there are no tabbable elements", async () => {
    const user = userEvent.setup();
    render(
      <Page open>
        <p>Just text</p>
      </Page>,
    );
    await user.tab();
    expect(screen.getByRole("dialog")).toHaveFocus();
    await user.tab({ shift: true });
    expect(screen.getByRole("dialog")).toHaveFocus();
  });

  it("calls onOpenChange(false) on Escape", async () => {
    const user = userEvent.setup();
    const onOpenChange = vi.fn();
    render(<Page open onOpenChange={onOpenChange} />);
    await user.keyboard("{Escape}");

    expect(onOpenChange).toHaveBeenCalledTimes(1);
    expect(onOpenChange).toHaveBeenCalledWith(false);
  });

  it("calls onOpenChange(false) on a backdrop click but not on a click inside the content", async () => {
    const user = userEvent.setup();
    const onOpenChange = vi.fn();
    render(<Page open onOpenChange={onOpenChange} />);

    await user.click(screen.getByRole("dialog"));
    expect(onOpenChange).not.toHaveBeenCalled();

    await user.click(getBackdrop());
    expect(onOpenChange).toHaveBeenCalledTimes(1);
    expect(onOpenChange).toHaveBeenCalledWith(false);
  });

  it("does not close when a press starts inside the content and ends on the backdrop", async () => {
    const user = userEvent.setup();
    const onOpenChange = vi.fn();
    render(<Page open onOpenChange={onOpenChange} />);

    await user.pointer([
      { keys: "[MouseLeft>]", target: screen.getByRole("textbox", { name: "Name" }) },
      { target: getBackdrop() },
      { keys: "[/MouseLeft]", target: getBackdrop() },
    ]);
    expect(onOpenChange).not.toHaveBeenCalled();
  });

  it("closes only the nested combobox on Escape, not the dialog", async () => {
    const user = userEvent.setup();
    const onOpenChange = vi.fn();
    render(
      <Page open onOpenChange={onOpenChange}>
        <Combobox label="Fruit" options={[{ value: "apple", label: "Apple" }]} />
      </Page>,
    );
    await user.type(screen.getByRole("combobox", { name: "Fruit" }), "a");
    expect(screen.getByRole("listbox", { name: "Fruit" })).toBeVisible();

    await user.keyboard("{Escape}");
    expect(screen.getByRole("combobox", { name: "Fruit" })).toHaveAttribute("aria-expanded", "false");
    expect(onOpenChange).not.toHaveBeenCalled();

    await user.keyboard("{Escape}");
    expect(onOpenChange).toHaveBeenCalledWith(false);
  });

  it("returns focus to the previously focused element when closed", async () => {
    const user = userEvent.setup();
    render(<Stateful />);
    await user.click(screen.getByRole("button", { name: "Open" }));
    expect(screen.getByRole("textbox", { name: "Name" })).toHaveFocus();

    await user.keyboard("{Escape}");
    expect(screen.queryByRole("dialog")).toBeNull();
    expect(screen.getByRole("button", { name: "Open" })).toHaveFocus();
  });

  it("returns focus to the previously focused element when unmounted while open", () => {
    const { rerender } = render(<Mountable show={false} />);
    const outside = screen.getByRole("button", { name: "Outside" });
    outside.focus();

    rerender(<Mountable show />);
    expect(screen.getByRole("textbox", { name: "Name" })).toHaveFocus();

    rerender(<Mountable show={false} />);
    expect(outside).toHaveFocus();
  });

  it("restores focus correctly when opened and closed rapidly", async () => {
    const user = userEvent.setup();
    render(<Stateful />);
    const open = screen.getByRole("button", { name: "Open" });

    for (let round = 0; round < 3; round++) {
      await user.click(open);
      await user.keyboard("{Escape}");
    }
    expect(open).toHaveFocus();
    expect(screen.queryByRole("dialog")).toBeNull();
  });

  it("includes tabbables added after open when trapping focus", async () => {
    const user = userEvent.setup();
    render(
      <Page open>
        <input aria-label="Name" />
        <button type="button">Add</button>
        <div />
      </Page>,
    );
    const dialog = screen.getByRole("dialog");
    const added = document.createElement("button");
    added.textContent = "Extra";
    dialog.querySelector("div")?.appendChild(added);

    added.focus();
    await user.tab();
    expect(screen.getByRole("textbox", { name: "Name" })).toHaveFocus();
  });

  it("applies className and extra props to the role=dialog element", () => {
    render(
      <Dialog open onOpenChange={vi.fn()} title="Confirm" className="sheet" data-testid="sheet">
        <p>Body</p>
      </Dialog>,
    );
    expect(screen.getByRole("dialog")).toHaveClass("sheet");
    expect(screen.getByRole("dialog")).toHaveAttribute("data-testid", "sheet");
    expect(getBackdrop()).not.toHaveClass("sheet");
  });

  it("passes onKeyDown through to the dialog element", async () => {
    const user = userEvent.setup();
    const onKeyDown = vi.fn();
    render(
      <Dialog open onOpenChange={vi.fn()} title="Confirm" onKeyDown={onKeyDown}>
        <p>Body</p>
      </Dialog>,
    );
    await user.keyboard("x");
    expect(onKeyDown).toHaveBeenCalledTimes(1);
  });

  it("does not close on a press that starts on the backdrop and ends inside the content", async () => {
    const user = userEvent.setup();
    const onOpenChange = vi.fn();
    render(<Page open onOpenChange={onOpenChange} />);

    await user.pointer([
      { keys: "[MouseLeft>]", target: getBackdrop() },
      { target: screen.getByRole("dialog") },
      { keys: "[/MouseLeft]", target: screen.getByRole("dialog") },
    ]);
    expect(onOpenChange).not.toHaveBeenCalled();
  });

  it("Escape in an inner dialog closes only the inner dialog and returns focus to its opener", async () => {
    const user = userEvent.setup();
    const onOuterChange = vi.fn();
    render(<Nested onOuterChange={onOuterChange} />);
    await user.click(screen.getByRole("button", { name: "Open inner" }));
    expect(screen.getByRole("textbox", { name: "Inner name" })).toHaveFocus();

    await user.keyboard("{Escape}");
    expect(onOuterChange).not.toHaveBeenCalled();
    expect(screen.queryByRole("dialog", { name: "Inner" })).toBeNull();
    expect(screen.getByRole("dialog", { name: "Outer" })).toBeInTheDocument();
    expect(screen.getByRole("button", { name: "Open inner" })).toHaveFocus();
  });

  it("keeps Tab and Shift+Tab inside the inner dialog while it is open", async () => {
    const user = userEvent.setup();
    render(<Nested />);
    await user.click(screen.getByRole("button", { name: "Open inner" }));
    const name = screen.getByRole("textbox", { name: "Inner name" });
    const save = screen.getByRole("button", { name: "Inner save" });

    await user.tab();
    expect(save).toHaveFocus();
    await user.tab();
    expect(name).toHaveFocus();
    await user.tab({ shift: true });
    expect(save).toHaveFocus();
  });

  it("Escape still closes the dialog after the focused element is removed", async () => {
    const user = userEvent.setup();
    const onOpenChange = vi.fn();
    render(<Page open onOpenChange={onOpenChange} />);
    screen.getByRole("textbox", { name: "Name" }).remove();
    expect(document.body).toHaveFocus();

    await user.keyboard("{Escape}");
    expect(onOpenChange).toHaveBeenCalledWith(false);
  });

  it("Tab from body moves focus to the first tabbable inside the dialog", async () => {
    const user = userEvent.setup();
    render(<Page open />);
    (document.activeElement as HTMLElement).blur();
    expect(document.body).toHaveFocus();

    await user.tab();
    expect(screen.getByRole("textbox", { name: "Name" })).toHaveFocus();
  });

  it("pulls focus back into the top-most dialog when focus lands outside it", () => {
    render(<Page open />);
    screen.getByRole("button", { name: "Outside" }).focus();
    expect(screen.getByRole("textbox", { name: "Name" })).toHaveFocus();
  });

  it("focuses and Escape-dismisses only the inner dialog when both mount open in the same commit", async () => {
    const user = userEvent.setup();
    const onOuterChange = vi.fn();
    const onInnerChange = vi.fn();
    render(<NestedOpenAtMount innerOpen onOuterChange={onOuterChange} onInnerChange={onInnerChange} />);
    const inner = screen.getByRole("button", { name: "i1" });
    expect(inner).toHaveFocus();

    await user.tab();
    expect(inner).toHaveFocus();

    await user.keyboard("{Escape}");
    expect(onInnerChange).toHaveBeenCalledTimes(1);
    expect(onInnerChange).toHaveBeenCalledWith(false);
    expect(onOuterChange).not.toHaveBeenCalled();
  });

  it("makes the outer dialog top-most again once the inner dialog closes", async () => {
    const user = userEvent.setup();
    const onOuterChange = vi.fn();
    const onInnerChange = vi.fn();
    const { rerender } = render(
      <NestedOpenAtMount innerOpen onOuterChange={onOuterChange} onInnerChange={onInnerChange} />,
    );
    rerender(<NestedOpenAtMount innerOpen={false} onOuterChange={onOuterChange} onInnerChange={onInnerChange} />);
    const first = screen.getByRole("button", { name: "ob" });
    const last = screen.getByRole("button", { name: "o2" });

    last.focus();
    await user.tab();
    expect(first).toHaveFocus();

    await user.keyboard("{Escape}");
    expect(onOuterChange).toHaveBeenCalledTimes(1);
    expect(onOuterChange).toHaveBeenCalledWith(false);
    expect(onInnerChange).not.toHaveBeenCalled();
  });
});

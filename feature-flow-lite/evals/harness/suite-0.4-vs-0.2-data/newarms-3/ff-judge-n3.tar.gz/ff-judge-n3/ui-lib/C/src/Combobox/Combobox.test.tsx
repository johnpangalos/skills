import { render, screen } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { useState } from "react";
import { describe, expect, it, vi } from "vitest";
import { Combobox, type ComboboxOption, type ComboboxProps } from "./Combobox";

const fruits: ComboboxOption[] = [
  { value: "apple", label: "Apple" },
  { value: "apricot", label: "Apricot", disabled: true },
  { value: "banana", label: "Banana" },
  { value: "blueberry", label: "Blueberry" },
];

function Stateful({
  initial = null,
  options = fruits,
  onChange,
}: {
  initial?: string | null;
  options?: ComboboxOption[];
  onChange?: (value: string | null) => void;
}) {
  const [value, setValue] = useState<string | null>(initial);
  return (
    <Combobox
      label="Fruit"
      options={options}
      value={value}
      onChange={(next) => {
        onChange?.(next);
        setValue(next);
      }}
    />
  );
}

function optionNames(): string[] {
  return screen.queryAllByRole("option").map((option) => option.textContent ?? "");
}

describe("Combobox", () => {
  it("has a visible label associated with the input", () => {
    render(<Stateful />);
    expect(screen.getByText("Fruit")).toBeInTheDocument();
    expect(screen.getByRole("combobox", { name: "Fruit" })).toBeInTheDocument();
  });

  it("exposes combobox, listbox and option ARIA state", async () => {
    const user = userEvent.setup();
    render(<Stateful initial="banana" />);
    const input = screen.getByRole("combobox");
    expect(input).toHaveAttribute("aria-expanded", "false");
    expect(input).toHaveAttribute("aria-autocomplete", "list");
    expect(input).not.toHaveAttribute("aria-activedescendant");
    await user.click(input);
    expect(input).toHaveAttribute("aria-expanded", "true");
    const listbox = screen.getByRole("listbox", { name: "Fruit" });
    expect(input).toHaveAttribute("aria-controls", listbox.id);
    expect(screen.getByRole("option", { name: "Banana" })).toHaveAttribute("aria-selected", "true");
    expect(screen.getByRole("option", { name: "Apple" })).toHaveAttribute("aria-selected", "false");
    expect(screen.getByRole("option", { name: "Apricot" })).toHaveAttribute("aria-disabled", "true");
    expect(screen.getByRole("option", { name: "Apple" })).not.toHaveAttribute("aria-disabled");
  });

  it("shows the selected option's label, and is empty for null or unknown values", () => {
    const { rerender } = render(<Stateful initial="banana" />);
    expect(screen.getByRole("combobox")).toHaveValue("Banana");
    rerender(
      <Combobox label="Fruit" options={fruits} value="missing" onChange={() => {}} />,
    );
    expect(screen.getByRole("combobox")).toHaveValue("");
    rerender(<Combobox label="Fruit" options={fruits} value={null} onChange={() => {}} />);
    expect(screen.getByRole("combobox")).toHaveValue("");
  });

  it("typing opens the listbox and filters by case-insensitive substring", async () => {
    const user = userEvent.setup();
    render(<Stateful />);
    await user.type(screen.getByRole("combobox"), "BLU");
    expect(screen.getByRole("combobox")).toHaveAttribute("aria-expanded", "true");
    expect(optionNames()).toEqual(["Blueberry"]);
    await user.clear(screen.getByRole("combobox"));
    await user.type(screen.getByRole("combobox"), "err");
    expect(optionNames()).toEqual(["Blueberry"]);
  });

  it("empty text shows all options", async () => {
    const user = userEvent.setup();
    render(<Stateful />);
    await user.type(screen.getByRole("combobox"), "x");
    expect(optionNames()).toEqual([]);
    await user.clear(screen.getByRole("combobox"));
    expect(optionNames()).toEqual(["Apple", "Apricot", "Banana", "Blueberry"]);
  });

  it("ArrowDown opens and moves to the next enabled option, skipping disabled ones and wrapping", async () => {
    const user = userEvent.setup();
    render(<Stateful />);
    const input = screen.getByRole("combobox");
    await user.click(input);
    await user.keyboard("{ArrowDown}");
    expect(input).toHaveAttribute("aria-activedescendant", screen.getByRole("option", { name: "Apple" }).id);
    await user.keyboard("{ArrowDown}");
    expect(input).toHaveAttribute("aria-activedescendant", screen.getByRole("option", { name: "Banana" }).id);
    await user.keyboard("{ArrowDown}");
    expect(input).toHaveAttribute("aria-activedescendant", screen.getByRole("option", { name: "Blueberry" }).id);
    await user.keyboard("{ArrowDown}");
    expect(input).toHaveAttribute("aria-activedescendant", screen.getByRole("option", { name: "Apple" }).id);
    await user.keyboard("{ArrowUp}");
    expect(input).toHaveAttribute("aria-activedescendant", screen.getByRole("option", { name: "Blueberry" }).id);
  });

  it("ArrowDown opens the closed listbox", async () => {
    const user = userEvent.setup();
    render(<Stateful />);
    await user.tab();
    await user.keyboard("{ArrowDown}");
    expect(screen.getByRole("combobox")).toHaveAttribute("aria-expanded", "true");
    expect(screen.getAllByRole("option")).toHaveLength(4);
  });

  it("aria-activedescendant is absent when closed or when no option is active", async () => {
    const user = userEvent.setup();
    render(<Stateful />);
    const input = screen.getByRole("combobox");
    await user.click(input);
    expect(input).not.toHaveAttribute("aria-activedescendant");
    await user.keyboard("{Escape}");
    await user.keyboard("{ArrowDown}");
    await user.keyboard("{Escape}");
    expect(input).not.toHaveAttribute("aria-activedescendant");
  });

  it("the active option resets when the filter text changes", async () => {
    const user = userEvent.setup();
    render(<Stateful />);
    const input = screen.getByRole("combobox");
    await user.tab();
    await user.keyboard("{ArrowDown}");
    expect(input).toHaveAttribute("aria-activedescendant");
    await user.type(input, "b");
    expect(input).not.toHaveAttribute("aria-activedescendant");
  });

  it("Enter on the active option selects it, closes the listbox and shows its label", async () => {
    const user = userEvent.setup();
    const onChange = vi.fn();
    render(<Stateful onChange={onChange} />);
    const input = screen.getByRole("combobox");
    await user.tab();
    await user.keyboard("{ArrowDown}{ArrowDown}");
    await user.keyboard("{Enter}");
    expect(onChange).toHaveBeenCalledExactlyOnceWith("banana");
    expect(input).toHaveAttribute("aria-expanded", "false");
    expect(input).toHaveValue("Banana");
  });

  it("Enter with no active option does nothing", async () => {
    const user = userEvent.setup();
    const onChange = vi.fn();
    render(<Stateful initial="apple" onChange={onChange} />);
    const input = screen.getByRole("combobox");
    await user.click(input);
    await user.keyboard("{Enter}");
    expect(onChange).not.toHaveBeenCalled();
    expect(input).toHaveAttribute("aria-expanded", "true");
  });

  it("clicking an enabled option selects it; clicking a disabled option does nothing", async () => {
    const user = userEvent.setup();
    const onChange = vi.fn();
    render(<Stateful onChange={onChange} />);
    await user.click(screen.getByRole("combobox"));
    await user.click(screen.getByRole("option", { name: "Apricot" }));
    expect(onChange).not.toHaveBeenCalled();
    expect(screen.getByRole("combobox")).toHaveAttribute("aria-expanded", "true");
    await user.click(screen.getByRole("option", { name: "Banana" }));
    expect(onChange).toHaveBeenCalledExactlyOnceWith("banana");
    expect(screen.getByRole("combobox")).toHaveValue("Banana");
    expect(screen.getByRole("combobox")).toHaveAttribute("aria-expanded", "false");
  });

  it("Escape closes without calling onChange and restores the selected label", async () => {
    const user = userEvent.setup();
    const onChange = vi.fn();
    render(<Stateful initial="banana" onChange={onChange} />);
    const input = screen.getByRole("combobox");
    await user.clear(input);
    await user.type(input, "ap");
    expect(optionNames()).toEqual(["Apple", "Apricot"]);
    await user.keyboard("{Escape}");
    expect(onChange).not.toHaveBeenCalled();
    expect(input).toHaveAttribute("aria-expanded", "false");
    expect(input).toHaveValue("Banana");
  });

  it("shows 'No results' as a status, not an option, and drops aria-activedescendant", async () => {
    const user = userEvent.setup();
    render(<Stateful />);
    const input = screen.getByRole("combobox");
    await user.type(input, "zzz");
    expect(screen.getByRole("status")).toHaveTextContent("No results");
    expect(screen.queryAllByRole("option")).toHaveLength(0);
    expect(input).not.toHaveAttribute("aria-activedescendant");
  });

  it("blur closes the listbox and restores the selected label", async () => {
    const user = userEvent.setup();
    render(<Stateful initial="banana" />);
    const input = screen.getByRole("combobox");
    await user.type(input, "ap");
    await user.tab();
    expect(input).toHaveAttribute("aria-expanded", "false");
    expect(input).toHaveValue("Banana");
  });

  it("clearing the text and blurring sets the value to null", async () => {
    const user = userEvent.setup();
    const onChange = vi.fn();
    render(<Stateful initial="banana" onChange={onChange} />);
    await user.clear(screen.getByRole("combobox"));
    await user.tab();
    expect(onChange).toHaveBeenCalledExactlyOnceWith(null);
    expect(screen.getByRole("combobox")).toHaveValue("");
  });

  it("clearing the text and pressing Enter with no active option sets the value to null", async () => {
    const user = userEvent.setup();
    const onChange = vi.fn();
    render(<Stateful initial="banana" onChange={onChange} />);
    await user.clear(screen.getByRole("combobox"));
    await user.keyboard("{Enter}");
    expect(onChange).toHaveBeenCalledExactlyOnceWith(null);
  });

  it("all options disabled: ArrowDown opens with no active option and Enter does nothing", async () => {
    const user = userEvent.setup();
    const onChange = vi.fn();
    const allDisabled = fruits.map((option) => ({ ...option, disabled: true }));
    render(<Stateful options={allDisabled} onChange={onChange} />);
    const input = screen.getByRole("combobox");
    await user.tab();
    await user.keyboard("{ArrowDown}");
    expect(input).toHaveAttribute("aria-expanded", "true");
    expect(input).not.toHaveAttribute("aria-activedescendant");
    await user.keyboard("{ArrowDown}{Enter}");
    expect(onChange).not.toHaveBeenCalled();
  });

  it("empty options array shows 'No results'", async () => {
    const user = userEvent.setup();
    render(<Stateful options={[]} />);
    await user.tab();
    await user.keyboard("{ArrowDown}");
    expect(screen.getByRole("status")).toHaveTextContent("No results");
    expect(screen.queryAllByRole("option")).toHaveLength(0);
  });

  it("regex characters are treated as literal text", async () => {
    const user = userEvent.setup();
    render(<Stateful />);
    const input = screen.getByRole("combobox");
    await user.type(input, "(");
    expect(screen.getByRole("status")).toHaveTextContent("No results");
    await user.clear(input);
    await user.type(input, ".*");
    expect(screen.getByRole("status")).toHaveTextContent("No results");
    expect(screen.queryAllByRole("option")).toHaveLength(0);
  });

  it("labels differing only in case both match, and a value not in options leaves the input empty", async () => {
    const user = userEvent.setup();
    const cased: ComboboxOption[] = [
      { value: "upper", label: "Apple" },
      { value: "lower", label: "apple" },
    ];
    render(<Stateful options={cased} initial="missing" />);
    const input = screen.getByRole("combobox");
    expect(input).toHaveValue("");
    await user.type(input, "APPLE");
    expect(optionNames()).toEqual(["Apple", "apple"]);
  });

  it("new options array identity on every render keeps the active option valid", async () => {
    const user = userEvent.setup();
    const onChange = vi.fn();
    const { rerender } = render(
      <Combobox label="Fruit" options={fruits} value={null} onChange={onChange} />,
    );
    const input = screen.getByRole("combobox");
    await user.tab();
    await user.keyboard("{ArrowDown}{ArrowDown}");
    const banana = screen.getByRole("option", { name: "Banana" }).id;
    rerender(
      <Combobox label="Fruit" options={fruits.map((option) => ({ ...option }))} value={null} onChange={onChange} />,
    );
    expect(input).toHaveAttribute("aria-activedescendant", banana);
    await user.keyboard("{Enter}");
    expect(onChange).toHaveBeenCalledExactlyOnceWith("banana");
  });

  it("two comboboxes on one page have no colliding option ids", async () => {
    const user = userEvent.setup();
    render(
      <>
        <Combobox label="First" options={fruits} value={null} onChange={() => {}} />
        <Combobox label="Second" options={fruits} value={null} onChange={() => {}} />
      </>,
    );
    const [first, second] = screen.getAllByRole("combobox");
    await user.click(first);
    const firstIds = screen.getAllByRole("option").map((option) => option.id);
    await user.click(second);
    const secondIds = screen.getAllByRole("option").map((option) => option.id);
    expect(firstIds).toHaveLength(4);
    expect(new Set([...firstIds, ...secondIds]).size).toBe(firstIds.length + secondIds.length);
  });

  it("passes className and extra props to the input", () => {
    render(
      <Combobox
        label="Fruit"
        options={fruits}
        value={null}
        onChange={() => {}}
        className="field"
        placeholder="Pick one"
        data-testid="input"
      />,
    );
    expect(screen.getByTestId("input")).toHaveClass("field");
    expect(screen.getByTestId("input")).toHaveAttribute("placeholder", "Pick one");
  });

  it("rejects defaultValue alongside value at the type level", () => {
    const props: ComboboxProps = {
      label: "Fruit",
      options: fruits,
      value: null,
      onChange: () => {},
      // @ts-expect-error defaultValue is omitted from ComboboxProps
      defaultValue: "apple",
    };
    expect(props.value).toBeNull();
  });
});

import { StrictMode, useState } from "react";
import type { ReactNode } from "react";
import { describe, expect, it, vi } from "vitest";
import { fireEvent, render, screen } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { Dialog } from "../src/Dialog";

function Controlled({
  onOpenChange,
  description,
  children,
}: {
  onOpenChange?: (open: boolean) => void;
  description?: string;
  children?: ReactNode;
}) {
  const [open, setOpen] = useState(false);
  return (
    <>
      <button type="button" onClick={() => setOpen(true)}>
        Open
      </button>
      <Dialog
        open={open}
        title="Settings"
        description={description}
        onOpenChange={(next) => {
          onOpenChange?.(next);
          setOpen(next);
        }}
      >
        {children ?? <button type="button">Save</button>}
      </Dialog>
    </>
  );
}

const opener = () => screen.getByRole("button", { name: "Open" });

describe("Dialog", () => {
  describe("rendering (D1)", () => {
    it("renders nothing when open is false", () => {
      const { container } = render(
        <Dialog open={false} title="Settings" onOpenChange={() => {}}>
          <button type="button">Save</button>
        </Dialog>,
      );
      expect(screen.queryByRole("dialog")).toBeNull();
      expect(container).toBeEmptyDOMElement();
    });

    it("portals a backdrop containing the dialog into document.body", () => {
      const { container } = render(
        <Dialog open title="Settings" onOpenChange={() => {}} className="panel" data-testid="dialog">
          <button type="button">Save</button>
        </Dialog>,
      );
      expect(container).toBeEmptyDOMElement();
      const dialog = screen.getByRole("dialog");
      expect(dialog.parentElement?.parentElement).toBe(document.body);
      expect(dialog).toHaveAttribute("aria-modal", "true");
      expect(dialog).toHaveClass("panel");
      expect(dialog).toHaveAttribute("data-testid", "dialog");
    });

    it("labels the dialog with its h2 title", () => {
      render(
        <Dialog open title="Settings" onOpenChange={() => {}}>
          <button type="button">Save</button>
        </Dialog>,
      );
      const dialog = screen.getByRole("dialog");
      const heading = screen.getByRole("heading", { name: "Settings" });
      expect(heading.tagName).toBe("H2");
      expect(dialog).toHaveAttribute("aria-labelledby", heading.id);
      expect(dialog).toHaveAccessibleName("Settings");
    });

    it("describes the dialog with its paragraph when description is given", () => {
      render(
        <Dialog open title="Settings" description="Change your preferences" onOpenChange={() => {}}>
          <button type="button">Save</button>
        </Dialog>,
      );
      const dialog = screen.getByRole("dialog");
      const paragraph = screen.getByText("Change your preferences");
      expect(paragraph.tagName).toBe("P");
      expect(dialog).toHaveAttribute("aria-describedby", paragraph.id);
      expect(dialog).toHaveAccessibleDescription("Change your preferences");
    });

    it("has no aria-describedby when description is not given", () => {
      render(
        <Dialog open title="Settings" onOpenChange={() => {}}>
          <button type="button">Save</button>
        </Dialog>,
      );
      expect(screen.getByRole("dialog")).not.toHaveAttribute("aria-describedby");
    });
  });

  describe("initial focus (D2)", () => {
    it("focuses the first enabled focusable element", async () => {
      render(
        <Controlled>
          <button type="button" disabled>
            Off
          </button>
          <input aria-label="Name" />
          <button type="button">Save</button>
        </Controlled>,
      );
      await userEvent.setup().click(opener());
      expect(screen.getByLabelText("Name")).toHaveFocus();
    });

    it("skips tabindex -1 elements and focuses a link with href", async () => {
      render(
        <Controlled>
          <div tabIndex={-1}>Note</div>
          <a href="#docs">Docs</a>
        </Controlled>,
      );
      await userEvent.setup().click(opener());
      expect(screen.getByRole("link", { name: "Docs" })).toHaveFocus();
    });

    it("focuses the dialog itself when it has no focusable elements", async () => {
      render(<Controlled>Just text</Controlled>);
      await userEvent.setup().click(opener());
      const dialog = screen.getByRole("dialog");
      expect(dialog).toHaveAttribute("tabindex", "-1");
      expect(dialog).toHaveFocus();
    });
  });

  describe("focus trap (D3)", () => {
    it("Tab on the last focusable wraps to the first", async () => {
      const user = userEvent.setup();
      render(
        <Controlled>
          <button type="button">A</button>
          <button type="button">B</button>
        </Controlled>,
      );
      await user.click(opener());
      expect(screen.getByRole("button", { name: "A" })).toHaveFocus();
      await user.tab();
      expect(screen.getByRole("button", { name: "B" })).toHaveFocus();
      await user.tab();
      expect(screen.getByRole("button", { name: "A" })).toHaveFocus();
    });

    it("Shift+Tab on the first focusable wraps to the last", async () => {
      const user = userEvent.setup();
      render(
        <Controlled>
          <button type="button">A</button>
          <button type="button">B</button>
        </Controlled>,
      );
      await user.click(opener());
      await user.tab({ shift: true });
      expect(screen.getByRole("button", { name: "B" })).toHaveFocus();
    });

    it("keeps focus on the dialog when there are no focusable elements", async () => {
      const user = userEvent.setup();
      render(<Controlled>Just text</Controlled>);
      await user.click(opener());
      const dialog = screen.getByRole("dialog");
      await user.tab();
      expect(dialog).toHaveFocus();
      await user.tab({ shift: true });
      expect(dialog).toHaveFocus();
    });
  });

  describe("dismissal (D4)", () => {
    it("Escape calls onOpenChange(false)", async () => {
      const user = userEvent.setup();
      const onOpenChange = vi.fn();
      render(<Controlled onOpenChange={onOpenChange} />);
      await user.click(opener());
      await user.keyboard("{Escape}");
      expect(onOpenChange).toHaveBeenCalledWith(false);
    });

    it("Escape does nothing when a child already prevented the default", async () => {
      const user = userEvent.setup();
      const onOpenChange = vi.fn();
      render(
        <Controlled onOpenChange={onOpenChange}>
          <button
            type="button"
            onKeyDown={(event) => {
              if (event.key === "Escape") event.preventDefault();
            }}
          >
            Inner
          </button>
        </Controlled>,
      );
      await user.click(opener());
      await user.keyboard("{Escape}");
      expect(onOpenChange).not.toHaveBeenCalled();
      expect(screen.getByRole("dialog")).toBeInTheDocument();
    });

    it("clicking the backdrop calls onOpenChange(false)", async () => {
      const user = userEvent.setup();
      const onOpenChange = vi.fn();
      render(<Controlled onOpenChange={onOpenChange} />);
      await user.click(opener());
      await user.click(screen.getByRole("dialog").parentElement as HTMLElement);
      expect(onOpenChange).toHaveBeenCalledWith(false);
    });

    it("clicking inside the dialog does not close it", async () => {
      const user = userEvent.setup();
      const onOpenChange = vi.fn();
      render(<Controlled onOpenChange={onOpenChange} description="Body copy" />);
      await user.click(opener());
      await user.click(screen.getByText("Body copy"));
      expect(onOpenChange).not.toHaveBeenCalled();
    });

    it("a press that starts inside and ends on the backdrop does not close it", async () => {
      const user = userEvent.setup();
      const onOpenChange = vi.fn();
      render(<Controlled onOpenChange={onOpenChange} />);
      await user.click(opener());
      const backdrop = screen.getByRole("dialog").parentElement as HTMLElement;
      fireEvent.mouseDown(screen.getByRole("heading", { name: "Settings" }));
      fireEvent.mouseUp(backdrop);
      fireEvent.click(backdrop);
      expect(onOpenChange).not.toHaveBeenCalled();
    });
  });

  describe("focus restore (D5)", () => {
    it("returns focus to the opener when the dialog closes", async () => {
      const user = userEvent.setup();
      render(<Controlled />);
      await user.click(opener());
      expect(screen.getByRole("button", { name: "Save" })).toHaveFocus();
      await user.keyboard("{Escape}");
      expect(screen.queryByRole("dialog")).toBeNull();
      expect(opener()).toHaveFocus();
    });

    it("returns focus to the previously focused element when the dialog unmounts", () => {
      const outside = document.createElement("button");
      document.body.append(outside);
      outside.focus();
      const { unmount } = render(
        <Dialog open title="Settings" onOpenChange={() => {}}>
          <button type="button">Save</button>
        </Dialog>,
      );
      expect(screen.getByRole("button", { name: "Save" })).toHaveFocus();
      unmount();
      expect(outside).toHaveFocus();
      outside.remove();
    });

    it("does not throw when the previously focused element was removed", () => {
      const outside = document.createElement("button");
      document.body.append(outside);
      outside.focus();
      const { rerender } = render(
        <Dialog open title="Settings" onOpenChange={() => {}}>
          <button type="button">Save</button>
        </Dialog>,
      );
      outside.remove();
      expect(() =>
        rerender(
          <Dialog open={false} title="Settings" onOpenChange={() => {}}>
            <button type="button">Save</button>
          </Dialog>,
        ),
      ).not.toThrow();
      expect(screen.queryByRole("dialog")).toBeNull();
    });

    it("restores focus to the opener under StrictMode", async () => {
      const user = userEvent.setup();
      render(
        <StrictMode>
          <Controlled />
        </StrictMode>,
      );
      await user.click(opener());
      expect(screen.getByRole("button", { name: "Save" })).toHaveFocus();
      await user.keyboard("{Escape}");
      expect(opener()).toHaveFocus();
    });
  });

  describe("backdrop press keeps focus (D3)", () => {
    it("clicking the backdrop keeps focus inside the dialog when the parent ignores onOpenChange", async () => {
      const user = userEvent.setup();
      render(
        <>
          <button type="button">Outside</button>
          <Dialog open title="Settings" onOpenChange={() => {}}>
            <button type="button">Save</button>
          </Dialog>
        </>,
      );
      const dialog = screen.getByRole("dialog");
      await user.click(dialog.parentElement as HTMLElement);
      await user.tab();
      expect(dialog).toContainElement(document.activeElement as HTMLElement);
      expect(screen.getByRole("button", { name: "Outside" })).not.toHaveFocus();
    });
  });

  describe("nested dialogs (D3)", () => {
    function Nested({
      onOuterOpenChange,
      onInnerOpenChange,
    }: {
      onOuterOpenChange: (open: boolean) => void;
      onInnerOpenChange: (open: boolean) => void;
    }) {
      const [inner, setInner] = useState(false);
      return (
        <Dialog open title="Outer" onOpenChange={onOuterOpenChange}>
          <button type="button" onClick={() => setInner(true)}>
            Open inner
          </button>
          <Dialog
            open={inner}
            title="Inner"
            onOpenChange={(next) => {
              onInnerOpenChange(next);
              setInner(next);
            }}
          >
            <button type="button">Cancel</button>
            <button type="button">Confirm</button>
          </Dialog>
        </Dialog>
      );
    }

    it("Escape closes only the inner dialog", async () => {
      const user = userEvent.setup();
      const onOuterOpenChange = vi.fn();
      const onInnerOpenChange = vi.fn();
      render(<Nested onOuterOpenChange={onOuterOpenChange} onInnerOpenChange={onInnerOpenChange} />);
      await user.click(screen.getByRole("button", { name: "Open inner" }));
      expect(screen.getByRole("dialog", { name: "Inner" })).toContainElement(document.activeElement as HTMLElement);
      await user.keyboard("{Escape}");
      expect(onInnerOpenChange).toHaveBeenCalledTimes(1);
      expect(onInnerOpenChange).toHaveBeenCalledWith(false);
      expect(onOuterOpenChange).not.toHaveBeenCalled();
    });

    it("Tab and Shift+Tab inside the inner dialog keep focus inside it", async () => {
      const user = userEvent.setup();
      render(<Nested onOuterOpenChange={() => {}} onInnerOpenChange={() => {}} />);
      await user.click(screen.getByRole("button", { name: "Open inner" }));
      const inner = screen.getByRole("dialog", { name: "Inner" });
      await user.tab();
      expect(screen.getByRole("button", { name: "Confirm" })).toHaveFocus();
      await user.tab();
      expect(screen.getByRole("button", { name: "Cancel" })).toHaveFocus();
      await user.tab({ shift: true });
      expect(screen.getByRole("button", { name: "Confirm" })).toHaveFocus();
      expect(inner).toContainElement(document.activeElement as HTMLElement);
    });
  });

  describe("focused element removed inside the dialog (D3, D4)", () => {
    function RemovableButton() {
      const [shown, setShown] = useState(true);
      return shown ? (
        <button type="button" onClick={() => setShown(false)}>
          Remove
        </button>
      ) : null;
    }

    it("Tab after the focused element is removed moves focus into the dialog", async () => {
      const user = userEvent.setup();
      render(
        <>
          <button type="button">Outside</button>
          <Controlled>
            <RemovableButton />
            <button type="button">Save</button>
          </Controlled>
        </>,
      );
      await user.click(opener());
      await user.click(screen.getByRole("button", { name: "Remove" }));
      expect(screen.queryByRole("button", { name: "Remove" })).toBeNull();
      await user.tab();
      expect(screen.getByRole("button", { name: "Save" })).toHaveFocus();
      expect(screen.getByRole("button", { name: "Outside" })).not.toHaveFocus();
    });

    it("Escape after the focused element is removed still calls onOpenChange(false)", async () => {
      const user = userEvent.setup();
      const onOpenChange = vi.fn();
      render(
        <Controlled onOpenChange={onOpenChange}>
          <RemovableButton />
          <button type="button">Save</button>
        </Controlled>,
      );
      await user.click(opener());
      await user.click(screen.getByRole("button", { name: "Remove" }));
      await user.keyboard("{Escape}");
      expect(onOpenChange).toHaveBeenCalledTimes(1);
      expect(onOpenChange).toHaveBeenCalledWith(false);
    });
  });

  describe("nested dialogs opened in the same render (D2, D3, D4, D5)", () => {
    function Together({
      onOuterOpenChange = () => {},
      onInnerOpenChange = () => {},
    }: {
      onOuterOpenChange?: (open: boolean) => void;
      onInnerOpenChange?: (open: boolean) => void;
    }) {
      const [outer, setOuter] = useState(false);
      const [inner, setInner] = useState(false);
      return (
        <>
          <button
            type="button"
            onClick={() => {
              setOuter(true);
              setInner(true);
            }}
          >
            Open both
          </button>
          <Dialog
            open={outer}
            title="Outer"
            onOpenChange={(next) => {
              onOuterOpenChange(next);
              setOuter(next);
            }}
          >
            <button type="button">o1</button>
            <button type="button" onClick={() => setOuter(false)}>
              Close outer
            </button>
            <Dialog
              open={inner}
              title="Inner"
              onOpenChange={(next) => {
                onInnerOpenChange(next);
                setInner(next);
              }}
            >
              <button type="button">i1</button>
              <button type="button">i2</button>
            </Dialog>
          </Dialog>
        </>
      );
    }

    it("focuses the inner dialog's first element, not the outer one's", () => {
      render(
        <Dialog open title="Outer" onOpenChange={() => {}}>
          <button type="button">o1</button>
          <Dialog open title="Inner" onOpenChange={() => {}}>
            <button type="button">i1</button>
          </Dialog>
        </Dialog>,
      );
      expect(screen.getByRole("button", { name: "i1" })).toHaveFocus();
      expect(screen.getByRole("button", { name: "o1" })).not.toHaveFocus();
    });

    it("Escape calls only the inner onOpenChange", async () => {
      const user = userEvent.setup();
      const onOuterOpenChange = vi.fn();
      const onInnerOpenChange = vi.fn();
      render(
        <Dialog open title="Outer" onOpenChange={onOuterOpenChange}>
          <button type="button">o1</button>
          <Dialog open title="Inner" onOpenChange={onInnerOpenChange}>
            <button type="button">i1</button>
          </Dialog>
        </Dialog>,
      );
      await user.keyboard("{Escape}");
      expect(onInnerOpenChange).toHaveBeenCalledTimes(1);
      expect(onInnerOpenChange).toHaveBeenCalledWith(false);
      expect(onOuterOpenChange).not.toHaveBeenCalled();
    });

    it("Tab wraps inside the inner dialog and never reaches the outer one", async () => {
      const user = userEvent.setup();
      render(
        <Dialog open title="Outer" onOpenChange={() => {}}>
          <button type="button">o1</button>
          <Dialog open title="Inner" onOpenChange={() => {}}>
            <button type="button">i1</button>
            <button type="button">i2</button>
          </Dialog>
        </Dialog>,
      );
      const inner = screen.getByRole("dialog", { name: "Inner" });
      await user.tab();
      expect(screen.getByRole("button", { name: "i2" })).toHaveFocus();
      await user.tab();
      expect(screen.getByRole("button", { name: "i1" })).toHaveFocus();
      expect(inner).toContainElement(document.activeElement as HTMLElement);
    });

    it("closing the inner moves focus into the outer dialog, not to the opener", async () => {
      const user = userEvent.setup();
      render(<Together />);
      await user.click(screen.getByRole("button", { name: "Open both" }));
      expect(screen.getByRole("button", { name: "i1" })).toHaveFocus();
      await user.keyboard("{Escape}");
      expect(screen.queryByRole("dialog", { name: "Inner" })).toBeNull();
      expect(screen.getByRole("button", { name: "o1" })).toHaveFocus();
    });

    it("after both close, focus returns to the opener", async () => {
      const user = userEvent.setup();
      render(<Together />);
      const opener = screen.getByRole("button", { name: "Open both" });
      await user.click(opener);
      await user.keyboard("{Escape}");
      await user.keyboard("{Escape}");
      expect(screen.queryByRole("dialog")).toBeNull();
      expect(opener).toHaveFocus();
    });

    it("closing the outer while the inner is open returns focus to the opener", async () => {
      const user = userEvent.setup();
      render(<Together />);
      const opener = screen.getByRole("button", { name: "Open both" });
      await user.click(opener);
      await user.click(screen.getByRole("button", { name: "Close outer" }));
      expect(screen.queryByRole("dialog")).toBeNull();
      expect(opener).toHaveFocus();
    });
  });

  describe("controlled open (D6)", () => {
    it("stays open when the parent ignores onOpenChange(false)", async () => {
      const user = userEvent.setup();
      const onOpenChange = vi.fn();
      render(
        <Dialog open title="Settings" onOpenChange={onOpenChange}>
          <button type="button">Save</button>
        </Dialog>,
      );
      await user.keyboard("{Escape}");
      expect(onOpenChange).toHaveBeenCalledWith(false);
      expect(screen.getByRole("dialog")).toBeInTheDocument();
    });
  });
});

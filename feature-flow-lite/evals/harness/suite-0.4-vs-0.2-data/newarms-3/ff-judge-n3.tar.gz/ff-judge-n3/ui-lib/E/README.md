# @acme/ui

Accessible React 19 components: `Tabs`, `Dialog`, `Combobox`. Components ship no styles and no CSS; pass `className` to style them.

## Install and usage

```tsx
import { Tabs, TabList, Tab, TabPanel, Dialog, Combobox } from "@acme/ui";
import type { ComboboxOption } from "@acme/ui";

<Tabs defaultValue="profile">
  <TabList aria-label="Settings">
    <Tab value="profile">Profile</Tab>
    <Tab value="billing">Billing</Tab>
  </TabList>
  <TabPanel value="profile">Profile form</TabPanel>
  <TabPanel value="billing">Billing form</TabPanel>
</Tabs>;

<Dialog open={open} onOpenChange={setOpen} title="Delete project" description="This cannot be undone.">
  <button onClick={() => setOpen(false)}>Cancel</button>
</Dialog>;

<Combobox label="Fruit" options={options} value={fruit} onChange={setFruit} />;
```

React and react-dom 19 are peer dependencies. There are no runtime dependencies.

## Development

- `pnpm test`: run the Vitest suite (jsdom and Testing Library).
- `pnpm typecheck`: run `tsc --noEmit` in strict mode.

## Tabs

Built from `Tabs`, `TabList`, `Tab` and `TabPanel`. `Tabs` owns the selection. If `value` is set, the component is controlled and selection changes only when the parent updates `value`. Otherwise it is uncontrolled and starts at `defaultValue`, or at the first enabled tab if `defaultValue` is omitted.

### Tabs props

| Name | Type | Default | Description |
| --- | --- | --- | --- |
| `defaultValue` | `string` | first enabled tab | Initially selected value (uncontrolled). |
| `value` | `string` | none | Selected value. Setting it makes the component controlled. |
| `onValueChange` | `(value: string) => void` | none | Called when the user selects a tab. |
| `className` | `string` | none | Class name for the wrapping `div`. |

### TabList props

| Name | Type | Default | Description |
| --- | --- | --- | --- |
| `aria-label` | `string` | required | Accessible name of the `role="tablist"` element. |
| `className` | `string` | none | Class name for the tablist. Other `div` props are passed through. |

### Tab props

| Name | Type | Default | Description |
| --- | --- | --- | --- |
| `value` | `string` | required | Value this tab selects. |
| `disabled` | `boolean` | `false` | Disables the tab. It cannot be clicked or reached by keyboard. |

Other `button` props are passed through to the `<button role="tab">`.

### TabPanel props

| Name | Type | Default | Description |
| --- | --- | --- | --- |
| `value` | `string` | required | Value of the tab that controls this panel. Every panel renders; panels other than the selected one have the `hidden` attribute. |

Other `div` props are passed through to the `role="tabpanel"` element.

### Tabs keyboard

Focus is on a tab. Selection follows focus.

| Key | Behavior |
| --- | --- |
| `ArrowRight` | Focus and select the next enabled tab. Wraps from the last to the first. |
| `ArrowLeft` | Focus and select the previous enabled tab. Wraps from the first to the last. |
| `Home` | Focus and select the first enabled tab. |
| `End` | Focus and select the last enabled tab. |

Other keys do nothing. Tab moves focus out of the tablist to the selected panel. Tab key handling is left to the browser.

## Dialog

A modal dialog rendered into `document.body` through a portal. It renders nothing while `open` is `false`. It is controlled only: it calls `onOpenChange` and never closes itself.

### Dialog props

| Name | Type | Default | Description |
| --- | --- | --- | --- |
| `open` | `boolean` | required | Whether the dialog is shown. |
| `onOpenChange` | `(open: boolean) => void` | required | Called with `false` on Escape or a backdrop click. |
| `title` | `ReactNode` | required | Rendered in an `<h2>` and used as the accessible name. |
| `description` | `ReactNode` | none | Rendered in a `<p>` and linked with `aria-describedby`. Omitted when not provided. |
| `children` | `ReactNode` | none | Dialog body. |
| `className` | `string` | none | Class name for the `role="dialog"` element. |
| `backdropClassName` | `string` | none | Class name for the backdrop element. The backdrop always has a `data-dialog-backdrop` attribute. |

### Dialog keyboard

Focus moves to the first tabbable element when the dialog opens, or to the dialog itself if none exists. Focus returns to the previously focused element when the dialog closes, if that element is still in the document.

| Key | Behavior |
| --- | --- |
| `Tab` | Moves to the next tabbable element. Wraps from the last to the first. With no tabbable elements, focus stays on the dialog. |
| `Shift+Tab` | Moves to the previous tabbable element. Wraps from the first to the last. With no tabbable elements, focus stays on the dialog. |
| `Escape` | Calls `onOpenChange(false)` for the innermost open dialog only. Nested dialogs do not close their parent. |

A mousedown and click on the backdrop (not inside the dialog) calls `onOpenChange(false)`. A press that starts inside the dialog does not close it.

Tabbable elements are `a[href]`, `button`, `input` (except `type="hidden"`), `select`, `textarea`, and `[tabindex]` other than `-1`, excluding disabled elements and elements inside a `hidden` element.

## Combobox

A text input with a filtered listbox. The input is controlled through `value`. The `onChange` callback runs when the user selects an option, or with `null` when the user empties the text and then presses Enter or leaves the field.

### Combobox props

| Name | Type | Default | Description |
| --- | --- | --- | --- |
| `label` | `string` | required | Visible label, linked to the input. |
| `options` | `ComboboxOption[]` | required | `{ value, label, disabled? }` items. |
| `value` | `string \| null` | required | Selected option value. `null` or an unknown value shows an empty input. |
| `onChange` | `(value: string \| null) => void` | required | Called with the option value when the user selects an enabled option. |
| `placeholder` | `string` | none | Placeholder for the input. |
| `className` | `string` | none | Class name for the wrapping `div`. |

Filtering is a case-insensitive substring match on the label. The query is literal, so regex characters are plain text. When the query changes, the first enabled match becomes active. If the trimmed query is empty, no option is active. When the popup shows no options, it displays "No results" and no option is active.

### Combobox keyboard

| Key | Behavior |
| --- | --- |
| Typing | Opens the listbox, filters the options, and activates the first enabled match. With empty text, no option is active. |
| `ArrowDown` | Closed: opens and activates the selected option if it is enabled and visible, else the first enabled option. Open: activates the next enabled option. Wraps from the last to the first. |
| `ArrowUp` | Closed: opens and activates the selected option if it is enabled and visible, else the last enabled option. Open: activates the previous enabled option. Wraps from the first to the last. |
| `Enter` | Open with an active enabled option: calls `onChange(option.value)`, closes, and shows the label. Open with no active option and empty text: calls `onChange(null)` and closes. Otherwise does nothing. Enter is consumed while open, so it does not submit a form. |
| `Escape` | Open: closes, reverts the text to the selected label, and does not call `onChange`. Closed: does nothing. |

Blur closes the listbox and reverts the text to the selected label. If the text is empty, blur calls `onChange(null)` first. Clicking an enabled option selects it. Clicking a disabled option does nothing and leaves the listbox open.

The active option has `data-active="true"` and is referenced by `aria-activedescendant` while the listbox is open. Disabled options are skipped by all arrow keys.

Clearing the text clears the value. When the user empties the text and then presses Enter or leaves the field, `onChange(null)` is called, unless `value` is already `null`. Text that is only whitespace counts as empty. Pressing Escape instead reverts the text and does not change the value.

## Types

`ComboboxOption` is exported with `ComboboxProps`, `DialogProps`, `TabsProps`, `TabListProps`, `TabProps` and `TabPanelProps`.

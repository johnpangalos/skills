import { createContext, useContext, useEffect, useId, useRef, type ComponentPropsWithoutRef, type ReactNode } from "react";
import { createPortal } from "react-dom";

export type DialogProps = Omit<ComponentPropsWithoutRef<"div">, "title"> & {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  title: ReactNode;
  description?: ReactNode;
  children?: ReactNode;
};

// Open dialogs in the order they opened. The topmost one, which alone handles Escape and Tab, is
// the most deeply nested; among equally nested ones, the last opened. Depth comes from context
// because nested dialogs that open in the same commit run their effects child first.
type Layer = { depth: number };
const openDialogs: Layer[] = [];
const DialogDepth = createContext(0);

function isTopmost(layer: Layer): boolean {
  let top = openDialogs[0];
  for (const open of openDialogs) if (open.depth >= top.depth) top = open;
  return top === layer;
}

function getTabbables(container: HTMLElement): HTMLElement[] {
  return Array.from(
    container.querySelectorAll<HTMLElement>("button, input, select, textarea, a[href], [tabindex]"),
  ).filter((el) => el.tabIndex >= 0 && !el.matches(":disabled") && !el.closest("[hidden]"));
}

function keepTabInside(event: globalThis.KeyboardEvent, dialog: HTMLElement) {
  const tabbables = getTabbables(dialog);
  if (tabbables.length === 0) {
    event.preventDefault();
    dialog.focus();
    return;
  }
  // -1 means focus is on the dialog itself or outside it.
  const index = tabbables.indexOf(document.activeElement as HTMLElement);
  if (event.shiftKey && index <= 0) {
    event.preventDefault();
    tabbables[tabbables.length - 1].focus();
  } else if (!event.shiftKey && (index === -1 || index === tabbables.length - 1)) {
    event.preventDefault();
    tabbables[0].focus();
  }
}

function DialogSurface({
  onOpenChange,
  title,
  description,
  children,
  ...rest
}: Omit<DialogProps, "open">) {
  const baseId = useId();
  const titleId = `${baseId}-title`;
  const descriptionId = `${baseId}-description`;
  const dialogRef = useRef<HTMLDivElement>(null);
  const pressedBackdrop = useRef(false);
  const depth = useContext(DialogDepth) + 1;
  const layer = useRef<Layer>({ depth }).current;
  const hasDescription = description != null && description !== false;

  // Focus moves in on open and goes back to the previously focused element on close or unmount.
  useEffect(() => {
    const previous = document.activeElement;
    const dialog = dialogRef.current as HTMLDivElement;
    (getTabbables(dialog)[0] ?? dialog).focus();
    return () => {
      if (previous instanceof HTMLElement && previous.isConnected) previous.focus();
    };
  }, []);

  useEffect(() => {
    openDialogs.push(layer);
    return () => {
      openDialogs.splice(openDialogs.indexOf(layer), 1);
    };
  }, [layer]);

  useEffect(() => {
    function handleKeyDown(event: globalThis.KeyboardEvent) {
      if (!isTopmost(layer)) return;
      if (event.key === "Escape") {
        onOpenChange(false);
      } else if (event.key === "Tab") {
        keepTabInside(event, dialogRef.current as HTMLDivElement);
      }
    }
    document.addEventListener("keydown", handleKeyDown);
    return () => document.removeEventListener("keydown", handleKeyDown);
  }, [onOpenChange, layer]);

  return (
    <div
      data-backdrop
      onMouseDown={(event) => {
        pressedBackdrop.current = event.target === event.currentTarget;
      }}
      onClick={(event) => {
        if (event.target === event.currentTarget && pressedBackdrop.current) onOpenChange(false);
      }}
    >
      <div
        {...rest}
        ref={dialogRef}
        role="dialog"
        aria-modal="true"
        aria-labelledby={titleId}
        aria-describedby={hasDescription ? descriptionId : undefined}
        tabIndex={-1}
      >
        <h2 id={titleId}>{title}</h2>
        {hasDescription ? <p id={descriptionId}>{description}</p> : null}
        <DialogDepth.Provider value={depth}>{children}</DialogDepth.Provider>
      </div>
    </div>
  );
}

export function Dialog({ open, ...props }: DialogProps) {
  if (!open) return null;
  return createPortal(<DialogSurface {...props} />, document.body);
}

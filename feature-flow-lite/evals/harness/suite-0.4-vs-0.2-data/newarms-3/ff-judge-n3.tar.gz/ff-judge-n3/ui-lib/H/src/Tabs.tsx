import {
  createContext,
  useCallback,
  useContext,
  useId,
  useLayoutEffect,
  useRef,
  useState,
  type ComponentPropsWithoutRef,
  type KeyboardEvent,
  type MouseEvent,
} from "react";

export type TabsProps = Omit<ComponentPropsWithoutRef<"div">, "defaultValue"> & {
  value?: string;
  defaultValue?: string;
  onValueChange?: (value: string) => void;
};

export type TabListProps = Omit<ComponentPropsWithoutRef<"div">, "role"> & {
  "aria-label": string;
};

export type TabProps = Omit<ComponentPropsWithoutRef<"button">, "type" | "role" | "value" | "disabled"> & {
  value: string;
  disabled?: boolean;
};

export type TabPanelProps = Omit<ComponentPropsWithoutRef<"div">, "role"> & {
  value: string;
};

type TabEntry = { value: string; disabled: boolean; element: HTMLElement };

type TabsContextValue = {
  baseId: string;
  selected: string | null;
  tabStop: string | null;
  select: (value: string) => void;
  register: (entry: TabEntry) => void;
  unregister: (element: HTMLElement) => void;
};

const TabsContext = createContext<TabsContextValue | null>(null);

function useTabsContext(): TabsContextValue {
  const context = useContext(TabsContext);
  if (!context) {
    throw new Error("Tab and TabPanel must be rendered inside <Tabs>");
  }
  return context;
}

const tabId = (baseId: string, value: string) => `${baseId}-tab-${encodeURIComponent(value)}`;
const panelId = (baseId: string, value: string) => `${baseId}-panel-${encodeURIComponent(value)}`;

function byDocumentOrder(a: TabEntry, b: TabEntry): number {
  return a.element.compareDocumentPosition(b.element) & Node.DOCUMENT_POSITION_FOLLOWING ? -1 : 1;
}

export function Tabs({ value, defaultValue, onValueChange, ...rest }: TabsProps) {
  const baseId = useId();
  const [uncontrolled, setUncontrolled] = useState(defaultValue);
  const [entries, setEntries] = useState<TabEntry[]>([]);

  const ordered = [...entries].sort(byDocumentOrder);
  const firstEnabled = ordered.find((entry) => !entry.disabled)?.value ?? null;
  const selected = value ?? uncontrolled ?? firstEnabled;
  const tabStop = ordered.some((entry) => entry.value === selected) ? selected : firstEnabled;

  const select = (next: string) => {
    if (next === selected) return;
    if (value === undefined) setUncontrolled(next);
    onValueChange?.(next);
  };

  const register = useCallback(
    (entry: TabEntry) =>
      setEntries((previous) => [...previous.filter((item) => item.element !== entry.element), entry]),
    [],
  );
  const unregister = useCallback(
    (element: HTMLElement) => setEntries((previous) => previous.filter((item) => item.element !== element)),
    [],
  );

  return (
    <TabsContext.Provider value={{ baseId, selected, tabStop, select, register, unregister }}>
      <div {...rest} />
    </TabsContext.Provider>
  );
}

export function TabList(props: TabListProps) {
  return <div {...props} role="tablist" />;
}

// Returns the tab that an arrow/Home/End key moves focus to, or undefined when the key does nothing.
function nextTab(current: HTMLElement, key: string): HTMLElement | undefined {
  const tablist = current.closest('[role="tablist"]');
  if (!tablist) return undefined;
  const tabs = Array.from(tablist.querySelectorAll<HTMLElement>('[role="tab"]')).filter(
    (tab) => tab.getAttribute("aria-disabled") !== "true",
  );
  const index = tabs.indexOf(current);
  if (index === -1) return undefined;
  switch (key) {
    case "ArrowRight":
      return tabs[(index + 1) % tabs.length];
    case "ArrowLeft":
      return tabs[(index - 1 + tabs.length) % tabs.length];
    case "Home":
      return tabs[0];
    case "End":
      return tabs[tabs.length - 1];
    default:
      return undefined;
  }
}

export function Tab({ value, disabled = false, onClick, onKeyDown, ...rest }: TabProps) {
  const { baseId, selected, tabStop, select, register, unregister } = useTabsContext();
  const ref = useRef<HTMLButtonElement>(null);

  useLayoutEffect(() => {
    const element = ref.current;
    if (!element) return;
    register({ value, disabled, element });
    return () => unregister(element);
  }, [value, disabled, register, unregister]);

  const handleClick = (event: MouseEvent<HTMLButtonElement>) => {
    onClick?.(event);
    if (!disabled) select(value);
  };

  // Focus alone never selects, so tabbing into a tablist does not report a change. Arrow, Home and End
  // keys select the tab they move to; the target's value is read from its data-value attribute.
  const handleKeyDown = (event: KeyboardEvent<HTMLButtonElement>) => {
    onKeyDown?.(event);
    if (event.defaultPrevented) return;
    const target = nextTab(event.currentTarget, event.key);
    if (!target) return;
    event.preventDefault();
    target.focus();
    if (target.dataset.value !== undefined) select(target.dataset.value);
  };

  return (
    <button
      {...rest}
      ref={ref}
      type="button"
      role="tab"
      id={tabId(baseId, value)}
      data-value={value}
      aria-selected={value === selected}
      aria-disabled={disabled}
      aria-controls={panelId(baseId, value)}
      tabIndex={value === tabStop ? 0 : -1}
      onClick={handleClick}
      onKeyDown={handleKeyDown}
    />
  );
}

export function TabPanel({ value, ...rest }: TabPanelProps) {
  const { baseId, selected } = useTabsContext();
  return (
    <div
      {...rest}
      id={panelId(baseId, value)}
      role="tabpanel"
      aria-labelledby={tabId(baseId, value)}
      tabIndex={0}
      hidden={value !== selected}
    />
  );
}

import * as ui from "../src/index";
import type {
  ComboboxOption,
  ComboboxProps,
  DialogProps,
  TabListProps,
  TabPanelProps,
  TabProps,
  TabsProps,
} from "../src/index";

// Compile-time check that every props type is exported from the entry point.
type PublicTypes = [
  TabsProps,
  TabListProps,
  TabProps,
  TabPanelProps,
  DialogProps,
  ComboboxProps,
  ComboboxOption,
];

describe("public exports (G1)", () => {
  it("exports the components from src/index.ts", () => {
    const types: PublicTypes | undefined = undefined;
    expect(types).toBeUndefined();
    expect(Object.keys(ui).sort()).toEqual(["Combobox", "Dialog", "Tab", "TabList", "TabPanel", "Tabs"]);
  });
});

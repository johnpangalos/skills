import { useState } from "react";
import { fireEvent, render, screen } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { Tabs, TabList, Tab, TabPanel } from "../src/index";

function Basic({
  onValueChange,
  defaultValue,
  disabled = [],
}: {
  onValueChange?: (value: string) => void;
  defaultValue?: string;
  disabled?: string[];
}) {
  return (
    <Tabs defaultValue={defaultValue} onValueChange={onValueChange}>
      <TabList aria-label="Sections">
        <Tab value="one">One</Tab>
        <Tab value="two" disabled={disabled.includes("two")}>Two</Tab>
        <Tab value="three" disabled={disabled.includes("three")}>Three</Tab>
      </TabList>
      <TabPanel value="one">Panel one</TabPanel>
      <TabPanel value="two">Panel two</TabPanel>
      <TabPanel value="three">Panel three</TabPanel>
    </Tabs>
  );
}

function Controlled({ onValueChange }: { onValueChange: (value: string) => void }) {
  const [value, setValue] = useState("one");
  return (
    <Tabs
      value={value}
      onValueChange={(next) => {
        onValueChange(next);
        setValue(next);
      }}
    >
      <TabList aria-label="Sections">
        <Tab value="one">One</Tab>
        <Tab value="two">Two</Tab>
      </TabList>
      <TabPanel value="one">Panel one</TabPanel>
      <TabPanel value="two">Panel two</TabPanel>
    </Tabs>
  );
}

describe("Tabs", () => {
  it("renders a tablist with the given aria-label and horizontal orientation", () => {
    render(<Basic />);
    const list = screen.getByRole("tablist", { name: "Sections" });
    expect(list).toHaveAttribute("aria-orientation", "horizontal");
  });

  it("selects the first enabled tab when no defaultValue is given", () => {
    render(
      <Tabs>
        <TabList aria-label="Sections">
          <Tab value="one" disabled>One</Tab>
          <Tab value="two">Two</Tab>
        </TabList>
        <TabPanel value="two">Panel two</TabPanel>
      </Tabs>,
    );
    expect(screen.getByRole("tab", { name: "Two" })).toHaveAttribute("aria-selected", "true");
    expect(screen.getByRole("tab", { name: "One" })).toHaveAttribute("aria-selected", "false");
    expect(screen.getByRole("tabpanel")).toHaveTextContent("Panel two");
  });

  it("starts uncontrolled at defaultValue", () => {
    render(<Basic defaultValue="three" />);
    expect(screen.getByRole("tab", { name: "Three" })).toHaveAttribute("aria-selected", "true");
    expect(screen.getByRole("tabpanel")).toHaveTextContent("Panel three");
  });

  it("links each tab to its panel and the panel back to its tab", () => {
    render(<Basic />);
    const tab = screen.getByRole("tab", { name: "One" });
    const panel = screen.getByRole("tabpanel");
    expect(tab).toHaveAttribute("aria-controls", panel.id);
    expect(panel).toHaveAttribute("aria-labelledby", tab.id);
    expect(panel).toHaveAttribute("tabindex", "0");
  });

  it("renders every panel and hides the unselected ones", () => {
    render(<Basic />);
    expect(screen.getAllByRole("tabpanel", { hidden: true })).toHaveLength(3);
    expect(screen.getByText("Panel one")).toBeVisible();
    expect(screen.getByText("Panel two")).not.toBeVisible();
    expect(screen.getByText("Panel two")).toHaveAttribute("hidden");
  });

  it("resolves every tab's aria-controls to its panel in the DOM", () => {
    render(<Basic />);
    for (const tab of screen.getAllByRole("tab")) {
      const panel = document.getElementById(tab.getAttribute("aria-controls") ?? "");
      expect(panel).toHaveAttribute("role", "tabpanel");
      expect(panel).toHaveAttribute("aria-labelledby", tab.id);
    }
  });

  it("gives tabs with special-character values valid, matching ids", () => {
    render(
      <Tabs defaultValue="a b_c">
        <TabList aria-label="Odd">
          <Tab value="a b_c">Odd</Tab>
          <Tab value="a_b c">Other</Tab>
        </TabList>
        <TabPanel value="a b_c">Odd panel</TabPanel>
      </Tabs>,
    );
    const tab = screen.getByRole("tab", { name: "Odd" });
    expect(tab.id).not.toMatch(/\s/);
    expect(tab.id).not.toBe(screen.getByRole("tab", { name: "Other" }).id);
    expect(screen.getByRole("tabpanel")).toHaveAttribute("aria-labelledby", tab.id);
  });

  it("keeps two Tabs instances from sharing ids", () => {
    render(
      <>
        <Basic />
        <Basic />
      </>,
    );
    const ids = screen.getAllByRole("tab").map((tab) => tab.id);
    expect(new Set(ids).size).toBe(ids.length);
  });

  it("uses a roving tabindex with only the selected tab in the tab order", () => {
    render(<Basic defaultValue="two" />);
    expect(screen.getByRole("tab", { name: "Two" })).toHaveAttribute("tabindex", "0");
    expect(screen.getByRole("tab", { name: "One" })).toHaveAttribute("tabindex", "-1");
    expect(screen.getByRole("tab", { name: "Three" })).toHaveAttribute("tabindex", "-1");
  });

  it("puts tabIndex 0 on the first enabled tab when the selected value matches no tab", () => {
    render(
      <Tabs value="missing">
        <TabList aria-label="Sections">
          <Tab value="one">One</Tab>
          <Tab value="two">Two</Tab>
        </TabList>
      </Tabs>,
    );
    expect(screen.getByRole("tab", { name: "One" })).toHaveAttribute("tabindex", "0");
    expect(screen.getByRole("tab", { name: "Two" })).toHaveAttribute("tabindex", "-1");
  });

  it("moves focus and selection with ArrowRight and ArrowLeft, wrapping at the ends", async () => {
    const user = userEvent.setup();
    const onValueChange = vi.fn();
    render(<Basic onValueChange={onValueChange} />);
    screen.getByRole("tab", { name: "One" }).focus();

    await user.keyboard("{ArrowRight}");
    expect(screen.getByRole("tab", { name: "Two" })).toHaveFocus();
    expect(screen.getByRole("tab", { name: "Two" })).toHaveAttribute("aria-selected", "true");
    expect(onValueChange).toHaveBeenLastCalledWith("two");

    await user.keyboard("{ArrowRight}{ArrowRight}");
    expect(screen.getByRole("tab", { name: "One" })).toHaveFocus();

    await user.keyboard("{ArrowLeft}");
    expect(screen.getByRole("tab", { name: "Three" })).toHaveFocus();
    expect(onValueChange).toHaveBeenLastCalledWith("three");
  });

  it("moves to the first and last enabled tabs with Home and End", async () => {
    const user = userEvent.setup();
    render(<Basic />);
    screen.getByRole("tab", { name: "One" }).focus();

    await user.keyboard("{End}");
    expect(screen.getByRole("tab", { name: "Three" })).toHaveFocus();
    expect(screen.getByRole("tab", { name: "Three" })).toHaveAttribute("aria-selected", "true");

    await user.keyboard("{Home}");
    expect(screen.getByRole("tab", { name: "One" })).toHaveFocus();
    expect(screen.getByRole("tab", { name: "One" })).toHaveAttribute("aria-selected", "true");
  });

  it("ignores other keys", async () => {
    const user = userEvent.setup();
    const onValueChange = vi.fn();
    render(<Basic onValueChange={onValueChange} />);
    screen.getByRole("tab", { name: "One" }).focus();
    await user.keyboard("a{PageDown}");
    expect(onValueChange).not.toHaveBeenCalled();
    expect(screen.getByRole("tab", { name: "One" })).toHaveFocus();
  });

  it("skips a disabled tab in the middle and one at the wrap boundary", async () => {
    const user = userEvent.setup();
    const { unmount } = render(<Basic disabled={["two"]} />);
    screen.getByRole("tab", { name: "One" }).focus();
    await user.keyboard("{ArrowRight}");
    expect(screen.getByRole("tab", { name: "Three" })).toHaveFocus();
    unmount();

    render(<Basic defaultValue="one" disabled={["three"]} />);
    screen.getByRole("tab", { name: "One" }).focus();
    await user.keyboard("{ArrowLeft}");
    expect(screen.getByRole("tab", { name: "Two" })).toHaveFocus();
  });

  it("does nothing with arrows when every tab is disabled", async () => {
    const user = userEvent.setup();
    const onValueChange = vi.fn();
    render(
      <Tabs onValueChange={onValueChange}>
        <TabList aria-label="Sections">
          <Tab value="one" disabled>One</Tab>
          <Tab value="two" disabled>Two</Tab>
        </TabList>
      </Tabs>,
    );
    expect(screen.getByRole("tab", { name: "One" })).toHaveAttribute("tabindex", "-1");
    const tab = screen.getByRole("tab", { name: "One" });
    fireEvent.keyDown(tab, { key: "ArrowRight" });
    fireEvent.keyDown(tab, { key: "Home" });
    fireEvent.keyDown(tab, { key: "End" });
    expect(onValueChange).not.toHaveBeenCalled();
    expect(screen.getByRole("tablist")).not.toHaveFocus();
  });

  it("keeps focus on the only enabled tab when arrows are pressed", async () => {
    const user = userEvent.setup();
    const onValueChange = vi.fn();
    render(
      <Tabs onValueChange={onValueChange}>
        <TabList aria-label="Sections">
          <Tab value="one">One</Tab>
          <Tab value="two" disabled>Two</Tab>
        </TabList>
      </Tabs>,
    );
    screen.getByRole("tab", { name: "One" }).focus();
    await user.keyboard("{ArrowRight}");
    expect(screen.getByRole("tab", { name: "One" })).toHaveFocus();
    await user.keyboard("{ArrowLeft}");
    expect(screen.getByRole("tab", { name: "One" })).toHaveFocus();
    expect(onValueChange).not.toHaveBeenCalled();
  });

  it("keeps the selection put in controlled mode while still calling onValueChange", async () => {
    const user = userEvent.setup();
    const onValueChange = vi.fn();
    render(
      <Tabs value="one" onValueChange={onValueChange}>
        <TabList aria-label="Sections">
          <Tab value="one">One</Tab>
          <Tab value="two">Two</Tab>
        </TabList>
        <TabPanel value="one">Panel one</TabPanel>
      </Tabs>,
    );
    screen.getByRole("tab", { name: "One" }).focus();
    await user.keyboard("{ArrowRight}");
    expect(onValueChange).toHaveBeenCalledWith("two");
    expect(screen.getByRole("tab", { name: "One" })).toHaveAttribute("aria-selected", "true");
    expect(screen.getByRole("tab", { name: "Two" })).toHaveAttribute("aria-selected", "false");
  });

  it("follows the parent when a controlled value is updated", async () => {
    const user = userEvent.setup();
    const onValueChange = vi.fn();
    render(<Controlled onValueChange={onValueChange} />);
    screen.getByRole("tab", { name: "One" }).focus();
    await user.keyboard("{ArrowRight}");
    expect(screen.getByRole("tab", { name: "Two" })).toHaveAttribute("aria-selected", "true");
    expect(screen.getByRole("tabpanel")).toHaveTextContent("Panel two");
  });

  it("selects a tab on click and never selects a disabled one", async () => {
    const user = userEvent.setup();
    const onValueChange = vi.fn();
    render(<Basic onValueChange={onValueChange} disabled={["two"]} />);
    await user.click(screen.getByRole("tab", { name: "Two" }));
    expect(onValueChange).not.toHaveBeenCalled();
    await user.click(screen.getByRole("tab", { name: "Three" }));
    expect(onValueChange).toHaveBeenCalledWith("three");
    expect(screen.getByRole("tab", { name: "Three" })).toHaveAttribute("aria-selected", "true");
  });

  it("throws a clear error when a Tab is rendered outside Tabs", () => {
    const spy = vi.spyOn(console, "error").mockImplementation(() => {});
    expect(() => render(<Tab value="x">X</Tab>)).toThrow(
      "Tab, TabList and TabPanel must be rendered inside <Tabs>",
    );
    spy.mockRestore();
  });
});

import { render, screen } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { useState } from "react";
import * as lib from "./index";
import {
  Tab,
  TabList,
  TabPanel,
  Tabs,
  type TabListProps,
  type TabPanelProps,
  type TabProps,
  type TabsProps,
} from "./index";

function Settings({ disabledTabs = [], ...props }: Omit<TabsProps, "children"> & { disabledTabs?: string[] }) {
  return (
    <Tabs {...props}>
      <TabList aria-label="Settings">
        <Tab value="a" disabled={disabledTabs.includes("a")}>
          Account
        </Tab>
        <Tab value="b" disabled={disabledTabs.includes("b")}>
          Billing
        </Tab>
        <Tab value="c" disabled={disabledTabs.includes("c")}>
          Contact
        </Tab>
      </TabList>
      <TabPanel value="a">Account panel</TabPanel>
      <TabPanel value="b">Billing panel</TabPanel>
      <TabPanel value="c">Contact panel</TabPanel>
    </Tabs>
  );
}

function ControlledSettings() {
  const [value, setValue] = useState("a");
  return <Settings value={value} onValueChange={setValue} />;
}

function Dynamic({ values }: { values: string[] }) {
  return (
    <Tabs defaultValue="a">
      <TabList aria-label="Dynamic">
        {values.map((value) => (
          <Tab key={value} value={value}>
            {value}
          </Tab>
        ))}
      </TabList>
      {values.map((value) => (
        <TabPanel key={value} value={value}>
          {value} panel
        </TabPanel>
      ))}
    </Tabs>
  );
}

function Values({ onValueChange }: { onValueChange: (value: string) => void }) {
  return (
    <Tabs defaultValue="1" onValueChange={onValueChange}>
      <TabList aria-label="Values">
        <Tab value="">Empty</Tab>
        <Tab value="1">One</Tab>
        <Tab value="10">Ten</Tab>
      </TabList>
      <TabPanel value="">Empty panel</TabPanel>
      <TabPanel value="1">One panel</TabPanel>
      <TabPanel value="10">Ten panel</TabPanel>
    </Tabs>
  );
}

const tab = (name: string) => screen.getByRole("tab", { name });

describe("Tabs", () => {
  it("G1 index exports Tabs, TabList, Tab and TabPanel with their prop types", () => {
    const propTypes: [TabsProps, TabListProps, TabProps, TabPanelProps] = [{}, {}, { value: "a" }, { value: "a" }];
    expect(propTypes).toHaveLength(4);
    expect(lib.Tabs).toBeTypeOf("function");
    expect(lib.TabList).toBeTypeOf("function");
    expect(lib.Tab).toBeTypeOf("function");
    expect(lib.TabPanel).toBeTypeOf("function");
  });

  it("G2 forwards className and other HTML props to each main element", () => {
    render(
      <Tabs className="root" data-testid="root" defaultValue="a">
        <TabList aria-label="Settings" className="list" data-testid="list">
          <Tab value="a" className="tab" data-testid="tab">
            Account
          </Tab>
        </TabList>
        <TabPanel value="a" className="panel" data-testid="panel">
          Account panel
        </TabPanel>
      </Tabs>,
    );
    expect(screen.getByTestId("root")).toHaveClass("root");
    expect(screen.getByTestId("list")).toHaveClass("list");
    expect(screen.getByTestId("tab")).toHaveClass("tab");
    expect(screen.getByTestId("panel")).toHaveClass("panel");
  });

  it("G2 two Tabs on one page do not share ids", () => {
    render(
      <>
        <Settings />
        <Settings />
      </>,
    );
    const tabs = screen.getAllByRole("tab");
    const panels = screen.getAllByRole("tabpanel", { hidden: true });
    const ids = [...tabs, ...panels].map((element) => element.id);
    expect(new Set(ids).size).toBe(ids.length);
    for (const element of tabs) {
      expect(document.getElementById(element.getAttribute("aria-controls") ?? "")).not.toBeNull();
    }
  });

  it("T1 renders a labelled tablist, button tabs and tabpanels", () => {
    render(<Settings />);
    expect(screen.getByRole("tablist", { name: "Settings" })).toBeInTheDocument();
    const tabs = screen.getAllByRole("tab");
    expect(tabs).toHaveLength(3);
    for (const element of tabs) {
      expect(element.tagName).toBe("BUTTON");
      expect(element).toHaveAttribute("type", "button");
    }
    expect(screen.getAllByRole("tabpanel", { hidden: true })).toHaveLength(3);
  });

  it("T1 links each tab to its panel and reports aria-selected", () => {
    render(<Settings defaultValue="b" />);
    const billing = tab("Billing");
    expect(billing.id).not.toBe("");
    expect(billing).toHaveAttribute("aria-selected", "true");
    expect(tab("Account")).toHaveAttribute("aria-selected", "false");
    const panel = screen.getByRole("tabpanel");
    expect(panel.id).not.toBe("");
    expect(billing).toHaveAttribute("aria-controls", panel.id);
    expect(panel).toHaveAttribute("aria-labelledby", billing.id);
    expect(panel).toHaveTextContent("Billing panel");
  });

  it("T1 a disabled tab is disabled and clicking it does not select it", async () => {
    const user = userEvent.setup();
    const onValueChange = vi.fn();
    render(<Settings disabledTabs={["b"]} onValueChange={onValueChange} />);
    expect(tab("Billing")).toBeDisabled();
    await user.click(tab("Billing"));
    expect(onValueChange).not.toHaveBeenCalled();
    expect(tab("Billing")).toHaveAttribute("aria-selected", "false");
  });

  it("T2 only the selected tab is in the tab order", () => {
    render(<Settings defaultValue="b" />);
    expect(tab("Billing")).toHaveAttribute("tabindex", "0");
    expect(tab("Account")).toHaveAttribute("tabindex", "-1");
    expect(tab("Contact")).toHaveAttribute("tabindex", "-1");
  });

  it("T2 only the selected panel is visible and it has tabIndex 0", () => {
    render(<Settings defaultValue="b" />);
    const panels = screen.getAllByRole("tabpanel", { hidden: true });
    expect(panels[0]).not.toBeVisible();
    expect(panels[1]).toBeVisible();
    expect(panels[2]).not.toBeVisible();
    expect(panels[1]).toHaveAttribute("tabindex", "0");
    expect(screen.getByRole("tabpanel")).toHaveTextContent("Billing panel");
  });

  it("T3 defaultValue selects that tab initially", () => {
    render(<Settings defaultValue="c" />);
    expect(tab("Contact")).toHaveAttribute("aria-selected", "true");
    expect(screen.getByRole("tabpanel")).toHaveTextContent("Contact panel");
  });

  it("T3 with no defaultValue the first enabled tab is selected", () => {
    render(<Settings disabledTabs={["a"]} />);
    expect(tab("Billing")).toHaveAttribute("aria-selected", "true");
    expect(tab("Account")).toHaveAttribute("aria-selected", "false");
    expect(screen.getByRole("tabpanel")).toHaveTextContent("Billing panel");
  });

  it("T3 clicking a tab selects it and calls onValueChange with its value", async () => {
    const user = userEvent.setup();
    const onValueChange = vi.fn();
    render(<Settings defaultValue="a" onValueChange={onValueChange} />);
    await user.click(tab("Contact"));
    expect(onValueChange).toHaveBeenCalledTimes(1);
    expect(onValueChange).toHaveBeenCalledWith("c");
    expect(tab("Contact")).toHaveAttribute("aria-selected", "true");
    expect(screen.getByRole("tabpanel")).toHaveTextContent("Contact panel");
  });

  it("T4 controlled: value wins, clicking calls onValueChange but selection does not change", async () => {
    const user = userEvent.setup();
    const onValueChange = vi.fn();
    render(<Settings value="a" onValueChange={onValueChange} />);
    await user.click(tab("Billing"));
    expect(onValueChange).toHaveBeenCalledWith("b");
    expect(tab("Account")).toHaveAttribute("aria-selected", "true");
    expect(tab("Billing")).toHaveAttribute("aria-selected", "false");
    expect(screen.getByRole("tabpanel")).toHaveTextContent("Account panel");
  });

  it("T4 controlled: arrow keys move focus and call onValueChange without changing selection", async () => {
    const user = userEvent.setup();
    const onValueChange = vi.fn();
    render(<Settings value="a" onValueChange={onValueChange} />);
    await user.tab();
    await user.keyboard("{ArrowRight}");
    expect(tab("Billing")).toHaveFocus();
    expect(onValueChange).toHaveBeenCalledWith("b");
    expect(tab("Account")).toHaveAttribute("aria-selected", "true");
  });

  it("T4 controlled: when the parent updates value the selection follows", async () => {
    const user = userEvent.setup();
    render(<ControlledSettings />);
    await user.click(tab("Billing"));
    expect(tab("Billing")).toHaveAttribute("aria-selected", "true");
    expect(screen.getByRole("tabpanel")).toHaveTextContent("Billing panel");
  });

  it("T5 ArrowRight and ArrowLeft move focus and selection to the next and previous tab, wrapping at both ends", async () => {
    const user = userEvent.setup();
    const onValueChange = vi.fn();
    render(<Settings defaultValue="a" onValueChange={onValueChange} />);
    await user.tab();
    await user.keyboard("{ArrowRight}");
    expect(tab("Billing")).toHaveFocus();
    expect(tab("Billing")).toHaveAttribute("aria-selected", "true");
    await user.keyboard("{ArrowRight}{ArrowRight}");
    expect(tab("Account")).toHaveFocus();
    await user.keyboard("{ArrowLeft}");
    expect(tab("Contact")).toHaveFocus();
    expect(onValueChange.mock.calls).toEqual([["b"], ["c"], ["a"], ["c"]]);
  });

  it("T5 ArrowRight and ArrowLeft skip disabled tabs", async () => {
    const user = userEvent.setup();
    render(<Settings defaultValue="a" disabledTabs={["b"]} />);
    await user.tab();
    await user.keyboard("{ArrowRight}");
    expect(tab("Contact")).toHaveFocus();
    await user.keyboard("{ArrowLeft}");
    expect(tab("Account")).toHaveFocus();
  });

  it("T5 Home and End move focus and selection to the first and last enabled tab", async () => {
    const user = userEvent.setup();
    const onValueChange = vi.fn();
    render(<Settings defaultValue="b" onValueChange={onValueChange} />);
    await user.tab();
    await user.keyboard("{End}");
    expect(tab("Contact")).toHaveFocus();
    expect(tab("Contact")).toHaveAttribute("aria-selected", "true");
    await user.keyboard("{Home}");
    expect(tab("Account")).toHaveFocus();
    expect(onValueChange.mock.calls).toEqual([["c"], ["a"]]);
  });

  it("T5 other keys do nothing", async () => {
    const user = userEvent.setup();
    const onValueChange = vi.fn();
    render(<Settings defaultValue="a" onValueChange={onValueChange} />);
    await user.tab();
    await user.keyboard("{ArrowDown}{PageDown}x");
    expect(tab("Account")).toHaveFocus();
    expect(tab("Account")).toHaveAttribute("aria-selected", "true");
    expect(onValueChange).not.toHaveBeenCalled();
  });

  it("T5 keys do not move tabs when focus is inside a panel", async () => {
    const user = userEvent.setup();
    const onValueChange = vi.fn();
    render(
      <Tabs defaultValue="a" onValueChange={onValueChange}>
        <TabList aria-label="Settings">
          <Tab value="a">Account</Tab>
          <Tab value="b">Billing</Tab>
        </TabList>
        <TabPanel value="a">
          <button>Save</button>
        </TabPanel>
      </Tabs>,
    );
    screen.getByRole("tabpanel").focus();
    await user.keyboard("{ArrowRight}");
    expect(screen.getByRole("tabpanel")).toHaveFocus();
    expect(onValueChange).not.toHaveBeenCalled();
  });

  it("T5 hostile: when all tabs but one are disabled, arrows and Home/End stay on that tab", async () => {
    const user = userEvent.setup();
    const onValueChange = vi.fn();
    render(<Settings defaultValue="b" disabledTabs={["a", "c"]} onValueChange={onValueChange} />);
    await user.tab();
    await user.keyboard("{ArrowRight}{ArrowLeft}{Home}{End}");
    expect(tab("Billing")).toHaveFocus();
    expect(onValueChange).not.toHaveBeenCalled();
  });

  it("T5 hostile: Home and End skip disabled tabs at both ends", async () => {
    const user = userEvent.setup();
    render(
      <Tabs defaultValue="b">
        <TabList aria-label="Four">
          <Tab value="a" disabled>
            A
          </Tab>
          <Tab value="b">B</Tab>
          <Tab value="c">C</Tab>
          <Tab value="d" disabled>
            D
          </Tab>
        </TabList>
      </Tabs>,
    );
    await user.tab();
    expect(tab("B")).toHaveFocus();
    await user.keyboard("{End}");
    expect(tab("C")).toHaveFocus();
    await user.keyboard("{Home}");
    expect(tab("B")).toHaveFocus();
  });

  it("T5 hostile: values '' and numeric-looking strings are compared as strings", async () => {
    const user = userEvent.setup();
    const onValueChange = vi.fn();
    render(<Values onValueChange={onValueChange} />);
    expect(tab("One")).toHaveAttribute("aria-selected", "true");
    await user.tab();
    await user.keyboard("{ArrowLeft}");
    expect(tab("Empty")).toHaveFocus();
    expect(tab("Empty")).toHaveAttribute("aria-selected", "true");
    expect(screen.getByRole("tabpanel")).toHaveTextContent("Empty panel");
    await user.keyboard("{ArrowRight}{ArrowRight}");
    expect(tab("Ten")).toHaveFocus();
    expect(tab("Ten")).toHaveAttribute("aria-selected", "true");
    expect(onValueChange.mock.calls).toEqual([[""], ["1"], ["10"]]);
  });

  it("T5 hostile: tabs inserted or removed later are ordered by DOM position, not mount order", async () => {
    const user = userEvent.setup();
    const { rerender } = render(<Dynamic values={["a", "c"]} />);
    rerender(<Dynamic values={["a", "b", "c"]} />);
    await user.tab();
    expect(tab("a")).toHaveFocus();
    await user.keyboard("{ArrowRight}");
    expect(tab("b")).toHaveFocus();
    await user.keyboard("{ArrowRight}");
    expect(tab("c")).toHaveFocus();
    rerender(<Dynamic values={["a", "c"]} />);
    await user.keyboard("{ArrowLeft}");
    expect(tab("a")).toHaveFocus();
  });

  it("T5 hostile: defaultValue naming no tab leaves the first enabled tab in the tab order", async () => {
    const user = userEvent.setup();
    render(<Settings defaultValue="nope" />);
    expect(tab("Account")).toHaveAttribute("tabindex", "0");
    expect(tab("Billing")).toHaveAttribute("tabindex", "-1");
    await user.tab();
    expect(tab("Account")).toHaveFocus();
  });

  it("T5 hostile: defaultValue naming no tab with a disabled first tab uses the first enabled tab", () => {
    render(<Settings defaultValue="nope" disabledTabs={["a"]} />);
    expect(tab("Billing")).toHaveAttribute("tabindex", "0");
    expect(tab("Contact")).toHaveAttribute("tabindex", "-1");
  });

  it("T2 hostile: hiding the selected tab from a child's state leaves exactly one tab stop", async () => {
    const user = userEvent.setup();
    render(<WithToggle initialOn defaultValue="c" />);
    expect(tab("C")).toHaveAttribute("tabindex", "0");
    await user.click(screen.getByRole("button", { name: "Toggle C" }));
    expect(screen.queryByRole("tab", { name: "C" })).toBeNull();
    const stops = screen.getAllByRole("tab").filter((element) => element.tabIndex === 0);
    expect(stops).toHaveLength(1);
    expect(stops[0]).toBe(tab("A"));
  });

  it("T2 hostile: adding the selected tab from a child's state moves the tab stop to it", async () => {
    const user = userEvent.setup();
    render(<WithToggle initialOn={false} defaultValue="c" />);
    expect(tab("A")).toHaveAttribute("tabindex", "0");
    await user.click(screen.getByRole("button", { name: "Toggle C" }));
    expect(tab("C")).toHaveAttribute("tabindex", "0");
    expect(tab("A")).toHaveAttribute("tabindex", "-1");
  });

  it("T2 hostile: a defaultValue naming no tab shows the fallback tab as selected, with its panel", () => {
    render(<Settings defaultValue="nope" />);
    expect(tab("Account")).toHaveAttribute("aria-selected", "true");
    expect(screen.getByRole("tabpanel")).toHaveTextContent("Account panel");
  });

  it("T2 hostile: a defaultValue naming no tab selects the first enabled tab when the first is disabled", () => {
    render(<Settings defaultValue="nope" disabledTabs={["a"]} />);
    expect(tab("Billing")).toHaveAttribute("aria-selected", "true");
    expect(screen.getByRole("tabpanel")).toHaveTextContent("Billing panel");
  });

  it("T4 hostile: a controlled value naming no tab shows the fallback tab as selected, with its panel", () => {
    render(<Settings value="nope" onValueChange={vi.fn()} />);
    expect(tab("Account")).toHaveAttribute("aria-selected", "true");
    expect(tab("Account")).toHaveAttribute("tabindex", "0");
    expect(screen.getByRole("tabpanel")).toHaveTextContent("Account panel");
  });
});

function Toggle({ initialOn }: { initialOn: boolean }) {
  const [on, setOn] = useState(initialOn);
  return (
    <>
      <button onClick={() => setOn(!on)}>Toggle C</button>
      {on && <Tab value="c">C</Tab>}
    </>
  );
}

function WithToggle({ initialOn, defaultValue }: { initialOn: boolean; defaultValue: string }) {
  return (
    <Tabs defaultValue={defaultValue}>
      <TabList aria-label="Toggled">
        <Tab value="a">A</Tab>
        <Toggle initialOn={initialOn} />
      </TabList>
      <TabPanel value="a">A panel</TabPanel>
      <TabPanel value="c">C panel</TabPanel>
    </Tabs>
  );
}

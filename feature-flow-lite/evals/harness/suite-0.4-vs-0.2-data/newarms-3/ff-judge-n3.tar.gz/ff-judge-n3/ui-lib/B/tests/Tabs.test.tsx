import { fireEvent, render, screen } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { renderToStaticMarkup } from "react-dom/server";
import { Tab, TabList, TabPanel, Tabs, type TabsProps } from "../src/index";

type SampleProps = Partial<TabsProps> & { values?: string[]; disabled?: string[] };

function SampleTabs({ values = ["one", "two", "three"], disabled = [], ...props }: SampleProps) {
  return (
    <Tabs {...props}>
      <TabList aria-label="Sections">
        {values.map((value) => (
          <Tab key={value} value={value} disabled={disabled.includes(value)}>
            {value}
          </Tab>
        ))}
      </TabList>
      {values.map((value) => (
        <TabPanel key={value} value={value}>
          panel {value}
        </TabPanel>
      ))}
    </Tabs>
  );
}

const tab = (name: string) => screen.getByRole("tab", { name });

function panelOf(tabEl: HTMLElement): HTMLElement {
  const panel = document.getElementById(tabEl.getAttribute("aria-controls") ?? "");
  if (!panel) throw new Error(`no panel for ${tabEl.textContent}`);
  return panel;
}

describe("Tabs selection (T1)", () => {
  it("uses defaultValue when uncontrolled and reports the new value on click", async () => {
    const user = userEvent.setup();
    const onValueChange = vi.fn();
    render(<SampleTabs defaultValue="two" onValueChange={onValueChange} />);
    expect(tab("two")).toHaveAttribute("aria-selected", "true");
    await user.click(tab("three"));
    expect(tab("three")).toHaveAttribute("aria-selected", "true");
    expect(tab("two")).toHaveAttribute("aria-selected", "false");
    expect(onValueChange).toHaveBeenCalledWith("three");
  });

  it("selects the first non-disabled tab when there is no default or value", () => {
    render(<SampleTabs disabled={["one"]} />);
    expect(tab("two")).toHaveAttribute("aria-selected", "true");
    expect(tab("one")).toHaveAttribute("aria-selected", "false");
  });

  it("keeps the old tab when a controlled parent ignores onValueChange", async () => {
    const user = userEvent.setup();
    const onValueChange = vi.fn();
    render(<SampleTabs value="one" onValueChange={onValueChange} />);
    await user.click(tab("two"));
    expect(onValueChange).toHaveBeenCalledWith("two");
    expect(tab("one")).toHaveAttribute("aria-selected", "true");
    expect(tab("two")).toHaveAttribute("aria-selected", "false");
  });

  it("follows the value prop when controlled", () => {
    const { rerender } = render(<SampleTabs value="one" />);
    rerender(<SampleTabs value="three" />);
    expect(tab("three")).toHaveAttribute("aria-selected", "true");
  });

  it("does not call onValueChange when re-selecting the current tab", async () => {
    const user = userEvent.setup();
    const onValueChange = vi.fn();
    render(<SampleTabs defaultValue="one" onValueChange={onValueChange} />);
    await user.click(tab("one"));
    expect(onValueChange).not.toHaveBeenCalled();
  });
});

describe("Tabs roles and ARIA (T2)", () => {
  it("wires tablist, tab and tabpanel roles, aria-controls and aria-labelledby", () => {
    render(<SampleTabs />);
    expect(screen.getByRole("tablist", { name: "Sections" })).toBeInTheDocument();
    for (const name of ["one", "two", "three"]) {
      const t = tab(name);
      expect(t.tagName).toBe("BUTTON");
      expect(t).toHaveAttribute("type", "button");
      const panel = panelOf(t);
      expect(panel).toHaveAttribute("role", "tabpanel");
      expect(panel).toHaveAttribute("aria-labelledby", t.id);
      expect(panel.tabIndex).toBe(0);
    }
  });

  it("shows only the selected panel", () => {
    render(<SampleTabs defaultValue="two" />);
    expect(screen.getByRole("tabpanel")).toHaveTextContent("panel two");
    expect(panelOf(tab("one"))).toHaveAttribute("hidden");
  });

  it("marks disabled tabs and does not select them on click", async () => {
    const user = userEvent.setup();
    render(<SampleTabs disabled={["two"]} />);
    expect(tab("two")).toBeDisabled();
    await user.click(tab("two"));
    expect(tab("two")).toHaveAttribute("aria-selected", "false");
    expect(tab("one")).toHaveAttribute("aria-selected", "true");
  });

  it("generates whitespace-free, unique ids for special-character values across two instances", () => {
    render(
      <>
        <SampleTabs values={["a b", "x/y"]} />
        <SampleTabs values={["a b", "x/y"]} />
      </>,
    );
    const tabs = screen.getAllByRole("tab");
    const ids = tabs.map((t) => t.id);
    expect(new Set(ids).size).toBe(4);
    for (const id of ids) expect(id).toMatch(/^\S+$/);
    for (const t of tabs) {
      expect(panelOf(t)).toHaveAttribute("aria-labelledby", t.id);
    }
  });
});

describe("Tabs tab order (T3)", () => {
  it("gives tabIndex 0 only to the selected tab", () => {
    render(<SampleTabs defaultValue="two" />);
    expect(tab("two").tabIndex).toBe(0);
    expect(tab("one").tabIndex).toBe(-1);
    expect(tab("three").tabIndex).toBe(-1);
  });

  it("lands Tab on the selected tab, then moves to the panel", async () => {
    const user = userEvent.setup();
    render(<SampleTabs defaultValue="two" />);
    await user.tab();
    expect(tab("two")).toHaveFocus();
    await user.tab();
    expect(panelOf(tab("two"))).toHaveFocus();
  });
});

describe("Tabs keyboard (T4)", () => {
  it("ArrowRight and ArrowLeft move focus and selection", async () => {
    const user = userEvent.setup();
    const onValueChange = vi.fn();
    render(<SampleTabs defaultValue="one" onValueChange={onValueChange} />);
    await user.tab();
    await user.keyboard("{ArrowRight}");
    expect(tab("two")).toHaveFocus();
    expect(tab("two")).toHaveAttribute("aria-selected", "true");
    expect(onValueChange).toHaveBeenLastCalledWith("two");
    await user.keyboard("{ArrowLeft}");
    expect(tab("one")).toHaveFocus();
  });

  it("wraps at both ends", async () => {
    const user = userEvent.setup();
    render(<SampleTabs defaultValue="one" />);
    await user.tab();
    await user.keyboard("{ArrowLeft}");
    expect(tab("three")).toHaveFocus();
    await user.keyboard("{ArrowRight}");
    expect(tab("one")).toHaveFocus();
  });

  it("Home and End move to the first and last tab", async () => {
    const user = userEvent.setup();
    render(<SampleTabs defaultValue="one" />);
    await user.tab();
    await user.keyboard("{End}");
    expect(tab("three")).toHaveFocus();
    expect(tab("three")).toHaveAttribute("aria-selected", "true");
    await user.keyboard("{Home}");
    expect(tab("one")).toHaveFocus();
  });

  it("skips disabled tabs when arrowing", async () => {
    const user = userEvent.setup();
    render(<SampleTabs defaultValue="one" disabled={["two"]} />);
    await user.tab();
    await user.keyboard("{ArrowRight}");
    expect(tab("three")).toHaveFocus();
    await user.keyboard("{ArrowLeft}");
    expect(tab("one")).toHaveFocus();
  });

  it("ignores other keys and calls preventDefault only for arrow keys", async () => {
    const user = userEvent.setup();
    const onValueChange = vi.fn();
    render(<SampleTabs defaultValue="one" onValueChange={onValueChange} />);
    await user.tab();
    await user.keyboard("a");
    expect(tab("one")).toHaveFocus();
    expect(onValueChange).not.toHaveBeenCalled();
    expect(fireEvent.keyDown(tab("one"), { key: "a" })).toBe(true);
    expect(fireEvent.keyDown(tab("one"), { key: "ArrowRight" })).toBe(false);
  });
});

describe("Tabs hostile keyboard cases (T5)", () => {
  it("keeps focus on the only enabled tab when all others are disabled", async () => {
    const user = userEvent.setup();
    render(<SampleTabs disabled={["one", "three"]} />);
    await user.tab();
    expect(tab("two")).toHaveFocus();
    await user.keyboard("{ArrowRight}{ArrowLeft}{Home}{End}");
    expect(tab("two")).toHaveFocus();
    expect(tab("two")).toHaveAttribute("aria-selected", "true");
  });

  it("Home and End land on the first and last enabled tab when those are disabled", async () => {
    const user = userEvent.setup();
    render(<SampleTabs values={["one", "two", "three", "four"]} disabled={["one", "four"]} />);
    await user.tab();
    expect(tab("two")).toHaveFocus();
    await user.keyboard("{End}");
    expect(tab("three")).toHaveFocus();
    await user.keyboard("{Home}");
    expect(tab("two")).toHaveFocus();
  });

  it("wraps past disabled first and last tabs", async () => {
    const user = userEvent.setup();
    render(<SampleTabs values={["one", "two", "three", "four"]} disabled={["one", "four"]} />);
    await user.tab();
    await user.keyboard("{ArrowLeft}");
    expect(tab("three")).toHaveFocus();
    await user.keyboard("{ArrowRight}");
    expect(tab("two")).toHaveFocus();
  });

  it("falls back to the first enabled tab when defaultValue matches no tab", async () => {
    const user = userEvent.setup();
    render(<SampleTabs defaultValue="nope" />);
    expect(tab("one")).toHaveAttribute("aria-selected", "true");
    expect(tab("one").tabIndex).toBe(0);
    await user.tab();
    expect(tab("one")).toHaveFocus();
  });

  it("follows DOM order when a tab is inserted after mount", async () => {
    const user = userEvent.setup();
    const { rerender } = render(<SampleTabs values={["a", "b", "c"]} />);
    rerender(<SampleTabs values={["a", "x", "b", "c"]} />);
    await user.tab();
    await user.keyboard("{ArrowRight}");
    expect(tab("x")).toHaveFocus();
    await user.keyboard("{ArrowRight}");
    expect(tab("b")).toHaveFocus();
  });

  it("follows DOM order when a tab is removed after mount", async () => {
    const user = userEvent.setup();
    const { rerender } = render(<SampleTabs values={["a", "b", "c"]} />);
    rerender(<SampleTabs values={["a", "c"]} />);
    await user.tab();
    await user.keyboard("{ArrowRight}");
    expect(tab("c")).toHaveFocus();
  });
});

describe("Tabs pass-through props (G2)", () => {
  it("applies className and extra attributes and still calls user handlers", async () => {
    const user = userEvent.setup();
    const onTabClick = vi.fn();
    const onListKeyDown = vi.fn();
    const { container } = render(
      <Tabs defaultValue="one" className="root">
        <TabList aria-label="S" className="list" onKeyDown={onListKeyDown}>
          <Tab value="one" className="t1">
            One
          </Tab>
          <Tab value="two" className="t2" data-testid="two" onClick={onTabClick}>
            Two
          </Tab>
        </TabList>
        <TabPanel value="one" className="p1" data-testid="panel-one">
          p
        </TabPanel>
      </Tabs>,
    );
    expect(container.firstElementChild).toHaveClass("root");
    expect(screen.getByRole("tablist")).toHaveClass("list");
    expect(tab("One")).toHaveClass("t1");
    expect(screen.getByTestId("two")).toBe(tab("Two"));
    expect(screen.getByTestId("panel-one")).toHaveClass("p1");

    await user.click(tab("Two"));
    expect(onTabClick).toHaveBeenCalledTimes(1);
    expect(tab("Two")).toHaveAttribute("aria-selected", "true");

    await user.keyboard("{ArrowLeft}");
    expect(onListKeyDown).toHaveBeenCalled();
    expect(tab("One")).toHaveAttribute("aria-selected", "true");
  });
});

describe("Tabs fallback follows DOM order (T1, T5)", () => {
  it("falls back to the first enabled tab in the DOM when a tab is inserted before the others", () => {
    const { rerender } = render(<SampleTabs values={["b", "c"]} defaultValue="zzz" />);
    rerender(<SampleTabs values={["a", "b", "c"]} defaultValue="zzz" />);
    expect(tab("a")).toHaveAttribute("aria-selected", "true");
    expect(tab("b")).toHaveAttribute("aria-selected", "false");
  });

  it("moves the fallback to the first tab in the DOM when tabs are reordered", () => {
    const { rerender } = render(<SampleTabs values={["a", "b"]} defaultValue="zzz" />);
    expect(tab("a")).toHaveAttribute("aria-selected", "true");
    rerender(<SampleTabs values={["b", "a"]} defaultValue="zzz" />);
    expect(tab("b")).toHaveAttribute("aria-selected", "true");
    expect(tab("a")).toHaveAttribute("aria-selected", "false");
  });
});

describe("Tabs before any tab registers (T1)", () => {
  it("renders the requested tab as selected in server markup", () => {
    const host = document.createElement("div");
    host.innerHTML = renderToStaticMarkup(<SampleTabs defaultValue="two" />);
    const selected = host.querySelector('[role="tab"][data-value="two"]');
    expect(selected).toHaveAttribute("aria-selected", "true");
    expect(selected).toHaveAttribute("tabindex", "0");
    const panel = host.querySelector('[role="tabpanel"][aria-labelledby="' + selected?.id + '"]');
    expect(panel).not.toHaveAttribute("hidden");
  });
});

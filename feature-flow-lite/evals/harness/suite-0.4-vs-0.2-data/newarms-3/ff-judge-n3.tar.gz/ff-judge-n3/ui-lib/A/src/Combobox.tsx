import { useId, useRef, useState, type ChangeEvent, type HTMLAttributes, type KeyboardEvent } from "react";

export interface ComboboxOption {
  value: string;
  label: string;
  disabled?: boolean;
}

export interface ComboboxProps extends Omit<HTMLAttributes<HTMLDivElement>, "onChange" | "defaultValue"> {
  label: string;
  options: ComboboxOption[];
  /** The selected option's value, or null for no selection. The component is always controlled. */
  value: string | null;
  /** Called with the chosen option's value. */
  onChange: (value: string | null) => void;
  placeholder?: string;
}

// Plain substring match, no regex: the filter text is user input.
function filterOptions(options: ComboboxOption[], query: string): ComboboxOption[] {
  const needle = query.trim().toLowerCase();
  return options.filter((option) => option.label.toLowerCase().includes(needle));
}

function firstEnabledValue(options: ComboboxOption[]): string | null {
  return options.find((option) => !option.disabled)?.value ?? null;
}

export function Combobox({ label, options, value, onChange, placeholder, ...rest }: ComboboxProps) {
  const id = useId();
  const inputId = `${id}-input`;
  const listboxId = `${id}-listbox`;
  const inputRef = useRef<HTMLInputElement>(null);
  const [open, setOpen] = useState(false);
  // null while the user is not editing; the input then shows the selected option's label.
  const [query, setQuery] = useState<string | null>(null);
  const [activeValue, setActiveValue] = useState<string | null>(null);

  const selected = options.find((option) => option.value === value);
  const filtered = open ? filterOptions(options, query ?? "") : [];
  const active = filtered.find((option) => option.value === activeValue && !option.disabled) ?? null;
  // The user has typed or cleared the text down to nothing; committing it clears the selection.
  const cleared = query !== null && query.trim() === "";

  function optionId(index: number): string {
    return `${id}-option-${index}`;
  }

  function openList() {
    setOpen(true);
    setActiveValue(firstEnabledValue(filterOptions(options, query ?? "")));
  }

  function close() {
    setOpen(false);
    setQuery(null);
    setActiveValue(null);
  }

  function choose(option: ComboboxOption) {
    onChange(option.value);
    close();
  }

  function commitCleared() {
    if (value !== null) onChange(null);
    close();
  }

  function handleBlur() {
    if (cleared) commitCleared();
    else close();
  }

  function moveActive(step: 1 | -1) {
    const enabled = filtered.filter((option) => !option.disabled);
    if (enabled.length === 0) {
      setActiveValue(null);
      return;
    }
    const current = active ? enabled.indexOf(active) : -1;
    const count = enabled.length;
    const next = current === -1 ? (step === 1 ? 0 : count - 1) : (current + step + count) % count;
    setActiveValue(enabled[next].value);
  }

  function handleChange(event: ChangeEvent<HTMLInputElement>) {
    const text = event.target.value;
    setQuery(text);
    setOpen(true);
    // Cleared text lists every option but highlights none, so Enter cannot pick one the user did not choose.
    setActiveValue(text.trim() === "" ? null : firstEnabledValue(filterOptions(options, text)));
  }

  function handleKeyDown(event: KeyboardEvent<HTMLInputElement>) {
    switch (event.key) {
      case "ArrowDown":
        event.preventDefault();
        if (open) moveActive(1);
        else openList();
        break;
      case "ArrowUp":
        if (open) {
          event.preventDefault();
          moveActive(-1);
        }
        break;
      case "Enter":
        if (open && active) {
          event.preventDefault();
          choose(active);
        } else if (open && cleared) {
          event.preventDefault();
          commitCleared();
        }
        break;
      case "Escape":
        if (open) {
          // Keeps the Escape from also closing an enclosing Dialog.
          event.preventDefault();
          event.stopPropagation();
          close();
        }
        break;
    }
  }

  return (
    <div {...rest}>
      <label htmlFor={inputId}>{label}</label>
      <input
        ref={inputRef}
        id={inputId}
        role="combobox"
        type="text"
        autoComplete="off"
        aria-autocomplete="list"
        aria-expanded={open}
        aria-controls={listboxId}
        aria-activedescendant={active ? optionId(options.indexOf(active)) : undefined}
        placeholder={placeholder}
        value={query ?? selected?.label ?? ""}
        onChange={handleChange}
        onKeyDown={handleKeyDown}
        onBlur={handleBlur}
      />
      {open && (
        <>
          <ul
            id={listboxId}
            role="listbox"
            // Keeps focus in the input when an option is pressed.
            onMouseDown={(event) => event.preventDefault()}
          >
            {filtered.map((option) => {
              const index = options.indexOf(option);
              return (
                <li
                  key={option.value}
                  id={optionId(index)}
                  role="option"
                  aria-selected={option.value === value}
                  aria-disabled={option.disabled ? true : undefined}
                  data-active={option === active}
                  onClick={() => {
                    if (option.disabled) return;
                    choose(option);
                    inputRef.current?.focus();
                  }}
                >
                  {option.label}
                </li>
              );
            })}
          </ul>
          {filtered.length === 0 && <div role="status">No results</div>}
        </>
      )}
    </div>
  );
}

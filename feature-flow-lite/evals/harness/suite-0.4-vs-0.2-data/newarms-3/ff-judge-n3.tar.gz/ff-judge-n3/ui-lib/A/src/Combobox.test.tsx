import { render, screen } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { useState } from "react";
import * as lib from "./index";
import { Combobox, Dialog, type ComboboxOption, type ComboboxProps } from "./index";

const fruits: ComboboxOption[] = [
  { value: "apple", label: "Apple" },
  { value: "banana", label: "Banana" },
  { value: "mango", label: "Mango" },
  { value: "grape", label: "Grape", disabled: true },
];

const input = () => screen.getByRole("combobox", { name: "Fruit" });

function Stateful({
  initial = null,
  options = fruits,
  onChange = () => {},
}: {
  initial?: string | null;
  options?: ComboboxOption[];
  onChange?: (value: string | null) => void;
}) {
  const [value, setValue] = useState(initial);
  return (
    <Combobox
      label="Fruit"
      options={options}
      value={value}
      onChange={(next) => {
        setValue(next);
        onChange(next);
      }}
    />
  );
}

describe("Combobox", () => {
  it("G1 index exports Combobox and its prop types", () => {
    const props: [ComboboxProps, ComboboxOption] = [
      { label: "Fruit", options: fruits, value: null, onChange: () => {} },
      { value: "a", label: "A" },
    ];
    expect(props[1].label).toBe("A");
    expect(lib.Combobox).toBeTypeOf("function");
  });

  it("G2 forwards className and other HTML props to the main element", () => {
    render(
      <Combobox
        label="Fruit"
        options={fruits}
        value={null}
        onChange={vi.fn()}
        className="picker"
        data-testid="picker"
      />,
    );
    expect(screen.getByTestId("picker")).toHaveClass("picker");
  });

  it("G2 two comboboxes on one page do not share ids", () => {
    render(
      <>
        <Combobox label="Fruit" options={fruits} value={null} onChange={vi.fn()} />
        <Combobox label="Fruit" options={fruits} value={null} onChange={vi.fn()} />
      </>,
    );
    const inputs = screen.getAllByRole("combobox", { name: "Fruit" });
    expect(inputs).toHaveLength(2);
    expect(inputs[0].id).not.toBe("");
    expect(inputs[0].id).not.toBe(inputs[1].id);
  });

  it("C1 links the label to the input and sets the combobox ARIA attributes", async () => {
    const user = userEvent.setup();
    render(<Combobox label="Fruit" options={fruits} value={null} onChange={vi.fn()} />);
    expect(input()).toHaveAttribute("aria-autocomplete", "list");
    expect(input()).toHaveAttribute("aria-expanded", "false");
    await user.click(input());
    await user.keyboard("{ArrowDown}");
    expect(input()).toHaveAttribute("aria-expanded", "true");
    const listbox = screen.getByRole("listbox");
    expect(listbox.id).not.toBe("");
    expect(input()).toHaveAttribute("aria-controls", listbox.id);
    const options = screen.getAllByRole("option");
    expect(options).toHaveLength(4);
    expect(new Set(options.map((option) => option.id)).size).toBe(4);
    expect(screen.getByRole("option", { name: "Grape" })).toHaveAttribute("aria-disabled", "true");
  });

  it("C1 aria-selected is true only for the selected value", async () => {
    const user = userEvent.setup();
    render(<Combobox label="Fruit" options={fruits} value="banana" onChange={vi.fn()} />);
    await user.click(input());
    await user.keyboard("{ArrowDown}");
    expect(screen.getByRole("option", { name: "Banana" })).toHaveAttribute("aria-selected", "true");
    expect(screen.getByRole("option", { name: "Apple" })).toHaveAttribute("aria-selected", "false");
  });

  it("C1 forwards placeholder to the input", () => {
    render(<Combobox label="Fruit" placeholder="Pick a fruit" options={fruits} value={null} onChange={vi.fn()} />);
    expect(input()).toHaveAttribute("placeholder", "Pick a fruit");
  });

  it("C2 shows the selected label, or an empty input for null", () => {
    const { unmount } = render(<Combobox label="Fruit" options={fruits} value="banana" onChange={vi.fn()} />);
    expect(input()).toHaveValue("Banana");
    unmount();
    render(<Combobox label="Fruit" options={fruits} value={null} onChange={vi.fn()} />);
    expect(input()).toHaveValue("");
  });

  it("C2 typing opens the listbox and filters by case-insensitive substring", async () => {
    const user = userEvent.setup();
    render(<Stateful />);
    await user.type(input(), "AN");
    expect(input()).toHaveAttribute("aria-expanded", "true");
    expect(screen.getAllByRole("option").map((option) => option.textContent)).toEqual(["Banana", "Mango"]);
  });

  it("C2 filter text is plain text: regex metacharacters do not throw or match everything", async () => {
    const user = userEvent.setup();
    render(<Stateful />);
    for (const text of ["(", ".*", "["]) {
      await user.click(input());
      await user.clear(input());
      await user.paste(text);
      expect(input()).toHaveValue(text);
      expect(screen.queryAllByRole("option")).toHaveLength(0);
    }
  });

  it("C2 hostile: leading and trailing whitespace in the filter is ignored", async () => {
    const user = userEvent.setup();
    render(<Stateful />);
    await user.click(input());
    await user.paste("  an  ");
    expect(screen.getAllByRole("option").map((option) => option.textContent)).toEqual(["Banana", "Mango"]);
  });

  it("C3 zero matches shows No results, no option role and no aria-activedescendant", async () => {
    const user = userEvent.setup();
    render(<Stateful />);
    await user.type(input(), "zzz");
    expect(screen.getByRole("status")).toHaveTextContent("No results");
    expect(screen.queryAllByRole("option")).toHaveLength(0);
    expect(input()).not.toHaveAttribute("aria-activedescendant");
  });

  it("C3 hostile: an empty options array shows No results when opened", async () => {
    const user = userEvent.setup();
    render(<Stateful options={[]} />);
    await user.click(input());
    await user.keyboard("{ArrowDown}");
    expect(input()).toHaveAttribute("aria-expanded", "true");
    expect(screen.getByRole("status")).toHaveTextContent("No results");
  });

  it("C4 ArrowDown opens the listbox when it is closed", async () => {
    const user = userEvent.setup();
    render(<Stateful />);
    await user.click(input());
    await user.keyboard("{ArrowDown}");
    expect(input()).toHaveAttribute("aria-expanded", "true");
    expect(screen.getByRole("listbox")).toBeInTheDocument();
  });

  it("C4 Alt+ArrowDown opens the listbox when it is closed", async () => {
    const user = userEvent.setup();
    render(<Stateful />);
    await user.click(input());
    await user.keyboard("{Alt>}{ArrowDown}{/Alt}");
    expect(input()).toHaveAttribute("aria-expanded", "true");
    expect(screen.getByRole("listbox")).toBeInTheDocument();
  });

  it("C4 ArrowDown and ArrowUp move the active option, skipping disabled options and wrapping", async () => {
    const user = userEvent.setup();
    render(<Stateful />);
    await user.click(input());
    await user.keyboard("{ArrowDown}");
    const active = () => input().getAttribute("aria-activedescendant");
    expect(active()).toBe(screen.getByRole("option", { name: "Apple" }).id);
    expect(screen.getByRole("option", { name: "Apple" })).toHaveAttribute("data-active", "true");
    await user.keyboard("{ArrowDown}");
    expect(active()).toBe(screen.getByRole("option", { name: "Banana" }).id);
    await user.keyboard("{ArrowDown}");
    expect(active()).toBe(screen.getByRole("option", { name: "Mango" }).id);
    await user.keyboard("{ArrowDown}");
    expect(active()).toBe(screen.getByRole("option", { name: "Apple" }).id);
    await user.keyboard("{ArrowUp}");
    expect(active()).toBe(screen.getByRole("option", { name: "Mango" }).id);
    expect(screen.getByRole("option", { name: "Apple" })).not.toHaveAttribute("data-active", "true");
    expect(input()).toHaveFocus();
  });

  it("C4 when every filtered option is disabled there is no active option", async () => {
    const user = userEvent.setup();
    const disabledOnly: ComboboxOption[] = [
      { value: "x", label: "Xray", disabled: true },
      { value: "y", label: "Yam", disabled: true },
    ];
    render(<Stateful options={disabledOnly} />);
    await user.click(input());
    await user.keyboard("{ArrowDown}{ArrowDown}");
    expect(input()).toHaveAttribute("aria-expanded", "true");
    expect(input()).not.toHaveAttribute("aria-activedescendant");
    expect(screen.queryByRole("option", { selected: true })).toBeNull();
  });

  it("C5 Enter with an active option calls onChange(value), closes and shows its label", async () => {
    const user = userEvent.setup();
    const onChange = vi.fn();
    render(<Stateful onChange={onChange} />);
    await user.click(input());
    await user.keyboard("{ArrowDown}{ArrowDown}{Enter}");
    expect(onChange).toHaveBeenCalledTimes(1);
    expect(onChange).toHaveBeenCalledWith("banana");
    expect(input()).toHaveAttribute("aria-expanded", "false");
    expect(input()).toHaveValue("Banana");
  });

  it("C5 Enter with no active option while open does not call onChange", async () => {
    const user = userEvent.setup();
    const onChange = vi.fn();
    render(<Stateful onChange={onChange} />);
    await user.type(input(), "zzz");
    await user.keyboard("{Enter}");
    expect(onChange).not.toHaveBeenCalled();
  });

  it("C5 clicking an enabled option selects it and focus stays in the input", async () => {
    const user = userEvent.setup();
    const onChange = vi.fn();
    render(<Stateful onChange={onChange} />);
    await user.click(input());
    await user.keyboard("{ArrowDown}");
    await user.click(screen.getByRole("option", { name: "Mango" }));
    expect(onChange).toHaveBeenCalledWith("mango");
    expect(input()).toHaveFocus();
    expect(input()).toHaveValue("Mango");
    expect(screen.queryByRole("listbox")).toBeNull();
  });

  it("C5 clicking a disabled option does nothing", async () => {
    const user = userEvent.setup();
    const onChange = vi.fn();
    render(<Stateful onChange={onChange} />);
    await user.click(input());
    await user.keyboard("{ArrowDown}");
    await user.click(screen.getByRole("option", { name: "Grape" }));
    expect(onChange).not.toHaveBeenCalled();
    expect(screen.getByRole("listbox")).toBeInTheDocument();
  });

  it("C5 hostile: duplicate labels select by value, not by label", async () => {
    const user = userEvent.setup();
    const onChange = vi.fn();
    const same: ComboboxOption[] = [
      { value: "1", label: "Same" },
      { value: "2", label: "Same" },
    ];
    render(<Stateful options={same} onChange={onChange} />);
    await user.click(input());
    await user.keyboard("{ArrowDown}");
    await user.click(screen.getAllByRole("option")[1]);
    expect(onChange).toHaveBeenCalledWith("2");
  });

  it("C5 hostile: numeric-looking values are passed through as strings", async () => {
    const user = userEvent.setup();
    const onChange = vi.fn();
    const numeric: ComboboxOption[] = [
      { value: "01", label: "Zero one" },
      { value: "1", label: "One" },
    ];
    render(<Stateful options={numeric} onChange={onChange} />);
    await user.click(input());
    await user.keyboard("{ArrowDown}{Enter}");
    expect(onChange).toHaveBeenCalledWith("01");
    expect(onChange.mock.calls[0][0]).toBeTypeOf("string");
  });

  it("C6 Escape closes the listbox without onChange and restores the selected label", async () => {
    const user = userEvent.setup();
    const onChange = vi.fn();
    render(<Combobox label="Fruit" options={fruits} value="apple" onChange={onChange} />);
    await user.click(input());
    await user.clear(input());
    await user.type(input(), "ban");
    expect(screen.getByRole("listbox")).toBeInTheDocument();
    await user.keyboard("{Escape}");
    expect(input()).toHaveAttribute("aria-expanded", "false");
    expect(screen.queryByRole("listbox")).toBeNull();
    expect(input()).toHaveValue("Apple");
    expect(onChange).not.toHaveBeenCalled();
  });

  it("C6 blur closes the listbox and restores the selected label", async () => {
    const user = userEvent.setup();
    const onChange = vi.fn();
    render(
      <>
        <Combobox label="Fruit" options={fruits} value="apple" onChange={onChange} />
        <button>Elsewhere</button>
      </>,
    );
    await user.click(input());
    await user.clear(input());
    await user.type(input(), "ban");
    await user.click(screen.getByRole("button", { name: "Elsewhere" }));
    expect(screen.queryByRole("listbox")).toBeNull();
    expect(input()).toHaveValue("Apple");
    expect(onChange).not.toHaveBeenCalled();
  });

  it("C6 hostile: Escape with the listbox open inside a Dialog closes only the listbox", async () => {
    const user = userEvent.setup();
    const onOpenChange = vi.fn();
    render(
      <Dialog open onOpenChange={onOpenChange} title="Pick">
        <Stateful />
      </Dialog>,
    );
    expect(input()).toHaveFocus();
    await user.keyboard("{ArrowDown}");
    expect(screen.getByRole("listbox")).toBeInTheDocument();
    await user.keyboard("{Escape}");
    expect(screen.queryByRole("listbox")).toBeNull();
    expect(onOpenChange).not.toHaveBeenCalled();
    await user.keyboard("{Escape}");
    expect(onOpenChange).toHaveBeenCalledTimes(1);
    expect(onOpenChange).toHaveBeenCalledWith(false);
  });

  it("C7 is controlled: the parent value is the source of truth", async () => {
    const user = userEvent.setup();
    const onChange = vi.fn();
    render(<Combobox label="Fruit" options={fruits} value="apple" onChange={onChange} />);
    await user.click(input());
    await user.keyboard("{ArrowDown}{ArrowDown}{Enter}");
    expect(onChange).toHaveBeenCalledWith("banana");
    expect(input()).toHaveValue("Apple");
  });

  it("C7 the input reflects value changes made by the parent while closed", () => {
    const { rerender } = render(<Combobox label="Fruit" options={fruits} value="apple" onChange={vi.fn()} />);
    expect(input()).toHaveValue("Apple");
    rerender(<Combobox label="Fruit" options={fruits} value="mango" onChange={vi.fn()} />);
    expect(input()).toHaveValue("Mango");
  });

  it("C7 a value that is not in options shows an empty input", () => {
    render(<Combobox label="Fruit" options={fruits} value="kiwi" onChange={vi.fn()} />);
    expect(input()).toHaveValue("");
  });

  it("C7 hostile: options changing while open never leave a stale aria-activedescendant", async () => {
    const user = userEvent.setup();
    const { rerender } = render(<Combobox label="Fruit" options={fruits} value={null} onChange={vi.fn()} />);
    await user.click(input());
    await user.keyboard("{ArrowDown}{ArrowDown}");
    expect(input()).toHaveAttribute("aria-activedescendant", screen.getByRole("option", { name: "Banana" }).id);
    rerender(
      <Combobox
        label="Fruit"
        options={fruits.filter((fruit) => fruit.value !== "banana")}
        value={null}
        onChange={vi.fn()}
      />,
    );
    expect(input()).not.toHaveAttribute("aria-activedescendant");
  });

  it("C7 hostile: typing after an option was active resets the active option to the first enabled match", async () => {
    const user = userEvent.setup();
    render(<Stateful />);
    await user.click(input());
    await user.keyboard("{ArrowDown}{ArrowDown}");
    await user.keyboard("m");
    expect(input()).toHaveAttribute("aria-activedescendant", screen.getByRole("option", { name: "Mango" }).id);
    await user.keyboard("z");
    expect(input()).not.toHaveAttribute("aria-activedescendant");
  });

  it("C5 clearing the text and pressing Enter calls onChange(null) and closes", async () => {
    const user = userEvent.setup();
    const onChange = vi.fn();
    render(<Stateful initial="apple" onChange={onChange} />);
    await user.click(input());
    await user.clear(input());
    await user.keyboard("{Enter}");
    expect(onChange).toHaveBeenCalledTimes(1);
    expect(onChange).toHaveBeenCalledWith(null);
    expect(input()).toHaveAttribute("aria-expanded", "false");
    expect(input()).toHaveValue("");
  });

  it("C5 hostile: whitespace-only text counts as cleared when committed by Enter", async () => {
    const user = userEvent.setup();
    const onChange = vi.fn();
    render(<Stateful initial="apple" onChange={onChange} />);
    await user.click(input());
    await user.clear(input());
    await user.type(input(), "   ");
    await user.keyboard("{Enter}");
    expect(onChange).toHaveBeenCalledTimes(1);
    expect(onChange).toHaveBeenCalledWith(null);
  });

  it("C5 clearing the text then ArrowDown and Enter selects the highlighted option, not null", async () => {
    const user = userEvent.setup();
    const onChange = vi.fn();
    render(<Stateful initial="apple" onChange={onChange} />);
    await user.click(input());
    await user.clear(input());
    await user.keyboard("{ArrowDown}{Enter}");
    expect(onChange).toHaveBeenCalledTimes(1);
    expect(onChange).toHaveBeenCalledWith("apple");
    expect(input()).toHaveAttribute("aria-expanded", "false");
    expect(input()).toHaveValue("Apple");
  });

  it("C4 clearing the text keeps the list open with every option and no active option", async () => {
    const user = userEvent.setup();
    render(<Stateful initial="apple" />);
    await user.click(input());
    await user.clear(input());
    expect(input()).toHaveAttribute("aria-expanded", "true");
    expect(screen.getAllByRole("option")).toHaveLength(4);
    expect(input()).not.toHaveAttribute("aria-activedescendant");
    expect(document.querySelector('[data-active="true"]')).toBeNull();
  });

  it("C4 hostile: whitespace-only text leaves no option active", async () => {
    const user = userEvent.setup();
    render(<Stateful />);
    await user.click(input());
    await user.type(input(), "   ");
    expect(screen.getAllByRole("option")).toHaveLength(4);
    expect(input()).not.toHaveAttribute("aria-activedescendant");
    expect(document.querySelector('[data-active="true"]')).toBeNull();
  });

  it("C6 clearing the text and blurring calls onChange(null) and closes", async () => {
    const user = userEvent.setup();
    const onChange = vi.fn();
    render(
      <>
        <Stateful initial="apple" onChange={onChange} />
        <button>Elsewhere</button>
      </>,
    );
    await user.click(input());
    await user.clear(input());
    await user.click(screen.getByRole("button", { name: "Elsewhere" }));
    expect(onChange).toHaveBeenCalledTimes(1);
    expect(onChange).toHaveBeenCalledWith(null);
    expect(screen.queryByRole("listbox")).toBeNull();
    expect(input()).toHaveValue("");
  });

  it("C6 Escape after clearing the text restores the selected label without onChange", async () => {
    const user = userEvent.setup();
    const onChange = vi.fn();
    render(<Combobox label="Fruit" options={fruits} value="apple" onChange={onChange} />);
    await user.click(input());
    await user.clear(input());
    await user.keyboard("{Escape}");
    expect(input()).toHaveValue("Apple");
    expect(onChange).not.toHaveBeenCalled();
  });

  it("C6 hostile: non-matching text that is blurred restores the selected label without onChange", async () => {
    const user = userEvent.setup();
    const onChange = vi.fn();
    render(
      <>
        <Combobox label="Fruit" options={fruits} value="apple" onChange={onChange} />
        <button>Elsewhere</button>
      </>,
    );
    await user.click(input());
    await user.clear(input());
    await user.type(input(), "zzz");
    await user.click(screen.getByRole("button", { name: "Elsewhere" }));
    expect(input()).toHaveValue("Apple");
    expect(onChange).not.toHaveBeenCalled();
  });
});

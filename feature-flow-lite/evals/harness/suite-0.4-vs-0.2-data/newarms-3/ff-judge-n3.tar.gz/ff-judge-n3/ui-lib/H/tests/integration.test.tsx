import { describe, expect, it, vi } from "vitest";
import { render, screen, within } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { Combobox } from "../src/Combobox";
import { Dialog } from "../src/Dialog";

const fruits = [
  { value: "apple", label: "Apple" },
  { value: "banana", label: "Banana" },
];

describe("Combobox inside Dialog (I1)", () => {
  it("Escape closes only the listbox, and a second Escape closes the dialog", async () => {
    const user = userEvent.setup();
    const onOpenChange = vi.fn();
    render(
      <Dialog open title="Pick a fruit" onOpenChange={onOpenChange}>
        <Combobox label="Fruit" options={fruits} value={null} onChange={() => {}} />
      </Dialog>,
    );
    const input = screen.getByRole("combobox", { name: "Fruit" });
    expect(input).toHaveFocus();

    await user.keyboard("{ArrowDown}");
    expect(within(screen.getByRole("listbox")).getAllByRole("option")).toHaveLength(2);

    await user.keyboard("{Escape}");
    expect(onOpenChange).not.toHaveBeenCalled();
    expect(input).toHaveAttribute("aria-expanded", "false");

    await user.keyboard("{Escape}");
    expect(onOpenChange).toHaveBeenCalledTimes(1);
    expect(onOpenChange).toHaveBeenCalledWith(false);
  });
});

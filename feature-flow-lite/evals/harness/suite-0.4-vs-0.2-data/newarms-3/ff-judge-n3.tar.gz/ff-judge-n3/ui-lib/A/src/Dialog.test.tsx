import { render, screen } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { useState, type ReactNode } from "react";
import * as lib from "./index";
import { Dialog, type DialogProps } from "./index";

function getBackdrop(): HTMLElement {
  const backdrop = document.querySelector<HTMLElement>("[data-backdrop]");
  if (!backdrop) throw new Error("backdrop not rendered");
  return backdrop;
}

function Stateful({ children, initialOpen = false }: { children?: ReactNode; initialOpen?: boolean }) {
  const [open, setOpen] = useState(initialOpen);
  return (
    <>
      <button onClick={() => setOpen(true)}>Open</button>
      <Dialog open={open} onOpenChange={setOpen} title="Confirm" description="Are you sure?">
        {children ?? <button>Yes</button>}
      </Dialog>
    </>
  );
}

function Host({ open }: { open: boolean }) {
  return (
    <>
      <button>Trigger</button>
      {open && (
        <Dialog open onOpenChange={() => {}} title="Confirm">
          <button>Yes</button>
        </Dialog>
      )}
    </>
  );
}

describe("Dialog", () => {
  it("G1 index exports Dialog and DialogProps", () => {
    const props: DialogProps = { open: false, onOpenChange: () => {}, title: "Title" };
    expect(props.title).toBe("Title");
    expect(lib.Dialog).toBeTypeOf("function");
  });

  it("G2 forwards className and other HTML props to the dialog element", () => {
    render(
      <Dialog open onOpenChange={vi.fn()} title="Confirm" className="modal" data-testid="modal">
        <p>Body</p>
      </Dialog>,
    );
    expect(screen.getByTestId("modal")).toHaveClass("modal");
    expect(screen.getByTestId("modal")).toHaveAttribute("role", "dialog");
  });

  it("G2 two open dialogs on one page do not share ids", () => {
    render(
      <>
        <Dialog open onOpenChange={vi.fn()} title="First">
          <p>a</p>
        </Dialog>
        <Dialog open onOpenChange={vi.fn()} title="Second">
          <p>b</p>
        </Dialog>
      </>,
    );
    const first = screen.getByRole("dialog", { name: "First" });
    const second = screen.getByRole("dialog", { name: "Second" });
    expect(first.getAttribute("aria-labelledby")).toBeTruthy();
    expect(first.getAttribute("aria-labelledby")).not.toBe(second.getAttribute("aria-labelledby"));
  });

  it("D1 open renders a backdrop and a modal dialog into document.body, labelled and described", () => {
    const { container } = render(
      <Dialog open onOpenChange={vi.fn()} title="Delete file" description="This cannot be undone.">
        <button>Delete</button>
      </Dialog>,
    );
    const dialog = screen.getByRole("dialog", { name: "Delete file" });
    expect(dialog).toHaveAttribute("aria-modal", "true");
    expect(dialog).toHaveAccessibleDescription("This cannot be undone.");
    expect(dialog.parentElement).toBe(document.body);
    expect(container).toBeEmptyDOMElement();
    expect(getBackdrop()).toBeInTheDocument();
  });

  it("D1 has no aria-describedby when there is no description", () => {
    render(
      <Dialog open onOpenChange={vi.fn()} title="Delete file">
        <button>Delete</button>
      </Dialog>,
    );
    expect(screen.getByRole("dialog")).not.toHaveAttribute("aria-describedby");
  });

  it("D1 renders nothing when open is false", () => {
    const { container } = render(
      <Dialog open={false} onOpenChange={vi.fn()} title="Delete file">
        <button>Delete</button>
      </Dialog>,
    );
    expect(screen.queryByRole("dialog")).toBeNull();
    expect(document.querySelector("[data-backdrop]")).toBeNull();
    expect(container).toBeEmptyDOMElement();
  });

  it("D2 focuses the first tabbable element when opened", () => {
    render(
      <Dialog open onOpenChange={vi.fn()} title="Confirm">
        <button>First</button>
        <button>Second</button>
      </Dialog>,
    );
    expect(screen.getByRole("button", { name: "First" })).toHaveFocus();
  });

  it("D2 focuses the dialog itself when it has no tabbable elements", () => {
    render(
      <Dialog open onOpenChange={vi.fn()} title="Confirm">
        <p>Just text</p>
      </Dialog>,
    );
    const dialog = screen.getByRole("dialog");
    expect(dialog).toHaveFocus();
    expect(dialog).toHaveAttribute("tabindex", "-1");
  });

  it("D3 Tab from the last tabbable element wraps to the first", async () => {
    const user = userEvent.setup();
    render(
      <Dialog open onOpenChange={vi.fn()} title="Confirm">
        <button>First</button>
        <button>Second</button>
      </Dialog>,
    );
    await user.tab();
    expect(screen.getByRole("button", { name: "Second" })).toHaveFocus();
    await user.tab();
    expect(screen.getByRole("button", { name: "First" })).toHaveFocus();
  });

  it("D3 Shift+Tab from the first tabbable element wraps to the last", async () => {
    const user = userEvent.setup();
    render(
      <Dialog open onOpenChange={vi.fn()} title="Confirm">
        <button>First</button>
        <button>Second</button>
      </Dialog>,
    );
    expect(screen.getByRole("button", { name: "First" })).toHaveFocus();
    await user.tab({ shift: true });
    expect(screen.getByRole("button", { name: "Second" })).toHaveFocus();
  });

  it("D3 with no tabbable elements, Tab keeps focus on the dialog", async () => {
    const user = userEvent.setup();
    render(
      <Dialog open onOpenChange={vi.fn()} title="Confirm">
        <p>Just text</p>
      </Dialog>,
    );
    await user.tab();
    expect(screen.getByRole("dialog")).toHaveFocus();
  });

  it("D3 excludes disabled, tabindex=-1 and hidden elements from the trap", async () => {
    const user = userEvent.setup();
    render(
      <Dialog open onOpenChange={vi.fn()} title="Confirm">
        <button disabled>Off</button>
        <button tabIndex={-1}>Skip</button>
        <button hidden>Hidden</button>
        <div style={{ display: "none" }}>
          <button>InsideHidden</button>
        </div>
        <button>Only</button>
      </Dialog>,
    );
    expect(screen.getByRole("button", { name: "Only" })).toHaveFocus();
    await user.tab();
    expect(screen.getByRole("button", { name: "Only" })).toHaveFocus();
    await user.tab({ shift: true });
    expect(screen.getByRole("button", { name: "Only" })).toHaveFocus();
  });

  it("D4 Escape calls onOpenChange(false)", async () => {
    const user = userEvent.setup();
    const onOpenChange = vi.fn();
    render(
      <Dialog open onOpenChange={onOpenChange} title="Confirm">
        <button>Yes</button>
      </Dialog>,
    );
    await user.keyboard("{Escape}");
    expect(onOpenChange).toHaveBeenCalledTimes(1);
    expect(onOpenChange).toHaveBeenCalledWith(false);
  });

  it("D4 clicking the backdrop calls onOpenChange(false)", async () => {
    const user = userEvent.setup();
    const onOpenChange = vi.fn();
    render(
      <Dialog open onOpenChange={onOpenChange} title="Confirm">
        <p>Body text</p>
      </Dialog>,
    );
    await user.click(getBackdrop());
    expect(onOpenChange).toHaveBeenCalledTimes(1);
    expect(onOpenChange).toHaveBeenCalledWith(false);
  });

  it("D4 clicking inside the dialog content does not close it", async () => {
    const user = userEvent.setup();
    const onOpenChange = vi.fn();
    render(
      <Dialog open onOpenChange={onOpenChange} title="Confirm">
        <p>Body text</p>
      </Dialog>,
    );
    await user.click(screen.getByText("Body text"));
    expect(onOpenChange).not.toHaveBeenCalled();
  });

  it("D4 a press inside the content released on the backdrop does not close it", async () => {
    const user = userEvent.setup();
    const onOpenChange = vi.fn();
    render(
      <Dialog open onOpenChange={onOpenChange} title="Confirm">
        <p>Body text</p>
      </Dialog>,
    );
    await user.pointer([
      { keys: "[MouseLeft>]", target: screen.getByText("Body text") },
      { target: getBackdrop() },
      { keys: "[/MouseLeft]", target: getBackdrop() },
    ]);
    expect(onOpenChange).not.toHaveBeenCalled();
  });

  it("D5 returns focus to the element focused before opening once closed", async () => {
    const user = userEvent.setup();
    render(<Stateful />);
    await user.click(screen.getByRole("button", { name: "Open" }));
    expect(screen.getByRole("button", { name: "Yes" })).toHaveFocus();
    await user.keyboard("{Escape}");
    expect(screen.queryByRole("dialog")).toBeNull();
    expect(screen.getByRole("button", { name: "Open" })).toHaveFocus();
  });

  it("D5 returns focus when the dialog unmounts while open", () => {
    const { rerender } = render(<Host open={false} />);
    screen.getByRole("button", { name: "Trigger" }).focus();
    rerender(<Host open />);
    expect(screen.getByRole("button", { name: "Yes" })).toHaveFocus();
    rerender(<Host open={false} />);
    expect(screen.getByRole("button", { name: "Trigger" })).toHaveFocus();
  });

  it("D5 does not move focus to an element that has left the document", () => {
    const previous = document.createElement("button");
    document.body.append(previous);
    previous.focus();
    const { rerender } = render(
      <Dialog open onOpenChange={vi.fn()} title="Confirm">
        <button>Yes</button>
      </Dialog>,
    );
    previous.remove();
    expect(() =>
      rerender(
        <Dialog open={false} onOpenChange={vi.fn()} title="Confirm">
          <button>Yes</button>
        </Dialog>,
      ),
    ).not.toThrow();
    expect(document.activeElement).toBe(document.body);
  });

  it("D6 controlled: stays open when the parent ignores onOpenChange(false)", async () => {
    const user = userEvent.setup();
    const onOpenChange = vi.fn();
    const { rerender } = render(
      <Dialog open onOpenChange={onOpenChange} title="Confirm">
        <p>Body text</p>
      </Dialog>,
    );
    await user.keyboard("{Escape}");
    await user.click(getBackdrop());
    expect(onOpenChange).toHaveBeenCalledTimes(2);
    expect(screen.getByRole("dialog")).toBeInTheDocument();
    rerender(
      <Dialog open={false} onOpenChange={onOpenChange} title="Confirm">
        <p>Body text</p>
      </Dialog>,
    );
    expect(screen.queryByRole("dialog")).toBeNull();
  });

  it("D6 hostile: Escape from a nested input closes once", async () => {
    const user = userEvent.setup();
    const onOpenChange = vi.fn();
    render(
      <Dialog open onOpenChange={onOpenChange} title="Search">
        <input aria-label="Query" />
      </Dialog>,
    );
    expect(screen.getByRole("textbox", { name: "Query" })).toHaveFocus();
    await user.keyboard("{Escape}");
    expect(onOpenChange).toHaveBeenCalledTimes(1);
    expect(onOpenChange).toHaveBeenCalledWith(false);
  });

  it("D6 hostile: a dialog open on first render focuses inside and returns focus to the previous element", () => {
    const previous = document.createElement("button");
    document.body.append(previous);
    previous.focus();
    const { rerender } = render(
      <Dialog open onOpenChange={vi.fn()} title="Confirm">
        <button>Yes</button>
      </Dialog>,
    );
    expect(screen.getByRole("button", { name: "Yes" })).toHaveFocus();
    rerender(
      <Dialog open={false} onOpenChange={vi.fn()} title="Confirm">
        <button>Yes</button>
      </Dialog>,
    );
    expect(previous).toHaveFocus();
    previous.remove();
  });

  it("D6 hostile: children changed while open are used by the trap, not a snapshot", async () => {
    const user = userEvent.setup();
    const { rerender } = render(
      <Dialog open onOpenChange={vi.fn()} title="Confirm">
        {[<button key="one">One</button>]}
      </Dialog>,
    );
    rerender(
      <Dialog open onOpenChange={vi.fn()} title="Confirm">
        {[<button key="one">One</button>, <button key="two">Two</button>]}
      </Dialog>,
    );
    expect(screen.getByRole("button", { name: "One" })).toHaveFocus();
    await user.tab();
    expect(screen.getByRole("button", { name: "Two" })).toHaveFocus();
    await user.tab();
    expect(screen.getByRole("button", { name: "One" })).toHaveFocus();
  });

  it("D6 hostile: title given as a ReactNode is the accessible name", () => {
    render(
      <Dialog open onOpenChange={vi.fn()} title={<span>Delete <em>draft</em></span>}>
        <button>Yes</button>
      </Dialog>,
    );
    expect(screen.getByRole("dialog", { name: "Delete draft" })).toBeInTheDocument();
  });

  it("D6 hostile: with two open dialogs, Escape calls only the most recently opened one", async () => {
    const user = userEvent.setup();
    const onA = vi.fn();
    const onB = vi.fn();
    const { rerender } = render(<Stack openA openB={false} onA={onA} onB={onB} />);
    rerender(<Stack openA openB onA={onA} onB={onB} />);
    await user.keyboard("{Escape}");
    expect(onB).toHaveBeenCalledTimes(1);
    expect(onB).toHaveBeenCalledWith(false);
    expect(onA).not.toHaveBeenCalled();
  });

  it("D6 hostile: after the top dialog closes, Escape closes the one beneath it", async () => {
    const user = userEvent.setup();
    const onA = vi.fn();
    const onB = vi.fn();
    const { rerender } = render(<Stack openA openB={false} onA={onA} onB={onB} />);
    rerender(<Stack openA openB onA={onA} onB={onB} />);
    rerender(<Stack openA openB={false} onA={onA} onB={onB} />);
    await user.keyboard("{Escape}");
    expect(onA).toHaveBeenCalledTimes(1);
    expect(onA).toHaveBeenCalledWith(false);
    expect(onB).not.toHaveBeenCalled();
  });
});

function Stack({
  openA,
  openB,
  onA,
  onB,
}: {
  openA: boolean;
  openB: boolean;
  onA: (open: boolean) => void;
  onB: (open: boolean) => void;
}) {
  return (
    <>
      <Dialog open={openA} onOpenChange={onA} title="First">
        <button>First action</button>
      </Dialog>
      <Dialog open={openB} onOpenChange={onB} title="Second">
        <button>Second action</button>
      </Dialog>
    </>
  );
}

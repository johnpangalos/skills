import {
  createContext,
  useContext,
  useEffect,
  useId,
  useLayoutEffect,
  useRef,
  type ComponentPropsWithoutRef,
  type RefObject,
} from "react";
import { createPortal } from "react-dom";

export type DialogProps = ComponentPropsWithoutRef<"div"> & {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  title: string;
  description?: string;
};

const FOCUSABLE_SELECTOR = [
  "a[href]",
  "button",
  "input:not([type='hidden'])",
  "select",
  "textarea",
  "[tabindex]",
  "[contenteditable='true']",
]
  .map((selector) => `${selector}:not([disabled]):not([tabindex="-1"])`)
  .join(", ");

function getFocusables(container: HTMLElement): HTMLElement[] {
  return Array.from(container.querySelectorAll<HTMLElement>(FOCUSABLE_SELECTOR));
}

type OpenDialog = { ref: RefObject<HTMLDivElement | null>; depth: number };

// Open dialogs in the order they were pushed. Only the topmost one handles Escape and Tab, so nested dialogs do not both react.
const dialogStack: OpenDialog[] = [];

// Nesting level of the Dialog being rendered: 0 at top level, one more inside each Dialog's children.
const DialogDepthContext = createContext(0);

// The deepest open dialog wins; on a tie the most recently pushed one does.
function getTopmostDialog(): OpenDialog | undefined {
  let top: OpenDialog | undefined;
  for (const entry of dialogStack) {
    if (top === undefined || entry.depth >= top.depth) top = entry;
  }
  return top;
}

export function Dialog({ open, onOpenChange, title, description, children, ...props }: DialogProps) {
  const baseId = useId();
  const depth = useContext(DialogDepthContext);
  const dialogRef = useRef<HTMLDivElement>(null);
  const backdropPressed = useRef(false);
  const titleId = `${baseId}-title`;
  const descriptionId = `${baseId}-description`;

  // Kept separate from the listener effect so re-renders with a new onOpenChange do not reorder the stack.
  // Declared before the focus effect so a deeper dialog opened in the same commit is already on the stack.
  useLayoutEffect(() => {
    if (!open) return;
    const entry = { ref: dialogRef, depth };
    dialogStack.push(entry);
    return () => {
      dialogStack.splice(dialogStack.indexOf(entry), 1);
    };
  }, [open, depth]);

  useLayoutEffect(() => {
    const dialog = dialogRef.current;
    // A deeper dialog that opened in the same commit keeps focus, so do not pull it back here.
    if (!open || dialog === null || getTopmostDialog()?.ref !== dialogRef) return;
    const opener = document.activeElement;
    (getFocusables(dialog)[0] ?? dialog).focus();
    return () => {
      if (opener instanceof HTMLElement && document.contains(opener)) opener.focus();
    };
  }, [open]);

  // Document-level so Escape and the focus trap still work if focus has fallen back to <body>.
  useEffect(() => {
    if (!open) return;
    function handleKeyDown(event: globalThis.KeyboardEvent) {
      const dialog = dialogRef.current;
      if (dialog === null || getTopmostDialog()?.ref !== dialogRef) return;
      if (event.key === "Escape") {
        onOpenChange(false);
        return;
      }
      if (event.key !== "Tab") return;

      const focusables = getFocusables(dialog);
      if (focusables.length === 0) {
        event.preventDefault();
        dialog.focus();
        return;
      }
      const first = focusables[0];
      const last = focusables[focusables.length - 1];
      const active = document.activeElement;
      const outside = !dialog.contains(active);
      if (event.shiftKey && (active === dialog || active === first || outside)) {
        event.preventDefault();
        last.focus();
      } else if (!event.shiftKey && (active === last || outside)) {
        event.preventDefault();
        first.focus();
      }
    }
    document.addEventListener("keydown", handleKeyDown);
    return () => document.removeEventListener("keydown", handleKeyDown);
  }, [open, onOpenChange]);

  if (!open) return null;

  // Only a press that starts and ends on the (childless) backdrop counts as a backdrop click.
  return createPortal(
    <>
      <div
        data-backdrop=""
        onMouseDown={() => {
          backdropPressed.current = true;
        }}
        onClick={() => {
          const closes = backdropPressed.current;
          backdropPressed.current = false;
          if (closes) onOpenChange(false);
        }}
      />
      <div
        {...props}
        ref={dialogRef}
        role="dialog"
        aria-modal="true"
        aria-labelledby={titleId}
        aria-describedby={description ? descriptionId : undefined}
        tabIndex={-1}
      >
        <h2 id={titleId}>{title}</h2>
        {description && <p id={descriptionId}>{description}</p>}
        <DialogDepthContext.Provider value={depth + 1}>{children}</DialogDepthContext.Provider>
      </div>
    </>,
    document.body,
  );
}

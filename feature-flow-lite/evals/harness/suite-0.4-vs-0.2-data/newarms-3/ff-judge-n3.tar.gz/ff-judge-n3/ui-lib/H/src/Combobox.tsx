import {
  useId,
  useState,
  type ChangeEvent,
  type ComponentPropsWithoutRef,
  type FocusEvent,
  type KeyboardEvent,
} from "react";

export type ComboboxOption = { value: string; label: string; disabled?: boolean };

export type ComboboxProps = Omit<ComponentPropsWithoutRef<"input">, "value" | "onChange" | "role"> & {
  label: string;
  options: ComboboxOption[];
  value: string | null;
  onChange: (value: string | null) => void;
};

// Indexes into `options` of the entries whose label contains the query (case-insensitive substring).
function visibleIndexes(options: ComboboxOption[], query: string): number[] {
  const needle = query.toLowerCase();
  return options.flatMap((option, index) => (option.label.toLowerCase().includes(needle) ? [index] : []));
}

// Returns the next enabled option index in the given direction, wrapping; null when none is enabled.
function stepActive(
  options: ComboboxOption[],
  visible: number[],
  active: number | null,
  direction: 1 | -1,
): number | null {
  const enabled = visible.filter((index) => !options[index].disabled);
  if (enabled.length === 0) return null;
  const position = enabled.indexOf(active ?? -1);
  if (position === -1) return direction === 1 ? enabled[0] : enabled[enabled.length - 1];
  return enabled[(position + direction + enabled.length) % enabled.length];
}

export function Combobox({ label, options, value, onChange, id, onKeyDown, onBlur, ...rest }: ComboboxProps) {
  const baseId = useId();
  const inputId = id ?? `${baseId}-input`;
  const labelId = `${baseId}-label`;
  const listboxId = `${baseId}-listbox`;
  const optionId = (index: number) => `${baseId}-option-${index}`;

  // `typed` is null while the input shows the selected label. Invariant: when closed, `typed` is null
  // and nothing is active.
  const [typed, setTyped] = useState<string | null>(null);
  const [open, setOpen] = useState(false);
  const [activeIndex, setActiveIndex] = useState<number | null>(null);

  const selectedLabel = options.find((option) => option.value === value)?.label ?? "";
  const visible = visibleIndexes(options, typed ?? "");
  // The stored index can go stale when options change; it only counts while visible and enabled.
  const active =
    activeIndex !== null && visible.includes(activeIndex) && !options[activeIndex].disabled ? activeIndex : null;

  const close = () => {
    setOpen(false);
    setTyped(null);
    setActiveIndex(null);
  };

  const handleChange = (event: ChangeEvent<HTMLInputElement>) => {
    const text = event.target.value;
    setTyped(text);
    setOpen(true);
    setActiveIndex(null);
    if (text === "") onChange(null);
  };

  const handleKeyDown = (event: KeyboardEvent<HTMLInputElement>) => {
    onKeyDown?.(event);
    switch (event.key) {
      case "ArrowDown":
      case "ArrowUp": {
        event.preventDefault();
        setOpen(true);
        setActiveIndex(stepActive(options, visible, active, event.key === "ArrowDown" ? 1 : -1));
        return;
      }
      case "Enter": {
        if (!open || active === null) return;
        event.preventDefault();
        onChange(options[active].value);
        close();
        return;
      }
      case "Escape": {
        if (!open) return;
        event.preventDefault();
        event.stopPropagation();
        close();
        return;
      }
    }
  };

  const handleBlur = (event: FocusEvent<HTMLInputElement>) => {
    onBlur?.(event);
    close();
  };

  return (
    <>
      <label id={labelId} htmlFor={inputId}>{label}</label>
      <input
        {...rest}
        id={inputId}
        role="combobox"
        aria-autocomplete="list"
        aria-expanded={open}
        aria-controls={listboxId}
        aria-activedescendant={active === null ? undefined : optionId(active)}
        value={typed ?? selectedLabel}
        onChange={handleChange}
        onKeyDown={handleKeyDown}
        onBlur={handleBlur}
      />
      <ul id={listboxId} role="listbox" aria-labelledby={labelId} hidden={!open}>
        {visible.map((index) => {
          const option = options[index];
          return (
            <li
              key={index}
              id={optionId(index)}
              role="option"
              aria-selected={option.value === value}
              aria-disabled={option.disabled ?? false}
              onMouseDown={(event) => event.preventDefault()}
              onClick={() => {
                if (option.disabled) return;
                onChange(option.value);
                close();
              }}
            >
              {option.label}
            </li>
          );
        })}
      </ul>
      {open && visible.length === 0 && <div role="status">No results</div>}
    </>
  );
}

import { useState } from "react";
import { fireEvent, render, screen } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { Combobox, type ComboboxOption, Dialog, type DialogProps } from "../src/index";

const fruits: ComboboxOption[] = [
  { value: "apple", label: "Apple" },
  { value: "cherry", label: "Cherry" },
];

function renderDialog(props: Partial<DialogProps> = {}) {
  const onOpenChange = vi.fn();
  render(
    <Dialog open title="Confirm" onOpenChange={onOpenChange} {...props}>
      <button>Ok</button>
    </Dialog>,
  );
  return { onOpenChange };
}

// The backdrop is the portal root element; the role=dialog element is its child.
const backdropOf = (dialog: HTMLElement) => dialog.parentElement as HTMLElement;

function DialogHarness({ open }: { open: boolean }) {
  return (
    <>
      <button>Trigger</button>
      <Dialog open={open} title="Confirm" onOpenChange={() => {}}>
        <button>Ok</button>
      </Dialog>
    </>
  );
}

describe("Dialog rendering (D1)", () => {
  it("renders nothing when closed", () => {
    render(
      <Dialog open={false} title="Confirm" onOpenChange={() => {}}>
        <p>hidden body</p>
      </Dialog>,
    );
    expect(screen.queryByRole("dialog")).toBeNull();
    expect(screen.queryByText("hidden body")).toBeNull();
  });

  it("portals a backdrop and a modal dialog into document.body", () => {
    renderDialog();
    const dialog = screen.getByRole("dialog");
    expect(dialog).toHaveAttribute("aria-modal", "true");
    expect(backdropOf(dialog).parentNode).toBe(document.body);
  });

  it("names the dialog with a heading containing the title", () => {
    renderDialog();
    const heading = screen.getByRole("heading", { name: "Confirm" });
    expect(screen.getByRole("dialog", { name: "Confirm" })).toHaveAttribute(
      "aria-labelledby",
      heading.id,
    );
  });

  it("describes the dialog only when description is given", () => {
    renderDialog({ description: "Are you sure?" });
    const dialog = screen.getByRole("dialog");
    const describedBy = dialog.getAttribute("aria-describedby");
    expect(describedBy).not.toBeNull();
    expect(document.getElementById(describedBy ?? "")).toHaveTextContent("Are you sure?");
  });

  it("has no aria-describedby without a description", () => {
    renderDialog();
    expect(screen.getByRole("dialog")).not.toHaveAttribute("aria-describedby");
  });
});

describe("Dialog initial focus (D2)", () => {
  it("moves focus to the first focusable element", () => {
    render(
      <Dialog open title="Confirm" onOpenChange={() => {}}>
        <button>First</button>
        <button>Second</button>
      </Dialog>,
    );
    expect(screen.getByRole("button", { name: "First" })).toHaveFocus();
  });

  it("focuses the dialog itself when it has no focusable children", () => {
    render(
      <Dialog open title="Confirm" onOpenChange={() => {}}>
        <p>Just text</p>
      </Dialog>,
    );
    const dialog = screen.getByRole("dialog");
    expect(dialog).toHaveFocus();
    expect(dialog).toHaveAttribute("tabindex", "-1");
  });
});

describe("Dialog focus trap (D3)", () => {
  it("wraps Tab from the last focusable to the first", async () => {
    const user = userEvent.setup();
    render(
      <Dialog open title="Confirm" onOpenChange={() => {}}>
        <button>First</button>
        <button>Last</button>
      </Dialog>,
    );
    await user.tab();
    expect(screen.getByRole("button", { name: "Last" })).toHaveFocus();
    await user.tab();
    expect(screen.getByRole("button", { name: "First" })).toHaveFocus();
  });

  it("wraps Shift+Tab from the first focusable to the last", async () => {
    const user = userEvent.setup();
    render(
      <Dialog open title="Confirm" onOpenChange={() => {}}>
        <button>First</button>
        <button>Last</button>
      </Dialog>,
    );
    expect(screen.getByRole("button", { name: "First" })).toHaveFocus();
    await user.tab({ shift: true });
    expect(screen.getByRole("button", { name: "Last" })).toHaveFocus();
  });

  it("skips disabled, tabindex=-1 and hidden inputs when cycling", async () => {
    const user = userEvent.setup();
    render(
      <Dialog open title="Confirm" onOpenChange={() => {}}>
        <button>First</button>
        <button>Second</button>
        <button disabled>Disabled</button>
        <button tabIndex={-1}>Skipped</button>
        <input type="hidden" name="token" />
      </Dialog>,
    );
    await user.tab();
    expect(screen.getByRole("button", { name: "Second" })).toHaveFocus();
    await user.tab();
    expect(screen.getByRole("button", { name: "First" })).toHaveFocus();
  });

  it("keeps focus on the dialog when there are no focusable children", async () => {
    const user = userEvent.setup();
    render(
      <Dialog open title="Confirm" onOpenChange={() => {}}>
        <p>Just text</p>
      </Dialog>,
    );
    await user.tab();
    expect(screen.getByRole("dialog")).toHaveFocus();
  });
});

describe("Dialog dismissal (D4)", () => {
  it("calls onOpenChange(false) on Escape", async () => {
    const user = userEvent.setup();
    const { onOpenChange } = renderDialog();
    await user.keyboard("{Escape}");
    expect(onOpenChange).toHaveBeenCalledWith(false);
  });

  it("calls onOpenChange(false) on a click on the backdrop", async () => {
    const user = userEvent.setup();
    const { onOpenChange } = renderDialog();
    await user.click(backdropOf(screen.getByRole("dialog")));
    expect(onOpenChange).toHaveBeenCalledWith(false);
  });

  it("does not close on a click inside the dialog content", async () => {
    const user = userEvent.setup();
    const { onOpenChange } = renderDialog();
    await user.click(screen.getByRole("heading", { name: "Confirm" }));
    await user.click(screen.getByRole("button", { name: "Ok" }));
    expect(onOpenChange).not.toHaveBeenCalled();
  });

  it("does not close when the press starts inside the content and ends on the backdrop", () => {
    const { onOpenChange } = renderDialog();
    const dialog = screen.getByRole("dialog");
    fireEvent.mouseDown(screen.getByRole("button", { name: "Ok" }));
    fireEvent.mouseUp(backdropOf(dialog));
    fireEvent.click(backdropOf(dialog));
    expect(onOpenChange).not.toHaveBeenCalled();
  });
});

describe("Dialog focus restore (D5)", () => {
  it("returns focus to the previously focused element when closed", () => {
    const { rerender } = render(<DialogHarness open={false} />);
    screen.getByRole("button", { name: "Trigger" }).focus();
    rerender(<DialogHarness open />);
    expect(screen.getByRole("button", { name: "Ok" })).toHaveFocus();
    rerender(<DialogHarness open={false} />);
    expect(screen.getByRole("button", { name: "Trigger" })).toHaveFocus();
  });

  it("does not throw or move focus to a trigger that left the document", () => {
    function TriggerHarness({ open, showTrigger }: { open: boolean; showTrigger: boolean }) {
      return (
        <>
          {showTrigger ? <button>Trigger</button> : null}
          <Dialog open={open} title="Confirm" onOpenChange={() => {}}>
            <button>Ok</button>
          </Dialog>
        </>
      );
    }
    const { rerender } = render(<TriggerHarness open={false} showTrigger />);
    screen.getByRole("button", { name: "Trigger" }).focus();
    rerender(<TriggerHarness open showTrigger />);
    rerender(<TriggerHarness open showTrigger={false} />);
    expect(() => rerender(<TriggerHarness open={false} showTrigger={false} />)).not.toThrow();
    expect(document.activeElement).toBe(document.body);
  });
});

describe("Dialog hostile cases (D6)", () => {
  it("Escape inside an open Combobox closes only the popup", async () => {
    const user = userEvent.setup();
    const onOpenChange = vi.fn();
    render(
      <Dialog open title="Pick" onOpenChange={onOpenChange}>
        <Combobox label="Fruit" options={fruits} />
      </Dialog>,
    );
    const input = screen.getByRole("combobox", { name: "Fruit" });
    await user.type(input, "a");
    expect(input).toHaveAttribute("aria-expanded", "true");
    await user.keyboard("{Escape}");
    expect(input).toHaveAttribute("aria-expanded", "false");
    expect(onOpenChange).not.toHaveBeenCalled();
    expect(screen.getByRole("dialog")).toBeInTheDocument();
    await user.keyboard("{Escape}");
    expect(onOpenChange).toHaveBeenCalledWith(false);
  });

  it("ignores an Escape that a child already prevented", async () => {
    const user = userEvent.setup();
    const onOpenChange = vi.fn();
    render(
      <Dialog open title="Confirm" onOpenChange={onOpenChange}>
        <input onKeyDown={(e) => e.preventDefault()} aria-label="Guarded" />
      </Dialog>,
    );
    await user.click(screen.getByRole("textbox", { name: "Guarded" }));
    await user.keyboard("{Escape}");
    expect(onOpenChange).not.toHaveBeenCalled();
  });

  it("moves focus in when mounted open and restores it when the parent unmounts it", async () => {
    const user = userEvent.setup();
    function MountOpen() {
      const [show, setShow] = useState(false);
      return (
        <>
          <button onClick={() => setShow(true)}>Show</button>
          {show && (
            <Dialog open title="Mounted" onOpenChange={() => setShow(false)}>
              <button>Inner</button>
            </Dialog>
          )}
        </>
      );
    }
    render(<MountOpen />);
    await user.click(screen.getByRole("button", { name: "Show" }));
    expect(screen.getByRole("button", { name: "Inner" })).toHaveFocus();
    await user.keyboard("{Escape}");
    expect(screen.queryByRole("dialog")).toBeNull();
    expect(screen.getByRole("button", { name: "Show" })).toHaveFocus();
  });

  it("stays open when the parent keeps open=true after Escape", async () => {
    const user = userEvent.setup();
    const { onOpenChange } = renderDialog();
    await user.keyboard("{Escape}");
    expect(onOpenChange).toHaveBeenCalledWith(false);
    expect(screen.getByRole("dialog")).toBeInTheDocument();
  });
});

describe("Dialog pass-through props (G2)", () => {
  it("applies className and extra attributes to the dialog and still calls user handlers", async () => {
    const user = userEvent.setup();
    const onKeyDown = vi.fn();
    const onOpenChange = vi.fn();
    render(
      <Dialog
        open
        title="Confirm"
        onOpenChange={onOpenChange}
        className="modal"
        data-testid="dlg"
        onKeyDown={onKeyDown}
      >
        <button>Ok</button>
      </Dialog>,
    );
    const dialog = screen.getByTestId("dlg");
    expect(dialog).toBe(screen.getByRole("dialog"));
    expect(dialog).toHaveClass("modal");
    await user.keyboard("{Escape}");
    expect(onKeyDown).toHaveBeenCalled();
    expect(onOpenChange).toHaveBeenCalledWith(false);
  });
});

describe("Dialog backdrop press and release (D4)", () => {
  it("does not close when the press starts on the backdrop and the release lands inside the content", async () => {
    const user = userEvent.setup();
    const { onOpenChange } = renderDialog();
    const backdrop = backdropOf(screen.getByRole("dialog"));
    const text = screen.getByRole("heading", { name: "Confirm" });
    await user.pointer([
      { keys: "[MouseLeft>]", target: backdrop },
      { target: text },
      { keys: "[/MouseLeft]", target: text },
    ]);
    expect(onOpenChange).not.toHaveBeenCalled();
  });

  it("does not close on Enter from an inner button after a right-button press and release on the backdrop", async () => {
    const user = userEvent.setup();
    const { onOpenChange } = renderDialog();
    const backdrop = backdropOf(screen.getByRole("dialog"));
    fireEvent.mouseDown(backdrop, { button: 2 });
    fireEvent.mouseUp(backdrop, { button: 2 });
    screen.getByRole("button", { name: "Ok" }).focus();
    await user.keyboard("{Enter}");
    expect(onOpenChange).not.toHaveBeenCalled();
  });

  it("a later mousedown overwrites a stale primary press on the backdrop", () => {
    const { onOpenChange } = renderDialog();
    const backdrop = backdropOf(screen.getByRole("dialog"));
    fireEvent.mouseDown(backdrop, { button: 0 });
    fireEvent.mouseDown(backdrop, { button: 2 });
    fireEvent.mouseUp(backdrop, { button: 0 });
    fireEvent.click(backdrop);
    expect(onOpenChange).not.toHaveBeenCalled();
  });

  it("resets the press and release flags after each click", () => {
    const { onOpenChange } = renderDialog();
    const backdrop = backdropOf(screen.getByRole("dialog"));
    fireEvent.mouseDown(backdrop);
    fireEvent.mouseUp(backdrop);
    fireEvent.click(backdrop);
    fireEvent.click(backdrop);
    expect(onOpenChange).toHaveBeenCalledTimes(1);
  });
});

describe("Dialog Escape without focus inside (D4)", () => {
  it("closes on Escape after focus has dropped to document.body", async () => {
    const user = userEvent.setup();
    const onOpenChange = vi.fn();
    const { rerender } = render(
      <Dialog open title="Confirm" onOpenChange={onOpenChange}>
        <button>Gone</button>
      </Dialog>,
    );
    expect(screen.getByRole("button", { name: "Gone" })).toHaveFocus();
    rerender(
      <Dialog open title="Confirm" onOpenChange={onOpenChange}>
        <p>Removed the button</p>
      </Dialog>,
    );
    expect(document.activeElement).toBe(document.body);
    await user.keyboard("{Escape}");
    expect(onOpenChange).toHaveBeenCalledWith(false);
  });
});

describe("Nested dialogs (D4, D6)", () => {
  const onOuter = vi.fn();
  const onInner = vi.fn();
  const stack = (innerOpen: boolean) => (
    <Dialog open title="Outer" onOpenChange={onOuter}>
      <Dialog open={innerOpen} title="Inner" onOpenChange={onInner}>
        <button>Inner one</button>
        <button>Inner two</button>
      </Dialog>
    </Dialog>
  );

  it("Escape closes only the topmost dialog, then the outer one once the inner closes", async () => {
    const user = userEvent.setup();
    onOuter.mockClear();
    onInner.mockClear();
    const { rerender } = render(stack(false));
    rerender(stack(true));
    await user.keyboard("{Escape}");
    expect(onInner).toHaveBeenCalledWith(false);
    expect(onOuter).not.toHaveBeenCalled();
    rerender(stack(false));
    await user.keyboard("{Escape}");
    expect(onOuter).toHaveBeenCalledWith(false);
  });

  it("Escape closes only the inner dialog when both are open at mount", async () => {
    const user = userEvent.setup();
    onOuter.mockClear();
    onInner.mockClear();
    render(stack(true));
    await user.keyboard("{Escape}");
    expect(onInner).toHaveBeenCalledWith(false);
    expect(onOuter).not.toHaveBeenCalled();
  });

  it("keeps Tab inside the inner dialog when the outer dialog has no focusable children", async () => {
    const user = userEvent.setup();
    const { rerender } = render(stack(false));
    rerender(stack(true));
    expect(screen.getByRole("button", { name: "Inner one" })).toHaveFocus();
    await user.tab();
    expect(screen.getByRole("button", { name: "Inner two" })).toHaveFocus();
    await user.tab();
    expect(screen.getByRole("button", { name: "Inner one" })).toHaveFocus();
  });
});

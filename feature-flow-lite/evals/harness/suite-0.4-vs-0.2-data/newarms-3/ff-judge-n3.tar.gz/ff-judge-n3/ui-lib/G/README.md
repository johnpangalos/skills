# @acme/ui

Accessible React components (React 19), style-agnostic: no CSS and no class names are imposed. Pass `className` and any other DOM props; they land on the root element of each component. Ids come from `React.useId`, so several instances can share a page.

Components: `Tabs`, `Dialog`, `Combobox`. They follow the WAI-ARIA Authoring Practices patterns for tabs, modal dialogs and combobox with listbox popup.

## Development

- `pnpm test` runs the Vitest suite (jsdom + Testing Library).
- `pnpm typecheck` runs `tsc --noEmit`.

## Tabs

```tsx
import { Tab, TabList, TabPanel, Tabs } from "@acme/ui";

<Tabs defaultValue="profile">
  <TabList aria-label="Account">
    <Tab value="profile">Profile</Tab>
    <Tab value="billing" disabled>Billing</Tab>
    <Tab value="security">Security</Tab>
  </TabList>
  <TabPanel value="profile">Profile settings</TabPanel>
  <TabPanel value="billing">Billing settings</TabPanel>
  <TabPanel value="security">Security settings</TabPanel>
</Tabs>;
```

Selection is uncontrolled by default. Pass `value` with `onValueChange` for controlled use; a parent that ignores the callback keeps the previous tab. When the requested tab is missing or disabled, the first enabled tab is selected.

### Tabs props

| Name | Type | Default | Description |
| --- | --- | --- | --- |
| `defaultValue` | `string` | first enabled tab | Initially selected tab (uncontrolled). |
| `value` | `string` | — | Selected tab (controlled). Wins over `defaultValue`. |
| `onValueChange` | `(value: string) => void` | — | Called on every user selection change. Not called when the selected tab is chosen again. |

Other `div` props are passed to the root element.

### TabList props

| Name | Type | Default | Description |
| --- | --- | --- | --- |
| `aria-label` | `string` | — | Accessible name. Required unless `aria-labelledby` is given. |
| `aria-labelledby` | `string` | — | Id of the element that names the list. |

Other `div` props are passed to the `role="tablist"` element. `onKeyDown` is called before the built-in handling.

### Tab props

| Name | Type | Default | Description |
| --- | --- | --- | --- |
| `value` | `string` | — | Identifies the tab and its panel. Required. |
| `disabled` | `boolean` | `false` | Disables the tab: it cannot be clicked, selected or reached with arrow keys. `aria-disabled="true"` has the same effect. |

Other `button` props are passed to the `role="tab"` button.

### TabPanel props

| Name | Type | Default | Description |
| --- | --- | --- | --- |
| `value` | `string` | — | The tab this panel belongs to. Required. |

Inactive panels are rendered with `hidden`. Other `div` props are passed through.

### Tabs keyboard

| Key | Behavior |
| --- | --- |
| Tab | Moves focus into the selected tab, then into its panel. Only the selected tab is in the tab order. |
| ArrowRight | Moves to the next enabled tab, wrapping from the last to the first. Selects it. |
| ArrowLeft | Moves to the previous enabled tab, wrapping from the first to the last. Selects it. |
| Home | Moves to the first enabled tab and selects it. |
| End | Moves to the last enabled tab and selects it. |

Arrow and Home/End keys call `preventDefault`. Tab order follows the DOM order of the tabs, so tabs added or removed later are handled.

## Dialog

```tsx
import { Dialog } from "@acme/ui";

<Dialog open={open} onOpenChange={setOpen} title="Delete project" description="This cannot be undone.">
  <button type="button" onClick={remove}>Delete</button>
</Dialog>;
```

The dialog renders nothing while `open` is false. When open it is rendered into `document.body` through a portal, with a backdrop element around `role="dialog"`. Focus moves to the first tabbable element inside (or to the dialog itself if there is none), Tab and Shift+Tab cycle within the dialog, and focus returns to the previously focused element when the dialog closes or unmounts.

Dialogs nest. Open dialogs form a stack ordered by nesting depth, so a dialog rendered inside another is always above it, even when both mount open in the same render. Escape closes only the top-most dialog, and Tab and focus stay within it, so an inner dialog never closes or hands focus to the outer one.

### Dialog props

| Name | Type | Default | Description |
| --- | --- | --- | --- |
| `open` | `boolean` | — | Whether the dialog is shown. Required. |
| `onOpenChange` | `(open: boolean) => void` | — | Called with `false` on Escape or a backdrop click. Required. |
| `title` | `ReactNode` | — | Rendered in an `h2`; labels the dialog. Required. |
| `description` | `ReactNode` | — | Rendered in a `p`; describes the dialog. When omitted, `aria-describedby` is absent. |
| `children` | `ReactNode` | — | Dialog content. |

`className` and other `div` props are passed to the `role="dialog"` element. The backdrop element has a `data-backdrop` attribute for styling.

### Dialog keyboard and pointer

| Input | Behavior |
| --- | --- |
| Escape | Calls `onOpenChange(false)` on the top-most dialog, unless an inner component already handled the key (`defaultPrevented`). A nested `Combobox` consumes Escape while its list is open. Escape in an inner dialog does not close the outer one. |
| Tab | Moves to the next tabbable element; from the last, wraps to the first. |
| Shift+Tab | Moves to the previous tabbable element; from the first, wraps to the last. |
| Click on backdrop | Calls `onOpenChange(false)` when the press and the release both happen on the backdrop. A press that starts inside the dialog and ends on the backdrop does not close it. |
| Click inside | Does not close the dialog. |

Tabbable elements exclude disabled elements, elements with `tabindex` below 0, and hidden inputs. The list is computed at each keypress, so content added after opening is included.

## Combobox

```tsx
import { Combobox, type ComboboxOption } from "@acme/ui";

const fruits: ComboboxOption<string>[] = [
  { value: "apple", label: "Apple" },
  { value: "kiwi", label: "Kiwi", disabled: true },
];

<Combobox label="Fruit" options={fruits} placeholder="Search fruit" onChange={(value) => setFruit(value)} />;
```

Use a generic type for other value types, for example `Combobox<number>`; `onChange` then receives `number | null`.

Typing filters the options by case-insensitive substring match. Regex characters are matched literally, and an empty or whitespace-only query shows all options. Typing that empties the input leaves no option active; ArrowDown then activates the first enabled option, and ArrowUp the last.

### Combobox props

| Name | Type | Default | Description |
| --- | --- | --- | --- |
| `label` | `string` | — | Visible label for the input. Also names the listbox. Required. |
| `options` | `ComboboxOption<T>[]` | — | `{ value, label, disabled? }` entries. Required. |
| `value` | `T \| null` | — | Selected option value (controlled). `null` means no selection. |
| `defaultValue` | `T \| null` | `null` | Initial selection (uncontrolled). |
| `onChange` | `(value: T \| null) => void` | — | Called when an option is chosen, or with `null` when the text is cleared and the input loses focus (or Enter is pressed with empty text). |
| `placeholder` | `string` | — | Placeholder for the input. |

`T` is `string | number` and defaults to `string`. The value `0` is a real value. Other `div` props are passed to the root element.

### Combobox keyboard

| Key | Behavior |
| --- | --- |
| ArrowDown | Opens the list if closed (activating the first enabled option). Otherwise moves the active option to the next enabled option, wrapping from the last to the first. |
| ArrowUp | Opens the list if closed (activating the last enabled option). Otherwise moves to the previous enabled option, wrapping from the first to the last. |
| Enter | With an active option: selects it, closes the list and shows its label. With no active option: does nothing, unless the text is empty and a value is selected, which clears the selection (`onChange(null)`). |
| Escape | While the list is open: closes it without selecting and restores the selected label. Stops propagation, so an enclosing `Dialog` stays open. |
| Typing | Opens the list and filters the options. |
| Blur | Closes the list and restores the selected label. If the text is empty and a value was selected, calls `onChange(null)`. |

Focus stays on the input throughout. The active option is exposed through `aria-activedescendant`, which is absent when no option is active. Disabled options are skipped by the arrow keys, and clicking one does nothing. A click on an enabled option selects it. When nothing matches, the list shows a "No results" status message.

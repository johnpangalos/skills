import {
  useId,
  useState,
  type ChangeEvent,
  type ComponentPropsWithoutRef,
  type KeyboardEvent,
} from "react";

export type ComboboxOption = {
  value: string;
  label: string;
  disabled?: boolean;
};

// Extra props go to the input. The ARIA wiring is applied after the spread, so it cannot be overridden.
export type ComboboxProps = Omit<
  ComponentPropsWithoutRef<"input">,
  "value" | "onChange" | "onKeyDown" | "onBlur" | "defaultValue"
> & {
  label: string;
  options: ComboboxOption[];
  value: string | null;
  onChange: (value: string | null) => void;
};

function optionId(baseId: string, value: string): string {
  return `${baseId}-option-${encodeURIComponent(value)}`;
}

export function Combobox({ label, options, value, onChange, ...rest }: ComboboxProps) {
  const baseId = useId();
  const inputId = `${baseId}-input`;
  const labelId = `${baseId}-label`;
  const listboxId = `${baseId}-listbox`;
  const [open, setOpen] = useState(false);
  // null while the user is not typing; the input then shows the selected option's label.
  const [query, setQuery] = useState<string | null>(null);
  const [activeValue, setActiveValue] = useState<string | null>(null);
  const [seenValue, setSeenValue] = useState(value);

  // An external change to value drops any typed text and active option.
  if (value !== seenValue) {
    setSeenValue(value);
    setQuery(null);
    setActiveValue(null);
  }

  const selectedOption = options.find((option) => option.value === value);
  const text = query ?? selectedOption?.label ?? "";
  const needle = (query ?? "").toLowerCase();
  const matches = options.filter((option) => option.label.toLowerCase().includes(needle));
  const enabled = matches.filter((option) => !option.disabled);
  // An active value that is no longer enabled and visible counts as no active option.
  const activeOption = enabled.find((option) => option.value === activeValue);

  function close() {
    setOpen(false);
    setQuery(null);
    setActiveValue(null);
  }

  function choose(next: string) {
    onChange(next);
    close();
  }

  function handleInput(event: ChangeEvent<HTMLInputElement>) {
    setQuery(event.target.value);
    setOpen(true);
    setActiveValue(null);
  }

  function handleKeyDown(event: KeyboardEvent<HTMLInputElement>) {
    switch (event.key) {
      case "ArrowDown":
      case "ArrowUp": {
        event.preventDefault();
        setOpen(true);
        if (enabled.length === 0) return;
        // Wraps at both ends.
        const step = event.key === "ArrowDown" ? 1 : -1;
        const current = enabled.findIndex((option) => option.value === activeValue);
        const next =
          current === -1
            ? (step === 1 ? 0 : enabled.length - 1)
            : (current + step + enabled.length) % enabled.length;
        setActiveValue(enabled[next].value);
        return;
      }
      case "Enter": {
        if (!open) return;
        // Only Enter that selects or clears prevents default, so a surrounding form still submits otherwise.
        if (activeOption !== undefined) {
          event.preventDefault();
          choose(activeOption.value);
        } else if (query === "" && value !== null) {
          event.preventDefault();
          onChange(null);
          close();
        }
        return;
      }
      case "Escape":
        if (!open) return;
        // Consume the Escape so an enclosing dialog stays open while the listbox closes.
        event.preventDefault();
        event.stopPropagation();
        close();
        return;
    }
  }

  function handleBlur() {
    if (query === "" && value !== null) onChange(null);
    close();
  }

  return (
    <>
      <label id={labelId} htmlFor={inputId}>
        {label}
      </label>
      <input
        {...rest}
        id={inputId}
        role="combobox"
        type="text"
        autoComplete="off"
        value={text}
        aria-autocomplete="list"
        aria-expanded={open}
        aria-controls={listboxId}
        aria-activedescendant={
          open && activeOption !== undefined ? optionId(baseId, activeOption.value) : undefined
        }
        onChange={handleInput}
        onKeyDown={handleKeyDown}
        onBlur={handleBlur}
      />
      <ul id={listboxId} role="listbox" aria-labelledby={labelId} hidden={!open}>
        {matches.map((option) => (
          <li
            key={option.value}
            id={optionId(baseId, option.value)}
            role="option"
            aria-selected={option.value === value}
            aria-disabled={option.disabled ? true : undefined}
            data-active={option.value === activeOption?.value || undefined}
            // Keep focus in the input: a mousedown that moved focus would blur and close the listbox first.
            onMouseDown={(event) => event.preventDefault()}
            onClick={() => {
              if (!option.disabled) choose(option.value);
            }}
          >
            {option.label}
          </li>
        ))}
      </ul>
      {open && matches.length === 0 && <p role="status">No results</p>}
    </>
  );
}

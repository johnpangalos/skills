import {
  useId,
  useState,
  type ChangeEvent,
  type ComponentPropsWithoutRef,
  type KeyboardEvent,
} from "react";

export type ComboboxValue = string | number;

export type ComboboxOption<T extends string | number = string | number> = {
  value: T;
  label: string;
  disabled?: boolean;
};

export type ComboboxProps<T extends string | number = string | number> = Omit<
  ComponentPropsWithoutRef<"div">,
  "onChange"
> & {
  label: string;
  options: ComboboxOption<T>[];
  value: T | null;
  onChange: (value: T | null) => void;
  placeholder?: string;
};

// A null query means nothing has been typed, so every option is shown.
function filterOptions<T extends string | number>(options: ComboboxOption<T>[], query: string | null): ComboboxOption<T>[] {
  if (query === null) return options;
  const needle = query.toLowerCase();
  return options.filter((option) => option.label.toLowerCase().includes(needle));
}

// Index of the next enabled option after `from` (-1 means none active yet), wrapping; -1 if none is enabled.
function nextEnabledIndex<T extends string | number>(options: ComboboxOption<T>[], from: number): number {
  const count = options.length;
  for (let offset = 1; offset <= count; offset++) {
    const index = (from + offset) % count;
    if (!options[index].disabled) return index;
  }
  return -1;
}

// Same as nextEnabledIndex, moving backwards; starting from "none active" begins at the last option.
function previousEnabledIndex<T extends string | number>(options: ComboboxOption<T>[], from: number): number {
  const count = options.length;
  const start = from < 0 ? count : from;
  for (let offset = 1; offset <= count; offset++) {
    const index = (((start - offset) % count) + count) % count;
    if (!options[index].disabled) return index;
  }
  return -1;
}

export function Combobox<T extends string | number>({ label, options, value, onChange, placeholder, ...props }: ComboboxProps<T>) {
  const baseId = useId();
  const inputId = `${baseId}-input`;
  const listboxId = `${baseId}-listbox`;
  const [open, setOpen] = useState(false);
  // Null while the input shows the selected label; set to the typed text while editing.
  const [query, setQuery] = useState<string | null>(null);
  const [activeIndex, setActiveIndex] = useState(-1);

  const visible = filterOptions(options, query);
  const selectedOption = options.find((option) => option.value === value);
  // close() resets activeIndex and it is only set while open, so it is always -1 when closed.
  const activeOption = visible[activeIndex];

  function close() {
    setOpen(false);
    setQuery(null);
    setActiveIndex(-1);
  }

  function choose(option: ComboboxOption<T>) {
    onChange(option.value);
    close();
  }

  function handleChange(event: ChangeEvent<HTMLInputElement>) {
    const next = event.target.value;
    setQuery(next);
    setOpen(true);
    setActiveIndex(nextEnabledIndex(filterOptions(options, next), -1));
  }

  function handleKeyDown(event: KeyboardEvent<HTMLInputElement>) {
    switch (event.key) {
      case "ArrowDown":
        event.preventDefault();
        setOpen(true);
        setActiveIndex(nextEnabledIndex(visible, activeIndex));
        return;
      case "ArrowUp":
        event.preventDefault();
        setOpen(true);
        setActiveIndex(previousEnabledIndex(visible, activeIndex));
        return;
      case "Enter":
        // Only an open list takes Enter; when closed, a surrounding form submits as usual.
        if (!open) return;
        event.preventDefault();
        if (activeOption && !activeOption.disabled) choose(activeOption);
        return;
      case "Escape":
        if (open) {
          // Close only the popup, not an enclosing Dialog.
          event.stopPropagation();
          close();
        }
        return;
    }
  }

  return (
    <div {...props}>
      <label htmlFor={inputId}>{label}</label>
      <input
        id={inputId}
        type="text"
        role="combobox"
        autoComplete="off"
        placeholder={placeholder}
        value={query ?? selectedOption?.label ?? ""}
        aria-expanded={open}
        aria-controls={listboxId}
        aria-autocomplete="list"
        aria-activedescendant={activeOption ? `${baseId}-option-${activeIndex}` : undefined}
        onChange={handleChange}
        onKeyDown={handleKeyDown}
        onBlur={close}
      />
      {/* Always mounted so aria-controls always resolves; hidden unless open. */}
      <ul id={listboxId} role="listbox" hidden={!open}>
        {open &&
          visible.map((option, index) => (
            <li
              key={index}
              id={`${baseId}-option-${index}`}
              role="option"
              aria-selected={option.value === value}
              aria-disabled={option.disabled || undefined}
              // Keeps focus in the input so the blur handler does not close the popup before the click lands.
              onMouseDown={(event) => event.preventDefault()}
              onClick={() => {
                if (!option.disabled) choose(option);
              }}
            >
              {option.label}
            </li>
          ))}
      </ul>
      {open && visible.length === 0 && <div role="status">No results</div>}
    </div>
  );
}

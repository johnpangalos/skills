import { render, screen } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { useState } from "react";
import { describe, expect, it, vi } from "vitest";
import { Dialog } from "../Dialog/Dialog";
import { Tab, TabList, TabPanel, Tabs, type TabsProps } from "./Tabs";

function Sample({ disabled = [], ...tabsProps }: Omit<TabsProps, "children"> & { disabled?: string[] }) {
  const values = ["a", "b", "c"];
  return (
    <Tabs {...tabsProps}>
      <TabList aria-label="Settings">
        {values.map((value) => (
          <Tab key={value} value={value} disabled={disabled.includes(value)}>
            Tab {value}
          </Tab>
        ))}
      </TabList>
      {values.map((value) => (
        <TabPanel key={value} value={value}>
          Panel {value}
        </TabPanel>
      ))}
    </Tabs>
  );
}

function Controlled({ onValueChange }: { onValueChange: (value: string) => void }) {
  const [value, setValue] = useState("a");
  return (
    <Sample
      value={value}
      onValueChange={(next) => {
        onValueChange(next);
        setValue(next);
      }}
    />
  );
}

function Dynamic({ showB }: { showB: boolean }) {
  return (
    <Tabs defaultValue="a">
      <TabList aria-label="Dynamic">
        <Tab value="a">Tab a</Tab>
        {showB && <Tab value="b">Tab b</Tab>}
        <Tab value="c">Tab c</Tab>
      </TabList>
      <TabPanel value="a">Panel a</TabPanel>
    </Tabs>
  );
}

// A Tab owned by a child component that mounts and unmounts on its own.
function RemovableTab({ show }: { show: boolean }) {
  return show ? <Tab value="x">X</Tab> : null;
}

function RemovableTabs() {
  const [show, setShow] = useState(true);
  return (
    <Tabs defaultValue="x">
      <TabList aria-label="Removable">
        <Tab value="a">A</Tab>
        <RemovableTab show={show} />
      </TabList>
      <TabPanel value="a">Panel A</TabPanel>
      <button type="button" onClick={() => setShow(false)}>
        Remove
      </button>
    </Tabs>
  );
}

function AddedTabs() {
  const [show, setShow] = useState(false);
  return (
    <Tabs>
      <TabList aria-label="Added">
        <Tab value="a" disabled>
          A
        </Tab>
        <RemovableTab show={show} />
      </TabList>
      <button type="button" onClick={() => setShow(true)}>
        Add
      </button>
    </Tabs>
  );
}

describe("Tabs", () => {
  it("selects the defaultValue tab and shows only its panel", () => {
    render(<Sample defaultValue="b" />);
    expect(screen.getByRole("tab", { name: "Tab b" })).toHaveAttribute("aria-selected", "true");
    expect(screen.getByRole("tab", { name: "Tab a" })).toHaveAttribute("aria-selected", "false");
    expect(screen.getByRole("tabpanel")).toHaveTextContent("Panel b");
    expect(screen.getAllByRole("tabpanel", { hidden: true })).toHaveLength(3);
  });

  it("selects the first enabled tab when neither value nor defaultValue is given", () => {
    render(<Sample disabled={["a"]} />);
    expect(screen.getByRole("tab", { name: "Tab b" })).toHaveAttribute("aria-selected", "true");
    expect(screen.getByRole("tab", { name: "Tab a" })).toHaveAttribute("aria-selected", "false");
  });

  it("controlled value changes only when the parent updates it, and onValueChange is still called", async () => {
    const user = userEvent.setup();
    const onValueChange = vi.fn();
    const { rerender } = render(<Sample value="a" onValueChange={onValueChange} />);
    await user.click(screen.getByRole("tab", { name: "Tab b" }));
    expect(onValueChange).toHaveBeenCalledWith("b");
    expect(screen.getByRole("tab", { name: "Tab a" })).toHaveAttribute("aria-selected", "true");
    expect(screen.getByRole("tab", { name: "Tab b" })).toHaveAttribute("aria-selected", "false");
    rerender(<Sample value="c" onValueChange={onValueChange} />);
    expect(screen.getByRole("tab", { name: "Tab c" })).toHaveAttribute("aria-selected", "true");
  });

  it("parent-controlled state moves selection when the parent updates value", async () => {
    const user = userEvent.setup();
    const onValueChange = vi.fn();
    render(<Controlled onValueChange={onValueChange} />);
    await user.click(screen.getByRole("tab", { name: "Tab c" }));
    expect(onValueChange).toHaveBeenCalledWith("c");
    expect(screen.getByRole("tab", { name: "Tab c" })).toHaveAttribute("aria-selected", "true");
    expect(screen.getByRole("tabpanel")).toHaveTextContent("Panel c");
  });

  it("TabList has tablist role, its aria-label and horizontal orientation", () => {
    render(<Sample />);
    const tablist = screen.getByRole("tablist", { name: "Settings" });
    expect(tablist).toHaveAttribute("aria-orientation", "horizontal");
  });

  it("wires tab and panel with button type, aria-controls, aria-labelledby and roving tabIndex", () => {
    render(<Sample />);
    const tab = screen.getByRole("tab", { name: "Tab a" });
    const other = screen.getByRole("tab", { name: "Tab b" });
    const panel = screen.getByRole("tabpanel");
    expect(tab.tagName).toBe("BUTTON");
    expect(tab).toHaveAttribute("type", "button");
    expect(tab).toHaveAttribute("aria-controls", panel.id);
    expect(panel).toHaveAttribute("aria-labelledby", tab.id);
    expect(panel).toHaveAttribute("tabindex", "0");
    expect(tab).toHaveAttribute("tabindex", "0");
    expect(other).toHaveAttribute("tabindex", "-1");
  });

  it("a child-owned Tab that unmounts hands tabIndex 0 back to an enabled tab, so the list stays reachable", async () => {
    const user = userEvent.setup();
    render(<RemovableTabs />);
    expect(screen.getByRole("tab", { name: "X" })).toHaveAttribute("tabindex", "0");
    await user.click(screen.getByRole("button", { name: "Remove" }));
    (document.activeElement as HTMLElement).blur();
    expect(screen.queryByRole("tab", { name: "X" })).toBeNull();
    expect(screen.getByRole("tab", { name: "A" })).toHaveAttribute("tabindex", "0");
    await user.tab();
    expect(screen.getByRole("tab", { name: "A" })).toHaveFocus();
  });

  it("a child-owned enabled Tab that mounts when no tab was enabled becomes the tabIndex 0 tab", async () => {
    const user = userEvent.setup();
    render(<AddedTabs />);
    expect(screen.getByRole("tab", { name: "A" })).toHaveAttribute("tabindex", "-1");
    await user.click(screen.getByRole("button", { name: "Add" }));
    (document.activeElement as HTMLElement).blur();
    expect(screen.getByRole("tab", { name: "X" })).toHaveAttribute("tabindex", "0");
    await user.tab();
    expect(screen.getByRole("tab", { name: "X" })).toHaveFocus();
  });

  it("arrow keys from a focused disabled tab move to the next and previous enabled tabs", async () => {
    const user = userEvent.setup();
    render(<Sample disabled={["b"]} defaultValue="a" />);
    await user.click(screen.getByRole("tab", { name: "Tab b" }));
    expect(screen.getByRole("tab", { name: "Tab b" })).toHaveFocus();
    await user.keyboard("{ArrowRight}");
    expect(screen.getByRole("tab", { name: "Tab c" })).toHaveFocus();
    await user.click(screen.getByRole("tab", { name: "Tab b" }));
    await user.keyboard("{ArrowLeft}");
    expect(screen.getByRole("tab", { name: "Tab a" })).toHaveFocus();
  });

  it("disabled tab has aria-disabled and cannot be selected by click or keyboard", async () => {
    const user = userEvent.setup();
    render(<Sample disabled={["b"]} />);
    const disabled = screen.getByRole("tab", { name: "Tab b" });
    expect(disabled).toHaveAttribute("aria-disabled", "true");
    await user.click(disabled);
    expect(disabled).toHaveAttribute("aria-selected", "false");
    expect(screen.getByRole("tab", { name: "Tab a" })).toHaveAttribute("aria-selected", "true");
    await user.click(screen.getByRole("tab", { name: "Tab a" }));
    await user.keyboard("{ArrowRight}");
    expect(screen.getByRole("tab", { name: "Tab c" })).toHaveFocus();
    expect(screen.getByRole("tab", { name: "Tab c" })).toHaveAttribute("aria-selected", "true");
  });

  it("ArrowRight and ArrowLeft move focus and selection, wrapping at both ends", async () => {
    const user = userEvent.setup();
    render(<Sample />);
    await user.tab();
    expect(screen.getByRole("tab", { name: "Tab a" })).toHaveFocus();
    await user.keyboard("{ArrowRight}");
    expect(screen.getByRole("tab", { name: "Tab b" })).toHaveFocus();
    expect(screen.getByRole("tab", { name: "Tab b" })).toHaveAttribute("aria-selected", "true");
    await user.keyboard("{ArrowRight}{ArrowRight}");
    expect(screen.getByRole("tab", { name: "Tab a" })).toHaveFocus();
    await user.keyboard("{ArrowLeft}");
    expect(screen.getByRole("tab", { name: "Tab c" })).toHaveFocus();
    expect(screen.getByRole("tab", { name: "Tab c" })).toHaveAttribute("aria-selected", "true");
  });

  it("arrow keys skip disabled tabs", async () => {
    const user = userEvent.setup();
    render(<Sample disabled={["b"]} />);
    await user.tab();
    await user.keyboard("{ArrowRight}");
    expect(screen.getByRole("tab", { name: "Tab c" })).toHaveFocus();
    await user.keyboard("{ArrowLeft}");
    expect(screen.getByRole("tab", { name: "Tab a" })).toHaveFocus();
  });

  it("Home and End move to the first and last enabled tab", async () => {
    const user = userEvent.setup();
    render(<Sample disabled={["a"]} />);
    await user.tab();
    expect(screen.getByRole("tab", { name: "Tab b" })).toHaveFocus();
    await user.keyboard("{End}");
    expect(screen.getByRole("tab", { name: "Tab c" })).toHaveFocus();
    await user.keyboard("{Home}");
    expect(screen.getByRole("tab", { name: "Tab b" })).toHaveFocus();
  });

  it("other keys do nothing", async () => {
    const user = userEvent.setup();
    const onValueChange = vi.fn();
    render(<Sample onValueChange={onValueChange} />);
    await user.tab();
    await user.keyboard("x");
    expect(screen.getByRole("tab", { name: "Tab a" })).toHaveFocus();
    expect(onValueChange).not.toHaveBeenCalled();
  });

  it("Tab enters the tablist on the selected tab and the next Tab leaves it for the panel", async () => {
    const user = userEvent.setup();
    render(<Sample defaultValue="b" />);
    await user.tab();
    expect(screen.getByRole("tab", { name: "Tab b" })).toHaveFocus();
    await user.tab();
    expect(screen.getByRole("tabpanel")).toHaveFocus();
  });

  it("with all tabs but one disabled, arrows keep focus on the one enabled tab", async () => {
    const user = userEvent.setup();
    render(<Sample disabled={["a", "c"]} />);
    await user.tab();
    expect(screen.getByRole("tab", { name: "Tab b" })).toHaveFocus();
    await user.keyboard("{ArrowRight}{ArrowLeft}{Home}{End}");
    expect(screen.getByRole("tab", { name: "Tab b" })).toHaveFocus();
    expect(screen.getByRole("tab", { name: "Tab b" })).toHaveAttribute("aria-selected", "true");
  });

  it("with every tab disabled, arrow keys do not loop or throw", async () => {
    const user = userEvent.setup();
    render(<Sample disabled={["a", "b", "c"]} />);
    await user.click(screen.getByRole("tab", { name: "Tab a" }));
    await user.keyboard("{ArrowRight}{ArrowLeft}");
    expect(screen.getByRole("tab", { name: "Tab a" })).toHaveFocus();
  });

  it("a defaultValue naming a disabled tab keeps the first enabled tab reachable", async () => {
    const user = userEvent.setup();
    render(<Sample defaultValue="a" disabled={["a"]} />);
    await user.tab();
    expect(screen.getByRole("tab", { name: "Tab b" })).toHaveFocus();
    expect(screen.getByRole("tab", { name: "Tab b" })).toHaveAttribute("tabindex", "0");
  });

  it("a value naming no tab keeps the first enabled tab reachable", async () => {
    const user = userEvent.setup();
    render(<Sample value="missing" onValueChange={() => {}} />);
    await user.tab();
    expect(screen.getByRole("tab", { name: "Tab a" })).toHaveFocus();
  });

  it("keyboard order follows DOM order when tabs are added and removed", async () => {
    const user = userEvent.setup();
    const { rerender } = render(<Dynamic showB />);
    await user.tab();
    await user.keyboard("{ArrowRight}");
    expect(screen.getByRole("tab", { name: "Tab b" })).toHaveFocus();
    await user.keyboard("{ArrowRight}");
    expect(screen.getByRole("tab", { name: "Tab c" })).toHaveFocus();
    rerender(<Dynamic showB={false} />);
    await user.keyboard("{ArrowLeft}");
    expect(screen.getByRole("tab", { name: "Tab a" })).toHaveFocus();
    await user.keyboard("{ArrowRight}");
    expect(screen.getByRole("tab", { name: "Tab c" })).toHaveFocus();
  });

  it("controlled value that ignores onValueChange: focus moves but aria-selected does not change", async () => {
    const user = userEvent.setup();
    const onValueChange = vi.fn();
    render(<Sample value="a" onValueChange={onValueChange} />);
    await user.tab();
    await user.keyboard("{ArrowRight}");
    expect(screen.getByRole("tab", { name: "Tab b" })).toHaveFocus();
    expect(onValueChange).toHaveBeenCalledWith("b");
    expect(screen.getByRole("tab", { name: "Tab a" })).toHaveAttribute("aria-selected", "true");
    expect(screen.getByRole("tab", { name: "Tab b" })).toHaveAttribute("aria-selected", "false");
  });

  it("passes className and extra props through to every part", () => {
    render(
      <Tabs className="root" data-testid="root" defaultValue="a">
        <TabList aria-label="Pass" className="list" data-testid="list">
          <Tab value="a" className="tab" data-testid="tab">
            A
          </Tab>
        </TabList>
        <TabPanel value="a" className="panel" data-testid="panel">
          Panel
        </TabPanel>
      </Tabs>,
    );
    expect(screen.getByTestId("root")).toHaveClass("root");
    expect(screen.getByTestId("list")).toHaveClass("list");
    expect(screen.getByTestId("tab")).toHaveClass("tab");
    expect(screen.getByTestId("panel")).toHaveClass("panel");
  });

  it("two instances on one page have unique ids and independent state", async () => {
    const user = userEvent.setup();
    render(
      <>
        <Sample />
        <Sample />
      </>,
    );
    const ids = Array.from(document.querySelectorAll("[id]")).map((element) => element.id);
    expect(new Set(ids).size).toBe(ids.length);
    const [first, second] = screen.getAllByRole("tablist");
    await user.click(first.querySelector<HTMLElement>('[role="tab"]:nth-child(2)') as HTMLElement);
    expect(first.querySelector('[aria-selected="true"]')).toHaveTextContent("Tab b");
    expect(second.querySelector('[aria-selected="true"]')).toHaveTextContent("Tab a");
  });

  it("Tab throws a clear error when rendered outside Tabs", () => {
    vi.spyOn(console, "error").mockImplementation(() => {});
    expect(() => render(<Tab value="a">A</Tab>)).toThrow("Tab components must be rendered inside <Tabs>");
    vi.restoreAllMocks();
  });

  it("a Tabs inside an open Dialog focuses the selected tab, not the panel, when the dialog opens", () => {
    render(
      <Dialog open onOpenChange={() => {}} title="T">
        <Tabs defaultValue="b">
          <TabList aria-label="x">
            <Tab value="a">A</Tab>
            <Tab value="b">B</Tab>
          </TabList>
          <TabPanel value="a">pa</TabPanel>
          <TabPanel value="b">pb</TabPanel>
        </Tabs>
      </Dialog>,
    );
    expect(screen.getByRole("tab", { name: "B" })).toHaveFocus();
  });

  it("a child-owned Tab whose value changes in place leaves exactly one tab with tabIndex 0", async () => {
    const user = userEvent.setup();
    render(<RenamedTabs />);
    expect(document.querySelectorAll('[role="tab"][tabindex="0"]')).toHaveLength(1);
    await user.click(screen.getByRole("button", { name: "Rename" }));
    expect(document.querySelectorAll('[role="tab"][tabindex="0"]')).toHaveLength(1);
  });
});

// Owns the value of the Tab it renders, so changing the value re-renders only this child.
function RenamedKid() {
  const [value, setValue] = useState("p");
  return (
    <>
      <Tab value={value}>Kid</Tab>
      <button type="button" onClick={() => setValue("q")}>
        Rename
      </button>
    </>
  );
}

function RenamedTabs() {
  return (
    <Tabs defaultValue="p">
      <TabList aria-label="Renamed">
        <Tab value="o">O</Tab>
        <RenamedKid />
      </TabList>
    </Tabs>
  );
}

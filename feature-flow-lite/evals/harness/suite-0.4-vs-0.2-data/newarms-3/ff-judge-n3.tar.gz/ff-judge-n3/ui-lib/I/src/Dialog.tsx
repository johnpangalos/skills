import {
  useId,
  useLayoutEffect,
  useRef,
  type ComponentPropsWithoutRef,
  type KeyboardEvent,
  type MouseEvent,
  type ReactNode,
} from "react";
import { createPortal } from "react-dom";

const FOCUSABLE =
  'a[href], button:not([disabled]), input:not([disabled]), select:not([disabled]), textarea:not([disabled]), [tabindex]:not([tabindex="-1"])';

// Candidates that cannot take focus are dropped, so the trap never wraps onto one of them.
function focusableIn(container: HTMLElement): HTMLElement[] {
  return Array.from(container.querySelectorAll<HTMLElement>(FOCUSABLE)).filter(
    (element) =>
      element.tabIndex >= 0 &&
      !element.matches(":disabled") &&
      element.closest('input[type="hidden"], [hidden], [inert]') === null,
  );
}

function focusFirst(container: HTMLElement): void {
  (focusableIn(container)[0] ?? container).focus();
}

export type DialogProps = Omit<ComponentPropsWithoutRef<"div">, "onKeyDown" | "title"> & {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  title: ReactNode;
  description?: ReactNode;
};

export function Dialog({ open, onOpenChange, title, description, children, ...rest }: DialogProps) {
  const baseId = useId();
  const titleId = `${baseId}-title`;
  const descriptionId = `${baseId}-description`;
  const dialogRef = useRef<HTMLDivElement>(null);
  const pressStartedOnBackdrop = useRef(false);
  const pressEndedOnBackdrop = useRef(false);

  useLayoutEffect(() => {
    const dialog = dialogRef.current;
    if (!open || dialog === null) return;
    const opener = document.activeElement;
    focusFirst(dialog);

    // Focus inside another dialog is left alone, so two open dialogs cannot pull focus back and forth forever.
    const keepFocusInside = (event: FocusEvent) => {
      const target = event.target;
      if (!(target instanceof Element)) return;
      if (dialog.contains(target) || target.closest('[role="dialog"]') !== null) return;
      focusFirst(dialog);
    };

    document.addEventListener("focusin", keepFocusInside);
    return () => {
      document.removeEventListener("focusin", keepFocusInside);
      if (opener instanceof HTMLElement && opener.isConnected) opener.focus();
    };
  }, [open]);

  function handleKeyDown(event: KeyboardEvent<HTMLDivElement>) {
    const dialog = event.currentTarget;
    if (event.key === "Escape") {
      // Stop here so that when dialogs are nested only the topmost one closes.
      event.stopPropagation();
      onOpenChange(false);
      return;
    }
    // A nested dialog's Tab bubbles through React's tree; only the dialog that contains the target traps it.
    if (event.key !== "Tab" || !dialog.contains(event.target as Node)) return;
    const focusable = focusableIn(dialog);
    const index = focusable.indexOf(document.activeElement as HTMLElement);
    const wrap = event.shiftKey ? index <= 0 : index === -1 || index === focusable.length - 1;
    if (!wrap) return;
    event.preventDefault();
    const target = event.shiftKey ? focusable.at(-1) : focusable[0];
    (target ?? dialog).focus();
  }

  // A click lands on the common ancestor of the press and release targets, so the click alone cannot tell a drag
  // from inside to the backdrop apart. Both ends of the press are tracked and the dialog closes only when both are on the backdrop.
  function handleBackdropMouseDown(event: MouseEvent<HTMLDivElement>) {
    pressStartedOnBackdrop.current = event.target === event.currentTarget;
    pressEndedOnBackdrop.current = false;
  }

  function handleBackdropMouseUp(event: MouseEvent<HTMLDivElement>) {
    pressEndedOnBackdrop.current = event.target === event.currentTarget;
  }

  function handleBackdropClick() {
    const shouldClose = pressStartedOnBackdrop.current && pressEndedOnBackdrop.current;
    // Each press counts once, so a later click with no press of its own can't reuse it.
    pressStartedOnBackdrop.current = false;
    pressEndedOnBackdrop.current = false;
    if (shouldClose) onOpenChange(false);
  }

  if (!open) return null;

  return createPortal(
    <div
      onMouseDown={handleBackdropMouseDown}
      onMouseUp={handleBackdropMouseUp}
      onClick={handleBackdropClick}
    >
      <div
        {...rest}
        ref={dialogRef}
        role="dialog"
        aria-modal="true"
        aria-labelledby={titleId}
        aria-describedby={description != null ? descriptionId : undefined}
        tabIndex={-1}
        onKeyDown={handleKeyDown}
      >
        <h2 id={titleId}>{title}</h2>
        {description != null && <div id={descriptionId}>{description}</div>}
        {children}
      </div>
    </div>,
    document.body,
  );
}

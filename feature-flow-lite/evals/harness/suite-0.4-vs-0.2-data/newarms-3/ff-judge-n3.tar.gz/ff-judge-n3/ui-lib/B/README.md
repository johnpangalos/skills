# @acme/ui

Accessible, typed React 19 components. They ship no styles and accept `className` plus native HTML attributes, so you bring your own CSS.

## Run

```sh
pnpm install
pnpm test       # vitest run (jsdom + Testing Library)
pnpm typecheck  # tsc --noEmit
```

## Tabs

```tsx
import { Tab, TabList, TabPanel, Tabs } from "@acme/ui";

<Tabs defaultValue="profile">
  <TabList aria-label="Account">
    <Tab value="profile">Profile</Tab>
    <Tab value="billing">Billing</Tab>
  </TabList>
  <TabPanel value="profile">Profile settings</TabPanel>
  <TabPanel value="billing">Billing details</TabPanel>
</Tabs>;
```

Every `Tab` must have a `TabPanel` with the same value, because `aria-controls` references that panel. A tab with no matching panel points at a missing id.

### Tabs

| Prop | Type | Required / default | Description |
| --- | --- | --- | --- |
| `value` | `string` | optional; makes the tabs controlled | Selected tab value. |
| `defaultValue` | `string` | optional; first enabled tab | Initial selection when uncontrolled. Falls back to the first enabled tab in DOM order if it matches none. |
| `onValueChange` | `(value: string) => void` | optional | Called only when the selection actually changes. |
| `className`, other `div` props | | optional | Passed to the wrapper `div`. |

### TabList

| Prop | Type | Required / default | Description |
| --- | --- | --- | --- |
| `aria-label` | `string` | required | Accessible name for the `tablist`. |
| `className`, other `div` props | | optional | Passed to the `div role="tablist"`. `onKeyDown` is called before the built-in keys. |

### Tab

| Prop | Type | Required / default | Description |
| --- | --- | --- | --- |
| `value` | `string` | required | Identifies the tab; matches a `TabPanel` with the same value. |
| `disabled` | `boolean` | optional; `false` | Disabled tabs cannot be clicked or reached with arrow keys. |
| `className`, other `button` props | | optional | Passed to the `button role="tab"`. `onClick` is called before selection. |

### TabPanel

| Prop | Type | Required / default | Description |
| --- | --- | --- | --- |
| `value` | `string` | required | Matches the `Tab` with the same value. Non-selected panels get `hidden`. |
| `className`, other `div` props | | optional | Passed to the `div role="tabpanel"`. |

### Tabs keyboard

| Key | Behavior |
| --- | --- |
| Tab | Moves focus into the selected tab, then from it to the panel. |
| ArrowRight / ArrowLeft | Focus and select the next / previous enabled tab. Wraps at the ends. |
| Home / End | Focus and select the first / last enabled tab. |

Selection follows focus. Other keys do nothing.

## Dialog

```tsx
import { Dialog } from "@acme/ui";

const [open, setOpen] = useState(false);

<Dialog open={open} onOpenChange={setOpen} title="Delete file" description="This cannot be undone.">
  <button onClick={() => setOpen(false)}>Cancel</button>
</Dialog>;
```

### Dialog props

| Prop | Type | Required / default | Description |
| --- | --- | --- | --- |
| `open` | `boolean` | required | Renders the dialog through a portal into `document.body` when true. Renders nothing when false. |
| `onOpenChange` | `(open: boolean) => void` | required | Called with `false` on Escape (unless a child prevented it) or when a press and its release both land on the backdrop. Clicks inside the dialog do not close it, and neither does a drag that starts inside and ends on the backdrop. |
| `title` | `string` | required | Rendered as an `h2` and used as the accessible name. |
| `description` | `string` | optional | Rendered as a `p` and linked with `aria-describedby`. Omitted when not given. |
| `className`, other `div` props | | optional | Passed to the `div role="dialog"` (the backdrop is a separate wrapper element). |

Focus moves to the first focusable element on open, or to the dialog itself when it has none. Focus returns to the previously focused element when the dialog closes, if that element is still in the document.

### Dialog keyboard

| Key | Behavior |
| --- | --- |
| Escape | Calls `onOpenChange(false)` on the topmost open dialog, unless a child already called `preventDefault` on the event (for example an open Combobox). Works even when focus has dropped to the body. |
| Tab | Moves to the next focusable element; from the last one, wraps to the first. |
| Shift+Tab | Moves to the previous focusable element; from the first one, wraps to the last. |

Focusable elements exclude disabled controls, `tabindex="-1"` elements, and hidden inputs.

## Combobox

```tsx
import { Combobox } from "@acme/ui";

const fruits = [
  { value: "apple", label: "Apple" },
  { value: "banana", label: "Banana", disabled: true },
  { value: "grape", label: "Grape" },
];

<Combobox label="Fruit" options={fruits} value={fruit} onChange={setFruit} placeholder="Search fruit" />;
```

### Combobox props

| Prop | Type | Required / default | Description |
| --- | --- | --- | --- |
| `label` | `string` | required | Visible label, associated with the input. Also names the listbox. |
| `options` | `ComboboxOption[]` | required | `{ value: string; label: string; disabled?: boolean }`. |
| `value` | `string \| null` | optional; makes the combobox controlled | Selected option value. `null` or an unmatched value shows an empty input. |
| `defaultValue` | `string \| null` | optional; `null` | Initial value when uncontrolled (`value` is `undefined`). |
| `onChange` | `(value: string \| null) => void` | optional | Called with the option value when an option is chosen, or with `null` when emptied text is confirmed with Enter or blur. A controlled parent that ignores it keeps the old text. |
| `placeholder` | `string` | optional | Passed to the input. |
| `className`, other `input` props | | optional | Passed to the `input role="combobox"`. |

### Combobox keyboard

| Key | Behavior |
| --- | --- |
| Typing | Opens the listbox and shows options whose label contains the text (case-insensitive). Resets the active option to the first enabled match, or to none when the text is empty. |
| ArrowDown | Opens the listbox (active option: first enabled) if closed; otherwise moves the active option down, skipping disabled options and wrapping. |
| ArrowUp | Moves the active option up, skipping disabled options and wrapping. Does nothing when closed. |
| Enter | With an active option: selects it and closes. With no active option and empty text: clears the value to `null` and closes. While open, it never submits a surrounding form. |
| Escape | While open: closes and restores the selected label, without calling `onChange`. Event does not propagate, so an enclosing Dialog stays open. When closed, Escape propagates normally. |
| Blur | Closes the listbox and restores the selected label. With empty text, clears the value to `null` first. |

Clicking an enabled option selects it. Clicking a disabled option does nothing. Focus stays in the input throughout. When nothing matches, the listbox shows "No results" (`role="status"`).

Clearing: emptying the text leaves no option active. Enter on empty text then clears the value to `null`, and so does blur. Nothing is called when the value is already `null`. With an active option, Enter on empty text selects that option instead.

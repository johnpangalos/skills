import { render, screen } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { useState, type ReactNode } from "react";
import { Combobox, Dialog } from "../src/index";

function Host({
  description,
  children,
  onOpenChange,
}: {
  description?: ReactNode;
  children?: ReactNode;
  onOpenChange?: (open: boolean) => void;
}) {
  const [open, setOpen] = useState(false);
  return (
    <>
      <button type="button" onClick={() => setOpen(true)}>Open</button>
      <Dialog
        open={open}
        onOpenChange={(next) => {
          onOpenChange?.(next);
          setOpen(next);
        }}
        title="Confirm"
        description={description}
      >
        {children ?? (
          <>
            <button type="button">Cancel</button>
            <button type="button">OK</button>
          </>
        )}
      </Dialog>
    </>
  );
}

function Plain({ open }: { open: boolean }) {
  return (
    <>
      <button type="button">Trigger</button>
      <Dialog open={open} onOpenChange={() => {}} title="Confirm">
        <button type="button">Cancel</button>
      </Dialog>
    </>
  );
}

function Conditional({ show }: { show: boolean }) {
  return (
    <>
      <button type="button">Trigger</button>
      {show && (
        <Dialog open onOpenChange={() => {}} title="Confirm">
          <button type="button">Cancel</button>
        </Dialog>
      )}
    </>
  );
}

function FruitField() {
  const [value, setValue] = useState<string | null>(null);
  return (
    <Combobox
      label="Fruit"
      options={[{ value: "apple", label: "Apple" }]}
      value={value}
      onChange={setValue}
    />
  );
}

function Nested({ onOuterChange = () => {} }: { onOuterChange?: (open: boolean) => void }) {
  const [outerOpen, setOuterOpen] = useState(false);
  const [innerOpen, setInnerOpen] = useState(false);
  return (
    <>
      <button type="button" onClick={() => setOuterOpen(true)}>Open outer</button>
      <Dialog
        open={outerOpen}
        onOpenChange={(next) => {
          onOuterChange(next);
          setOuterOpen(next);
        }}
        title="Outer"
      >
        <button type="button" onClick={() => setInnerOpen(true)}>Open inner</button>
        <Dialog open={innerOpen} onOpenChange={setInnerOpen} title="Inner">
          <button type="button">Inner cancel</button>
          <button type="button">Inner OK</button>
        </Dialog>
      </Dialog>
    </>
  );
}

// The outer dialog has no tabbable element of its own; the inner one is opened by a rerender.
function NestedNoOuterTabbables({ innerOpen }: { innerOpen: boolean }) {
  return (
    <Dialog open onOpenChange={() => {}} title="Outer">
      <Dialog open={innerOpen} onOpenChange={() => {}} title="Inner">
        <button type="button">Inner cancel</button>
        <button type="button">Inner OK</button>
      </Dialog>
    </Dialog>
  );
}

async function openDialog(user: ReturnType<typeof userEvent.setup>) {
  await user.click(screen.getByRole("button", { name: "Open" }));
  return screen.getByRole("dialog");
}

const backdrop = () => document.querySelector("[data-backdrop]") as HTMLElement;

describe("Dialog", () => {
  it("D1: renders nothing while closed and shows the title when open", async () => {
    const user = userEvent.setup();
    render(<Host />);
    expect(screen.queryByRole("dialog")).toBeNull();
    await openDialog(user);
    expect(screen.getByRole("heading", { level: 2, name: "Confirm" })).toBeInTheDocument();
  });

  it("D1: open=false renders nothing at all", () => {
    render(<Dialog open={false} onOpenChange={() => {}} title="Confirm" />);
    expect(screen.queryByRole("dialog")).toBeNull();
    expect(document.querySelector("[data-backdrop]")).toBeNull();
  });

  it("D2: portals a backdrop sibling and a modal dialog labelled by its h2 title", async () => {
    const user = userEvent.setup();
    render(<Host />);
    const dialog = await openDialog(user);
    expect(dialog).toHaveAttribute("aria-modal", "true");
    expect(dialog.parentElement).toBe(document.body);
    expect(backdrop()).not.toBeNull();
    expect(dialog.contains(backdrop())).toBe(false);
    const heading = screen.getByRole("heading", { level: 2, name: "Confirm" });
    expect(dialog).toHaveAttribute("aria-labelledby", heading.id);
  });

  it("D2: aria-describedby points at the description when one is given", async () => {
    const user = userEvent.setup();
    render(<Host description="This cannot be undone." />);
    const dialog = await openDialog(user);
    const describedBy = dialog.getAttribute("aria-describedby");
    expect(describedBy).toBeTruthy();
    expect(document.getElementById(describedBy ?? "")).toHaveTextContent("This cannot be undone.");
  });

  it("D3: focuses the first tabbable element when opened", async () => {
    const user = userEvent.setup();
    render(<Host />);
    await openDialog(user);
    expect(screen.getByRole("button", { name: "Cancel" })).toHaveFocus();
  });

  it("D3: focuses the dialog itself when nothing inside is tabbable", async () => {
    const user = userEvent.setup();
    render(<Host>{<p>Just text</p>}</Host>);
    const dialog = await openDialog(user);
    expect(dialog).toHaveFocus();
  });

  it("D4: Tab from the last tabbable wraps to the first", async () => {
    const user = userEvent.setup();
    render(<Host />);
    await openDialog(user);
    await user.tab();
    expect(screen.getByRole("button", { name: "OK" })).toHaveFocus();
    await user.tab();
    expect(screen.getByRole("button", { name: "Cancel" })).toHaveFocus();
  });

  it("D4: Shift+Tab from the first tabbable wraps to the last", async () => {
    const user = userEvent.setup();
    render(<Host />);
    await openDialog(user);
    await user.tab({ shift: true });
    expect(screen.getByRole("button", { name: "OK" })).toHaveFocus();
  });

  it("D4: with no tabbables, Tab keeps focus on the dialog", async () => {
    const user = userEvent.setup();
    render(<Host>{<p>Just text</p>}</Host>);
    const dialog = await openDialog(user);
    await user.tab();
    expect(dialog).toHaveFocus();
    await user.tab({ shift: true });
    expect(dialog).toHaveFocus();
  });

  it("D4: tabbable excludes disabled, tabIndex -1 and hidden elements", async () => {
    const user = userEvent.setup();
    render(
      <Host>
        <button type="button" disabled>Off</button>
        <button type="button" tabIndex={-1}>Skip</button>
        <button type="button" hidden>Hidden</button>
        <input aria-label="Name" />
      </Host>,
    );
    await openDialog(user);
    expect(screen.getByRole("textbox", { name: "Name" })).toHaveFocus();
    await user.tab();
    expect(screen.getByRole("textbox", { name: "Name" })).toHaveFocus();
  });

  it("D5: Escape calls onOpenChange(false) and closes the dialog", async () => {
    const user = userEvent.setup();
    const onOpenChange = vi.fn();
    render(<Host onOpenChange={onOpenChange} />);
    await openDialog(user);
    await user.keyboard("{Escape}");
    expect(onOpenChange).toHaveBeenCalledWith(false);
    expect(screen.queryByRole("dialog")).toBeNull();
  });

  it("D5: clicking the backdrop closes, clicking inside the dialog does not", async () => {
    const user = userEvent.setup();
    const onOpenChange = vi.fn();
    render(<Host onOpenChange={onOpenChange} />);
    await openDialog(user);
    await user.click(screen.getByRole("heading", { level: 2, name: "Confirm" }));
    expect(onOpenChange).not.toHaveBeenCalled();
    await user.click(backdrop());
    expect(onOpenChange).toHaveBeenCalledWith(false);
    expect(screen.queryByRole("dialog")).toBeNull();
  });

  it("D6: closing returns focus to the element focused before opening", async () => {
    const user = userEvent.setup();
    render(<Host />);
    await openDialog(user);
    expect(screen.getByRole("button", { name: "Cancel" })).toHaveFocus();
    await user.keyboard("{Escape}");
    expect(screen.getByRole("button", { name: "Open" })).toHaveFocus();
  });

  it("D6: unmounting an open dialog returns focus to the previous element", () => {
    const { rerender } = render(<Conditional show={false} />);
    const trigger = screen.getByRole("button", { name: "Trigger" });
    trigger.focus();
    rerender(<Conditional show />);
    expect(screen.getByRole("button", { name: "Cancel" })).toHaveFocus();
    rerender(<Conditional show={false} />);
    expect(trigger).toHaveFocus();
  });

  it("D7: Escape inside an open Combobox closes only the popup, not the dialog", async () => {
    const user = userEvent.setup();
    render(<Host><FruitField /></Host>);
    await openDialog(user);
    await user.keyboard("a");
    const combobox = screen.getByRole("combobox");
    expect(combobox).toHaveAttribute("aria-expanded", "true");
    await user.keyboard("{Escape}");
    expect(combobox).toHaveAttribute("aria-expanded", "false");
    expect(screen.getByRole("dialog")).toBeInTheDocument();
    await user.keyboard("{Escape}");
    expect(screen.queryByRole("dialog")).toBeNull();
  });

  it("hostile: parent that keeps open=true after onOpenChange(false) stays open without crashing", async () => {
    const user = userEvent.setup();
    const onOpenChange = vi.fn();
    render(
      <Dialog open onOpenChange={onOpenChange} title="Confirm">
        <button type="button">Cancel</button>
      </Dialog>,
    );
    await user.keyboard("{Escape}");
    expect(onOpenChange).toHaveBeenCalledWith(false);
    expect(screen.getByRole("dialog")).toBeInTheDocument();
  });

  it("hostile: a press starting inside the dialog and ending on the backdrop does not close it", async () => {
    const user = userEvent.setup();
    const onOpenChange = vi.fn();
    render(<Host onOpenChange={onOpenChange} />);
    const dialog = await openDialog(user);
    const heading = screen.getByRole("heading", { level: 2, name: "Confirm" });
    await user.pointer([
      { keys: "[MouseLeft>]", target: heading },
      { target: backdrop() },
      { keys: "[/MouseLeft]", target: backdrop() },
    ]);
    expect(onOpenChange).not.toHaveBeenCalled();
    expect(dialog).toBeInTheDocument();
  });

  it("hostile: opened while focus is on body, closing does not crash and focus stays on body", async () => {
    const user = userEvent.setup();
    const { rerender } = render(<Plain open={false} />);
    expect(document.activeElement).toBe(document.body);
    rerender(<Plain open />);
    expect(screen.getByRole("button", { name: "Cancel" })).toHaveFocus();
    rerender(<Plain open={false} />);
    expect(screen.queryByRole("dialog")).toBeNull();
    expect(document.activeElement).toBe(document.body);
    await user.keyboard("{Escape}");
  });

  it("hostile: no description means no aria-describedby attribute at all", async () => {
    const user = userEvent.setup();
    render(<Host />);
    const dialog = await openDialog(user);
    expect(dialog).not.toHaveAttribute("aria-describedby");
  });

  it("hostile: description='' renders no description paragraph and no aria-describedby", async () => {
    const user = userEvent.setup();
    render(<Host description="" />);
    const dialog = await openDialog(user);
    expect(dialog).not.toHaveAttribute("aria-describedby");
    expect(dialog.querySelector("p")).toBeNull();
  });

  it("D5: nested dialogs - Escape closes only the inner dialog and the outer stays open", async () => {
    const user = userEvent.setup();
    const onOuterChange = vi.fn();
    render(<Nested onOuterChange={onOuterChange} />);
    await user.click(screen.getByRole("button", { name: "Open outer" }));
    await user.click(screen.getByRole("button", { name: "Open inner" }));
    expect(screen.getByRole("button", { name: "Inner cancel" })).toHaveFocus();
    await user.keyboard("{Escape}");
    expect(screen.queryByRole("dialog", { name: "Inner" })).toBeNull();
    expect(onOuterChange).not.toHaveBeenCalled();
    expect(screen.getByRole("dialog", { name: "Outer" })).toBeInTheDocument();
    await user.keyboard("{Escape}");
    expect(onOuterChange).toHaveBeenCalledWith(false);
    expect(screen.queryByRole("dialog")).toBeNull();
  });

  it("D4: nested dialogs - Tab and Shift+Tab inside the inner dialog keep focus inside it", async () => {
    const user = userEvent.setup();
    render(<Nested />);
    await user.click(screen.getByRole("button", { name: "Open outer" }));
    await user.click(screen.getByRole("button", { name: "Open inner" }));
    expect(screen.getByRole("button", { name: "Inner cancel" })).toHaveFocus();
    await user.tab();
    expect(screen.getByRole("button", { name: "Inner OK" })).toHaveFocus();
    await user.tab();
    expect(screen.getByRole("button", { name: "Inner cancel" })).toHaveFocus();
    await user.tab({ shift: true });
    expect(screen.getByRole("button", { name: "Inner OK" })).toHaveFocus();
    await user.tab({ shift: true });
    expect(screen.getByRole("button", { name: "Inner cancel" })).toHaveFocus();
  });

  it("D4: nested dialog whose outer has no tabbables - Tab wraps inside the inner dialog", async () => {
    const user = userEvent.setup();
    const { rerender } = render(<NestedNoOuterTabbables innerOpen={false} />);
    rerender(<NestedNoOuterTabbables innerOpen />);
    expect(screen.getByRole("button", { name: "Inner cancel" })).toHaveFocus();
    await user.tab();
    expect(screen.getByRole("button", { name: "Inner OK" })).toHaveFocus();
    await user.tab();
    expect(screen.getByRole("button", { name: "Inner cancel" })).toHaveFocus();
  });

  it("D4: nested dialog whose outer has no tabbables - Shift+Tab wraps inside the inner dialog", async () => {
    const user = userEvent.setup();
    const { rerender } = render(<NestedNoOuterTabbables innerOpen={false} />);
    rerender(<NestedNoOuterTabbables innerOpen />);
    await user.tab({ shift: true });
    expect(screen.getByRole("button", { name: "Inner OK" })).toHaveFocus();
    await user.tab({ shift: true });
    expect(screen.getByRole("button", { name: "Inner cancel" })).toHaveFocus();
  });

  it("D7: Escape that a nested element already prevented does not close the dialog", async () => {
    const user = userEvent.setup();
    const onOpenChange = vi.fn();
    render(
      <Dialog open onOpenChange={onOpenChange} title="Confirm">
        <input
          aria-label="Search"
          onKeyDown={(event) => {
            if (event.key === "Escape") event.preventDefault();
          }}
        />
      </Dialog>,
    );
    expect(screen.getByRole("textbox", { name: "Search" })).toHaveFocus();
    await user.keyboard("{Escape}");
    expect(onOpenChange).not.toHaveBeenCalled();
    expect(screen.getByRole("dialog")).toBeInTheDocument();
  });
});

// Lets tests import files as text with the Vite `?raw` suffix (used by tests/index.test.ts).
declare module "*?raw" {
  const content: string;
  export default content;
}

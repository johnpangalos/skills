import {
  createContext,
  useContext,
  useId,
  useLayoutEffect,
  useRef,
  useState,
  type ComponentPropsWithoutRef,
  type KeyboardEvent,
  type ReactNode,
} from "react";

export type TabsProps = {
  defaultValue?: string;
  value?: string;
  onValueChange?: (value: string) => void;
  children?: ReactNode;
};

export type TabListProps = ComponentPropsWithoutRef<"div"> & { "aria-label": string };

export type TabProps = ComponentPropsWithoutRef<"button"> & { value: string };

export type TabPanelProps = ComponentPropsWithoutRef<"div"> & { value: string };

type TabsContextValue = {
  baseId: string;
  selected: string | null;
  tabStop: string | null;
  select: (value: string) => void;
  syncEnabledValues: (values: string[]) => void;
};

const TabsContext = createContext<TabsContextValue | null>(null);

function useTabsContext(): TabsContextValue {
  const context = useContext(TabsContext);
  if (!context) {
    throw new Error("Tab, TabList and TabPanel must be rendered inside <Tabs>");
  }
  return context;
}

function tabId(baseId: string, value: string): string {
  return `${baseId}-tab-${encodeURIComponent(value)}`;
}

function panelId(baseId: string, value: string): string {
  return `${baseId}-panel-${encodeURIComponent(value)}`;
}

function getEnabledTabs(list: HTMLElement): HTMLElement[] {
  return Array.from(list.querySelectorAll<HTMLElement>('[role="tab"]:not(:disabled)'));
}

export function Tabs({ defaultValue, value, onValueChange, children }: TabsProps) {
  const baseId = useId();
  const [internalValue, setInternalValue] = useState<string | undefined>(defaultValue);
  const [enabledValues, setEnabledValues] = useState<string[]>([]);
  const isControlled = value !== undefined;
  // Before any user choice, the first enabled tab is selected.
  const selected = (isControlled ? value : internalValue) ?? enabledValues[0] ?? null;
  // The selected tab is the tab stop when it is enabled; otherwise the first enabled tab is.
  const tabStop =
    selected !== null && enabledValues.includes(selected) ? selected : (enabledValues[0] ?? null);

  function select(next: string) {
    if (next === selected) return;
    if (!isControlled) setInternalValue(next);
    onValueChange?.(next);
  }

  function syncEnabledValues(next: string[]) {
    setEnabledValues((prev) => (JSON.stringify(prev) === JSON.stringify(next) ? prev : next));
  }

  return (
    <TabsContext.Provider value={{ baseId, selected, tabStop, select, syncEnabledValues }}>
      {children}
    </TabsContext.Provider>
  );
}

export function TabList({ "aria-label": label, children, onKeyDown, ...rest }: TabListProps) {
  const { select, syncEnabledValues } = useTabsContext();
  const listRef = useRef<HTMLDivElement>(null);

  // Runs after every render so the enabled tabs (and DOM order) are always current.
  useLayoutEffect(() => {
    const tabs = getEnabledTabs(listRef.current as HTMLElement);
    syncEnabledValues(tabs.map((tab) => tab.dataset.value ?? ""));
  });

  function handleKeyDown(event: KeyboardEvent<HTMLDivElement>) {
    onKeyDown?.(event);
    const tabs = getEnabledTabs(event.currentTarget);
    if (tabs.length === 0) return;
    const current = tabs.indexOf(event.target as HTMLElement);
    const last = tabs.length - 1;
    let next: number;
    switch (event.key) {
      case "ArrowRight":
        next = current === last ? 0 : current + 1;
        break;
      case "ArrowLeft":
        next = current <= 0 ? last : current - 1;
        break;
      case "Home":
        next = 0;
        break;
      case "End":
        next = last;
        break;
      default:
        return;
    }
    event.preventDefault();
    tabs[next].focus();
    select(tabs[next].dataset.value ?? "");
  }

  return (
    <div {...rest} ref={listRef} role="tablist" aria-label={label} onKeyDown={handleKeyDown}>
      {children}
    </div>
  );
}

export function Tab({ value, onClick, children, ...rest }: TabProps) {
  const { baseId, selected, tabStop, select } = useTabsContext();
  return (
    <button
      type="button"
      {...rest}
      role="tab"
      id={tabId(baseId, value)}
      data-value={value}
      aria-selected={value === selected}
      aria-controls={panelId(baseId, value)}
      tabIndex={value === tabStop ? 0 : -1}
      onClick={(event) => {
        onClick?.(event);
        select(value);
      }}
    >
      {children}
    </button>
  );
}

export function TabPanel({ value, children, ...rest }: TabPanelProps) {
  const { baseId, selected } = useTabsContext();
  return (
    <div
      {...rest}
      role="tabpanel"
      id={panelId(baseId, value)}
      aria-labelledby={tabId(baseId, value)}
      tabIndex={0}
      hidden={value !== selected}
    >
      {children}
    </div>
  );
}

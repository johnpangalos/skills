import { render, screen } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { useEffect, useState } from "react";
import { Tab, TabList, TabPanel, Tabs, type TabsProps } from "./Tabs";

type ExampleProps = Partial<TabsProps> & { disabled?: string[] };

function Example({ disabled = [], ...props }: ExampleProps) {
  return (
    <Tabs {...props}>
      <TabList aria-label="Sections">
        <Tab value="a" disabled={disabled.includes("a")}>A</Tab>
        <Tab value="b" disabled={disabled.includes("b")}>B</Tab>
        <Tab value="c" disabled={disabled.includes("c")}>C</Tab>
      </TabList>
      <TabPanel value="a">Panel A</TabPanel>
      <TabPanel value="b">Panel B</TabPanel>
      <TabPanel value="c">Panel C</TabPanel>
    </Tabs>
  );
}

function ControlledExample({ onValueChange }: { onValueChange: (value: string) => void }) {
  const [value, setValue] = useState("a");
  return (
    <Example
      value={value}
      onValueChange={(next) => {
        setValue(next);
        onValueChange(next);
      }}
    />
  );
}

function Inserted({ withMiddle }: { withMiddle: boolean }) {
  return (
    <Tabs defaultValue="a">
      <TabList aria-label="Sections">
        <Tab value="a">A</Tab>
        {withMiddle && <Tab value="m">M</Tab>}
        <Tab value="b">B</Tab>
      </TabList>
    </Tabs>
  );
}

const tab = (name: string) => screen.getByRole("tab", { name });

describe("Tabs", () => {
  it("selects the defaultValue tab in uncontrolled mode and reports changes", async () => {
    const user = userEvent.setup();
    const onValueChange = vi.fn();
    render(<Example defaultValue="b" onValueChange={onValueChange} />);
    expect(tab("B")).toHaveAttribute("aria-selected", "true");
    expect(screen.getByRole("tabpanel")).toHaveTextContent("Panel B");

    await user.click(tab("C"));
    expect(onValueChange).toHaveBeenCalledWith("c");
    expect(tab("C")).toHaveAttribute("aria-selected", "true");

    await user.click(tab("C"));
    expect(onValueChange).toHaveBeenCalledTimes(1);
  });

  it("selects the first enabled tab when no value is given", () => {
    render(<Example disabled={["a"]} />);
    expect(tab("A")).toHaveAttribute("aria-selected", "false");
    expect(tab("B")).toHaveAttribute("aria-selected", "true");
  });

  it("follows a controlled value and keeps it when the parent ignores the change", async () => {
    const user = userEvent.setup();
    const onValueChange = vi.fn();
    const { rerender } = render(<Example value="a" onValueChange={onValueChange} />);
    await user.click(tab("B"));
    expect(onValueChange).toHaveBeenCalledWith("b");
    expect(tab("A")).toHaveAttribute("aria-selected", "true");

    rerender(<Example value="c" onValueChange={onValueChange} />);
    expect(tab("C")).toHaveAttribute("aria-selected", "true");
  });

  it("updates selection when the controlled parent accepts the change", async () => {
    const user = userEvent.setup();
    const onValueChange = vi.fn();
    render(<ControlledExample onValueChange={onValueChange} />);
    await user.click(tab("B"));
    expect(onValueChange).toHaveBeenCalledWith("b");
    expect(tab("B")).toHaveAttribute("aria-selected", "true");
  });

  it("wires ARIA roles, ids and hidden panels", () => {
    render(<Example defaultValue="a" />);
    expect(screen.getByRole("tablist", { name: "Sections" })).toBeInTheDocument();
    const tabB = tab("B");
    expect(tabB.tagName).toBe("BUTTON");
    expect(tabB).toHaveAttribute("type", "button");
    const panelB = document.getElementById(tabB.getAttribute("aria-controls") ?? "");
    expect(panelB).toHaveAttribute("role", "tabpanel");
    expect(panelB).toHaveAttribute("aria-labelledby", tabB.id);
    expect(panelB).toHaveAttribute("hidden");
    expect(panelB).toHaveAttribute("tabindex", "0");
  });

  it("uses a roving tabindex on the selected tab", () => {
    render(<Example defaultValue="b" />);
    expect(tab("A")).toHaveAttribute("tabindex", "-1");
    expect(tab("B")).toHaveAttribute("tabindex", "0");
    expect(tab("C")).toHaveAttribute("tabindex", "-1");
  });

  it("makes the first enabled tab reachable when value matches no tab", async () => {
    const user = userEvent.setup();
    render(<Example value="zzz" />);
    expect(tab("A")).toHaveAttribute("aria-selected", "true");
    expect(tab("A")).toHaveAttribute("tabindex", "0");
    await user.tab();
    expect(tab("A")).toHaveFocus();
  });

  it("moves focus and selection with ArrowRight/ArrowLeft, wrapping at both ends", async () => {
    const user = userEvent.setup();
    const onValueChange = vi.fn();
    render(<Example defaultValue="a" onValueChange={onValueChange} />);
    await user.tab();
    await user.keyboard("{ArrowLeft}");
    expect(tab("C")).toHaveFocus();
    expect(tab("C")).toHaveAttribute("aria-selected", "true");
    await user.keyboard("{ArrowRight}");
    expect(tab("A")).toHaveFocus();
    await user.keyboard("{ArrowRight}");
    expect(tab("B")).toHaveFocus();
    expect(onValueChange).toHaveBeenLastCalledWith("b");
  });

  it("moves to the first and last enabled tab with Home and End", async () => {
    const user = userEvent.setup();
    render(<Example defaultValue="b" />);
    await user.tab();
    await user.keyboard("{End}");
    expect(tab("C")).toHaveFocus();
    await user.keyboard("{Home}");
    expect(tab("A")).toHaveFocus();
  });

  it("skips a disabled tab between the current tab and the target", async () => {
    const user = userEvent.setup();
    render(<Example defaultValue="a" disabled={["b"]} />);
    await user.tab();
    await user.keyboard("{ArrowRight}");
    expect(tab("C")).toHaveFocus();
    expect(tab("C")).toHaveAttribute("aria-selected", "true");
  });

  it("ignores other keys and lets Tab leave the list", async () => {
    const user = userEvent.setup();
    const onValueChange = vi.fn();
    render(<Example defaultValue="a" onValueChange={onValueChange} />);
    await user.tab();
    await user.keyboard("x");
    expect(tab("A")).toHaveFocus();
    expect(onValueChange).not.toHaveBeenCalled();
    await user.tab();
    expect(screen.getByRole("tabpanel")).toHaveFocus();
  });

  it("does not select a disabled tab on click", async () => {
    const user = userEvent.setup();
    const onValueChange = vi.fn();
    render(<Example defaultValue="a" disabled={["b"]} onValueChange={onValueChange} />);
    await user.click(tab("B"));
    expect(onValueChange).not.toHaveBeenCalled();
    expect(tab("A")).toHaveAttribute("aria-selected", "true");
    expect(tab("B")).toBeDisabled();
    expect(tab("B")).toHaveAttribute("aria-disabled", "true");
  });

  it("does nothing with arrow keys when every tab is disabled", async () => {
    const user = userEvent.setup();
    render(<Example disabled={["a", "b", "c"]} />);
    await user.tab();
    await user.keyboard("{ArrowRight}{Home}{End}");
    expect(document.body).toHaveFocus();
  });

  it("keeps focus on the only enabled tab when arrowing", async () => {
    const user = userEvent.setup();
    const onValueChange = vi.fn();
    render(<Example defaultValue="a" disabled={["b", "c"]} onValueChange={onValueChange} />);
    await user.tab();
    await user.keyboard("{ArrowRight}{ArrowLeft}");
    expect(tab("A")).toHaveFocus();
    expect(onValueChange).not.toHaveBeenCalled();
  });

  it("follows DOM order for a tab inserted after mount", async () => {
    const user = userEvent.setup();
    const { rerender } = render(<Inserted withMiddle={false} />);
    rerender(<Inserted withMiddle />);
    await user.tab();
    await user.keyboard("{ArrowRight}");
    expect(tab("M")).toHaveFocus();
    await user.keyboard("{ArrowRight}");
    expect(tab("B")).toHaveFocus();
  });

  it("gives the first enabled tab tabIndex 0 when a child disables the selected tab", async () => {
    const user = userEvent.setup();
    // The child owns the disabled state, so TabList and Tabs' parent never re-render.
    function StatefulTab() {
      const [disabled, setDisabled] = useState(false);
      useEffect(() => {
        setDisabled(true);
      }, []);
      return <Tab value="a" disabled={disabled}>A</Tab>;
    }
    render(
      <Tabs defaultValue="a">
        <TabList aria-label="Sections">
          <StatefulTab />
          <Tab value="b">B</Tab>
        </TabList>
      </Tabs>,
    );
    expect(tab("A")).toBeDisabled();
    expect(tab("B")).toHaveAttribute("tabindex", "0");
    await user.tab();
    expect(tab("B")).toHaveFocus();
  });

  it("registers a tab added by a stateful child after mount so a controlled value can select it", () => {
    function LateTab() {
      const [ready, setReady] = useState(false);
      useEffect(() => {
        setReady(true);
      }, []);
      return ready ? <Tab value="c">C</Tab> : null;
    }
    function LateTabs() {
      const [value, setValue] = useState("c");
      return (
        <Tabs value={value} onValueChange={setValue}>
          <TabList aria-label="Sections">
            <Tab value="a">A</Tab>
            <LateTab />
          </TabList>
          <TabPanel value="a">Panel A</TabPanel>
          <TabPanel value="c">Panel C</TabPanel>
        </Tabs>
      );
    }
    render(<LateTabs />);
    expect(tab("C")).toHaveAttribute("aria-selected", "true");
    expect(screen.getByRole("tabpanel")).toHaveTextContent("Panel C");
  });

  it("throws a clear error when Tab is rendered outside Tabs", () => {
    expect(() => render(<Tab value="a">A</Tab>)).toThrow("Tab must be rendered inside <Tabs>");
  });

  it("calls onValueChange when the fallback-shown tab is clicked and value matches no tab", async () => {
    const user = userEvent.setup();
    const onValueChange = vi.fn();
    render(<Example value="zzz" onValueChange={onValueChange} />);
    expect(tab("A")).toHaveAttribute("aria-selected", "true");
    await user.click(tab("A"));
    expect(onValueChange).toHaveBeenCalledTimes(1);
    expect(onValueChange).toHaveBeenCalledWith("a");
  });

  it("forwards className, style and data attributes to the root elements", () => {
    render(
      <Tabs className="root" data-testid="tabs">
        <TabList aria-label="Sections" className="list" data-testid="list">
          <Tab value="a" style={{ color: "red" }}>
            A
          </Tab>
        </TabList>
      </Tabs>,
    );
    expect(screen.getByTestId("tabs")).toHaveClass("root");
    expect(screen.getByTestId("list")).toHaveClass("list");
    expect(tab("A").style.color).toBe("red");
  });
});

test("uncontrolled without defaultValue: clicking the fallback-selected tab does not call onValueChange", async () => {
  const onValueChange = vi.fn();
  render(
    <Tabs onValueChange={onValueChange}>
      <TabList aria-label="Fallback">
        <Tab value="a">A</Tab>
        <Tab value="b">B</Tab>
      </TabList>
      <TabPanel value="a">Panel A</TabPanel>
      <TabPanel value="b">Panel B</TabPanel>
    </Tabs>,
  );
  await userEvent.click(screen.getByRole("tab", { name: "A" }));
  expect(onValueChange).not.toHaveBeenCalled();
  await userEvent.click(screen.getByRole("tab", { name: "B" }));
  expect(onValueChange).toHaveBeenCalledWith("b");
});

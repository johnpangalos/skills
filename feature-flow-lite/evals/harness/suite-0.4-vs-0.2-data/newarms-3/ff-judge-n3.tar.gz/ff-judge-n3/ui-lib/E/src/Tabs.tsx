import * as React from "react";

type TabsContextValue = {
  baseId: string;
  selected: string | undefined;
  tabStop: string | undefined;
  select: (value: string) => void;
  setEnabledValues: (values: string[]) => void;
};

const TabsContext = React.createContext<TabsContextValue | null>(null);

export type TabsProps = {
  defaultValue?: string;
  value?: string;
  onValueChange?: (value: string) => void;
  children?: React.ReactNode;
  className?: string;
};

export type TabListProps = Omit<React.ComponentPropsWithoutRef<"div">, "role" | "onKeyDown"> & {
  "aria-label": string;
};

export type TabProps = Omit<React.ComponentPropsWithoutRef<"button">, "value" | "type" | "role"> & {
  value: string;
};

export type TabPanelProps = Omit<React.ComponentPropsWithoutRef<"div">, "value" | "role"> & {
  value: string;
};

// Encodes a tab value as an id-safe segment. Letters, digits and "-" pass through; every other
// character (including "_") becomes _<hex code>_, so distinct values never produce the same id.
function idSegment(value: string): string {
  return value.replace(/[^A-Za-z0-9-]/g, (char) => `_${char.charCodeAt(0).toString(16)}_`);
}

function tabId(baseId: string, value: string): string {
  return `${baseId}-tab-${idSegment(value)}`;
}

function panelId(baseId: string, value: string): string {
  return `${baseId}-panel-${idSegment(value)}`;
}

function sameValues(a: string[], b: string[]): boolean {
  return a.length === b.length && a.every((value, index) => value === b[index]);
}

function getTabs(list: HTMLElement | null): HTMLButtonElement[] {
  return list ? Array.from(list.querySelectorAll<HTMLButtonElement>('[role="tab"]')) : [];
}

// Steps from `from` in direction `step`, wrapping and skipping disabled tabs. Returns -1 if none is enabled.
function stepEnabled(tabs: HTMLButtonElement[], from: number, step: 1 | -1): number {
  const count = tabs.length;
  for (let k = 1; k <= count; k++) {
    const index = (((from + step * k) % count) + count) % count;
    if (!tabs[index].disabled) return index;
  }
  return -1;
}

function useTabsContext(): TabsContextValue {
  const context = React.useContext(TabsContext);
  if (!context) {
    throw new Error("Tab, TabList and TabPanel must be rendered inside <Tabs>");
  }
  return context;
}

export function Tabs({ defaultValue, value, onValueChange, children, className }: TabsProps) {
  const baseId = React.useId();
  const [uncontrolled, setUncontrolled] = React.useState(defaultValue);
  const [enabledValues, setEnabled] = React.useState<string[]>([]);

  // Controlled when `value` is provided. With no selection, the first enabled tab is selected.
  const selected = value ?? uncontrolled ?? enabledValues[0];
  const tabStop =
    selected !== undefined && enabledValues.includes(selected) ? selected : enabledValues[0];

  function select(next: string) {
    if (value === undefined) setUncontrolled(next);
    onValueChange?.(next);
  }

  function setEnabledValues(next: string[]) {
    setEnabled((prev) => (sameValues(prev, next) ? prev : next));
  }

  return (
    <TabsContext.Provider value={{ baseId, selected, tabStop, select, setEnabledValues }}>
      <div className={className}>{children}</div>
    </TabsContext.Provider>
  );
}

export function TabList({ children, className, ...rest }: TabListProps) {
  const { select, setEnabledValues } = useTabsContext();
  const listRef = React.useRef<HTMLDivElement>(null);

  // Re-measured on every render so the tab stop follows the DOM order and the disabled state.
  React.useLayoutEffect(() => {
    const enabled = getTabs(listRef.current).filter((tab) => !tab.disabled);
    setEnabledValues(enabled.map((tab) => tab.dataset.value ?? ""));
  });

  function handleKeyDown(event: React.KeyboardEvent<HTMLDivElement>) {
    const tabs = getTabs(listRef.current);
    const current = tabs.indexOf(event.target as HTMLButtonElement);
    if (current === -1) return;

    let next: number;
    switch (event.key) {
      case "ArrowRight":
        next = stepEnabled(tabs, current, 1);
        break;
      case "ArrowLeft":
        next = stepEnabled(tabs, current, -1);
        break;
      case "Home":
        next = stepEnabled(tabs, -1, 1);
        break;
      case "End":
        next = stepEnabled(tabs, tabs.length, -1);
        break;
      default:
        return;
    }
    event.preventDefault();
    if (next === -1 || next === current) return;
    tabs[next].focus();
    select(tabs[next].dataset.value ?? "");
  }

  return (
    <div
      {...rest}
      ref={listRef}
      role="tablist"
      aria-orientation="horizontal"
      className={className}
      onKeyDown={handleKeyDown}
    >
      {children}
    </div>
  );
}

export function Tab({ value, disabled, onClick, ...rest }: TabProps) {
  const { baseId, selected, tabStop, select } = useTabsContext();
  return (
    <button
      {...rest}
      type="button"
      role="tab"
      id={tabId(baseId, value)}
      data-value={value}
      aria-selected={selected === value}
      aria-controls={panelId(baseId, value)}
      tabIndex={tabStop === value ? 0 : -1}
      disabled={disabled}
      onClick={(event) => {
        onClick?.(event);
        select(value);
      }}
    />
  );
}

export function TabPanel({ value, ...rest }: TabPanelProps) {
  const { baseId, selected } = useTabsContext();
  // Every panel stays in the DOM so each tab's aria-controls resolves; unselected panels are hidden.
  return (
    <div
      {...rest}
      role="tabpanel"
      id={panelId(baseId, value)}
      aria-labelledby={tabId(baseId, value)}
      hidden={selected !== value}
      tabIndex={0}
    />
  );
}

import { fireEvent, render, screen } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { useState } from "react";
import { Combobox, type ComboboxOption } from "../src/index";

const fruits: ComboboxOption[] = [
  { value: "apple", label: "Apple" },
  { value: "banana", label: "Banana", disabled: true },
  { value: "cherry", label: "Cherry" },
  { value: "date", label: "Date" },
];

function Stateful({
  options = fruits,
  initial = null,
  onChange = () => {},
}: {
  options?: ComboboxOption[];
  initial?: string | null;
  onChange?: (value: string | null) => void;
}) {
  const [value, setValue] = useState<string | null>(initial);
  return (
    <Combobox
      label="Fruit"
      options={options}
      value={value}
      onChange={(next) => {
        onChange(next);
        setValue(next);
      }}
    />
  );
}

const input = () => screen.getByRole("combobox");
const activeLabel = () => {
  const id = input().getAttribute("aria-activedescendant");
  return id === null ? null : document.getElementById(id)?.textContent;
};
const optionLabels = () => screen.getAllByRole("option").map((option) => option.textContent);

describe("Combobox", () => {
  it("C1: the label is associated with the combobox input", () => {
    render(<Stateful />);
    expect(screen.getByRole("combobox", { name: "Fruit" })).toBe(input());
  });

  it("C2: input exposes autocomplete, expanded and controls state", async () => {
    const user = userEvent.setup();
    render(<Stateful />);
    expect(input()).toHaveAttribute("aria-autocomplete", "list");
    expect(input()).toHaveAttribute("aria-expanded", "false");
    await user.click(input());
    await user.keyboard("{ArrowDown}");
    expect(input()).toHaveAttribute("aria-expanded", "true");
    expect(input()).toHaveAttribute("aria-controls", screen.getByRole("listbox").id);
  });

  it("C2: aria-activedescendant is set only while an option is active", async () => {
    const user = userEvent.setup();
    render(<Stateful />);
    await user.click(input());
    expect(input()).not.toHaveAttribute("aria-activedescendant");
    await user.keyboard("{ArrowDown}");
    expect(input()).toHaveAttribute("aria-activedescendant", screen.getByRole("option", { name: "Apple" }).id);
  });

  it("C3: popup is a listbox labelled by the label, with options exposing selection and disabled state", async () => {
    const user = userEvent.setup();
    render(<Stateful initial="cherry" />);
    await user.click(input());
    await user.keyboard("{ArrowDown}");
    expect(screen.getByRole("listbox", { name: "Fruit" })).toBeInTheDocument();
    const options = screen.getAllByRole("option");
    expect(options).toHaveLength(4);
    expect(new Set(options.map((option) => option.id)).size).toBe(4);
    expect(screen.getByRole("option", { name: "Cherry" })).toHaveAttribute("aria-selected", "true");
    expect(screen.getByRole("option", { name: "Apple" })).toHaveAttribute("aria-selected", "false");
    expect(screen.getByRole("option", { name: "Banana" })).toHaveAttribute("aria-disabled", "true");
    expect(screen.getByRole("option", { name: "Apple" })).not.toHaveAttribute("aria-disabled");
  });

  it("C4: input shows the selected label", () => {
    render(<Stateful initial="cherry" />);
    expect(input()).toHaveValue("Cherry");
  });

  it("C4: input is empty when value is null", () => {
    render(<Stateful />);
    expect(input()).toHaveValue("");
  });

  it("C4: typing opens the popup, filters case-insensitively and does not call onChange", async () => {
    const user = userEvent.setup();
    const onChange = vi.fn();
    render(<Stateful onChange={onChange} />);
    await user.click(input());
    await user.keyboard("AN");
    expect(input()).toHaveAttribute("aria-expanded", "true");
    expect(optionLabels()).toEqual(["Banana"]);
    expect(onChange).not.toHaveBeenCalled();
  });

  it("C4: filter text is trimmed, and empty text shows all options", async () => {
    const user = userEvent.setup();
    render(<Stateful />);
    await user.click(input());
    await user.keyboard("  ch  ");
    expect(optionLabels()).toEqual(["Cherry"]);
    await user.clear(input());
    expect(optionLabels()).toEqual(["Apple", "Banana", "Cherry", "Date"]);
  });

  it("C5: ArrowDown and ArrowUp move the active option, skip disabled and wrap at both ends", async () => {
    const user = userEvent.setup();
    render(<Stateful />);
    await user.click(input());
    await user.keyboard("{ArrowDown}");
    expect(activeLabel()).toBe("Apple");
    await user.keyboard("{ArrowDown}");
    expect(activeLabel()).toBe("Cherry");
    await user.keyboard("{ArrowDown}");
    expect(activeLabel()).toBe("Date");
    await user.keyboard("{ArrowDown}");
    expect(activeLabel()).toBe("Apple");
    await user.keyboard("{ArrowUp}");
    expect(activeLabel()).toBe("Date");
  });

  it("C5: Alt+ArrowDown opens the popup without moving the active option", async () => {
    const user = userEvent.setup();
    render(<Stateful />);
    await user.click(input());
    await user.keyboard("{Alt>}{ArrowDown}{/Alt}");
    expect(input()).toHaveAttribute("aria-expanded", "true");
    expect(input()).not.toHaveAttribute("aria-activedescendant");
  });

  it("C5: handled keys call preventDefault", () => {
    render(<Stateful />);
    expect(fireEvent.keyDown(input(), { key: "ArrowDown" })).toBe(false);
    expect(fireEvent.keyDown(input(), { key: "ArrowUp" })).toBe(false);
    expect(fireEvent.keyDown(input(), { key: "a" })).toBe(true);
  });

  it("C6: Enter selects the active option, closes the popup and shows its label", async () => {
    const user = userEvent.setup();
    const onChange = vi.fn();
    render(<Stateful onChange={onChange} />);
    await user.click(input());
    await user.keyboard("{ArrowDown}{ArrowDown}{Enter}");
    expect(onChange).toHaveBeenCalledWith("cherry");
    expect(input()).toHaveValue("Cherry");
    expect(input()).toHaveAttribute("aria-expanded", "false");
  });

  it("C6: Enter with no active option does nothing", async () => {
    const user = userEvent.setup();
    const onChange = vi.fn();
    render(<Stateful onChange={onChange} />);
    await user.click(input());
    await user.keyboard("ch{Enter}");
    expect(onChange).not.toHaveBeenCalled();
  });

  it("C6: clicking an enabled option selects it and keeps focus in the input", async () => {
    const user = userEvent.setup();
    const onChange = vi.fn();
    render(<Stateful onChange={onChange} />);
    await user.click(input());
    await user.keyboard("{ArrowDown}");
    await user.click(screen.getByRole("option", { name: "Date" }));
    expect(onChange).toHaveBeenCalledWith("date");
    expect(input()).toHaveValue("Date");
    expect(input()).toHaveFocus();
  });

  it("C6: clicking a disabled option does nothing", async () => {
    const user = userEvent.setup();
    const onChange = vi.fn();
    render(<Stateful onChange={onChange} />);
    await user.click(input());
    await user.keyboard("{ArrowDown}");
    await user.click(screen.getByRole("option", { name: "Banana" }));
    expect(onChange).not.toHaveBeenCalled();
    expect(input()).toHaveAttribute("aria-expanded", "true");
  });

  it("C7: Escape closes the open popup without onChange and restores the selected label", async () => {
    const user = userEvent.setup();
    const onChange = vi.fn();
    render(<Stateful initial="apple" onChange={onChange} />);
    await user.clear(input());
    await user.keyboard("ch");
    expect(input()).toHaveAttribute("aria-expanded", "true");
    await user.keyboard("{Escape}");
    expect(input()).toHaveAttribute("aria-expanded", "false");
    expect(input()).toHaveValue("Apple");
    expect(onChange).not.toHaveBeenCalled();
  });

  it("C8: no matches shows a No results status and no active option", async () => {
    const user = userEvent.setup();
    render(<Stateful />);
    await user.click(input());
    await user.keyboard("zzz");
    expect(screen.getByRole("status")).toHaveTextContent("No results");
    expect(screen.queryByRole("option")).toBeNull();
    await user.keyboard("{ArrowDown}");
    expect(input()).not.toHaveAttribute("aria-activedescendant");
  });

  it("C9: blur closes the popup and restores the selected label without onChange", async () => {
    const user = userEvent.setup();
    const onChange = vi.fn();
    render(<Stateful initial="apple" onChange={onChange} />);
    await user.clear(input());
    await user.keyboard("ch");
    await user.click(document.body);
    expect(input()).toHaveAttribute("aria-expanded", "false");
    expect(input()).toHaveValue("Apple");
    expect(onChange).not.toHaveBeenCalled();
  });

  it("C10: displayed text follows value changes from the parent", () => {
    const { rerender } = render(
      <Combobox label="Fruit" options={fruits} value="apple" onChange={() => {}} />,
    );
    expect(input()).toHaveValue("Apple");
    rerender(<Combobox label="Fruit" options={fruits} value="date" onChange={() => {}} />);
    expect(input()).toHaveValue("Date");
  });

  it("C10: a parent value change replaces text that was being typed", async () => {
    const user = userEvent.setup();
    const { rerender } = render(
      <Combobox label="Fruit" options={fruits} value="apple" onChange={() => {}} />,
    );
    await user.clear(input());
    await user.keyboard("ch");
    rerender(<Combobox label="Fruit" options={fruits} value="date" onChange={() => {}} />);
    expect(input()).toHaveValue("Date");
  });

  it("hostile: all options disabled - arrows and Enter select nothing and no active option", async () => {
    const user = userEvent.setup();
    const onChange = vi.fn();
    render(<Stateful options={[{ value: "a", label: "Alpha", disabled: true }]} onChange={onChange} />);
    await user.click(input());
    await user.keyboard("{ArrowDown}{ArrowUp}{Enter}");
    expect(input()).not.toHaveAttribute("aria-activedescendant");
    expect(onChange).not.toHaveBeenCalled();
  });

  it("hostile: empty options list - opening and typing do not crash and show No results", async () => {
    const user = userEvent.setup();
    render(<Stateful options={[]} />);
    await user.click(input());
    await user.keyboard("{ArrowDown}a");
    expect(screen.getByRole("status")).toHaveTextContent("No results");
    expect(input()).not.toHaveAttribute("aria-activedescendant");
  });

  it("hostile: filter text with regex characters is matched literally", async () => {
    const user = userEvent.setup();
    render(
      <Stateful
        options={[
          { value: "pear", label: "Pear (green)" },
          { value: "quince", label: "Quince" },
        ]}
      />,
    );
    await user.click(input());
    await user.keyboard("(");
    expect(optionLabels()).toEqual(["Pear (green)"]);
    await user.clear(input());
    await user.keyboard(".*");
    expect(screen.getByRole("status")).toHaveTextContent("No results");
  });

  it("hostile: an active option filtered out by typing is not referenced by aria-activedescendant", async () => {
    const user = userEvent.setup();
    const onChange = vi.fn();
    render(<Stateful onChange={onChange} />);
    await user.click(input());
    await user.keyboard("{ArrowDown}");
    expect(activeLabel()).toBe("Apple");
    await user.keyboard("c");
    expect(optionLabels()).toEqual(["Cherry"]);
    expect(input()).not.toHaveAttribute("aria-activedescendant");
    await user.keyboard("{Enter}");
    expect(onChange).not.toHaveBeenCalled();
  });

  it("hostile: duplicate labels get distinct options and select by value", async () => {
    const user = userEvent.setup();
    const onChange = vi.fn();
    render(
      <Stateful
        options={[
          { value: "1", label: "Same" },
          { value: "2", label: "Same" },
        ]}
        onChange={onChange}
      />,
    );
    await user.click(input());
    await user.keyboard("{ArrowDown}");
    const options = screen.getAllByRole("option");
    expect(new Set(options.map((option) => option.id)).size).toBe(2);
    await user.click(options[1]);
    expect(onChange).toHaveBeenCalledWith("2");
  });

  it("hostile: a value matching no option shows an empty input", () => {
    render(<Stateful initial="nope" />);
    expect(input()).toHaveValue("");
  });

  it("hostile: two Comboboxes on one page do not share ids", async () => {
    const user = userEvent.setup();
    render(
      <>
        <Combobox label="Fruit" options={fruits} value={null} onChange={() => {}} />
        <Combobox label="Colour" options={fruits} value={null} onChange={() => {}} />
      </>,
    );
    const [first, second] = screen.getAllByRole("combobox");
    expect(first.id).not.toBe(second.id);
    expect(first.getAttribute("aria-controls")).not.toBe(second.getAttribute("aria-controls"));
    await user.click(second);
    await user.keyboard("{ArrowDown}");
    expect(document.getElementById(first.getAttribute("aria-controls") ?? "")).toBeInTheDocument();
    expect(second).toHaveAttribute("aria-activedescendant", screen.getByRole("option", { name: "Apple" }).id);
  });
});

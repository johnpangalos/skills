import {
  createContext,
  useContext,
  useId,
  useLayoutEffect,
  useRef,
  useState,
  type ComponentPropsWithoutRef,
  type KeyboardEvent,
  type RefObject,
} from "react";

type TabEntry = { value: string; disabled: boolean; element: RefObject<HTMLButtonElement | null> };

type TabsContextValue = {
  baseId: string;
  selected: string | undefined;
  select: (value: string) => void;
  register: (entry: TabEntry) => () => void;
};

const TabsContext = createContext<TabsContextValue | null>(null);

function useTabsContext(component: string): TabsContextValue {
  const context = useContext(TabsContext);
  if (!context) throw new Error(`${component} must be rendered inside <Tabs>`);
  return context;
}

// encodeURIComponent keeps ids free of whitespace and unique per value.
const tabId = (baseId: string, value: string) => `${baseId}-tab-${encodeURIComponent(value)}`;
const panelId = (baseId: string, value: string) => `${baseId}-panel-${encodeURIComponent(value)}`;

function enabledTabs(list: HTMLElement | null): HTMLButtonElement[] {
  if (!list) return [];
  return Array.from(list.querySelectorAll<HTMLButtonElement>('[role="tab"]:not(:disabled)'));
}

function keyTarget(key: string, index: number, count: number): number | null {
  switch (key) {
    case "ArrowRight":
      return (index + 1) % count;
    case "ArrowLeft":
      return (index - 1 + count) % count;
    case "Home":
      return 0;
    case "End":
      return count - 1;
    default:
      return null;
  }
}

export type TabsProps = Omit<ComponentPropsWithoutRef<"div">, "defaultValue"> & {
  value?: string;
  defaultValue?: string;
  onValueChange?: (value: string) => void;
};

// Registration order is mount order, so the fallback is chosen by position in the DOM.
function byDomOrder(a: TabEntry, b: TabEntry): number {
  const first = a.element.current;
  const second = b.element.current;
  if (!first || !second) return 0;
  return first.compareDocumentPosition(second) & Node.DOCUMENT_POSITION_FOLLOWING ? -1 : 1;
}

export function Tabs({ value, defaultValue, onValueChange, ...rest }: TabsProps) {
  const baseId = useId();
  const [internal, setInternal] = useState(defaultValue);
  const [entries, setEntries] = useState<TabEntry[]>([]);
  const [firstEnabled, setFirstEnabled] = useState<string | undefined>(undefined);

  const requested = value === undefined ? internal : value;
  const enabled = entries.filter((entry) => !entry.disabled);
  // Before any tab registers (first render, SSR) the requested value is used as-is.
  // Otherwise falls back to the first enabled tab when the requested value matches none.
  const selected =
    entries.length === 0 || enabled.some((entry) => entry.value === requested)
      ? requested
      : firstEnabled;

  // Runs after every commit, so the fallback tracks the DOM order of the current tabs.
  useLayoutEffect(() => {
    setFirstEnabled([...entries].sort(byDomOrder).find((entry) => !entry.disabled)?.value);
  });

  const select = (next: string) => {
    if (next === selected) return;
    if (value === undefined) setInternal(next);
    onValueChange?.(next);
  };

  const register = (entry: TabEntry) => {
    setEntries((prev) => [...prev, entry]);
    return () => setEntries((prev) => prev.filter((item) => item !== entry));
  };

  return (
    <TabsContext.Provider value={{ baseId, selected, select, register }}>
      <div {...rest} />
    </TabsContext.Provider>
  );
}

export type TabListProps = Omit<ComponentPropsWithoutRef<"div">, "role"> & {
  "aria-label": string;
};

export function TabList({ onKeyDown, ...rest }: TabListProps) {
  const { select } = useTabsContext("TabList");
  const ref = useRef<HTMLDivElement>(null);

  return (
    <div
      {...rest}
      ref={ref}
      role="tablist"
      aria-orientation="horizontal"
      onKeyDown={(event: KeyboardEvent<HTMLDivElement>) => {
        onKeyDown?.(event);
        const tabs = enabledTabs(ref.current);
        const index = tabs.indexOf(event.target as HTMLButtonElement);
        const next = keyTarget(event.key, index, tabs.length);
        if (index === -1 || next === null) return;
        event.preventDefault();
        tabs[next].focus();
        select(tabs[next].getAttribute("data-value") ?? "");
      }}
    />
  );
}

export type TabProps = Omit<ComponentPropsWithoutRef<"button">, "value" | "role" | "type"> & {
  value: string;
};

export function Tab({ value, disabled, onClick, ...rest }: TabProps) {
  const { baseId, selected, select, register } = useTabsContext("Tab");
  const ref = useRef<HTMLButtonElement>(null);
  const isDisabled = Boolean(disabled);

  // Registration keeps the fallback tab stop and selection in sync with mounted tabs.
  useLayoutEffect(
    () => register({ value, disabled: isDisabled, element: ref }),
    [value, isDisabled],
  );

  const isSelected = value === selected;

  return (
    <button
      {...rest}
      ref={ref}
      type="button"
      role="tab"
      id={tabId(baseId, value)}
      data-value={value}
      aria-selected={isSelected}
      aria-controls={panelId(baseId, value)}
      tabIndex={isSelected ? 0 : -1}
      disabled={disabled}
      onClick={(event) => {
        onClick?.(event);
        select(value);
      }}
    />
  );
}

export type TabPanelProps = Omit<ComponentPropsWithoutRef<"div">, "role"> & {
  value: string;
};

export function TabPanel({ value, ...rest }: TabPanelProps) {
  const { baseId, selected } = useTabsContext("TabPanel");

  return (
    <div
      {...rest}
      role="tabpanel"
      id={panelId(baseId, value)}
      aria-labelledby={tabId(baseId, value)}
      tabIndex={0}
      hidden={value !== selected}
    />
  );
}

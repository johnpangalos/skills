import {
  useEffect,
  useId,
  useLayoutEffect,
  useRef,
  type HTMLAttributes,
  type KeyboardEvent as ReactKeyboardEvent,
} from "react";
import { createPortal } from "react-dom";

// Open dialogs, outermost first. Only the topmost one acts on document-level events.
const openDialogs: object[] = [];

export interface DialogProps extends Omit<HTMLAttributes<HTMLDivElement>, "title"> {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  title: string;
  description?: string;
}

const FOCUSABLE_SELECTOR =
  'a[href], area[href], button, input, select, textarea, iframe, [tabindex], [contenteditable="true"]';

function focusableElements(container: HTMLElement): HTMLElement[] {
  return Array.from(container.querySelectorAll<HTMLElement>(FOCUSABLE_SELECTOR)).filter(
    (element) =>
      !element.matches(":disabled") &&
      element.getAttribute("tabindex") !== "-1" &&
      element.getAttribute("type") !== "hidden" &&
      element.closest("[hidden]") === null,
  );
}

export function Dialog({
  open,
  onOpenChange,
  title,
  description,
  className,
  onKeyDown,
  children,
  ...rest
}: DialogProps) {
  const baseId = useId();
  const contentRef = useRef<HTMLDivElement>(null);
  const titleId = `${baseId}-title`;
  const descriptionId = `${baseId}-description`;

  // Listeners read the latest onOpenChange without re-subscribing on every render.
  const onOpenChangeRef = useRef(onOpenChange);
  useLayoutEffect(() => {
    onOpenChangeRef.current = onOpenChange;
  });

  // Focus moves in on open and returns on close or unmount (cleanup), if the element still exists.
  useEffect(() => {
    const content = contentRef.current;
    if (!open || content === null) return;
    const previous = document.activeElement as HTMLElement | null;
    const token = {};
    openDialogs.push(token);
    const isTopmost = () => openDialogs[openDialogs.length - 1] === token;
    const focusFirst = () => (focusableElements(content)[0] ?? content).focus();
    const focusLast = () => {
      const focusables = focusableElements(content);
      (focusables[focusables.length - 1] ?? content).focus();
    };
    // Focus that lands outside the content (e.g. a button behind the backdrop) is pulled back in.
    const handleFocusIn = (event: FocusEvent) => {
      if (isTopmost() && !content.contains(event.target as Node)) focusFirst();
    };
    // Keys whose target is outside the content (e.g. focus was lost to body) are handled here.
    const handleDocumentKeyDown = (event: KeyboardEvent) => {
      if (!isTopmost() || content.contains(event.target as Node)) return;
      if (event.key === "Escape") {
        event.stopPropagation();
        onOpenChangeRef.current(false);
      } else if (event.key === "Tab") {
        event.preventDefault();
        if (event.shiftKey) focusLast();
        else focusFirst();
      }
    };
    document.addEventListener("focusin", handleFocusIn);
    document.addEventListener("keydown", handleDocumentKeyDown);
    focusFirst();
    return () => {
      openDialogs.splice(openDialogs.indexOf(token), 1);
      document.removeEventListener("focusin", handleFocusIn);
      document.removeEventListener("keydown", handleDocumentKeyDown);
      if (previous?.isConnected) previous.focus();
    };
  }, [open]);

  const handleKeyDown = (event: ReactKeyboardEvent<HTMLDivElement>) => {
    onKeyDown?.(event);
    const content = contentRef.current;
    if (event.key === "Escape") {
      // Stopping propagation lets only the innermost open dialog close.
      event.stopPropagation();
      onOpenChange(false);
      return;
    }
    if (event.key !== "Tab" || content === null || !content.contains(event.target as Node)) return;
    // Wrap at the ends of the focusable list; elsewhere the browser's native Tab move is correct.
    const focusables = focusableElements(content);
    const index = focusables.findIndex((element) => element === document.activeElement);
    let target: HTMLElement | null = null;
    if (focusables.length === 0) {
      target = content;
    } else if (event.shiftKey) {
      if (index <= 0) target = focusables[focusables.length - 1];
    } else if (index === -1 || index === focusables.length - 1) {
      target = focusables[0];
    }
    if (target !== null) {
      event.preventDefault();
      target.focus();
    }
  };

  if (!open) return null;

  return createPortal(
    <>
      <div
        data-backdrop=""
        aria-hidden="true"
        // Keeps focus where it was, so a backdrop click does not move it to body.
        onMouseDown={(event) => event.preventDefault()}
        onClick={() => onOpenChange(false)}
      />
      <div
        {...rest}
        ref={contentRef}
        role="dialog"
        aria-modal="true"
        aria-labelledby={titleId}
        aria-describedby={description === undefined ? undefined : descriptionId}
        tabIndex={-1}
        className={className}
        onKeyDown={handleKeyDown}
      >
        <h2 id={titleId}>{title}</h2>
        {description === undefined ? null : <p id={descriptionId}>{description}</p>}
        {children}
      </div>
    </>,
    document.body,
  );
}

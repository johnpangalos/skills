import { render, screen } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { useState } from "react";
import { Combobox, type ComboboxOption, type ComboboxValue } from "./Combobox";

const OPTIONS: ComboboxOption[] = [
  { value: "apple", label: "Apple" },
  { value: "banana", label: "Banana", disabled: true },
  { value: "cherry", label: "Cherry" },
  { value: "apricot", label: "Apricot" },
];

type ExampleProps = {
  options?: ComboboxOption[];
  value?: ComboboxValue | null;
  onChange?: (value: ComboboxValue | null) => void;
};

function Example({ options = OPTIONS, value = null, onChange = () => {} }: ExampleProps) {
  return <Combobox label="Fruit" placeholder="Search" options={options} value={value} onChange={onChange} />;
}

function Controlled({ options = OPTIONS, onChange }: { options?: ComboboxOption[]; onChange: (value: ComboboxValue | null) => void }) {
  const [value, setValue] = useState<ComboboxValue | null>(null);
  return (
    <Combobox
      label="Fruit"
      options={options}
      value={value}
      onChange={(next) => {
        setValue(next);
        onChange(next);
      }}
    />
  );
}

const input = () => screen.getByRole("combobox", { name: "Fruit" });
const option = (name: string) => screen.getByRole("option", { name });

describe("Combobox", () => {
  it("renders a labelled input with combobox ARIA and a placeholder", () => {
    render(<Example />);
    expect(input()).toHaveAttribute("aria-expanded", "false");
    expect(input()).toHaveAttribute("aria-autocomplete", "list");
    expect(input()).toHaveAttribute("placeholder", "Search");
    expect(input()).not.toHaveAttribute("aria-activedescendant");
    const listbox = document.getElementById(input().getAttribute("aria-controls") ?? "");
    expect(listbox).toHaveAttribute("role", "listbox");
    expect(listbox).not.toBeVisible();
  });

  it("opens and filters by case-insensitive substring, activating the first enabled match", async () => {
    const user = userEvent.setup();
    render(<Example />);
    await user.type(input(), "AP");
    expect(input()).toHaveAttribute("aria-expanded", "true");
    expect(screen.getAllByRole("option").map((item) => item.textContent)).toEqual(["Apple", "Apricot"]);
    expect(input()).toHaveAttribute("aria-activedescendant", option("Apple").id);
  });

  it("moves the active option with ArrowDown/ArrowUp, wrapping and skipping disabled options", async () => {
    const user = userEvent.setup();
    render(<Example />);
    await user.click(input());
    await user.keyboard("{ArrowDown}");
    expect(input()).toHaveAttribute("aria-expanded", "true");
    expect(input()).toHaveAttribute("aria-activedescendant", option("Apple").id);
    await user.keyboard("{ArrowDown}");
    expect(input()).toHaveAttribute("aria-activedescendant", option("Cherry").id);
    await user.keyboard("{ArrowDown}");
    expect(input()).toHaveAttribute("aria-activedescendant", option("Apricot").id);
    await user.keyboard("{ArrowDown}");
    expect(input()).toHaveAttribute("aria-activedescendant", option("Apple").id);
    await user.keyboard("{ArrowUp}");
    expect(input()).toHaveAttribute("aria-activedescendant", option("Apricot").id);
    expect(input()).toHaveFocus();
  });

  it("selects the active option on Enter, closes and shows its label", async () => {
    const user = userEvent.setup();
    const onChange = vi.fn();
    render(<Controlled onChange={onChange} />);
    await user.type(input(), "che");
    await user.keyboard("{Enter}");
    expect(onChange).toHaveBeenCalledWith("cherry");
    expect(input()).toHaveValue("Cherry");
    expect(input()).toHaveAttribute("aria-expanded", "false");
    expect(screen.queryByRole("option")).toBeNull();
  });

  it("does nothing on Enter with no active option", async () => {
    const user = userEvent.setup();
    const onChange = vi.fn();
    render(<Example onChange={onChange} />);
    await user.type(input(), "zzz");
    await user.keyboard("{Enter}");
    expect(onChange).not.toHaveBeenCalled();
    expect(input()).toHaveValue("zzz");
  });

  it("selects an enabled option on click and ignores a disabled one", async () => {
    const user = userEvent.setup();
    const onChange = vi.fn();
    render(<Controlled onChange={onChange} />);
    await user.click(input());
    await user.keyboard("{ArrowDown}");
    await user.click(option("Banana"));
    expect(onChange).not.toHaveBeenCalled();
    expect(option("Banana")).toHaveAttribute("aria-disabled", "true");
    expect(input()).toHaveFocus();
    await user.click(option("Cherry"));
    expect(onChange).toHaveBeenCalledWith("cherry");
    expect(input()).toHaveValue("Cherry");
  });

  it("marks the selected option with aria-selected", async () => {
    const user = userEvent.setup();
    render(<Example value="cherry" />);
    await user.click(input());
    await user.keyboard("{ArrowDown}");
    expect(option("Cherry")).toHaveAttribute("aria-selected", "true");
    expect(option("Apple")).toHaveAttribute("aria-selected", "false");
  });

  it("closes on Escape without calling onChange and restores the selected label", async () => {
    const user = userEvent.setup();
    const onChange = vi.fn();
    render(<Example value="apple" onChange={onChange} />);
    await user.type(input(), "ch");
    await user.keyboard("{Escape}");
    expect(onChange).not.toHaveBeenCalled();
    expect(input()).toHaveValue("Apple");
    expect(input()).toHaveAttribute("aria-expanded", "false");
  });

  it("closes on blur and restores the label, keeping the current value", async () => {
    const user = userEvent.setup();
    const onChange = vi.fn();
    render(<Example value="apple" onChange={onChange} />);
    await user.clear(input());
    expect(screen.getAllByRole("option")).toHaveLength(4);
    await user.tab();
    expect(onChange).not.toHaveBeenCalled();
    expect(input()).toHaveValue("Apple");
    expect(input()).toHaveAttribute("aria-expanded", "false");
  });

  it("shows No results when nothing matches and omits aria-activedescendant", async () => {
    const user = userEvent.setup();
    render(<Example />);
    await user.type(input(), "zzz");
    expect(screen.getByText("No results")).toBeInTheDocument();
    expect(screen.queryByRole("option")).toBeNull();
    expect(input()).not.toHaveAttribute("aria-activedescendant");
  });

  it("follows the controlled value when it changes from outside", () => {
    const { rerender } = render(<Example value="apple" />);
    expect(input()).toHaveValue("Apple");
    rerender(<Example value="cherry" />);
    expect(input()).toHaveValue("Cherry");
  });

  it("keeps the old value when the parent ignores onChange", async () => {
    const user = userEvent.setup();
    const onChange = vi.fn();
    render(<Example value={null} onChange={onChange} />);
    await user.type(input(), "apr");
    await user.keyboard("{Enter}");
    expect(onChange).toHaveBeenCalledWith("apricot");
    expect(input()).toHaveValue("");
  });

  it("treats falsy option values 0 and empty string as real selections", async () => {
    const user = userEvent.setup();
    const onChange = vi.fn();
    const options: ComboboxOption[] = [
      { value: 0, label: "Zero" },
      { value: "", label: "Empty" },
    ];
    const { rerender } = render(<Example options={options} value={0} onChange={onChange} />);
    expect(input()).toHaveValue("Zero");
    rerender(<Example options={options} value="" onChange={onChange} />);
    expect(input()).toHaveValue("Empty");
    await user.click(input());
    await user.keyboard("{ArrowDown}");
    await user.click(option("Zero"));
    expect(onChange).toHaveBeenCalledWith(0);
  });

  it("does not throw on regex special characters in the filter text", async () => {
    const user = userEvent.setup();
    render(<Example />);
    await user.type(input(), "(.");
    expect(screen.getByText("No results")).toBeInTheDocument();
  });

  it("keeps ArrowDown without an active option when all options are disabled", async () => {
    const user = userEvent.setup();
    const onChange = vi.fn();
    render(
      <Example
        options={[{ value: "a", label: "A", disabled: true }]}
        onChange={onChange}
      />,
    );
    await user.click(input());
    await user.keyboard("{ArrowDown}{Enter}");
    expect(input()).not.toHaveAttribute("aria-activedescendant");
    expect(onChange).not.toHaveBeenCalled();
  });

  it("shows No results for an empty options array", async () => {
    const user = userEvent.setup();
    render(<Example options={[]} />);
    await user.click(input());
    await user.keyboard("{ArrowDown}");
    expect(screen.getByText("No results")).toBeInTheDocument();
  });

  it("shows an empty input when value matches no option", () => {
    render(<Example value="missing" />);
    expect(input()).toHaveValue("");
  });

  it("gives two comboboxes distinct ids", () => {
    render(
      <>
        <Example />
        <Combobox label="Second" options={OPTIONS} value={null} onChange={() => {}} />
      </>,
    );
    const second = screen.getByRole("combobox", { name: "Second" });
    expect(input().id).not.toBe(second.id);
    expect(input().getAttribute("aria-controls")).not.toBe(second.getAttribute("aria-controls"));
  });

  it("accepts useState<string | null> setters as onChange (type-level check)", async () => {
    const user = userEvent.setup();
    const FRUITS: ComboboxOption<string>[] = [{ value: "apple", label: "Apple" }];
    function StringPicker() {
      const [value, setValue] = useState<string | null>(null);
      return <Combobox label="Fruit" options={FRUITS} value={value} onChange={setValue} />;
    }
    render(<StringPicker />);
    await user.type(input(), "app");
    await user.keyboard("{Enter}");
    expect(input()).toHaveValue("Apple");
  });

  it("lets Enter submit a surrounding form when the list is closed", async () => {
    const user = userEvent.setup();
    const onSubmit = vi.fn();
    render(
      <form
        onSubmit={(event) => {
          event.preventDefault();
          onSubmit();
        }}
      >
        <Example />
        <button>Go</button>
      </form>,
    );
    await user.click(input());
    await user.keyboard("{Enter}");
    expect(onSubmit).toHaveBeenCalledTimes(1);
  });

  it("does not submit a surrounding form when Enter chooses an active option", async () => {
    const user = userEvent.setup();
    const onChange = vi.fn();
    const onSubmit = vi.fn();
    render(
      <form
        onSubmit={(event) => {
          event.preventDefault();
          onSubmit();
        }}
      >
        <Controlled onChange={onChange} />
        <button>Go</button>
      </form>,
    );
    await user.type(input(), "che");
    await user.keyboard("{Enter}");
    expect(onChange).toHaveBeenCalledWith("cherry");
    expect(onSubmit).not.toHaveBeenCalled();
  });

  it("announces No results in a role=status region", async () => {
    const user = userEvent.setup();
    render(<Example />);
    await user.type(input(), "zzz");
    expect(screen.getByRole("status")).toHaveTextContent(/^No results$/);
  });

  it("forwards className and data attributes to the root element", () => {
    render(
      <Combobox label="Tagged" className="field" data-testid="combo" options={OPTIONS} value={null} onChange={() => {}} />,
    );
    expect(screen.getByTestId("combo")).toHaveClass("field");
  });
});

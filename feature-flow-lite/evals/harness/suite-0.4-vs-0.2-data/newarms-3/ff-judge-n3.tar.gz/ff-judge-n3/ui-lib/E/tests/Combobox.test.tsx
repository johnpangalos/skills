import { useState } from "react";
import { render, screen } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { Combobox, type ComboboxOption } from "../src/index";

const OPTIONS: ComboboxOption[] = [
  { value: "apple pie", label: "Apple" },
  { value: "banana", label: "Banana", disabled: true },
  { value: "cherry", label: "Cherry" },
  { value: "date", label: "Date (dried)" },
];

function Controlled({
  options = OPTIONS,
  initial = null,
  onChange = () => {},
}: {
  options?: ComboboxOption[];
  initial?: string | null;
  onChange?: (value: string | null) => void;
}) {
  const [value, setValue] = useState<string | null>(initial);
  return (
    <Combobox
      label="Fruit"
      options={options}
      value={value}
      onChange={(next) => {
        onChange(next);
        setValue(next);
      }}
    />
  );
}

function input() {
  return screen.getByRole("combobox", { name: "Fruit" });
}

function optionLabels() {
  return screen.queryAllByRole("option").map((option) => option.textContent);
}

describe("Combobox", () => {
  it("ties the label to the input and the listbox to the label", () => {
    render(<Controlled />);
    const listbox = screen.getByRole("listbox", { hidden: true });
    expect(input()).toHaveAttribute("aria-autocomplete", "list");
    expect(input()).toHaveAttribute("aria-expanded", "false");
    expect(input()).toHaveAttribute("aria-controls", listbox.id);
    expect(listbox).toHaveAttribute("aria-labelledby", screen.getByText("Fruit").id);
    expect(input()).not.toHaveAttribute("aria-activedescendant");
  });

  it("shows the selected label while not editing, and updates when value changes", () => {
    const { rerender } = render(<Combobox label="Fruit" options={OPTIONS} value="cherry" onChange={() => {}} />);
    expect(input()).toHaveValue("Cherry");
    rerender(<Combobox label="Fruit" options={OPTIONS} value="date" onChange={() => {}} />);
    expect(input()).toHaveValue("Date (dried)");
  });

  it("shows an empty input when value is null or matches no option", () => {
    const { rerender } = render(<Combobox label="Fruit" options={OPTIONS} value={null} onChange={() => {}} />);
    expect(input()).toHaveValue("");
    rerender(<Combobox label="Fruit" options={OPTIONS} value="missing" onChange={() => {}} />);
    expect(input()).toHaveValue("");
  });

  it("opens and filters case-insensitively on typing", async () => {
    const user = userEvent.setup();
    render(<Controlled />);
    await user.type(input(), "AN");
    expect(input()).toHaveAttribute("aria-expanded", "true");
    expect(optionLabels()).toEqual(["Banana"]);
  });

  it("treats the query as a literal substring, so regex characters do not throw", async () => {
    const user = userEvent.setup();
    render(<Controlled />);
    await user.type(input(), "(dr");
    expect(optionLabels()).toEqual(["Date (dried)"]);
    await user.clear(input());
    await user.type(input(), ".*");
    expect(screen.getByRole("status")).toHaveTextContent("No results");
  });

  it("marks the selected option and disabled options", async () => {
    const user = userEvent.setup();
    render(<Controlled initial="cherry" />);
    await user.click(input());
    await user.keyboard("{ArrowDown}");
    const cherry = screen.getByRole("option", { name: "Cherry" });
    expect(cherry).toHaveAttribute("aria-selected", "true");
    expect(screen.getByRole("option", { name: "Banana" })).toHaveAttribute("aria-disabled", "true");
    expect(screen.getByRole("option", { name: "Apple" })).toHaveAttribute("aria-selected", "false");
  });

  it("gives options ids without whitespace even when values contain spaces", async () => {
    const user = userEvent.setup();
    render(<Controlled />);
    await user.type(input(), "a");
    for (const option of screen.getAllByRole("option")) {
      expect(option.id).not.toMatch(/\s/);
    }
  });

  it("opens on ArrowDown and activates the first enabled option, skipping disabled ones", async () => {
    const user = userEvent.setup();
    render(<Controlled />);
    await user.click(input());
    await user.keyboard("{ArrowDown}");
    expect(input()).toHaveAttribute("aria-expanded", "true");
    const apple = screen.getByRole("option", { name: "Apple" });
    expect(input()).toHaveAttribute("aria-activedescendant", apple.id);
    expect(apple).toHaveAttribute("data-active", "true");
    await user.keyboard("{ArrowDown}");
    expect(input()).toHaveAttribute("aria-activedescendant", screen.getByRole("option", { name: "Cherry" }).id);
  });

  it("wraps ArrowDown and ArrowUp at the ends of the list", async () => {
    const user = userEvent.setup();
    render(<Controlled />);
    await user.click(input());
    await user.keyboard("{ArrowUp}");
    expect(input()).toHaveAttribute("aria-activedescendant", screen.getByRole("option", { name: "Date (dried)" }).id);
    await user.keyboard("{ArrowDown}");
    expect(input()).toHaveAttribute("aria-activedescendant", screen.getByRole("option", { name: "Apple" }).id);
    await user.keyboard("{ArrowUp}");
    expect(input()).toHaveAttribute("aria-activedescendant", screen.getByRole("option", { name: "Date (dried)" }).id);
  });

  it("activates the selected option when opened with the keyboard", async () => {
    const user = userEvent.setup();
    render(<Controlled initial="cherry" />);
    await user.click(input());
    await user.keyboard("{ArrowDown}");
    expect(screen.getByRole("option", { name: "Cherry" })).toHaveAttribute("data-active", "true");
  });

  it("does not activate anything when the only matching option is disabled", async () => {
    const user = userEvent.setup();
    render(<Controlled />);
    await user.type(input(), "ban");
    await user.keyboard("{ArrowDown}");
    expect(input()).not.toHaveAttribute("aria-activedescendant");
    await user.keyboard("{Enter}");
    expect(input()).toHaveAttribute("aria-expanded", "true");
  });

  it("selects the active option on Enter, closes, and shows its label", async () => {
    const user = userEvent.setup();
    const onChange = vi.fn();
    render(<Controlled onChange={onChange} />);
    await user.type(input(), "app");
    await user.keyboard("{ArrowDown}{Enter}");
    expect(onChange).toHaveBeenCalledWith("apple pie");
    expect(input()).toHaveValue("Apple");
    expect(input()).toHaveAttribute("aria-expanded", "false");
  });

  it("does nothing on Enter when there is no active option", async () => {
    const user = userEvent.setup();
    const onChange = vi.fn();
    render(<Controlled onChange={onChange} />);
    await user.type(input(), "zzz");
    await user.keyboard("{Enter}");
    expect(onChange).not.toHaveBeenCalled();
    expect(input()).toHaveAttribute("aria-expanded", "true");
  });

  it("selects an enabled option on click and does nothing on a disabled one", async () => {
    const user = userEvent.setup();
    const onChange = vi.fn();
    render(<Controlled onChange={onChange} />);
    await user.click(input());
    await user.keyboard("{ArrowDown}");
    await user.click(screen.getByRole("option", { name: "Banana" }));
    expect(onChange).not.toHaveBeenCalled();
    expect(input()).toHaveAttribute("aria-expanded", "true");
    await user.click(screen.getByRole("option", { name: "Cherry" }));
    expect(onChange).toHaveBeenCalledWith("cherry");
    expect(input()).toHaveValue("Cherry");
  });

  it("closes on Escape without calling onChange and reverts the typed text", async () => {
    const user = userEvent.setup();
    const onChange = vi.fn();
    render(<Controlled initial="cherry" onChange={onChange} />);
    await user.type(input(), "ap");
    await user.keyboard("{Escape}");
    expect(onChange).not.toHaveBeenCalled();
    expect(input()).toHaveAttribute("aria-expanded", "false");
    expect(input()).toHaveValue("Cherry");
  });

  it("does not crash on Escape while closed", async () => {
    const user = userEvent.setup();
    render(<Controlled />);
    await user.click(input());
    await user.keyboard("{Escape}");
    expect(input()).toHaveValue("");
  });

  it("shows No results, drops aria-activedescendant, and ignores Enter when nothing matches", async () => {
    const user = userEvent.setup();
    const onChange = vi.fn();
    render(<Controlled onChange={onChange} />);
    await user.type(input(), "zzz");
    expect(screen.getByRole("status")).toHaveTextContent("No results");
    expect(input()).not.toHaveAttribute("aria-activedescendant");
    await user.keyboard("{Enter}");
    expect(onChange).not.toHaveBeenCalled();
  });

  it("shows No results when there are no options at all", async () => {
    const user = userEvent.setup();
    render(<Controlled options={[]} />);
    await user.click(input());
    await user.keyboard("{ArrowDown}");
    expect(screen.getByRole("status")).toHaveTextContent("No results");
    expect(input()).not.toHaveAttribute("aria-activedescendant");
  });

  it("does not activate anything when every option is disabled", async () => {
    const user = userEvent.setup();
    const onChange = vi.fn();
    render(<Controlled options={[{ value: "a", label: "A", disabled: true }]} onChange={onChange} />);
    await user.click(input());
    await user.keyboard("{ArrowDown}{ArrowUp}{Enter}");
    expect(input()).not.toHaveAttribute("aria-activedescendant");
    expect(onChange).not.toHaveBeenCalled();
  });

  it("closes on blur and reverts the text to the selected label", async () => {
    const user = userEvent.setup();
    const onChange = vi.fn();
    render(<Controlled initial="apple pie" onChange={onChange} />);
    await user.type(input(), "ch");
    await user.tab();
    expect(input()).toHaveAttribute("aria-expanded", "false");
    expect(input()).toHaveValue("Apple");
    expect(onChange).not.toHaveBeenCalled();
  });

  it("keeps two comboboxes on one page with distinct ids", () => {
    render(
      <>
        <Controlled />
        <Controlled />
      </>,
    );
    const inputs = screen.getAllByRole("combobox", { name: "Fruit" });
    expect(inputs[0].id).not.toBe(inputs[1].id);
    const listboxes = screen.getAllByRole("listbox", { hidden: true });
    expect(listboxes[0].id).not.toBe(listboxes[1].id);
    expect(inputs[1]).toHaveAttribute("aria-controls", listboxes[1].id);
  });

  it("calls onChange(null) when the text is emptied and the input blurs", async () => {
    const user = userEvent.setup();
    const onChange = vi.fn();
    render(<Controlled initial="apple pie" onChange={onChange} />);
    await user.clear(input());
    await user.tab();
    expect(onChange).toHaveBeenCalledTimes(1);
    expect(onChange).toHaveBeenCalledWith(null);
    expect(input()).toHaveValue("");
  });

  it("calls onChange(null) on Enter when the text is emptied and no option is active", async () => {
    const user = userEvent.setup();
    const onChange = vi.fn();
    render(<Controlled initial="apple pie" onChange={onChange} />);
    await user.clear(input());
    await user.keyboard("{Enter}");
    expect(onChange).toHaveBeenCalledTimes(1);
    expect(onChange).toHaveBeenCalledWith(null);
    expect(input()).toHaveAttribute("aria-expanded", "false");
  });

  it("does not call onChange when the text is emptied and the value is already null", async () => {
    const user = userEvent.setup();
    const onChange = vi.fn();
    render(<Controlled onChange={onChange} />);
    await user.type(input(), "ap");
    await user.clear(input());
    await user.tab();
    expect(onChange).not.toHaveBeenCalled();
    expect(input()).toHaveValue("");
  });

  it("selects the active option on Enter after the text is emptied", async () => {
    const user = userEvent.setup();
    const onChange = vi.fn();
    render(<Controlled onChange={onChange} />);
    await user.clear(input());
    await user.keyboard("{ArrowDown}{Enter}");
    expect(onChange).toHaveBeenCalledTimes(1);
    expect(onChange).toHaveBeenCalledWith("apple pie");
  });

  it("reverts the emptied text on Escape without calling onChange", async () => {
    const user = userEvent.setup();
    const onChange = vi.fn();
    render(<Controlled initial="apple pie" onChange={onChange} />);
    await user.clear(input());
    await user.keyboard("{Escape}");
    expect(onChange).not.toHaveBeenCalled();
    expect(input()).toHaveValue("Apple");
  });

  it("selects the first enabled match on Enter after typing, without arrow keys", async () => {
    const user = userEvent.setup();
    const onChange = vi.fn();
    render(<Controlled onChange={onChange} />);
    await user.type(input(), "app");
    await user.keyboard("{Enter}");
    expect(onChange).toHaveBeenCalledTimes(1);
    expect(onChange).toHaveBeenCalledWith("apple pie");
    expect(input()).toHaveValue("Apple");
  });

  it("activates the next enabled match when the first match is disabled", async () => {
    const user = userEvent.setup();
    const onChange = vi.fn();
    const options: ComboboxOption[] = [
      { value: "bagel", label: "Bagel", disabled: true },
      { value: "baguette", label: "Baguette" },
    ];
    render(<Controlled options={options} onChange={onChange} />);
    await user.type(input(), "ba");
    expect(input()).toHaveAttribute("aria-activedescendant");
    expect(screen.getByRole("option", { name: "Baguette" })).toHaveAttribute("data-active", "true");
    await user.keyboard("{Enter}");
    expect(onChange).toHaveBeenCalledWith("baguette");
  });

  it("calls onChange(null) on Enter after the text is cleared by typing", async () => {
    const user = userEvent.setup();
    const onChange = vi.fn();
    render(<Controlled initial="apple pie" onChange={onChange} />);
    await user.type(input(), "app");
    await user.clear(input());
    await user.keyboard("{Enter}");
    expect(onChange).toHaveBeenCalledTimes(1);
    expect(onChange).toHaveBeenCalledWith(null);
    expect(input()).toHaveAttribute("aria-expanded", "false");
  });
});

import {
  useId,
  useState,
  type ChangeEvent,
  type ComponentPropsWithoutRef,
  type KeyboardEvent,
} from "react";

export type ComboboxOption<T extends string | number = string> = {
  value: T;
  label: string;
  disabled?: boolean;
};

export type ComboboxProps<T extends string | number = string> = Omit<
  ComponentPropsWithoutRef<"div">,
  "defaultValue" | "onChange"
> & {
  label: string;
  options: ComboboxOption<T>[];
  value?: T | null;
  defaultValue?: T | null;
  onChange?: (value: T | null) => void;
  placeholder?: string;
};

// An option together with its position in the full `options` array, which keeps option ids stable while filtering.
type Entry<T extends string | number> = { option: ComboboxOption<T>; index: number };

function filterEntries<T extends string | number>(options: ComboboxOption<T>[], query: string): Entry<T>[] {
  const needle = query.trim().toLowerCase();
  return options
    .map((option, index) => ({ option, index }))
    .filter(({ option }) => option.label.toLowerCase().includes(needle));
}

// First enabled entry after `from` (-1 means the start), wrapping past the end. Returns -1 when none is enabled.
function nextEnabled<T extends string | number>(entries: Entry<T>[], from: number): number {
  const count = entries.length;
  for (let step = 1; step <= count; step++) {
    const index = (from + step) % count;
    if (!entries[index].option.disabled) return index;
  }
  return -1;
}

// Last enabled entry before `from` (entries.length means the end), wrapping past the start. Returns -1 when none is enabled.
function previousEnabled<T extends string | number>(entries: Entry<T>[], from: number): number {
  const count = entries.length;
  for (let step = 1; step <= count; step++) {
    const index = (from - step + count) % count;
    if (!entries[index].option.disabled) return index;
  }
  return -1;
}

export function Combobox<T extends string | number = string>({
  label,
  options,
  value,
  defaultValue,
  onChange,
  placeholder,
  ...rest
}: ComboboxProps<T>) {
  const baseId = useId();
  const labelId = `${baseId}-label`;
  const inputId = `${baseId}-input`;
  const listboxId = `${baseId}-listbox`;
  const optionId = (index: number) => `${baseId}-option-${index}`;

  const [internal, setInternal] = useState<T | null>(defaultValue ?? null);
  const selectedValue = value === undefined ? internal : value;
  const selected = options.find((option) => option.value === selectedValue);

  // `text` is null while the user is not editing, so the input shows the selected label.
  const [text, setText] = useState<string | null>(null);
  const [open, setOpen] = useState(false);
  const [activeIndex, setActiveIndex] = useState(-1);

  const entries = filterEntries(options, text ?? "");
  const active =
    open && activeIndex >= 0 && activeIndex < entries.length && !entries[activeIndex].option.disabled
      ? entries[activeIndex]
      : undefined;

  const reset = () => {
    setText(null);
    setOpen(false);
    setActiveIndex(-1);
  };

  const commit = (next: T | null) => {
    if (value === undefined) setInternal(next);
    reset();
    onChange?.(next);
  };

  const handleChange = (event: ChangeEvent<HTMLInputElement>) => {
    const next = event.target.value;
    setText(next);
    setOpen(true);
    setActiveIndex(next.trim() === "" ? -1 : nextEnabled(filterEntries(options, next), -1));
  };

  const handleKeyDown = (event: KeyboardEvent<HTMLInputElement>) => {
    switch (event.key) {
      case "ArrowDown":
        // `active` is only set while open, so a closed list starts from the beginning.
        event.preventDefault();
        setActiveIndex(nextEnabled(entries, active ? activeIndex : -1));
        setOpen(true);
        return;
      case "ArrowUp":
        event.preventDefault();
        setActiveIndex(previousEnabled(entries, active ? activeIndex : entries.length));
        setOpen(true);
        return;
      case "Enter":
        if (active) {
          event.preventDefault();
          commit(active.option.value);
        } else if (text === "" && selected !== undefined) {
          event.preventDefault();
          commit(null);
        }
        return;
      case "Escape":
        if (!open) return;
        // Stops an enclosing Dialog from also handling this Escape.
        event.preventDefault();
        event.stopPropagation();
        reset();
        return;
    }
  };

  const handleBlur = () => {
    if (text === "" && selected !== undefined) {
      commit(null);
    } else {
      reset();
    }
  };

  return (
    <div {...rest}>
      <label id={labelId} htmlFor={inputId}>
        {label}
      </label>
      <input
        id={inputId}
        type="text"
        role="combobox"
        autoComplete="off"
        aria-autocomplete="list"
        aria-expanded={open}
        aria-controls={listboxId}
        aria-activedescendant={active ? optionId(active.index) : undefined}
        placeholder={placeholder}
        value={text ?? selected?.label ?? ""}
        onChange={handleChange}
        onKeyDown={handleKeyDown}
        onBlur={handleBlur}
      />
      {/* Keeps DOM focus on the input: a mousedown on an option must not blur it. */}
      <div
        id={listboxId}
        role="listbox"
        aria-labelledby={labelId}
        hidden={!open}
        onMouseDown={(event) => event.preventDefault()}
      >
        {open &&
          entries.map(({ option, index }) => (
            <div
              key={index}
              id={optionId(index)}
              role="option"
              aria-selected={option.value === selectedValue}
              aria-disabled={option.disabled ? "true" : undefined}
              data-active={active?.index === index ? "" : undefined}
              onClick={() => {
                if (!option.disabled) commit(option.value);
              }}
            >
              {option.label}
            </div>
          ))}
      </div>
      {open && entries.length === 0 && <div role="status">No results</div>}
    </div>
  );
}

import { describe, expect, it } from "vitest";
import * as library from "../src/index";
import type {
  ComboboxOption,
  ComboboxProps,
  DialogProps,
  TabListProps,
  TabPanelProps,
  TabProps,
  TabsProps,
} from "../src/index";

describe("package exports (G1)", () => {
  it("exports the components from src/index.ts", () => {
    expect(Object.keys(library).sort()).toEqual(
      ["Combobox", "Dialog", "Tab", "TabList", "TabPanel", "Tabs"].sort(),
    );
    for (const name of Object.keys(library)) {
      expect(typeof library[name as keyof typeof library]).toBe("function");
    }
  });

  it("exports the props types, and Combobox types its value and onChange by option value", () => {
    const option: ComboboxOption<"a" | "b"> = { value: "a", label: "A" };
    const props: ComboboxProps<"a" | "b"> = {
      label: "Letter",
      options: [option],
      value: null,
      onChange: (next) => {
        const check: "a" | "b" | null = next;
        return check;
      },
    };
    const tabs: TabsProps = {};
    const list: TabListProps = { "aria-label": "Sections" };
    const tab: TabProps = { value: "one" };
    const panel: TabPanelProps = { value: "one" };
    const dialog: DialogProps = { open: false, onOpenChange: () => {}, title: "T", children: null };
    expect([props, tabs, list, tab, panel, dialog]).toHaveLength(6);
  });
});

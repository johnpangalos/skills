package middleware

import (
	"bufio"
	"bytes"
	"crypto/sha256"
	"encoding/hex"
	"io"
	"maps"
	"net"
	"net/http"
	"strings"
)

// ETag buffers the response to GET and HEAD requests. When the handler responds
// 200 without setting an ETag header, it sets a strong ETag: the hex-encoded
// SHA-256 digest of the body, quoted. If the request's If-None-Match matches the
// ETag (weak comparison, per RFC 9110), the response becomes 304 Not Modified with
// no body. Other methods and non-200 responses pass through unchanged.
//
// Placed outside Compress, the ETag hashes the encoded bytes. A NoCache middleware
// placed outside ETag removes If-None-Match, so no 304 is sent.
func ETag(next http.Handler) http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		if r.Method != http.MethodGet && r.Method != http.MethodHead {
			next.ServeHTTP(w, r)
			return
		}

		ew := &etagWriter{dst: w, header: w.Header().Clone()}
		next.ServeHTTP(ew, r)
		if !ew.hijacked {
			ew.emit(r)
		}
	})
}

// etagWriter holds a response until the handler returns. It is not an embedding
// wrapper, so the optional interfaces it exposes are the only ones dst can reach.
type etagWriter struct {
	dst         http.ResponseWriter
	header      http.Header
	snapshot    http.Header
	status      int
	wroteHeader bool
	hijacked    bool
	body        bytes.Buffer
}

func (ew *etagWriter) Header() http.Header {
	return ew.header
}

// WriteHeader records the first final status and snapshots the headers at that
// point, as net/http does. Informational 1xx codes are forwarded to dst right
// away and never recorded as the final status.
func (ew *etagWriter) WriteHeader(code int) {
	if ew.wroteHeader {
		return
	}
	if code >= 100 && code < 200 {
		dh := ew.dst.Header()
		clear(dh)
		maps.Copy(dh, ew.header)
		ew.dst.WriteHeader(code)
		return
	}
	ew.wroteHeader = true
	ew.status = code
	ew.snapshot = ew.header.Clone()
}

func (ew *etagWriter) Write(p []byte) (int, error) {
	if !ew.wroteHeader {
		ew.WriteHeader(http.StatusOK)
	}
	return ew.body.Write(p)
}

// ReadFrom buffers src, so the underlying writer is never written to early.
func (ew *etagWriter) ReadFrom(src io.Reader) (int64, error) {
	if !ew.wroteHeader {
		ew.WriteHeader(http.StatusOK)
	}
	return ew.body.ReadFrom(src)
}

// Flush is a no-op: the response is sent only once the handler returns.
func (ew *etagWriter) Flush() {}

func (ew *etagWriter) Hijack() (net.Conn, *bufio.ReadWriter, error) {
	hj, ok := ew.dst.(http.Hijacker)
	if !ok {
		return nil, nil, http.ErrNotSupported
	}
	conn, rw, err := hj.Hijack()
	if err == nil {
		ew.hijacked = true
	}
	return conn, rw, err
}

func (ew *etagWriter) Push(target string, opts *http.PushOptions) error {
	p, ok := ew.dst.(http.Pusher)
	if !ok {
		return http.ErrNotSupported
	}
	return p.Push(target, opts)
}

// Unwrap exposes dst to http.ResponseController, which checks Flush first, so
// Flush stays buffered while deadlines and full duplex reach the real writer.
func (ew *etagWriter) Unwrap() http.ResponseWriter {
	return ew.dst
}

// emit sends the buffered response to dst, replacing a 200 with 304 when the
// request's If-None-Match matches its ETag. Trailers are set after the body, so
// net/http sends them at the end of the response.
func (ew *etagWriter) emit(r *http.Request) {
	if !ew.wroteHeader {
		ew.WriteHeader(http.StatusOK)
	}
	h, status, body := ew.snapshot, ew.status, ew.body.Bytes()
	if status == http.StatusOK {
		// A HEAD that wrote no body has no representation to tag, so it gets no computed ETag.
		if h.Get("ETag") == "" && (r.Method == http.MethodGet || len(body) > 0) {
			h.Set("ETag", etagFor(body))
		}
		if etag := h.Get("ETag"); ifNoneMatch(r.Header.Values("If-None-Match"), etag) {
			h.Del("Content-Length")
			h.Del("Content-Type")
			h.Del("Content-Encoding")
			h.Del("Last-Modified")
			h.Del("Transfer-Encoding")
			status, body = http.StatusNotModified, nil
		}
	}

	dh := ew.dst.Header()
	clear(dh)
	maps.Copy(dh, h)
	ew.dst.WriteHeader(status)
	if len(body) > 0 {
		ew.dst.Write(body)
	}
	for _, k := range trailerKeys(h) {
		if v, ok := ew.header[k]; ok {
			dh[k] = v
		}
	}
	for k, v := range ew.header {
		if strings.HasPrefix(k, http.TrailerPrefix) {
			dh[k] = v
		}
	}
}

// trailerKeys returns the canonical names declared in the Trailer header.
func trailerKeys(h http.Header) []string {
	var keys []string
	for _, line := range h.Values("Trailer") {
		for _, name := range strings.Split(line, ",") {
			keys = append(keys, http.CanonicalHeaderKey(strings.TrimSpace(name)))
		}
	}
	return keys
}

// etagFor returns the strong entity-tag for body: its quoted SHA-256 hex digest.
func etagFor(body []byte) string {
	sum := sha256.Sum256(body)
	return `"` + hex.EncodeToString(sum[:]) + `"`
}

// ifNoneMatch reports whether a line is "*", or whether any entity-tag in the
// If-None-Match lines weakly matches etag. An empty etag has no tag to compare.
// Opaque tags are compared byte for byte.
func ifNoneMatch(lines []string, etag string) bool {
	want := strings.TrimPrefix(etag, "W/")
	for _, line := range lines {
		if strings.TrimSpace(line) == "*" {
			return true
		}
		if want == "" {
			continue
		}
		for _, tag := range splitEntityTags(line) {
			if strings.TrimPrefix(strings.TrimSpace(tag), "W/") == want {
				return true
			}
		}
	}
	return false
}

// splitEntityTags splits an If-None-Match line on commas that are outside quotes.
func splitEntityTags(line string) []string {
	var tags []string
	start, quoted := 0, false
	for i := range len(line) {
		switch line[i] {
		case '"':
			quoted = !quoted
		case ',':
			if !quoted {
				tags = append(tags, line[start:i])
				start = i + 1
			}
		}
	}
	return append(tags, line[start:])
}

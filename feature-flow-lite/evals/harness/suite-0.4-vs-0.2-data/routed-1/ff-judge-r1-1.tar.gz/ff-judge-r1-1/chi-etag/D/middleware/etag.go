package middleware

import (
	"bufio"
	"bytes"
	"crypto/sha256"
	"encoding/hex"
	"errors"
	"maps"
	"net"
	"net/http"
	"strings"
)

// ETag is a middleware that adds a strong ETag to GET and HEAD responses and
// answers conditional requests with 304 Not Modified.
//
// The response is buffered until the handler returns, so the whole body is
// held in memory. When the handler responds 200 without setting an ETag
// header, the ETag is the quoted hex SHA-256 digest of the body. If the
// request's If-None-Match header matches the response's ETag under the weak
// comparison of RFC 9110 section 13.1.2, the response is replaced by a
// 304 Not Modified without a body. Responses with any other status are sent
// unchanged, and methods other than GET and HEAD are not buffered at all.
func ETag(next http.Handler) http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		if r.Method != http.MethodGet && r.Method != http.MethodHead {
			next.ServeHTTP(w, r)
			return
		}

		bw := &etagWriter{dst: w, header: w.Header().Clone()}
		next.ServeHTTP(bw, r)
		bw.replay(r)
	})
}

// etagWriter buffers a response so that ETag can inspect it before it is sent.
type etagWriter struct {
	dst         http.ResponseWriter
	header      http.Header
	snapshot    http.Header
	status      int
	wroteHeader bool
	hijacked    bool
	body        bytes.Buffer
}

// Header returns the buffered header map. Changes made after the first
// WriteHeader or Write are not sent.
func (bw *etagWriter) Header() http.Header {
	return bw.header
}

// WriteHeader records the status code and snapshots the headers. Informational
// (1xx) responses other than 101 are forwarded to the underlying writer
// immediately. Any WriteHeader after the final status is ignored.
func (bw *etagWriter) WriteHeader(code int) {
	if bw.wroteHeader {
		return
	}
	if code >= 100 && code < 200 && code != http.StatusSwitchingProtocols {
		clear(bw.dst.Header())
		maps.Copy(bw.dst.Header(), bw.header)
		bw.dst.WriteHeader(code)
		return
	}
	bw.wroteHeader = true
	bw.status = code
	bw.snapshot = bw.header.Clone()
}

// Write buffers p. Like net/http, it implies a 200 status if none was set.
func (bw *etagWriter) Write(p []byte) (int, error) {
	if !bw.wroteHeader {
		bw.WriteHeader(http.StatusOK)
	}
	return bw.body.Write(p)
}

// Flush does nothing, so that nothing is sent before the ETag is known.
func (bw *etagWriter) Flush() {}

// Unwrap returns the underlying writer, so that http.ResponseController can
// reach its deadline and full-duplex support.
func (bw *etagWriter) Unwrap() http.ResponseWriter {
	return bw.dst
}

// Hijack hands the connection to the underlying writer. The buffered response
// is then never sent, because the caller owns the connection.
func (bw *etagWriter) Hijack() (net.Conn, *bufio.ReadWriter, error) {
	hj, ok := bw.dst.(http.Hijacker)
	if !ok {
		return nil, nil, errors.New("chi/middleware: http.Hijacker is unavailable on the writer")
	}
	conn, rw, err := hj.Hijack()
	if err == nil {
		bw.hijacked = true
	}
	return conn, rw, err
}

// Push forwards a server push to the underlying writer. A pushed resource is
// not part of the buffered response, so it is sent immediately.
func (bw *etagWriter) Push(target string, opts *http.PushOptions) error {
	if ps, ok := bw.dst.(http.Pusher); ok {
		return ps.Push(target, opts)
	}
	return errors.New("chi/middleware: http.Pusher is unavailable on the writer")
}

// replay sends the buffered response to the underlying writer, unless the
// connection was hijacked.
func (bw *etagWriter) replay(r *http.Request) {
	if bw.hijacked {
		return
	}
	if !bw.wroteHeader {
		bw.WriteHeader(http.StatusOK)
	}
	if bw.status == http.StatusOK {
		// A HEAD response with an empty body has nothing to hash, so it only
		// keeps an ETag the handler set.
		if r.Method == http.MethodGet || bw.body.Len() > 0 {
			bw.setETag()
		}
		if etagMatch(r.Header.Values("If-None-Match"), bw.snapshot.Get("ETag")) {
			bw.notModified()
		}
	}

	h := bw.dst.Header()
	clear(h)
	maps.Copy(h, bw.snapshot)
	bw.dst.WriteHeader(bw.status)
	if bw.body.Len() > 0 {
		bw.dst.Write(bw.body.Bytes())
	}
	bw.copyTrailers(h)
}

// copyTrailers sets the trailers the handler declared in the Trailer header and
// the ones named with http.TrailerPrefix. Their values are read from the live
// header map, as net/http does when it finishes the response.
func (bw *etagWriter) copyTrailers(h http.Header) {
	for _, line := range bw.snapshot.Values("Trailer") {
		for _, key := range strings.Split(line, ",") {
			key = http.CanonicalHeaderKey(strings.TrimSpace(key))
			if vals, ok := bw.header[key]; ok {
				h[key] = vals
			}
		}
	}
	for key, vals := range bw.header {
		if strings.HasPrefix(key, http.TrailerPrefix) {
			h[key] = vals
		}
	}
}

// setETag adds a strong ETag computed from the body, unless the handler set an
// ETag header of its own, even an empty one.
func (bw *etagWriter) setETag() {
	if _, ok := bw.snapshot[http.CanonicalHeaderKey("ETag")]; ok {
		return
	}
	sum := sha256.Sum256(bw.body.Bytes())
	bw.snapshot.Set("ETag", `"`+hex.EncodeToString(sum[:])+`"`)
}

// notModified turns the buffered response into a 304 without a body. Validator
// and caching headers are kept; Content-Length and Content-Type are dropped
// because they describe the body that is no longer sent.
func (bw *etagWriter) notModified() {
	bw.snapshot.Del("Content-Length")
	bw.snapshot.Del("Content-Type")
	bw.status = http.StatusNotModified
	bw.body.Reset()
}

// etagMatch reports whether any member of the If-None-Match header lines
// matches etag under weak comparison. A "*" member matches any representation.
func etagMatch(ifNoneMatch []string, etag string) bool {
	current, currentOK := parseEntityTag(etag)
	for _, line := range ifNoneMatch {
		for _, member := range splitETagList(line) {
			if member == "*" {
				return true
			}
			if tag, ok := parseEntityTag(member); ok && currentOK && tag == current {
				return true
			}
		}
	}
	return false
}

// splitETagList splits a header line on commas that are outside quotes. It
// trims optional whitespace from each member and drops empty members.
func splitETagList(line string) []string {
	var members []string
	inQuotes := false
	start := 0
	for i := 0; i <= len(line); i++ {
		if i == len(line) || (line[i] == ',' && !inQuotes) {
			if member := strings.Trim(line[start:i], " \t"); member != "" {
				members = append(members, member)
			}
			start = i + 1
		} else if line[i] == '"' {
			inQuotes = !inQuotes
		}
	}
	return members
}

// parseEntityTag returns the opaque-tag of an entity-tag, without its weakness
// prefix or quotes. It reports false if s is not a well-formed entity-tag.
func parseEntityTag(s string) (string, bool) {
	s = strings.TrimPrefix(s, "W/")
	if len(s) < 2 || s[0] != '"' || s[len(s)-1] != '"' {
		return "", false
	}
	opaque := s[1 : len(s)-1]
	for i := 0; i < len(opaque); i++ {
		c := opaque[i]
		if c != 0x21 && (c < 0x23 || c > 0x7e) && c < 0x80 {
			return "", false
		}
	}
	return opaque, true
}

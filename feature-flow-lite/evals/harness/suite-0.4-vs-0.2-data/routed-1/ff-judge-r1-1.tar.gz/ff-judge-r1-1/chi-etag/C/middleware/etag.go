package middleware

import (
	"bufio"
	"bytes"
	"crypto/sha256"
	"encoding/hex"
	"errors"
	"net"
	"net/http"
	"strconv"
	"strings"
)

// ETag is middleware that adds a strong, body-derived ETag to 200 responses of
// GET and HEAD requests, and answers 304 Not Modified when the request's
// If-None-Match matches the response's ETag.
//
// The response is buffered until the handler returns, so the whole body is held
// in memory. If the handler did not set an ETag header, the ETag is the SHA-256
// of the body in hex, in double quotes. A HEAD response without body bytes gets
// no ETag, so it does not disagree with GET. If-None-Match uses the weak
// comparison of RFC 9110 section 13.1.2, and "*" matches any 200 response. A 304
// keeps the handler's headers but drops Content-Type, Content-Length,
// Content-Encoding and, when an ETag is present, Last-Modified.
//
// Calling Flush sends the buffered response and gives up on the ETag for it, so
// later writes stream directly. A successful Hijack ends the response without an
// ETag. ETag should be placed before Compress in the chain (r.Use(ETag) ahead of
// r.Use(Compress)), so the tag is computed from the encoded body and differs per
// Content-Encoding. ETag should not be combined with NoCache, which strips
// If-None-Match from requests. Requests with other methods pass through unchanged.
func ETag(next http.Handler) http.Handler {
	fn := func(w http.ResponseWriter, r *http.Request) {
		if r.Method != http.MethodGet && r.Method != http.MethodHead {
			next.ServeHTTP(w, r)
			return
		}

		ew := &etagResponseWriter{ResponseWriter: w, status: http.StatusOK}
		next.ServeHTTP(ew, r)
		if !ew.flushed && !ew.hijacked {
			ew.finish(r)
		}
	}

	return http.HandlerFunc(fn)
}

type etagResponseWriter struct {
	http.ResponseWriter

	buf         bytes.Buffer
	status      int
	wroteHeader bool
	flushed     bool
	hijacked    bool
}

func (ew *etagResponseWriter) WriteHeader(code int) {
	// Informational responses are sent right away and do not end the response.
	// 101 Switching Protocols is final, as in net/http.
	if code >= 100 && code < 200 && code != http.StatusSwitchingProtocols {
		ew.ResponseWriter.WriteHeader(code)
		return
	}
	if ew.wroteHeader {
		return
	}
	ew.wroteHeader = true
	ew.status = code
}

func (ew *etagResponseWriter) Write(p []byte) (int, error) {
	if !ew.wroteHeader {
		ew.WriteHeader(http.StatusOK)
	}
	if ew.flushed {
		return ew.ResponseWriter.Write(p)
	}
	return ew.buf.Write(p)
}

// Flush sends the buffered response, since it can no longer be buffered, and
// gives up on the ETag for it.
func (ew *etagResponseWriter) Flush() {
	if ew.hijacked {
		return
	}
	if !ew.flushed {
		ew.flushed = true
		ew.wroteHeader = true
		ew.ResponseWriter.WriteHeader(ew.status)
		ew.ResponseWriter.Write(ew.buf.Bytes())
		ew.buf.Reset()
	}
	if f, ok := ew.ResponseWriter.(http.Flusher); ok {
		f.Flush()
	}
}

func (ew *etagResponseWriter) Hijack() (net.Conn, *bufio.ReadWriter, error) {
	if hj, ok := ew.ResponseWriter.(http.Hijacker); ok {
		conn, rw, err := hj.Hijack()
		ew.hijacked = err == nil
		return conn, rw, err
	}
	return nil, nil, errors.New("chi/middleware: http.Hijacker is unavailable on the writer")
}

func (ew *etagResponseWriter) Push(target string, opts *http.PushOptions) error {
	if ps, ok := ew.ResponseWriter.(http.Pusher); ok {
		return ps.Push(target, opts)
	}
	return errors.New("chi/middleware: http.Pusher is unavailable on the writer")
}

func (ew *etagResponseWriter) Unwrap() http.ResponseWriter {
	return ew.ResponseWriter
}

// finish sends the buffered response, adding an ETag to a 200 and answering
// 304 when the request's If-None-Match matches it.
func (ew *etagResponseWriter) finish(r *http.Request) {
	h := ew.Header()
	body := ew.buf.Bytes()
	if ew.status == http.StatusOK {
		if h.Get("ETag") == "" && (r.Method == http.MethodGet || len(body) > 0) {
			h.Set("ETag", bodyETag(body))
		}
		if noneMatch(r.Header.Values("If-None-Match"), h.Get("ETag")) {
			writeNotModified(ew.ResponseWriter)
			return
		}
		if r.Method == http.MethodGet && h.Get("Content-Length") == "" {
			h.Set("Content-Length", strconv.Itoa(len(body)))
		}
	}

	ew.ResponseWriter.WriteHeader(ew.status)
	ew.ResponseWriter.Write(body)
}

// bodyETag returns the strong ETag for a response body: its SHA-256 in hex,
// in double quotes.
func bodyETag(body []byte) string {
	sum := sha256.Sum256(body)
	return `"` + hex.EncodeToString(sum[:]) + `"`
}

// writeNotModified writes a 304 that keeps the handler's headers, minus the
// ones that describe a body, as net/http's ServeContent does.
func writeNotModified(w http.ResponseWriter) {
	h := w.Header()
	h.Del("Content-Type")
	h.Del("Content-Length")
	h.Del("Content-Encoding")
	if h.Get("ETag") != "" {
		h.Del("Last-Modified")
	}
	w.WriteHeader(http.StatusNotModified)
}

// noneMatch reports whether an entity-tag in the If-None-Match header values
// weakly matches etag, or whether the header contains "*". An etag that is not
// a valid entity-tag matches no tag.
func noneMatch(values []string, etag string) bool {
	want, _ := opaqueTag(etag) // want is "" when etag is invalid, which matches no tag
	for _, v := range values {
		for _, member := range splitETagList(v) {
			if member == "*" {
				return true
			}
			if got, ok := opaqueTag(member); ok && got == want {
				return true
			}
		}
	}
	return false
}

// splitETagList splits an If-None-Match value into its list members, trimming
// spaces and tabs from each. A member that starts with a quote or W/" runs to
// the comma after its closing quote, so a comma inside the entity-tag is part of
// it. Other members run to the next comma. A member that is not a valid
// entity-tag is left for noneMatch to reject.
func splitETagList(v string) []string {
	var members []string
	for {
		v = strings.TrimLeft(v, " \t")
		end := memberEnd(v)
		members = append(members, strings.TrimRight(v[:end], " \t"))
		if end == len(v) {
			return members
		}
		v = v[end+1:]
	}
}

// memberEnd returns the index of the comma that ends the list member at the
// start of v, or len(v) if the member runs to the end of v. An unterminated
// quoted entity-tag runs to the end of v.
func memberEnd(v string) int {
	from := 0
	if strings.HasPrefix(v, `"`) || strings.HasPrefix(v, `W/"`) {
		open := strings.IndexByte(v, '"')
		closing := strings.IndexByte(v[open+1:], '"')
		if closing < 0 {
			return len(v)
		}
		from = open + 1 + closing + 1
	}
	if i := strings.IndexByte(v[from:], ','); i >= 0 {
		return from + i
	}
	return len(v)
}

// opaqueTag returns the opaque-tag of an entity-tag, which is the entity-tag
// without its W/ weakness prefix. It reports false if s is not a valid
// entity-tag.
func opaqueTag(s string) (string, bool) {
	tag := strings.TrimPrefix(s, "W/")
	if len(tag) < 2 || tag[0] != '"' || tag[len(tag)-1] != '"' {
		return "", false
	}
	for i := 1; i < len(tag)-1; i++ {
		if c := tag[i]; c < 0x21 || c == '"' || c == 0x7f {
			return "", false
		}
	}
	return tag, true
}

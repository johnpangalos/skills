package middleware

import (
	"bufio"
	"bytes"
	"crypto/sha256"
	"encoding/hex"
	"errors"
	"net"
	"net/http"
	"strings"
)

// ETag adds a strong ETag to successful GET and HEAD responses and answers
// requests whose If-None-Match matches the ETag with 304 Not Modified.
//
// The response is buffered until the handler returns so the ETag can be
// computed from the full body. Only 200 responses get a computed ETag or a
// 304. Other statuses and other methods are passed through unchanged, and an
// ETag set by the handler is never replaced. A HEAD response that writes no
// body gets no computed ETag. Informational 1xx responses are sent as soon as
// they are written.
//
// Calling Flush, or a successful Hijack, stops buffering: the response is
// streamed as it is written, so it gets no computed ETag and no 304. After
// Hijack, writes return http.ErrHijacked from the underlying writer and
// nothing more is sent.
func ETag(next http.Handler) http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		if r.Method != http.MethodGet && r.Method != http.MethodHead {
			next.ServeHTTP(w, r)
			return
		}
		ew := &etagResponseWriter{ResponseWriter: w, req: r}
		next.ServeHTTP(ew, r)
		ew.finish()
	})
}

type etagResponseWriter struct {
	http.ResponseWriter

	req         *http.Request
	body        bytes.Buffer
	code        int
	wroteHeader bool
	streaming   bool
}

func (w *etagResponseWriter) WriteHeader(code int) {
	if w.wroteHeader {
		return // the first final status wins
	}
	if code >= 100 && code <= 199 && code != http.StatusSwitchingProtocols {
		w.ResponseWriter.WriteHeader(code)
		return
	}
	w.wroteHeader = true
	w.code = code
}

func (w *etagResponseWriter) Write(p []byte) (int, error) {
	w.WriteHeader(http.StatusOK)
	if w.streaming {
		return w.ResponseWriter.Write(p)
	}
	return w.body.Write(p)
}

func (w *etagResponseWriter) Flush() {
	w.commit()
	if f, ok := w.ResponseWriter.(http.Flusher); ok {
		f.Flush()
	}
}

func (w *etagResponseWriter) Hijack() (net.Conn, *bufio.ReadWriter, error) {
	hj, ok := w.ResponseWriter.(http.Hijacker)
	if !ok {
		return nil, nil, errors.New("chi/middleware: http.Hijacker is unavailable on the writer")
	}
	if w.wroteHeader {
		w.commit()
	}
	conn, rw, err := hj.Hijack()
	if err == nil {
		// The connection is no longer HTTP, so finish and commit must not
		// write to it. Setting streaming makes both no-ops.
		w.streaming = true
	}
	return conn, rw, err
}

func (w *etagResponseWriter) Push(target string, opts *http.PushOptions) error {
	if ps, ok := w.ResponseWriter.(http.Pusher); ok {
		return ps.Push(target, opts)
	}
	return errors.New("chi/middleware: http.Pusher is unavailable on the writer")
}

func (w *etagResponseWriter) Unwrap() http.ResponseWriter {
	return w.ResponseWriter
}

// finish runs when the handler returns and sends the response, unless it was
// already streamed.
func (w *etagResponseWriter) finish() {
	if w.streaming {
		return
	}
	w.WriteHeader(http.StatusOK)
	if w.code == http.StatusOK {
		w.setETag()
		if ifNoneMatch(w.req.Header.Values("If-None-Match"), w.Header().Get("ETag")) {
			// Send a 304 without the body and representation headers, as
			// net/http's ServeContent does.
			h := w.Header()
			h.Del("Content-Type")
			h.Del("Content-Length")
			h.Del("Content-Encoding")
			w.ResponseWriter.WriteHeader(http.StatusNotModified)
			return
		}
	}
	w.commit()
}

// commit sends the pending status, headers and buffered body, and stops
// buffering.
func (w *etagResponseWriter) commit() {
	if w.streaming {
		return
	}
	w.WriteHeader(http.StatusOK)
	w.streaming = true
	w.ResponseWriter.WriteHeader(w.code)
	if w.body.Len() > 0 {
		w.ResponseWriter.Write(w.body.Bytes())
	}
}

// setETag gives the response a strong ETag computed from its body, unless the
// handler already set one. On HEAD with no body written, the body is unknown,
// so no ETag is set.
func (w *etagResponseWriter) setETag() {
	if len(w.Header().Values("ETag")) > 0 {
		return
	}
	if w.req.Method == http.MethodHead && w.body.Len() == 0 {
		return
	}
	sum := sha256.Sum256(w.body.Bytes())
	w.Header().Set("ETag", `"`+hex.EncodeToString(sum[:])+`"`)
}

// ifNoneMatch reports whether any If-None-Match header line matches etag.
func ifNoneMatch(lines []string, etag string) bool {
	for _, line := range lines {
		if listMatches(line, etag) {
			return true
		}
	}
	return false
}

// listMatches reports whether the comma-separated entity-tags in list match
// etag, or whether list is "*". Scanning stops at the first malformed member.
func listMatches(list, etag string) bool {
	rest := strings.Trim(list, " \t")
	if rest == "*" {
		return true
	}
	for rest != "" {
		if rest[0] == ',' { // empty list elements are allowed (RFC 9110 §5.6.1)
			rest = strings.Trim(rest[1:], " \t")
			continue
		}
		tag, after := scanETag(rest)
		if tag == "" {
			return false
		}
		if weakMatch(tag, etag) {
			return true
		}
		rest = strings.Trim(after, " \t")
		if rest != "" && rest[0] != ',' {
			return false
		}
	}
	return false
}

// scanETag returns the entity-tag at the start of s and the text after it, or
// an empty tag if s does not start with a well-formed one. A quoted
// opaque-tag may contain commas, so it is scanned rather than split.
func scanETag(s string) (tag, rest string) {
	start := 0
	if strings.HasPrefix(s, "W/") {
		start = 2
	}
	if len(s) < start+2 || s[start] != '"' {
		return "", ""
	}
	for i := start + 1; i < len(s); i++ {
		c := s[i]
		switch {
		case c == 0x21 || c >= 0x23 && c <= 0x7E || c >= 0x80: // etagc
		case c == '"':
			return s[:i+1], s[i+1:]
		default:
			return "", ""
		}
	}
	return "", ""
}

// weakMatch reports whether tag and etag match under weak comparison: the W/
// prefixes are ignored and the opaque-tags must be identical. A malformed etag
// never matches.
func weakMatch(tag, etag string) bool {
	if t, rest := scanETag(etag); t == "" || rest != "" {
		return false
	}
	return strings.TrimPrefix(tag, "W/") == strings.TrimPrefix(etag, "W/")
}

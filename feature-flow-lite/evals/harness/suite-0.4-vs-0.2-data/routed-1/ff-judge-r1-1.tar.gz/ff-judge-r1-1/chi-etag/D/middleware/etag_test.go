package middleware

import (
	"bufio"
	"crypto/sha256"
	"encoding/hex"
	"fmt"
	"io"
	"maps"
	"net"
	"net/http"
	"net/http/httptest"
	"reflect"
	"strings"
	"testing"
	"time"
)

func etagDigest(body string) string {
	sum := sha256.Sum256([]byte(body))
	return `"` + hex.EncodeToString(sum[:]) + `"`
}

// serveETag runs a request with the given method and headers through ETag(h).
func serveETag(w http.ResponseWriter, h http.Handler, method string, header http.Header) {
	req := httptest.NewRequest(method, "/", http.NoBody)
	maps.Copy(req.Header, header)
	ETag(h).ServeHTTP(w, req)
}

func etagRequest(t *testing.T, ts *httptest.Server, method string, header http.Header) (*http.Response, string) {
	t.Helper()
	req, err := http.NewRequest(method, ts.URL, http.NoBody)
	if err != nil {
		t.Fatal(err)
	}
	maps.Copy(req.Header, header)

	resp, err := http.DefaultClient.Do(req)
	if err != nil {
		t.Fatal(err)
	}
	defer resp.Body.Close()

	respBody, err := io.ReadAll(resp.Body)
	if err != nil {
		t.Fatal(err)
	}
	return resp, string(respBody)
}

// informationalRecorder records 1xx status codes separately from the final response.
type informationalRecorder struct {
	*httptest.ResponseRecorder
	informational []int
	linkAtInfo    string
}

func (rw *informationalRecorder) WriteHeader(code int) {
	if code >= 100 && code < 200 && code != http.StatusSwitchingProtocols {
		rw.informational = append(rw.informational, code)
		rw.linkAtInfo = rw.Header().Get("Link")
		return
	}
	rw.ResponseRecorder.WriteHeader(code)
}

func TestETagComputesStrongDigest(t *testing.T) {
	hello := http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		w.Write([]byte("hello"))
	})
	rec := httptest.NewRecorder()
	serveETag(rec, hello, http.MethodGet, nil)

	if rec.Code != http.StatusOK {
		t.Fatalf("status: got %d, want %d", rec.Code, http.StatusOK)
	}
	if got, want := rec.Header().Get("ETag"), etagDigest("hello"); got != want {
		t.Fatalf("ETag: got %q, want %q", got, want)
	}

	again := httptest.NewRecorder()
	serveETag(again, hello, http.MethodGet, nil)
	if again.Header().Get("ETag") != rec.Header().Get("ETag") {
		t.Fatal("same body produced different ETags")
	}

	other := httptest.NewRecorder()
	serveETag(other, http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		w.Write([]byte("world"))
	}), http.MethodGet, nil)
	if other.Header().Get("ETag") == rec.Header().Get("ETag") {
		t.Fatal("different body produced the same ETag")
	}
}

func TestETagEmptyBodyIs200(t *testing.T) {
	rec := httptest.NewRecorder()
	serveETag(rec, http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {}), http.MethodGet, nil)

	if rec.Code != http.StatusOK {
		t.Fatalf("status: got %d, want %d", rec.Code, http.StatusOK)
	}
	if got, want := rec.Header().Get("ETag"), etagDigest(""); got != want {
		t.Fatalf("ETag: got %q, want %q", got, want)
	}
	if rec.Body.Len() != 0 {
		t.Fatalf("body: got %q, want empty", rec.Body.String())
	}
}

func TestETagKeepsHandlerSetETag(t *testing.T) {
	for _, etag := range []string{`W/"x"`, `"x"`} {
		rec := httptest.NewRecorder()
		serveETag(rec, http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
			w.Header().Set("ETag", etag)
			w.Write([]byte("body"))
		}), http.MethodGet, nil)

		if got := rec.Header().Get("ETag"); got != etag {
			t.Fatalf("ETag: got %q, want %q", got, etag)
		}
	}
}

func TestETagKeepsHandlerSetEmptyETag(t *testing.T) {
	rec := httptest.NewRecorder()
	serveETag(rec, http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		w.Header().Set("ETag", "")
		w.Write([]byte("body"))
	}), http.MethodGet, nil)

	vals, ok := rec.Header()["Etag"]
	if !ok || !reflect.DeepEqual(vals, []string{""}) {
		t.Fatalf("ETag header: got %q (present=%v), want one empty value", vals, ok)
	}
}

// deadlineRecorder accepts write deadlines, as the server's own writer does.
type deadlineRecorder struct {
	*httptest.ResponseRecorder
	deadline time.Time
}

func (rw *deadlineRecorder) SetWriteDeadline(deadline time.Time) error {
	rw.deadline = deadline
	return nil
}

func TestETagBuffersUntilHandlerReturns(t *testing.T) {
	rec := &deadlineRecorder{ResponseRecorder: httptest.NewRecorder()}
	var bodyDuringHandler int
	var flushErr, deadlineErr error
	deadline := time.Now().Add(time.Minute)
	serveETag(rec, http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		w.Write([]byte("partial"))
		w.(http.Flusher).Flush()
		flushErr = http.NewResponseController(w).Flush()
		deadlineErr = http.NewResponseController(w).SetWriteDeadline(deadline)
		bodyDuringHandler = rec.Body.Len()
	}), http.MethodGet, nil)

	if bodyDuringHandler != 0 || rec.Flushed {
		t.Fatalf("data reached the client before the handler returned: body=%d flushed=%v", bodyDuringHandler, rec.Flushed)
	}
	if flushErr != nil {
		t.Fatalf("ResponseController.Flush: got %v, want nil", flushErr)
	}
	if deadlineErr != nil {
		t.Fatalf("ResponseController.SetWriteDeadline: got %v, want nil", deadlineErr)
	}
	if !rec.deadline.Equal(deadline) {
		t.Fatalf("write deadline: got %v, want %v", rec.deadline, deadline)
	}
	if rec.Body.String() != "partial" {
		t.Fatalf("body: got %q, want %q", rec.Body.String(), "partial")
	}
}

func TestETagSnapshotsHeaders(t *testing.T) {
	rec := httptest.NewRecorder()
	serveETag(rec, http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		w.Header().Set("X-Before", "1")
		w.WriteHeader(http.StatusCreated)
		w.Header().Set("X-After", "1")
		w.WriteHeader(http.StatusInternalServerError)
		w.Write([]byte("made"))
	}), http.MethodGet, nil)

	if rec.Code != http.StatusCreated {
		t.Fatalf("status: got %d, want %d (first WriteHeader wins)", rec.Code, http.StatusCreated)
	}
	if rec.Header().Get("X-Before") != "1" || rec.Header().Get("X-After") != "" {
		t.Fatalf("headers: got X-Before=%q X-After=%q", rec.Header().Get("X-Before"), rec.Header().Get("X-After"))
	}

	late := httptest.NewRecorder()
	serveETag(late, http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		w.Write([]byte("a"))
		w.Header().Set("X-Late", "1")
	}), http.MethodGet, nil)

	if late.Header().Get("X-Late") != "" {
		t.Fatal("header changed after the first Write was sent")
	}
}

func TestETagKeepsOuterHeaders(t *testing.T) {
	outer := func(next http.Handler) http.Handler {
		return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
			w.Header().Set("X-Outer", "1")
			next.ServeHTTP(w, r)
		})
	}
	rec := httptest.NewRecorder()
	outer(ETag(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		w.Write([]byte("x"))
	}))).ServeHTTP(rec, httptest.NewRequest(http.MethodGet, "/", http.NoBody))

	if rec.Header().Get("X-Outer") != "1" {
		t.Fatal("header set by an outer middleware was lost")
	}
	if rec.Header().Get("ETag") != etagDigest("x") {
		t.Fatalf("ETag: got %q, want %q", rec.Header().Get("ETag"), etagDigest("x"))
	}
}

func TestETagIfNoneMatch(t *testing.T) {
	computed := etagDigest("body")
	tests := []struct {
		name string
		etag string // ETag set by the handler; the digest is used when empty
		inm  []string
		want int
	}{
		{"computed tag matches", "", []string{computed}, http.StatusNotModified},
		{"weak request matches strong", `"a"`, []string{`W/"a"`}, http.StatusNotModified},
		{"strong request matches weak", `W/"a"`, []string{`"a"`}, http.StatusNotModified},
		{"weak on both sides", `W/"a"`, []string{`W/"a"`}, http.StatusNotModified},
		{"list with whitespace", `"b"`, []string{`"a" , W/"b"`}, http.StatusNotModified},
		{"leading whitespace", `"b"`, []string{`  "b"`}, http.StatusNotModified},
		{"empty members", `"a"`, []string{`,,"a"`}, http.StatusNotModified},
		{"multiple header lines", `"a"`, []string{`"x"`, `"a"`}, http.StatusNotModified},
		{"star matches handler tag", `"a"`, []string{"*"}, http.StatusNotModified},
		{"star matches computed tag", "", []string{"*"}, http.StatusNotModified},
		{"prefix is not a match", `"a"`, []string{`"ab"`}, http.StatusOK},
		{"different tag", `"a"`, []string{`"b"`}, http.StatusOK},
		{"no member matches", `"c"`, []string{`"a" , W/"b"`}, http.StatusOK},
		{"unquoted member", `"a"`, []string{`a`}, http.StatusOK},
		{"bare weak prefix", `"a"`, []string{`W/`}, http.StatusOK},
		{"unterminated quote", `"a"`, []string{`"unterminated`}, http.StatusOK},
		{"unterminated before a valid tag", `"a"`, []string{`"unterminated, "a"`}, http.StatusOK},
		{"empty quoted tag", `"a"`, []string{`""`}, http.StatusOK},
		{"no If-None-Match", "", nil, http.StatusOK},
	}

	for _, tc := range tests {
		t.Run(tc.name, func(t *testing.T) {
			h := http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
				if tc.etag != "" {
					w.Header().Set("ETag", tc.etag)
				}
				w.Write([]byte("body"))
			})
			rec := httptest.NewRecorder()
			serveETag(rec, h, http.MethodGet, http.Header{"If-None-Match": tc.inm})

			if rec.Code != tc.want {
				t.Fatalf("status: got %d, want %d", rec.Code, tc.want)
			}
			if tc.want == http.StatusNotModified && rec.Body.Len() != 0 {
				t.Fatalf("304 body: got %q, want empty", rec.Body.String())
			}
		})
	}
}

func TestETagEmptyHandlerETagOnlyMatchesStar(t *testing.T) {
	tests := []struct {
		inm  string
		want int
	}{
		{`""`, http.StatusOK},
		{`*`, http.StatusNotModified},
	}
	for _, tc := range tests {
		rec := httptest.NewRecorder()
		serveETag(rec, http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
			w.Header()["ETag"] = []string{""}
			w.Write([]byte("body"))
		}), http.MethodGet, http.Header{"If-None-Match": {tc.inm}})

		if rec.Code != tc.want {
			t.Fatalf("If-None-Match %q: status got %d, want %d", tc.inm, rec.Code, tc.want)
		}
	}
}

func TestETagNotModifiedKeepsValidatorHeaders(t *testing.T) {
	rec := httptest.NewRecorder()
	serveETag(rec, http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		w.Header().Set("Cache-Control", "max-age=60")
		w.Header().Set("Content-Location", "/v2")
		w.Header().Set("Expires", "Wed, 21 Oct 2037 07:28:00 GMT")
		w.Header().Set("Vary", "Accept-Encoding")
		w.Header().Set("Content-Type", "text/plain")
		w.Header().Set("Content-Length", "4")
		w.Write([]byte("body"))
	}), http.MethodGet, http.Header{"If-None-Match": {etagDigest("body")}})

	if rec.Code != http.StatusNotModified {
		t.Fatalf("status: got %d, want %d", rec.Code, http.StatusNotModified)
	}
	for _, name := range []string{"Cache-Control", "Content-Location", "Expires", "Vary", "ETag"} {
		if rec.Header().Get(name) == "" {
			t.Errorf("304 is missing %s", name)
		}
	}
	for _, name := range []string{"Content-Length", "Content-Type"} {
		if vals, ok := rec.Header()[name]; ok {
			t.Errorf("304 still has %s: %q", name, vals)
		}
	}
	if rec.Body.Len() != 0 {
		t.Fatalf("304 body: got %q, want empty", rec.Body.String())
	}
}

func TestETagPassesThroughOtherMethods(t *testing.T) {
	for _, method := range []string{http.MethodPost, http.MethodPut, http.MethodDelete, http.MethodOptions, http.MethodPatch} {
		rec := httptest.NewRecorder()
		var got http.ResponseWriter
		serveETag(rec, http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
			got = w
			w.Write([]byte("ok"))
		}), method, http.Header{"If-None-Match": {"*"}})

		if got != http.ResponseWriter(rec) {
			t.Fatalf("%s: next handler did not receive the original ResponseWriter", method)
		}
		if rec.Code != http.StatusOK || rec.Body.String() != "ok" {
			t.Fatalf("%s: got %d %q, want 200 \"ok\"", method, rec.Code, rec.Body.String())
		}
		if _, ok := rec.Header()["Etag"]; ok {
			t.Fatalf("%s: ETag was added", method)
		}
	}
}

func TestETagPassesThroughNon200Unchanged(t *testing.T) {
	for _, status := range []int{201, 204, 206, 301, 304, 404, 500} {
		h := http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
			w.Header().Set("Content-Type", "text/plain")
			w.Header().Set("Cache-Control", "no-store")
			w.WriteHeader(status)
			w.Write([]byte("body"))
		})

		want := httptest.NewRecorder()
		h.ServeHTTP(want, httptest.NewRequest(http.MethodGet, "/", http.NoBody))

		got := httptest.NewRecorder()
		serveETag(got, h, http.MethodGet, http.Header{"If-None-Match": {"*"}})

		if got.Code != want.Code || got.Body.String() != want.Body.String() {
			t.Fatalf("status %d: got %d %q, want %d %q", status, got.Code, got.Body.String(), want.Code, want.Body.String())
		}
		if !reflect.DeepEqual(got.Header(), want.Header()) {
			t.Fatalf("status %d: headers got %v, want %v", status, got.Header(), want.Header())
		}
	}
}

func TestETagForwardsInformationalResponses(t *testing.T) {
	rec := &informationalRecorder{ResponseRecorder: httptest.NewRecorder()}
	serveETag(rec, http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		w.Header().Set("Link", "</style.css>; rel=preload")
		w.WriteHeader(http.StatusEarlyHints)
		w.Write([]byte("body"))
	}), http.MethodGet, nil)

	if !reflect.DeepEqual(rec.informational, []int{http.StatusEarlyHints}) {
		t.Fatalf("informational codes: got %v, want [103]", rec.informational)
	}
	if rec.linkAtInfo != "</style.css>; rel=preload" {
		t.Fatalf("Link on 103: got %q", rec.linkAtInfo)
	}
	if rec.Code != http.StatusOK {
		t.Fatalf("final status: got %d, want 200", rec.Code)
	}
	if got, want := rec.Header().Get("ETag"), etagDigest("body"); got != want {
		t.Fatalf("ETag: got %q, want %q", got, want)
	}
}

func TestETagHeadReplay(t *testing.T) {
	ts := httptest.NewServer(ETag(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		w.Header().Set("Cache-Control", "max-age=60")
		w.Write([]byte("hello"))
	})))
	defer ts.Close()

	getResp, getBody := etagRequest(t, ts, http.MethodGet, nil)
	if getBody != "hello" {
		t.Fatalf("GET body: got %q, want %q", getBody, "hello")
	}
	getETag := getResp.Header.Get("ETag")
	if getETag != etagDigest("hello") {
		t.Fatalf("GET ETag: got %q, want %q", getETag, etagDigest("hello"))
	}

	headResp, headBody := etagRequest(t, ts, http.MethodHead, nil)
	if headBody != "" {
		t.Fatalf("HEAD body: got %q, want empty", headBody)
	}
	if headResp.Header.Get("ETag") != getETag {
		t.Fatalf("HEAD ETag: got %q, want %q", headResp.Header.Get("ETag"), getETag)
	}
	if headResp.ContentLength != int64(len("hello")) {
		t.Fatalf("HEAD Content-Length: got %d, want %d", headResp.ContentLength, len("hello"))
	}

	notModified, notModifiedBody := etagRequest(t, ts, http.MethodHead, http.Header{"If-None-Match": {getETag}})
	if notModified.StatusCode != http.StatusNotModified || notModifiedBody != "" {
		t.Fatalf("HEAD conditional: got %d %q, want 304 empty", notModified.StatusCode, notModifiedBody)
	}
	if notModified.Header.Get("Content-Length") != "" {
		t.Fatalf("304 Content-Length: got %q, want none", notModified.Header.Get("Content-Length"))
	}
}

func TestETagHeadWithoutBody(t *testing.T) {
	rec := httptest.NewRecorder()
	serveETag(rec, http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {}), http.MethodHead, nil)

	if vals, ok := rec.Header()["Etag"]; ok {
		t.Fatalf("HEAD ETag: got %q, want none", vals)
	}
}

func TestETagHeadServeContentHasNoComputedETag(t *testing.T) {
	content := http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		http.ServeContent(w, r, "a.txt", time.Time{}, strings.NewReader("hello"))
	})

	get := httptest.NewRecorder()
	serveETag(get, content, http.MethodGet, nil)
	if got, want := get.Header().Get("ETag"), etagDigest("hello"); got != want {
		t.Fatalf("GET ETag: got %q, want %q", got, want)
	}

	head := httptest.NewRecorder()
	serveETag(head, content, http.MethodHead, nil)
	if vals, ok := head.Header()["Etag"]; ok {
		t.Fatalf("HEAD ETag: got %q, want none", vals)
	}
}

func TestETagHeadEmptyBodyMatchesHandlerETag(t *testing.T) {
	rec := httptest.NewRecorder()
	serveETag(rec, http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		w.Header().Set("ETag", `"v1"`)
		w.WriteHeader(http.StatusOK)
	}), http.MethodHead, http.Header{"If-None-Match": {`"v1"`}})

	if rec.Code != http.StatusNotModified {
		t.Fatalf("status: got %d, want %d", rec.Code, http.StatusNotModified)
	}
}

func TestETagIgnoresInformationalAfterFinalStatus(t *testing.T) {
	rec := &informationalRecorder{ResponseRecorder: httptest.NewRecorder()}
	serveETag(rec, http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		w.WriteHeader(http.StatusOK)
		w.WriteHeader(http.StatusEarlyHints)
		w.Write([]byte("body"))
	}), http.MethodGet, nil)

	if len(rec.informational) != 0 {
		t.Fatalf("informational codes after the final status: got %v, want none", rec.informational)
	}
	if rec.Code != http.StatusOK {
		t.Fatalf("status: got %d, want 200", rec.Code)
	}
}

func TestETagTreats101AsFinalStatus(t *testing.T) {
	rec := &informationalRecorder{ResponseRecorder: httptest.NewRecorder()}
	serveETag(rec, http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		w.WriteHeader(http.StatusSwitchingProtocols)
	}), http.MethodGet, nil)

	if len(rec.informational) != 0 {
		t.Fatalf("101 was forwarded as informational: got %v, want none", rec.informational)
	}
	if rec.Code != http.StatusSwitchingProtocols {
		t.Fatalf("status: got %d, want 101", rec.Code)
	}
}

func TestETagHijackWithoutHijackerFails(t *testing.T) {
	var hijackErr error
	rec := httptest.NewRecorder()
	serveETag(rec, http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		_, _, hijackErr = w.(http.Hijacker).Hijack()
	}), http.MethodGet, nil)

	const want = "chi/middleware: http.Hijacker is unavailable on the writer"
	if hijackErr == nil || hijackErr.Error() != want {
		t.Fatalf("Hijack error: got %v, want %q", hijackErr, want)
	}
}

func TestETagForwardsHijackForUpgrade(t *testing.T) {
	ts := httptest.NewServer(ETag(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		w.Header().Set("ETag", `"unused"`)
		conn, rw, err := http.NewResponseController(w).Hijack()
		if err != nil {
			t.Errorf("Hijack: %v", err)
			return
		}
		defer conn.Close()
		rw.WriteString("HTTP/1.1 101 Switching Protocols\r\nUpgrade: test\r\nConnection: Upgrade\r\n\r\nping")
		rw.Flush()
	})))
	defer ts.Close()

	conn, err := net.Dial("tcp", ts.Listener.Addr().String())
	if err != nil {
		t.Fatal(err)
	}
	defer conn.Close()
	conn.SetDeadline(time.Now().Add(5 * time.Second))

	fmt.Fprint(conn, "GET / HTTP/1.1\r\nHost: example\r\nUpgrade: test\r\nConnection: Upgrade\r\n\r\n")
	br := bufio.NewReader(conn)
	resp, err := http.ReadResponse(br, nil)
	if err != nil {
		t.Fatal(err)
	}
	if resp.StatusCode != http.StatusSwitchingProtocols {
		t.Fatalf("status: got %d, want 101", resp.StatusCode)
	}

	// The handler closes the connection after the upgrade, so anything the
	// middleware replayed would show up here before EOF.
	rest, err := io.ReadAll(br)
	if err != nil {
		t.Fatal(err)
	}
	if string(rest) != "ping" {
		t.Fatalf("bytes after 101: got %q, want %q", rest, "ping")
	}
}

func TestETagReplaysTrailers(t *testing.T) {
	ts := httptest.NewServer(ETag(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		w.Header().Set("Trailer", "X-Sum")
		w.Write([]byte("hello"))
		w.Header().Set("X-Sum", "abc")
		w.Header().Set(http.TrailerPrefix+"X-Late", "late")
	})))
	defer ts.Close()

	resp, _ := etagRequest(t, ts, http.MethodGet, nil)
	if got := resp.Trailer.Get("X-Sum"); got != "abc" {
		t.Fatalf("X-Sum trailer: got %q, want %q", got, "abc")
	}
	if got := resp.Trailer.Get("X-Late"); got != "late" {
		t.Fatalf("X-Late trailer: got %q, want %q", got, "late")
	}
}

// pusherRecorder records server pushes, as HTTP/2 writers do.
type pusherRecorder struct {
	*httptest.ResponseRecorder
	pushed []string
	method string
}

func (rw *pusherRecorder) Push(target string, opts *http.PushOptions) error {
	rw.pushed = append(rw.pushed, target)
	rw.method = opts.Method
	return nil
}

func TestETagForwardsPush(t *testing.T) {
	rec := &pusherRecorder{ResponseRecorder: httptest.NewRecorder()}
	var pushErr error
	serveETag(rec, http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		pushErr = w.(http.Pusher).Push("/style.css", &http.PushOptions{Method: http.MethodGet})
		w.Write([]byte("body"))
	}), http.MethodGet, nil)

	if pushErr != nil {
		t.Fatalf("Push: got %v, want nil", pushErr)
	}
	if !reflect.DeepEqual(rec.pushed, []string{"/style.css"}) || rec.method != http.MethodGet {
		t.Fatalf("pushed: got %v method %q, want [/style.css] GET", rec.pushed, rec.method)
	}
}

func TestETagPushWithoutPusherFails(t *testing.T) {
	var pushErr error
	rec := httptest.NewRecorder()
	serveETag(rec, http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		pushErr = w.(http.Pusher).Push("/style.css", nil)
		w.Write([]byte("body"))
	}), http.MethodGet, nil)

	const want = "chi/middleware: http.Pusher is unavailable on the writer"
	if pushErr == nil || pushErr.Error() != want {
		t.Fatalf("Push error: got %v, want %q", pushErr, want)
	}
}

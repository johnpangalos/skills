"""Thread-safe stock on hand, with reservations that hold units until settled."""

import threading
from dataclasses import dataclass

from shop import catalog


class OutOfStock(ValueError):
    pass


class ReservationError(ValueError):
    pass


@dataclass(frozen=True, eq=False)
class Reservation:
    """Units of one SKU held by an Inventory; compared by identity."""

    sku: str
    qty: int


def _check_sku(sku):
    try:
        catalog.PRODUCTS[sku]
    except (KeyError, TypeError):
        raise catalog.UnknownProduct(sku) from None


def _check_stock(count):
    if type(count) is not int or count < 0:
        raise ValueError("stock must be a non-negative int")


def _check_qty(qty):
    if type(qty) is not int or qty < 1:
        raise ValueError("qty must be a positive int")


class Inventory:
    """Units on hand per SKU, shared safely between threads."""

    def __init__(self, stock):
        """Copy the on-hand counts, each of which must be a non-negative int."""
        self._on_hand = dict(stock)
        for count in self._on_hand.values():
            _check_stock(count)
        self._lock = threading.Lock()
        self._open = {}  # Reservation -> (sku, qty) as recorded at reserve time

    def available(self, sku):
        """Return units on hand minus units held by open reservations."""
        _check_sku(sku)
        with self._lock:
            return self._available_locked(sku)

    def reserve(self, sku, qty):
        """Hold qty units of a SKU and return the Reservation."""
        _check_sku(sku)
        _check_qty(qty)
        with self._lock:
            free = self._available_locked(sku)
            if qty > free:
                raise OutOfStock(f"{sku}: requested {qty}, available {free}")
            reservation = Reservation(sku, qty)
            self._open[reservation] = (sku, qty)
            return reservation

    def commit(self, reservation):
        """Consume a reservation's units for good."""
        with self._lock:
            sku, qty = self._settle_locked(reservation)
            self._on_hand[sku] -= qty

    def release(self, reservation):
        """Return a reservation's units to availability."""
        with self._lock:
            self._settle_locked(reservation)

    def _available_locked(self, sku):
        held = sum(qty for held_sku, qty in self._open.values() if held_sku == sku)
        return self._on_hand.get(sku, 0) - held

    def _settle_locked(self, reservation):
        if not isinstance(reservation, Reservation) or reservation not in self._open:
            raise ReservationError("reservation is not open in this inventory")
        return self._open.pop(reservation)

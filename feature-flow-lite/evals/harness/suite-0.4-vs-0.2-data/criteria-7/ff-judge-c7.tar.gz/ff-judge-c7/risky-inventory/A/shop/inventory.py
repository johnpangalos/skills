"""Stock on hand, with holds for open reservations."""

import threading
from dataclasses import dataclass

from shop.catalog import UnknownProduct, lookup

__all__ = ["OutOfStock", "ReservationError", "Reservation", "Inventory", "UnknownProduct"]


class OutOfStock(ValueError):
    pass


class ReservationError(ValueError):
    pass


@dataclass(frozen=True, eq=False)
class Reservation:
    sku: str
    qty: int


def _is_int(value):
    return isinstance(value, int) and not isinstance(value, bool)


class Inventory:
    def __init__(self, stock):
        self._lock = threading.Lock()
        self._on_hand = {}
        for sku, units in stock.items():
            if not _is_int(units) or units < 0:
                raise ValueError(f"units for {sku!r} must be a non-negative int")
            self._on_hand[sku] = units
        # open (unsettled) reservations -> (sku, qty) as reserved; keyed by identity
        self._held = {}

    def _available(self, sku):
        # caller must hold self._lock
        held = sum(qty for held_sku, qty in self._held.values() if held_sku == sku)
        return self._on_hand.get(sku, 0) - held

    def _settle(self, reservation):
        # caller must hold self._lock
        if not isinstance(reservation, Reservation) or reservation not in self._held:
            raise ReservationError("reservation is not open in this inventory")
        return self._held.pop(reservation)

    def available(self, sku):
        lookup(sku)
        with self._lock:
            return self._available(sku)

    def reserve(self, sku, qty):
        lookup(sku)
        if not _is_int(qty) or qty < 1:
            raise ValueError("qty must be a positive int")
        with self._lock:
            available = self._available(sku)
            if available < qty:
                raise OutOfStock(f"{sku}: requested {qty}, available {available}")
            reservation = Reservation(sku, qty)
            self._held[reservation] = (sku, qty)
            return reservation

    def commit(self, reservation):
        with self._lock:
            sku, qty = self._settle(reservation)
            self._on_hand[sku] -= qty

    def release(self, reservation):
        with self._lock:
            self._settle(reservation)

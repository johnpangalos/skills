import threading
import unittest
from concurrent.futures import ThreadPoolExecutor
from dataclasses import FrozenInstanceError

from shop.catalog import UnknownProduct
from shop.inventory import Inventory, OutOfStock, Reservation, ReservationError


class Liar(int):
    """An int whose ordering comparisons always say False."""

    def __lt__(self, other):
        return False

    __gt__ = __le__ = __ge__ = __lt__


class InventoryTest(unittest.TestCase):
    def race(self, workers, action):
        """Run action(i) in workers threads released together; return outcomes."""
        barrier = threading.Barrier(workers)

        def run(i):
            barrier.wait()
            try:
                return action(i)
            except Exception as exc:  # the outcome is the exception itself
                return exc

        with ThreadPoolExecutor(max_workers=workers) as pool:
            return list(pool.map(run, range(workers)))

    def test_copies_stock_dict(self):
        stock = {"MUG": 2}
        inv = Inventory(stock)
        stock["MUG"] = 50
        stock["FILTER"] = 9
        self.assertEqual(inv.available("MUG"), 2)
        self.assertEqual(inv.available("FILTER"), 0)

    def test_empty_inventory_is_valid(self):
        self.assertEqual(Inventory({}).available("MUG"), 0)

    def test_rejects_unknown_sku_at_construction(self):
        with self.assertRaises(UnknownProduct):
            Inventory({"NOPE": 3})

    def test_rejects_negative_units(self):
        with self.assertRaises(ValueError) as cm:
            Inventory({"MUG": -1})
        self.assertIs(type(cm.exception), ValueError)
        self.assertEqual(str(cm.exception), "units on hand must be an int >= 0")

    def test_rejects_float_and_bool_units(self):
        for units in (2.5, True):
            with self.subTest(units=units):
                with self.assertRaises(ValueError):
                    Inventory({"MUG": units})

    def test_available_unknown_sku_raises_even_when_empty(self):
        with self.assertRaises(UnknownProduct):
            Inventory({}).available("NOPE")

    def test_catalog_sku_missing_from_stock_has_zero_available(self):
        self.assertEqual(Inventory({"MUG": 1}).available("FILTER"), 0)

    def test_available_subtracts_open_holds(self):
        inv = Inventory({"MUG": 5})
        inv.reserve("MUG", 2)
        self.assertEqual(inv.available("MUG"), 3)

    def test_reserve_unknown_sku_raises(self):
        with self.assertRaises(UnknownProduct):
            Inventory({"MUG": 5}).reserve("NOPE", 1)

    def test_reserve_rejects_bad_qty_with_plain_value_error(self):
        inv = Inventory({"MUG": 5})
        for qty in (0, -1, 1.5, "2", True, None):
            with self.subTest(qty=qty):
                with self.assertRaises(ValueError) as cm:
                    inv.reserve("MUG", qty)
                self.assertIs(type(cm.exception), ValueError)
                self.assertEqual(str(cm.exception), "qty must be a positive int")
        self.assertEqual(inv.available("MUG"), 5)

    def test_reserve_more_than_available_is_out_of_stock(self):
        inv = Inventory({"MUG": 2})
        with self.assertRaises(OutOfStock) as cm:
            inv.reserve("MUG", 3)
        self.assertEqual(str(cm.exception), "MUG: requested 3, available 2")
        self.assertEqual(inv.available("MUG"), 2)

    def test_reserve_exactly_available_succeeds(self):
        inv = Inventory({"MUG": 2})
        reservation = inv.reserve("MUG", 2)
        self.assertEqual((reservation.sku, reservation.qty), ("MUG", 2))
        self.assertEqual(inv.available("MUG"), 0)

    def test_reserve_catalog_sku_without_stock_is_out_of_stock(self):
        with self.assertRaises(OutOfStock):
            Inventory({}).reserve("FILTER", 1)

    def test_reserve_huge_qty_is_out_of_stock(self):
        with self.assertRaises(OutOfStock):
            Inventory({"MUG": 5}).reserve("MUG", 10**30)

    def test_same_sku_and_qty_reservations_are_distinct(self):
        inv = Inventory({"MUG": 4})
        first = inv.reserve("MUG", 1)
        second = inv.reserve("MUG", 1)
        self.assertIsNot(first, second)
        inv.commit(first)
        inv.release(second)
        self.assertEqual(inv.available("MUG"), 3)

    def test_commit_reduces_on_hand_and_keeps_available(self):
        inv = Inventory({"MUG": 5})
        reservation = inv.reserve("MUG", 2)
        inv.commit(reservation)
        self.assertEqual(inv.available("MUG"), 3)
        inv.release(inv.reserve("MUG", 3))  # a released hold leaves on hand alone
        self.assertEqual(inv.available("MUG"), 3)

    def test_release_restores_available_and_keeps_on_hand(self):
        inv = Inventory({"MUG": 5})
        reservation = inv.reserve("MUG", 2)
        inv.release(reservation)
        self.assertEqual(inv.available("MUG"), 5)
        inv.reserve("MUG", 5)  # on hand is still 5

    def test_commit_then_release_does_not_restore(self):
        inv = Inventory({"MUG": 5})
        reservation = inv.reserve("MUG", 2)
        inv.commit(reservation)
        with self.assertRaises(ReservationError):
            inv.release(reservation)
        self.assertEqual(inv.available("MUG"), 3)

    def test_second_commit_raises_and_state_unchanged(self):
        inv = Inventory({"MUG": 5})
        reservation = inv.reserve("MUG", 2)
        inv.commit(reservation)
        with self.assertRaises(ReservationError) as cm:
            inv.commit(reservation)
        self.assertEqual(str(cm.exception), "reservation is unknown or already settled")
        self.assertEqual(inv.available("MUG"), 3)

    def test_second_release_raises_and_state_unchanged(self):
        inv = Inventory({"MUG": 5})
        reservation = inv.reserve("MUG", 2)
        inv.release(reservation)
        with self.assertRaises(ReservationError):
            inv.release(reservation)
        self.assertEqual(inv.available("MUG"), 5)

    def test_commit_after_release_raises_and_state_unchanged(self):
        inv = Inventory({"MUG": 5})
        reservation = inv.reserve("MUG", 2)
        inv.release(reservation)
        with self.assertRaises(ReservationError):
            inv.commit(reservation)
        self.assertEqual(inv.available("MUG"), 5)

    def test_foreign_reservations_raise_and_state_unchanged(self):
        inv = Inventory({"MUG": 5})
        other = Inventory({"MUG": 5})
        foreign = other.reserve("MUG", 2)
        handmade = Reservation("MUG", 2)
        for bad in (foreign, handmade, None):
            with self.subTest(bad=bad):
                with self.assertRaises(ReservationError):
                    inv.commit(bad)
                with self.assertRaises(ReservationError):
                    inv.release(bad)
        self.assertEqual(inv.available("MUG"), 5)
        self.assertEqual(other.available("MUG"), 3)

    def test_reservation_is_immutable(self):
        inv = Inventory({"MUG": 5})
        reservation = inv.reserve("MUG", 2)
        with self.assertRaises(FrozenInstanceError):
            reservation.qty = 999
        inv.commit(reservation)
        self.assertEqual(inv.available("MUG"), 3)

    def test_concurrent_reserve_never_oversells(self):
        inv = Inventory({"MUG": 10})
        outcomes = self.race(50, lambda i: inv.reserve("MUG", 1))
        successes = [o for o in outcomes if isinstance(o, Reservation)]
        failures = [o for o in outcomes if isinstance(o, OutOfStock)]
        self.assertEqual(len(successes), 10)
        self.assertEqual(len(failures), 40)
        self.assertEqual(inv.available("MUG"), 0)

    def test_concurrent_commit_of_one_reservation_settles_once(self):
        inv = Inventory({"MUG": 10})
        reservation = inv.reserve("MUG", 3)
        outcomes = self.race(20, lambda i: inv.commit(reservation))
        self.assertEqual(sum(o is None for o in outcomes), 1)
        self.assertEqual(sum(isinstance(o, ReservationError) for o in outcomes), 19)
        self.assertEqual(inv.available("MUG"), 7)
        inv.reserve("MUG", 7)
        with self.assertRaises(OutOfStock):
            inv.reserve("MUG", 1)

    def test_concurrent_commit_and_release_one_wins(self):
        inv = Inventory({"MUG": 10})
        reservation = inv.reserve("MUG", 3)
        actions = (inv.commit, inv.release)
        outcomes = self.race(2, lambda i: actions[i](reservation))
        winners = [o for o in outcomes if o is None]
        losers = [o for o in outcomes if isinstance(o, ReservationError)]
        self.assertEqual(len(winners), 1)
        self.assertEqual(len(losers), 1)
        if outcomes[0] is None:  # commit won: on hand dropped by 3
            self.assertEqual(inv.available("MUG"), 7)
        else:  # release won: the hold is gone and nothing was sold
            self.assertEqual(inv.available("MUG"), 10)

    def test_mutated_reservation_sku_and_qty_do_not_move_stock(self):
        inv = Inventory({"MUG": 5, "FILTER": 5})
        reservation = inv.reserve("MUG", 2)
        object.__setattr__(reservation, "qty", 999)
        object.__setattr__(reservation, "sku", "FILTER")
        inv.commit(reservation)
        self.assertEqual(inv.available("MUG"), 3)
        self.assertEqual(inv.available("FILTER"), 5)
        with self.assertRaises(OutOfStock):
            inv.reserve("MUG", 4)

    def test_mutated_reservation_qty_does_not_change_release(self):
        inv = Inventory({"MUG": 5})
        reservation = inv.reserve("MUG", 2)
        object.__setattr__(reservation, "qty", 999)
        inv.release(reservation)
        self.assertEqual(inv.available("MUG"), 5)

    def test_reserve_liar_qty_cannot_oversell(self):
        inv = Inventory({"MUG": 2})
        with self.assertRaises(OutOfStock):
            inv.reserve("MUG", Liar(3))
        self.assertEqual(inv.available("MUG"), 2)

    def test_reserve_liar_qty_below_one_is_rejected(self):
        inv = Inventory({"MUG": 2})
        with self.assertRaises(ValueError) as cm:
            inv.reserve("MUG", Liar(0))
        self.assertIs(type(cm.exception), ValueError)
        self.assertEqual(str(cm.exception), "qty must be a positive int")
        self.assertEqual(inv.available("MUG"), 2)

    def test_reserve_liar_qty_is_held_as_plain_int(self):
        inv = Inventory({"MUG": 5})
        reservation = inv.reserve("MUG", Liar(2))
        self.assertIs(type(reservation.qty), int)
        self.assertEqual(inv.available("MUG"), 3)

    def test_constructor_liar_units_cannot_oversell(self):
        inv = Inventory({"MUG": Liar(2)})
        with self.assertRaises(OutOfStock):
            inv.reserve("MUG", 3)
        self.assertEqual(inv.available("MUG"), 2)

    def test_constructor_liar_negative_units_rejected(self):
        with self.assertRaises(ValueError) as cm:
            Inventory({"MUG": Liar(-1)})
        self.assertIs(type(cm.exception), ValueError)
        self.assertEqual(str(cm.exception), "units on hand must be an int >= 0")

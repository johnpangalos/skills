"""Thread-safe stock tracking with reservations."""

import threading
from dataclasses import dataclass

from shop.catalog import lookup


class OutOfStock(ValueError):
    pass


class ReservationError(ValueError):
    pass


@dataclass(frozen=True, eq=False)
class Reservation:
    sku: str
    qty: int


class Inventory:
    def __init__(self, stock):
        self._lock = threading.RLock()
        self._on_hand = {}
        self._open = {}  # Reservation -> (sku, qty) for each unsettled hold
        for sku, units in stock.items():
            lookup(sku)
            if isinstance(units, bool) or not isinstance(units, int):
                raise ValueError("units on hand must be an int >= 0")
            units = int(units)
            if units < 0:
                raise ValueError("units on hand must be an int >= 0")
            self._on_hand[sku] = units

    def available(self, sku):
        """Units on hand minus units held by open reservations."""
        lookup(sku)
        with self._lock:
            held = sum(qty for held_sku, qty in self._open.values() if held_sku == sku)
            return self._on_hand.get(sku, 0) - held

    def reserve(self, sku, qty):
        """Hold qty units of sku and return the Reservation."""
        lookup(sku)
        if isinstance(qty, bool) or not isinstance(qty, int):
            raise ValueError("qty must be a positive int")
        qty = int(qty)
        if qty < 1:
            raise ValueError("qty must be a positive int")
        with self._lock:
            avail = self.available(sku)
            if avail < qty:
                raise OutOfStock(f"{sku}: requested {qty}, available {avail}")
            reservation = Reservation(sku, qty)
            self._open[reservation] = (sku, qty)
            return reservation

    def commit(self, reservation):
        """Sell the held units: on hand drops by the reserved qty."""
        with self._lock:
            sku, qty = self._close(reservation)
            self._on_hand[sku] -= qty

    def release(self, reservation):
        """Drop the hold so its units become available again."""
        with self._lock:
            self._close(reservation)

    def _close(self, reservation):
        """Remove an open hold and return its (sku, qty); caller holds the lock."""
        if not isinstance(reservation, Reservation) or reservation not in self._open:
            raise ReservationError("reservation is unknown or already settled")
        return self._open.pop(reservation)

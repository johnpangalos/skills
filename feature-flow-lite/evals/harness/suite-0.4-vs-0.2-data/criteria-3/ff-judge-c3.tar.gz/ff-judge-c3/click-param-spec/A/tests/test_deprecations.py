import importlib.metadata
import sys
import warnings

import pytest

import click
import click.core
import click.parser
import click.shell_completion
import click.utils
from click._utils import UNSET


@pytest.mark.parametrize(
    ("module", "name", "target"),
    [
        # Stream helpers, re-exported from both `click` and `click.utils`.
        (click, "get_binary_stream", click.utils._get_binary_stream),
        (click, "get_text_stream", click.utils._get_text_stream),
        (click.utils, "get_binary_stream", click.utils._get_binary_stream),
        (click.utils, "get_text_stream", click.utils._get_text_stream),
        # Command-class aliases, re-exported from `click` and `click.core`.
        (click, "BaseCommand", click.core._BaseCommand),
        (click, "MultiCommand", click.core._MultiCommand),
        (click.core, "BaseCommand", click.core._BaseCommand),
        (click.core, "MultiCommand", click.core._MultiCommand),
        # Old parser API (moved to `optparse`); `OptionParser` is also
        # re-exported from the top-level `click` namespace.
        (click, "OptionParser", click.parser._OptionParser),
        (click.parser, "OptionParser", click.parser._OptionParser),
        (click.parser, "Argument", click.parser._Argument),
        (click.parser, "Option", click.parser._Option),
        (click.parser, "split_opt", click.parser._split_opt),
        (click.parser, "normalize_opt", click.parser._normalize_opt),
        (click.parser, "ParsingState", click.parser._ParsingState),
        (click.parser, "split_arg_string", click.shell_completion.split_arg_string),
        # Deprecated `click.utils` utilities.
        (click.utils, "LazyFile", click.utils._LazyFile),
        (click.utils, "KeepOpenFile", click.utils._KeepOpenFile),
        (click.utils, "make_default_short_help", click.utils._make_default_short_help),
        (click.utils, "PacifyFlushWrapper", click.utils._PacifyFlushWrapper),
        (click.utils, "safecall", click.utils._safecall),
        # Version metadata attribute.
        (click, "__version__", importlib.metadata.version("click")),
    ],
    ids=lambda v: getattr(v, "__name__", v),
)
def test_attr_deprecated(module, name, target):
    with pytest.warns(DeprecationWarning, match=name):
        value = getattr(module, name)

    assert value == target


@pytest.mark.parametrize(
    "module",
    [click, click.core, click.parser, click.utils],
    ids=lambda m: m.__name__,
)
def test_unknown_attribute_raises(module):
    with pytest.raises(AttributeError, match="no_such_attribute"):
        _ = module.no_such_attribute


def test_context_protected_args_deprecated():
    ctx = click.Context(click.Command("cli"))

    with pytest.warns(DeprecationWarning, match="protected_args"):
        assert ctx.protected_args == []


def test_isolated_filesystem_deprecated(runner):
    with pytest.warns(DeprecationWarning, match="isolated_filesystem"):
        with runner.isolated_filesystem():
            pass


@pytest.mark.parametrize(
    ("make_param", "match"),
    [
        pytest.param(
            lambda: click.Argument(["0foo"]),
            "not a valid Python identifier",
            id="argument-leading-digit",
        ),
        pytest.param(
            lambda: click.Argument(["foo.bar"]),
            "not a valid Python identifier",
            id="argument-dot",
        ),
        pytest.param(
            lambda: click.Argument(["foo bar"]),
            "not a valid Python identifier",
            id="argument-space",
        ),
        pytest.param(
            lambda: click.Argument([""]),
            "not a valid Python identifier",
            id="argument-empty-decl",
        ),
        pytest.param(
            lambda: click.Argument(["0foo"], expose_value=False),
            "not a valid Python identifier",
            id="argument-unexposed",
        ),
        pytest.param(
            lambda: click.Argument([], expose_value=False),
            "not a valid Python identifier",
            id="argument-no-decl",
        ),
        pytest.param(
            lambda: click.Option(["--0foo"], expose_value=False),
            "not a valid Python identifier",
            id="option-unexposed",
        ),
        pytest.param(
            lambda: click.Option([], expose_value=False),
            "not a valid Python identifier",
            id="option-no-decl",
        ),
        # A keyword is an identifier too, so this rule alone reports it.
        pytest.param(
            lambda: click.Option(["--from"]),
            "is a Python keyword",
            id="option-from",
        ),
        pytest.param(
            lambda: click.Option(["--import"]),
            "is a Python keyword",
            id="option-import",
        ),
        pytest.param(
            lambda: click.Argument(["class"]),
            "is a Python keyword",
            id="argument-class",
        ),
    ],
)
def test_unusable_name_deprecated(make_param, match):
    """A name Click 9.0 refuses reports which of its two rules it broke."""
    with pytest.warns(DeprecationWarning, match=match):
        make_param()


@pytest.mark.parametrize(
    "make_param",
    [
        pytest.param(lambda: click.Argument(["foo-bar"]), id="argument-hyphen"),
        pytest.param(lambda: click.Argument(["Foo_Bar"]), id="argument-case"),
        pytest.param(lambda: click.Option(["--foo-bar"]), id="option-hyphen"),
        pytest.param(
            lambda: click.Option(["--0foo", "zero_foo"]), id="option-explicit-name"
        ),
        # Soft keywords are contextual and name a parameter fine.
        pytest.param(lambda: click.Option(["--match"]), id="soft-keyword-match"),
        pytest.param(lambda: click.Argument(["type"]), id="soft-keyword-type"),
        # These lower case out of the keyword set.
        pytest.param(lambda: click.Option(["--True"]), id="true"),
        pytest.param(lambda: click.Option(["--None"]), id="none"),
    ],
)
def test_usable_name_not_deprecated(recwarn, make_param):
    """A name a callback can declare keeps working, and says nothing."""
    make_param()
    assert [w for w in recwarn if issubclass(w.category, DeprecationWarning)] == []


@pytest.mark.parametrize(
    "make_param",
    [
        pytest.param(lambda: click.Option(["--from"]), id="keyword"),
        pytest.param(lambda: click.Argument(["0foo"]), id="non-identifier"),
    ],
)
def test_unusable_name_names_the_release_that_refuses_it(make_param):
    """Both refusals name the release that turns the warning into an error."""
    match = r"will raise a TypeError in Click 9\.0"
    with pytest.warns(DeprecationWarning, match=match):
        make_param()


@pytest.mark.parametrize(
    ("decl", "expect"),
    [
        pytest.param("Foo_Bar", "foo_bar", id="mixed-case"),
        pytest.param("X_Y", "x_y", id="upper-case"),
        pytest.param("ΟΔΟΣ", "οδος", id="final-sigma"),
        pytest.param("\N{KELVIN SIGN}", "k", id="kelvin-sign"),
    ],
)
def test_unnormalized_explicit_name_deprecated(decl, expect):
    """Click 9.0 lower cases an explicit name like any other declaration."""
    with pytest.warns(DeprecationWarning, match="lower cases an explicit name"):
        param = click.Option(["--x", decl])

    assert param.name == decl
    assert decl.lower() == expect


@pytest.mark.parametrize(
    "decls",
    [
        pytest.param(["--x", "foo_bar"], id="already-lower"),
        pytest.param(["--x", "_from"], id="leading-underscore"),
        pytest.param(["--Foo-Bar"], id="derived-not-explicit"),
        pytest.param(["--x", "café"], id="lower-case-non-ascii"),
    ],
)
def test_normalized_explicit_name_not_deprecated(recwarn, decls):
    """A name already spelled the way 9.0 spells it says nothing."""
    click.Option(decls)
    assert [w for w in recwarn if issubclass(w.category, DeprecationWarning)] == []


def test_unnormalized_name_on_a_refused_option_is_silent():
    """An option that cannot be built at all warns about nothing."""
    with pytest.raises(TypeError, match="No options defined"):
        with warnings.catch_warnings():
            warnings.simplefilter("error", DeprecationWarning)
            click.Option(["Foo_Bar"])


@pytest.mark.parametrize(
    ("make_param", "expected"),
    [
        pytest.param(lambda: click.Option(["--my-option"]), "--my-option", id="option"),
        pytest.param(
            lambda: click.Option(["-m", "--my-option"]), "--my-option", id="short-first"
        ),
        pytest.param(
            lambda: click.Argument(["my-argument"]), "MY_ARGUMENT", id="argument"
        ),
    ],
)
def test_human_readable_name_deprecated(make_param, expected):
    """The deprecated property warns at the caller and still returns the spec."""
    param = make_param()

    with pytest.warns(
        DeprecationWarning, match="'human_readable_name' is deprecated"
    ) as record:
        assert param.human_readable_name == expected

    assert record[0].filename == __file__


@pytest.mark.parametrize(
    ("decls", "args", "expected"),
    [
        pytest.param(
            ["-m", "--my-option"], ["-m", "x"], "--my-option", id="short-first"
        ),
        pytest.param(
            ["--shout/--no-shout"], ["--no-shout"], "--shout", id="flag-secondary"
        ),
    ],
)
def test_deprecated_message_names_spec(runner, decls, args, expected):
    @click.command()
    @click.option(*decls, deprecated=True)
    def cli(**kwargs):
        click.echo("ok")

    result = runner.invoke(cli, args)
    assert result.exit_code == 0, result.output
    assert f"The option '{expected}' is deprecated." in result.output


def test_deprecated_required_message_names_spec():
    with pytest.raises(ValueError) as excinfo:
        click.Option(["-m", "--a"], required=True, deprecated=True)

    assert str(excinfo.value) == (
        "The option '--a' is deprecated and still required. A deprecated option"
        " cannot be required."
    )


def test_missing_parameter_names_spec():
    param = click.Option(["-m", "--my-name"], required=True)

    with pytest.raises(click.MissingParameter) as excinfo:
        param.process_value(click.Context(click.Command("")), UNSET)

    assert str(excinfo.value) == "Missing parameter: --my-name"


@pytest.mark.parametrize(
    "base",
    [
        pytest.param(click.Parameter, id="parameter"),
        pytest.param(click.Option, id="option"),
        pytest.param(click.Argument, id="argument"),
    ],
)
def test_subclass_overriding_human_readable_name_warns(base):
    with pytest.warns(
        DeprecationWarning,
        match="'Custom' overrides 'human_readable_name', which is deprecated."
        " Override 'spec' instead.",
    ) as record:

        class Custom(base):  # type: ignore[valid-type, misc]
            @property
            def human_readable_name(self) -> str:
                return "custom"

    assert record[0].filename == __file__


def test_subclass_of_overriding_class_is_silent(recwarn):
    with pytest.warns(DeprecationWarning, match="'Base' overrides"):

        class Base(click.Option):
            @property
            def human_readable_name(self) -> str:
                return "base"

    recwarn.clear()

    class Sub(Base):
        pass

    assert [w for w in recwarn if issubclass(w.category, DeprecationWarning)] == []


def test_subclass_overriding_spec_is_silent(recwarn):
    class Custom(click.Option):
        @property
        def spec(self) -> str:
            return "custom"

    assert Custom(["--x"]).spec == "custom"
    assert [w for w in recwarn if issubclass(w.category, DeprecationWarning)] == []


def test_subclass_keyword_arguments_pass_through():
    class Base(click.Option):
        flavor: str | None = None

        def __init_subclass__(cls, flavor=None, **kwargs):
            cls.flavor = flavor
            super().__init_subclass__(**kwargs)

    with pytest.warns(DeprecationWarning, match="'Custom' overrides"):

        class Custom(Base, flavor="vanilla"):  # type: ignore[call-arg]
            @property
            def human_readable_name(self) -> str:
                return "custom"

    assert Custom.flavor == "vanilla"


def test_subclass_warning_points_at_class_statement_with_metaclass():
    """A metaclass ``__new__`` and a base ``__init_subclass__`` between the class
    statement and Click do not shift the warning's location.
    """

    class Meta(type(click.Option)):  # type: ignore[misc]
        def __new__(mcls, name, bases, ns, **kwargs):  # type: ignore[no-untyped-def]
            return super().__new__(mcls, name, bases, ns, **kwargs)

    class Base(click.Option, metaclass=Meta):
        def __init_subclass__(cls, **kwargs):  # type: ignore[no-untyped-def]
            super().__init_subclass__(**kwargs)

    with pytest.warns(DeprecationWarning, match="'Custom' overrides") as record:
        line = sys._getframe().f_lineno + 2

        class Custom(Base):
            @property
            def human_readable_name(self) -> str:
                return "custom"

    assert (record[0].filename, record[0].lineno) == (__file__, line)

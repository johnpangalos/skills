import copy
import functools
import pickle
import warnings

import pytest

import click


class CustomParameter(click.Parameter):
    def _parse_decls(self, decls, expose_value):
        return "name", ["-x", "--ex"], []

    def add_to_parser(self, parser, ctx):
        pass


@pytest.mark.parametrize(
    ("decls", "kwargs", "expected"),
    [
        (["-t", "--times"], {}, "--times"),
        (["--times", "-t"], {}, "--times"),
        (["--color/--no-color"], {}, "--color"),
        (["-v"], {}, "-v"),
        (["-t", "--times", "count"], {}, "--times"),
        (["/debug;/no-debug"], {}, "/debug"),
        (["+w/-w"], {}, "+w"),
        (["--x/--no-x"], {}, "--x"),
        (["-a", "-b"], {}, "-a"),
    ],
)
def test_option_spec(decls, kwargs, expected):
    assert click.Option(decls, **kwargs).spec == expected


@pytest.mark.parametrize(
    ("decls", "kwargs", "expected"),
    [
        (["filename"], {}, "FILENAME"),
        (["filename"], {"metavar": "SRC"}, "SRC"),
        (["filename"], {"required": False}, "FILENAME"),
        (["filename"], {"nargs": -1, "required": False}, "FILENAME"),
        (["filename"], {"required": False, "deprecated": True}, "FILENAME"),
    ],
)
def test_argument_spec(decls, kwargs, expected):
    assert click.Argument(decls, **kwargs).spec == expected


def test_argument_spec_without_name():
    with pytest.warns(DeprecationWarning, match="uses '' as its name"):
        arg = click.Argument([], expose_value=False)

    assert arg.spec == ""


def test_base_spec_uses_longest_prefix():
    assert CustomParameter(["x"]).spec == "--ex"


def test_base_spec_falls_back_to_name():
    param = CustomParameter(["x"])
    param.opts = []
    assert param.spec == "name"


def test_spec_is_read_only():
    with pytest.raises(AttributeError):
        click.Option(["-t", "--times"]).spec = "other"


def test_get_help_spec_is_on_parameter():
    assert "get_help_spec" not in click.Option.__dict__
    assert "get_help_spec" in click.Parameter.__dict__


@pytest.mark.parametrize(
    ("decls", "expected"),
    [(["-t", "--times"], "--times"), (["--color/--no-color"], "--color")],
)
@pytest.mark.parametrize("hidden", [False, True])
def test_option_get_help_spec_is_spec(decls, expected, hidden):
    ctx = click.Context(click.Command("cli"))
    assert click.Option(decls, hidden=hidden).get_help_spec(ctx) == expected


def test_base_get_help_spec_is_spec():
    ctx = click.Context(click.Command("cli"))
    assert CustomParameter(["x"]).get_help_spec(ctx) == "--ex"


@pytest.mark.parametrize(
    ("kwargs", "expected"),
    [
        ({"nargs": -1, "required": False}, "[FILENAME]..."),
        ({}, "FILENAME"),
    ],
)
def test_argument_get_help_spec(kwargs, expected):
    ctx = click.Context(click.Command("cli"))
    assert click.Argument(["filename"], **kwargs).get_help_spec(ctx) == expected


def test_argument_error_hint_without_context():
    assert click.Argument(["filename"]).get_error_hint(None) == "'FILENAME'"


@pytest.mark.parametrize(
    ("cls", "decls", "match"),
    [
        (click.Option, ["-m", "--my-option"], "option '--my-option' is deprecated"),
        (click.Argument, ["filename"], "argument 'FILENAME' is deprecated"),
    ],
)
def test_deprecated_required_names_spec(cls, decls, match):
    with pytest.raises(ValueError, match=match):
        cls(decls, required=True, deprecated=True)


@pytest.mark.parametrize(
    ("cls", "decls", "expected"),
    [
        (click.Option, ["-t", "--times"], "--times"),
        (click.Argument, ["filename"], "FILENAME"),
    ],
)
def test_human_readable_name_returns_spec(cls, decls, expected):
    param = cls(decls)

    with pytest.warns(DeprecationWarning, match="Use 'spec' instead"):
        assert param.human_readable_name == expected


def test_human_readable_name_warning_points_at_caller():
    param = click.Option(["-t", "--times"])

    with pytest.warns(DeprecationWarning) as record:
        _ = param.human_readable_name

    assert record[0].filename == __file__


def test_argument_has_no_human_readable_name():
    assert "human_readable_name" not in click.Argument.__dict__


def test_override_of_spec_does_not_warn():
    with warnings.catch_warnings(record=True) as caught:
        warnings.simplefilter("always")

        class Custom(click.Option):
            @property
            def spec(self):
                return "--custom"

    assert not caught
    assert Custom(["-x"]).spec == "--custom"


def test_human_readable_name_returns_spec_override():
    class Custom(click.Option):
        @property
        def spec(self):
            return "--custom"

    with pytest.warns(DeprecationWarning, match="Use 'spec' instead"):
        assert Custom(["-x"]).human_readable_name == "--custom"


@pytest.mark.parametrize(
    "body",
    [
        {"human_readable_name": property(lambda self: "other")},
        {"human_readable_name": "other"},
        {"human_readable_name": functools.cached_property(lambda self: "other")},
    ],
)
def test_override_of_human_readable_name_warns(body):
    with pytest.warns(DeprecationWarning, match="Custom overrides"):
        cls = type("Custom", (click.Option,), body)

    # Click does not call the override.
    assert cls(["-t", "--times"]).spec == "--times"


def test_argument_override_of_human_readable_name_warns():
    with pytest.warns(DeprecationWarning, match="Custom overrides") as record:

        class Custom(click.Argument):
            @property
            def human_readable_name(self):
                return "other"

    assert record[0].filename == __file__
    assert Custom(["filename"]).spec == "FILENAME"


def test_override_warns_for_subclass_at_depth():
    with pytest.warns(DeprecationWarning, match="Custom overrides"):

        class Custom(click.Option):
            human_readable_name = "other"

    with pytest.warns(DeprecationWarning, match="Deeper overrides"):

        class Deeper(Custom):
            human_readable_name = "deeper"


def test_subclass_of_overriding_class_does_not_warn_again():
    with pytest.warns(DeprecationWarning, match="Custom overrides"):

        class Custom(click.Option):
            human_readable_name = "other"

    with warnings.catch_warnings(record=True) as caught:
        warnings.simplefilter("always")

        class Child(Custom):
            pass

    assert not caught


def test_copy_and_pickle_keep_spec():
    opt = click.Option(["-t", "--times"])
    assert copy.deepcopy(opt).spec == "--times"
    assert pickle.loads(pickle.dumps(opt)).spec == "--times"

// Shop data shared by the home, books and events pages.
// Event dates are 'YYYY-MM-DD' strings; pages build local dates from them.

const BOOKS = [
  {
    id: 'the-salt-clock',
    title: 'The Salt Clock',
    author: 'Imogen Varley',
    genre: 'Mystery',
    price: 9.99,
    staffPick: true,
    blurb: 'When a ship’s chronometer turns up in a Dunmere pawnshop, retired harbour clerk Edith Maddox starts asking the questions the town would rather forget.'
  },
  {
    id: 'a-ledger-of-small-debts',
    title: 'A Ledger of Small Debts',
    author: 'Tobias Ferrant',
    genre: 'Mystery',
    price: 11.5,
    staffPick: false,
    blurb: 'Every column in the parish account book balances except one entry, marked <unpaid> in red ink, that appears in three different decades.'
  },
  {
    id: 'night-tram-to-ossory',
    title: 'Night Tram to Ossory',
    author: 'Rhiannon Osei',
    genre: 'Mystery',
    price: 10.99,
    staffPick: false,
    blurb: 'A sleeper train, a stopped clock and a passenger who was never on the manifest. Sergeant Hale has until the next station to find her.'
  },
  {
    id: 'orbit-of-glass-gardens',
    title: 'Orbit of Glass Gardens',
    author: 'Lena Achterberg',
    genre: 'Science Fiction',
    price: 13,
    staffPick: false,
    blurb: 'On a station that grows its food under ice, the seed archivist discovers the crops have started keeping records of their own.'
  },
  {
    id: 'the-quiet-relay',
    title: 'The Quiet Relay',
    author: 'Samuel Oyelaran-Pryce',
    genre: 'Science Fiction',
    price: 12.5,
    staffPick: false,
    blurb: 'A signal from a dead probe arrives forty years late, addressed to a village that no longer appears on any map.'
  },
  {
    id: 'tidewright',
    title: 'Tidewright',
    author: 'Mireille Sato',
    genre: 'Science Fiction',
    price: 14.99,
    staffPick: false,
    blurb: 'Engineers on a drowned moon repair its tides by hand, and one apprentice would rather break them.'
  },
  {
    id: 'tides-and-tallies',
    title: 'Tides & Tallies',
    author: 'Harriet Lowe',
    genre: 'Literary Fiction',
    price: 12.99,
    staffPick: true,
    blurb: 'Three generations of one fishing family keep the same tally book, each writing the weather in a different hand, until the storm year arrives.'
  },
  {
    id: 'the-lighthouse-keepers-almanac',
    title: 'The Lighthouse Keeper’s Almanac',
    author: 'Dorothea Quill',
    genre: 'Literary Fiction',
    price: 11,
    staffPick: false,
    blurb: 'A year of diary entries from a keeper who records the weather, the christenings and the boats that never came back.'
  },
  {
    id: 'the-bookbinders-last-winter',
    title: 'The Bookbinder’s Last Winter',
    author: 'Anselm Brandt',
    genre: 'Literary Fiction',
    price: 10.5,
    staffPick: false,
    blurb: 'In a market town where every shop is closing, an old bookbinder keeps one room open for the customers who still ask for repairs.'
  },
  {
    id: 'wet-ink-dry-hands',
    title: 'Wet Ink, Dry Hands',
    author: 'Nadia Corrigan',
    genre: 'Poetry',
    price: 10.5,
    staffPick: false,
    blurb: 'Poems written at a kitchen table through a long winter of night shifts, with recipes tucked into the margins.'
  },
  {
    id: 'small-hours-sonnets',
    title: 'Small Hours Sonnets',
    author: 'Idris Penhale',
    genre: 'Poetry',
    price: 9,
    staffPick: false,
    blurb: 'Fourteen-line poems about insomnia, bus shelters and the first grey light over the reservoir.'
  },
  {
    id: 'field-notes-in-verse',
    title: 'Field Notes in Verse',
    author: 'Ottilie Brandreth',
    genre: 'Poetry',
    price: 12,
    staffPick: false,
    blurb: 'Short poems written on the backs of receipts, bird surveys and shopping lists, gathered into one slim and surprising volume.'
  },
  {
    id: 'mapping-the-marsh',
    title: 'Mapping the Marsh',
    author: 'Grace Ellery-Tan',
    genre: 'Nature Writing',
    price: 14,
    staffPick: false,
    blurb: 'A year spent walking the same four miles of saltmarsh, noting the birds, the tides and the people who stop to ask what she is looking for.'
  },
  {
    id: 'hedgerow-calendar',
    title: 'Hedgerow Calendar',
    author: 'Peter Vashti',
    genre: 'Nature Writing',
    price: 12,
    staffPick: true,
    blurb: 'Month by month through one hedge on the Dunmere road: blackthorn, bats and the stubborn survival of the dormouse.'
  },
  {
    id: 'the-orchard-keeps-its-own-time',
    title: 'The Orchard Keeps Its Own Time',
    author: 'Alba Renfrew',
    genre: 'Nature Writing',
    price: 13.5,
    staffPick: false,
    blurb: 'Notes from an apple grower on pruning, pollinators and the patience of trees planted by people long gone.'
  }
];

const EVENTS = [
  {
    date: '2026-11-21',
    title: 'Saturday Storytime for Early Readers',
    start: '11:00am',
    cost: 'Free',
    bookingRequired: false,
    description: 'Picture books, a song or two and a sticker for every reader. The children’s corner is by the back window, so buggies can park by the door.'
  },
  {
    date: '2026-11-28',
    title: 'Open Mic for Poets',
    start: '6:30pm',
    cost: 'Free',
    bookingRequired: false,
    description: 'Five minutes each, any kind of poem, read from paper or from memory. Bring a poem or just come and listen with a cup of tea.'
  },
  {
    date: '2026-12-05',
    title: 'Ink and Ember: a Letterpress Demonstration',
    start: '7:00pm',
    cost: '£8 per person',
    bookingRequired: true,
    description: 'Our printer, Ruth Abernathy, sets type by hand and pulls a broadside in front of you. Limited to 14 seats.'
  },
  {
    date: '2026-12-12',
    title: 'Mapping the Marsh: a Talk by Grace Ellery-Tan',
    start: '2:00pm',
    cost: 'Free',
    bookingRequired: true,
    description: 'The author talks about four miles of saltmarsh and a year of walking them. Signed copies will be on the table afterwards.'
  },
  {
    date: '2026-12-19',
    title: 'Carols and Chapbooks',
    start: '5:00pm',
    cost: 'Free',
    bookingRequired: false,
    description: 'An hour of winter readings and carols sung by the Little Ashcombe Choir, with mulled cider while it lasts.'
  },
  {
    date: '2027-01-09',
    title: 'Mystery Book Club: The Salt Clock',
    start: '7:30pm',
    cost: 'Free',
    bookingRequired: true,
    description: 'We talk through Imogen Varley’s The Salt Clock over a plate of biscuits. Copies are on the shelf; please book so we can order enough.'
  }
];

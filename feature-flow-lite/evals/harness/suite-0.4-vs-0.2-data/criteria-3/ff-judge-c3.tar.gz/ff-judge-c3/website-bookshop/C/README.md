# Marginalia Books

A static website for Marginalia Books, a fictional independent bookshop. It has four pages (Home, Books, Events, Visit), a genre-filtered catalogue, a list of events split into upcoming ones, and a demo contact form.

It is plain HTML, CSS and vanilla JavaScript. There is no build step, no framework, no package install and no external requests: no CDNs, web fonts, analytics or remote images.

## Viewing the site

Either of these works:

- Open `index.html` directly in a browser (`file://` works).
- Serve the folder over HTTP, for example `npx http-server -p 8080 -c-1 .`, then open http://localhost:8080/

## Running the tests

The tests are Node's built-in test runner with Playwright driving the system Chrome at `/usr/bin/google-chrome`. Playwright must be installed globally. Each test file starts its own static server on an ephemeral port.

```sh
NODE_PATH=$(npm root -g) node --test 'tests/*.test.cjs'
```

To run one file, pass its path, for example `tests/books.test.cjs`.

## Layout

- `index.html`, `books.html`, `events.html`, `visit.html`: the pages
- `css/styles.css`: the shared stylesheet
- `js/data.js`: the books and events arrays used by every page
- `js/main.js`: shared script (footer year)
- `js/home.js`, `js/books.js`, `js/events.js`, `js/contact.js`: one script per page
- `tests/`: Playwright tests and the shared test helper

## Notes

- The genre filter is kept in the query string (for example `books.html?genre=poetry`), so filtered views can be bookmarked and the back and forward buttons work.
- Event dates are stored as local date and time strings and compared with the reader's local date.
- The contact form only checks its fields. It does not send anything, and it says so.

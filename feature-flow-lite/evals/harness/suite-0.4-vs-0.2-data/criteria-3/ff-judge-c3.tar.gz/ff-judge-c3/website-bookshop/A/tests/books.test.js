'use strict';

const { test, before, after } = require('node:test');
const assert = require('node:assert/strict');
const path = require('node:path');
const { ROOT, chromium, startServer, stopServer, watchErrors } = require('./helpers');

let server;
let base;
let browser;

before(async function () {
  ({ server, base } = await startServer());
  browser = await chromium.launch();
});

after(async function () {
  await browser.close();
  await stopServer(server);
});

// Reads what the visitor sees: the checked genre, the cards, the count text and the URL.
async function readState(page) {
  return page.evaluate(function () {
    const checked = document.querySelector('input[name="genre"]:checked');
    const cards = Array.from(document.querySelectorAll('#book-list > li'));
    return {
      checked: checked ? checked.value : null,
      cards: cards.length,
      genres: cards.map(function (card) {
        return card.querySelector('.book-genre').textContent.replace('Genre: ', '');
      }),
      count: document.getElementById('result-count').textContent,
      path: location.pathname + location.search
    };
  });
}

async function newBooksPage(context) {
  const page = await context.newPage();
  const errors = watchErrors(page);
  page.on('dialog', function (dialog) {
    dialog.dismiss();
    errors.push('unexpected dialog: ' + dialog.message());
  });
  await page.goto(base + '/books.html');
  return { page, errors };
}

test('catalogue data: at least 12 titles across 5+ genres with 2+ titles each, no duplicate titles', async function () {
  const context = await browser.newContext();
  const { page } = await newBooksPage(context);
  const data = await page.evaluate(function () {
    return BOOKS.map(function (book) {
      return { title: book.title, author: book.author, genre: book.genre, blurb: book.blurb, price: book.price };
    });
  });
  assert.ok(data.length >= 12, 'expected at least 12 books, got ' + data.length);
  const byGenre = {};
  data.forEach(function (book) {
    byGenre[book.genre] = (byGenre[book.genre] || 0) + 1;
    assert.ok(book.title && book.author && book.blurb, 'book missing text fields');
    assert.equal(typeof book.price, 'number');
  });
  assert.ok(Object.keys(byGenre).length >= 5, 'expected at least 5 genres');
  Object.keys(byGenre).forEach(function (genre) {
    assert.ok(byGenre[genre] >= 2, genre + ' has fewer than 2 titles');
  });
  const titles = new Set(data.map(function (book) { return book.title; }));
  assert.equal(titles.size, data.length, 'duplicate titles in data');
  await context.close();
});

test('filter shows only the chosen genre, with an exact count and matching cards', async function () {
  const context = await browser.newContext();
  const { page, errors } = await newBooksPage(context);
  const initial = await readState(page);
  assert.equal(initial.cards, 15);
  assert.equal(initial.count, 'Showing 15 of 15 books');
  assert.equal(initial.checked, 'all');

  await page.click('label[for="genre-mystery"]');
  const mystery = await readState(page);
  assert.equal(mystery.cards, 3);
  assert.equal(mystery.count, 'Showing 3 of 15 books in Mystery');
  assert.deepEqual([...new Set(mystery.genres)], ['Mystery']);
  assert.equal(mystery.checked, 'Mystery');

  await page.click('label[for="genre-all"]');
  const all = await readState(page);
  assert.equal(all.cards, 15);
  assert.equal(all.count, 'Showing 15 of 15 books');
  assert.deepEqual(errors, []);
  await context.close();
});

test('the count is a polite live region and the filter is a labelled radio group', async function () {
  const context = await browser.newContext();
  const { page } = await newBooksPage(context);
  assert.equal(await page.getAttribute('#result-count', 'aria-live'), 'polite');
  assert.equal(await page.textContent('fieldset legend'), 'Filter by genre');
  const labels = await page.$$eval('input[name="genre"]', function (inputs) {
    return inputs.map(function (input) {
      return document.querySelector('label[for="' + input.id + '"]').textContent;
    });
  });
  assert.equal(labels[0], 'All genres');
  assert.deepEqual(labels.slice(1).sort(), ['Literary Fiction', 'Mystery', 'Nature Writing', 'Poetry', 'Science Fiction']);
  await context.close();
});

test('selecting a genre updates the query string and adds one history entry per change', async function () {
  const context = await browser.newContext();
  const { page, errors } = await newBooksPage(context);
  const start = await page.evaluate(function () { return history.length; });
  await page.click('label[for="genre-science-fiction"]');
  assert.equal((await readState(page)).path, '/books.html?genre=science-fiction');
  await page.click('label[for="genre-poetry"]');
  assert.equal((await readState(page)).path, '/books.html?genre=poetry');
  const after = await page.evaluate(function () { return history.length; });
  assert.equal(after - start, 2);
  assert.deepEqual(errors, []);
  await context.close();
});

test('choosing the already-selected genre does not add a history entry or change the result', async function () {
  const context = await browser.newContext();
  const { page } = await newBooksPage(context);
  await page.click('label[for="genre-mystery"]');
  const before = await page.evaluate(function () { return history.length; });
  await page.click('label[for="genre-mystery"]');
  assert.equal(await page.evaluate(function () { return history.length; }), before);
  const state = await readState(page);
  assert.equal(state.cards, 3);
  assert.equal(state.count, 'Showing 3 of 15 books in Mystery');
  await context.close();
});

test('rapid repeated changes leave the count matching the visible cards', async function () {
  const context = await browser.newContext();
  const { page, errors } = await newBooksPage(context);
  const genres = ['mystery', 'poetry', 'all', 'nature-writing', 'mystery', 'literary-fiction', 'mystery'];
  for (const slug of genres) {
    await page.click('label[for="genre-' + slug + '"]', { delay: 0 });
  }
  const state = await readState(page);
  assert.equal(state.cards, 3);
  assert.equal(state.count, 'Showing 3 of 15 books in Mystery');
  assert.deepEqual([...new Set(state.genres)], ['Mystery']);
  assert.deepEqual(errors, []);
  await context.close();
});

test('keyboard arrows in the genre group change the filter', async function () {
  const context = await browser.newContext();
  const { page } = await newBooksPage(context);
  await page.focus('input[name="genre"]:checked');
  await page.keyboard.press('ArrowDown');
  const state = await readState(page);
  assert.equal(state.checked, 'Mystery');
  assert.equal(state.cards, 3);
  await context.close();
});

test('back and forward restore the previous filter, control state and count', async function () {
  const context = await browser.newContext();
  const { page, errors } = await newBooksPage(context);
  await page.click('label[for="genre-mystery"]');
  await page.click('label[for="genre-poetry"]');
  await page.goBack();
  let state = await readState(page);
  assert.equal(state.checked, 'Mystery');
  assert.equal(state.cards, 3);
  assert.equal(state.count, 'Showing 3 of 15 books in Mystery');
  await page.goBack();
  state = await readState(page);
  assert.equal(state.checked, 'all');
  assert.equal(state.cards, 15);
  assert.equal(state.count, 'Showing 15 of 15 books');
  await page.goForward();
  state = await readState(page);
  assert.equal(state.checked, 'Mystery');
  assert.equal(state.cards, 3);
  assert.deepEqual(errors, []);
  await context.close();
});

test('loading books.html?genre=mystery shows only mystery books with Mystery selected', async function () {
  const context = await browser.newContext();
  const page = await context.newPage();
  const errors = watchErrors(page);
  await page.goto(base + '/books.html?genre=mystery');
  const state = await readState(page);
  assert.equal(state.checked, 'Mystery');
  assert.equal(state.cards, 3);
  assert.equal(state.count, 'Showing 3 of 15 books in Mystery');
  assert.deepEqual([...new Set(state.genres)], ['Mystery']);
  assert.deepEqual(errors, []);
  await context.close();
});

// Each hostile value must fall back to the expected genre with no errors and no injected markup.
const HOSTILE = [
  { query: '?genre=', checked: 'all', cards: 15 },
  { query: '?genre=NotAGenre', checked: 'all', cards: 15 },
  { query: '?genre=%3Cscript%3Ealert(1)%3C%2Fscript%3E', checked: 'all', cards: 15 },
  { query: '?genre=MYSTERY', checked: 'Mystery', cards: 3 },
  { query: '?genre=science%20fiction', checked: 'Science Fiction', cards: 3 },
  { query: '?genre=Science%20Fiction', checked: 'Science Fiction', cards: 3 },
  { query: '?genre=science-fiction', checked: 'Science Fiction', cards: 3 },
  { query: '?genre=Science+Fiction', checked: 'Science Fiction', cards: 3 },
  { query: '?genre=%20Mystery%20', checked: 'Mystery', cards: 3 },
  { query: '?genre=Mystery!!!', checked: 'all', cards: 15 },
  { query: '?genre=science_fiction', checked: 'all', cards: 15 },
  { query: '?genre=science-fiction-', checked: 'all', cards: 15 }
];

for (const item of HOSTILE) {
  test('hostile query ' + item.query + ' falls back or matches without errors', async function () {
    const context = await browser.newContext();
    const page = await context.newPage();
    const errors = watchErrors(page);
    let dialogs = 0;
    page.on('dialog', function (dialog) {
      dialogs++;
      dialog.dismiss();
    });
    await page.goto(base + '/books.html' + item.query);
    const state = await readState(page);
    assert.equal(state.checked, item.checked);
    assert.equal(state.cards, item.cards);
    const injected = await page.evaluate(function () {
      return document.querySelectorAll('#book-list script, #book-list img').length + (window.pwned ? 1 : 0);
    });
    assert.equal(injected, 0);
    assert.equal(dialogs, 0, 'a dialog opened');
    assert.deepEqual(errors, []);
    await context.close();
  });
}

test('data with HTML special characters renders as text, not markup', async function () {
  const context = await browser.newContext();
  const { page, errors } = await newBooksPage(context);
  const tides = await page.locator('#book-list h2', { hasText: 'Tides & Tallies' }).count();
  assert.equal(tides, 1);
  await page.click('label[for="genre-mystery"]');
  // The second mystery card is A Ledger of Small Debts, whose blurb contains "<unpaid>".
  const ledger = await page.locator('#book-list .book-blurb').nth(1).textContent();
  assert.match(ledger, /<unpaid> in red ink/);
  assert.equal(await page.locator('#book-list unpaid').count(), 0);
  assert.deepEqual(errors, []);
  await context.close();
});

test('the filter works from a file:// load without console errors', async function () {
  const context = await browser.newContext();
  const page = await context.newPage();
  const errors = watchErrors(page);
  const file = 'file://' + path.join(ROOT, 'books.html');
  await page.goto(file + '?genre=mystery');
  let state = await readState(page);
  assert.equal(state.checked, 'Mystery');
  assert.equal(state.cards, 3);
  await page.click('label[for="genre-science-fiction"]');
  state = await readState(page);
  assert.equal(state.cards, 3);
  assert.equal(state.count, 'Showing 3 of 15 books in Science Fiction');
  assert.deepEqual(errors, []);
  await context.close();
});

test('a refused history update is caught: the filter still works with no console error', async function () {
  const context = await browser.newContext();
  const page = await context.newPage();
  await page.addInitScript(function () {
    history.pushState = function () {
      throw new Error('SecurityError: pushState refused');
    };
  });
  const errors = watchErrors(page);
  await page.goto(base + '/books.html');
  await page.click('label[for="genre-poetry"]');
  const state = await readState(page);
  assert.equal(state.cards, 3);
  assert.equal(state.count, 'Showing 3 of 15 books in Poetry');
  assert.equal(state.path, '/books.html');
  assert.deepEqual(errors, []);
  await context.close();
});

import { test, describe } from 'node:test';
import assert from 'node:assert/strict';
import { useSite, withPage, PAGES } from './helpers.mjs';

const site = useSite();

describe('responsive layout', () => {
  for (const width of [360, 1280]) {
    for (const file of PAGES) {
      test(`${file} has no horizontal scrolling at ${width}px`, () =>
        withPage(site.browser, { viewport: { width, height: 800 } }, async (page) => {
          await page.goto(`${site.base}/${file}`);
          const sizes = await page.evaluate(() => ({
            scroll: document.documentElement.scrollWidth,
            inner: window.innerWidth
          }));
          assert.ok(sizes.scroll <= sizes.inner, `scrollWidth ${sizes.scroll} > innerWidth ${sizes.inner}`);
        }));
    }
  }

  test('pages stay within 360px with the mobile menu open', () =>
    withPage(site.browser, { viewport: { width: 360, height: 800 } }, async (page) => {
      await page.goto(`${site.base}/visit.html`);
      await page.locator('.nav-toggle').click();
      const sizes = await page.evaluate(() => ({
        scroll: document.documentElement.scrollWidth,
        inner: window.innerWidth
      }));
      assert.ok(sizes.scroll <= sizes.inner, `scrollWidth ${sizes.scroll} > innerWidth ${sizes.inner}`);
    }));

  test('body text is at least 16px so it reads without zooming', () =>
    withPage(site.browser, { viewport: { width: 360, height: 800 } }, async (page) => {
      await page.goto(`${site.base}/index.html`);
      const size = await page.evaluate(() => parseFloat(getComputedStyle(document.body).fontSize));
      assert.ok(size >= 16, `font-size ${size}px`);
    }));

  test('catalogue is one column at 360px and several columns at 1280px', () =>
    withPage(site.browser, { viewport: { width: 360, height: 800 } }, async (page) => {
      await page.goto(`${site.base}/books.html`);
      const columns = () => page.$eval('#book-list', (ul) =>
        getComputedStyle(ul).gridTemplateColumns.split(' ').length);
      assert.equal(await columns(), 1);
      await page.setViewportSize({ width: 1280, height: 800 });
      assert.equal(await columns(), 3);
    }));

  test('nav toggle and genre filter are at least 44x44px at 360px', () =>
    withPage(site.browser, { viewport: { width: 360, height: 800 } }, async (page) => {
      await page.goto(`${site.base}/books.html`);
      for (const selector of ['.nav-toggle', '#genre-select']) {
        const box = await page.locator(selector).boundingBox();
        assert.ok(box.width >= 44 && box.height >= 44, `${selector} is ${box.width}x${box.height}`);
      }
    }));

  test('every page declares a device-width viewport', () =>
    withPage(site.browser, {}, async (page) => {
      for (const file of PAGES) {
        await page.goto(`${site.base}/${file}`);
        const content = await page.$eval('meta[name="viewport"]', (m) => m.getAttribute('content'));
        assert.match(content, /width=device-width/, file);
      }
    }));
});

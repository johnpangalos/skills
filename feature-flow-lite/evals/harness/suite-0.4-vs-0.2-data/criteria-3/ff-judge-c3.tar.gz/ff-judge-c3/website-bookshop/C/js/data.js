// Shared site data for Marginalia Books (fictional). Plain arrays, rendered by the page scripts.
// Event start times are local date and time strings ("YYYY-MM-DDTHH:MM"); they are parsed
// as local time, never as UTC.

const BOOKS = [
  {
    title: "The Lamplighter's Daughter",
    author: "Helen Marsh",
    genre: "Literary Fiction",
    blurb: "A widowed harbour lamplighter's daughter inherits her father's route and a box of unsent letters. Quietly devastating and very hard to put down.",
    price: "£12.99"
  },
  {
    title: "The Glass Orchard",
    author: "Idris Calloway",
    genre: "Literary Fiction",
    blurb: "Three generations of a hill-farming family argue over one glasshouse and the secrets it has kept. Our most-recommended novel this autumn.",
    price: "£11.50"
  },
  {
    title: "Low Tide at Saint Brannoc",
    author: "Nell Easterbrook",
    genre: "Literary Fiction",
    blurb: "When the causeway floods, a stranded ferry captain and a visiting archivist must share a single night and a single lighthouse.",
    price: "£10.99"
  },
  {
    title: "Brine and Bread",
    author: "Ruth Anselm",
    genre: "Poetry",
    blurb: "Poems about kitchens, coastlines and the small rituals that hold a family together. Short enough to read aloud over breakfast.",
    price: "£9.50"
  },
  {
    title: "Notes from a Slow Railway",
    author: "Kit Harrowgate",
    genre: "Poetry",
    blurb: "A poet rides a branch line from end to end and writes a stanza at every stop. Wry, tender and full of wet platforms.",
    price: "£8.99"
  },
  {
    title: "The Orchard of Small Hours",
    author: "Dana Quill",
    genre: "Poetry",
    blurb: "Sleepless night poems set in an abandoned fruit farm. Staff favourite for anyone who likes their verse precise and a little eerie.",
    price: "£10.00"
  },
  {
    title: "A City Made of Ledgers",
    author: "Peter Lindqvist",
    genre: "History",
    blurb: "How account books, not kings, quietly shaped the trading port of Veldmouth over four centuries. Meticulously researched and surprisingly funny.",
    price: "£18.99"
  },
  {
    title: "The Salt Road",
    author: "Marisol Ferreira",
    genre: "History",
    blurb: "A coastal history of the smugglers, merchants and ordinary carters who moved salt inland before the railways arrived.",
    price: "£16.50"
  },
  {
    title: "Ink and Empire",
    author: "Samuel Okonedo",
    genre: "History",
    blurb: "The printing presses of one small market town and the pamphlets that travelled from them. A gentle look at how news once spread.",
    price: "£14.00"
  },
  {
    title: "Hettie and the Clockwork Gull",
    author: "Bea Tanaka",
    genre: "Young Readers",
    blurb: "Ages 8 and up. A curious girl repairs a mechanical seabird and discovers it has been carrying messages for the lighthouse keepers.",
    price: "£7.99"
  },
  {
    title: "The Moon Who Forgot Her Name",
    author: "Poppy Linwood",
    genre: "Young Readers",
    blurb: "Ages 4 and up. A lonely moon goes looking for her name across the night sky, with a great deal of help from the owls.",
    price: "£6.50"
  },
  {
    title: "Ferdinand's Very Long Scarf",
    author: "Oskar Brennan",
    genre: "Young Readers",
    blurb: "Ages 5 and up. Ferdinand knits a scarf so long it reaches the next village, and then has to work out how to get it back.",
    price: "£6.99"
  },
  {
    title: "The Quiet Mathematics of Bees",
    author: "Inés Halloran",
    genre: "Science",
    blurb: "A beekeeper turned statistician explains how hives make decisions without a leader. Clear, warm and full of pleasant surprises.",
    price: "£13.99"
  },
  {
    title: "Under the Ice, Breathing",
    author: "Tobias Wren",
    genre: "Science",
    blurb: "Field notes from a decade studying life beneath frozen lakes. Vivid, careful and honest about how much is still unknown.",
    price: "£15.50"
  },
  {
    title: "A Field Guide to Ordinary Weather",
    author: "June Castellano",
    genre: "Science",
    blurb: "Why the drizzle, the fog and the sudden August downpour behave the way they do, explained with a notebook and a good coat.",
    price: "£12.00"
  }
];

const EVENTS = [
  {
    title: "Winter Reading with Ana Morrow",
    start: "2026-11-21T18:30",
    kind: "Reading",
    description: "Ana Morrow reads from her new collection of coastal stories, followed by questions and a book signing. Tickets are free; please reserve a seat at the till."
  },
  {
    title: "Book Club: The Tidewater Letters",
    start: "2026-12-03T19:00",
    kind: "Book club",
    description: "Our monthly evening group discusses this season's choice over mulled cider. New members are always welcome, and you do not need to have finished the book."
  },
  {
    title: "Kids' Story Time: Winter Animals",
    start: "2026-12-05T10:30",
    kind: "Story time",
    description: "Stories, songs and a craft table for children aged 3 to 7. Parents and carers stay with their little ones. About 40 minutes."
  },
  {
    title: "Open Mic Poetry Night",
    start: "2026-12-12T19:30",
    kind: "Poetry",
    description: "Read something of your own or something you love. Three minutes per reader, sign-up sheet at the door. Bring a poem and a friend."
  },
  {
    title: "Gift Wrapping Afternoon",
    start: "2026-12-19T13:00",
    kind: "Workshop",
    description: "Our staff wrap your purchases in brown paper and string, free of charge, while you browse. Donations to the local library trust are appreciated."
  }
];

// Shared event helpers, used by the home and events pages.

// The start of an event as a Date in the reader's local time zone.
function eventStart(event) {
  var parts = event.start.split('T');
  var date = parts[0].split('-').map(Number);
  var time = parts[1].split(':').map(Number);
  return new Date(date[0], date[1] - 1, date[2], time[0], time[1]);
}

function formatEventDate(date) {
  return date.toLocaleString('en-GB', {
    weekday: 'long',
    day: 'numeric',
    month: 'long',
    year: 'numeric',
    hour: 'numeric',
    minute: '2-digit'
  });
}

// Events starting on or after today's local date, soonest first. An event on today's date is still upcoming.
function upcomingEvents() {
  var today = new Date();
  today = new Date(today.getFullYear(), today.getMonth(), today.getDate());
  return EVENTS.filter(function (event) {
    return eventStart(event) >= today;
  }).sort(function (a, b) {
    return eventStart(a) - eventStart(b);
  });
}

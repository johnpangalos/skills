import { test, describe } from 'node:test';
import assert from 'node:assert/strict';
import { useSite, withPage, PAGES } from './helpers.mjs';

const site = useSite();

describe('page structure', () => {
  for (const file of PAGES) {
    test(`${file} has lang, a title, one h1, no skipped heading levels and all landmarks`, () =>
      withPage(site.browser, {}, async (page) => {
        await page.goto(`${site.base}/${file}`);
        const info = await page.evaluate(() => {
          const levels = [...document.querySelectorAll('h1, h2, h3, h4, h5, h6')]
            .map((h) => Number(h.tagName[1]));
          return {
            lang: document.documentElement.lang,
            title: document.title,
            h1: document.querySelectorAll('h1').length,
            skipped: levels.some((level, i) => i > 0 && level > levels[i - 1] + 1),
            landmarks: ['header', 'nav[aria-label]', 'main', 'footer'].every((sel) => document.querySelector(sel) !== null),
            covers: [...document.querySelectorAll('.cover')].every((c) => c.getAttribute('aria-hidden') === 'true')
          };
        });
        assert.equal(info.lang, 'en');
        assert.ok(info.title.length > 0);
        assert.equal(info.h1, 1);
        assert.equal(info.skipped, false);
        assert.equal(info.landmarks, true);
        assert.equal(info.covers, true);
      }));
  }

  test('each page has a unique title', () =>
    withPage(site.browser, {}, async (page) => {
      const titles = [];
      for (const file of PAGES) {
        await page.goto(`${site.base}/${file}`);
        titles.push(await page.title());
      }
      assert.equal(new Set(titles).size, PAGES.length);
    }));
});

describe('focus and motion', () => {
  test('skip link is off-screen until focused, then moves to #main', () =>
    withPage(site.browser, {}, async (page) => {
      await page.goto(`${site.base}/books.html`);
      const skip = page.locator('.skip-link');
      assert.ok((await skip.boundingBox()).y < 0, 'hidden before focus');
      await page.keyboard.press('Tab');
      assert.equal(await page.evaluate(() => document.activeElement.classList.contains('skip-link')), true);
      assert.ok((await skip.boundingBox()).y >= 0, 'visible on focus');
      await page.keyboard.press('Enter');
      assert.equal(await page.evaluate(() => location.hash), '#main');
    }));

  test('keyboard focus on a control shows a visible outline', () =>
    withPage(site.browser, {}, async (page) => {
      await page.goto(`${site.base}/books.html`);
      await page.focus('#genre-select');
      const style = await page.evaluate(() => {
        const el = document.getElementById('genre-select');
        return { focusVisible: el.matches(':focus-visible'), outline: getComputedStyle(el).outlineStyle };
      });
      assert.equal(style.focusVisible, true);
      assert.equal(style.outline, 'solid');
    }));

  test('prefers-reduced-motion removes transitions and animations', () =>
    withPage(site.browser, { reducedMotion: 'reduce' }, async (page) => {
      await page.goto(`${site.base}/books.html`);
      const durations = await page.evaluate(() => {
        const el = document.querySelector('.nav-toggle');
        return getComputedStyle(el).transitionDuration + ' ' + getComputedStyle(el).animationDuration;
      });
      assert.equal(durations, '0s 0s');
    }));
});

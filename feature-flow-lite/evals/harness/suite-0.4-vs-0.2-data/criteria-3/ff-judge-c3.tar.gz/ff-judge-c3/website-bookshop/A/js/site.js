// Shared helpers for every page, loaded before the page scripts. They live on window.Marginalia.
(function () {
  'use strict';

  const WEEKDAYS = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
  const MONTHS = ['January', 'February', 'March', 'April', 'May', 'June', 'July',
    'August', 'September', 'October', 'November', 'December'];

  function slugify(text) {
    return String(text).trim().toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-+|-+$/g, '');
  }

  // 'YYYY-MM-DD' becomes a local date, so no UTC shift.
  function parseDay(iso) {
    const parts = iso.split('-').map(Number);
    return new Date(parts[0], parts[1] - 1, parts[2]);
  }

  function formatDay(date) {
    return WEEKDAYS[date.getDay()] + ' ' + date.getDate() + ' ' + MONTHS[date.getMonth()] + ' ' + date.getFullYear();
  }

  // Events dated today or later, in the order given. "Today" is the visitor's local day.
  function upcomingEvents(events) {
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    return events.filter(function (event) {
      return parseDay(event.date) >= today;
    });
  }

  window.Marginalia = {
    slugify: slugify,
    parseDay: parseDay,
    formatDay: formatDay,
    upcomingEvents: upcomingEvents
  };
})();

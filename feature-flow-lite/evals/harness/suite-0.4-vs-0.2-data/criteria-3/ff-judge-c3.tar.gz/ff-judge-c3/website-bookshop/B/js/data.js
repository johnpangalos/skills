// Shop content shared by every page. Loaded as a classic script before main.js.
window.MarginaliaData = {
  shop: {
    name: 'Marginalia Books',
    street: "14 Tanner's Row",
    town: 'Ashcombe',
    postcode: 'AS4 2LB',
    phone: '01632 960417',
    email: 'hello@marginalia.example'
  },

  // Monday first. Times are 24-hour local times.
  hours: [
    { day: 'Monday', open: '10:00', close: '18:00' },
    { day: 'Tuesday', open: '10:00', close: '18:00' },
    { day: 'Wednesday', open: '10:00', close: '18:00' },
    { day: 'Thursday', open: '10:00', close: '20:00' },
    { day: 'Friday', open: '10:00', close: '20:00' },
    { day: 'Saturday', open: '10:00', close: '18:00' },
    { day: 'Sunday', open: '11:00', close: '16:00' }
  ],

  books: [
    { title: 'The Salt Road', author: 'Ines Halloran', genre: 'Fiction', price: 12.99,
      description: 'A retired ferry pilot takes one last crossing along a coastline that is slowly giving itself back to the sea.' },
    { title: "The Lantern Keeper's Daughter", author: 'Miriam Fell', genre: 'Fiction', price: 9.99,
      description: 'Three generations of women keep a light burning on a rock nobody visits any more, until the letters start to arrive.' },
    { title: 'Quiet Arithmetic', author: 'Owen Pask', genre: 'Fiction', price: 11.5,
      description: 'A maths teacher in a failing seaside town starts a secret ledger of every kindness he is shown, and then has to explain it.' },

    { title: 'Low Tide Hymnal', author: 'Nadia Brisk', genre: 'Poetry', price: 10,
      description: 'Poems set on mudflats, in kitchens and on night buses, each one holding a single breath for as long as it can.' },
    { title: 'Ink Left in the Bottle', author: 'Callum Reyes', genre: 'Poetry', price: 14,
      description: "Forty years of collected poems, with pencilled notes in the margins from the poet's late sister, who typed the first drafts." },
    { title: 'The Orchard Ledger', author: 'Priya Narayan', genre: 'Poetry', price: 9.5,
      description: 'Short lyric poems about apples, debts, and the people who keep coming back to pick what is left in the grass.' },

    { title: 'Against Tidiness', author: 'Helena Marsh', genre: 'Essays', price: 13,
      description: 'Eleven essays on untidy desks, unfinished books and the pleasure of leaving a thing half-read on purpose.' },
    { title: 'Notes from the Reading Room', author: 'Gideon Abara', genre: 'Essays', price: 15,
      description: 'A decade behind the desk of a public library, on what strangers borrow, what they hide, and why they come back.' },
    { title: 'Small Rooms', author: 'Juno Ferrier', genre: 'Essays', price: 12.5,
      description: 'A slim book about houses, the rooms we keep for ourselves, and the furniture we cannot bear to give away.' },

    { title: 'The Printers of Ashcombe Lane', author: 'Edward Quayle', genre: 'History', price: 24,
      description: "How one street of print shops kept a town's news alive through three wars and a flood, told through the printers' own ledgers." },
    { title: 'A Map Drawn in Wet Ink', author: 'Renata Solis', genre: 'History', price: 19.99,
      description: 'Surveyors, smugglers and cartographers who made the north-west coast a little less of a mystery, and a little more of a dispute.' },
    { title: 'Tallow and Candlelight', author: 'Peter Hobday', genre: 'History', price: 17.5,
      description: 'Everyday domestic life in the nineteenth century, measured out in candles, soap and what a household could afford.' },

    { title: 'Hedgerow Calendar', author: 'Sunniva Lowe', genre: 'Nature & Place', price: 16.99,
      description: 'A month-by-month guide to the wild food, birdsong and weather along the hedges around one small village.' },
    { title: 'The Tideline', author: 'Oskar Lind', genre: 'Nature & Place', price: 18,
      description: 'Walks along the marsh edge in every season, with notes on the birds that wait out the winter on the mud.' },
    { title: 'Stone and Weather', author: 'Eilidh Morrow', genre: 'Nature & Place', price: 14.99,
      description: 'A field guide to reading the rock beneath our feet, and to the old villages that were built out of it.' }
  ],

  events: [
    { title: 'Autumn Poetry Evening', date: '2026-10-14', start: '19:00', end: '21:00', booking: true,
      description: 'Five local poets read new work in the back room, followed by an open floor and mulled cider.' },
    { title: 'Halloween Story Time', date: '2026-10-31', start: '11:00', end: '11:45', booking: false,
      description: 'Spooky picture books for under-sevens, with paper bats to take home.' },
    { title: 'Book Club: The Salt Road', date: '2026-12-03', start: '18:30', end: '20:00', booking: true,
      description: "Our monthly book club talks about Ines Halloran's novel. New members are welcome, and copies are on the counter." },
    { title: "Kids' Winter Story Time", date: '2026-12-05', start: '11:00', end: '11:45', booking: false,
      description: 'Winter stories and a song for ages three to six. Wrap up warm, the back door is draughty.' },
    { title: 'Reading: Renata Solis on the Northern Coast', date: '2026-12-12', start: '19:00', end: '20:30', booking: true,
      description: 'The author of A Map Drawn in Wet Ink reads from her new chapter and answers questions about the coast.' },
    { title: 'Letterpress Workshop', date: '2026-12-19', start: '10:00', end: '13:00', booking: true,
      description: 'Set a line of type by hand and pull a print on our old press. Aprons and materials are provided.' },
    { title: 'Essay Club: Small Rooms', date: '2027-01-16', start: '18:30', end: '20:00', booking: false,
      description: "A relaxed evening discussing Juno Ferrier's essays. Bring a favourite room and a chair." },
    { title: 'Open Mic for Poets', date: '2027-02-06', start: '19:00', end: '21:30', booking: false,
      description: 'Three minutes each, any kind of poem. Sign up at the door from 18:45. The listeners are the best part.' }
  ]
};

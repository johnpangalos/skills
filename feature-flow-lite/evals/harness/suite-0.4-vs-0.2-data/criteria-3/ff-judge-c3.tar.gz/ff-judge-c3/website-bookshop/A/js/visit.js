// Visit page: contact form validation. The form is a demo and sends nothing.
(function () {
  'use strict';

  const form = document.getElementById('contact-form');
  const statusBox = document.getElementById('form-status');
  const REQUIRED = ['name', 'email', 'message'];
  const EMPTY_MESSAGES = {
    name: 'Please enter your name.',
    email: 'Please enter your email address.',
    message: 'Please write a message.'
  };
  // Dots only separate non-empty parts: no leading, trailing or doubled dots, and the domain needs one.
  const EMAIL_PATTERN = /^[^\s@.]+(?:\.[^\s@.]+)*@[^\s@.]+(?:\.[^\s@.]+)+$/;

  // Returns an error message for the field, or an empty string when it is valid.
  function problemWith(field) {
    const value = field.value.trim();
    if (!value) {
      return EMPTY_MESSAGES[field.name];
    }
    if (field.name === 'email' && !EMAIL_PATTERN.test(value)) {
      return 'Please enter an email address like name@example.com.';
    }
    return '';
  }

  function showError(field, message) {
    const error = document.createElement('p');
    error.className = 'field-error';
    error.id = field.id + '-error';
    error.textContent = message;
    field.parentNode.appendChild(error);
    field.setAttribute('aria-invalid', 'true');
    field.setAttribute('aria-describedby', error.id);
  }

  function clearError(field) {
    const error = document.getElementById(field.id + '-error');
    if (error) {
      error.remove();
    }
    field.removeAttribute('aria-invalid');
    field.removeAttribute('aria-describedby');
  }

  function showDemoMessage() {
    statusBox.textContent = 'Thank you for your message. This is a demo site, so nothing was sent. ' +
      'To reach the shop, please write to hello@marginalia.example and we will reply.';
    statusBox.focus();
  }

  form.addEventListener('submit', function (event) {
    event.preventDefault();

    let firstInvalid = null;
    REQUIRED.forEach(function (name) {
      const field = form.elements[name];
      clearError(field);
      const message = problemWith(field);
      if (message) {
        showError(field, message);
        if (!firstInvalid) {
          firstInvalid = field;
        }
      }
    });

    if (firstInvalid) {
      statusBox.textContent = 'Please check the highlighted fields.';
      firstInvalid.focus();
      return;
    }

    form.reset();
    showDemoMessage();
  });
})();

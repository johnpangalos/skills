import { test, describe } from 'node:test';
import assert from 'node:assert/strict';
import { useSite, withPage, watchErrors, PAGES } from './helpers.mjs';

const LABELS = ['Home', 'Books', 'Events', 'Visit'];
const HREFS = ['index.html', 'books.html', 'events.html', 'visit.html'];
const MOBILE = { width: 360, height: 740 };

const site = useSite();

describe('shared navigation', () => {
  for (const file of PAGES) {
    test(`${file} has the shared nav with aria-current on its own link only`, () =>
      withPage(site.browser, {}, async (page) => {
        await page.goto(`${site.base}/${file}`);
        const links = await page.$$eval('.site-nav a', (as) => as.map((a) => ({
          text: a.textContent,
          href: a.getAttribute('href'),
          current: a.getAttribute('aria-current')
        })));
        assert.deepEqual(links.map((l) => l.text), LABELS);
        assert.deepEqual(links.map((l) => l.href), HREFS);
        assert.deepEqual(links.filter((l) => l.current === 'page').map((l) => l.href), [file]);
        assert.equal(await page.locator('.site-name').getAttribute('href'), 'index.html');
      }));
  }
});

describe('mobile nav toggle', () => {
  test('toggle opens the nav, and Escape closes it and returns focus to the button', () =>
    withPage(site.browser, { viewport: MOBILE }, async (page) => {
      const errors = watchErrors(page);
      await page.goto(`${site.base}/books.html`);
      const toggle = page.locator('.nav-toggle');
      const nav = page.locator('#site-nav');
      assert.equal(await nav.isVisible(), false);
      assert.equal(await toggle.getAttribute('aria-expanded'), 'false');

      await toggle.click();
      assert.equal(await toggle.getAttribute('aria-expanded'), 'true');
      assert.equal(await toggle.getAttribute('aria-controls'), 'site-nav');
      assert.equal(await nav.isVisible(), true);

      await page.keyboard.press('Escape');
      assert.equal(await nav.isVisible(), false);
      assert.equal(await toggle.getAttribute('aria-expanded'), 'false');
      assert.equal(await page.evaluate(() => document.activeElement.classList.contains('nav-toggle')), true);
      assert.deepEqual(errors, []);
    }));

  test('Escape while the menu is closed does nothing and logs no error', () =>
    withPage(site.browser, { viewport: MOBILE }, async (page) => {
      const errors = watchErrors(page);
      await page.goto(`${site.base}/index.html`);
      await page.keyboard.press('Escape');
      assert.equal(await page.locator('.nav-toggle').getAttribute('aria-expanded'), 'false');
      assert.equal(await page.locator('#site-nav').isVisible(), false);
      assert.deepEqual(errors, []);
    }));

  test('toggle opens from the keyboard with Enter', () =>
    withPage(site.browser, { viewport: MOBILE }, async (page) => {
      await page.goto(`${site.base}/events.html`);
      await page.focus('.nav-toggle');
      await page.keyboard.press('Enter');
      assert.equal(await page.locator('.nav-toggle').getAttribute('aria-expanded'), 'true');
      assert.equal(await page.locator('#site-nav').isVisible(), true);
    }));

  test('Tab moves through the open menu links in order', () =>
    withPage(site.browser, { viewport: MOBILE }, async (page) => {
      await page.goto(`${site.base}/visit.html`);
      await page.locator('.nav-toggle').click();
      const order = [];
      for (let i = 0; i < LABELS.length; i += 1) {
        await page.keyboard.press('Tab');
        order.push(await page.evaluate(() => document.activeElement.textContent));
      }
      assert.deepEqual(order, LABELS);
    }));

  test('opened menu, then window widened past the breakpoint: nav stays visible', () =>
    withPage(site.browser, { viewport: MOBILE }, async (page) => {
      await page.goto(`${site.base}/books.html`);
      await page.locator('.nav-toggle').click();
      await page.setViewportSize({ width: 1024, height: 740 });
      assert.equal(await page.locator('#site-nav').isVisible(), true);
      assert.equal(await page.locator('.nav-toggle').isVisible(), false);
      const links = await page.locator('#site-nav a').count();
      assert.equal(links, 4);
    }));
});

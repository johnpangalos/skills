// Events page: renders every event from the shared data, in date order.
(function () {
  'use strict';

  const { parseDay, formatDay, upcomingEvents } = window.Marginalia;

  const list = document.getElementById('event-list');

  function buildEvent(event) {
    const item = document.createElement('li');
    item.className = 'event-card';

    const title = document.createElement('h2');
    title.className = 'event-title';
    title.textContent = event.title;

    const when = document.createElement('p');
    when.className = 'event-when';
    const time = document.createElement('time');
    time.dateTime = event.date;
    time.textContent = formatDay(parseDay(event.date));
    when.append(time, ' at ' + event.start);

    const description = document.createElement('p');
    description.className = 'event-description';
    description.textContent = event.description;

    const booking = document.createElement('p');
    booking.className = 'event-booking';
    booking.textContent = event.cost + ' · ' + (event.bookingRequired ? 'Booking required' : 'No booking needed');

    item.append(title, when, description, booking);
    return item;
  }

  // Past events drop off the list; when none remain, say so instead of showing an empty list.
  const upcoming = upcomingEvents(EVENTS);
  if (upcoming.length === 0) {
    const note = document.createElement('p');
    note.textContent = 'There are no upcoming events right now. Check back soon.';
    list.replaceWith(note);
  } else {
    list.replaceChildren(...upcoming.map(buildEvent));
  }
})();

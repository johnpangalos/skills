'use strict';

const { test, before, after } = require('node:test');
const assert = require('node:assert/strict');
const { chromium, startServer, stopServer, watchErrors } = require('./helpers');

let server;
let base;
let browser;

before(async function () {
  ({ server, base } = await startServer());
  browser = await chromium.launch();
});

after(async function () {
  await browser.close();
  await stopServer(server);
});

test('events page lists at least 5 events, all after 2026-11-16, in date order with full dates', async function () {
  const context = await browser.newContext();
  const page = await context.newPage();
  const errors = watchErrors(page);
  await page.clock.setFixedTime(new Date(2026, 10, 16, 10));
  await page.goto(base + '/events.html');
  const events = await page.$$eval('#event-list > li', function (items) {
    return items.map(function (item) {
      return {
        time: item.querySelector('time').getAttribute('datetime'),
        when: item.querySelector('time').textContent,
        text: item.textContent
      };
    });
  });
  assert.ok(events.length >= 5, 'expected at least 5 events, got ' + events.length);
  events.forEach(function (event, index) {
    assert.ok(event.time > '2026-11-16', event.time + ' is not after 2026-11-16');
    assert.match(event.when, /^(Sunday|Monday|Tuesday|Wednesday|Thursday|Friday|Saturday) \d{1,2} [A-Z][a-z]+ \d{4}$/);
    assert.match(event.text, /Booking required|No booking needed/);
    if (index > 0) {
      assert.ok(events[index - 1].time < event.time, 'events out of order at ' + index);
    }
  });
  assert.equal(events[0].when, 'Saturday 21 November 2026');
  assert.equal(events[0].time, '2026-11-21');
  assert.deepEqual(errors, []);
  await context.close();
});

test('event dates are built as local dates, so the weekday never shifts by a day', async function () {
  const context = await browser.newContext();
  const page = await context.newPage();
  await page.clock.setFixedTime(new Date(2026, 10, 16, 10));
  await page.goto(base + '/events.html');
  const shown = await page.$$eval('#event-list time', function (times) {
    return times.map(function (time) { return time.textContent; });
  });
  const dates = await page.evaluate(function () {
    return EVENTS.map(function (event) { return event.date; });
  });
  const expected = dates.map(function (iso) {
    const parts = iso.split('-').map(Number);
    const date = new Date(parts[0], parts[1] - 1, parts[2]);
    const weekday = date.toLocaleDateString('en-GB', { weekday: 'long' });
    return weekday + ' ' + date.getDate() + ' ' + date.toLocaleDateString('en-GB', { month: 'long' }) + ' ' + date.getFullYear();
  });
  assert.deepEqual(shown, expected);
  await context.close();
});

// Dates from the shared data, read in the page, so expectations follow the data rather than a fixed list.
async function dataDates(page) {
  return page.evaluate(function () {
    return EVENTS.map(function (event) { return event.date; });
  });
}

async function shownDates(page, selector) {
  return page.$$eval(selector, function (times) {
    return times.map(function (time) { return time.getAttribute('datetime'); });
  });
}

test('home page shows the next two or three upcoming events linking to events.html', async function () {
  const context = await browser.newContext();
  const page = await context.newPage();
  const errors = watchErrors(page);
  await page.clock.setFixedTime(new Date(2026, 10, 16, 10));
  await page.goto(base + '/index.html');
  const teaser = await shownDates(page, '#event-teaser > li time');
  const dates = await dataDates(page);
  assert.equal(teaser.length, 3);
  assert.deepEqual(teaser, dates.filter(function (iso) { return iso >= '2026-11-16'; }).slice(0, 3));
  assert.equal(await page.getAttribute('a[href="events.html"]', 'href'), 'events.html');
  assert.deepEqual(errors, []);
  await context.close();
});

test('home staff picks come from the shared book data and deep-link into the filter', async function () {
  const context = await browser.newContext();
  const page = await context.newPage();
  await page.goto(base + '/index.html');
  const picks = await page.$$eval('#staff-picks li', function (items) {
    return items.map(function (item) {
      return {
        title: item.querySelector('h3').textContent,
        link: item.querySelector('a').getAttribute('href')
      };
    });
  });
  assert.equal(picks.length, 3);
  const fromData = await page.evaluate(function () {
    return BOOKS.filter(function (book) { return book.staffPick; }).slice(0, 3).map(function (book) { return book.title; });
  });
  assert.deepEqual(picks.map(function (pick) { return pick.title; }), fromData);
  assert.equal(picks[0].link, 'books.html?genre=mystery');
  await context.close();
});

test('the day boundary is the visitor\'s local day: an event stays listed all day and drops the next morning', async function () {
  const context = await browser.newContext();
  const page = await context.newPage();
  await page.clock.setFixedTime(new Date(2026, 10, 21, 23, 30));
  await page.goto(base + '/events.html');
  assert.equal((await shownDates(page, '#event-list time'))[0], '2026-11-21');
  await page.clock.setFixedTime(new Date(2026, 10, 22, 0, 0));
  await page.goto(base + '/events.html');
  assert.equal((await shownDates(page, '#event-list time'))[0], '2026-11-28');
  await context.close();
});

test('past events drop out of the events page and the home teaser as the day moves on', async function () {
  const context = await browser.newContext();
  const page = await context.newPage();
  const errors = watchErrors(page);
  await page.clock.setFixedTime(new Date(2026, 10, 25, 10));
  await page.goto(base + '/events.html');
  const dates = await dataDates(page);
  const upcoming = dates.filter(function (iso) { return iso >= '2026-11-25'; });
  assert.ok(upcoming.length < dates.length, 'the data should include events that have already passed');
  const listed = await shownDates(page, '#event-list time');
  assert.deepEqual(listed, upcoming);
  assert.ok(!listed.includes('2026-11-21'), 'the 21 November event should have dropped off');
  await page.goto(base + '/index.html');
  assert.deepEqual(await shownDates(page, '#event-teaser > li time'), upcoming.slice(0, 3));
  assert.deepEqual(errors, []);
  await context.close();
});

test('with every event past, the events page and home teaser say so instead of showing an empty list', async function () {
  const context = await browser.newContext();
  const page = await context.newPage();
  const errors = watchErrors(page);
  await page.clock.setFixedTime(new Date(2027, 0, 10, 10));
  await page.goto(base + '/events.html');
  assert.equal(await page.locator('#event-list').count(), 0);
  assert.match(await page.textContent('main'), /There are no upcoming events right now\. Check back soon\./);
  await page.goto(base + '/index.html');
  assert.equal(await page.locator('#event-teaser').count(), 0);
  assert.match(await page.textContent('section[aria-labelledby="coming-up-title"]'), /No events are scheduled yet\. Check back soon\./);
  assert.deepEqual(errors, []);
  await context.close();
});

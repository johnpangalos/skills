// Home page: staff picks from the catalogue, the next few events, and an accurate note on
// whether the shop is open right now. Events use the same data and local-day rule as the events page.
(function () {
  'use strict';

  var createEl = window.Marginalia.createEl;
  var data = window.MarginaliaData;
  var now = new Date();

  // Picks are matched to the catalogue by title, so the cover and author come from the data.
  var PICKS = [
    { title: 'Low Tide Hymnal', note: 'Poems that hold a single breath for a long time, and the one we read aloud at the counter most often.' },
    { title: 'The Salt Road', note: "A ferry pilot's last crossing, along a coast that is giving itself back to the sea." },
    { title: 'The Printers of Ashcombe Lane', note: "A whole street of presses, told through the printers' own ledgers." }
  ];

  function slugify(name) {
    return name.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-+|-+$/g, '');
  }

  function bookByTitle(title) {
    return data.books.filter(function (book) { return book.title === title; })[0];
  }

  function pickItem(pick) {
    var book = bookByTitle(pick.title);
    var slug = slugify(book.genre);
    var item = createEl('li');
    var article = createEl('article', 'card pick');

    var cover = createEl('div', 'cover cover--' + slug);
    cover.setAttribute('aria-hidden', 'true');
    cover.appendChild(createEl('span', 'cover__title', book.title));
    cover.appendChild(createEl('span', 'cover__author', book.author));

    var body = createEl('div', 'card__body');
    var heading = createEl('h3');
    var link = createEl('a', null, book.title);
    link.setAttribute('href', 'books.html?genre=' + slug);
    heading.appendChild(link);
    body.appendChild(heading);
    body.appendChild(createEl('p', 'pick__author', 'by ' + book.author));
    body.appendChild(createEl('p', 'pick__note', pick.note));

    article.appendChild(cover);
    article.appendChild(body);
    item.appendChild(article);
    return item;
  }

  function eventItem(event) {
    var item = createEl('li');
    var article = createEl('article', 'card dated');
    article.appendChild(window.Marginalia.dateBadge(event.date));

    var body = createEl('div', 'card__body');
    var heading = createEl('h3');
    var link = createEl('a', null, event.title);
    link.setAttribute('href', 'events.html');
    heading.appendChild(link);
    body.appendChild(heading);

    var when = createEl('p', 'dated__when');
    var time = createEl('time', null, window.Marginalia.formatEventWhen(event));
    time.setAttribute('datetime', event.date + 'T' + event.start);
    when.appendChild(time);
    body.appendChild(when);

    article.appendChild(body);
    item.appendChild(article);
    return item;
  }

  // Minutes since midnight for a 24-hour HH:MM string.
  function toMinutes(hhmm) {
    var parts = hhmm.split(':').map(Number);
    return parts[0] * 60 + parts[1];
  }

  // The opening row for a weekday name. The hours table is Monday first, so look rows up by name.
  function hoursFor(weekday) {
    return data.hours.filter(function (row) { return row.day === weekday; })[0];
  }

  // The status sentence for the visitor's local time. Only local getters are used.
  function openingStatus(date) {
    var today = window.Marginalia.WEEKDAYS[date.getDay()];
    var tomorrow = window.Marginalia.WEEKDAYS[(date.getDay() + 1) % 7];
    var hours = hoursFor(today);
    var minutes = date.getHours() * 60 + date.getMinutes();

    if (minutes < toMinutes(hours.open)) {
      return 'Today (' + today + ') we open at ' + hours.open + ' and close at ' + hours.close + '.';
    }
    if (minutes < toMinutes(hours.close)) {
      return 'Open now until ' + hours.close + '.';
    }
    return 'Closed for today. We open again tomorrow (' + tomorrow + ') at ' +
      hoursFor(tomorrow).open + '.';
  }

  var picks = document.getElementById('home-picks');
  PICKS.forEach(function (pick) {
    picks.appendChild(pickItem(pick));
  });

  var list = document.getElementById('home-events');
  var upcoming = window.Marginalia.splitEvents(
    data.events,
    window.Marginalia.localDateKey(now)
  ).upcoming;

  upcoming.slice(0, 3).forEach(function (event) {
    list.appendChild(eventItem(event));
  });

  if (upcoming.length === 0) {
    list.appendChild(createEl('li', null, 'No events are scheduled at the moment.'));
  }

  document.getElementById('home-today').textContent = openingStatus(now);
})();

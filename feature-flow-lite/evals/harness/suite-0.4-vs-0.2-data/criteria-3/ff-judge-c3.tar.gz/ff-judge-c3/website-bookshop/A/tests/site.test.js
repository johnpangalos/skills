'use strict';

const { test, before, after } = require('node:test');
const assert = require('node:assert/strict');
const { PAGES, chromium, startServer, stopServer, watchErrors } = require('./helpers');

const NAV_HREFS = ['index.html', 'books.html', 'events.html', 'visit.html'];
let server;
let base;
let browser;

before(async function () {
  ({ server, base } = await startServer());
  browser = await chromium.launch();
});

after(async function () {
  await browser.close();
  await stopServer(server);
});

test('every page loads with no console errors and only same-origin requests', async function () {
  for (const name of PAGES) {
    const context = await browser.newContext();
    const page = await context.newPage();
    const errors = watchErrors(page);
    const origins = new Set();
    page.on('request', function (request) {
      origins.add(new URL(request.url()).origin);
    });
    await page.goto(base + '/' + name);
    await page.waitForLoadState('networkidle');
    assert.deepEqual(errors, [], name + ' logged errors');
    assert.deepEqual([...origins], [base], name + ' made off-site requests');
    await context.close();
  }
});

test('shared nav links all four pages, resolves, and aria-current marks only the current page', async function () {
  const context = await browser.newContext();
  const page = await context.newPage();
  for (const name of PAGES) {
    await page.goto(base + '/' + name);
    const links = await page.$$eval('nav[aria-label="Main"] a', function (anchors) {
      return anchors.map(function (a) {
        return { href: a.getAttribute('href'), current: a.getAttribute('aria-current') };
      });
    });
    assert.deepEqual(links.map(function (l) { return l.href; }), NAV_HREFS, name + ' nav links');
    const current = links.filter(function (l) { return l.current !== null; });
    assert.deepEqual(current, [{ href: name, current: 'page' }], name + ' aria-current');
    for (const link of links) {
      const response = await page.request.get(base + '/' + link.href);
      assert.equal(response.status(), 200, link.href + ' should resolve');
    }
  }
  await context.close();
});

test('every page has a unique title, exactly one h1, lang, viewport meta, and shared header and footer', async function () {
  const context = await browser.newContext();
  const page = await context.newPage();
  const titles = [];
  let navHtml = null;
  for (const name of PAGES) {
    await page.goto(base + '/' + name);
    titles.push(await page.title());
    assert.equal(await page.locator('h1').count(), 1, name + ' h1 count');
    assert.equal(await page.getAttribute('html', 'lang'), 'en');
    assert.equal(await page.getAttribute('meta[name="viewport"]', 'content'), 'width=device-width, initial-scale=1');
    assert.equal(await page.getAttribute('header .brand', 'href'), 'index.html');
    assert.match(await page.textContent('footer'), /14 Lantern Row/);
    assert.match(await page.textContent('footer'), /Closed Mondays/);
    assert.equal(await page.locator('header').count(), 1);
    assert.equal(await page.locator('main').count(), 1);
    assert.equal(await page.locator('footer').count(), 1);
    const nav = await page.innerHTML('nav[aria-label="Main"]');
    if (navHtml === null) {
      navHtml = nav;
    }
    const withoutCurrent = function (html) {
      return html.replace(/ aria-current="page"/g, '').replace(/ +>/g, '>');
    };
    assert.equal(withoutCurrent(nav), withoutCurrent(navHtml), name + ' nav differs');
  }
  assert.equal(new Set(titles).size, PAGES.length, 'titles must be unique: ' + titles.join(' | '));
  await context.close();
});

test('no page scrolls horizontally at 360, 768 and 1280 pixels wide', async function () {
  const context = await browser.newContext();
  for (const width of [360, 768, 1280]) {
    const page = await context.newPage();
    await page.setViewportSize({ width: width, height: 800 });
    for (const name of PAGES) {
      await page.goto(base + '/' + name);
      const scrollWidth = await page.evaluate(function () {
        return document.documentElement.scrollWidth;
      });
      assert.ok(scrollWidth <= width, name + ' at ' + width + 'px scrolls to ' + scrollWidth + 'px');
    }
    await page.close();
  }
  await context.close();
});

test('at 360px all four nav links are inside the viewport and do not overlap', async function () {
  const context = await browser.newContext();
  const page = await context.newPage();
  await page.setViewportSize({ width: 360, height: 740 });
  await page.goto(base + '/books.html');
  const boxes = [];
  for (const link of await page.locator('nav[aria-label="Main"] a').all()) {
    const box = await link.boundingBox();
    assert.ok(box.x >= 0 && box.x + box.width <= 360, 'nav link outside the 360px viewport');
    assert.ok(box.height >= 24 && box.width >= 24, 'nav link smaller than 24x24');
    boxes.push(box);
  }
  for (let i = 0; i < boxes.length; i++) {
    for (let j = i + 1; j < boxes.length; j++) {
      const a = boxes[i];
      const b = boxes[j];
      const overlap = a.x < b.x + b.width && b.x < a.x + a.width && a.y < b.y + b.height && b.y < a.y + a.height;
      assert.equal(overlap, false, 'nav links ' + i + ' and ' + j + ' overlap');
    }
  }
  await context.close();
});

test('skip link is the first focusable element, shows on focus, and moves focus to main', async function () {
  const context = await browser.newContext();
  const page = await context.newPage();
  await page.goto(base + '/index.html');
  await page.keyboard.press('Tab');
  const focused = await page.evaluate(function () {
    return document.activeElement.className;
  });
  assert.equal(focused, 'skip-link');
  const box = await page.locator('.skip-link').boundingBox();
  assert.ok(box && box.y >= 0, 'skip link should be visible when focused');
  await page.keyboard.press('Enter');
  const mainFocused = await page.evaluate(function () {
    return document.activeElement.id;
  });
  assert.equal(mainFocused, 'main');
  await context.close();
});

test('keyboard can reach the first nav link after the skip link', async function () {
  const context = await browser.newContext();
  const page = await context.newPage();
  await page.goto(base + '/events.html');
  // Skip link, then the brand link, then the first nav link.
  await page.keyboard.press('Tab');
  await page.keyboard.press('Tab');
  await page.keyboard.press('Tab');
  const text = await page.evaluate(function () {
    return document.activeElement.textContent;
  });
  assert.equal(text, 'Home');
  await context.close();
});

test('every link, button and label is at least 24px tall and wide at 360px', async function () {
  const context = await browser.newContext();
  const page = await context.newPage();
  await page.setViewportSize({ width: 360, height: 740 });
  for (const name of PAGES) {
    await page.goto(base + '/' + name);
    const targets = await page.$$eval('a[href], button, label', function (nodes) {
      return nodes.map(function (node) {
        const box = node.getBoundingClientRect();
        return { text: node.textContent.trim().slice(0, 40), width: box.width, height: box.height };
      });
    });
    assert.ok(targets.length > 0, name + ' has no targets to measure');
    for (const target of targets) {
      assert.ok(target.height >= 24 && target.width >= 24,
        name + ' target "' + target.text + '" is ' + target.width + 'x' + target.height + 'px');
    }
  }
  await context.close();
});

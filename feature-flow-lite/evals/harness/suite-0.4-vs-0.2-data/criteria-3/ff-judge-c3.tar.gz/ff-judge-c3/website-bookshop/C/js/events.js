// Events page: lists upcoming events from EVENTS in date order, using the reader's local date.
(function () {
  'use strict';

  var list = document.getElementById('event-list');
  var empty = document.getElementById('no-events');

  function eventItem(event) {
    var item = document.createElement('li');
    item.className = 'event';

    var kind = document.createElement('p');
    kind.className = 'event-kind';
    kind.textContent = event.kind;

    var title = document.createElement('h2');
    title.textContent = event.title;

    var when = document.createElement('p');
    var time = document.createElement('time');
    time.setAttribute('datetime', event.start);
    time.textContent = formatEventDate(eventStart(event));
    when.appendChild(time);

    var description = document.createElement('p');
    description.textContent = event.description;

    item.appendChild(kind);
    item.appendChild(title);
    item.appendChild(when);
    item.appendChild(description);
    return item;
  }

  var upcoming = upcomingEvents();

  empty.hidden = upcoming.length > 0;
  upcoming.forEach(function (event) {
    list.appendChild(eventItem(event));
  });
})();

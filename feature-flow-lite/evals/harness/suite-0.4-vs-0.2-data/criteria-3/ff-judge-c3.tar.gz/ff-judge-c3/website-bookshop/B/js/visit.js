// Visit page: the opening hours table and the demo contact form with its validation.
(function () {
  'use strict';

  var createEl = window.Marginalia.createEl;
  var shop = window.MarginaliaData.shop;
  var MAX_NAME = 100;
  var MAX_MESSAGE = 1000;
  var EMAIL_PATTERN = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  var FIELDS = ['name', 'email', 'message'];

  var hoursBody = document.getElementById('hours-body');
  window.MarginaliaData.hours.forEach(function (row) {
    var tr = createEl('tr');
    var th = createEl('th', null, row.day);
    th.setAttribute('scope', 'row');
    tr.appendChild(th);
    tr.appendChild(createEl('td', null, row.open + '–' + row.close));
    hoursBody.appendChild(tr);
  });

  // Each rule takes the trimmed value and returns an error message, or '' when valid.
  var rules = {
    name: function (value) {
      if (!value) return 'Please enter your name.';
      if (value.length > MAX_NAME) return 'Names can be up to ' + MAX_NAME + ' characters.';
      return '';
    },
    email: function (value) {
      if (!value) return 'Please enter your email address.';
      if (!EMAIL_PATTERN.test(value)) return 'Please enter an email address in the form name@example.com.';
      return '';
    },
    message: function (value) {
      if (!value) return 'Please enter a message.';
      if (value.length > MAX_MESSAGE) {
        return 'Messages can be up to ' + MAX_MESSAGE + ' characters. Yours is ' + value.length + '.';
      }
      return '';
    }
  };

  // Shows or clears one field's error text and aria-invalid. Returns true when the field is valid.
  function checkField(name) {
    var field = document.getElementById(name);
    var error = document.getElementById(name + '-error');
    var message = rules[name](field.value.trim());
    error.textContent = message;
    error.hidden = message === '';
    if (message) {
      field.setAttribute('aria-invalid', 'true');
    } else {
      field.removeAttribute('aria-invalid');
    }
    return message === '';
  }

  var form = document.getElementById('contact-form');
  var formStatus = document.getElementById('form-status');

  form.addEventListener('submit', function (event) {
    event.preventDefault();

    // filter() runs every check, so all errors are shown before focus moves to the first one.
    var firstInvalid = FIELDS.filter(function (name) { return !checkField(name); })[0];
    if (firstInvalid) {
      formStatus.textContent = '';
      document.getElementById(firstInvalid).focus();
      return;
    }

    var fullName = document.getElementById('name').value.trim();
    formStatus.textContent = 'Thank you, ' + fullName + '. This is a demo form, so your message was NOT sent. ' +
      'To reach the shop, email ' + shop.email + ' or call ' + shop.phone + '.';
    form.reset();
  });

  // Once a field is flagged, re-check it as the visitor types so the error clears when fixed.
  FIELDS.forEach(function (name) {
    var field = document.getElementById(name);
    field.addEventListener('input', function () {
      if (field.getAttribute('aria-invalid') === 'true') checkField(name);
    });
  });

  // Editing any field after a demo submit clears the confirmation, so it never describes old input.
  form.addEventListener('input', function () {
    formStatus.textContent = '';
  });
})();

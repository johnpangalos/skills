// Home page: staff picks and the next upcoming events, both from the shared data.
(function () {
  'use strict';

  const { slugify, parseDay, formatDay, upcomingEvents } = window.Marginalia;

  const picksList = document.getElementById('staff-picks');
  const teaserList = document.getElementById('event-teaser');

  function buildPick(book) {
    const item = document.createElement('li');
    item.className = 'pick-card';

    const title = document.createElement('h3');
    title.className = 'book-title';
    title.textContent = book.title;

    const author = document.createElement('p');
    author.className = 'book-author';
    author.textContent = 'by ' + book.author;

    const blurb = document.createElement('p');
    blurb.className = 'book-blurb';
    blurb.textContent = book.blurb;

    const more = document.createElement('a');
    more.href = 'books.html?genre=' + encodeURIComponent(slugify(book.genre));
    more.textContent = 'More ' + book.genre;
    more.className = 'standalone-link';

    item.append(title, author, blurb, more);
    return item;
  }

  function buildTeaser(event) {
    const item = document.createElement('li');
    item.className = 'teaser-event';

    const title = document.createElement('h3');
    title.className = 'event-title';
    title.textContent = event.title;

    const when = document.createElement('p');
    const time = document.createElement('time');
    time.dateTime = event.date;
    time.textContent = formatDay(parseDay(event.date));
    when.append(time, ' at ' + event.start);

    item.append(title, when);
    return item;
  }

  picksList.replaceChildren(...BOOKS.filter(function (book) {
    return book.staffPick;
  }).slice(0, 3).map(buildPick));

  const upcoming = upcomingEvents(EVENTS).slice(0, 3);
  if (upcoming.length === 0) {
    const note = document.createElement('p');
    note.textContent = 'No events are scheduled yet. Check back soon.';
    teaserList.replaceWith(note);
  } else {
    teaserList.replaceChildren(...upcoming.map(buildTeaser));
  }
})();

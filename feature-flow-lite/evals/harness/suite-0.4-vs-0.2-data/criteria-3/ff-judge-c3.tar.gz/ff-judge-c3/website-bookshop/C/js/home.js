// Home page: staff picks and the next few upcoming events, from the shared data in data.js.
(function () {
  'use strict';

  var PICK_COUNT = 3;
  var EVENT_COUNT = 3;

  function pickCard(book) {
    var item = document.createElement('li');
    item.className = 'book';

    var title = document.createElement('h3');
    title.textContent = book.title;

    var author = document.createElement('p');
    author.className = 'book-author';
    author.textContent = book.author;

    var meta = document.createElement('p');
    meta.className = 'book-meta';
    meta.textContent = book.genre + ', ' + book.price;

    item.appendChild(title);
    item.appendChild(author);
    item.appendChild(meta);
    return item;
  }

  function eventItem(event) {
    var item = document.createElement('li');
    item.className = 'event';

    var title = document.createElement('h3');
    title.textContent = event.title;

    var when = document.createElement('p');
    var time = document.createElement('time');
    time.setAttribute('datetime', event.start);
    time.textContent = formatEventDate(eventStart(event));
    when.appendChild(time);

    item.appendChild(title);
    item.appendChild(when);
    return item;
  }

  // The first book of each of the first few genres, so the picks cover the range of the catalogue.
  var pickedGenres = [];
  var picked = [];
  BOOKS.forEach(function (book) {
    if (pickedGenres.length < PICK_COUNT && pickedGenres.indexOf(book.genre) === -1) {
      pickedGenres.push(book.genre);
      picked.push(book);
    }
  });

  var picks = document.getElementById('picks');
  picked.forEach(function (book) {
    picks.appendChild(pickCard(book));
  });

  var upcoming = upcomingEvents().slice(0, EVENT_COUNT);
  var list = document.getElementById('home-events');
  if (upcoming.length === 0) {
    document.getElementById('home-events-empty').hidden = false;
  }
  upcoming.forEach(function (event) {
    list.appendChild(eventItem(event));
  });
})();

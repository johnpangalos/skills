// Site-wide checks on every page: shared nav, landmarks, no external requests, no console errors, no sideways scroll.
const { describe, it, before, after } = require('node:test');
const assert = require('node:assert/strict');
const path = require('node:path');
const { PAGES, startServer, launchBrowser, watchErrors } = require('./helpers.cjs');

const NAV = [
  ['Home', 'index.html'],
  ['Books', 'books.html'],
  ['Events', 'events.html'],
  ['Visit', 'visit.html']
];

describe('site', () => {
  let server;
  let origin;
  let browser;

  before(async () => {
    ({ server, origin } = await startServer());
    browser = await launchBrowser();
  });

  after(async () => {
    await browser.close();
    server.close();
  });

  it('every page has the same four-link nav with the current page marked', async () => {
    const context = await browser.newContext();
    const page = await context.newPage();
    for (const current of PAGES) {
      await page.goto(`${origin}/${current}`);
      const links = await page.locator('header nav[aria-label="Main"] a').evaluateAll((as) =>
        as.map((a) => ({ text: a.textContent.trim(), href: a.getAttribute('href'), current: a.getAttribute('aria-current') }))
      );
      assert.deepEqual(
        links.map((l) => [l.text, l.href]),
        NAV,
        `nav links on ${current}`
      );
      const marked = links.filter((l) => l.current === 'page').map((l) => l.href);
      assert.deepEqual(marked, [current], `aria-current on ${current}`);
      const brand = page.locator('header a.brand');
      assert.equal(await brand.textContent(), 'Marginalia Books');
      assert.equal(await brand.getAttribute('href'), 'index.html');
    }
    await context.close();
  });

  it('every page has the same footer and a skip link as its first focusable element', async () => {
    const context = await browser.newContext();
    const page = await context.newPage();
    for (const name of PAGES) {
      await page.goto(`${origin}/${name}`);
      const footer = await page.locator('footer.site-footer').innerText();
      assert.match(footer, /Marginalia Books, 14 Lantern Row, Eastmere EM3 2QB/, `footer on ${name}`);
      await page.keyboard.press('Tab');
      const focused = await page.evaluate(() => document.activeElement.textContent);
      assert.equal(focused, 'Skip to main content', `first Tab stop on ${name}`);
      assert.equal(await page.locator('.skip-link').isVisible(), true, `skip link visible on focus on ${name}`);
    }
    await context.close();
  });

  it('every nav and page link resolves to an existing page (no 404s)', async () => {
    const context = await browser.newContext();
    const page = await context.newPage();
    const failed = [];
    page.on('response', (res) => {
      if (res.status() >= 400) failed.push(`${res.status()} ${res.url()}`);
    });
    for (const name of PAGES) {
      await page.goto(`${origin}/${name}`);
      const hrefs = await page.locator('a[href]').evaluateAll((as) => as.map((a) => a.getAttribute('href')));
      for (const href of hrefs) {
        if (/^(https?:|mailto:|tel:|#)/.test(href)) continue;
        const res = await page.request.get(`${origin}/${href}`);
        assert.equal(res.status(), 200, `link ${href} from ${name}`);
      }
    }
    assert.deepEqual(failed, []);
    await context.close();
  });

  it('pages open from file:// with relative links that work', async () => {
    const context = await browser.newContext();
    const page = await context.newPage();
    const errors = watchErrors(page);
    const file = path.join(__dirname, '..', 'index.html');
    await page.goto(`file://${file}`);
    await page.click('header nav a[href="books.html"]');
    await page.waitForURL(/books\.html$/);
    assert.equal(await page.locator('h1').textContent(), 'Books');
    assert.deepEqual(errors, []);
    await context.close();
  });

  it('makes no requests to any other origin on any page', async () => {
    const context = await browser.newContext();
    const page = await context.newPage();
    const external = [];
    page.on('request', (req) => {
      const url = req.url();
      if (!url.startsWith(origin + '/')) external.push(url);
    });
    for (const name of PAGES) {
      await page.goto(`${origin}/${name}`);
      await page.waitForLoadState('networkidle');
    }
    assert.deepEqual(external, []);
    await context.close();
  });

  it('has no console errors or uncaught exceptions on load', async () => {
    const context = await browser.newContext();
    const page = await context.newPage();
    const errors = watchErrors(page);
    for (const name of PAGES) {
      await page.goto(`${origin}/${name}`);
      await page.waitForLoadState('networkidle');
    }
    assert.deepEqual(errors, []);
    await context.close();
  });

  it('has lang, a unique title, one h1, no skipped heading levels and landmarks on every page', async () => {
    const context = await browser.newContext();
    const page = await context.newPage();
    const titles = new Set();
    for (const name of PAGES) {
      await page.goto(`${origin}/${name}`);
      const info = await page.evaluate(() => ({
        lang: document.documentElement.lang,
        title: document.title,
        h1: document.querySelectorAll('h1').length,
        levels: [...document.querySelectorAll('h1,h2,h3,h4,h5,h6')].map((h) => Number(h.tagName[1])),
        landmarks: ['header', 'nav', 'main', 'footer'].every((t) => document.querySelector(t) !== null)
      }));
      assert.equal(info.lang, 'en', name);
      assert.ok(info.title.length > 0, name);
      titles.add(info.title);
      assert.equal(info.h1, 1, `one h1 on ${name}`);
      for (let i = 1; i < info.levels.length; i++) {
        assert.ok(info.levels[i] <= info.levels[i - 1] + 1, `no skipped heading level on ${name}`);
      }
      assert.equal(info.landmarks, true, `landmarks on ${name}`);
    }
    assert.equal(titles.size, PAGES.length, 'titles are unique');
    await context.close();
  });

  it('does not scroll sideways at 360, 768 or 1280 px on any page', async () => {
    const context = await browser.newContext();
    const page = await context.newPage();
    for (const width of [360, 768, 1280]) {
      await page.setViewportSize({ width, height: 800 });
      for (const name of PAGES) {
        await page.goto(`${origin}/${name}`);
        const overflow = await page.evaluate(() => document.documentElement.scrollWidth - window.innerWidth);
        assert.ok(overflow <= 0, `${name} at ${width}px overflows by ${overflow}px`);
      }
    }
    await context.close();
  });

  it('keeps a side gutter around main content at 360 px', async () => {
    const context = await browser.newContext();
    const page = await context.newPage();
    await page.setViewportSize({ width: 360, height: 800 });
    for (const name of PAGES) {
      await page.goto(`${origin}/${name}`);
      const edges = await page.locator('main h1, main h2, main p, main label, main select, main ul > li').evaluateAll((els) =>
        els.filter((el) => el.getClientRects().length).map((el) => {
          const r = el.getBoundingClientRect();
          return { tag: el.tagName, left: r.left, right: window.innerWidth - r.right };
        }));
      for (const e of edges) {
        assert.ok(e.left >= 12 && e.right >= 12, `${e.tag} on ${name} is within 12px of the edge (${e.left}, ${e.right})`);
      }
    }
    await context.close();
  });

  it('keeps nav links at least 44px tall at 360 px', async () => {
    const context = await browser.newContext();
    const page = await context.newPage();
    await page.setViewportSize({ width: 360, height: 800 });
    for (const name of PAGES) {
      await page.goto(`${origin}/${name}`);
      const heights = await page.locator('header nav a').evaluateAll((as) => as.map((a) => a.getBoundingClientRect().height));
      for (const h of heights) assert.ok(h >= 44, `nav link height ${h} on ${name}`);
    }
    await context.close();
  });
});

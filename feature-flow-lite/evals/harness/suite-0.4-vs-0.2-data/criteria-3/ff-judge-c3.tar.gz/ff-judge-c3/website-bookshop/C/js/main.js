// Shared script for every page: fills in the copyright year in the footer.
(function () {
  'use strict';

  var thisYear = String(new Date().getFullYear());
  document.querySelectorAll('[data-year]').forEach(function (node) {
    node.textContent = thisYear;
  });
})();

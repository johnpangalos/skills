// Catalogue page: renders BOOKS, filters by genre, keeps the genre in the query string.
(function () {
  'use strict';

  var select = document.getElementById('genre');
  var list = document.getElementById('book-list');
  var count = document.getElementById('count');
  var empty = document.getElementById('empty');

  function slugOf(genre) {
    return genre.toLowerCase().replace(/\s+/g, '-');
  }

  var genres = [];
  BOOKS.forEach(function (book) {
    if (genres.indexOf(book.genre) === -1) {
      genres.push(book.genre);
    }
  });
  genres.forEach(function (genre) {
    var option = document.createElement('option');
    option.value = slugOf(genre);
    option.textContent = genre;
    select.appendChild(option);
  });

  // Anything that is not a known genre (unknown, empty, hostile, repeated) means "all genres".
  function genreFromUrl() {
    var raw = new URLSearchParams(window.location.search).get('genre') || '';
    var wanted = slugOf(raw.trim());
    return genres.map(slugOf).indexOf(wanted) === -1 ? 'all' : wanted;
  }

  function bookCard(book) {
    var item = document.createElement('li');
    item.className = 'book';

    var title = document.createElement('h2');
    title.textContent = book.title;

    var author = document.createElement('p');
    author.className = 'book-author';
    author.textContent = 'by ' + book.author;

    var blurb = document.createElement('p');
    blurb.className = 'book-blurb';
    blurb.textContent = book.blurb;

    var meta = document.createElement('p');
    meta.className = 'book-meta';
    meta.textContent = book.genre + ' · ' + book.price;

    item.appendChild(title);
    item.appendChild(author);
    item.appendChild(blurb);
    item.appendChild(meta);
    return item;
  }

  function render(slug) {
    var shown = BOOKS.filter(function (book) {
      return slug === 'all' || slugOf(book.genre) === slug;
    });

    list.textContent = '';
    shown.forEach(function (book) {
      list.appendChild(bookCard(book));
    });

    select.value = slug;
    count.textContent = 'Showing ' + shown.length + ' of ' + BOOKS.length + ' books';
    empty.hidden = shown.length > 0;
  }

  select.addEventListener('change', function () {
    var slug = select.value;
    var url = slug === 'all' ? window.location.pathname : '?genre=' + encodeURIComponent(slug);
    history.pushState({ genre: slug }, '', url);
    render(slug);
  });

  window.addEventListener('popstate', function () {
    render(genreFromUrl());
  });

  render(genreFromUrl());
})();

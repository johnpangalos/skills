import { test, describe } from 'node:test';
import assert from 'node:assert/strict';
import { useSite, withPage, watchErrors, PAGES } from './helpers.mjs';

const site = useSite();

const FOOTER_HOURS = 'Hours: Mon–Wed & Sat 10–18 · Thu–Fri 10–20 · Sun 11–16.';

// Europe/London is on GMT in November, so these local times match the UTC instants used here.
// 2026-11-16 is a Monday, so the tomorrow line names Tuesday.
describe('home opening status follows the local clock', () => {
  const cases = [
    ['before opening', '2026-11-16T09:30:00+00:00', 'Today (Monday) we open at 10:00 and close at 18:00.'],
    ['while open', '2026-11-16T12:00:00+00:00', 'Open now until 18:00.'],
    ['after closing', '2026-11-16T19:00:00+00:00', 'Closed for today. We open again tomorrow (Tuesday) at 10:00.']
  ];

  for (const [name, instant, expected] of cases) {
    test(`${name} shows the matching sentence`, () =>
      withPage(site.browser, { timezoneId: 'Europe/London' }, async (page) => {
        const errors = watchErrors(page);
        await page.clock.setFixedTime(Date.parse(instant));
        await page.goto(`${site.base}/index.html`);
        assert.equal(await page.textContent('#home-today'), expected);
        assert.deepEqual(errors, []);
      }));
  }
});

describe('home staff picks come from the catalogue', () => {
  test('three picks, each with a decorative cover and a link to its genre', () =>
    withPage(site.browser, {}, async (page) => {
      const errors = watchErrors(page);
      await page.goto(`${site.base}/index.html`);
      const picks = await page.$$eval('#home-picks .pick', (articles) => articles.map((a) => ({
        title: a.querySelector('h3 a')?.textContent,
        href: a.querySelector('h3 a')?.getAttribute('href'),
        author: a.querySelector('.pick__author')?.textContent,
        coverHidden: a.querySelector('.cover')?.getAttribute('aria-hidden')
      })));
      assert.deepEqual(picks.map((p) => p.title), ['Low Tide Hymnal', 'The Salt Road', 'The Printers of Ashcombe Lane']);
      assert.deepEqual(picks.map((p) => p.href), ['books.html?genre=poetry', 'books.html?genre=fiction', 'books.html?genre=history']);
      assert.deepEqual(picks.map((p) => p.author), ['by Nadia Brisk', 'by Ines Halloran', 'by Edward Quayle']);
      assert.ok(picks.every((p) => p.coverHidden === 'true'));
      assert.deepEqual(errors, []);
    }));
});

describe('footer hours summary', () => {
  test('is the same accurate summary on all four pages', () =>
    withPage(site.browser, {}, async (page) => {
      for (const file of PAGES) {
        await page.goto(`${site.base}/${file}`);
        const footer = await page.textContent('footer');
        assert.ok(footer.includes(FOOTER_HOURS), `${file}: ${footer}`);
        assert.ok(!footer.includes('most days'), file);
      }
    }));
});

describe('hero call-to-action focus ring', () => {
  test('keyboard focus outline is visible against the hero background', () =>
    withPage(site.browser, {}, async (page) => {
      await page.goto(`${site.base}/index.html`);
      const count = await page.locator('.hero a').count();
      assert.ok(count >= 2);
      // Tab until each hero link has keyboard focus, then compare its outline with the band.
      const seen = [];
      for (let i = 0; i < 20 && seen.length < count; i++) {
        await page.keyboard.press('Tab');
        const info = await page.evaluate(() => {
          const el = document.activeElement;
          const hero = el && el.closest('.hero');
          if (!hero) return null;
          const s = getComputedStyle(el);
          return {
            text: el.textContent.trim(),
            outline: s.outlineColor,
            width: parseFloat(s.outlineWidth),
            style: s.outlineStyle,
            bg: getComputedStyle(hero).backgroundColor
          };
        });
        if (info) seen.push(info);
      }
      assert.equal(seen.length, count);
      for (const info of seen) {
        assert.notEqual(info.style, 'none', info.text);
        assert.ok(info.width >= 2, `${info.text}: outline width ${info.width}`);
        assert.notEqual(info.outline, info.bg, `${info.text}: outline matches hero background`);
      }
    }));
});

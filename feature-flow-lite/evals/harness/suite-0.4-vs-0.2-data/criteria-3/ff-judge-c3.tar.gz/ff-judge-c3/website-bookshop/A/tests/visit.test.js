'use strict';

const { test, before, after } = require('node:test');
const assert = require('node:assert/strict');
const { chromium, startServer, stopServer, watchErrors } = require('./helpers');

const EMAIL_ERROR = 'Please enter an email address like name@example.com.';
let server;
let base;
let browser;

before(async function () {
  ({ server, base } = await startServer());
  browser = await chromium.launch();
});

after(async function () {
  await browser.close();
  await stopServer(server);
});

// Opens the visit page with a marker on window; a page reload or navigation would clear it.
async function openForm(context) {
  const page = await context.newPage();
  const errors = watchErrors(page);
  await page.goto(base + '/visit.html');
  await page.evaluate(function () {
    window.marker = 'still-here';
  });
  return { page, errors };
}

async function fill(page, values) {
  for (const name of Object.keys(values)) {
    await page.fill('[name="' + name + '"]', values[name]);
  }
}

async function errorTexts(page) {
  return page.$$eval('.field-error', function (nodes) {
    return nodes.map(function (node) { return node.textContent; });
  });
}

async function markerIntact(page) {
  return page.evaluate(function () { return window.marker === 'still-here' && location.pathname.endsWith('/visit.html') && location.search === ''; });
}

test('submitting empty required fields shows errors linked to their fields and focuses the first one', async function () {
  const context = await browser.newContext();
  const { page, errors } = await openForm(context);
  await page.click('button[type="submit"]');

  assert.deepEqual(await errorTexts(page), [
    'Please enter your name.',
    'Please enter your email address.',
    'Please write a message.'
  ]);
  for (const name of ['name', 'email', 'message']) {
    const field = page.locator('[name="' + name + '"]');
    assert.equal(await field.getAttribute('aria-invalid'), 'true', name + ' aria-invalid');
    const describedBy = await field.getAttribute('aria-describedby');
    assert.equal(await page.locator('#' + describedBy).count(), 1, name + ' describedby target');
    assert.ok(describedBy.endsWith('-error'), name + ' describedby');
  }
  assert.equal(await page.evaluate(function () { return document.activeElement.name; }), 'name');
  assert.equal(await markerIntact(page), true, 'page navigated or reloaded');
  assert.deepEqual(errors, []);
  await context.close();
});

test('whitespace-only name and message count as empty', async function () {
  const context = await browser.newContext();
  const { page } = await openForm(context);
  await fill(page, { name: '   ', email: 'reader@example.com', message: '\n\t  ' });
  await page.click('button[type="submit"]');
  assert.deepEqual(await errorTexts(page), ['Please enter your name.', 'Please write a message.']);
  assert.equal(await page.getAttribute('[name="email"]', 'aria-invalid'), null);
  await context.close();
});

test('malformed emails are rejected with a message next to the field', async function () {
  const context = await browser.newContext();
  const { page } = await openForm(context);
  for (const value of ['a@b', 'foo@', '@bar.com']) {
    await fill(page, { name: 'Ada Reader', email: value, message: 'Hello there.' });
    await page.click('button[type="submit"]');
    assert.deepEqual(await errorTexts(page), [EMAIL_ERROR], value + ' should be rejected');
    assert.equal(await page.getAttribute('[name="email"]', 'aria-invalid'), 'true', value + ' aria-invalid');
    assert.equal(await page.evaluate(function () { return document.activeElement.name; }), 'email');
    assert.equal(await markerIntact(page), true, 'page navigated');
  }
  await context.close();
});

test('dots must separate non-empty parts: doubled, leading and trailing dots are rejected, dotted addresses are accepted', async function () {
  const context = await browser.newContext();
  const { page, errors } = await openForm(context);
  const malformed = ['a@b..com', 'a@b.com.', 'a..b@example.com', '.a@example.com', 'a.@example.com', 'a@.example.com'];
  for (const value of malformed) {
    await fill(page, { name: 'Ada Reader', email: value, message: 'Hello there.' });
    await page.click('button[type="submit"]');
    assert.deepEqual(await errorTexts(page), [EMAIL_ERROR], value + ' should be rejected');
    assert.equal(await page.getAttribute('[name="email"]', 'aria-invalid'), 'true', value + ' aria-invalid');
    assert.equal(await markerIntact(page), true, value + ' navigated the page');
  }
  for (const value of ['first.last@example.co.uk', 'ada+books@example.com']) {
    await fill(page, { name: 'Ada Reader', email: value, message: 'Hello there.' });
    await page.click('button[type="submit"]');
    assert.deepEqual(await errorTexts(page), [], value + ' should not show an error');
    assert.match(await page.textContent('#form-status'), /nothing was sent/, value + ' should be accepted');
  }
  assert.deepEqual(errors, []);
  await context.close();
});

test('fixing the fields and resubmitting clears old errors and aria-invalid', async function () {
  const context = await browser.newContext();
  const { page } = await openForm(context);
  await page.click('button[type="submit"]');
  assert.equal((await errorTexts(page)).length, 3);
  await fill(page, { name: 'Ada Reader', email: 'ada@example.com', message: 'Is the storytime still on?' });
  await page.click('button[type="submit"]');
  assert.deepEqual(await errorTexts(page), []);
  for (const name of ['name', 'email', 'message']) {
    assert.equal(await page.getAttribute('[name="' + name + '"]', 'aria-invalid'), null, name);
    assert.equal(await page.getAttribute('[name="' + name + '"]', 'aria-describedby'), null, name);
  }
  await context.close();
});

test('a valid submit shows the demo message with the shop email and does not navigate', async function () {
  const context = await browser.newContext();
  const { page, errors } = await openForm(context);
  await fill(page, { name: 'Ada Reader', email: 'ada@example.com', message: 'Do you take special orders?' });
  await page.click('button[type="submit"]');
  const status = await page.textContent('#form-status');
  assert.match(status, /demo site/);
  assert.match(status, /nothing was sent/);
  assert.match(status, /hello@marginalia\.example/);
  assert.equal(await page.evaluate(function () { return document.activeElement.id; }), 'form-status');
  assert.equal(await page.getAttribute('#form-status', 'role'), 'status');
  assert.equal(await markerIntact(page), true, 'page navigated or reloaded');
  assert.deepEqual(errors, []);
  await context.close();
});

test('a very long message does not overflow the page at 360px', async function () {
  const context = await browser.newContext();
  const page = await context.newPage();
  await page.setViewportSize({ width: 360, height: 740 });
  await page.goto(base + '/visit.html');
  const long = 'Our shelves hold a little of everything, mostly things we have read. '.repeat(90);
  assert.ok(long.length >= 5000);
  await fill(page, { name: 'Ada Reader', email: 'ada@example.com', message: long + 'superlongwordwithoutanyspacesatall'.repeat(20) });
  await page.click('button[type="submit"]');
  assert.match(await page.textContent('#form-status'), /nothing was sent/);
  const scrollWidth = await page.evaluate(function () { return document.documentElement.scrollWidth; });
  assert.ok(scrollWidth <= 360, 'page scrolls horizontally to ' + scrollWidth + 'px');
  await context.close();
});

test('HTML typed into the fields is shown as text and never becomes markup', async function () {
  const context = await browser.newContext();
  const { page, errors } = await openForm(context);
  const payload = '<img src="x" onerror="window.pwned=1"><b>bold</b>';
  await fill(page, { name: payload, email: 'ada@example.com', message: payload });
  await page.click('button[type="submit"]');
  assert.match(await page.textContent('#form-status'), /nothing was sent/);
  assert.equal(await page.evaluate(function () { return window.pwned; }), undefined);
  assert.equal(await page.locator('form img, form b').count(), 0);
  assert.deepEqual(errors, []);
  await context.close();
});

// Events page: upcoming split against a faked local clock, chronological order, timezone stability.
const { describe, it, before, after } = require('node:test');
const assert = require('node:assert/strict');
const { startServer, launchBrowser, watchErrors } = require('./helpers.cjs');

describe('events', () => {
  let server;
  let origin;
  let browser;

  before(async () => {
    ({ server, origin } = await startServer());
    browser = await launchBrowser();
  });

  after(async () => {
    await browser.close();
    server.close();
  });

  // Opens events.html with the clock frozen at the given local date and time.
  async function openEvents(context, year, monthIndex, day, hour = 9) {
    const page = await context.newPage();
    await page.clock.setFixedTime(new Date(year, monthIndex, day, hour, 0));
    const errors = watchErrors(page);
    await page.goto(`${origin}/events.html`);
    return { page, errors };
  }

  async function listed(page) {
    return page.locator('#event-list h2').allTextContents();
  }

  it('lists at least four events in chronological order with a time element each', async () => {
    const context = await browser.newContext();
    const { page, errors } = await openEvents(context, 2026, 10, 16);
    const titles = await listed(page);
    assert.ok(titles.length >= 4, 'at least four events');
    const datetimes = await page.locator('#event-list time').evaluateAll((ts) => ts.map((t) => t.getAttribute('datetime')));
    assert.deepEqual(datetimes, [...datetimes].sort(), 'chronological order');
    assert.equal(await page.locator('#no-events').isHidden(), true);
    assert.deepEqual(errors, []);
    await context.close();
  });

  it('hides events dated before today and keeps today as upcoming', async () => {
    const context = await browser.newContext();
    // 3 December 2026 is the book club's day: it must still be listed on that day.
    const { page, errors } = await openEvents(context, 2026, 11, 3, 8);
    const titles = await listed(page);
    assert.ok(titles.includes('Book Club: The Tidewater Letters'), 'today counts as upcoming');
    assert.ok(!titles.includes('Winter Reading with Ana Morrow'), 'earlier event is hidden');
    assert.deepEqual(errors, []);
    await context.close();
  });

  it('drops an event once its day has passed', async () => {
    const context = await browser.newContext();
    const { page } = await openEvents(context, 2026, 11, 4, 9);
    const titles = await listed(page);
    assert.ok(!titles.includes('Book Club: The Tidewater Letters'), 'day after is not upcoming');
    assert.ok(titles.includes("Kids' Story Time: Winter Animals"));
    await context.close();
  });

  it('shows a clear message when no upcoming events remain', async () => {
    const context = await browser.newContext();
    const { page, errors } = await openEvents(context, 2027, 0, 2, 9);
    assert.equal(await page.locator('#event-list li').count(), 0);
    assert.equal(await page.locator('#no-events').isVisible(), true);
    assert.match(await page.locator('#no-events').textContent(), /no upcoming events/i);
    assert.deepEqual(errors, []);
    await context.close();
  });

  // Opens events.html with the clock at an exact instant, given as an ISO string with its offset,
  // so the reader's local date does not depend on the timezone of the Node process running the test.
  async function openEventsAt(context, instant) {
    const page = await context.newPage();
    await page.clock.setFixedTime(new Date(instant));
    const errors = watchErrors(page);
    await page.goto(`${origin}/events.html`);
    return { page, errors };
  }

  it('shows the same local date at UTC+14 and UTC-12 and counts the book club by local day', async () => {
    const zones = [
      { timezoneId: 'Pacific/Kiritimati', offset: '+14:00' },
      { timezoneId: 'Etc/GMT+12', offset: '-12:00' }
    ];
    // The book club is on Thursday 3 December 2026 at 19:00 local time.
    const moments = [
      { local: '2026-12-03T00:05:00', listed: true, label: 'just after midnight on the event day' },
      { local: '2026-12-03T23:55:00', listed: true, label: 'just before midnight on the event day' },
      { local: '2026-12-04T00:05:00', listed: false, label: 'just after midnight the day after' }
    ];
    for (const { timezoneId, offset } of zones) {
      const context = await browser.newContext({ timezoneId });
      for (const moment of moments) {
        const { page, errors } = await openEventsAt(context, `${moment.local}${offset}`);
        const bookClub = page.locator('#event-list li', { hasText: 'Book Club' });
        const where = `${timezoneId}, ${moment.label}`;
        assert.equal(await bookClub.count(), moment.listed ? 1 : 0, `listed or hidden: ${where}`);
        if (moment.listed) {
          const time = bookClub.locator('time');
          assert.match(await time.textContent(), /^Thursday, 3 December 2026 at 19:00$/, `date text: ${where}`);
          assert.equal(await time.getAttribute('datetime'), '2026-12-03T19:00', where);
        }
        assert.deepEqual(errors, [], where);
        await page.close();
      }
      await context.close();
    }
  });
});

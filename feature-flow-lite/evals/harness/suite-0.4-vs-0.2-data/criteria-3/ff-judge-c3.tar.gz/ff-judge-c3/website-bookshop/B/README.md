# Marginalia Books

The website for Marginalia Books, a fictional independent bookshop on Tanner's Row in Ashcombe. It has four pages: home, books (with a genre filter), events, and visit (opening hours, access, and a demo contact form).

The site is plain HTML, CSS and JavaScript. There is no build step, no npm dependency, no web font, and no request to any host other than the one that serves the files.

## Run it locally

Serve the repository root with any static server, then open `localhost:8080` in a browser.

```sh
python3 -m http.server 8080
# or
npx http-server -p 8080 .
```

JavaScript must be enabled. Serving over HTTP is the supported way to view the site (the tests do the same); in particular the genre filter's address-bar history needs a real origin.

## Run the tests

The tests use Playwright from a global install and headless Chrome (`channel: 'chrome'`). They start their own static server on a random local port.

```sh
npm test
```

To run one file while working on it:

```sh
NODE_PATH=$(npm root -g) node --test tests/books.test.mjs
```

The tests cover the navigation (including the mobile menu), external requests and console errors, accessibility basics, responsive layout at 360px and 1280px, the books filter and its URL state, the events split by local date, and the contact form.

## File layout

```
index.html          Home page
books.html          Catalogue with genre filter (state in ?genre=)
events.html         Upcoming and past events
visit.html          Address, opening hours, access, and contact form
css/styles.css      All styles: palette, layout, covers, forms, motion
js/data.js          Shop details, opening hours, books and events
js/main.js          Shared: mobile nav, footer year, local-date helpers
js/books.js         Books page: genre filter and URL handling
js/events.js        Events page: upcoming and past lists
js/home.js          Home page: next events and today's hours
js/visit.js         Visit page: hours table and contact form
tests/helpers.mjs   Static server and browser helpers for the tests
tests/*.test.mjs    Test files (node:test with Playwright)
package.json        Test script only; no dependencies
FEATURE_FLOW.md     Standing criteria and conventions for this site
```

## Editing content

Opening hours, books, events and contact details live in `js/data.js`. The books filter and the events lists are built from that file, so a new book or event appears on the right pages without other changes. Events are split into upcoming and past using the visitor's local calendar day.

## The contact form

The contact form on the visit page is a demo. It checks the fields and shows errors, but it has no backend, so it does not send messages anywhere. After a valid submit it says plainly that the message was not sent and gives the shop's email address and phone number.

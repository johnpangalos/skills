// Contact form on the visit page: client-side checks only. Nothing is sent anywhere.
(function () {
  'use strict';

  var form = document.getElementById('contact-form');
  var status = document.getElementById('form-status');
  var EMAIL_PATTERN = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  var FIELDS = ['name', 'email', 'subject', 'message'];
  var PROBLEMS = {
    name: 'Please enter your name.',
    email: 'Please enter an email address in the form name@example.com.',
    subject: 'Please enter a subject.',
    message: 'Please enter a message.'
  };

  function problemWith(field) {
    var value = field.value.trim();
    if (value === '') {
      return PROBLEMS[field.name];
    }
    if (field.name === 'email' && !EMAIL_PATTERN.test(value)) {
      return PROBLEMS.email;
    }
    return '';
  }

  // Shows or clears the error for one field. Returns true when the field is valid.
  function showProblem(field) {
    var error = document.getElementById(field.name + '-error');
    var message = problemWith(field);

    error.textContent = message;
    error.hidden = message === '';

    if (message === '') {
      field.removeAttribute('aria-invalid');
      field.removeAttribute('aria-describedby');
      return true;
    }
    field.setAttribute('aria-invalid', 'true');
    field.setAttribute('aria-describedby', error.id);
    return false;
  }

  form.addEventListener('submit', function (event) {
    event.preventDefault();

    var firstInvalid = null;
    FIELDS.forEach(function (name) {
      var field = form.elements.namedItem(name);
      if (!showProblem(field) && firstInvalid === null) {
        firstInvalid = field;
      }
    });

    if (firstInvalid !== null) {
      status.textContent = '';
      firstInvalid.focus();
      return;
    }

    status.textContent = 'This is a demo form, so your message was not sent. Please email hello@marginaliabooks.example to reach us.';
  });

  FIELDS.forEach(function (name) {
    var field = form.elements.namedItem(name);
    field.addEventListener('input', function () {
      if (field.getAttribute('aria-invalid') === 'true') {
        showProblem(field);
      }
    });
  });
})();

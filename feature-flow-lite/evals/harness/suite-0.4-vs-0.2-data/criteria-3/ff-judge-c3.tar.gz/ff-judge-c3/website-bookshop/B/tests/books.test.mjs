import { test, describe } from 'node:test';
import assert from 'node:assert/strict';
import { useSite, withPage, watchErrors } from './helpers.mjs';

const site = useSite();

// Reads every rendered book card into plain objects.
function readBooks(page) {
  return page.$$eval('#book-list article', (articles) => articles.map((a) => ({
    title: a.querySelector('h2').textContent,
    author: a.querySelector('.book__author').textContent,
    genre: a.querySelector('.book__genre').textContent,
    description: a.querySelector('.book__description').textContent,
    price: a.querySelector('.book__price').textContent
  })));
}

function readOptions(page) {
  return page.$$eval('#genre-select option', (opts) => opts.map((o) => ({ value: o.value, label: o.textContent })));
}

const selectValue = (page) => page.$eval('#genre-select', (s) => s.value);
const countText = (page) => page.textContent('#result-count');
const shownTitles = (page) => page.$$eval('#book-list h2', (hs) => hs.map((h) => h.textContent));

describe('catalogue', () => {
  test('lists at least 12 books across at least 5 genres, with 2 or more in each', () =>
    withPage(site.browser, {}, async (page) => {
      await page.goto(`${site.base}/books.html`);
      const books = await readBooks(page);
      assert.ok(books.length >= 12, `only ${books.length} books`);
      for (const book of books) {
        assert.ok(book.title && book.author && book.genre && book.description, `incomplete: ${book.title}`);
        assert.match(book.price, /^£\d+\.\d{2}$/);
      }
      const byGenre = {};
      for (const book of books) byGenre[book.genre] = (byGenre[book.genre] || 0) + 1;
      const genres = Object.keys(byGenre);
      assert.ok(genres.length >= 5, `only ${genres.length} genres`);
      for (const genre of genres) assert.ok(byGenre[genre] >= 2, `${genre} has ${byGenre[genre]}`);
    }));

  test('the filter offers All plus each genre in the data, and All is selected by default', () =>
    withPage(site.browser, {}, async (page) => {
      await page.goto(`${site.base}/books.html`);
      assert.deepEqual(await readOptions(page), [
        { value: '', label: 'All' },
        { value: 'fiction', label: 'Fiction' },
        { value: 'poetry', label: 'Poetry' },
        { value: 'essays', label: 'Essays' },
        { value: 'history', label: 'History' },
        { value: 'nature-place', label: 'Nature & Place' }
      ]);
      assert.equal(await selectValue(page), '');
      assert.equal(await countText(page), 'Showing 15 of 15 books');
      assert.equal(await page.getAttribute('#result-count', 'aria-live'), 'polite');
      assert.equal(await page.getByLabel('Filter by genre').count(), 1);
    }));
});

describe('genre filter', () => {
  test('choosing a genre shows only its books and announces the count', () =>
    withPage(site.browser, {}, async (page) => {
      await page.goto(`${site.base}/books.html`);
      await page.selectOption('#genre-select', 'poetry');
      const titles = await shownTitles(page);
      assert.deepEqual(titles.sort(), ['Ink Left in the Bottle', 'Low Tide Hymnal', 'The Orchard Ledger']);
      assert.equal(await countText(page), 'Showing 3 of 15 books in Poetry');
      assert.equal(new URL(page.url()).search, '?genre=poetry');
    }));

  test('choosing All shows every book and removes the genre from the URL', () =>
    withPage(site.browser, {}, async (page) => {
      await page.goto(`${site.base}/books.html`);
      await page.selectOption('#genre-select', 'essays');
      await page.selectOption('#genre-select', '');
      assert.equal((await readBooks(page)).length, 15);
      assert.equal(await countText(page), 'Showing 15 of 15 books');
      assert.equal(new URL(page.url()).search, '');
    }));

  test('loading books.html?genre=poetry shows Poetry with the control set to Poetry', () =>
    withPage(site.browser, {}, async (page) => {
      const errors = watchErrors(page);
      await page.goto(`${site.base}/books.html?genre=poetry`);
      assert.equal(await selectValue(page), 'poetry');
      assert.equal((await readBooks(page)).length, 3);
      assert.equal(await countText(page), 'Showing 3 of 15 books in Poetry');
      assert.deepEqual(errors, []);
    }));

  test('browser back and forward restore earlier filters', () =>
    withPage(site.browser, {}, async (page) => {
      await page.goto(`${site.base}/books.html`);
      await page.selectOption('#genre-select', 'poetry');
      await page.selectOption('#genre-select', 'history');
      assert.equal(new URL(page.url()).search, '?genre=history');

      await page.goBack();
      await page.waitForFunction(() => document.getElementById('genre-select').value === 'poetry');
      assert.equal(new URL(page.url()).search, '?genre=poetry');
      assert.equal((await readBooks(page)).length, 3);

      await page.goBack();
      await page.waitForFunction(() => document.getElementById('genre-select').value === '');
      assert.equal((await readBooks(page)).length, 15);

      await page.goForward();
      await page.waitForFunction(() => document.getElementById('genre-select').value === 'poetry');
      assert.equal(await countText(page), 'Showing 3 of 15 books in Poetry');
    }));
});

describe('hostile genre parameters', () => {
  const cases = [
    { query: '?genre=unknown-genre', value: '', count: 15, text: 'Showing 15 of 15 books' },
    { query: '?genre=', value: '', count: 15, text: 'Showing 15 of 15 books' },
    { query: '?genre=POETRY', value: 'poetry', count: 3, text: 'Showing 3 of 15 books in Poetry' },
    { query: '?genre=%3Cscript%3Ealert(1)%3C%2Fscript%3E', value: '', count: 15, text: 'Showing 15 of 15 books' },
    { query: '?genre=%3Cimg%20src%3Dx%20onerror%3Dalert(1)%3E', value: '', count: 15, text: 'Showing 15 of 15 books' }
  ];

  for (const { query, value, count, text } of cases) {
    test(`books.html${query} falls back cleanly without dialogs or injected HTML`, () =>
      withPage(site.browser, {}, async (page) => {
        const errors = watchErrors(page);
        const dialogs = [];
        page.on('dialog', (dialog) => {
          dialogs.push(dialog.message());
          dialog.dismiss();
        });
        await page.goto(`${site.base}/books.html${query}`);
        assert.equal(await selectValue(page), value);
        assert.equal((await readBooks(page)).length, count);
        assert.equal(await countText(page), text);
        assert.equal(await page.locator('#book-list script, #book-list img').count(), 0);
        assert.deepEqual(dialogs, []);
        assert.deepEqual(errors, []);
      }));
  }
});

// Books page: genre filter built from the catalogue data, with the choice kept in ?genre=.
(function () {
  'use strict';

  var createEl = window.Marginalia.createEl;
  var books = window.MarginaliaData.books;
  var select = document.getElementById('genre-select');
  var list = document.getElementById('book-list');
  var resultCount = document.getElementById('result-count');

  function slugify(name) {
    return name.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-+|-+$/g, '');
  }

  // Unique genres in the order they first appear in the data.
  var genres = books.reduce(function (found, book) {
    var slug = slugify(book.genre);
    if (!found.some(function (g) { return g.slug === slug; })) {
      found.push({ slug: slug, name: book.genre });
    }
    return found;
  }, []);

  // Maps a raw ?genre= value to a known genre slug, case-insensitively.
  // Anything unknown, empty or missing becomes '' (All).
  function genreFromParam(raw) {
    var wanted = (raw || '').trim().toLowerCase();
    var match = genres.find(function (g) { return g.slug === wanted; });
    return match ? match.slug : '';
  }

  function currentParam() {
    return new URLSearchParams(window.location.search).get('genre');
  }

  function genreName(slug) {
    return genres.find(function (g) { return g.slug === slug; }).name;
  }

  function formatPrice(price) {
    return '£' + price.toFixed(2);
  }

  function bookItem(book) {
    var item = createEl('li', 'book-item');
    var article = createEl('article', 'book');

    var cover = createEl('div', 'cover cover--' + slugify(book.genre));
    cover.setAttribute('aria-hidden', 'true');
    cover.appendChild(createEl('span', 'cover__title', book.title));
    cover.appendChild(createEl('span', 'cover__author', book.author));

    var body = createEl('div', 'book__body');
    body.appendChild(createEl('h2', 'book__title', book.title));
    body.appendChild(createEl('p', 'book__author', 'by ' + book.author));
    body.appendChild(createEl('p', 'book__genre', book.genre));
    body.appendChild(createEl('p', 'book__description', book.description));
    body.appendChild(createEl('p', 'book__price', formatPrice(book.price)));

    article.appendChild(cover);
    article.appendChild(body);
    item.appendChild(article);
    return item;
  }

  // Shows the books for one genre slug ('' shows all), and syncs the select and the count.
  function showGenre(slug) {
    var shown = slug
      ? books.filter(function (book) { return slugify(book.genre) === slug; })
      : books;

    select.value = slug;
    list.textContent = '';
    shown.forEach(function (book) {
      list.appendChild(bookItem(book));
    });

    var text = 'Showing ' + shown.length + ' of ' + books.length + ' books';
    resultCount.textContent = slug ? text + ' in ' + genreName(slug) : text;
  }

  function populateSelect() {
    var all = createEl('option', null, 'All');
    all.value = '';
    select.appendChild(all);

    genres.forEach(function (g) {
      var option = createEl('option', null, g.name);
      option.value = g.slug;
      select.appendChild(option);
    });
  }

  select.addEventListener('change', function () {
    var slug = select.value;
    var path = slug
      ? window.location.pathname + '?genre=' + encodeURIComponent(slug)
      : window.location.pathname;
    window.history.pushState({ genre: slug }, '', path);
    showGenre(slug);
  });

  window.addEventListener('popstate', function () {
    showGenre(genreFromParam(currentParam()));
  });

  populateSelect();
  showGenre(genreFromParam(currentParam()));
})();

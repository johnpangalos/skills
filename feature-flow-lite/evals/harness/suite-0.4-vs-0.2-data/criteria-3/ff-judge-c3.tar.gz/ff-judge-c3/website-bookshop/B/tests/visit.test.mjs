import { test, describe } from 'node:test';
import assert from 'node:assert/strict';
import { useSite, withPage, watchErrors } from './helpers.mjs';

const site = useSite();

const MSG = {
  name: 'Please enter your name.',
  email: 'Please enter your email address.',
  emailFormat: 'Please enter an email address in the form name@example.com.',
  message: 'Please enter a message.'
};

const errorText = (page, id) => page.textContent(`#${id}-error`);
const isHidden = (page, id) => page.locator(`#${id}-error`).isHidden();
const invalid = (page, id) => page.getAttribute(`#${id}`, 'aria-invalid');
const status = (page) => page.textContent('#form-status');
const submit = (page) => page.click('button[type="submit"]');

async function fillForm(page, { name = 'Ines Halloran', email = 'ines@example.com', message = 'Could you hold a copy of Small Rooms?' } = {}) {
  await page.fill('#name', name);
  await page.fill('#email', email);
  await page.fill('#message', message);
}

describe('visit page content', () => {
  test('address, seven opening hours rows and access information are present', () =>
    withPage(site.browser, {}, async (page) => {
      await page.goto(`${site.base}/visit.html`);
      assert.match(await page.textContent('main address'), /14 Tanner's Row/);
      const days = await page.$$eval('table.hours tbody tr th', (ths) => ths.map((th) => th.textContent));
      assert.deepEqual(days, ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday']);
      assert.match(await page.textContent('.access-list'), /Step-free entrance/);
      assert.equal(await page.locator('form#contact-form label[for="name"]').count(), 1);
    }));

  test('the page says plainly that the form is a demo and sends nothing', () =>
    withPage(site.browser, {}, async (page) => {
      await page.goto(`${site.base}/visit.html`);
      assert.match(await page.textContent('.notice'), /does not send anything/);
    }));
});

describe('contact form validation', () => {
  test('empty submit shows an error under each required field, marks them invalid and focuses the first', () =>
    withPage(site.browser, {}, async (page) => {
      await page.goto(`${site.base}/visit.html`);
      await submit(page);
      assert.equal(await errorText(page, 'name'), MSG.name);
      assert.equal(await errorText(page, 'email'), MSG.email);
      assert.equal(await errorText(page, 'message'), MSG.message);
      for (const id of ['name', 'email', 'message']) {
        assert.equal(await invalid(page, id), 'true');
        assert.equal(await isHidden(page, id), false);
      }
      assert.equal(await page.getAttribute('#name', 'aria-describedby'), 'name-error');
      assert.equal(await page.evaluate(() => document.activeElement.id), 'name');
      assert.equal(await status(page), '');
    }));

  test('whitespace-only name and message are rejected after trimming', () =>
    withPage(site.browser, {}, async (page) => {
      await page.goto(`${site.base}/visit.html`);
      await fillForm(page, { name: '    ', message: ' \n\t ' });
      await submit(page);
      assert.equal(await errorText(page, 'name'), MSG.name);
      assert.equal(await errorText(page, 'message'), MSG.message);
      assert.equal(await errorText(page, 'email'), '');
      assert.equal(await invalid(page, 'email'), null);
    }));

  for (const email of ['a@b', 'no-at-sign', 'x@y.']) {
    test(`email "${email}" is rejected with the format message`, () =>
      withPage(site.browser, {}, async (page) => {
        await page.goto(`${site.base}/visit.html`);
        await fillForm(page, { email });
        await submit(page);
        assert.equal(await errorText(page, 'email'), MSG.emailFormat);
        assert.equal(await invalid(page, 'email'), 'true');
        assert.equal(await page.evaluate(() => document.activeElement.id), 'email');
      }));
  }

  test('a message over 1000 characters is rejected and reports its length', () =>
    withPage(site.browser, {}, async (page) => {
      await page.goto(`${site.base}/visit.html`);
      await fillForm(page, { message: 'a'.repeat(1001) });
      await submit(page);
      assert.equal(await errorText(page, 'message'), 'Messages can be up to 1000 characters. Yours is 1001.');
      assert.equal(await status(page), '');
    }));

  test('a message of exactly 1000 characters is accepted', () =>
    withPage(site.browser, {}, async (page) => {
      await page.goto(`${site.base}/visit.html`);
      await fillForm(page, { message: 'a'.repeat(1000) });
      await submit(page);
      assert.equal(await errorText(page, 'message'), '');
      assert.match(await status(page), /NOT sent/);
    }));

  test('fixing a field clears its message and aria-invalid as the visitor types', () =>
    withPage(site.browser, {}, async (page) => {
      await page.goto(`${site.base}/visit.html`);
      await submit(page);
      await page.fill('#name', 'Ines');
      assert.equal(await errorText(page, 'name'), '');
      assert.equal(await isHidden(page, 'name'), true);
      assert.equal(await invalid(page, 'name'), null);
      assert.equal(await invalid(page, 'email'), 'true');
    }));
});

describe('contact form submission', () => {
  test('a valid submit shows a confirmation that says the message was NOT sent', () =>
    withPage(site.browser, {}, async (page) => {
      const errors = watchErrors(page);
      await page.goto(`${site.base}/visit.html`);
      await fillForm(page);
      await submit(page);
      const text = await status(page);
      assert.match(text, /NOT sent/);
      assert.doesNotMatch(text, /\b(was|has been|been) sent\b/i);
      assert.equal(await page.getAttribute('#form-status', 'aria-live'), 'polite');
      assert.deepEqual(errors, []);
    }));

  test('a valid submit resets the fields, and editing a field clears the confirmation', () =>
    withPage(site.browser, {}, async (page) => {
      await page.goto(`${site.base}/visit.html`);
      await fillForm(page);
      await submit(page);
      assert.match(await status(page), /NOT sent/);
      assert.equal(await page.inputValue('#name'), '');
      assert.equal(await page.inputValue('#email'), '');
      assert.equal(await page.inputValue('#message'), '');
      await page.fill('#name', 'I');
      assert.equal(await status(page), '');
      await submit(page);
      assert.equal(await status(page), '');
      assert.equal(await errorText(page, 'email'), MSG.email);
      assert.equal(await invalid(page, 'email'), 'true');
    }));

  test('a name containing HTML is shown as text, never as an element', () =>
    withPage(site.browser, {}, async (page) => {
      const dialogs = [];
      page.on('dialog', (dialog) => {
        dialogs.push(dialog.message());
        dialog.dismiss();
      });
      await page.goto(`${site.base}/visit.html`);
      const hostile = '<img src=x onerror=alert(1)>';
      await fillForm(page, { name: hostile });
      await submit(page);
      assert.match(await status(page), /<img src=x onerror=alert\(1\)>/);
      assert.equal(await page.locator('img').count(), 0);
      assert.equal(await page.locator('#form-status img').count(), 0);
      assert.deepEqual(dialogs, []);
    }));

  test('submitting again after a demo send shows errors on the reset form, not a second confirmation', () =>
    withPage(site.browser, {}, async (page) => {
      await page.goto(`${site.base}/visit.html`);
      await fillForm(page);
      await submit(page);
      await submit(page);
      assert.equal(await status(page), '');
      assert.equal(await errorText(page, 'name'), MSG.name);
      assert.equal(await invalid(page, 'name'), 'true');
    }));
});

// Catalogue page: data coverage, genre filter, URL state, back/forward, and hostile ?genre values.
const { describe, it, before, after } = require('node:test');
const assert = require('node:assert/strict');
const { startServer, launchBrowser, watchErrors } = require('./helpers.cjs');

describe('books catalogue', () => {
  let server;
  let origin;
  let browser;

  before(async () => {
    ({ server, origin } = await startServer());
    browser = await launchBrowser();
  });

  after(async () => {
    await browser.close();
    server.close();
  });

  async function openBooks(query = '') {
    const context = await browser.newContext();
    const page = await context.newPage();
    const errors = watchErrors(page);
    await page.goto(`${origin}/books.html${query}`);
    await page.waitForFunction(() => document.getElementById('count').textContent !== '');
    return { context, page, errors };
  }

  it('lists at least 12 books across at least 4 genres, each with title, author, blurb and price', async () => {
    const { context, page, errors } = await openBooks();
    const cards = page.locator('#book-list li.book');
    assert.ok((await cards.count()) >= 12);
    const complete = await cards.evaluateAll((items) =>
      items.every((li) => li.querySelector('h2') && li.querySelector('.book-author') && li.querySelector('.book-blurb') && /£\d/.test(li.textContent))
    );
    assert.equal(complete, true);
    const genres = await page.locator('#genre option').allTextContents();
    assert.ok(genres.length - 1 >= 4, 'at least 4 genre options');
    assert.deepEqual(errors, []);
    await context.close();
  });

  it('gives every genre option at least one matching book', async () => {
    const { context, page } = await openBooks();
    const values = await page.locator('#genre option').evaluateAll((opts) => opts.map((o) => o.value));
    for (const value of values.filter((v) => v !== 'all')) {
      await page.selectOption('#genre', value);
      const count = await page.locator('#book-list li').count();
      assert.ok(count >= 1, `genre ${value} has books`);
    }
    await context.close();
  });

  it('filters by genre, announces the count and reflects it in the URL', async () => {
    const { context, page, errors } = await openBooks();
    const total = await page.locator('#book-list li').count();
    assert.equal(await page.locator('#count').textContent(), `Showing ${total} of ${total} books`);

    await page.selectOption('#genre', 'poetry');
    assert.equal(await page.locator('#count').textContent(), `Showing 3 of ${total} books`);
    assert.equal(await page.locator('#book-list li').count(), 3);
    assert.equal(new URL(page.url()).searchParams.get('genre'), 'poetry');
    assert.deepEqual(errors, []);
    await context.close();
  });

  it('applies a genre from the URL on load, including mixed case', async () => {
    const { context, page } = await openBooks('?genre=POETRY');
    assert.equal(await page.locator('#genre').inputValue(), 'poetry');
    assert.equal(await page.locator('#book-list li').count(), 3);
    await context.close();
  });

  it('applies a multi-word genre given by its display name', async () => {
    const young = await openBooks('?genre=Young+Readers');
    assert.equal(await young.page.locator('#genre').inputValue(), 'young-readers');
    assert.equal(await young.page.locator('#book-list li').count(), 3);
    assert.equal(await young.page.locator('#count').textContent(), 'Showing 3 of 15 books');
    await young.context.close();

    const literary = await openBooks('?genre=Literary%20Fiction');
    assert.equal(await literary.page.locator('#genre').inputValue(), 'literary-fiction');
    assert.equal(await literary.page.locator('#book-list li').count(), 3);
    await literary.context.close();
  });

  it('restores the filter on back and forward', async () => {
    const { context, page } = await openBooks();
    const total = await page.locator('#book-list li').count();
    await page.selectOption('#genre', 'history');
    assert.equal(await page.locator('#book-list li').count(), 3);
    await page.goBack();
    await page.waitForFunction((n) => document.querySelectorAll('#book-list li').length === n, total);
    assert.equal(await page.locator('#genre').inputValue(), 'all');
    await page.goForward();
    await page.waitForFunction(() => document.querySelectorAll('#book-list li').length === 3);
    assert.equal(await page.locator('#genre').inputValue(), 'history');
    await context.close();
  });

  it('shows all books for hostile or unknown ?genre values without errors', async () => {
    const hostile = [
      ['?genre=unknown-value', 'all'],
      ['?genre=', 'all'],
      ['?genre=' + encodeURIComponent('<script>alert(1)</script>'), 'all'],
      ['?genre=a&genre=b', 'all'],
      ['?genre=poetry&genre=history', 'poetry']
    ];
    for (const [query, expected] of hostile) {
      const { context, page, errors } = await openBooks(query);
      assert.equal(await page.locator('#genre').inputValue(), expected, query);
      const count = await page.locator('#count').textContent();
      assert.match(count, /^Showing \d+ of \d+ books$/, query);
      assert.equal(await page.locator('#empty').isHidden(), true, `no empty state for ${query}`);
      assert.equal(await page.locator('script:not([src])').count(), 0, `no injected script for ${query}`);
      assert.equal(await page.locator('#book-list script, #book-list img').count(), 0, query);
      assert.deepEqual(errors, [], `no errors for ${query}`);
      await context.close();
    }
  });

  it('renders book text as text, not markup', async () => {
    const { context, page } = await openBooks();
    assert.ok((await page.locator('#book-list h2').count()) >= 12);
    assert.equal(await page.locator('#book-list em, #book-list b, #book-list i').count(), 0);
    await context.close();
  });
});

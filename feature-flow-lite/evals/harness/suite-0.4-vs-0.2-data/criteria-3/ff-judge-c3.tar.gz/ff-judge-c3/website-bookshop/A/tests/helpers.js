'use strict';

// Shared helpers for the browser tests: a tiny static server and a headless Chromium.
const http = require('node:http');
const fs = require('node:fs');
const path = require('node:path');
const { chromium } = require('playwright');

const ROOT = path.join(__dirname, '..');
const PAGES = ['index.html', 'books.html', 'events.html', 'visit.html'];
const TYPES = {
  '.html': 'text/html; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.js': 'text/javascript; charset=utf-8',
  '.svg': 'image/svg+xml'
};

function startServer() {
  const server = http.createServer(function (request, response) {
    const pathname = decodeURIComponent(new URL(request.url, 'http://localhost').pathname);
    const relative = pathname === '/' ? 'index.html' : pathname.replace(/^\/+/, '');
    const file = path.normalize(path.join(ROOT, relative));
    if (!file.startsWith(ROOT + path.sep)) {
      response.writeHead(403);
      response.end();
      return;
    }
    fs.readFile(file, function (error, body) {
      if (error) {
        response.writeHead(404, { 'Content-Type': 'text/plain' });
        response.end('Not found');
        return;
      }
      response.writeHead(200, { 'Content-Type': TYPES[path.extname(file)] || 'application/octet-stream' });
      response.end(body);
    });
  });
  return new Promise(function (resolve) {
    server.listen(0, '127.0.0.1', function () {
      resolve({
        server: server,
        base: 'http://127.0.0.1:' + server.address().port
      });
    });
  });
}

function stopServer(server) {
  return new Promise(function (resolve) {
    server.close(resolve);
  });
}

// Collects console errors and uncaught page errors so a test can assert there are none.
function watchErrors(page) {
  const errors = [];
  page.on('console', function (message) {
    if (message.type() === 'error') {
      errors.push(message.text());
    }
  });
  page.on('pageerror', function (error) {
    errors.push(String(error));
  });
  return errors;
}

module.exports = { ROOT, PAGES, chromium, startServer, stopServer, watchErrors };

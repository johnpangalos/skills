// Shared test helpers: a tiny static server for the site, and a headless Chrome.
// Playwright is the global install, so it is loaded with createRequire (NODE_PATH applies).
import { createServer } from 'node:http';
import { readFile } from 'node:fs/promises';
import { extname, resolve, sep } from 'node:path';
import { fileURLToPath } from 'node:url';
import { createRequire } from 'node:module';
import { before, after } from 'node:test';

const require = createRequire(import.meta.url);
const { chromium } = require('playwright');

export const ROOT = resolve(fileURLToPath(new URL('..', import.meta.url)));

export const PAGES = ['index.html', 'books.html', 'events.html', 'visit.html'];

const TYPES = {
  '.html': 'text/html; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.js': 'text/javascript; charset=utf-8',
  '.svg': 'image/svg+xml'
};

// Serves the repo root on a random 127.0.0.1 port. Resolves to { base, close }.
export function startServer() {
  const server = createServer(async (req, res) => {
    let pathname;
    try {
      pathname = decodeURIComponent(new URL(req.url, 'http://localhost').pathname);
    } catch {
      res.writeHead(400, { 'Content-Type': 'text/plain' }).end('Bad request');
      return;
    }
    const filePath = resolve(ROOT, pathname === '/' ? 'index.html' : pathname.slice(1));
    if (!filePath.startsWith(ROOT + sep)) {
      res.writeHead(403, { 'Content-Type': 'text/plain' }).end('Forbidden');
      return;
    }
    try {
      const body = await readFile(filePath);
      res.writeHead(200, { 'Content-Type': TYPES[extname(filePath)] || 'application/octet-stream' });
      res.end(body);
    } catch {
      res.writeHead(404, { 'Content-Type': 'text/plain' }).end('Not found');
    }
  });
  return new Promise((ready) => {
    server.listen(0, '127.0.0.1', () => {
      const { port } = server.address();
      ready({
        base: `http://127.0.0.1:${port}`,
        close: () => new Promise((done) => server.close(done))
      });
    });
  });
}

export function launchBrowser() {
  return chromium.launch({ channel: 'chrome' });
}

// Registers hooks for the calling test file: starts the server and a Chrome before its tests
// and closes both after. Returns { base, browser }, filled in before the first test runs.
export function useSite() {
  const site = {};
  let server;
  before(async () => {
    server = await startServer();
    site.base = server.base;
    site.browser = await launchBrowser();
  });
  after(async () => {
    await site.browser.close();
    await server.close();
  });
  return site;
}

// Runs fn with a fresh page in its own context, always closing the context afterwards.
export async function withPage(browser, options, fn) {
  const context = await browser.newContext(options);
  const page = await context.newPage();
  try {
    return await fn(page);
  } finally {
    await context.close();
  }
}

// Collects uncaught page errors and console errors into the returned array.
export function watchErrors(page) {
  const errors = [];
  page.on('pageerror', (err) => errors.push(err.message));
  page.on('console', (msg) => {
    if (msg.type() === 'error') errors.push(msg.text());
  });
  return errors;
}

# Marginalia Books

A static website for Marginalia Books, a fictional independent bookshop in Little Ashcombe. It has a home page, a catalogue with a genre filter, an events page and a visit page with opening hours and a contact form.

Plain HTML, CSS and JavaScript. No build step and no dependencies.

## Viewing the site

- Open `index.html` directly in a browser. The genre filter works from a `file://` load too.
- Or serve the folder: `npx http-server -p 8080 .` and visit http://localhost:8080.

## File layout

```
index.html        home page: introduction, staff picks, next events, call to visit
books.html        catalogue with genre filter (state kept in ?genre=)
events.html      events list
visit.html        opening hours, address, access, contact form
css/styles.css    shared styles
js/data.js        BOOKS and EVENTS data (edit content here)
js/site.js        shared helpers on window.Marginalia (slugify, date formatting, upcoming events)
js/home.js        staff picks and upcoming events teaser
js/books.js       catalogue filter and URL state
js/events.js      events list
js/visit.js       contact form validation
tests/            browser tests (Node test runner + Playwright)
```

## Running the tests

The tests use the globally installed `playwright` package and start their own static server on a free port.

```
NODE_PATH=/opt/node22/lib/node_modules node --test tests/
```

To check the scripts for syntax errors:

```
for f in js/*.js; do node --check "$f"; done
```

## Notes

- The contact form is a demo. It validates the fields, but it sends nothing. The success message says so and asks visitors to email hello@marginalia.example.
- All names, books, authors, events and addresses are fictional. The phone number and email use reserved fictional ranges.
- Past events are hidden. The home page teaser and the events list show only events on or after today's date (the visitor's local day), so they change as time passes. When no events remain, the events page says so.

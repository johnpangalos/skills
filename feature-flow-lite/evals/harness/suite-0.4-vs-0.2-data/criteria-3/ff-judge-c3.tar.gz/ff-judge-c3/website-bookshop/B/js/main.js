// Shared behaviour for every page: the mobile nav toggle, the footer year,
// and the date and element helpers that the page scripts use.
(function () {
  'use strict';

  var MONTHS = ['January', 'February', 'March', 'April', 'May', 'June', 'July',
    'August', 'September', 'October', 'November', 'December'];
  var WEEKDAYS = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];

  function setupNav() {
    var toggle = document.querySelector('.nav-toggle');
    var nav = document.getElementById('site-nav');
    if (!toggle || !nav) return;

    function isOpen() {
      return nav.classList.contains('is-open');
    }

    function setOpen(open) {
      nav.classList.toggle('is-open', open);
      toggle.setAttribute('aria-expanded', open ? 'true' : 'false');
    }

    toggle.addEventListener('click', function () {
      setOpen(!isOpen());
    });

    document.addEventListener('keydown', function (event) {
      if (event.key === 'Escape' && isOpen()) {
        setOpen(false);
        toggle.focus();
      }
    });

    // Past the breakpoint the CSS always shows the nav, so drop the stale open state too.
    window.matchMedia('(min-width: 700px)').addEventListener('change', function (event) {
      if (event.matches) setOpen(false);
    });
  }

  function setYear() {
    var year = document.getElementById('year');
    if (year) year.textContent = String(new Date().getFullYear());
  }

  function pad(n) {
    return n < 10 ? '0' + n : String(n);
  }

  // The local calendar day as YYYY-MM-DD, built from local getters (never a UTC parse).
  function localDateKey(date) {
    return date.getFullYear() + '-' + pad(date.getMonth() + 1) + '-' + pad(date.getDate());
  }

  // Splits events into upcoming (today or later) and past, each sorted by date ascending.
  // Dates are YYYY-MM-DD strings, so plain string comparison is date order.
  function splitEvents(events, todayKey) {
    var sorted = events.slice().sort(function (a, b) {
      return a.date < b.date ? -1 : a.date > b.date ? 1 : 0;
    });
    return {
      upcoming: sorted.filter(function (event) { return event.date >= todayKey; }),
      past: sorted.filter(function (event) { return event.date < todayKey; })
    };
  }

  // Human-readable event time, e.g. "Thursday 3 December 2026, 18:30–20:00".
  function formatEventWhen(event) {
    var parts = event.date.split('-').map(Number);
    var weekday = WEEKDAYS[new Date(Date.UTC(parts[0], parts[1] - 1, parts[2])).getUTCDay()];
    return weekday + ' ' + parts[2] + ' ' + MONTHS[parts[1] - 1] + ' ' + parts[0] +
      ', ' + event.start + '–' + event.end;
  }

  // Creates an element and sets its text with textContent, so data is never parsed as HTML.
  function createEl(tag, className, text) {
    var el = document.createElement(tag);
    if (className) el.className = className;
    if (text !== undefined) el.textContent = text;
    return el;
  }

  // Calendar-style badge: the day number over the month abbreviation. It is decorative,
  // because the full date sits in the adjacent <time> element.
  function dateBadge(dateKey) {
    var parts = dateKey.split('-').map(Number);
    var badge = createEl('div', 'date-badge');
    badge.setAttribute('aria-hidden', 'true');
    badge.appendChild(createEl('span', 'date-badge__day', String(parts[2])));
    badge.appendChild(createEl('span', 'date-badge__month', MONTHS[parts[1] - 1].slice(0, 3)));
    return badge;
  }

  window.Marginalia = {
    WEEKDAYS: WEEKDAYS,
    localDateKey: localDateKey,
    splitEvents: splitEvents,
    formatEventWhen: formatEventWhen,
    createEl: createEl,
    dateBadge: dateBadge
  };

  setupNav();
  setYear();
})();

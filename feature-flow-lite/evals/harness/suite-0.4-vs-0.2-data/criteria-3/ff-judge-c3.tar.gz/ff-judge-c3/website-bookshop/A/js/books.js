// Catalogue page: genre filter, result count and ?genre= state in the URL.
(function () {
  'use strict';

  const ALL = 'all';
  const { slugify } = window.Marginalia;
  const optionsBox = document.getElementById('genre-options');
  const list = document.getElementById('book-list');
  const count = document.getElementById('result-count');

  const genres = Array.from(new Set(BOOKS.map(function (book) {
    return book.genre;
  })));

  let current = ALL;
  let inputs = [];

  // Accepts the slug (science-fiction) or the lowercased display name (science fiction),
  // ignoring case and surrounding spaces. Anything else, including an empty value, means All.
  function genreFromParam(value) {
    const wanted = (value || '').trim().toLowerCase();
    const match = genres.find(function (genre) {
      return wanted === slugify(genre) || wanted === genre.toLowerCase();
    });
    return match || ALL;
  }

  function buildOptions() {
    [ALL].concat(genres).forEach(function (value) {
      const id = 'genre-' + slugify(value);
      const input = document.createElement('input');
      input.type = 'radio';
      input.name = 'genre';
      input.id = id;
      input.value = value;
      const label = document.createElement('label');
      label.htmlFor = id;
      label.textContent = value === ALL ? 'All genres' : value;
      optionsBox.appendChild(input);
      optionsBox.appendChild(label);
      inputs.push(input);
    });
  }

  function buildCard(book) {
    const item = document.createElement('li');
    item.className = 'book-card';

    const title = document.createElement('h2');
    title.className = 'book-title';
    title.textContent = book.title;

    const author = document.createElement('p');
    author.className = 'book-author';
    author.textContent = 'by ' + book.author;

    const genre = document.createElement('p');
    genre.className = 'book-genre';
    genre.textContent = 'Genre: ' + book.genre;

    const blurb = document.createElement('p');
    blurb.className = 'book-blurb';
    blurb.textContent = book.blurb;

    const price = document.createElement('p');
    price.className = 'book-price';
    price.textContent = '£' + book.price.toFixed(2);

    item.append(title, author, genre, blurb, price);
    return item;
  }

  function visibleBooks(genre) {
    if (genre === ALL) {
      return BOOKS;
    }
    return BOOKS.filter(function (book) {
      return book.genre === genre;
    });
  }

  function renderCards(books) {
    list.replaceChildren(...books.map(buildCard));
  }

  function renderCount(books, genre) {
    const suffix = genre === ALL ? '' : ' in ' + genre;
    count.textContent = 'Showing ' + books.length + ' of ' + BOOKS.length + ' books' + suffix;
  }

  function checkOption(genre) {
    inputs.forEach(function (input) {
      input.checked = input.value === genre;
    });
  }

  function show(genre) {
    const books = visibleBooks(genre);
    current = genre;
    checkOption(genre);
    renderCards(books);
    renderCount(books, genre);
  }

  // Each genre change adds one history entry. Some contexts (file://, or
  // a browser that refuses the update) throw here; the filter still works.
  function pushGenre(genre) {
    const url = genre === ALL ? 'books.html' : 'books.html?genre=' + encodeURIComponent(slugify(genre));
    try {
      history.pushState({ genre: genre }, '', url);
    } catch (error) {
      // The URL simply stays as it is.
    }
  }

  function genreFromLocation() {
    return genreFromParam(new URLSearchParams(window.location.search).get('genre'));
  }

  buildOptions();
  show(genreFromLocation());

  optionsBox.addEventListener('change', function (event) {
    const genre = event.target.value;
    if (genre === current) {
      return;
    }
    show(genre);
    pushGenre(genre);
  });

  window.addEventListener('popstate', function () {
    show(genreFromLocation());
  });
})();

// Contact form on the visit page: labels, validation messages, focus, demo status, no network on submit.
const { describe, it, before, after } = require('node:test');
const assert = require('node:assert/strict');
const { startServer, launchBrowser, watchErrors } = require('./helpers.cjs');

describe('contact form', () => {
  let server;
  let origin;
  let browser;

  before(async () => {
    ({ server, origin } = await startServer());
    browser = await launchBrowser();
  });

  after(async () => {
    await browser.close();
    server.close();
  });

  async function openVisit() {
    const context = await browser.newContext();
    const page = await context.newPage();
    const errors = watchErrors(page);
    await page.goto(`${origin}/visit.html`);
    return { context, page, errors };
  }

  async function fill(page, values) {
    for (const [name, value] of Object.entries(values)) {
      await page.fill(`#${name}`, value);
    }
  }

  async function errorText(page, name) {
    return page.locator(`#${name}-error`).textContent();
  }

  it('has a visible label for each field and marks required fields in text', async () => {
    const { context, page } = await openVisit();
    for (const name of ['name', 'email', 'subject', 'message']) {
      const label = page.locator(`label[for="${name}"]`);
      assert.equal(await label.count(), 1, `label for ${name}`);
      assert.match(await label.textContent(), /\(required\)/, `required text for ${name}`);
      assert.equal(await page.locator(`#${name}`).getAttribute('required'), '');
    }
    assert.equal(await page.locator('#contact-form').getAttribute('novalidate'), '');
    await context.close();
  });

  it('on empty submit shows a text error per field, marks them invalid and focuses the first', async () => {
    const { context, page, errors } = await openVisit();
    await page.click('#contact-form button[type="submit"]');
    for (const name of ['name', 'email', 'subject', 'message']) {
      assert.equal(await page.locator(`#${name}`).getAttribute('aria-invalid'), 'true', name);
      assert.equal(await page.locator(`#${name}`).getAttribute('aria-describedby'), `${name}-error`, name);
      assert.equal(await page.locator(`#${name}-error`).isVisible(), true, name);
      assert.ok((await errorText(page, name)).length > 0, `text for ${name}`);
    }
    assert.equal(await errorText(page, 'name'), 'Please enter your name.');
    assert.equal(await page.evaluate(() => document.activeElement.id), 'name');
    assert.equal(await page.locator('#form-status').textContent(), '');
    assert.deepEqual(errors, []);
    await context.close();
  });

  it('treats whitespace-only name and message as empty', async () => {
    const { context, page } = await openVisit();
    await fill(page, { name: '   ', email: 'reader@example.com', subject: 'Hours', message: '  \n\t ' });
    await page.click('#contact-form button[type="submit"]');
    assert.equal(await errorText(page, 'name'), 'Please enter your name.');
    assert.equal(await errorText(page, 'message'), 'Please enter a message.');
    assert.equal(await page.locator('#email-error').isHidden(), true);
    await context.close();
  });

  it('rejects malformed email addresses with the exact message', async () => {
    const { context, page } = await openVisit();
    const expected = 'Please enter an email address in the form name@example.com.';
    for (const bad of ['a@b', 'not-an-email', 'a b@c.d', '@example.com']) {
      await fill(page, { name: 'Ada', email: bad, subject: 'Hours', message: 'Hello' });
      await page.click('#contact-form button[type="submit"]');
      assert.equal(await errorText(page, 'email'), expected, `email ${bad}`);
      assert.equal(await page.locator('#email').getAttribute('aria-invalid'), 'true', bad);
    }
    await fill(page, { email: '  ada@example.co.uk  ' });
    await page.click('#contact-form button[type="submit"]');
    assert.equal(await page.locator('#email-error').isHidden(), true, 'trimmed valid email accepted');
    await context.close();
  });

  it('clears an error as soon as the field is corrected', async () => {
    const { context, page } = await openVisit();
    await page.click('#contact-form button[type="submit"]');
    await page.fill('#name', 'Ada');
    assert.equal(await page.locator('#name-error').isHidden(), true);
    assert.equal(await page.locator('#name').getAttribute('aria-invalid'), null);
    assert.equal(await page.locator('#name').getAttribute('aria-describedby'), null);
    await context.close();
  });

  it('moves focus to the first invalid field, not the first field', async () => {
    const { context, page } = await openVisit();
    await fill(page, { name: 'Ada', email: 'not-an-email', subject: 'Hours', message: 'Hello' });
    await page.click('#contact-form button[type="submit"]');
    assert.equal(await page.evaluate(() => document.activeElement.id), 'email');
    await context.close();
  });

  it('shows a demo status that says the message was not sent, with no network request', async () => {
    const { context, page, errors } = await openVisit();
    await fill(page, { name: 'Ada', email: 'ada@example.com', subject: 'Hours', message: 'Are you open on Sunday?' });
    const requests = [];
    page.on('request', (req) => {
      if (!req.url().startsWith(origin + '/')) requests.push(req.url());
      if (req.method() !== 'GET') requests.push(`${req.method()} ${req.url()}`);
    });
    await page.click('#contact-form button[type="submit"]');
    const status = page.locator('#form-status');
    assert.equal(await status.getAttribute('role'), 'status');
    const text = await status.textContent();
    assert.match(text, /demo/i);
    assert.match(text, /was not sent/i);
    assert.doesNotMatch(text, /(has been|have been|was|been) sent|thank you for your message/i);
    await page.waitForTimeout(300);
    assert.deepEqual(requests, []);
    assert.deepEqual(errors, []);
    await context.close();
  });

  it('does not duplicate the status on double submit', async () => {
    const { context, page } = await openVisit();
    await fill(page, { name: 'Ada', email: 'ada@example.com', subject: 'Hours', message: 'Hello' });
    await page.dblclick('#contact-form button[type="submit"]');
    assert.equal(await page.locator('#form-status').count(), 1);
    assert.equal(await page.locator('#form-status p, #form-status li').count(), 0);
    assert.equal((await page.locator('#form-status').textContent()).match(/was not sent/gi).length, 1);
    await context.close();
  });

  it('submits through the same validation when Enter is pressed in a field', async () => {
    const { context, page } = await openVisit();
    await page.fill('#name', 'Ada');
    await page.press('#name', 'Enter');
    assert.equal(await page.locator('#name-error').isHidden(), true);
    assert.equal(await page.locator('#email-error').isVisible(), true);
    assert.equal(await page.locator('#form-status').textContent(), '');
    await context.close();
  });

  it('keeps a 5000+ character message inside the layout at 360 px', async () => {
    const { context, page } = await openVisit();
    await page.setViewportSize({ width: 360, height: 800 });
    const long = 'Supercalifragilisticexpialidocious'.repeat(200);
    await fill(page, { name: 'Ada', email: 'ada@example.com', subject: 'Hours', message: long });
    assert.ok(long.length >= 5000);
    await page.click('#contact-form button[type="submit"]');
    const overflow = await page.evaluate(() => document.documentElement.scrollWidth - window.innerWidth);
    assert.ok(overflow <= 0, `overflow ${overflow}px`);
    await context.close();
  });
});

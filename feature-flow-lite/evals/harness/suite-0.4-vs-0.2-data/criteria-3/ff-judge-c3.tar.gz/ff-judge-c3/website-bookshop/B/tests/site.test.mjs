import { test, describe } from 'node:test';
import assert from 'node:assert/strict';
import { useSite, withPage, watchErrors, PAGES } from './helpers.mjs';

const site = useSite();

describe('no external requests and no console errors', () => {
  for (const file of PAGES) {
    test(`${file} requests only the local server and logs no errors`, () =>
      withPage(site.browser, {}, async (page) => {
        const errors = watchErrors(page);
        const requests = [];
        page.on('request', (req) => requests.push(req.url()));
        await page.goto(`${site.base}/${file}`);
        await page.waitForLoadState('load');

        const origin = new URL(site.base).origin;
        const foreign = requests.filter((url) => new URL(url).origin !== origin);
        assert.deepEqual(foreign, []);
        assert.ok(requests.some((url) => url.endsWith('/css/styles.css')), 'stylesheet was requested');
        assert.deepEqual(errors, []);
      }));
  }

  test('following every nav link keeps requests local and logs no errors', () =>
    withPage(site.browser, {}, async (page) => {
      const errors = watchErrors(page);
      const origin = new URL(site.base).origin;
      const foreign = [];
      page.on('request', (req) => {
        if (new URL(req.url()).origin !== origin) foreign.push(req.url());
      });
      await page.goto(`${site.base}/index.html`);
      for (const label of ['Books', 'Events', 'Visit', 'Home']) {
        await page.locator('#site-nav').getByRole('link', { name: label, exact: true }).click();
        await page.waitForLoadState('load');
      }
      assert.deepEqual(foreign, []);
      assert.deepEqual(errors, []);
    }));
});

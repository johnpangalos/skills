// Events page: upcoming and past lists, split on the visitor's local calendar day.
(function () {
  'use strict';

  var createEl = window.Marginalia.createEl;
  var shop = window.MarginaliaData.shop;
  var split = window.Marginalia.splitEvents(
    window.MarginaliaData.events,
    window.Marginalia.localDateKey(new Date())
  );

  function bookingText(event) {
    return event.booking
      ? 'Booking required: call ' + shop.phone + ' or ask at the counter'
      : 'No booking needed';
  }

  function eventItem(event) {
    var item = createEl('li', 'event-item');
    var article = createEl('article', 'card dated');
    article.appendChild(window.Marginalia.dateBadge(event.date));

    var body = createEl('div', 'card__body');
    body.appendChild(createEl('h3', 'event__title', event.title));

    var when = createEl('p', 'dated__when');
    var time = createEl('time', null, window.Marginalia.formatEventWhen(event));
    time.setAttribute('datetime', event.date + 'T' + event.start);
    when.appendChild(time);
    body.appendChild(when);

    body.appendChild(createEl('p', 'event__booking', bookingText(event)));
    body.appendChild(createEl('p', 'event__description', event.description));

    article.appendChild(body);
    item.appendChild(article);
    return item;
  }

  function fillList(list, events, emptyText) {
    list.textContent = '';
    if (events.length === 0) {
      list.appendChild(createEl('li', 'event-item', emptyText));
      return;
    }
    events.forEach(function (event) {
      list.appendChild(eventItem(event));
    });
  }

  fillList(document.getElementById('upcoming-list'), split.upcoming,
    'No events are scheduled at the moment. Check back soon.');
  fillList(document.getElementById('past-list'), split.past,
    'No past events to show.');
})();

'use strict';

// Node 22 treats `node --test tests/` as a module path, so this entry point loads every suite.
require('./books.test.js');
require('./events.test.js');
require('./site.test.js');
require('./visit.test.js');

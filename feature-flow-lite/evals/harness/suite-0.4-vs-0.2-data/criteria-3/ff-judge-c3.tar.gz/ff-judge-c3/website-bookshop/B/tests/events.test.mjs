import { test, describe } from 'node:test';
import assert from 'node:assert/strict';
import { useSite, withPage, watchErrors } from './helpers.mjs';

const site = useSite();

const BOOK_CLUB = 'Book Club: The Salt Road';

// Opens events.html with the browser clock frozen at `now` in the given time zone.
async function eventsAt(browserOptions, now) {
  return withPage(site.browser, browserOptions, async (page) => {
    await page.clock.setFixedTime(Date.parse(now));
    await page.goto(`${site.base}/events.html`);
    return {
      upcoming: await page.$$eval('#upcoming-list h3', (hs) => hs.map((h) => h.textContent)),
      past: await page.$$eval('#past-list h3', (hs) => hs.map((h) => h.textContent)),
      upcomingDates: await page.$$eval('#upcoming-list time', (ts) => ts.map((t) => t.getAttribute('datetime')))
    };
  });
}

describe('upcoming and past events', () => {
  test('on 16 November 2026 the events after today are upcoming and the October events are past', async () => {
    const result = await eventsAt({ timezoneId: 'UTC' }, '2026-11-16T12:00:00Z');
    assert.equal(result.upcoming.length, 6);
    assert.equal(result.upcoming[0], BOOK_CLUB);
    assert.deepEqual(result.past, ['Autumn Poetry Evening', 'Halloween Story Time']);
  });

  test('upcoming events are listed in ascending date order with a datetime on each time element', async () => {
    const result = await eventsAt({ timezoneId: 'UTC' }, '2026-11-16T12:00:00Z');
    assert.deepEqual(result.upcomingDates, [...result.upcomingDates].sort());
    for (const date of result.upcomingDates) assert.match(date, /^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}$/);
  });

  test('an event dated today (local) counts as upcoming, though it is still yesterday in UTC', async () => {
    // 00:30 on 3 December in UTC+14 is 10:30 on 2 December in UTC.
    const result = await eventsAt({ timezoneId: 'Pacific/Kiritimati' }, '2026-12-03T00:30:00+14:00');
    assert.equal(result.upcoming[0], BOOK_CLUB);
    assert.ok(!result.past.includes(BOOK_CLUB));
  });

  test('late evening in UTC-11 keeps today (local) as upcoming', async () => {
    // 23:30 on 3 December in UTC-11 is 10:30 on 4 December in UTC.
    const result = await eventsAt({ timezoneId: 'Pacific/Pago_Pago' }, '2026-12-03T23:30:00-11:00');
    assert.equal(result.upcoming[0], BOOK_CLUB);
  });

  test('the next morning in UTC+14 makes yesterday (local) past, not upcoming', async () => {
    // 00:30 on 4 December in UTC+14 is 10:30 on 3 December in UTC.
    const result = await eventsAt({ timezoneId: 'Pacific/Kiritimati' }, '2026-12-04T00:30:00+14:00');
    assert.ok(result.past.includes(BOOK_CLUB));
    assert.equal(result.upcoming[0], "Kids' Winter Story Time");
  });
});

describe('event details', () => {
  test('each event has a title, a time element, a description and a booking statement', () =>
    withPage(site.browser, { timezoneId: 'UTC' }, async (page) => {
      const errors = watchErrors(page);
      await page.clock.setFixedTime(Date.parse('2026-11-16T12:00:00Z'));
      await page.goto(`${site.base}/events.html`);
      const items = await page.$$eval('#upcoming-list article, #past-list article', (articles) =>
        articles.map((a) => ({
          title: a.querySelector('h3')?.textContent,
          time: a.querySelector('time')?.textContent,
          description: a.querySelector('.event__description')?.textContent,
          booking: a.querySelector('.event__booking')?.textContent
        })));
      assert.equal(items.length, 8);
      for (const item of items) {
        assert.ok(item.title && item.time && item.description, `incomplete: ${item.title}`);
        assert.match(item.booking, /^(No booking needed|Booking required: call 01632 960417 or ask at the counter)$/);
      }
      assert.deepEqual(errors, []);
    }));
});

describe('booking line says how to book', () => {
  test('events that need booking name the phone number and the counter', () =>
    withPage(site.browser, {}, async (page) => {
      const errors = watchErrors(page);
      await page.clock.setFixedTime(Date.parse('2026-11-16T12:00:00Z'));
      await page.goto(`${site.base}/events.html`);
      const lines = await page.$$eval('#upcoming-list .event__booking', (els) => els.map((e) => e.textContent));
      assert.ok(lines.includes('Booking required: call 01632 960417 or ask at the counter'));
      assert.ok(lines.includes('No booking needed'));
      assert.deepEqual(errors, []);
    }));
});

describe('home teaser uses the same rule', () => {
  test('home lists the next three events from the local day', () =>
    withPage(site.browser, { timezoneId: 'Pacific/Kiritimati' }, async (page) => {
      const errors = watchErrors(page);
      await page.clock.setFixedTime(Date.parse('2026-12-03T00:30:00+14:00'));
      await page.goto(`${site.base}/index.html`);
      const titles = await page.$$eval('#home-events a', (as) => as.map((a) => a.textContent));
      assert.deepEqual(titles, [BOOK_CLUB, "Kids' Winter Story Time", 'Reading: Renata Solis on the Northern Coast']);
      assert.deepEqual(errors, []);
    }));
});

import unittest
from unittest import mock

from shop import auth
from shop.auth import InvalidToken, TokenExpired, TokenUsed, issue_reset_token, redeem_reset_token


class ResetTokenTest(unittest.TestCase):
    def setUp(self):
        auth._TOKENS.clear()

    def test_round_trip(self):
        token = issue_reset_token("ada")
        self.assertEqual(redeem_reset_token(token), "ada")

    def test_unknown_token(self):
        with self.assertRaises(InvalidToken) as cm:
            redeem_reset_token("not-a-token")
        self.assertIs(type(cm.exception), InvalidToken)
        self.assertEqual(str(cm.exception), "unknown token")

    def test_empty_token_is_plain_invalid(self):
        with self.assertRaises(InvalidToken) as cm:
            redeem_reset_token("")
        self.assertIs(type(cm.exception), InvalidToken)
        self.assertEqual(str(cm.exception), "unknown token")

    def test_zero_timestamp_is_real_at_issue_and_redeem(self):
        token = issue_reset_token("ada", now=0)
        self.assertEqual(redeem_reset_token(token, now=0), "ada")

    def test_zero_issue_time_is_not_defaulted(self):
        token = issue_reset_token("ada", now=0)
        with self.assertRaises(TokenExpired):
            redeem_reset_token(token, now=1801)

    def test_zero_redeem_time_is_not_defaulted(self):
        token = issue_reset_token("ada", now=5)
        self.assertEqual(redeem_reset_token(token, now=0), "ada")

    def test_exactly_window_succeeds(self):
        token = issue_reset_token("ada", now=1000)
        self.assertEqual(redeem_reset_token(token, now=2800), "ada")

    def test_just_past_window_expires(self):
        token = issue_reset_token("ada", now=1000)
        with self.assertRaises(TokenExpired) as cm:
            redeem_reset_token(token, now=2800.001)
        self.assertEqual(str(cm.exception), "token expired")

    def test_well_past_window_expires(self):
        token = issue_reset_token("ada", now=1000)
        with self.assertRaises(TokenExpired):
            redeem_reset_token(token, now=2801)

    def test_float_timestamps_at_window_edge(self):
        token = issue_reset_token("ada", now=1000.5)
        self.assertEqual(redeem_reset_token(token, now=2800.5), "ada")
        other = issue_reset_token("ada", now=1000.5)
        with self.assertRaises(TokenExpired):
            redeem_reset_token(other, now=2800.501)

    def test_redeem_before_issue_time_succeeds(self):
        token = issue_reset_token("ada", now=1000)
        self.assertEqual(redeem_reset_token(token, now=500), "ada")

    def test_second_redeem_raises_used(self):
        token = issue_reset_token("ada", now=0)
        self.assertEqual(redeem_reset_token(token, now=100), "ada")
        with self.assertRaises(TokenUsed) as cm:
            redeem_reset_token(token, now=100)
        self.assertEqual(str(cm.exception), "token already used")

    def test_used_wins_over_expired(self):
        token = issue_reset_token("ada", now=0)
        self.assertEqual(redeem_reset_token(token, now=100), "ada")
        with self.assertRaises(TokenUsed):
            redeem_reset_token(token, now=5000)

    def test_expired_redeem_does_not_consume(self):
        token = issue_reset_token("ada", now=0)
        with self.assertRaises(TokenExpired):
            redeem_reset_token(token, now=1801)
        with self.assertRaises(TokenExpired) as cm:
            redeem_reset_token(token, now=1802)
        self.assertIs(type(cm.exception), TokenExpired)

    def test_subclasses_of_invalid_token(self):
        self.assertTrue(issubclass(TokenExpired, InvalidToken))
        self.assertTrue(issubclass(TokenUsed, InvalidToken))

    def test_except_invalid_token_catches_all(self):
        token = issue_reset_token("ada", now=0)
        redeem_reset_token(token, now=0)
        for now in (1, 5000):
            with self.assertRaises(InvalidToken):
                redeem_reset_token(token, now=now)

    def test_nan_redeem_time_fails_closed(self):
        token = issue_reset_token("ada", now=1000)
        with self.assertRaises(TokenExpired) as cm:
            redeem_reset_token(token, now=float("nan"))
        self.assertEqual(str(cm.exception), "token expired")

    def test_nan_issue_time_fails_closed(self):
        token = issue_reset_token("ada", now=float("nan"))
        with self.assertRaises(TokenExpired):
            redeem_reset_token(token, now=1000)

    def test_default_now_reads_clock_at_call_time(self):
        with mock.patch.object(auth.time, "time", return_value=1000):
            token = issue_reset_token("ada")
        with mock.patch.object(auth.time, "time", return_value=2800):
            self.assertEqual(redeem_reset_token(token), "ada")
        with mock.patch.object(auth.time, "time", return_value=1000):
            stale = issue_reset_token("ada")
        with mock.patch.object(auth.time, "time", return_value=2801):
            with self.assertRaises(TokenExpired):
                redeem_reset_token(stale)

import unittest
from unittest.mock import patch

from shop.auth import (
    InvalidToken,
    TokenExpired,
    TokenUsed,
    issue_reset_token,
    redeem_reset_token,
)


class ResetTokenTest(unittest.TestCase):
    def test_round_trip(self):
        token = issue_reset_token("ada")
        self.assertEqual(redeem_reset_token(token), "ada")

    def test_exactly_1800_seconds_is_valid(self):
        token = issue_reset_token("ada", now=1000)
        self.assertEqual(redeem_reset_token(token, now=2800), "ada")

    def test_1801_seconds_is_expired(self):
        token = issue_reset_token("ada", now=1000)
        with self.assertRaises(TokenExpired) as cm:
            redeem_reset_token(token, now=2801)
        self.assertEqual(str(cm.exception), "token expired")

    def test_float_boundary(self):
        token = issue_reset_token("ada", now=1700000000.5)
        self.assertEqual(redeem_reset_token(token, now=1700001800.5), "ada")
        other = issue_reset_token("ada", now=1700000000.5)
        with self.assertRaises(TokenExpired):
            redeem_reset_token(other, now=1700001800.501)

    def test_clock_skew_before_issue_is_valid(self):
        token = issue_reset_token("ada", now=1000)
        self.assertEqual(redeem_reset_token(token, now=900), "ada")

    def test_second_redemption_is_token_used(self):
        token = issue_reset_token("ada", now=1000)
        self.assertEqual(redeem_reset_token(token, now=1000), "ada")
        with self.assertRaises(TokenUsed) as cm:
            redeem_reset_token(token, now=1000)
        self.assertEqual(str(cm.exception), "token already used")

    def test_used_after_expiry_is_token_used(self):
        token = issue_reset_token("ada", now=1000)
        redeem_reset_token(token, now=1000)
        with self.assertRaises(TokenUsed):
            redeem_reset_token(token, now=5000)

    def test_expired_token_stays_expired_on_retry(self):
        token = issue_reset_token("ada", now=1000)
        with self.assertRaises(TokenExpired):
            redeem_reset_token(token, now=3000)
        with self.assertRaises(TokenExpired):
            redeem_reset_token(token, now=3000)

    def test_two_tokens_for_same_user_are_independent(self):
        first = issue_reset_token("ada", now=1000)
        second = issue_reset_token("ada", now=1000)
        self.assertEqual(redeem_reset_token(first, now=1000), "ada")
        self.assertEqual(redeem_reset_token(second, now=1000), "ada")

    def test_now_zero_is_honored(self):
        with patch("time.time", return_value=5000.0):
            token = issue_reset_token("ada", now=0)
        with self.assertRaises(TokenExpired):
            redeem_reset_token(token, now=1801)

    def test_now_zero_redeem_is_honored(self):
        token = issue_reset_token("ada", now=0)
        with patch("time.time", return_value=5000.0):
            self.assertEqual(redeem_reset_token(token, now=0), "ada")

    def test_default_now_uses_time_time(self):
        with patch("time.time", return_value=1000.0):
            token = issue_reset_token("ada")
        with patch("time.time", return_value=2801.0):
            with self.assertRaises(TokenExpired):
                redeem_reset_token(token)

    def test_unknown_token(self):
        for bad in ("not-a-token", ""):
            with self.assertRaises(InvalidToken) as cm:
                redeem_reset_token(bad)
            self.assertNotIsInstance(cm.exception, TokenExpired)
            self.assertNotIsInstance(cm.exception, TokenUsed)
            self.assertEqual(str(cm.exception), "unknown token")

    def test_error_subclasses(self):
        self.assertTrue(issubclass(TokenExpired, InvalidToken))
        self.assertTrue(issubclass(TokenUsed, InvalidToken))

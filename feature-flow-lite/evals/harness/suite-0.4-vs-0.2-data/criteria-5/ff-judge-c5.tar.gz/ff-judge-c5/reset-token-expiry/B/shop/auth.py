"""Password-reset tokens (in-memory store)."""

import secrets
import time

RESET_WINDOW = 1800  # seconds a token stays redeemable after issue

_TOKENS = {}  # token -> {"username", "issued_at", "used"}


class InvalidToken(Exception):
    pass


class TokenExpired(InvalidToken):
    pass


class TokenUsed(InvalidToken):
    pass


def issue_reset_token(username, now=None):
    """Create a reset token for username, issued at now (default: time.time())."""
    if now is None:
        now = time.time()
    token = secrets.token_urlsafe(16)
    _TOKENS[token] = {"username": username, "issued_at": now, "used": False}
    return token


def redeem_reset_token(token, now=None):
    """Return the username a token was issued for; a token redeems only once."""
    if now is None:
        now = time.time()
    record = _TOKENS.get(token)
    if record is None:
        raise InvalidToken("unknown token")
    if record["used"]:
        raise TokenUsed("token already used")
    # Written as "not <=" so NaN timestamps compare false and fail closed.
    if not now - record["issued_at"] <= RESET_WINDOW:
        raise TokenExpired("token expired")
    record["used"] = True
    return record["username"]

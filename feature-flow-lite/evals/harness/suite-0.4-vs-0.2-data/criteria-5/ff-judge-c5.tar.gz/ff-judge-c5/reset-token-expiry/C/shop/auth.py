"""Password-reset tokens (in-memory store)."""

import secrets
import time

TOKEN_TTL_SECONDS = 1800  # reset tokens expire this long after issue (inclusive)

_TOKENS = {}  # token -> (username, issued_at in Unix seconds)
_USED = set()  # tokens already redeemed


class InvalidToken(Exception):
    pass


class TokenExpired(InvalidToken):
    pass


class TokenUsed(InvalidToken):
    pass


def issue_reset_token(username, now=None):
    """Create a reset token for username, issued at now (default time.time())."""
    if now is None:
        now = time.time()
    token = secrets.token_urlsafe(16)
    _TOKENS[token] = (username, now)
    return token


def redeem_reset_token(token, now=None):
    """Return the username a token was issued for, marking the token used.

    Raises InvalidToken for an unknown token, TokenUsed if it was already
    redeemed, and TokenExpired if more than TOKEN_TTL_SECONDS have passed
    since issue. Only a successful redemption consumes the token.
    """
    if now is None:
        now = time.time()
    entry = _TOKENS.get(token)
    if entry is None:
        raise InvalidToken("unknown token")
    if token in _USED:
        raise TokenUsed("token already used")
    username, issued_at = entry
    if not now - issued_at <= TOKEN_TTL_SECONDS:  # fails closed on NaN
        raise TokenExpired("token expired")
    _USED.add(token)
    return username

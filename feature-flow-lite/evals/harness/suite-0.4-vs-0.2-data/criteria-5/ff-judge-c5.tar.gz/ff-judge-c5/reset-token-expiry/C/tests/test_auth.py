import unittest
from unittest import mock

from shop.auth import InvalidToken, TokenExpired, TokenUsed, issue_reset_token, redeem_reset_token


class ResetTokenTest(unittest.TestCase):
    def test_round_trip(self):
        token = issue_reset_token("ada")
        self.assertEqual(redeem_reset_token(token), "ada")

    def test_unknown_token(self):
        with self.assertRaises(InvalidToken):
            redeem_reset_token("not-a-token")

    def test_unknown_token_is_plain_invalid_token(self):
        for bad in ("", None, "never-issued"):
            with self.subTest(token=bad):
                with self.assertRaises(InvalidToken) as ctx:
                    redeem_reset_token(bad)
                self.assertIs(type(ctx.exception), InvalidToken)
                self.assertEqual(str(ctx.exception), "unknown token")

    def test_omitted_now_uses_clock_at_call_time(self):
        with mock.patch("shop.auth.time.time", return_value=1000.0):
            token = issue_reset_token("ada")
        with mock.patch("shop.auth.time.time", return_value=1000.0 + 1801):
            with self.assertRaises(TokenExpired):
                redeem_reset_token(token)

    def test_redeem_at_exactly_ttl_succeeds(self):
        token = issue_reset_token("ada", now=1000)
        self.assertEqual(redeem_reset_token(token, now=1000 + 1800), "ada")

    def test_redeem_after_ttl_expires(self):
        token = issue_reset_token("ada", now=1000)
        with self.assertRaises(TokenExpired) as ctx:
            redeem_reset_token(token, now=1000 + 1801)
        self.assertEqual(str(ctx.exception), "token expired")

    def test_fractional_age_past_ttl_expires(self):
        token = issue_reset_token("ada", now=1000)
        with self.assertRaises(TokenExpired):
            redeem_reset_token(token, now=1000 + 1800.001)

    def test_float_now_accepted(self):
        token = issue_reset_token("ada", now=1000.5)
        self.assertEqual(redeem_reset_token(token, now=1000.5 + 1800), "ada")

    def test_redeem_before_issue_time_succeeds(self):
        token = issue_reset_token("ada", now=1000)
        self.assertEqual(redeem_reset_token(token, now=900), "ada")

    def test_nan_now_is_expired(self):
        token = issue_reset_token("ada", now=1000)
        with self.assertRaises(TokenExpired):
            redeem_reset_token(token, now=float("nan"))
        token = issue_reset_token("ada", now=float("nan"))
        with self.assertRaises(TokenExpired):
            redeem_reset_token(token, now=1000)

    def test_now_zero_is_honored(self):
        expired = issue_reset_token("ada", now=0)
        with self.assertRaises(TokenExpired):
            redeem_reset_token(expired, now=1801)
        valid = issue_reset_token("ada", now=0)
        self.assertEqual(redeem_reset_token(valid, now=1800), "ada")

    def test_reuse_at_same_time_is_token_used(self):
        token = issue_reset_token("ada", now=1000)
        redeem_reset_token(token, now=1000)
        with self.assertRaises(TokenUsed) as ctx:
            redeem_reset_token(token, now=1000)
        self.assertEqual(str(ctx.exception), "token already used")

    def test_reuse_after_ttl_is_token_used_not_expired(self):
        token = issue_reset_token("ada", now=1000)
        redeem_reset_token(token, now=1001)
        with self.assertRaises(TokenUsed):
            redeem_reset_token(token, now=1000 + 1801)

    def test_distinct_tokens_for_same_user_are_independent(self):
        first = issue_reset_token("ada", now=1000)
        second = issue_reset_token("ada", now=1000)
        redeem_reset_token(first, now=1000)
        self.assertEqual(redeem_reset_token(second, now=1000), "ada")

    def test_expired_token_stays_expired_on_retry(self):
        token = issue_reset_token("ada", now=1000)
        for _ in range(2):
            with self.assertRaises(TokenExpired) as ctx:
                redeem_reset_token(token, now=1000 + 1801)
            self.assertIs(type(ctx.exception), TokenExpired)

    def test_expired_and_used_are_invalid_token_subclasses(self):
        self.assertTrue(issubclass(TokenExpired, InvalidToken))
        self.assertTrue(issubclass(TokenUsed, InvalidToken))
        expired = issue_reset_token("ada", now=1000)
        with self.assertRaises(InvalidToken) as ctx:
            redeem_reset_token(expired, now=1000 + 1801)
        self.assertIs(type(ctx.exception), TokenExpired)
        used = issue_reset_token("ada", now=1000)
        redeem_reset_token(used, now=1000)
        with self.assertRaises(InvalidToken) as ctx:
            redeem_reset_token(used, now=1000)
        self.assertIs(type(ctx.exception), TokenUsed)

import abc
import importlib.metadata
import inspect
import warnings

import pytest

import click
import click.core
import click.parser
import click.shell_completion
import click.utils


@pytest.mark.parametrize(
    ("module", "name", "target"),
    [
        # Stream helpers, re-exported from both `click` and `click.utils`.
        (click, "get_binary_stream", click.utils._get_binary_stream),
        (click, "get_text_stream", click.utils._get_text_stream),
        (click.utils, "get_binary_stream", click.utils._get_binary_stream),
        (click.utils, "get_text_stream", click.utils._get_text_stream),
        # Command-class aliases, re-exported from `click` and `click.core`.
        (click, "BaseCommand", click.core._BaseCommand),
        (click, "MultiCommand", click.core._MultiCommand),
        (click.core, "BaseCommand", click.core._BaseCommand),
        (click.core, "MultiCommand", click.core._MultiCommand),
        # Old parser API (moved to `optparse`); `OptionParser` is also
        # re-exported from the top-level `click` namespace.
        (click, "OptionParser", click.parser._OptionParser),
        (click.parser, "OptionParser", click.parser._OptionParser),
        (click.parser, "Argument", click.parser._Argument),
        (click.parser, "Option", click.parser._Option),
        (click.parser, "split_opt", click.parser._split_opt),
        (click.parser, "normalize_opt", click.parser._normalize_opt),
        (click.parser, "ParsingState", click.parser._ParsingState),
        (click.parser, "split_arg_string", click.shell_completion.split_arg_string),
        # Deprecated `click.utils` utilities.
        (click.utils, "LazyFile", click.utils._LazyFile),
        (click.utils, "KeepOpenFile", click.utils._KeepOpenFile),
        (click.utils, "make_default_short_help", click.utils._make_default_short_help),
        (click.utils, "PacifyFlushWrapper", click.utils._PacifyFlushWrapper),
        (click.utils, "safecall", click.utils._safecall),
        # Version metadata attribute.
        (click, "__version__", importlib.metadata.version("click")),
    ],
    ids=lambda v: getattr(v, "__name__", v),
)
def test_attr_deprecated(module, name, target):
    with pytest.warns(DeprecationWarning, match=name):
        value = getattr(module, name)

    assert value == target


@pytest.mark.parametrize(
    "module",
    [click, click.core, click.parser, click.utils],
    ids=lambda m: m.__name__,
)
def test_unknown_attribute_raises(module):
    with pytest.raises(AttributeError, match="no_such_attribute"):
        _ = module.no_such_attribute


def test_context_protected_args_deprecated():
    ctx = click.Context(click.Command("cli"))

    with pytest.warns(DeprecationWarning, match="protected_args"):
        assert ctx.protected_args == []


def test_isolated_filesystem_deprecated(runner):
    with pytest.warns(DeprecationWarning, match="isolated_filesystem"):
        with runner.isolated_filesystem():
            pass


@pytest.mark.parametrize(
    ("make_param", "match"),
    [
        pytest.param(
            lambda: click.Argument(["0foo"]),
            "not a valid Python identifier",
            id="argument-leading-digit",
        ),
        pytest.param(
            lambda: click.Argument(["foo.bar"]),
            "not a valid Python identifier",
            id="argument-dot",
        ),
        pytest.param(
            lambda: click.Argument(["foo bar"]),
            "not a valid Python identifier",
            id="argument-space",
        ),
        pytest.param(
            lambda: click.Argument([""]),
            "not a valid Python identifier",
            id="argument-empty-decl",
        ),
        pytest.param(
            lambda: click.Argument(["0foo"], expose_value=False),
            "not a valid Python identifier",
            id="argument-unexposed",
        ),
        pytest.param(
            lambda: click.Argument([], expose_value=False),
            "not a valid Python identifier",
            id="argument-no-decl",
        ),
        pytest.param(
            lambda: click.Option(["--0foo"], expose_value=False),
            "not a valid Python identifier",
            id="option-unexposed",
        ),
        pytest.param(
            lambda: click.Option([], expose_value=False),
            "not a valid Python identifier",
            id="option-no-decl",
        ),
        # A keyword is an identifier too, so this rule alone reports it.
        pytest.param(
            lambda: click.Option(["--from"]),
            "is a Python keyword",
            id="option-from",
        ),
        pytest.param(
            lambda: click.Option(["--import"]),
            "is a Python keyword",
            id="option-import",
        ),
        pytest.param(
            lambda: click.Argument(["class"]),
            "is a Python keyword",
            id="argument-class",
        ),
    ],
)
def test_unusable_name_deprecated(make_param, match):
    """A name Click 9.0 refuses reports which of its two rules it broke."""
    with pytest.warns(DeprecationWarning, match=match):
        make_param()


@pytest.mark.parametrize(
    "make_param",
    [
        pytest.param(lambda: click.Argument(["foo-bar"]), id="argument-hyphen"),
        pytest.param(lambda: click.Argument(["Foo_Bar"]), id="argument-case"),
        pytest.param(lambda: click.Option(["--foo-bar"]), id="option-hyphen"),
        pytest.param(
            lambda: click.Option(["--0foo", "zero_foo"]), id="option-explicit-name"
        ),
        # Soft keywords are contextual and name a parameter fine.
        pytest.param(lambda: click.Option(["--match"]), id="soft-keyword-match"),
        pytest.param(lambda: click.Argument(["type"]), id="soft-keyword-type"),
        # These lower case out of the keyword set.
        pytest.param(lambda: click.Option(["--True"]), id="true"),
        pytest.param(lambda: click.Option(["--None"]), id="none"),
    ],
)
def test_usable_name_not_deprecated(recwarn, make_param):
    """A name a callback can declare keeps working, and says nothing."""
    make_param()
    assert [w for w in recwarn if issubclass(w.category, DeprecationWarning)] == []


@pytest.mark.parametrize(
    "make_param",
    [
        pytest.param(lambda: click.Option(["--from"]), id="keyword"),
        pytest.param(lambda: click.Argument(["0foo"]), id="non-identifier"),
    ],
)
def test_unusable_name_names_the_release_that_refuses_it(make_param):
    """Both refusals name the release that turns the warning into an error."""
    match = r"will raise a TypeError in Click 9\.0"
    with pytest.warns(DeprecationWarning, match=match):
        make_param()


@pytest.mark.parametrize(
    ("decl", "expect"),
    [
        pytest.param("Foo_Bar", "foo_bar", id="mixed-case"),
        pytest.param("X_Y", "x_y", id="upper-case"),
        pytest.param("ΟΔΟΣ", "οδος", id="final-sigma"),
        pytest.param("\N{KELVIN SIGN}", "k", id="kelvin-sign"),
    ],
)
def test_unnormalized_explicit_name_deprecated(decl, expect):
    """Click 9.0 lower cases an explicit name like any other declaration."""
    with pytest.warns(DeprecationWarning, match="lower cases an explicit name"):
        param = click.Option(["--x", decl])

    assert param.name == decl
    assert decl.lower() == expect


@pytest.mark.parametrize(
    "decls",
    [
        pytest.param(["--x", "foo_bar"], id="already-lower"),
        pytest.param(["--x", "_from"], id="leading-underscore"),
        pytest.param(["--Foo-Bar"], id="derived-not-explicit"),
        pytest.param(["--x", "café"], id="lower-case-non-ascii"),
    ],
)
def test_normalized_explicit_name_not_deprecated(recwarn, decls):
    """A name already spelled the way 9.0 spells it says nothing."""
    click.Option(decls)
    assert [w for w in recwarn if issubclass(w.category, DeprecationWarning)] == []


def test_unnormalized_name_on_a_refused_option_is_silent():
    """An option that cannot be built at all warns about nothing."""
    with pytest.raises(TypeError, match="No options defined"):
        with warnings.catch_warnings():
            warnings.simplefilter("error", DeprecationWarning)
            click.Option(["Foo_Bar"])


@pytest.mark.parametrize(
    ("make_param", "expected"),
    [
        pytest.param(lambda: click.Option(["--times"]), "--times", id="option"),
        pytest.param(lambda: click.Argument(["filename"]), "FILENAME", id="argument"),
    ],
)
def test_human_readable_name_deprecated(make_param, expected):
    """Reading the old name warns at the caller's line and returns the spec."""
    param = make_param()

    with pytest.warns(DeprecationWarning) as record:
        assert param.human_readable_name == expected

    assert len(record) == 1
    assert str(record[0].message) == (
        "'human_readable_name' is deprecated and will be removed in Click 9.0."
        " Use 'spec' instead."
    )
    assert record[0].filename == __file__


def test_overriding_human_readable_name_warns_at_class_statement():
    with pytest.warns(DeprecationWarning, match="overrides") as record:
        lineno = inspect.currentframe().f_lineno + 2

        class Legacy(click.Option):
            @property
            def human_readable_name(self):
                return "legacy"

    assert len(record) == 1
    assert str(record[0].message) == (
        "Legacy overrides 'human_readable_name', which is deprecated and will be"
        " removed in Click 9.0. Override 'spec' instead."
    )
    assert record[0].filename == __file__
    assert record[0].lineno == lineno


@pytest.mark.parametrize(
    "namespace",
    [
        pytest.param(
            {"human_readable_name": property(lambda self: "x")}, id="property"
        ),
        pytest.param({"human_readable_name": "x"}, id="attribute"),
        pytest.param({"human_readable_name": lambda self: "x"}, id="method"),
    ],
)
def test_overriding_human_readable_name_kinds_warn(namespace):
    with pytest.warns(DeprecationWarning, match="overrides 'human_readable_name'"):
        type("Legacy", (click.Option,), namespace)


class _NameMixin:
    human_readable_name = "mixin"


def test_mixin_human_readable_name_warns():
    with pytest.warns(DeprecationWarning, match="overrides 'human_readable_name'"):

        class Mixed(_NameMixin, click.Option):
            pass


def test_subclass_of_overriding_class_does_not_warn_again(recwarn):
    class Legacy(click.Option):
        @property
        def human_readable_name(self):
            return "legacy"

    class Mixed(_NameMixin, click.Option):
        pass

    recwarn.clear()

    class Further(Legacy):
        pass

    class MixedFurther(Mixed):
        pass

    assert [w for w in recwarn if issubclass(w.category, DeprecationWarning)] == []


def test_overriding_spec_does_not_warn(recwarn):
    class Renamed(click.Option):
        @property
        def spec(self):
            return "--renamed"

    assert [w for w in recwarn if issubclass(w.category, DeprecationWarning)] == []


def test_overridden_spec_names_the_parameter_in_messages(runner):
    class Renamed(click.Option):
        @property
        def spec(self):
            return "--renamed"

    class RenamedArgument(click.Argument):
        @property
        def spec(self):
            return "OTHER"

    cli = click.Command("cli", params=[Renamed(["--my-option"], deprecated=True)])
    result = runner.invoke(cli, ["--my-option", "x"])
    assert "The option '--renamed' is deprecated." in result.output
    assert RenamedArgument(["a"]).get_error_hint(None) == "'OTHER'"


def test_overridden_human_readable_name_is_not_used_by_click(runner):
    with pytest.warns(DeprecationWarning, match="overrides"):

        class Legacy(click.Option):
            @property
            def human_readable_name(self):
                return "legacy"

    cli = click.Command("cli", params=[Legacy(["--my-option"], deprecated=True)])
    result = runner.invoke(cli, ["--my-option", "x"])
    assert "The option '--my-option' is deprecated." in result.output
    assert "legacy" not in result.output


@pytest.mark.parametrize(
    ("make_param", "expected"),
    [
        pytest.param(
            lambda: click.Option(["-m", "--my-option"], required=True, deprecated=True),
            "The option '--my-option' is deprecated and still required. A deprecated"
            " option cannot be required.",
            id="option",
        ),
        pytest.param(
            lambda: click.Argument(["my-argument"], required=True, deprecated=True),
            "The argument 'MY_ARGUMENT' is deprecated and still required. A deprecated"
            " argument cannot be required.",
            id="argument",
        ),
    ],
)
def test_deprecated_required_names_spec(make_param, expected):
    with pytest.raises(ValueError) as excinfo:
        make_param()

    assert str(excinfo.value) == expected


class _TracingMeta(abc.ABCMeta):
    def __new__(mcls, *args, **kwargs):
        return super().__new__(mcls, *args, **kwargs)


class _CooperativeBase(click.Option):
    def __init_subclass__(cls, **kwargs):
        super().__init_subclass__(**kwargs)


def test_overriding_under_custom_metaclass_warns_at_class_statement():
    with pytest.warns(DeprecationWarning, match="overrides") as record:
        lineno = inspect.currentframe().f_lineno + 2

        class Custom(click.Option, metaclass=_TracingMeta):
            human_readable_name = "x"

    assert len(record) == 1
    assert record[0].filename == __file__
    assert record[0].lineno == lineno


def test_overriding_under_cooperative_init_subclass_warns_at_class_statement():
    with pytest.warns(DeprecationWarning, match="overrides") as record:
        lineno = inspect.currentframe().f_lineno + 2

        class Cooperative(_CooperativeBase):
            human_readable_name = "x"

    assert len(record) == 1
    assert record[0].filename == __file__
    assert record[0].lineno == lineno


def test_mixin_first_override_warns_at_class_statement():
    with pytest.warns(DeprecationWarning, match="overrides") as record:
        lineno = inspect.currentframe().f_lineno + 2

        class Mixed(_NameMixin, click.Option):
            human_readable_name = "x"

    assert len(record) == 1
    assert record[0].filename == __file__
    assert record[0].lineno == lineno


def test_type_call_override_warns_at_call_line():
    with pytest.warns(DeprecationWarning, match="overrides") as record:
        lineno = inspect.currentframe().f_lineno + 1
        type("X", (click.Option,), {"human_readable_name": "x"})

    assert len(record) == 1
    assert record[0].filename == __file__
    assert record[0].lineno == lineno

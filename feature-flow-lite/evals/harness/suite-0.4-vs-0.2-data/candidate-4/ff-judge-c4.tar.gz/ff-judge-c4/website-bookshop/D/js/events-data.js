// Marginalia Books events. Dates are local calendar dates (YYYY-MM-DD) and times are
// local 24-hour times. events.js decides which events are past or upcoming in the visitor's
// own time zone, so nothing here needs updating as days pass.
window.EVENTS = [
  {
    name: 'Ink and Ember: An Autumn Reading',
    date: '2026-10-14',
    time: '19:00',
    admission: 'Free entry',
    description: 'Four local writers read from new work in the reading room, followed by a short question session and mulled cider at the counter.',
  },
  {
    name: 'Open Mic for Poets',
    date: '2026-11-07',
    time: '18:30',
    admission: 'Free entry',
    description: 'Bring three minutes of verse, or simply come and listen. Sign-up opens at 18:00 at the till, and everyone gets a turn.',
  },
  {
    name: 'Mystery Book Club: The Salt Ledger',
    date: '2026-11-21',
    time: '19:00',
    admission: 'Booking required',
    description: 'We read The Salt Ledger together and argue about the ending. Copies are on the shelf by the door. Please book a seat so we can set out enough chairs.',
  },
  {
    name: 'Launch of the Nightjar Press Chapbooks',
    date: '2026-11-28',
    time: '18:00',
    admission: 'Free entry',
    description: 'Nightjar Press launches three handmade chapbooks of poetry, with a short reading from each poet and a chance to buy signed copies.',
  },
  {
    name: 'Winter Solstice Reading Night',
    date: '2026-12-05',
    time: '19:30',
    admission: 'Ticketed: £8, including a book voucher',
    description: 'A long evening of winter stories read aloud by candlelight. Tickets include a mulled drink and a small voucher to spend in the shop.',
  },
  {
    name: 'Stories for Little Readers',
    date: '2026-12-12',
    time: '10:30',
    admission: 'Booking required',
    description: 'A Saturday morning of picture books and rhymes for ages three to six. Parents and carers stay in the room, and the rug is well padded.',
  },
  {
    name: 'Essays in Conversation',
    date: '2027-01-16',
    time: '19:00',
    admission: 'Ticketed: £6',
    description: 'Gervase Lowe and Nadia Solenko talk about the craft of the essay and the discipline of keeping things short, with questions from the floor.',
  },
  {
    name: 'Science Fiction Salon',
    date: '2027-02-13',
    time: '19:00',
    admission: 'Free entry',
    description: 'Readers talk through Orbit of the Long Night and The Quiet Relay, with a table of other favourites to browse and borrow for the evening.',
  },
  {
    name: 'Spring Bookbinding Workshop',
    date: '2027-03-06',
    time: '14:00',
    admission: 'Booking required, materials £35',
    description: 'Make a stitched notebook in an afternoon with a local bookbinder. All materials are supplied, and places are limited to twelve.',
  },
];

/*
 * Marginalia Books: the fictional catalogue, events and opening hours.
 * Pages render from window.Marginalia. Helpers here are pure so every page
 * works out "today" and genres the same way.
 */
(function () {
  'use strict';

  var books = [
    {
      title: "The Cartographer's Daughter",
      author: 'Ilse Marrow',
      genre: 'Literary Fiction',
      blurb: 'A surveyor\'s orphan inherits her father\'s unfinished maps of a coastline that keeps shifting. Every sheet she redraws changes the town a little.',
      price: 12.99,
      featured: true
    },
    {
      title: 'Salt & Ember',
      author: 'Rosalind Pike',
      genre: 'Literary Fiction',
      blurb: 'Three generations of a fishing family argue over a kiln they can no longer afford to fire. A quiet novel about inheritance, weather and the cost of staying put.',
      price: 11.5,
      featured: false
    },
    {
      title: 'Orchard Winter',
      author: 'Samuel Okonedo-Hale',
      genre: 'Literary Fiction',
      blurb: 'A retired schoolteacher tends a neglected orchard through its first hard frost. A visit from the grandson she has not seen in years makes the season harder.',
      price: 10.99,
      featured: false
    },
    {
      title: "The Lamplighter's Alibi",
      author: 'Teodora Blackwood',
      genre: 'Mystery',
      blurb: 'When the night lamplighter of a cathedral town is found drowned, the only witness has a perfect alibi and a very imperfect memory.',
      price: 9.99,
      featured: true
    },
    {
      title: 'Nine Bells for Mrs Fairweather',
      author: 'Gideon Strand',
      genre: 'Mystery',
      blurb: 'A village choir director receives nine bells in the post, one for each suspect, and a single note: start with the organist.',
      price: 8.99,
      featured: false
    },
    {
      title: '"Do Not Disturb" at Hollis Court',
      author: 'Bea Tanaka-Lowe',
      genre: 'Mystery',
      blurb: 'A hotel inspector checks into a crumbling country house the week before its owners vanish. The guest list refuses to add up.',
      price: 10.5,
      featured: false
    },
    {
      title: 'Field Notes for a Wet Spring',
      author: 'Maeve Corrigan',
      genre: 'Poetry',
      blurb: 'Forty short poems written in the back of a van during a damp, stubborn spring on the moors.',
      price: 9.5,
      featured: false
    },
    {
      title: 'The Weight of Small Birds',
      author: 'Tomasz Wren',
      genre: 'Poetry',
      blurb: 'Poems about garden sparrows, border crossings and the small, deliberate courage of keeping a home.',
      price: 10,
      featured: false
    },
    {
      title: 'Tidelines: A Year on the Ness',
      author: 'Judith Ashdown',
      genre: 'Nature Writing',
      blurb: 'Twelve months walking one headland at low tide, recording the wrack, the birds and the people who depend on both.',
      price: 14,
      featured: true
    },
    {
      title: 'Hedgerow Grammar',
      author: 'Nell Osgood',
      genre: 'Nature Writing',
      blurb: 'An illustrated field guide to the words and wildlife of English hedgerows, from blackthorn to bramble.',
      price: 13.5,
      featured: false
    },
    {
      title: 'The Ledger of Clerkenhythe Mill',
      author: 'Arthur Penhallow',
      genre: 'History',
      blurb: 'Account books from a Victorian flour mill reveal the wages, debts and small rebellions of the families who worked it.',
      price: 16.99,
      featured: false
    },
    {
      title: 'Ink & Ration: Letters from the Home Front',
      author: 'Dorothea Quayle',
      genre: 'History',
      blurb: 'Wartime letters between a village postmistress and the soldiers she kept in touch with, read beside the ration books that shaped their days.',
      price: 15,
      featured: false
    },
    {
      title: 'Orbit Without Witnesses',
      author: 'Yusuf Adeyemi-Clarke',
      genre: 'Science Fiction',
      blurb: 'A deep-space salvage crew finds a derelict station that has been quietly repairing itself for three centuries.',
      price: 8.5,
      featured: false
    },
    {
      title: 'The Slow Archive',
      author: 'Ines Halvorsen',
      genre: 'Science Fiction',
      blurb: 'An archivist on a generation ship must decide which memories to keep when the databanks begin to decay.',
      price: 9,
      featured: true
    }
  ];

  // Dates are local calendar dates (YYYY-MM-DD), compared as strings.
  var events = [
    {
      date: '2026-10-08',
      start: '19:00',
      end: '20:30',
      title: 'Harvest Poetry Night',
      description: 'Readings from the autumn anthology, with cider from the orchard next door.',
      booking: 'free'
    },
    {
      date: '2026-11-17',
      start: '19:00',
      end: '20:30',
      title: 'Lamplight Lecture: Maps of Imaginary Counties',
      description: 'A cartographer walks us through the invented counties of nineteenth-century fiction, with slides and a short tea break.',
      booking: 'booking'
    },
    {
      date: '2026-11-19',
      start: '18:30',
      end: '19:30',
      title: 'Thursday Reading Circle',
      description: 'This month we read The Slow Archive and talk about what we would keep if we could keep only a little.',
      booking: 'free'
    },
    {
      date: '2026-11-21',
      start: '18:30',
      end: '20:00',
      title: 'Poetry Open Mic',
      description: 'Five minutes at the lectern. Sign up at the counter on the night. Listeners are very welcome.',
      booking: 'free'
    },
    {
      date: '2026-11-28',
      start: '10:30',
      end: '12:00',
      title: 'Saturday Story Morning',
      description: 'Picture books, bubbles and a sing-song in the back room, for children under five and their grown-ups.',
      booking: 'booking'
    },
    {
      date: '2026-12-12',
      start: '17:00',
      end: '19:00',
      title: 'Winter Solstice Reading',
      description: 'The longest night and the shortest readings: six local writers, one candle and mulled apple juice.',
      booking: 'booking'
    },
    {
      date: '2027-01-23',
      start: '19:00',
      end: '20:30',
      title: 'Author Evening: Teodora Blackwood',
      description: 'The author of The Lamplighter\'s Alibi explains how she hid a murder inside the ringing of a cathedral\'s bells.',
      booking: 'booking'
    }
  ];

  // Weekday numbers match Date.getDay(): Sunday is 0.
  var hours = [
    { day: 'Monday', weekday: 1, open: null, close: null },
    { day: 'Tuesday', weekday: 2, open: '10:00', close: '18:30' },
    { day: 'Wednesday', weekday: 3, open: '10:00', close: '18:30' },
    { day: 'Thursday', weekday: 4, open: '10:00', close: '20:00' },
    { day: 'Friday', weekday: 5, open: '10:00', close: '18:30' },
    { day: 'Saturday', weekday: 6, open: '10:00', close: '17:30' },
    { day: 'Sunday', weekday: 0, open: '11:00', close: '16:00' }
  ];

  function pad(value) {
    return value < 10 ? '0' + value : String(value);
  }

  // The browser's local calendar date as YYYY-MM-DD. Never UTC.
  function localDateString(date) {
    return date.getFullYear() + '-' + pad(date.getMonth() + 1) + '-' + pad(date.getDate());
  }

  function genreSlug(genre) {
    return genre.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '');
  }

  // Every genre present in the books, sorted by name, with its URL slug.
  function genres(bookList) {
    var names = [];
    bookList.forEach(function (book) {
      if (names.indexOf(book.genre) === -1) names.push(book.genre);
    });
    return names.sort().map(function (name) {
      return { name: name, slug: genreSlug(name) };
    });
  }

  function upcomingEvents(today) {
    return events.filter(function (event) {
      return event.date >= today;
    });
  }

  // Most recent first.
  function pastEvents(today) {
    return events
      .filter(function (event) {
        return event.date < today;
      })
      .reverse();
  }

  function formatDate(dateString) {
    var parts = dateString.split('-').map(Number);
    return new Date(parts[0], parts[1] - 1, parts[2]).toLocaleDateString('en-GB', {
      weekday: 'long',
      day: 'numeric',
      month: 'long',
      year: 'numeric'
    });
  }

  window.Marginalia = {
    books: books,
    events: events,
    hours: hours,
    genres: genres,
    genreSlug: genreSlug,
    localDateString: localDateString,
    upcomingEvents: upcomingEvents,
    pastEvents: pastEvents,
    formatDate: formatDate
  };
})();

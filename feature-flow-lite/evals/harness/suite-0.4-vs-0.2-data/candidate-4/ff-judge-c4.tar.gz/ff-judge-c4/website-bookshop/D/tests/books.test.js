'use strict';

const { test } = require('node:test');
const assert = require('node:assert/strict');
const { setupSuite, openTracked, visit } = require('./helpers');

const suite = setupSuite();

const slugOf = (genre) => genre.toLowerCase().replace(/\s+/g, '-');

async function openCatalogue(path = 'books.html') {
  const t = await openTracked(suite);
  await visit(t, `${suite.base}/${path}`);
  return t;
}

async function catalogueData(page) {
  return page.evaluate(() => window.BOOKS);
}

async function visibleTitles(page) {
  return page.locator('#book-list .book-card:not([hidden]) .book-title').allTextContents();
}

test('catalogue has at least 12 invented titles across 5+ genres, each with 2+ titles', async () => {
  const t = await openCatalogue();
  const cards = await t.page.$$eval('#book-list .book-card', (nodes) =>
    nodes.map((node) => ({
      title: node.querySelector('.book-title')?.textContent.trim(),
      author: node.querySelector('.book-author')?.textContent.trim(),
      genre: node.querySelector('.book-genre')?.textContent.trim(),
      price: node.querySelector('.book-price')?.textContent.trim(),
      blurb: node.querySelector('.book-blurb')?.textContent.trim(),
    })),
  );
  assert.ok(cards.length >= 12, `expected 12+ books, got ${cards.length}`);
  for (const card of cards) {
    assert.ok(card.title, 'title missing');
    assert.ok(card.author, `author missing for ${card.title}`);
    assert.ok(card.genre, `genre missing for ${card.title}`);
    assert.match(card.price, /^£\d+\.\d{2}$/, `price format for ${card.title}`);
    const sentences = card.blurb.split(/[.!?](?=\s|$)/).filter((s) => s.trim()).length;
    assert.ok(sentences >= 1 && sentences <= 2, `blurb of ${card.title} has ${sentences} sentences`);
  }
  const perGenre = new Map();
  for (const card of cards) perGenre.set(card.genre, (perGenre.get(card.genre) || 0) + 1);
  assert.ok(perGenre.size >= 5, `expected 5+ genres, got ${perGenre.size}`);
  for (const [genre, count] of perGenre) {
    assert.ok(count >= 2, `${genre} has only ${count} title(s)`);
  }
  assert.deepEqual(t.problems, []);
  await t.context.close();
});

test('genre filter is a labelled fieldset with All plus one option per genre, generated from the data', async () => {
  const t = await openCatalogue();
  const { page } = t;
  const fieldset = page.locator('fieldset', { has: page.locator('legend', { hasText: /^Genre$/ }) });
  assert.equal(await fieldset.count(), 1);
  const labels = await fieldset.locator('input[type=radio]').evaluateAll((inputs) =>
    inputs.map((input) => input.labels[0].textContent.trim()),
  );
  const books = await catalogueData(page);
  const genres = [...new Set(books.map((book) => book.genre))];
  assert.deepEqual(labels, ['All', ...genres]);
  for (const genre of genres) {
    const expected = books.filter((book) => book.genre === genre).length;
    await page.getByRole('radio', { name: genre }).check();
    assert.equal((await visibleTitles(page)).length, expected, `count for ${genre}`);
  }
  assert.deepEqual(t.problems, []);
  await t.context.close();
});

test('choosing a genre shows exactly its books, removes the rest from the accessibility tree, and updates the polite count', async () => {
  const t = await openCatalogue();
  const { page } = t;
  const books = await catalogueData(page);
  const expected = books.filter((book) => book.genre === 'Mystery').map((book) => book.title);

  await page.getByRole('radio', { name: 'Mystery' }).check();

  assert.deepEqual(await visibleTitles(page), expected);
  assert.deepEqual(
    await page.getByRole('heading', { level: 2 }).allTextContents(),
    expected,
    'hidden books must not appear in the accessibility tree',
  );
  assert.equal(await page.locator('#book-list li[hidden]').count(), books.length - expected.length);
  const count = page.locator('#results-count');
  assert.equal(await count.getAttribute('aria-live'), 'polite');
  assert.equal(await count.textContent(), `Showing ${expected.length} of ${books.length} books in Mystery`);

  await page.getByRole('radio', { name: 'All' }).check();
  assert.equal(await count.textContent(), `Showing ${books.length} of ${books.length} books`);
  assert.deepEqual(t.problems, []);
  await t.context.close();
});

test('rapid switching between genres and back to All restores every book in original order', async () => {
  const t = await openCatalogue();
  const { page } = t;
  const books = await catalogueData(page);
  const order = ['Poetry', 'Essays', 'Mystery', 'All', 'Science Fiction', 'Natural History', 'Literary Fiction', 'Poetry', 'All'];
  for (const name of order) {
    await page.getByRole('radio', { name }).check();
  }
  await page.getByRole('radio', { name: 'All' }).check();
  assert.deepEqual(await page.locator('#book-list .book-title').allTextContents(), books.map((book) => book.title));
  assert.equal(await page.locator('#book-list li[hidden]').count(), 0);
  assert.deepEqual(t.problems, []);
  await t.context.close();
});

test('filtering with the keyboard never moves focus away from the control being used', async () => {
  const t = await openCatalogue();
  const { page } = t;
  const poetry = page.getByRole('radio', { name: 'Poetry' });
  await poetry.focus();
  await page.keyboard.press('Space');
  assert.equal(await poetry.isChecked(), true);
  assert.equal(await page.evaluate(() => document.activeElement.id), 'genre-poetry');
  await page.keyboard.press('Space');
  assert.equal(await page.evaluate(() => document.activeElement.id), 'genre-poetry');
  assert.deepEqual(t.problems, []);
  await t.context.close();
});

test('Tab never reaches books hidden by the filter', async () => {
  const t = await openCatalogue();
  const { page } = t;
  await page.getByRole('radio', { name: 'Mystery' }).check();
  await page.getByRole('radio', { name: 'Mystery' }).focus();
  const reached = [];
  for (let i = 0; i < 60; i += 1) {
    await page.keyboard.press('Tab');
    reached.push(await page.evaluate(() => {
      const active = document.activeElement;
      return active.closest('[hidden]') ? active.outerHTML.slice(0, 80) : null;
    }));
  }
  assert.deepEqual(reached.filter(Boolean), []);
  assert.deepEqual(t.problems, []);
  await t.context.close();
});

test('the empty-results message is in the code and shown when a genre has no books', async () => {
  const t = await openCatalogue();
  const { page } = t;
  const message = page.locator('#empty-message');
  assert.equal(await message.count(), 1);
  assert.equal(await message.isVisible(), false);

  // The data always has books in every genre, so remove the cards to force the empty branch.
  await page.evaluate(() => document.querySelectorAll('#book-list li').forEach((item) => item.remove()));
  await page.getByRole('radio', { name: 'Essays' }).check();

  assert.equal(await message.isVisible(), true);
  assert.match(await message.textContent(), /No books/);
  assert.equal(await page.locator('#results-count').textContent(), 'Showing 0 of 0 books in Essays');
  assert.deepEqual(t.problems, []);
  await t.context.close();
});

test('choosing a genre writes it to the query string and All removes it', async () => {
  const t = await openCatalogue();
  const { page } = t;
  await page.getByRole('radio', { name: 'Poetry' }).check();
  assert.equal(new URL(page.url()).searchParams.get('genre'), 'poetry');
  await page.getByRole('radio', { name: 'All' }).check();
  assert.equal(new URL(page.url()).searchParams.has('genre'), false);
  assert.deepEqual(t.problems, []);
  await t.context.close();
});

test('loading ?genre=mystery shows Mystery selected and filtered', async () => {
  const t = await openCatalogue('books.html?genre=mystery');
  const { page } = t;
  assert.equal(await page.getByRole('radio', { name: 'Mystery' }).isChecked(), true);
  const total = (await catalogueData(page)).length;
  assert.equal(await page.locator('#results-count').textContent(), `Showing 3 of ${total} books in Mystery`);
  assert.equal((await visibleTitles(page)).length, 3);
  assert.deepEqual(t.problems, []);
  await t.context.close();
});

test('loading ?genre=Literary%20Fiction (the display name) selects Literary Fiction', async () => {
  const t = await openCatalogue('books.html?genre=Literary%20Fiction');
  const { page } = t;
  assert.equal(await page.getByRole('radio', { name: 'Literary Fiction' }).isChecked(), true);
  assert.equal(new URL(page.url()).searchParams.get('genre'), 'literary-fiction');
  assert.equal((await visibleTitles(page)).length, (await catalogueData(page)).filter((book) => book.genre === 'Literary Fiction').length);
  assert.deepEqual(t.problems, []);
  await t.context.close();
});

test('loading ?genre=literary+fiction selects Literary Fiction', async () => {
  const t = await openCatalogue('books.html?genre=literary+fiction');
  const { page } = t;
  assert.equal(await page.getByRole('radio', { name: 'Literary Fiction' }).isChecked(), true);
  assert.equal(new URL(page.url()).searchParams.get('genre'), 'literary-fiction');
  assert.deepEqual(t.problems, []);
  await t.context.close();
});

test('reload restores the chosen genre', async () => {
  const t = await openCatalogue();
  const { page } = t;
  await page.getByRole('radio', { name: 'Essays' }).check();
  await page.reload({ waitUntil: 'load' });
  assert.equal(await page.getByRole('radio', { name: 'Essays' }).isChecked(), true);
  assert.equal((await visibleTitles(page)).length, 2);
  assert.deepEqual(t.problems, []);
  await t.context.close();
});

// Malformed or hostile genre values must fall back to All, never break the page, and never
// inject anything from the URL into the document.
const HOSTILE_GENRE_QUERIES = [
  ['genre=', null],
  ['genre=nonexistent', null],
  ['genre=%3Cscript%3Ealert(1)%3C%2Fscript%3E', null],
  ['genre=MYSTERY', 'mystery'],
  ['genre=mystery&genre=poetry', null],
  ['genre=%20essays%20', 'essays'],
  ['genre=literary-fiction', 'literary-fiction'],
];

for (const [query, expectedSlug] of HOSTILE_GENRE_QUERIES) {
  test(`hostile ?${query} falls back to All or matches the genre, without errors or injection`, async () => {
    const t = await openCatalogue(`books.html?${query}`);
    const { page } = t;
    const books = await catalogueData(page);
    const expectedId = expectedSlug ? `genre-${expectedSlug}` : 'genre-all';
    const expectedCount = expectedSlug
      ? books.filter((book) => slugOf(book.genre) === expectedSlug).length
      : books.length;

    const checked = await page.locator('input[name=genre]:checked').getAttribute('id');
    assert.equal(checked, expectedId);
    assert.equal((await visibleTitles(page)).length, expectedCount);
    assert.equal(await page.locator('#book-list script, #genre-filter script').count(), 0);
    const html = await page.content();
    assert.equal(html.includes('alert(1)'), false, 'URL text must never be injected');
    assert.equal(t.dialogs.length, 0);
    assert.deepEqual(t.problems, []);
    await t.context.close();
  });
}

// Property test: generated query values, checked against a reference rule.
test('generated genre values always yield a valid filtered state with no errors', async () => {
  let seed = 20261117;
  const random = () => {
    seed = (seed * 1103515245 + 12345) & 0x7fffffff;
    return seed / 0x7fffffff;
  };
  const alphabet = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789 -_<>&=%\'"/+';
  const slugs = ['mystery', 'poetry', 'essays', 'science-fiction', 'natural-history', 'literary-fiction'];
  const cases = [];
  for (let i = 0; i < 25; i += 1) {
    const length = Math.floor(random() * 18);
    let value = '';
    for (let j = 0; j < length; j += 1) value += alphabet[Math.floor(random() * alphabet.length)];
    cases.push(value);
    const base = slugs[i % slugs.length];
    cases.push(base.split('').map((ch) => (random() < 0.5 ? ch.toUpperCase() : ch)).join(''));
  }

  const t = await openCatalogue();
  const { page } = t;
  const books = await catalogueData(page);
  for (const value of cases) {
    await visit(t, `${suite.base}/books.html?genre=${encodeURIComponent(value)}`);
    const normalised = value.trim().toLowerCase().replace(/\s+/g, '-');
    const match = slugs.includes(normalised) ? normalised : null;
    const checked = await page.locator('input[name=genre]:checked').getAttribute('id');
    assert.equal(checked, match ? `genre-${match}` : 'genre-all', `value ${JSON.stringify(value)}`);
    const expected = match ? books.filter((book) => slugOf(book.genre) === match).length : books.length;
    assert.equal((await visibleTitles(page)).length, expected, `count for ${JSON.stringify(value)}`);
  }
  assert.equal(t.dialogs.length, 0);
  assert.deepEqual(t.problems, []);
  await t.context.close();
});

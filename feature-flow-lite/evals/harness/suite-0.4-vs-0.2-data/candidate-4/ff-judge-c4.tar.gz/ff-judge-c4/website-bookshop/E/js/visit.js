// Highlights today's opening hours (local time) and checks the contact form. Nothing is sent.
(function () {
  var DAYS = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
  var DEMO_MESSAGE = 'This is a demo site, so your message wasn\'t sent. To reach us for real, email hello@marginalia.test or call (555) 010-0142.';

  var form = document.getElementById('contact-form');
  var statusBox = document.getElementById('form-status');

  var RULES = [
    { id: 'name', message: 'Enter your name.', valid: nonBlank },
    { id: 'email', message: 'Enter an email address such as name@example.com.', valid: validEmail },
    { id: 'subject', message: 'Enter a subject for your message.', valid: nonBlank },
    { id: 'message', message: 'Enter a message.', valid: nonBlank }
  ];

  function nonBlank(value) {
    return value.trim() !== '';
  }

  function validEmail(value) {
    var email = value.trim();
    // No leading or trailing dot, no empty label next to a dot and no dot touching the @.
    return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email) && !/^\.|\.$|\.\.|\.@|@\./.test(email);
  }

  function highlightToday() {
    var today = DAYS[new Date().getDay()];
    document.querySelectorAll('.hours-table tr[data-day]').forEach(function (row) {
      if (row.getAttribute('data-day') !== today) return;
      row.classList.add('is-today');
      var note = document.createElement('span');
      note.className = 'today-note';
      note.textContent = ' (today)';
      row.querySelector('th').appendChild(note);
    });
  }

  // Sets aria-invalid, the linked error text and its visibility for one field.
  function checkField(rule) {
    var field = document.getElementById(rule.id);
    var error = document.getElementById(rule.id + '-error');
    var ok = rule.valid(field.value);
    field.setAttribute('aria-invalid', ok ? 'false' : 'true');
    error.textContent = ok ? '' : rule.message;
    error.hidden = ok;
    if (ok) {
      field.removeAttribute('aria-describedby');
    } else {
      field.setAttribute('aria-describedby', error.id);
    }
    return ok;
  }

  // Clears the status, then sets it a moment later so a repeated message is announced again.
  var statusTimer = null;
  function setStatus(text) {
    clearTimeout(statusTimer);
    statusBox.textContent = '';
    statusTimer = setTimeout(function () {
      statusBox.textContent = text;
    }, 50);
  }

  function onSubmit(event) {
    event.preventDefault();
    // Check every field so all errors show at once, then focus the first invalid one.
    var firstInvalid = null;
    RULES.forEach(function (rule) {
      if (!checkField(rule) && firstInvalid === null) firstInvalid = rule;
    });
    if (firstInvalid !== null) {
      setStatus('');
      document.getElementById(firstInvalid.id).focus();
      return;
    }
    setStatus(DEMO_MESSAGE);
  }

  highlightToday();
  // The send button ships disabled, so without JavaScript nothing can be submitted into the URL.
  form.querySelector('button[type="submit"]').disabled = false;
  form.addEventListener('submit', onSubmit);
  RULES.forEach(function (rule) {
    document.getElementById(rule.id).addEventListener('input', function () {
      if (this.getAttribute('aria-invalid') === 'true') checkField(rule);
    });
  });
})();

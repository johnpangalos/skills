/*
 * Shared behaviour for every page: the skip link moves focus into <main>.
 */
(function () {
  'use strict';

  var skipLink = document.querySelector('.skip-link');
  var main = document.getElementById('main');
  if (!skipLink || !main) return;

  skipLink.addEventListener('click', function () {
    main.focus();
  });
})();

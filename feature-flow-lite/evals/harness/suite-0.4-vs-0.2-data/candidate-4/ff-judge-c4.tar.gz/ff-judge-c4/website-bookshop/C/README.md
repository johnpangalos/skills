# Marginalia Books

A static website for Marginalia Books, a fictional independent bookshop. It has four pages:

- **Home** (`index.html`): a welcome, staff picks from the catalog, the next upcoming event, and a pointer to visit.
- **Books** (`books.html`): a catalog of 15 invented titles across five genres, with a genre filter. The chosen genre is kept in the address (`books.html?genre=mystery`), so it can be bookmarked and restored with Back and Forward.
- **Events** (`events.html`): upcoming events with dates, times, descriptions and who each one is for.
- **Visit** (`visit.html`): opening hours, the address, directions and transport notes, and a contact form.

The site is plain HTML, CSS and vanilla JavaScript. There is no build step and no dependencies, and it makes no requests outside its own origin: no CDNs, web fonts or remote images.

## Layout

- `index.html`, `books.html`, `events.html`, `visit.html`: the pages, each with the same header, navigation and footer.
- `css/styles.css`: the shared stylesheet.
- `js/books-data.js`, `js/events-data.js`: the catalog and events data. Pages render from these files.
- `js/dates.js`: date helpers that read dates as the local day.
- `js/books.js`, `js/events.js`, `js/home.js`, `js/contact.js`: page behaviour.
- `tests/`: browser tests (Playwright, Node's test runner) and a small static server they use.

## Run it locally

From the repo root, start a static server and open the site:

```sh
python3 -m http.server 8000
```

Then visit http://localhost:8000/. You can also open `index.html` directly in a browser, although the address-bar behaviour of the genre filter works best over HTTP.

## Run the tests

Playwright must be available (the tests look for it through `NODE_PATH`, for example `NODE_PATH="$(npm root -g)"`). Then run:

```sh
node --test tests/
```

The tests start their own static server on a random port, load each page in headless Chromium, and check the acceptance criteria: structure, navigation, the catalog filter and URL state, events dates, the visit page, the contact form, responsive layout, accessibility, and network use.

## Notes

- The contact form is a demo. It checks the name, email and message in the browser, but it does not send anything anywhere, and the confirmation says so.
- The catalog, events and business details (name, address, phone, hours) are invented for this demo.

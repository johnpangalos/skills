// Contact form on the visit page. This is a demonstration: validation runs here, nothing is
// sent anywhere, and the status message says so. Errors are announced through aria-invalid
// and aria-describedby, and focus moves to the first invalid field.
(function () {
  'use strict';

  const form = document.getElementById('contact-form');
  if (!form) return;

  const status = document.getElementById('contact-status');
  const EMAIL_PATTERN = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  const MESSAGE_MAX_LENGTH = 5000;
  const CONTACT_EMAIL = 'hello@marginaliabooks.example';

  const fields = [
    {
      input: document.getElementById('contact-name'),
      error: document.getElementById('contact-name-error'),
      check(value) {
        return value.trim() ? '' : 'Please tell us your name.';
      },
    },
    {
      input: document.getElementById('contact-email'),
      error: document.getElementById('contact-email-error'),
      check(value) {
        if (!value.trim()) return 'Please enter your email address.';
        if (!EMAIL_PATTERN.test(value.trim())) return 'Please enter an email address like name@example.com.';
        return '';
      },
    },
    {
      input: document.getElementById('contact-message'),
      error: document.getElementById('contact-message-error'),
      check(value) {
        if (!value.trim()) return 'Please write a message before sending.';
        if (value.length > MESSAGE_MAX_LENGTH) return `Please keep your message to ${MESSAGE_MAX_LENGTH} characters.`;
        return '';
      },
    },
  ];

  // Shows or clears one field's error. Returns true when the field is valid.
  function applyCheck(field) {
    const message = field.check(field.input.value);
    field.error.textContent = message;
    field.error.hidden = message === '';
    if (message) {
      field.input.setAttribute('aria-invalid', 'true');
    } else {
      field.input.removeAttribute('aria-invalid');
    }
    return message === '';
  }

  // True after a successful demo submit, until the visitor types into the form again.
  let showingConfirmation = false;

  function allEmpty() {
    return fields.every((field) => !field.input.value.trim());
  }

  function submitDemo() {
    const name = fields[0].input.value.trim();
    // Clear first so a repeated confirmation is announced again.
    status.textContent = '';
    status.textContent = `Thanks, ${name}. This demo form doesn't send messages, so please email us at ${CONTACT_EMAIL} instead.`;
    form.reset();
    showingConfirmation = true;
  }

  form.addEventListener('submit', (event) => {
    event.preventDefault();
    // A second submit on the form we just reset keeps the confirmation and shows no errors.
    if (showingConfirmation && allEmpty()) return;
    const results = fields.map((field) => applyCheck(field));
    const firstInvalid = fields[results.indexOf(false)];
    if (firstInvalid) {
      status.textContent = '';
      firstInvalid.input.focus();
      return;
    }
    submitDemo();
  });

  // Typing ends the confirmed state. Once a field has an error, re-check it as the visitor
  // types so the error clears when fixed.
  form.addEventListener('input', (event) => {
    showingConfirmation = false;
    const field = fields.find((candidate) => candidate.input === event.target);
    if (field && field.input.getAttribute('aria-invalid') === 'true') {
      applyCheck(field);
    }
  });
})();

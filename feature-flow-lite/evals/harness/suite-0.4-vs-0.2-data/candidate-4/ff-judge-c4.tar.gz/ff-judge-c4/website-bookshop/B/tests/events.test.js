'use strict';

const { test, before, after } = require('node:test');
const assert = require('node:assert/strict');
const { startSite, launchBrowser, openSite, closeContexts } = require('./helpers');

let site;
let browser;

before(async () => {
  site = await startSite();
  browser = await launchBrowser();
});

after(async () => {
  await closeContexts();
  await browser.close();
  await site.close();
});

// Criterion 7: at least 4 events, each with title, time element, description, ordered by date.
test('events page lists at least 4 events with title, <time datetime>, description, ordered by date (criterion 7)', async () => {
  const { page, log } = await openSite(browser, site.origin, 'events.html');
  const events = await page.$$eval('main article', (articles) => articles.map((article) => {
    const time = article.querySelector('time');
    return {
      title: article.querySelector('h2') && article.querySelector('h2').textContent.trim(),
      datetime: time && time.getAttribute('datetime'),
      timeText: time && time.textContent.trim(),
      description: article.querySelector('p:last-of-type') && article.querySelector('p:last-of-type').textContent.trim(),
    };
  }));
  assert.ok(events.length >= 4, `events: ${events.length}`);
  for (const event of events) {
    assert.ok(event.title, 'has a title');
    assert.ok(event.timeText, 'time element has visible text');
    assert.match(event.datetime, /^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}$/, `${event.title} datetime`);
    assert.ok(!Number.isNaN(Date.parse(event.datetime)), `${event.title} datetime parses`);
    assert.ok(event.description && event.description.length >= 40, `${event.title} description`);
  }
  const stamps = events.map((event) => Date.parse(event.datetime));
  assert.deepEqual(stamps, [...stamps].sort((a, b) => a - b), 'ordered by date');
  assert.deepEqual(log.pageErrors, []);
});

test('event dates are fixed in the markup and no script computes them (criterion 7)', async () => {
  const { page } = await openSite(browser, site.origin, 'events.html');
  const datetimes = await page.$$eval('main time', (times) => times.map((t) => t.getAttribute('datetime')));
  assert.ok(datetimes.length >= 4);
  assert.equal(await page.locator('script').count(), 0, 'events page runs no date logic');
  assert.deepEqual(datetimes, [...datetimes].sort(), 'datetime values are fixed ISO strings in order');
});

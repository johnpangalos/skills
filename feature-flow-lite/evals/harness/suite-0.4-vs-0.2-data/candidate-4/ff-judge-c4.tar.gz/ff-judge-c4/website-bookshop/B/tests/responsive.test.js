'use strict';

const { test, before, after } = require('node:test');
const assert = require('node:assert/strict');
const { startSite, launchBrowser, openSite, closeContexts } = require('./helpers');

const PAGES = ['index.html', 'books.html', 'events.html', 'visit.html'];
const WIDTHS = [360, 768, 1280];

let site;
let browser;

before(async () => {
  site = await startSite();
  browser = await launchBrowser();
});

after(async () => {
  await closeContexts();
  await browser.close();
  await site.close();
});

// Criterion 10: no horizontal scroll and readable base font at each width.
for (const width of WIDTHS) {
  test(`every page fits ${width}px with no horizontal scroll and a 16px+ base font (criterion 10)`, async () => {
    for (const file of PAGES) {
      const { page } = await openSite(browser, site.origin, file, width);
      const metrics = await page.evaluate(() => ({
        scrollWidth: document.documentElement.scrollWidth,
        innerWidth: window.innerWidth,
        fontSize: parseFloat(getComputedStyle(document.body).fontSize),
      }));
      assert.ok(metrics.scrollWidth <= metrics.innerWidth, `${file} at ${width}: ${metrics.scrollWidth} > ${metrics.innerWidth}`);
      assert.ok(metrics.fontSize >= 16, `${file} base font ${metrics.fontSize}px`);
      await page.context().close();
    }
  });
}

// Criterion 10 and 2: at 360px the nav exposes all four links with 44px tap targets.
test('at 360px the nav shows all four links, each at least 44px tall (criterion 2, criterion 10)', async () => {
  for (const file of PAGES) {
    const { page } = await openSite(browser, site.origin, file, 360);
    const links = page.locator('nav[aria-label] a');
    assert.equal(await links.count(), 4);
    for (let i = 0; i < 4; i++) {
      const box = await links.nth(i).boundingBox();
      assert.ok(box && box.height >= 44, `${file} nav link ${i} height ${box && box.height}`);
    }
    assert.equal(await page.locator('nav[aria-label] button').count(), 0, 'nav has no hidden toggle to get stuck');
    await page.context().close();
  }
});

test('genre filter labels are at least 44px tall at 360px (criterion 10)', async () => {
  const { page } = await openSite(browser, site.origin, 'books.html', 360);
  const labels = page.locator('fieldset label');
  const count = await labels.count();
  assert.ok(count >= 6, `filter labels: ${count}`);
  for (let i = 0; i < count; i++) {
    const box = await labels.nth(i).boundingBox();
    assert.ok(box && box.height >= 44, `filter label ${i} height ${box && box.height}`);
  }
});

// Hostile: resize from 360px to 1280px with the nav untouched; links must be visible at desktop width.
test('resizing from 360px to 1280px keeps all four nav links visible (criterion 2, hostile)', async () => {
  const { page } = await openSite(browser, site.origin, 'index.html', 360);
  await page.setViewportSize({ width: 1280, height: 900 });
  const visible = await page.locator('nav[aria-label] a').evaluateAll((links) => links.map((a) => {
    const box = a.getBoundingClientRect();
    return box.width > 0 && box.height > 0 && getComputedStyle(a).visibility !== 'hidden';
  }));
  assert.deepEqual(visible, [true, true, true, true]);
  await page.context().close();
});

import http from 'node:http';
import { readFile, stat } from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { createRequire } from 'node:module';

export const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
export const PAGES = ['index.html', 'books.html', 'events.html', 'visit.html'];

const MIME = {
  '.html': 'text/html; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.js': 'text/javascript; charset=utf-8',
  '.md': 'text/markdown; charset=utf-8',
  '.svg': 'image/svg+xml',
};

// Tiny static server over the repo root; port 0 picks a free port.
export function startServer(root = ROOT) {
  const server = http.createServer(async (req, res) => {
    let pathname;
    try {
      pathname = decodeURIComponent(new URL(req.url, 'http://localhost').pathname);
    } catch {
      res.writeHead(400, { 'Content-Type': 'text/plain' }).end('Bad request');
      return;
    }
    const file = path.join(root, pathname);
    if (file !== root && !file.startsWith(root + path.sep)) {
      res.writeHead(403, { 'Content-Type': 'text/plain' }).end('Forbidden');
      return;
    }
    try {
      let target = file;
      if ((await stat(target)).isDirectory()) target = path.join(target, 'index.html');
      const body = await readFile(target);
      res.writeHead(200, { 'Content-Type': MIME[path.extname(target)] ?? 'application/octet-stream' });
      res.end(body);
    } catch {
      res.writeHead(404, { 'Content-Type': 'text/plain' }).end('Not found');
    }
  });
  return new Promise((resolve) => {
    server.listen(0, '127.0.0.1', () => {
      const { port } = server.address();
      resolve({
        baseUrl: `http://127.0.0.1:${port}`,
        close: () => new Promise((done) => { server.closeAllConnections(); server.close(done); }),
      });
    });
  });
}

// Uses the preinstalled playwright module. Chromium first, then the system Chrome.
export async function launchBrowser() {
  const require = createRequire(import.meta.url);
  const { chromium } = require('playwright');
  const args = process.getuid?.() === 0 ? ['--no-sandbox'] : [];
  try {
    return await chromium.launch({ args, timeout: 30000 });
  } catch {
    return chromium.launch({ args, timeout: 30000, executablePath: '/usr/bin/google-chrome' });
  }
}

// Per-test context: every page opened through open() is closed by the runner afterwards.
export function makeContext(browser, baseUrl) {
  const contexts = [];
  return {
    baseUrl,
    contexts,
    url: (file) => `${baseUrl}/${file}`,
    async open(options = {}) {
      const context = await browser.newContext({ viewport: { width: 1280, height: 800 }, ...options });
      contexts.push(context);
      const page = await context.newPage();
      const log = { page, requests: [], dialogs: [], errors: [] };
      page.on('request', (request) => log.requests.push(request.url()));
      page.on('dialog', (dialog) => { log.dialogs.push(dialog.message()); dialog.dismiss(); });
      page.on('pageerror', (error) => log.errors.push(error.message));
      return log;
    },
  };
}

function luminance([r, g, b]) {
  const lin = (v) => {
    const s = v / 255;
    return s <= 0.03928 ? s / 12.92 : ((s + 0.055) / 1.055) ** 2.4;
  };
  return 0.2126 * lin(r) + 0.7152 * lin(g) + 0.0722 * lin(b);
}

export function contrastRatio(a, b) {
  const [hi, lo] = [luminance(a), luminance(b)].sort((x, y) => y - x);
  return (hi + 0.05) / (lo + 0.05);
}

// Walks the DOM in the browser: text colour against the nearest opaque background.
export async function auditContrast(page, selectors) {
  const pairs = await page.evaluate((sels) => {
    const parse = (c) => {
      const parts = c.match(/rgba?\(([^)]+)\)/)[1].split(/[ ,/]+/).filter(Boolean).map(Number);
      return { rgb: parts.slice(0, 3), a: parts.length > 3 ? parts[3] : 1 };
    };
    const background = (el) => {
      for (let node = el; node; node = node.parentElement) {
        const c = parse(getComputedStyle(node).backgroundColor);
        if (c.a > 0) return c.rgb;
      }
      return [255, 255, 255];
    };
    const out = [];
    for (const sel of sels) {
      for (const el of document.querySelectorAll(sel)) {
        if (!el.getClientRects().length || !el.textContent.trim()) continue;
        out.push({
          sel,
          text: el.textContent.trim().slice(0, 40),
          color: parse(getComputedStyle(el).color).rgb,
          bg: background(el),
        });
      }
    }
    return out;
  }, selectors);
  return pairs.map((p) => ({ ...p, ratio: contrastRatio(p.color, p.bg) }));
}

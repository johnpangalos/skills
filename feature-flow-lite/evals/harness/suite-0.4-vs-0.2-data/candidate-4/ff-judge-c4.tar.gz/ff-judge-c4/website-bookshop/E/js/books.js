// Genre filter for the books page. The selected genre lives in the ?genre= query so it can be bookmarked.
(function () {
  var ALL = '';
  var select = document.getElementById('genre-filter');
  var count = document.getElementById('result-count');
  var emptyState = document.getElementById('empty-state');
  var books = Array.prototype.slice.call(document.querySelectorAll('.book-list > li[data-genre]'));

  // Genres come from the catalog's data-genre attributes. The select options in books.html list the same genres.
  function catalogGenres() {
    var genres = [];
    books.forEach(function (book) {
      var genre = book.getAttribute('data-genre');
      if (genres.indexOf(genre) === -1) genres.push(genre);
    });
    return genres.sort();
  }

  // Case-insensitive match against the catalog; anything unknown or empty means All.
  function genreFromQuery() {
    var wanted = (new URLSearchParams(window.location.search).get('genre') || '').trim().toLowerCase();
    var match = catalogGenres().find(function (genre) {
      return genre.toLowerCase() === wanted;
    });
    return match === undefined ? ALL : match;
  }

  function urlFor(genre) {
    var params = new URLSearchParams(window.location.search);
    if (genre === ALL) {
      params.delete('genre');
    } else {
      params.set('genre', genre);
    }
    var query = params.toString();
    return window.location.pathname + (query ? '?' + query : '') + window.location.hash;
  }

  function showGenre(genre) {
    var shown = 0;
    select.value = genre;
    books.forEach(function (book) {
      var match = genre === ALL || book.getAttribute('data-genre') === genre;
      book.hidden = !match;
      if (match) shown += 1;
    });
    count.textContent = 'Showing ' + shown + ' of ' + books.length + ' books';
    emptyState.hidden = shown > 0;
  }

  var initial = genreFromQuery();
  showGenre(initial);
  history.replaceState(null, '', urlFor(initial));

  select.addEventListener('change', function () {
    showGenre(select.value);
    history.pushState(null, '', urlFor(select.value));
  });

  window.addEventListener('popstate', function () {
    showGenre(genreFromQuery());
  });
})();

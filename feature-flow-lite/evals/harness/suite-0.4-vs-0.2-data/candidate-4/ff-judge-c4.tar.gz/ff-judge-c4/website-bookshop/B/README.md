# Marginalia Books

A static website for Marginalia Books, a fictional independent bookshop in Alder Bend, Oregon. It has four pages: home, books (a genre-filtered catalog), events and visit (hours, address and a contact form). It is plain HTML, CSS and vanilla JavaScript with no build step and no external requests.

## View the site

Serve the repository root with any static server and open the printed address. For example:

```sh
npx http-server -p 8080 -s .
```

Then open http://localhost:8080/. Opening `index.html` directly from disk also works for most pages, but the catalog is best viewed through a server.

## Run the tests

The tests use Node's built-in test runner and the globally installed Playwright. They start their own static server and drive headless Chromium, falling back to `/usr/bin/google-chrome` when no bundled browser is available.

```sh
NODE_PATH=$(npm root -g) node --test tests/
```

To run one file, pass its path instead, for example `tests/books.test.js`.

## Layout

- `index.html`, `books.html`, `events.html`, `visit.html`: the pages.
- `css/styles.css`: the shared stylesheet.
- `js/books.js`: the catalog data. `js/catalog.js` renders and filters it. `js/contact.js` validates the contact form.
- `tests/`: the browser tests. `tests/index.js` loads every suite.

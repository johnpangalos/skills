// Criterion 4 (responsive, no sideways scroll, nav menu) and the focus/keyboard triggered checks.
import assert from 'node:assert/strict';
import { PAGES } from './helpers.mjs';

const MOBILE = { width: 360, height: 740 };

async function overflow(page) {
  return page.evaluate(() => document.scrollingElement.scrollWidth - document.scrollingElement.clientWidth);
}

async function tabTo(page, selector, limit = 40) {
  for (let i = 0; i < limit; i += 1) {
    await page.keyboard.press('Tab');
    const matches = await page.evaluate((sel) => document.activeElement.matches(sel), selector);
    if (matches) return;
  }
  throw new Error(`Tab never reached ${selector}`);
}

export const tests = [
  {
    name: 'criterion 4: no page scrolls sideways at 360px or 320px',
    async run(ctx) {
      for (const width of [360, 320]) {
        const { page } = await ctx.open({ viewport: { width, height: 700 } });
        for (const file of PAGES) {
          await page.goto(ctx.url(file));
          assert.ok(await overflow(page) <= 0, `${file} at ${width}px scrolls sideways`);
        }
      }
    },
  },
  {
    name: 'criterion 4: books page has no sideways scroll with every genre selected at 360px',
    async run(ctx) {
      const { page } = await ctx.open({ viewport: MOBILE });
      await page.goto(ctx.url('books.html'));
      const values = await page.$$eval('#genre-filter option', (opts) => opts.map((o) => o.value));
      assert.ok(values.length >= 6, 'All plus at least five genres');
      for (const value of values) {
        await page.selectOption('#genre-filter', value);
        assert.ok(await overflow(page) <= 0, `genre "${value}" scrolls sideways at 360px`);
      }
    },
  },
  {
    name: 'criterion 4: visit form with error messages shown has no sideways scroll at 360px',
    async run(ctx) {
      const { page } = await ctx.open({ viewport: MOBILE });
      await page.goto(ctx.url('visit.html'));
      await page.locator('#contact-form button[type="submit"]').click();
      assert.ok(await page.locator('.field-error:visible').count() >= 4, 'errors should be shown');
      assert.ok(await overflow(page) <= 0, 'form errors scroll sideways at 360px');
    },
  },
  {
    name: 'criterion 4 hostile: a 200-character unbroken title and author do not widen the page at 360px',
    async run(ctx) {
      const { page } = await ctx.open({ viewport: MOBILE });
      await page.goto(ctx.url('books.html'));
      await page.evaluate(() => {
        const card = document.querySelector('.book-list > li');
        card.querySelector('.book-title').textContent = 'Supercalifragilistic'.repeat(10);
        card.querySelector('.book-author').textContent = 'by Maximiliana-Wolfgangus-Ferdinand'.repeat(5);
      });
      assert.ok(await overflow(page) <= 0, 'long title or author widens the page');
    },
  },
  {
    name: 'criterion 4: at 360px the nav is a menu button with aria-expanded and aria-controls, toggled by Enter and Space',
    async run(ctx) {
      const { page } = await ctx.open({ viewport: MOBILE });
      await page.goto(ctx.url('books.html'));
      const toggle = page.getByRole('button', { name: 'Menu' });
      const controls = await toggle.getAttribute('aria-controls');
      assert.ok(await page.locator(`#${controls}`).count() === 1, 'aria-controls should point at the nav list');
      assert.equal(await toggle.getAttribute('aria-expanded'), 'false');
      assert.ok(!(await page.locator('#site-nav-list').isVisible()), 'menu starts closed');
      await toggle.focus();
      await page.keyboard.press('Enter');
      assert.equal(await toggle.getAttribute('aria-expanded'), 'true');
      assert.ok(await page.getByRole('link', { name: 'Events', exact: true }).isVisible(), 'menu shows links after Enter');
      await page.keyboard.press('Space');
      assert.equal(await toggle.getAttribute('aria-expanded'), 'false');
      assert.ok(!(await page.locator('#site-nav-list').isVisible()), 'Space closes the menu');
      await page.keyboard.press('Space');
      assert.equal(await toggle.getAttribute('aria-expanded'), 'true');
    },
  },
  {
    name: 'triggered focus: open the menu from its button by keyboard, Escape closes it and focus returns to the button',
    async run(ctx) {
      const { page } = await ctx.open({ viewport: MOBILE });
      await page.goto(ctx.url('events.html'));
      await tabTo(page, '.nav-toggle');
      await page.keyboard.press('Enter');
      await page.keyboard.press('Tab');
      assert.equal(await page.evaluate(() => document.activeElement.closest('#site-nav-list') !== null), true, 'Tab moves into the open menu');
      await page.keyboard.press('Escape');
      assert.equal(await page.getByRole('button', { name: 'Menu' }).getAttribute('aria-expanded'), 'false');
      assert.equal(await page.evaluate(() => document.activeElement.className), 'nav-toggle', 'focus should return to the menu button');
    },
  },
  {
    name: 'triggered focus: Escape with the menu already closed does nothing to focus or state',
    async run(ctx) {
      const { page } = await ctx.open({ viewport: MOBILE });
      await page.goto(ctx.url('books.html'));
      await tabTo(page, '.nav-toggle');
      await page.keyboard.press('Escape');
      assert.equal(await page.getByRole('button', { name: 'Menu' }).getAttribute('aria-expanded'), 'false');
      assert.equal(await page.evaluate(() => document.activeElement.className), 'nav-toggle');
    },
  },
  {
    name: 'triggered focus: with the menu closed at 360px, Tab never lands on hidden nav links',
    async run(ctx) {
      const { page } = await ctx.open({ viewport: MOBILE });
      await page.goto(ctx.url('books.html'));
      for (let i = 0; i < 60; i += 1) {
        await page.keyboard.press('Tab');
        const state = await page.evaluate(() => ({
          visible: document.activeElement.getClientRects().length > 0,
          inMenu: document.activeElement.closest('#site-nav-list') !== null,
        }));
        assert.equal(state.visible, true, `Tab ${i + 1} landed on a hidden element`);
        assert.equal(state.inMenu, false, `Tab ${i + 1} landed in the closed menu`);
      }
    },
  },
  {
    name: 'criterion 4 hostile: menu opened at 360px then resized to 1280px leaves a usable inline nav with no sideways scroll',
    async run(ctx) {
      const { page } = await ctx.open({ viewport: MOBILE });
      await page.goto(ctx.url('books.html'));
      await page.getByRole('button', { name: 'Menu' }).click();
      assert.ok(await page.getByRole('link', { name: 'Visit', exact: true }).isVisible(), 'menu open at 360px');
      await page.setViewportSize({ width: 1280, height: 800 });
      await page.waitForFunction(() => document.querySelector('.nav-toggle').getAttribute('aria-expanded') === 'false');
      assert.equal(await page.locator('.nav-toggle').isVisible(), false, 'toggle hidden on desktop');
      assert.equal(await page.locator('.nav-toggle').getAttribute('aria-expanded'), 'false');
      for (const name of ['Home', 'Books', 'Events', 'Visit']) {
        assert.ok(await page.getByRole('link', { name, exact: true }).first().isVisible(), `${name} visible on desktop`);
      }
      assert.ok(await overflow(page) <= 0, 'desktop layout scrolls sideways after resize');
    },
  },
  {
    name: 'criterion 4 hostile: a menu opened on one page is closed after navigating, and back keeps state consistent',
    async run(ctx) {
      const { page } = await ctx.open({ viewport: MOBILE });
      await page.goto(ctx.url('books.html'));
      await page.getByRole('button', { name: 'Menu' }).click();
      await page.getByRole('link', { name: 'Events', exact: true }).click();
      await page.waitForURL(/events\.html$/);
      assert.equal(await page.getByRole('button', { name: 'Menu' }).getAttribute('aria-expanded'), 'false');
      assert.ok(!(await page.locator('#site-nav-list').isVisible()), 'menu closed on the new page');
      await page.goBack();
      await page.waitForURL(/books\.html$/);
      const expanded = await page.getByRole('button', { name: 'Menu' }).getAttribute('aria-expanded');
      const visible = await page.locator('#site-nav-list').isVisible();
      assert.equal(visible, expanded === 'true', 'aria-expanded must match what is shown');
    },
  },
  {
    name: 'criterion 4: at 1280px the nav is inline with no menu button and the catalog runs in several columns',
    async run(ctx) {
      const { page } = await ctx.open();
      await page.goto(ctx.url('books.html'));
      assert.equal(await page.getByRole('button', { name: 'Menu' }).isVisible(), false);
      assert.ok(await page.getByRole('link', { name: 'Visit', exact: true }).isVisible(), 'inline nav link visible');
      const xs = await page.$$eval('.book-list > li', (items) => items.map((li) => Math.round(li.getBoundingClientRect().x)));
      assert.ok(new Set(xs).size >= 2, 'catalog cards should sit in more than one column at 1280px');
      assert.ok(await overflow(page) <= 0);
    },
  },
  {
    name: 'finding 1: with JavaScript off at 360px every nav link is visible, the menu button stays hidden and nothing scrolls sideways',
    async run(ctx) {
      const { page } = await ctx.open({ viewport: MOBILE, javaScriptEnabled: false });
      for (const file of PAGES) {
        await page.goto(ctx.url(file));
        const nav = page.getByRole('navigation', { name: 'Main' });
        for (const name of ['Home', 'Books', 'Events', 'Visit']) {
          assert.ok(await nav.getByRole('link', { name, exact: true }).isVisible(), `${file}: ${name} link visible without JavaScript`);
        }
        assert.equal(await page.locator('.nav-toggle').isVisible(), false, `${file}: menu button hidden without JavaScript`);
        assert.ok(await overflow(page) <= 0, `${file} scrolls sideways without JavaScript at 360px`);
      }
    },
  },
  {
    name: 'finding 6: menu open with focus on the toggle, then resized to desktop, moves focus to the first nav link',
    async run(ctx) {
      const { page } = await ctx.open({ viewport: MOBILE });
      await page.goto(ctx.url('books.html'));
      await page.getByRole('button', { name: 'Menu' }).click();
      assert.equal(await page.evaluate(() => document.activeElement.className), 'nav-toggle', 'toggle has focus before resize');
      await page.setViewportSize({ width: 1280, height: 800 });
      await page.waitForFunction(() => document.querySelector('.nav-toggle').getAttribute('aria-expanded') === 'false');
      assert.equal(await page.evaluate(() => document.activeElement.textContent.trim()), 'Home', 'focus moves to the first nav link, not BODY');
    },
  },
  {
    name: 'finding 6: menu open with focus on a menu link, then resized to desktop, keeps focus on that link',
    async run(ctx) {
      const { page } = await ctx.open({ viewport: MOBILE });
      await page.goto(ctx.url('books.html'));
      await page.getByRole('button', { name: 'Menu' }).click();
      await page.getByRole('link', { name: 'Events', exact: true }).focus();
      await page.setViewportSize({ width: 1280, height: 800 });
      await page.waitForFunction(() => document.querySelector('.nav-toggle').getAttribute('aria-expanded') === 'false');
      assert.equal(await page.evaluate(() => document.activeElement.textContent.trim()), 'Events', 'focus stays on the menu link');
    },
  },
  {
    name: 'triggered focus: Escape from a link inside the open menu closes only the menu, and a second Escape changes nothing',
    async run(ctx) {
      const { page } = await ctx.open({ viewport: MOBILE });
      await page.goto(ctx.url('books.html'));
      await tabTo(page, '.nav-toggle');
      await page.keyboard.press('Enter');
      await tabTo(page, '#site-nav-list a');
      await page.keyboard.press('Escape');
      assert.equal(await page.evaluate(() => document.activeElement.className), 'nav-toggle', 'focus returns to the toggle');
      assert.equal(await page.getByRole('button', { name: 'Menu' }).getAttribute('aria-expanded'), 'false');
      await page.keyboard.press('Escape');
      assert.equal(await page.evaluate(() => document.activeElement.className), 'nav-toggle', 'second Escape leaves focus alone');
      assert.equal(await page.getByRole('button', { name: 'Menu' }).getAttribute('aria-expanded'), 'false');
    },
  },
];

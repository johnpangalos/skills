// Events data, sorted by start. `start` is a local date and time in the shop's timezone (YYYY-MM-DDTHH:MM).
window.MARGINALIA_EVENTS = [
  {
    title: 'Winter Reading Circle',
    start: '2026-12-05T18:30',
    description: 'Bring a book you loved this year and tell the group why. Mulled apple juice is on the house, and the chairs by the fire are yours for the evening.',
    audience: 'adults who enjoy talking about books',
  },
  {
    title: 'Story Time: Lanterns and Lullabies',
    start: '2026-12-12T11:00',
    description: 'Picture books, a paper lantern craft and a sing-along for the youngest readers. Please stay with your child for the whole session.',
    audience: 'children aged 3 to 7, with a grown-up',
  },
  {
    title: 'Mulled Poetry Night',
    start: '2026-12-19T19:00',
    description: 'Local poets read new work and old favourites in the back room, with mince pies and a short open mic at the end of the evening.',
    audience: 'everyone, including first-time poetry listeners',
  },
  {
    title: 'Secondhand Book Fair',
    start: '2027-01-09T10:30',
    description: 'Hundreds of secondhand books at fair prices, from paperback thrillers to rare field guides. Bring a tote bag, because you will need one.',
    audience: 'all ages, no booking needed',
  },
  {
    title: "Mystery Book Club: The Clockmaker's Last Witness",
    start: '2027-01-23T19:30',
    description: "We discuss Evander Holt's puzzle novel and try to guess the culprit before the last chapter. Spoilers are welcome after the first half hour.",
    audience: 'adults who like a good puzzle',
  },
  {
    title: 'Author Evening with Imogen Scarrow',
    start: '2027-02-13T18:00',
    description: 'The author of Walking the Fell Wall talks about her walks, her notebooks and the stubborn stone wall that started the whole book. Questions are welcome.',
    audience: 'nature writing fans and walkers',
  },
  {
    title: "Children's Poetry Workshop",
    start: '2027-03-06T14:00',
    description: 'A relaxed afternoon of writing games, rhyme and a little bit of mess. Each young writer goes home with a notebook of their own poems.',
    audience: 'children aged 8 to 12',
  },
];

'use strict';

const { test } = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const http = require('node:http');
const path = require('node:path');
const { setupSuite, openTracked, visit, PAGES } = require('./helpers');
const { ROOT } = require('./server');

const suite = setupSuite();

const SHARED_FILES = [
  ['css/styles.css', 'text/css'],
  ['js/books-data.js', 'javascript'],
  ['js/books.js', 'javascript'],
  ['js/events-data.js', 'javascript'],
  ['js/events.js', 'javascript'],
  ['js/contact.js', 'javascript'],
  ['favicon.svg', 'image/svg+xml'],
  ['README.md', 'text/markdown'],
];

function rawGet(url) {
  return new Promise((resolve, reject) => {
    http.get(url, (res) => {
      res.resume();
      res.on('end', () => resolve(res.statusCode));
    }).on('error', reject);
  });
}

test('the four pages and shared assets are served with correct content types', async () => {
  for (const name of PAGES) {
    const response = await fetch(`${suite.base}/${name}`);
    assert.equal(response.status, 200, name);
    assert.match(response.headers.get('content-type'), /^text\/html/, name);
  }
  for (const [name, type] of SHARED_FILES) {
    const response = await fetch(`${suite.base}/${name}`);
    assert.equal(response.status, 200, name);
    assert.ok(response.headers.get('content-type').includes(type), name);
  }
});

test('there is no build step and no package.json dependencies', () => {
  const manifest = path.join(ROOT, 'package.json');
  if (fs.existsSync(manifest)) {
    const pkg = JSON.parse(fs.readFileSync(manifest, 'utf8'));
    assert.deepEqual(Object.keys(pkg.dependencies || {}), []);
    assert.deepEqual(Object.keys(pkg.devDependencies || {}), []);
  }
});

test('every page renders its content when opened directly from file://, with no errors', async () => {
  const cases = [
    ['index.html', 'main section.hero h1', 'Marginalia Books'],
    ['books.html', '#book-list .book-card', null],
    ['books.html?genre=mystery', '#book-list .book-card:not([hidden])', null],
    ['events.html', '#upcoming-list li.event', null],
    ['visit.html', '#hours tbody tr', null],
  ];
  for (const [name, selector] of cases) {
    const t = await openTracked(suite, { origin: null });
    await visit(t, `file://${ROOT}/${name}`);
    assert.ok(await t.page.locator(selector).count() > 0, `${name} renders ${selector}`);
    assert.deepEqual(t.problems, [], name);
    await t.context.close();
  }
});

test('file:// books page filters from the query string', async () => {
  const t = await openTracked(suite, { origin: null });
  await visit(t, `file://${ROOT}/books.html?genre=mystery`);
  assert.equal(await t.page.getByRole('radio', { name: 'Mystery' }).isChecked(), true);
  assert.equal(await t.page.locator('#book-list .book-card:not([hidden])').count(), 3);
  await t.context.close();
});

test('every request stays on the local origin; no fonts, CDNs, analytics or iframes', async () => {
  for (const name of PAGES) {
    const t = await openTracked(suite);
    await visit(t, `${suite.base}/${name}`);
    await t.page.waitForLoadState('networkidle');
    assert.equal(await t.page.locator('main').count(), 1, `${name} rendered`);
    assert.deepEqual(t.problems.filter((p) => p.startsWith('offsite')), [], name);
    const remote = await t.page.$$eval('link[href], script[src], img[src], iframe, source[src], video, audio', (nodes) =>
      nodes.map((node) => node.getAttribute('href') || node.getAttribute('src') || node.tagName).filter((value) => /^(https?:)?\/\//.test(value) || value === 'IFRAME'),
    );
    assert.deepEqual(remote, [], `${name} references`);
    assert.equal(await t.page.locator('link[rel="preconnect"], link[rel="dns-prefetch"]').count(), 0);
    assert.equal(await t.page.evaluate(() => document.fonts.size), 0, `${name} loads no web fonts`);
    await t.context.close();
  }
  const css = await (await fetch(`${suite.base}/css/styles.css`)).text();
  assert.doesNotMatch(css, /@import/);
  assert.doesNotMatch(css, /url\(\s*['"]?(https?:)?\/\//);
});

test('the favicon is a local file that resolves', async () => {
  const t = await openTracked(suite);
  await visit(t, `${suite.base}/index.html`);
  const href = await t.page.locator('link[rel~="icon"]').getAttribute('href');
  assert.ok(!/^(https?:)?\/\//.test(href), 'favicon is not remote');
  const response = await t.page.request.get(new URL(href, t.page.url()).toString());
  assert.equal(response.status(), 200);
  await t.context.close();
});

test('missing files, dotfiles and traversal attempts return 404', async () => {
  assert.equal(await rawGet(`${suite.base}/no-such-page.html`), 404);
  assert.equal(await rawGet(`${suite.base}/.git/config`), 404);
  assert.equal(await rawGet(`${suite.base}/..%2FFEATURE_FLOW.md`), 404);
  assert.equal(await rawGet(`${suite.base}/%2e%2e%2fFEATURE_FLOW.md`), 404);
});

test('no console errors, page errors or failed requests on any page, including filtered URLs', async () => {
  const urls = ['index.html', 'books.html', 'books.html?genre=mystery', 'books.html?genre=nonexistent', 'events.html', 'visit.html'];
  for (const name of urls) {
    const t = await openTracked(suite);
    await visit(t, `${suite.base}/${name}`);
    await t.page.waitForLoadState('networkidle');
    assert.deepEqual(t.problems, [], name);
    await t.context.close();
  }
});

test('no lorem ipsum placeholder copy on any page', async () => {
  for (const name of PAGES) {
    const t = await openTracked(suite);
    await visit(t, `${suite.base}/${name}`);
    assert.equal(await t.page.locator('main').count(), 1, `${name} rendered`);
    assert.doesNotMatch(await t.page.locator('body').textContent(), /lorem ipsum/i, name);
    await t.context.close();
  }
});

test('README explains what the site is, how to view it, the layout and how to run the tests', () => {
  const readme = fs.readFileSync(path.join(ROOT, 'README.md'), 'utf8');
  assert.match(readme, /Marginalia Books/);
  assert.match(readme, /python3 -m http\.server/);
  assert.match(readme, /index\.html/);
  assert.match(readme, /css\/styles\.css/);
  assert.match(readme, /node --test/);
});

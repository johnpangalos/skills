'use strict';

const { test, before, after } = require('node:test');
const assert = require('node:assert/strict');
const { chromium } = require('playwright');
const { startServer } = require('./server');

let server;
let browser;

before(async () => {
  server = await startServer();
  browser = await chromium.launch();
});

after(async () => {
  await browser.close();
  await server.close();
});

// Opens books.html with a query string and records console errors, page errors and dialogs.
async function openBooks(query = '') {
  const page = await browser.newPage();
  const problems = [];
  page.on('console', (msg) => {
    if (msg.type() === 'error') problems.push(msg.text());
  });
  page.on('pageerror', (err) => problems.push(err.message));
  page.on('dialog', (dialog) => {
    problems.push(`dialog: ${dialog.message()}`);
    dialog.dismiss();
  });
  await page.goto(`${server.origin}/books.html${query}`);
  await page.waitForSelector('#book-list > li');
  return { page, problems };
}

const dataBooks = (page) => page.evaluate(() => window.MARGINALIA_BOOKS);
const titles = (page) => page.$$eval('#book-list h2', (els) => els.map((el) => el.textContent));
const genreTags = (page) => page.$$eval('#book-list .book-genre', (els) => els.map((el) => el.textContent));
const selectedGenre = (page) => page.getByLabel('Genre').inputValue();
const countText = (page) => page.getByRole('status').textContent();

async function waitForGenre(page, value) {
  await page.waitForFunction((v) => document.getElementById('genre-filter').value === v, value);
}

async function state(page) {
  return {
    genre: await selectedGenre(page),
    count: await countText(page),
    titles: await titles(page),
  };
}

test('catalog has at least 12 books across at least 5 genres, each genre with at least 2 titles', async () => {
  const { page, problems } = await openBooks();
  const books = await dataBooks(page);
  assert.ok(books.length >= 12, `only ${books.length} books`);
  const counts = {};
  for (const book of books) counts[book.genre] = (counts[book.genre] || 0) + 1;
  assert.ok(Object.keys(counts).length >= 5, 'at least five genres');
  for (const [genre, n] of Object.entries(counts)) assert.ok(n >= 2, `${genre} has ${n} titles`);
  assert.equal(await page.locator('#book-list > li').count(), books.length);
  assert.deepEqual(problems, []);
  await page.close();
});

test('each book shows title, author, genre, price and a blurb', async () => {
  const { page } = await openBooks();
  const cards = await page.$$eval('#book-list > li', (items) =>
    items.map((li) => ({
      title: li.querySelector('h2')?.textContent.trim() || '',
      author: li.querySelector('.book-author')?.textContent.trim() || '',
      genre: li.querySelector('.book-genre')?.textContent.trim() || '',
      price: li.querySelector('.book-price')?.textContent.trim() || '',
      blurb: li.querySelector('.book-blurb')?.textContent.trim() || '',
    })),
  );
  assert.ok(cards.length >= 12);
  for (const card of cards) {
    assert.ok(card.title, 'title');
    assert.match(card.author, /^by \S/, `author for ${card.title}`);
    assert.ok(card.genre, `genre for ${card.title}`);
    assert.match(card.price, /^£\d+\.\d{2}$/, `price for ${card.title}`);
    assert.ok(card.blurb.length >= 40, `blurb for ${card.title}`);
  }
  await page.close();
});

test('genre control is labelled and offers All genres plus every genre from the data, in order', async () => {
  const { page } = await openBooks();
  const books = await dataBooks(page);
  const options = await page.getByLabel('Genre').locator('option').allTextContents();
  const genres = [...new Set(books.map((b) => b.genre))];
  assert.deepEqual(options, ['All genres', ...genres]);
  await page.close();
});

test('choosing a genre shows only its books, updates the count, and All restores every book', async () => {
  const { page } = await openBooks();
  const books = await dataBooks(page);
  const mystery = books.filter((b) => b.genre === 'Mystery').length;
  await page.getByLabel('Genre').selectOption('mystery');
  assert.deepEqual(await genreTags(page), Array(mystery).fill('Mystery'));
  assert.equal(await countText(page), `Showing ${mystery} of ${books.length} books`);
  await page.getByLabel('Genre').selectOption('');
  assert.equal((await titles(page)).length, books.length);
  assert.equal(await countText(page), `Showing ${books.length} of ${books.length} books`);
  await page.close();
});

test('the result count sits in a polite live region', async () => {
  const { page } = await openBooks();
  const status = page.getByRole('status');
  assert.equal(await status.count(), 1);
  const live = await status.getAttribute('aria-live');
  assert.ok(live === null || live === 'polite', `aria-live is ${live}`);
  await page.close();
});

test('choosing a genre writes it to the query string', async () => {
  const { page } = await openBooks();
  await page.getByLabel('Genre').selectOption('poetry');
  assert.equal(new URL(page.url()).search, '?genre=poetry');
  await page.close();
});

test('loading a genre URL restores the control and the list', async () => {
  const { page, problems } = await openBooks('?genre=poetry');
  assert.equal(await selectedGenre(page), 'poetry');
  const tags = await genreTags(page);
  assert.ok(tags.length >= 2);
  assert.ok(tags.every((tag) => tag === 'Poetry'));
  assert.equal(await countText(page), `Showing ${tags.length} of 15 books`);
  assert.deepEqual(problems, []);
  await page.close();
});

test('back and forward keep the control and the list in sync', async () => {
  const { page } = await openBooks();
  const all = await titles(page);
  await page.getByLabel('Genre').selectOption('mystery');
  const mystery = await titles(page);
  await page.getByLabel('Genre').selectOption('poetry');
  await page.goBack();
  await waitForGenre(page, 'mystery');
  assert.deepEqual(await titles(page), mystery);
  await page.goBack();
  await waitForGenre(page, '');
  assert.deepEqual(await titles(page), all);
  await page.goForward();
  await waitForGenre(page, 'mystery');
  assert.deepEqual(await titles(page), mystery);
  await page.close();
});

test('hostile ?genre= (empty) shows All with no error', async () => {
  const { page, problems } = await openBooks('?genre=');
  assert.equal(await selectedGenre(page), '');
  assert.equal((await titles(page)).length, 15);
  assert.equal(await countText(page), 'Showing 15 of 15 books');
  assert.deepEqual(problems, []);
  await page.close();
});

test('hostile ?genre=doesnotexist falls back to All with no blank list and no console error', async () => {
  const { page, problems } = await openBooks('?genre=doesnotexist');
  assert.equal(await selectedGenre(page), '');
  assert.equal((await titles(page)).length, 15);
  assert.equal(await countText(page), 'Showing 15 of 15 books');
  assert.deepEqual(problems, []);
  await page.close();
});

test('hostile ?genre=MYSTERY matches case-insensitively', async () => {
  const { page, problems } = await openBooks('?genre=MYSTERY');
  assert.equal(await selectedGenre(page), 'mystery');
  assert.deepEqual(await genreTags(page), ['Mystery', 'Mystery', 'Mystery']);
  assert.deepEqual(problems, []);
  await page.close();
});

test('hostile ?genre=%20mystery%20 matches after trimming', async () => {
  const { page, problems } = await openBooks('?genre=%20mystery%20');
  assert.equal(await selectedGenre(page), 'mystery');
  assert.deepEqual(await genreTags(page), ['Mystery', 'Mystery', 'Mystery']);
  assert.deepEqual(problems, []);
  await page.close();
});

test('hostile ?genre=<script> runs no script and injects no HTML', async () => {
  const payload = '<script>window.__pwned = true</script><img src=x onerror="window.__pwned = true">';
  const { page, problems } = await openBooks(`?genre=${encodeURIComponent(payload)}`);
  assert.equal(await page.evaluate(() => window.__pwned), undefined);
  assert.equal(await page.evaluate(() => document.querySelectorAll('script:not([src])').length), 0);
  assert.equal(await page.evaluate(() => document.querySelectorAll('#book-list img').length), 0);
  assert.equal(await selectedGenre(page), '');
  assert.equal(await countText(page), 'Showing 15 of 15 books');
  assert.deepEqual(problems, []);
  await page.close();
});

test('URL and filter state round-trip: every genre and every hostile value reloads to the same state', async () => {
  const first = await openBooks();
  const values = await first.page.getByLabel('Genre').locator('option').evaluateAll((os) => os.map((o) => o.value));
  const allState = await state(first.page);
  for (const value of values.filter(Boolean)) {
    await first.page.getByLabel('Genre').selectOption(value);
    const before = await state(first.page);
    const fresh = await openBooks(new URL(first.page.url()).search);
    assert.deepEqual(await state(fresh.page), before, `round trip for ${value}`);
    assert.deepEqual(fresh.problems, []);
    await fresh.page.close();
    await first.page.getByLabel('Genre').selectOption('');
  }
  const hostile = ['', 'doesnotexist', 'MYSTERY', '%20mystery%20', encodeURIComponent('<b>x</b>')];
  for (const raw of hostile) {
    const once = await openBooks(`?genre=${raw}`);
    const before = await state(once.page);
    const canonical = new URL(once.page.url()).search;
    const again = await openBooks(canonical);
    assert.deepEqual(await state(again.page), before, `round trip for "${raw}"`);
    assert.deepEqual(once.problems, []);
    await once.page.close();
    await again.page.close();
  }
  assert.deepEqual(allState.titles.length, 15);
  await first.page.close();
});

test('a filter that yields zero results shows a visible no-books message, not an empty area', async () => {
  const { page, problems } = await openBooks();
  await page.evaluate(() => {
    const option = document.createElement('option');
    option.value = 'ghost';
    option.textContent = 'Ghost';
    document.getElementById('genre-filter').appendChild(option);
    const select = document.getElementById('genre-filter');
    select.value = 'ghost';
    select.dispatchEvent(new Event('change'));
  });
  await page.waitForFunction(() => document.getElementById('result-count').textContent.startsWith('Showing 0 '));
  assert.equal(await countText(page), 'Showing 0 of 15 books');
  assert.equal(await page.locator('#book-list > li').count(), 0);
  await page.locator('#no-books').waitFor({ state: 'visible' });
  assert.match(await page.locator('#no-books').textContent(), /No books match this genre/);
  assert.deepEqual(problems, []);
  await page.close();
});

test('book title and blurb containing HTML are shown as literal text and run no script', async () => {
  const hostile = '<img src=x onerror="window.__xss=1">';
  const page = await browser.newPage();
  await page.route('**/js/books-data.js', async (route) => {
    const response = await route.fetch();
    const fixture = { title: hostile, author: 'Test Author', genre: 'Mystery', price: 1, featured: false, blurb: hostile };
    const body = `${await response.text()}\nwindow.MARGINALIA_BOOKS.push(${JSON.stringify(fixture)});`;
    await route.fulfill({ status: 200, contentType: 'text/javascript', body });
  });
  await page.goto(`${server.origin}/books.html`);
  await page.waitForSelector('#book-list > li');
  assert.equal(await page.evaluate(() => window.__xss), undefined, 'no script ran');
  assert.equal(await page.locator('#book-list img').count(), 0, 'no image element was created');
  const cards = await page.$$eval('#book-list h2', (els) => els.map((el) => el.textContent));
  assert.ok(cards.includes(hostile), 'the title is shown literally');
  assert.ok((await page.locator('#book-list .book-blurb').allTextContents()).includes(hostile), 'the blurb is shown literally');
  await page.close();
});

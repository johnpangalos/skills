# Marginalia Books

A static website for Marginalia Books, a fictional independent bookshop. It has four pages (home, books, events and visit) with a shared navigation, a genre-filterable catalog, an events list, opening hours and a contact form.

The site is plain HTML, CSS and vanilla JavaScript with no build step and no external requests. Everything in it is fictional: the address (14 Example Row), the 555 phone number and the `.test` email domain.

## Run it locally

From the repository root:

```sh
python3 -m http.server 8000
```

Then open <http://localhost:8000/>.

## Run the tests

The tests use headless Chromium through the preinstalled `playwright` module and start their own static server on a free port. No packages need installing.

```sh
node tests/run.mjs                 # all tests
node tests/run.mjs books           # only test files whose name contains "books"
```

## Layout

- `index.html`, `books.html`, `events.html`, `visit.html`: the four pages.
- `css/styles.css`: the single shared stylesheet.
- `js/nav.js`: menu button for narrow screens.
- `js/books.js`: genre filter, state kept in the `genre` query parameter.
- `js/visit.js`: today's hours and contact form validation (the form sends nothing).
- `tests/`: Playwright tests, one file per area.

'use strict';

const { test, before, after } = require('node:test');
const assert = require('node:assert/strict');
const { startSite, launchBrowser, openSite, closeContexts } = require('./helpers');

const DEMO_TEXT = 'This is a demo site — your message was not sent. Please email or phone us instead.';
const DAYS = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'];

let site;
let browser;

before(async () => {
  site = await startSite();
  browser = await launchBrowser();
});

after(async () => {
  await closeContexts();
  await browser.close();
  await site.close();
});

const fieldState = (page, id) => page.$eval(`#${id}`, (input, fieldId) => ({
  invalid: input.getAttribute('aria-invalid'),
  describedBy: input.getAttribute('aria-describedby'),
  error: document.getElementById(`${fieldId}-error`).textContent.trim(),
}), id);
const activeId = (page) => page.evaluate(() => document.activeElement.id);
const status = (page) => page.locator('#form-status').textContent();

// Criterion 8: hours table, address, contact form on the visit page.
test('visit page has hours for every day with proper headers and a full <address> (criterion 8)', async () => {
  const { page } = await openSite(browser, site.origin, 'visit.html');
  const rows = await page.$$eval('table tbody tr', (trs) => trs.map((tr) => ({
    day: tr.querySelector('th').textContent.trim(),
    scope: tr.querySelector('th').getAttribute('scope'),
    hours: tr.querySelector('td') && tr.querySelector('td').textContent.trim(),
  })));
  assert.deepEqual(rows.map((r) => r.day), DAYS);
  assert.ok(rows.every((r) => r.scope === 'row' && r.hours), 'row headers and hours cells');
  const headers = await page.$$eval('table thead th', (ths) => ths.map((th) => [th.textContent.trim(), th.getAttribute('scope')]));
  assert.deepEqual(headers.map((h) => h[1]), ['col', 'col']);
  assert.equal(await page.locator('table caption').count(), 1);
  const address = await page.locator('main address').innerText();
  assert.match(address, /14 Lantern Row/);
  assert.match(address, /Alder Bend, OR 97420/);
});

// Criterion 9: contact form labels and required text.
test('contact form has visible labels, required marked in text, and input types (criterion 9)', async () => {
  const { page } = await openSite(browser, site.origin, 'visit.html');
  for (const [id, label] of [['name', 'Name'], ['email', 'Email'], ['message', 'Message']]) {
    const text = await page.locator(`label[for="${id}"]`).textContent();
    assert.ok(text.includes(label), `${id} label`);
    assert.match(text, /required/i, `${id} label marks required in text`);
    assert.equal(await page.locator(`#${id}`).getAttribute('required'), '');
  }
  assert.equal(await page.locator('#email').getAttribute('type'), 'email');
  assert.equal(await page.getByRole('textbox', { name: /Name/ }).count(), 1);
});

test('empty required fields show inline errors linked by aria-describedby and focus the first invalid field (criterion 9)', async () => {
  const { page, log } = await openSite(browser, site.origin, 'visit.html');
  await page.getByRole('button', { name: /send|submit/i }).click();
  assert.equal(await activeId(page), 'name');
  for (const id of ['name', 'email', 'message']) {
    const state = await fieldState(page, id);
    assert.equal(state.invalid, 'true', `${id} aria-invalid`);
    assert.equal(state.describedBy, `${id}-error`, `${id} aria-describedby`);
    assert.ok(state.error.length > 0, `${id} error text`);
  }
  assert.equal(await status(page), 'Please fix the highlighted fields.');
  assert.deepEqual(log.pageErrors, []);
});

test('errors clear when the field is fixed (criterion 9)', async () => {
  const { page } = await openSite(browser, site.origin, 'visit.html');
  await page.getByRole('button', { name: /send|submit/i }).click();
  await page.fill('#name', 'Ada Okafor');
  const state = await fieldState(page, 'name');
  assert.equal(state.error, '');
  assert.notEqual(state.invalid, 'true');
  assert.equal(state.describedBy, null);
});

test('whitespace-only name and message are treated as empty (criterion 9, hostile)', async () => {
  const { page } = await openSite(browser, site.origin, 'visit.html');
  await page.fill('#name', '     ');
  await page.fill('#email', 'ada@example.org');
  await page.fill('#message', '\n\t   ');
  await page.getByRole('button', { name: /send|submit/i }).click();
  assert.equal((await fieldState(page, 'name')).invalid, 'true');
  assert.equal((await fieldState(page, 'message')).invalid, 'true');
  assert.notEqual((await fieldState(page, 'email')).invalid, 'true');
  assert.equal(await activeId(page), 'name');
});

for (const [email, valid] of [
  ['a@b', false],
  ['not-an-email', false],
  ['a@b.co', true],
  ['x@y..com', false],
  ['a@-b.com', false],
  ['first.last+tag@shop.example.org', true],
]) {
  test(`email "${email}" is ${valid ? 'accepted' : 'rejected with an inline error'} (criterion 9, hostile)`, async () => {
    const { page } = await openSite(browser, site.origin, 'visit.html');
    await page.fill('#name', 'Ada Okafor');
    await page.fill('#email', email);
    await page.fill('#message', 'Do you hold a copy of the Lantern Murders?');
    await page.getByRole('button', { name: /send|submit/i }).click();
    const state = await fieldState(page, 'email');
    if (valid) {
      assert.equal(state.invalid, null);
      assert.equal(state.error, '');
      assert.equal(await status(page), DEMO_TEXT);
    } else {
      assert.equal(state.invalid, 'true');
      assert.equal(state.describedBy, 'email-error');
      assert.ok(state.error.length > 0);
      assert.equal(await activeId(page), 'email');
    }
  });
}

test('a valid submit sends nothing over the network and says plainly it is a demo (criterion 9)', async () => {
  const { page, log } = await openSite(browser, site.origin, 'visit.html');
  await page.fill('#name', 'Ada Okafor');
  await page.fill('#email', 'ada@example.org');
  await page.fill('#message', 'Do you hold a copy of the Lantern Murders?');
  const before = log.requests.length;
  await page.getByRole('button', { name: /send|submit/i }).click();
  await page.waitForFunction(() => document.getElementById('form-status').textContent.length > 0);
  assert.equal(await status(page), DEMO_TEXT);
  assert.equal(await page.locator('#form-status').getAttribute('role'), 'status');
  assert.equal(log.requests.length, before, 'no request after submit');
  assert.doesNotMatch(await status(page), /thank you|we.ve received|message (has been )?sent/i);
});

test('submitting twice keeps the demo message and sends nothing (criterion 9, hostile)', async () => {
  const { page, log } = await openSite(browser, site.origin, 'visit.html');
  await page.fill('#name', 'Ada Okafor');
  await page.fill('#email', 'ada@example.org');
  await page.fill('#message', 'Do you hold a copy of the Lantern Murders?');
  const before = log.requests.length;
  await page.getByRole('button', { name: /send|submit/i }).click();
  await page.getByRole('button', { name: /send|submit/i }).click();
  await page.waitForFunction(() => document.getElementById('form-status').textContent.length > 0);
  assert.equal(await status(page), DEMO_TEXT);
  assert.equal(await page.locator('.field-error:not(:empty)').count(), 0);
  assert.equal(log.requests.length, before, 'no request after two submits');
});

test('a 5000-character message is accepted and 5001 characters is rejected with focus on the message (criterion 9, hostile)', async () => {
  const { page } = await openSite(browser, site.origin, 'visit.html');
  await page.fill('#name', 'Ada Okafor');
  await page.fill('#email', 'ada@example.org');
  await page.fill('#message', 'a'.repeat(5000));
  await page.getByRole('button', { name: /send|submit/i }).click();
  assert.equal(await status(page), DEMO_TEXT);
  assert.equal((await fieldState(page, 'message')).invalid, null);

  // Typed into the real textarea: the field must keep all 5001 characters, not cut them off silently.
  await page.fill('#message', 'a'.repeat(5001));
  assert.equal(await page.inputValue('#message'), 'a'.repeat(5001));
  await page.getByRole('button', { name: /send|submit/i }).click();
  const state = await fieldState(page, 'message');
  assert.equal(state.invalid, 'true');
  assert.equal(state.describedBy, 'message-error');
  assert.equal(state.error, 'Please keep your message to 5,000 characters or fewer.');
  assert.equal(await activeId(page), 'message');
  assert.equal(await status(page), 'Please fix the highlighted fields.');
});

test('markup in the name is never rendered as HTML and runs no script (criterion 9, hostile)', async () => {
  const { page, log } = await openSite(browser, site.origin, 'visit.html');
  const payload = '<img src=x onerror=alert(1)>';
  await page.fill('#name', payload);
  await page.fill('#email', 'ada@example.org');
  await page.fill('#message', 'Hello from the Lantern Row shop.');
  await page.getByRole('button', { name: /send|submit/i }).click();
  assert.equal(await status(page), DEMO_TEXT);
  assert.equal(await page.locator('img').count(), 0);
  assert.equal(await page.locator('main').evaluate((main) => main.querySelectorAll('[onerror]').length), 0);
  assert.equal(await page.inputValue('#name'), payload);
  assert.deepEqual(log.dialogs, []);
  assert.deepEqual(log.pageErrors, []);
});

// Round 2: with JavaScript off the form must not fall back to a GET submit that puts the message in the URL.
test('with JavaScript off the submit button is disabled, Enter and click do not submit, and the noscript note shows (criterion 9, hostile)', async () => {
  const context = await browser.newContext({ javaScriptEnabled: false, viewport: { width: 1280, height: 900 } });
  try {
    const page = await context.newPage();
    const requests = [];
    page.on('request', (request) => requests.push(request.url()));
    const response = await page.goto(`${site.origin}/visit.html`);
    assert.equal(response.status(), 200);
    const url = page.url();
    assert.equal(await page.locator('button[type="submit"]').isDisabled(), true);
    assert.equal(await page.getByText(/needs JavaScript/).isVisible(), true);
    await page.fill('#name', 'Ada Okafor');
    await page.fill('#email', 'ada@example.org');
    await page.fill('#message', 'Do you hold a copy of the Lantern Murders?');
    const before = requests.length;
    await page.locator('button[type="submit"]').click({ force: true, timeout: 2000 });
    await page.press('#email', 'Enter');
    await page.waitForTimeout(300);
    assert.equal(page.url(), url, 'no navigation');
    assert.equal(requests.length, before, 'no request after click or Enter');
    assert.ok(!requests.some((u) => u.includes('message=')), 'message never in a URL');
  } finally {
    await context.close();
  }
});

test('with JavaScript on the submit button is enabled and the noscript note is hidden (criterion 9)', async () => {
  const { page } = await openSite(browser, site.origin, 'visit.html');
  assert.equal(await page.locator('button[type="submit"]').isDisabled(), false);
  assert.equal(await page.getByText(/needs JavaScript/).isVisible(), false);
});

test('fixing the last invalid field clears the "Please fix" status text (criterion 9)', async () => {
  const { page } = await openSite(browser, site.origin, 'visit.html');
  await page.getByRole('button', { name: /send|submit/i }).click();
  assert.equal(await status(page), 'Please fix the highlighted fields.');
  await page.fill('#name', 'Ada Okafor');
  await page.fill('#email', 'ada@example.org');
  assert.equal(await status(page), 'Please fix the highlighted fields.', 'still one invalid field');
  await page.fill('#message', 'Do you hold a copy of the Lantern Murders?');
  assert.equal(await status(page), '');
});

// Triggered check: keyboard-only use of the form, focus moves to the first invalid field.
test('contact form can be submitted from the keyboard and focus moves to the first error (keyboard)', async () => {
  const { page } = await openSite(browser, site.origin, 'visit.html');
  await page.click('#message');
  await page.keyboard.press('Tab');
  assert.equal(await page.evaluate(() => document.activeElement.textContent.trim()), 'Send message');
  await page.keyboard.press('Enter');
  assert.equal(await activeId(page), 'name');
  assert.equal((await fieldState(page, 'name')).invalid, 'true');
});

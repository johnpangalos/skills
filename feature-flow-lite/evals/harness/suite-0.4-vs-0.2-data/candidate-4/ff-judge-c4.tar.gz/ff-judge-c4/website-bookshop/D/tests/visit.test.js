'use strict';

const { test } = require('node:test');
const assert = require('node:assert/strict');
const { setupSuite, openTracked, visit } = require('./helpers');

const suite = setupSuite();

const VALID_NAME = 'Ada Lovelace';
const VALID_EMAIL = 'ada.lovelace+books@example.co.uk';
const VALID_MESSAGE = 'Do you hold copies of poetry chapbooks?';

async function openVisit(viewport) {
  const t = await openTracked(suite, { viewport });
  await visit(t, `${suite.base}/visit.html`);
  return t;
}

async function fillForm(page, { name = VALID_NAME, email = VALID_EMAIL, message = VALID_MESSAGE } = {}) {
  await page.fill('#contact-name', name);
  await page.fill('#contact-email', email);
  await page.fill('#contact-message', message);
}

async function submit(page) {
  await page.getByRole('button', { name: 'Send message' }).click();
}

test('opening hours cover every day with closed days stated', async () => {
  const t = await openVisit();
  const rows = await t.page.$$eval('#hours tbody tr', (trs) =>
    trs.map((tr) => [...tr.children].map((cell) => cell.textContent.trim())),
  );
  assert.deepEqual(rows.map((row) => row[0]), [
    'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday',
  ]);
  for (const [, hours] of rows) assert.ok(hours.length > 0, 'every day has hours or Closed');
  assert.match(rows[0][1], /Closed/);
  await t.context.close();
});

test('address is a full street address in an address element; no embedded map', async () => {
  const t = await openVisit();
  const address = await t.page.locator('address').textContent();
  assert.match(address, /Quill Lane/);
  assert.match(address, /[A-Z]{1,2}\d{1,2} \d[A-Z]{2}/);
  assert.equal(await t.page.locator('iframe').count(), 0);
  await t.context.close();
});

test('phone and email are tel: and mailto: links, and directions, transit and accessibility are covered', async () => {
  const t = await openVisit();
  const { page } = t;
  assert.ok(await page.locator('a[href^="tel:"]').count() >= 1);
  assert.ok(await page.locator('a[href^="mailto:"]').count() >= 1);
  const headings = (await page.locator('main h2').allTextContents()).join(' | ');
  assert.match(headings, /Directions|Getting here/i);
  assert.match(headings, /Transit|Bus|Train/i);
  assert.match(headings, /Accessibility/i);
  await t.context.close();
});

test('every form field has a visible label tied by for/id, with required, types and autocomplete set', async () => {
  const t = await openVisit();
  const { page } = t;
  const fields = await page.$$eval('#contact-form input, #contact-form select, #contact-form textarea', (nodes) =>
    nodes.map((node) => ({
      id: node.id,
      tag: node.tagName.toLowerCase(),
      type: node.getAttribute('type'),
      required: node.required,
      autocomplete: node.getAttribute('autocomplete'),
      labelText: node.labels && node.labels[0] ? node.labels[0].textContent.trim() : '',
    })),
  );
  const byId = Object.fromEntries(fields.map((field) => [field.id, field]));
  for (const field of fields) {
    assert.ok(field.labelText, `${field.id} has a label`);
    assert.equal(await page.locator(`label[for="${field.id}"]`).isVisible(), true, `${field.id} label visible`);
  }
  assert.equal(byId['contact-name'].required, true);
  assert.equal(byId['contact-name'].autocomplete, 'name');
  assert.equal(byId['contact-email'].required, true);
  assert.equal(byId['contact-email'].type, 'email');
  assert.equal(byId['contact-email'].autocomplete, 'email');
  assert.equal(byId['contact-message'].required, true);
  assert.equal(byId['contact-reason'].required, false, 'reason is optional');
  assert.equal(await page.locator('#contact-form').evaluate((form) => form.noValidate), true);
  assert.deepEqual(t.problems, []);
  await t.context.close();
});

test('empty submit flags each required field, links errors with aria-describedby, and focuses the first', async () => {
  const t = await openVisit();
  const { page } = t;
  await submit(page);
  for (const id of ['contact-name', 'contact-email', 'contact-message']) {
    assert.equal(await page.locator(`#${id}`).getAttribute('aria-invalid'), 'true', `${id} aria-invalid`);
    const describedBy = (await page.locator(`#${id}`).getAttribute('aria-describedby')).split(' ');
    const errorId = describedBy.find((token) => token.endsWith('-error'));
    assert.ok(errorId, `${id} links its error`);
    assert.ok((await page.locator(`#${errorId}`).textContent()).trim().length > 0, `${errorId} has text`);
  }
  assert.equal(await page.evaluate(() => document.activeElement.id), 'contact-name');
  assert.equal(await page.locator('#contact-status').textContent(), '');
  await t.context.close();
});

test('whitespace-only name and message count as empty', async () => {
  const t = await openVisit();
  const { page } = t;
  await fillForm(page, { name: '   ', message: '\n\t  ' });
  await submit(page);
  assert.equal(await page.locator('#contact-name').getAttribute('aria-invalid'), 'true');
  assert.equal(await page.locator('#contact-message').getAttribute('aria-invalid'), 'true');
  assert.notEqual(await page.locator('#contact-email').getAttribute('aria-invalid'), 'true');
  await t.context.close();
});

test('email validation rejects a@b, foo, @x.com and user@@x.com and accepts ada.lovelace+books@example.co.uk', async () => {
  const t = await openVisit();
  const { page } = t;
  for (const bad of ['a@b', 'foo', '@x.com', 'user@@x.com']) {
    await fillForm(page, { email: bad });
    await submit(page);
    assert.equal(await page.locator('#contact-email').getAttribute('aria-invalid'), 'true', `${bad} should be invalid`);
    assert.equal(t.dialogs.length, 0);
  }
  await fillForm(page, { email: VALID_EMAIL });
  await submit(page);
  assert.equal(await page.locator('#contact-status').getAttribute('role'), 'status');
  assert.match(await page.locator('#contact-status').textContent(), /Thanks, Ada Lovelace/);
  await t.context.close();
});

test('errors clear as soon as the field is fixed', async () => {
  const t = await openVisit();
  const { page } = t;
  await submit(page);
  await page.fill('#contact-name', 'Ada');
  assert.notEqual(await page.locator('#contact-name').getAttribute('aria-invalid'), 'true');
  assert.equal(await page.locator('#contact-name-error').textContent(), '');
  assert.equal(await page.locator('#contact-name-error').isVisible(), false);
  assert.equal(await page.locator('#contact-email').getAttribute('aria-invalid'), 'true', 'other fields keep their errors');
  await t.context.close();
});

test('a valid submission shows a demo status in a live region, resets the form, and sends nothing', async () => {
  const t = await openVisit();
  const { page } = t;
  await fillForm(page);
  const before = t.requests.length;
  const url = page.url();
  await submit(page);
  const status = page.locator('#contact-status');
  assert.equal(await status.getAttribute('aria-live'), 'polite');
  const text = await status.textContent();
  assert.match(text, /Thanks, Ada Lovelace/);
  assert.match(text, /demo form doesn't send messages/);
  assert.doesNotMatch(text, /\b(was|has been|have been|been) sent\b/i);
  assert.equal(await page.inputValue('#contact-name'), '');
  assert.equal(await page.inputValue('#contact-message'), '');
  assert.equal(page.url(), url, 'the page does not navigate');
  assert.equal(t.requests.length, before, 'no network request is made');
  assert.deepEqual(t.problems, []);
  await t.context.close();
});

test('a hostile name is shown as text, never parsed as HTML', async () => {
  const t = await openVisit();
  const { page } = t;
  const hostile = '<img src=x onerror=alert(1)>';
  await fillForm(page, { name: hostile });
  await submit(page);
  const status = page.locator('#contact-status');
  assert.ok((await status.textContent()).includes(hostile));
  assert.equal(await status.locator('img').count(), 0);
  assert.equal(await page.locator('img[src="x"]').count(), 0);
  assert.equal(t.dialogs.length, 0);
  await t.context.close();
});

test('pressing Enter in a text input submits through the same validation', async () => {
  const t = await openVisit();
  const { page } = t;
  await page.fill('#contact-name', 'Ada');
  await page.focus('#contact-name');
  await page.keyboard.press('Enter');
  assert.equal(await page.locator('#contact-email').getAttribute('aria-invalid'), 'true');
  assert.equal(await page.locator('#contact-message').getAttribute('aria-invalid'), 'true');
  assert.equal(await page.evaluate(() => document.activeElement.id), 'contact-email');

  await fillForm(page, { email: VALID_EMAIL });
  await page.focus('#contact-name');
  await page.keyboard.press('Enter');
  assert.match(await page.locator('#contact-status').textContent(), /Thanks, Ada Lovelace/);
  assert.deepEqual(t.problems, []);
  await t.context.close();
});

test('a 5000-character message is accepted and the field declares maxlength 5000', async () => {
  const t = await openVisit();
  const { page } = t;
  assert.equal(await page.locator('#contact-message').getAttribute('maxlength'), '5000');
  await fillForm(page, { message: 'a'.repeat(5000) });
  await submit(page);
  assert.match(await page.locator('#contact-status').textContent(), /Thanks, Ada Lovelace/);
  assert.equal(await page.locator('#contact-message').getAttribute('aria-invalid'), null);
  await t.context.close();
});

test('submitting twice without refilling keeps the demo confirmation and shows no errors', async () => {
  const t = await openVisit();
  const { page } = t;
  await fillForm(page);
  await submit(page);
  await submit(page);
  const text = await page.locator('#contact-status').textContent();
  assert.equal(text.split('Thanks,').length - 1, 1, 'one status message');
  assert.match(text, /Thanks, Ada Lovelace/);
  assert.match(text, /demo form doesn't send messages/);
  for (const id of ['contact-name', 'contact-email', 'contact-message']) {
    assert.equal(await page.locator(`#${id}`).getAttribute('aria-invalid'), null, `${id} not invalid`);
    assert.equal(await page.locator(`#${id}-error`).textContent(), '', `${id} has no error text`);
    assert.equal(await page.locator(`#${id}-error`).isVisible(), false, `${id} error hidden`);
  }
  assert.deepEqual(t.problems, []);
  await t.context.close();
});

test('submitting twice after refilling the form does not duplicate the status message', async () => {
  const t = await openVisit();
  const { page } = t;
  await fillForm(page);
  await submit(page);
  await fillForm(page);
  await submit(page);
  const text = await page.locator('#contact-status').textContent();
  assert.equal(text.split('Thanks,').length - 1, 1);
  assert.deepEqual(t.problems, []);
  await t.context.close();
});

test('a refilled form after a successful submit still validates normally', async () => {
  const t = await openVisit();
  const { page } = t;
  await fillForm(page);
  await submit(page);
  await fillForm(page, { email: 'a@b' });
  await submit(page);
  assert.equal(await page.locator('#contact-email').getAttribute('aria-invalid'), 'true');
  assert.match(await page.locator('#contact-email-error').textContent(), /name@example\.com/);
  assert.equal(await page.locator('#contact-status').textContent(), '');
  assert.deepEqual(t.problems, []);
  await t.context.close();
});

test('typing into a field after a success returns the empty form to normal validation', async () => {
  const t = await openVisit();
  const { page } = t;
  await fillForm(page);
  await submit(page);
  await page.fill('#contact-name', 'B');
  await page.fill('#contact-name', '');
  await submit(page);
  assert.equal(await page.locator('#contact-name').getAttribute('aria-invalid'), 'true');
  assert.equal(await page.evaluate(() => document.activeElement.id), 'contact-name');
  assert.equal(await page.locator('#contact-status').textContent(), '');
  await t.context.close();
});

test('a second successful submit clears and sets the status again', async () => {
  const t = await openVisit();
  const { page } = t;
  await fillForm(page);
  await submit(page);
  const before = t.requests.length;
  await page.evaluate(() => {
    window.statusMutations = 0;
    new MutationObserver(() => { window.statusMutations += 1; })
      .observe(document.getElementById('contact-status'), { childList: true, characterData: true, subtree: true });
  });
  await fillForm(page, { name: 'Grace Hopper' });
  await submit(page);
  assert.ok(await page.evaluate(() => window.statusMutations) >= 1, 'status element was updated');
  assert.match(await page.locator('#contact-status').textContent(), /Thanks, Grace Hopper/);
  assert.equal(t.requests.length, before, 'no network request is made');
  await t.context.close();
});

test('accessibility copy does not send wheelchair users up stairs to the reading room', async () => {
  const t = await openVisit();
  const text = await t.page.locator('#access-heading').evaluate((heading) =>
    heading.parentElement.textContent.replace(/\s+/g, ' ').trim(),
  );
  assert.match(text, /step-free/);
  assert.doesNotMatch(text, /stairs to the reading room/i);
  assert.match(text, /reading room is on the ground floor|lift to the reading room/i);
  await t.context.close();
});

test('the form layout stays within 360px and the email link does not overflow', async () => {
  const t = await openVisit({ width: 360, height: 800 });
  const { page } = t;
  const email = await page.locator('a[href^="mailto:"]').first().boundingBox();
  assert.ok(email.x + email.width <= 360, 'email link fits the viewport');
  await t.context.close();
});

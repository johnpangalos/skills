'use strict';

const fs = require('node:fs');
const http = require('node:http');
const path = require('node:path');
const { chromium } = require('playwright');

const ROOT = path.resolve(__dirname, '..');
const MIME = {
  '.html': 'text/html; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.js': 'text/javascript; charset=utf-8',
  '.svg': 'image/svg+xml',
  '.md': 'text/markdown; charset=utf-8',
};

function resolveFile(urlPath) {
  const relative = urlPath === '/' ? 'index.html' : urlPath.slice(1);
  const file = path.resolve(ROOT, relative);
  if (!file.startsWith(ROOT + path.sep)) return null;
  if (!fs.existsSync(file) || fs.statSync(file).isDirectory()) return null;
  return file;
}

// Serves the repository root on a free local port.
function startSite() {
  const server = http.createServer((req, res) => {
    let urlPath;
    try {
      urlPath = decodeURIComponent(new URL(req.url, 'http://localhost').pathname);
    } catch (error) {
      res.writeHead(400);
      res.end();
      return;
    }
    const file = resolveFile(urlPath);
    if (!file) {
      res.writeHead(404, { 'Content-Type': 'text/plain' });
      res.end('Not found');
      return;
    }
    res.writeHead(200, { 'Content-Type': MIME[path.extname(file)] || 'application/octet-stream' });
    fs.createReadStream(file).pipe(res);
  });
  return new Promise((resolve, reject) => {
    server.once('error', reject);
    server.listen(0, '127.0.0.1', () => {
      const { port } = server.address();
      resolve({
        origin: `http://127.0.0.1:${port}`,
        close: () => new Promise((done) => server.close(done)),
      });
    });
  });
}

// Tries the bundled Chromium first, then the system Chrome.
async function launchBrowser() {
  try {
    return await chromium.launch({ headless: true });
  } catch (error) {
    return chromium.launch({ headless: true, executablePath: '/usr/bin/google-chrome' });
  }
}

const contexts = [];

// Opens a page on the local site and records everything the page does.
async function openSite(browser, origin, file, width = 1280) {
  const context = await browser.newContext({ viewport: { width, height: 900 } });
  contexts.push(context);
  const page = await context.newPage();
  const log = { requests: [], failed: [], consoleErrors: [], pageErrors: [], dialogs: [] };
  page.on('request', (request) => log.requests.push(request.url()));
  page.on('response', (response) => {
    if (response.status() >= 400) log.failed.push(`${response.status()} ${response.url()}`);
  });
  page.on('console', (message) => {
    if (message.type() === 'error') log.consoleErrors.push(message.text());
  });
  page.on('pageerror', (error) => log.pageErrors.push(error.message));
  page.on('dialog', (dialog) => {
    log.dialogs.push(dialog.message());
    dialog.dismiss();
  });
  const response = await page.goto(`${origin}/${file}`);
  if (response.status() !== 200) throw new Error(`${file} answered ${response.status()}`);
  return { page, log };
}

async function closeContexts() {
  while (contexts.length) await contexts.pop().close();
}

module.exports = { startSite, launchBrowser, openSite, closeContexts };

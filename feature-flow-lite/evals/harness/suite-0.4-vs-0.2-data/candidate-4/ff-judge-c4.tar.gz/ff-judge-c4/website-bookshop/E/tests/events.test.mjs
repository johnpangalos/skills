// Criterion 7: upcoming events, machine-readable dates, honest attendance notes.
import assert from 'node:assert/strict';

const NOW_UTC = Date.UTC(2026, 10, 17);

export const tests = [
  {
    name: 'criterion 7: at least four upcoming events, each with title, time element, description and attendance note',
    async run(ctx) {
      const { page } = await ctx.open();
      await page.goto(ctx.url('events.html'));
      const events = await page.$$eval('main article', (items) => items.map((item) => ({
        title: item.querySelector('h2')?.textContent.trim() ?? '',
        datetime: item.querySelector('time')?.getAttribute('datetime') ?? '',
        shown: item.querySelector('time')?.textContent.trim() ?? '',
        description: item.querySelector('.event-description')?.textContent.trim() ?? '',
        attend: item.querySelector('.event-attend')?.textContent.trim() ?? '',
      })));
      assert.ok(events.length >= 4, `expected at least 4 events, found ${events.length}`);
      for (const event of events) {
        assert.ok(event.title, 'event title');
        assert.ok(event.shown, `time text for "${event.title}"`);
        assert.match(event.datetime, /^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}$/, `datetime for "${event.title}"`);
        const when = Date.parse(`${event.datetime}:00Z`);
        assert.ok(when >= NOW_UTC + 24 * 3600 * 1000, `"${event.title}" must be after 2026-11-17`);
        assert.ok(event.description.length > 40, `description for "${event.title}"`);
        assert.match(event.attend, /RSVP|attend|reserve|walk in|free/i, `attendance note for "${event.title}"`);
      }
    },
  },
  {
    name: 'criterion 7: the events page never claims an RSVP was received and has no RSVP form',
    async run(ctx) {
      const { page } = await ctx.open();
      await page.goto(ctx.url('events.html'));
      const text = await page.locator('body').innerText();
      assert.doesNotMatch(text, /you('re| are) (booked|registered|confirmed)|rsvp (received|confirmed|saved)|reservation (is )?confirmed|we('ve| have) (received|saved) your/i);
      assert.equal(await page.locator('form').count(), 0, 'no form that could pretend to take RSVPs');
    },
  },
];

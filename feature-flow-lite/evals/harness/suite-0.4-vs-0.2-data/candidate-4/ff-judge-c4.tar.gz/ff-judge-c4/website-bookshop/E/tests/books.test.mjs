// Criterion 6 (books catalog and genre filter) and the filtered-list triggered check.
import assert from 'node:assert/strict';

const TOTAL = 14;

async function readState(page) {
  return page.evaluate(() => ({
    value: document.getElementById('genre-filter').value,
    param: new URL(location.href).searchParams.get('genre'),
    visibleGenres: Array.from(document.querySelectorAll('.book-list > li'))
      .filter((li) => !li.hidden)
      .map((li) => li.dataset.genre),
    count: document.getElementById('result-count').textContent,
    emptyVisible: !document.getElementById('empty-state').hidden,
  }));
}

// genre is '' for All. Checks control, URL, visible list and count all agree.
async function expectState(page, genre, shown) {
  const state = await readState(page);
  assert.equal(state.value, genre, 'select shows the effective genre');
  assert.equal(state.param, genre === '' ? null : genre, 'URL genre parameter');
  assert.equal(state.visibleGenres.length, shown, 'visible book count');
  if (genre !== '') assert.ok(state.visibleGenres.every((g) => g === genre), 'only matching books visible');
  assert.equal(state.count, `Showing ${shown} of ${TOTAL} books`, 'result count');
  return state;
}

export const tests = [
  {
    name: 'criterion 6: catalog has at least 12 titles across at least 5 genres, some genres with several titles',
    async run(ctx) {
      const { page } = await ctx.open();
      await page.goto(ctx.url('books.html'));
      const books = await page.$$eval('.book-list > li[data-genre]', (items) => items.map((li) => ({
        genre: li.dataset.genre,
        title: li.querySelector('h2')?.textContent.trim() ?? '',
        author: li.querySelector('.book-author')?.textContent.trim() ?? '',
        description: li.querySelector('.book-description')?.textContent.trim() ?? '',
        price: li.querySelector('.book-price')?.textContent.trim() ?? '',
        genreLabel: li.querySelector('.book-genre')?.textContent.trim() ?? '',
      })));
      assert.equal(books.length, TOTAL);
      assert.ok(books.length >= 12);
      for (const book of books) {
        assert.ok(book.title && book.author && book.description, `book "${book.title}" needs title, author and description`);
        assert.match(book.price, /^\$\d+\.\d{2}$/, `price for "${book.title}"`);
        assert.equal(book.genreLabel, book.genre, 'genre shown matches data genre');
      }
      assert.equal(new Set(books.map((b) => b.title)).size, books.length, 'titles unique');
      const counts = {};
      for (const book of books) counts[book.genre] = (counts[book.genre] ?? 0) + 1;
      assert.ok(Object.keys(counts).length >= 5, 'at least five genres');
      assert.ok(Object.values(counts).some((n) => n >= 2), 'some genre has several titles');
    },
  },
  {
    name: 'criterion 6: the genre filter is a labelled select with an All option and one option per genre',
    async run(ctx) {
      const { page } = await ctx.open();
      await page.goto(ctx.url('books.html'));
      const select = page.getByLabel('Genre', { exact: true });
      assert.equal(await select.evaluate((el) => el.tagName), 'SELECT');
      const options = await select.evaluate((el) => Array.from(el.options).map((o) => [o.value, o.textContent]));
      assert.deepEqual(options[0], ['', 'All genres']);
      assert.deepEqual(options.slice(1).map(([v]) => v), ['Cookery', 'Literary Fiction', 'Mystery', 'Nature & Place', 'Science Fiction']);
    },
  },
  {
    name: 'criterion 6: choosing a genre shows only its books and updates the count in a polite live region',
    async run(ctx) {
      const { page } = await ctx.open();
      await page.goto(ctx.url('books.html'));
      await expectState(page, '', TOTAL);
      assert.equal(await page.locator('#result-count').getAttribute('aria-live'), 'polite');
      await page.selectOption('#genre-filter', 'Mystery');
      await expectState(page, 'Mystery', 4);
      assert.equal(await page.locator('#result-count').textContent(), 'Showing 4 of 14 books');
    },
  },
  {
    name: 'criterion 6: the selected genre is written to the URL, restored on reload, and restored by back and forward',
    async run(ctx) {
      const { page } = await ctx.open();
      await page.goto(ctx.url('books.html'));
      await page.selectOption('#genre-filter', 'Mystery');
      await page.selectOption('#genre-filter', 'Cookery');
      await expectState(page, 'Cookery', 2);
      await page.goBack();
      await expectState(page, 'Mystery', 4);
      await page.goForward();
      await expectState(page, 'Cookery', 2);
      await page.reload();
      await expectState(page, 'Cookery', 2);
    },
  },
  {
    name: 'criterion 6 hostile: an unknown genre in the URL is treated as All without an error',
    async run(ctx) {
      const { page, errors } = await ctx.open();
      await page.goto(ctx.url('books.html?genre=unknown-value'));
      await expectState(page, '', TOTAL);
      assert.deepEqual(errors, []);
    },
  },
  {
    name: 'criterion 6 hostile: an empty genre parameter is treated as All',
    async run(ctx) {
      const { page, errors } = await ctx.open();
      await page.goto(ctx.url('books.html?genre='));
      await expectState(page, '', TOTAL);
      assert.deepEqual(errors, []);
    },
  },
  {
    name: 'criterion 6 hostile: a genre in the wrong case is matched and the URL is normalised',
    async run(ctx) {
      const { page } = await ctx.open();
      await page.goto(ctx.url('books.html?genre=MYSTERY'));
      await expectState(page, 'Mystery', 4);
    },
  },
  {
    name: 'criterion 6 hostile: a script tag in the genre parameter is inert and treated as All',
    async run(ctx) {
      const { page, dialogs, errors } = await ctx.open();
      const payload = encodeURIComponent('<script>alert(1)</script>');
      await page.goto(ctx.url(`books.html?genre=${payload}`));
      await expectState(page, '', TOTAL);
      assert.deepEqual(dialogs, [], 'no alert should fire');
      assert.deepEqual(errors, []);
      assert.equal(await page.evaluate(() => document.body.innerHTML.includes('<script>alert')), false);
    },
  },
  {
    name: 'criterion 6 hostile: genres with spaces and punctuation round-trip through the URL',
    async run(ctx) {
      const { page } = await ctx.open();
      await page.goto(ctx.url('books.html'));
      await page.selectOption('#genre-filter', 'Science Fiction');
      const param = await page.evaluate(() => new URL(location.href).searchParams.get('genre'));
      assert.equal(param, 'Science Fiction');
      await page.reload();
      await expectState(page, 'Science Fiction', 3);
      await page.selectOption('#genre-filter', 'Nature & Place');
      await page.reload();
      await expectState(page, 'Nature & Place', 2);
      await page.goto(ctx.url('books.html?genre=Science%20Fiction'));
      await expectState(page, 'Science Fiction', 3);
    },
  },
  {
    name: 'criterion 6 hostile: a genre with zero books shows the empty-state message',
    async run(ctx) {
      const { page, errors } = await ctx.open();
      await page.goto(ctx.url('books.html'));
      await page.evaluate(() => document.getElementById('genre-filter').add(new Option('Poetry', 'Poetry')));
      await page.selectOption('#genre-filter', 'Poetry');
      const state = await expectState(page, 'Poetry', 0);
      assert.equal(state.emptyVisible, true, 'empty-state message shown');
      assert.ok((await page.locator('#empty-state').textContent()).includes('No books'));
      assert.deepEqual(errors, []);
    },
  },
  {
    name: 'triggered filtered list: changing the filter while viewing keeps control, URL and results in sync; All restores everything',
    async run(ctx) {
      const { page } = await ctx.open();
      await page.goto(ctx.url('books.html?genre=Mystery'));
      await expectState(page, 'Mystery', 4);
      await page.selectOption('#genre-filter', 'Literary Fiction');
      await expectState(page, 'Literary Fiction', 3);
      await page.selectOption('#genre-filter', '');
      await expectState(page, '', TOTAL);
      await page.goBack();
      await expectState(page, 'Literary Fiction', 3);
    },
  },
  {
    name: 'triggered filtered list: the genre select works from the keyboard and updates list and URL',
    async run(ctx) {
      const { page } = await ctx.open();
      await page.goto(ctx.url('books.html'));
      for (let i = 0; i < 30; i += 1) {
        if (await page.evaluate(() => document.activeElement.id === 'genre-filter')) break;
        await page.keyboard.press('Tab');
      }
      assert.equal(await page.evaluate(() => document.activeElement.id), 'genre-filter', 'select reached by Tab');
      await page.keyboard.press('ArrowDown');
      await expectState(page, 'Cookery', 2);
      await page.keyboard.press('ArrowUp');
      await expectState(page, '', TOTAL);
    },
  },
  {
    name: 'finding 3: with JavaScript off the genre options are in the HTML and match the catalog genres exactly',
    async run(ctx) {
      const { page } = await ctx.open({ javaScriptEnabled: false });
      await page.goto(ctx.url('books.html'));
      const options = await page.$$eval('#genre-filter option', (opts) => opts.map((o) => [o.value, o.textContent.trim()]));
      assert.deepEqual(options[0], ['', 'All genres']);
      const catalog = await page.$$eval('.book-list > li[data-genre]', (items) => items.map((li) => li.dataset.genre));
      const genres = [...new Set(catalog)].sort();
      assert.deepEqual(options.slice(1).map(([value]) => value), genres, 'option values match the catalog genres');
      assert.deepEqual(options.slice(1).map(([, label]) => label), genres, 'option labels match the catalog genres');
    },
  },
];

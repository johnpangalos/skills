'use strict';

const { test } = require('node:test');
const assert = require('node:assert/strict');
const { setupSuite, openTracked, visit } = require('./helpers');

const suite = setupSuite();

test('hero introduces Marginalia Books with a real description', async () => {
  const t = await openTracked(suite);
  await visit(t, `${suite.base}/index.html`);
  const hero = t.page.locator('main section.hero');
  assert.equal(await hero.count(), 1);
  assert.equal(await hero.locator('h1').textContent(), 'Marginalia Books');
  const lead = (await hero.locator('p').first().textContent()).trim();
  assert.ok(lead.length >= 80, `hero paragraph is ${lead.length} characters`);
  await t.context.close();
});

test('at least two further sections with real copy, each with a heading and links to other pages', async () => {
  const t = await openTracked(suite);
  await visit(t, `${suite.base}/index.html`);
  const sections = await t.page.$$eval('main section:not(.hero)', (nodes) =>
    nodes.map((node) => ({
      heading: node.querySelector('h2')?.textContent.trim(),
      text: node.textContent.replace(/\s+/g, ' ').trim(),
    })),
  );
  assert.ok(sections.length >= 2, `expected 2+ sections, got ${sections.length}`);
  for (const section of sections) {
    assert.ok(section.heading, 'section has a heading');
    assert.ok(section.text.length >= 150, `${section.heading} has ${section.text.length} characters`);
  }
  const hrefs = await t.page.$$eval('main a[href]', (anchors) => anchors.map((anchor) => anchor.getAttribute('href')));
  for (const target of ['books.html', 'events.html', 'visit.html']) {
    assert.ok(hrefs.includes(target), `home links to ${target}`);
  }
  assert.doesNotMatch(await t.page.locator('main').textContent(), /lorem ipsum/i);
  assert.deepEqual(t.problems, []);
  await t.context.close();
});

test('staff picks are real titles drawn from the catalogue', async () => {
  const t = await openTracked(suite);
  await visit(t, `${suite.base}/index.html`);
  const picks = await t.page.locator('#staff-picks h3').allTextContents();
  assert.ok(picks.length >= 2, 'at least two staff picks');
  await visit(t, `${suite.base}/books.html`);
  const catalogue = await t.page.evaluate(() => window.BOOKS.map((book) => book.title));
  for (const pick of picks) {
    assert.ok(catalogue.includes(pick.trim()), `${pick} is in the catalogue`);
  }
  await t.context.close();
});

# Marginalia Books

A static website for Marginalia Books, a fictional independent bookshop. It has four pages:
the home page, a catalogue of books with a genre filter, a list of upcoming and past events,
and a visit page with opening hours, the address and a contact form. Every title, author and
event is invented.

The site is plain HTML, CSS and JavaScript. There is no build step and no dependencies, and
it makes no requests beyond its own files.

## Viewing the site

Either open `index.html` directly in a browser, or serve the folder with any static server:

```sh
python3 -m http.server 8000
```

Then open http://localhost:8000/.

## Files

- `index.html`, `books.html`, `events.html`, `visit.html`: the four pages.
- `css/styles.css`: the shared stylesheet for every page.
- `js/books-data.js`: the catalogue, as a JavaScript array on `window.BOOKS`.
- `js/books.js`: builds the genre filter and book cards, and keeps the genre in `?genre=`.
- `js/events-data.js`: the events, as a JavaScript array on `window.EVENTS`.
- `js/events.js`: sorts events into upcoming and past using the visitor's local date.
- `js/contact.js`: validation for the demo contact form on the visit page.
- `favicon.svg`: the site icon.
- `tests/`: the browser tests (see below).

Data is kept in plain script files, not fetched, so the pages also work from `file://`.

## Running the tests

The tests drive the system Chrome through the globally installed Playwright, and start their
own static server from `tests/server.js`.

```sh
NODE_PATH=$(npm root -g) node --test tests/*.test.js
```

Set `PLAYWRIGHT_CHROME` to use a different Chrome binary. The default is `/usr/bin/google-chrome`.

'use strict';

// Shared headless-browser helpers for the test suite. Playwright comes from the global
// install (NODE_PATH) and drives the system Chrome.

const { before, after } = require('node:test');
const { chromium } = require('playwright');
const { startServer } = require('./server');

const PAGES = ['index.html', 'books.html', 'events.html', 'visit.html'];

// Starts one browser and one static server for a test file. Call at the top of the file.
function setupSuite() {
  const suite = {};
  before(async () => {
    suite.browser = await chromium.launch({
      executablePath: process.env.PLAYWRIGHT_CHROME || '/usr/bin/google-chrome',
    });
    suite.server = await startServer();
    suite.base = suite.server.url;
  });
  after(async () => {
    await suite.browser.close();
    await suite.server.close();
  });
  return suite;
}

// Requests that stay on the local origin (or are non-network schemes) are allowed.
function isAllowedRequest(url, origin) {
  if (/^(data|file|about|blob):/.test(url)) return true;
  return Boolean(origin) && new URL(url).origin === origin;
}

// Opens a fresh page and records everything a user would notice going wrong: console
// errors, uncaught page errors, failed or 4xx/5xx responses, requests off the origin,
// and any dialog (alert/confirm). Every request is kept in `requests`.
async function openTracked(suite, options = {}) {
  const context = await suite.browser.newContext({
    viewport: options.viewport || { width: 1280, height: 900 },
    timezoneId: options.timezoneId,
    reducedMotion: options.reducedMotion || 'no-preference',
  });
  const page = await context.newPage();
  if (options.now) await page.clock.setFixedTime(options.now);

  const problems = [];
  const dialogs = [];
  const requests = [];
  const origin = options.origin === undefined ? suite.base : options.origin;

  page.on('console', (message) => {
    if (message.type() === 'error') problems.push(`console: ${message.text()}`);
  });
  page.on('pageerror', (error) => problems.push(`pageerror: ${error.message}`));
  page.on('requestfailed', (request) => problems.push(`requestfailed: ${request.url()}`));
  page.on('response', (response) => {
    if (response.status() >= 400) problems.push(`${response.status()}: ${response.url()}`);
  });
  page.on('request', (request) => {
    requests.push(request.url());
    if (!isAllowedRequest(request.url(), origin)) problems.push(`offsite: ${request.url()}`);
  });
  page.on('dialog', (dialog) => {
    dialogs.push(dialog.message());
    dialog.dismiss();
  });

  return { context, page, problems, dialogs, requests };
}

// Navigates and waits for the page to finish loading.
async function visit(t, url) {
  await t.page.goto(url, { waitUntil: 'load' });
  return t.page;
}

module.exports = { setupSuite, openTracked, visit, PAGES };

// Events page. Splits window.EVENTS into upcoming and past using the visitor's local date.
// Dates are compared as YYYY-MM-DD strings built from local calendar fields, so there is no
// UTC parsing and an event dated today is upcoming for the whole local day.
(function () {
  'use strict';

  const events = (window.EVENTS || []).slice().sort((a, b) =>
    (a.date + a.time).localeCompare(b.date + b.time),
  );
  const upcomingList = document.getElementById('upcoming-list');
  const upcomingEmpty = document.getElementById('upcoming-empty');
  const pastSection = document.getElementById('past-section');
  const pastList = document.getElementById('past-list');

  const WEEKDAYS = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
  const MONTHS = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August',
    'September', 'October', 'November', 'December'];

  function pad(number) {
    return String(number).padStart(2, '0');
  }

  function todayKey(now) {
    return [now.getFullYear(), pad(now.getMonth() + 1), pad(now.getDate())].join('-');
  }

  function localDate(key) {
    const [year, month, day] = key.split('-').map(Number);
    return new Date(year, month - 1, day);
  }

  function formatWhen(event) {
    const date = localDate(event.date);
    const [hours, minutes] = event.time.split(':').map(Number);
    const period = hours >= 12 ? 'pm' : 'am';
    const clock = (hours % 12 || 12) + (minutes ? ':' + pad(minutes) : '') + period;
    return `${WEEKDAYS[date.getDay()]} ${date.getDate()} ${MONTHS[date.getMonth()]} ${date.getFullYear()}, ${clock}`;
  }

  function eventItem(event) {
    const item = document.createElement('li');
    item.className = 'event';

    const name = document.createElement('h3');
    name.textContent = event.name;
    item.appendChild(name);

    const when = document.createElement('p');
    when.className = 'event-when';
    const time = document.createElement('time');
    time.setAttribute('datetime', `${event.date}T${event.time}`);
    time.textContent = formatWhen(event);
    when.appendChild(time);
    item.appendChild(when);

    const admission = document.createElement('p');
    admission.className = 'event-admission';
    admission.textContent = event.admission;
    item.appendChild(admission);

    const description = document.createElement('p');
    description.className = 'event-description';
    description.textContent = event.description;
    item.appendChild(description);
    return item;
  }

  function init() {
    const today = todayKey(new Date());
    const upcoming = events.filter((event) => event.date >= today);
    const past = events.filter((event) => event.date < today);

    upcoming.forEach((event) => upcomingList.appendChild(eventItem(event)));
    past.forEach((event) => pastList.appendChild(eventItem(event)));
    upcomingEmpty.hidden = upcoming.length > 0;
    pastSection.hidden = past.length === 0;
  }

  init();
})();

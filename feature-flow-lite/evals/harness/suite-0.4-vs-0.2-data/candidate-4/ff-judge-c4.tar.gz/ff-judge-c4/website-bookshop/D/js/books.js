// Catalogue page. Builds the genre filter and the book cards from window.BOOKS, and keeps
// the chosen genre in the ?genre= query string. Text is always set with textContent, so
// nothing read from the URL or the data is ever parsed as HTML.
(function () {
  'use strict';

  const books = window.BOOKS || [];
  const genres = uniqueGenres(books);
  const optionsGroup = document.getElementById('genre-options');
  const list = document.getElementById('book-list');
  const countText = document.getElementById('results-count');
  const emptyMessage = document.getElementById('empty-message');

  function uniqueGenres(items) {
    return [...new Set(items.map((book) => book.genre))];
  }

  function slugify(genre) {
    return genre.toLowerCase().replace(/\s+/g, '-');
  }

  function makeElement(tag, className, text) {
    const element = document.createElement(tag);
    if (className) element.className = className;
    if (text !== undefined) element.textContent = text;
    return element;
  }

  function formatPrice(price) {
    return '£' + price.toFixed(2);
  }

  function bookCard(book) {
    const item = makeElement('li', 'book-card');
    item.dataset.genre = slugify(book.genre);
    item.appendChild(makeElement('h2', 'book-title', book.title));
    item.appendChild(makeElement('p', 'book-author', 'by ' + book.author));
    const meta = makeElement('p', 'book-meta');
    meta.appendChild(makeElement('span', 'book-genre', book.genre));
    meta.appendChild(document.createTextNode(' · '));
    meta.appendChild(makeElement('span', 'book-price', formatPrice(book.price)));
    item.appendChild(meta);
    item.appendChild(makeElement('p', 'book-blurb', book.blurb));
    return item;
  }

  function genreOption(value, label, checked) {
    const wrapper = makeElement('label', 'filter-option');
    wrapper.htmlFor = 'genre-' + value;
    const input = document.createElement('input');
    input.type = 'radio';
    input.name = 'genre';
    input.id = 'genre-' + value;
    input.value = value;
    input.checked = checked;
    wrapper.appendChild(input);
    wrapper.appendChild(document.createTextNode(label));
    return wrapper;
  }

  // Returns the genre named by ?genre=, or null for All. Only a single value that matches a
  // genre once slugified (so "Literary Fiction", "literary+fiction" and "literary-fiction" all
  // match, ignoring case and surrounding spaces) counts; anything else means All.
  function genreFromUrl() {
    const values = new URLSearchParams(window.location.search).getAll('genre');
    if (values.length !== 1) return null;
    const wanted = slugify(values[0].trim());
    return genres.find((genre) => slugify(genre) === wanted) || null;
  }

  function writeUrl(genre) {
    const params = new URLSearchParams(window.location.search);
    params.delete('genre');
    if (genre) params.set('genre', slugify(genre));
    const query = params.toString();
    history.replaceState(null, '', window.location.pathname + (query ? '?' + query : '') + window.location.hash);
  }

  function applyFilter(genre) {
    const slug = genre ? slugify(genre) : null;
    const cards = Array.from(list.children);
    let shown = 0;
    cards.forEach((card) => {
      const visible = !slug || card.dataset.genre === slug;
      card.hidden = !visible;
      if (visible) shown += 1;
    });
    countText.textContent = `Showing ${shown} of ${cards.length} books` + (genre ? ` in ${genre}` : '');
    emptyMessage.hidden = shown > 0;
    writeUrl(genre);
  }

  function init() {
    const selected = genreFromUrl();
    optionsGroup.appendChild(genreOption('all', 'All', selected === null));
    genres.forEach((genre) => optionsGroup.appendChild(genreOption(slugify(genre), genre, genre === selected)));
    books.forEach((book) => list.appendChild(bookCard(book)));
    optionsGroup.addEventListener('change', (event) => {
      const chosen = genres.find((genre) => slugify(genre) === event.target.value) || null;
      applyFilter(chosen);
    });
    applyFilter(selected);
  }

  init();
})();

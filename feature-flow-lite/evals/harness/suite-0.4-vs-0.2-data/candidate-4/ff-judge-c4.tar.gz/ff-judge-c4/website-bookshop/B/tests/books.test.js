'use strict';

const { test, before, after } = require('node:test');
const assert = require('node:assert/strict');
const { startSite, launchBrowser, openSite, closeContexts } = require('./helpers');

let site;
let browser;

before(async () => {
  site = await startSite();
  browser = await launchBrowser();
});

after(async () => {
  await closeContexts();
  await browser.close();
  await site.close();
});

const renderedTitles = (page) => page.$$eval('#book-list > li h2', (headings) => headings.map((h) => h.textContent.trim()));
const expectedTitles = (books, genre) => books
  .filter((book) => book.genre === genre)
  .map((book) => book.title);
const allTitles = (books) => books.map((book) => book.title);
const waitForCount = (page, count) => page.waitForFunction(
  (n) => document.querySelectorAll('#book-list > li').length === n,
  count,
);
const checkedGenre = (page) => page.$eval('input[name="genre"]:checked', (input) => input.value);

// Criterion 4: catalog data and rendering.
test('catalog has at least 12 books across 5 genres with 2+ titles each, rendered from js/books.js (criterion 4)', async () => {
  const { page, log } = await openSite(browser, site.origin, 'books.html');
  const books = await page.evaluate(() => window.MARGINALIA_BOOKS);
  assert.ok(books.length >= 12, `books: ${books.length}`);
  const counts = {};
  for (const book of books) {
    for (const field of ['title', 'author', 'genre', 'description']) {
      assert.ok(typeof book[field] === 'string' && book[field].trim().length > 0, `${book.title} ${field}`);
    }
    assert.match(book.price, /^\$\d+\.\d{2}$/, `${book.title} price`);
    counts[book.genre] = (counts[book.genre] || 0) + 1;
  }
  assert.ok(Object.keys(counts).length >= 5, 'at least 5 genres');
  for (const [genre, count] of Object.entries(counts)) assert.ok(count >= 2, `${genre} has ${count}`);
  const rendered = await page.$$eval('#book-list > li', (items) => items.map((li) => ({
    title: li.querySelector('h2').textContent.trim(),
    text: li.textContent,
  })));
  assert.equal(rendered.length, books.length);
  books.forEach((book, i) => {
    assert.equal(rendered[i].title, book.title);
    for (const field of ['author', 'genre', 'description', 'price']) {
      assert.ok(rendered[i].text.includes(book[field]), `${book.title} shows ${field}`);
    }
  });
  assert.deepEqual(log.pageErrors, []);
});

// Criterion 5: labelled genre filter.
test('genre filter is a labelled radio group with All genres plus each genre (criterion 5)', async () => {
  const { page } = await openSite(browser, site.origin, 'books.html');
  const books = await page.evaluate(() => window.MARGINALIA_BOOKS);
  const genres = [...new Set(books.map((b) => b.genre))];
  const group = page.getByRole('group', { name: 'Filter by genre' });
  assert.equal(await group.count(), 1);
  const labels = await group.getByRole('radio').evaluateAll((inputs) => inputs.map((input) => input.labels[0].textContent.trim()));
  assert.deepEqual(labels, ['All genres', ...genres]);
});

test('choosing a genre shows exactly its books and All shows everything, announced politely (criterion 5)', async () => {
  const { page } = await openSite(browser, site.origin, 'books.html');
  const books = await page.evaluate(() => window.MARGINALIA_BOOKS);
  const count = page.locator('#result-count');
  assert.equal(await count.getAttribute('aria-live'), 'polite');
  assert.equal(await count.textContent(), `Showing ${books.length} of ${books.length} books`);

  await page.getByRole('radio', { name: 'Mystery', exact: true }).check();
  await waitForCount(page, expectedTitles(books, 'Mystery').length);
  assert.deepEqual(await renderedTitles(page), expectedTitles(books, 'Mystery'));
  assert.equal(await count.textContent(), `Showing ${expectedTitles(books, 'Mystery').length} of ${books.length} books`);

  await page.getByRole('radio', { name: 'All genres', exact: true }).check();
  await waitForCount(page, books.length);
  assert.deepEqual(await renderedTitles(page), allTitles(books));
  assert.equal(await count.textContent(), `Showing ${books.length} of ${books.length} books`);
});

// Criterion 5 keyboard and the triggered selection check: the selected genre is tracked by value.
test('genre filter works by keyboard alone and keeps the selected genre by value (criterion 5, keyboard)', async () => {
  const { page } = await openSite(browser, site.origin, 'books.html');
  const books = await page.evaluate(() => window.MARGINALIA_BOOKS);
  await page.getByRole('radio', { name: 'All genres', exact: true }).focus();
  await page.keyboard.press('ArrowDown');
  const first = books[0].genre;
  assert.equal(await checkedGenre(page), first);
  await waitForCount(page, expectedTitles(books, first).length);
  assert.deepEqual(await renderedTitles(page), expectedTitles(books, first));
  // Clearing the selection with All empties the genre state and the URL.
  await page.keyboard.press('ArrowUp');
  assert.equal(await checkedGenre(page), '');
  await waitForCount(page, books.length);
  assert.equal(new URL(page.url()).searchParams.get('genre'), null);
});

// Criterion 5 hostile inputs and criterion 6 URL state.
test('books.html?genre=mystery loads with Mystery selected and filtered (criterion 5, hostile)', async () => {
  const { page, log } = await openSite(browser, site.origin, 'books.html?genre=mystery');
  const books = await page.evaluate(() => window.MARGINALIA_BOOKS);
  assert.equal(await checkedGenre(page), 'Mystery');
  assert.deepEqual(await renderedTitles(page), expectedTitles(books, 'Mystery'));
  assert.deepEqual(log.pageErrors, []);
});

for (const query of ['?genre=nonexistent', '?genre=', '?genre=%3Cscript%3E']) {
  test(`books.html${query} falls back to All without errors or injected markup (criterion 5, hostile)`, async () => {
    const { page, log } = await openSite(browser, site.origin, `books.html${query}`);
    const books = await page.evaluate(() => window.MARGINALIA_BOOKS);
    assert.equal(await checkedGenre(page), '');
    assert.deepEqual(await renderedTitles(page), allTitles(books));
    assert.equal(await page.locator('#book-list script, main script').count(), 0);
    assert.equal(await page.locator('#book-list img').count(), 0);
    assert.doesNotMatch(await page.locator('main').innerHTML(), /<script>/i);
    assert.deepEqual(log.pageErrors, []);
    assert.deepEqual(log.consoleErrors, []);
  });
}

test('genre names with a space or ampersand round-trip through the URL (criterion 5, hostile)', async () => {
  const { page } = await openSite(browser, site.origin, 'books.html?genre=Science%20Fiction');
  const books = await page.evaluate(() => window.MARGINALIA_BOOKS);
  assert.equal(await checkedGenre(page), 'Science Fiction');
  assert.deepEqual(await renderedTitles(page), expectedTitles(books, 'Science Fiction'));

  await page.getByRole('radio', { name: 'Poetry & Drama', exact: true }).check();
  await waitForCount(page, expectedTitles(books, 'Poetry & Drama').length);
  assert.equal(new URL(page.url()).searchParams.get('genre'), 'Poetry & Drama');

  await page.reload();
  assert.equal(await checkedGenre(page), 'Poetry & Drama');
  assert.deepEqual(await renderedTitles(page), expectedTitles(books, 'Poetry & Drama'));
});

// Criterion 6: filter state in the URL, with pushState and Back.
test('choosing a genre updates the query string and reloading restores it (criterion 6)', async () => {
  const { page } = await openSite(browser, site.origin, 'books.html');
  const books = await page.evaluate(() => window.MARGINALIA_BOOKS);
  await page.getByRole('radio', { name: 'Mystery', exact: true }).check();
  await waitForCount(page, expectedTitles(books, 'Mystery').length);
  assert.equal(new URL(page.url()).searchParams.get('genre'), 'Mystery');
  await page.reload();
  assert.equal(await checkedGenre(page), 'Mystery');
  assert.deepEqual(await renderedTitles(page), expectedTitles(books, 'Mystery'));
});

test('Back restores the previous filter after a pushState change (criterion 6)', async () => {
  const { page } = await openSite(browser, site.origin, 'books.html');
  const books = await page.evaluate(() => window.MARGINALIA_BOOKS);
  await page.getByRole('radio', { name: 'Mystery', exact: true }).check();
  await waitForCount(page, expectedTitles(books, 'Mystery').length);
  await page.getByRole('radio', { name: 'Science Fiction', exact: true }).check();
  await waitForCount(page, expectedTitles(books, 'Science Fiction').length);
  await page.goBack();
  await waitForCount(page, expectedTitles(books, 'Mystery').length);
  assert.equal(await checkedGenre(page), 'Mystery');
  assert.deepEqual(await renderedTitles(page), expectedTitles(books, 'Mystery'));
});

'use strict';

const { test, before, after } = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const { chromium } = require('playwright');
const { startServer, ROOT } = require('./server');

const PAGES = ['index.html', 'books.html', 'events.html', 'visit.html'];

let server;
let browser;

before(async () => {
  server = await startServer();
  browser = await chromium.launch();
});

after(async () => {
  await browser.close();
  await server.close();
});

test('every request each page makes is same-origin, with no console errors, page errors or failed requests', async () => {
  for (const file of PAGES) {
    const page = await browser.newPage();
    const requests = [];
    const problems = [];
    page.on('request', (req) => requests.push(req.url()));
    page.on('requestfailed', (req) => problems.push(`failed: ${req.url()}`));
    page.on('console', (msg) => {
      if (msg.type() === 'error') problems.push(`console: ${msg.text()}`);
    });
    page.on('pageerror', (err) => problems.push(`page error: ${err.message}`));
    await page.goto(`${server.origin}/${file}`);
    await page.waitForLoadState('networkidle');
    const foreign = requests.filter((url) => !url.startsWith(server.origin + '/') && !url.startsWith('data:'));
    assert.deepEqual(foreign, [], `${file} requested other origins`);
    assert.ok(requests.length >= 1, `${file} made requests`);
    assert.deepEqual(problems, [], file);
    await page.close();
  }
});

test('no http(s) URL to another host appears in the HTML, CSS or JS of the site', () => {
  const files = fs.readdirSync(ROOT, { recursive: true })
    .filter((f) => /\.(html|css|js)$/.test(f) && !f.startsWith('tests' + path.sep) && !f.startsWith('node_modules'));
  assert.ok(files.length >= 6, 'site files found');
  const hits = [];
  for (const file of files) {
    const text = fs.readFileSync(path.join(ROOT, file), 'utf8');
    for (const match of text.matchAll(/https?:\/\/[^\s"'<>)]+/g)) hits.push(`${file}: ${match[0]}`);
  }
  assert.deepEqual(hits, []);
});

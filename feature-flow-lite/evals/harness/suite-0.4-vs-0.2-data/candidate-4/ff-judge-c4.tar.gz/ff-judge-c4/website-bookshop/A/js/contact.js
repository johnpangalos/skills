/*
 * Contact form: custom validation with novalidate. Invalid fields get
 * aria-invalid and an aria-describedby error, focus moves to the first one, and
 * the summary is announced. Nothing is sent: this is a demo site, and the
 * confirmation says so.
 */
(function () {
  'use strict';

  var form = document.getElementById('contact-form');
  if (!form) return;

  var summary = document.getElementById('form-summary');
  var result = document.getElementById('form-result');
  var fields = ['name', 'email', 'message'];
  var rules = {
    name: function (value) {
      return value.trim() ? '' : 'Please enter your name.';
    },
    email: function (value) {
      var address = value.trim();
      if (!address) return 'Please enter your email address.';
      return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(address) ? '' : 'Please enter an email address like name@example.com.';
    },
    message: function (value) {
      var text = value.trim();
      if (!text) return 'Please write a message.';
      return text.length >= 10 ? '' : 'Please write at least 10 characters.';
    }
  };

  function field(id) {
    return document.getElementById(id);
  }

  // Sets or clears one field's error. Returns the message, or '' when valid.
  function setError(id, message) {
    var input = field(id);
    document.getElementById(id + '-error').textContent = message;
    if (message) {
      input.setAttribute('aria-invalid', 'true');
      input.setAttribute('aria-describedby', id + '-error');
    } else {
      input.removeAttribute('aria-invalid');
      input.removeAttribute('aria-describedby');
    }
    return message;
  }

  function invalidFields() {
    return fields.filter(function (id) {
      return field(id).getAttribute('aria-invalid') === 'true';
    });
  }

  function summaryText(count) {
    if (count === 0) return '';
    return count === 1 ? 'Please fix 1 field.' : 'Please fix ' + count + ' fields.';
  }

  form.addEventListener('submit', function (event) {
    event.preventDefault();
    var failing = fields.filter(function (id) {
      return setError(id, rules[id](field(id).value));
    });
    summary.textContent = summaryText(failing.length);
    if (failing.length > 0) {
      result.textContent = '';
      field(failing[0]).focus();
      return;
    }
    result.textContent = 'Thanks, ' + field('name').value.trim() + " — this is a demo site, so your message wasn't sent anywhere.";
  });

  fields.forEach(function (id) {
    field(id).addEventListener('input', function () {
      if (field(id).getAttribute('aria-invalid') !== 'true') return;
      setError(id, rules[id](field(id).value));
      summary.textContent = summaryText(invalidFields().length);
    });
  });
})();

'use strict';

const { test, before, after } = require('node:test');
const assert = require('node:assert/strict');
const { chromium } = require('playwright');
const { startServer } = require('./server');

const PAGES = ['index.html', 'books.html', 'events.html', 'visit.html'];
const WIDTHS = [360, 768, 1280];
const CONTENT_SELECTOR = 'main p, main li, main h1, main h2, main h3, main a, main label, main th, main td, main address, nav a, header .brand a, footer p, footer a, main button, .cover';
const INTERACTIVE_SELECTOR = 'a[href], button, input, select, textarea';

let server;
let browser;

before(async () => {
  server = await startServer();
  browser = await chromium.launch();
});

after(async () => {
  await browser.close();
  await server.close();
});

// Parses an rgb()/rgba() computed colour. Returns null for anything else.
function parseColor(value) {
  const match = value && value.match(/rgba?\(([^)]+)\)/);
  if (!match) return null;
  const [r, g, b, a = '1'] = match[1].split(',').map((part) => Number(part.trim()));
  return { r, g, b, a };
}

function luminance({ r, g, b }) {
  const lin = (c) => {
    const s = c / 255;
    return s <= 0.03928 ? s / 12.92 : ((s + 0.055) / 1.055) ** 2.4;
  };
  return 0.2126 * lin(r) + 0.7152 * lin(g) + 0.0722 * lin(b);
}

function contrastRatio(a, b) {
  const [hi, lo] = [luminance(a), luminance(b)].sort((x, y) => y - x);
  return (hi + 0.05) / (lo + 0.05);
}

// First opaque background walking up from the element; white if none is set.
function effectiveBackground(chain) {
  for (const value of chain) {
    const color = parseColor(value);
    if (color && color.a > 0) return color;
  }
  return { r: 255, g: 255, b: 255, a: 1 };
}

function isLargeText(size, weight) {
  return size >= 24 || (size >= 18.66 && weight >= 700);
}

async function openAt(page, file, width) {
  await page.setViewportSize({ width, height: 800 });
  await page.goto(`${server.origin}/${file}`);
  await page.waitForLoadState('load');
}

test('no page scrolls sideways at 360, 768 or 1280 pixels', async () => {
  const page = await browser.newPage();
  for (const file of PAGES) {
    for (const width of WIDTHS) {
      await openAt(page, file, width);
      const { scroll, inner } = await page.evaluate(() => ({
        scroll: document.documentElement.scrollWidth,
        inner: window.innerWidth,
      }));
      assert.ok(scroll <= inner, `${file} at ${width}px: scrollWidth ${scroll} > ${inner}`);
    }
  }
  await page.close();
});

test('body copy is at least 16px at 360px on every page', async () => {
  const page = await browser.newPage();
  for (const file of PAGES) {
    await openAt(page, file, 360);
    await page.waitForSelector('main');
    const sizes = await page.$$eval('main p, main li, main td, main th, main label, main address', (els) =>
      els.filter((el) => el.getClientRects().length > 0).map((el) => ({
        size: parseFloat(getComputedStyle(el).fontSize),
        text: el.textContent.trim().slice(0, 30),
      })),
    );
    assert.ok(sizes.length > 0);
    for (const { size, text } of sizes) assert.ok(size >= 16, `${file}: ${size}px for "${text}"`);
  }
  await page.close();
});

test('nav links, buttons, selects and inputs are at least 44px tall at 360px', async () => {
  const page = await browser.newPage();
  for (const file of PAGES) {
    await openAt(page, file, 360);
    await page.waitForSelector('main');
    const targets = await page.$$eval('nav a, main button, main select, main input, main textarea', (els) =>
      els.filter((el) => el.getClientRects().length > 0).map((el) => ({
        height: el.getBoundingClientRect().height,
        text: (el.textContent || el.id).trim().slice(0, 30),
      })),
    );
    for (const { height, text } of targets) assert.ok(height >= 44, `${file}: "${text}" is ${height}px tall`);
  }
  await page.close();
});

test('body text, links, nav, buttons and labels meet 4.5:1 contrast (3:1 for large text) on every page', async () => {
  const page = await browser.newPage();
  const failures = [];
  let checked = 0;
  for (const file of PAGES) {
    await openAt(page, file, 1280);
    await page.waitForSelector('main');
    const samples = await page.$$eval(CONTENT_SELECTOR, (els) =>
      els.filter((el) => el.getClientRects().length > 0 && el.textContent.trim()).map((el) => {
        const style = getComputedStyle(el);
        const chain = [];
        for (let node = el; node; node = node.parentElement) chain.push(getComputedStyle(node).backgroundColor);
        return {
          text: el.textContent.trim().slice(0, 30),
          color: style.color,
          size: parseFloat(style.fontSize),
          weight: Number(style.fontWeight),
          chain,
        };
      }),
    );
    for (const sample of samples) {
      checked += 1;
      const ratio = contrastRatio(parseColor(sample.color), effectiveBackground(sample.chain));
      const needed = isLargeText(sample.size, sample.weight) ? 3 : 4.5;
      if (ratio < needed) failures.push(`${file} "${sample.text}" ${ratio.toFixed(2)}:1 (needs ${needed})`);
    }
  }
  assert.ok(checked > 50, `only ${checked} text elements checked`);
  assert.deepEqual(failures, []);
  await page.close();
});

test('every keyboard stop has a visible focus outline with at least 3:1 contrast, and every interactive element is reached', async () => {
  const page = await browser.newPage();
  const problems = [];
  for (const file of PAGES) {
    await openAt(page, file, 1280);
    await page.waitForSelector('main');
    await page.evaluate(() => document.activeElement && document.activeElement.blur());
    const stops = [];
    for (let i = 0; i < 80; i += 1) {
      await page.keyboard.press('Tab');
      const stop = await page.evaluate(() => {
        const el = document.activeElement;
        if (!el || el === document.body) return null;
        const style = getComputedStyle(el);
        // The outline is drawn outside the element, so it sits on the surrounding background.
        const chain = [];
        for (let node = el.parentElement; node; node = node.parentElement) chain.push(getComputedStyle(node).backgroundColor);
        return {
          label: (el.id || el.textContent || el.tagName).trim().slice(0, 30),
          outlineStyle: style.outlineStyle,
          outlineWidth: parseFloat(style.outlineWidth),
          outlineColor: style.outlineColor,
          chain,
        };
      });
      if (!stop) break;
      stops.push(stop);
    }
    const expected = await page.evaluate((sel) => [...document.querySelectorAll(sel)].filter((el) => el.getClientRects().length > 0).length, INTERACTIVE_SELECTOR);
    if (stops.length !== expected) problems.push(`${file}: ${stops.length} keyboard stops for ${expected} interactive elements`);
    for (const stop of stops) {
      if (stop.outlineStyle === 'none' || stop.outlineWidth < 2) problems.push(`${file} "${stop.label}" has no focus outline`);
      const ratio = contrastRatio(parseColor(stop.outlineColor), effectiveBackground(stop.chain));
      if (ratio < 3) problems.push(`${file} "${stop.label}" focus outline ${ratio.toFixed(2)}:1`);
    }
  }
  assert.deepEqual(problems, []);
  await page.close();
});

test('decorative SVGs are hidden from assistive tech and images have alt text', async () => {
  const page = await browser.newPage();
  for (const file of PAGES) {
    await openAt(page, file, 1280);
    const problems = await page.evaluate(() => {
      const out = [];
      document.querySelectorAll('svg').forEach((svg) => {
        if (svg.getAttribute('aria-hidden') !== 'true') out.push('svg without aria-hidden');
      });
      document.querySelectorAll('img').forEach((img) => {
        if (!img.hasAttribute('alt')) out.push(`img ${img.src} without alt`);
      });
      return out;
    });
    assert.deepEqual(problems, [], file);
  }
  await page.close();
});

test('prefers-reduced-motion removes button transitions, and normal motion keeps them', async () => {
  const page = await browser.newPage();
  await openAt(page, 'visit.html', 1280);
  const durations = () => page.$$eval('main button', (els) => els.map((el) => getComputedStyle(el).transitionDuration));
  await page.emulateMedia({ reducedMotion: 'no-preference' });
  const normal = await durations();
  assert.ok(normal.length > 0);
  assert.ok(normal.some((d) => d !== '0s'), `expected a transition without reduced motion, got ${normal}`);
  await page.emulateMedia({ reducedMotion: 'reduce' });
  const reduced = await durations();
  assert.ok(reduced.every((d) => d === '0s'), `transitions left under reduced motion: ${reduced}`);
  await page.close();
});

test('book and event cards do not look clickable: no pointer cursor and no hover lift', async () => {
  const page = await browser.newPage();
  for (const [file, selector] of [['books.html', '#book-list > li'], ['events.html', '#event-list > li']]) {
    await openAt(page, file, 1280);
    await page.waitForSelector(selector);
    const card = page.locator(selector).first();
    await card.hover();
    const style = await card.evaluate((el) => {
      const s = getComputedStyle(el);
      return { cursor: s.cursor, transform: s.transform, shadow: s.boxShadow };
    });
    assert.notEqual(style.cursor, 'pointer', `${file} card cursor`);
    assert.equal(style.transform, 'none', `${file} card hover transform`);
    assert.equal(style.shadow, 'none', `${file} card hover shadow`);
  }
  await page.close();
});

// Appends one item to a data script the page loads, so the page renders it through its own code.
async function addFixture(page, script, global, item) {
  await page.route(`**/js/${script}`, async (route) => {
    const response = await route.fetch();
    const body = `${await response.text()}\nwindow.${global}.push(${JSON.stringify(item)});`;
    await route.fulfill({ status: 200, contentType: 'text/javascript', body });
  });
}

test('a 70-character unbroken word in a book or event title does not scroll the page sideways at 360px', async () => {
  const longWord = 'W'.repeat(70);
  const page = await browser.newPage();
  await addFixture(page, 'books-data.js', 'MARGINALIA_BOOKS', {
    title: `Title ${longWord}`, author: 'Long Word', genre: 'Mystery', price: 5, featured: false,
    blurb: 'A fixture book whose title holds one unbroken word, to check the card wraps it.',
  });
  await addFixture(page, 'events-data.js', 'MARGINALIA_EVENTS', {
    title: longWord, start: '2027-01-10T10:00', description: 'A fixture event whose title is one unbroken word, to check the card wraps it.',
    audience: 'everyone',
  });
  for (const file of ['books.html', 'events.html']) {
    await openAt(page, file, 360);
    await page.waitForSelector('main');
    assert.ok(await page.getByText(longWord, { exact: false }).first().count() > 0, `${file} shows the long word`);
    const { scroll, inner } = await page.evaluate(() => ({ scroll: document.documentElement.scrollWidth, inner: window.innerWidth }));
    assert.ok(scroll <= inner, `${file} at 360px: scrollWidth ${scroll} > ${inner}`);
  }
  await page.close();
});

test('with the root font size at 200%, no page scrolls sideways at 360px', async () => {
  const page = await browser.newPage();
  for (const file of PAGES) {
    await openAt(page, file, 360);
    await page.evaluate(() => { document.documentElement.style.fontSize = '200%'; });
    const { scroll, inner } = await page.evaluate(() => ({ scroll: document.documentElement.scrollWidth, inner: window.innerWidth }));
    assert.ok(scroll <= inner, `${file} at 200% root size: scrollWidth ${scroll} > ${inner}`);
  }
  await page.close();
});

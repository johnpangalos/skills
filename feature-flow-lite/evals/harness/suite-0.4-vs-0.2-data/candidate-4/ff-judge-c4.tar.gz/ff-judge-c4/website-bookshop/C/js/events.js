// Events page: lists upcoming events from the events data, with human-readable dates.
(function () {
  'use strict';

  var list = document.getElementById('event-list');
  var dates = window.MarginaliaDates;
  if (!list || !dates) return;

  function createEvent(event) {
    var item = document.createElement('li');
    item.className = 'event';

    var title = document.createElement('h2');
    title.textContent = event.title;

    var when = document.createElement('p');
    when.className = 'event-when';
    var time = document.createElement('time');
    time.dateTime = event.start;
    time.textContent = dates.formatWhen(event.start);
    when.appendChild(time);

    var description = document.createElement('p');
    description.className = 'event-description';
    description.textContent = event.description;

    var audience = document.createElement('p');
    audience.className = 'event-for';
    audience.textContent = 'For: ' + event.audience;

    item.append(title, when, description, audience);
    return item;
  }

  function createNotice() {
    var item = document.createElement('li');
    item.textContent = 'There are no upcoming events at the moment. Please check back soon.';
    return item;
  }

  var events = dates.upcoming(window.MARGINALIA_EVENTS || []);
  list.replaceChildren.apply(list, events.length ? events.map(createEvent) : [createNotice()]);
})();

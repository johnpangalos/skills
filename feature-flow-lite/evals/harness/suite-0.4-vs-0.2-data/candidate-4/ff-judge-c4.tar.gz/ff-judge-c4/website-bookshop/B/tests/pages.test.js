'use strict';

const { test, before, after } = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const { startSite, launchBrowser, openSite, closeContexts } = require('./helpers');

const PAGES = [
  { file: 'index.html', name: 'Home' },
  { file: 'books.html', name: 'Books' },
  { file: 'events.html', name: 'Events' },
  { file: 'visit.html', name: 'Visit' },
];
const NAV_TEXT = ['Home', 'Books', 'Events', 'Visit'];
const NAV_HREF = ['index.html', 'books.html', 'events.html', 'visit.html'];

let site;
let browser;

before(async () => {
  site = await startSite();
  browser = await launchBrowser();
});

after(async () => {
  await closeContexts();
  await browser.close();
  await site.close();
});

// Criterion 1: title, lang, viewport, one h1, landmarks.
for (const { file, name } of PAGES) {
  test(`${file} has a titled, landmarked, lang="en" document (criterion 1)`, async () => {
    const { page } = await openSite(browser, site.origin, file);
    assert.equal(await page.getAttribute('html', 'lang'), 'en');
    const title = await page.title();
    assert.match(title, new RegExp(name));
    assert.match(title, /Marginalia Books/);
    const viewport = await page.getAttribute('meta[name="viewport"]', 'content');
    assert.match(viewport, /width=device-width/);
    assert.equal(await page.locator('h1').count(), 1);
    assert.equal(await page.locator('header').count(), 1);
    assert.equal(await page.locator('nav[aria-label]').count(), 1);
    assert.equal(await page.locator('main').count(), 1);
    assert.equal(await page.locator('footer').count(), 1);
  });

  test(`${file} skip link is the first focusable element and moves focus to main (criterion 1)`, async () => {
    const { page } = await openSite(browser, site.origin, file);
    assert.equal(await page.evaluate(() => document.activeElement.tagName), 'BODY');
    await page.keyboard.press('Tab');
    const first = await page.evaluate(() => ({
      text: document.activeElement.textContent.trim(),
      href: document.activeElement.getAttribute('href'),
    }));
    assert.deepEqual(first, { text: 'Skip to main content', href: '#main' });
    await page.keyboard.press('Enter');
    assert.equal(await page.evaluate(() => document.activeElement.tagName + '#' + document.activeElement.id), 'MAIN#main');
  });
}

// Criterion 2: shared nav, same order, aria-current, links resolve.
test('shared nav has the same four links in order on every page (criterion 2)', async () => {
  const navMarkup = [];
  for (const { file, name } of PAGES) {
    const { page } = await openSite(browser, site.origin, file);
    navMarkup.push(await page.locator('nav[aria-label]').evaluate((nav) => nav.outerHTML.replace(' aria-current="page"', '')));
    const links = await page.$$eval('nav[aria-label] a', (anchors) => anchors.map((a) => ({
      text: a.textContent.trim(),
      href: a.getAttribute('href'),
      current: a.getAttribute('aria-current'),
    })));
    assert.deepEqual(links.map((l) => l.text), NAV_TEXT, `${file} nav text`);
    assert.deepEqual(links.map((l) => l.href), NAV_HREF, `${file} nav hrefs`);
    assert.deepEqual(
      links.filter((l) => l.current !== null).map((l) => [l.text, l.current]),
      [[name, 'page']],
      `${file} aria-current`,
    );
  }
  assert.equal(new Set(navMarkup).size, 1, 'nav markup is identical on every page');
});

test('every internal link and nav link resolves without a 404 (criterion 2)', async () => {
  for (const { file } of PAGES) {
    const { page } = await openSite(browser, site.origin, file);
    const hrefs = await page.$$eval('a[href]', (anchors) => anchors
      .map((a) => a.getAttribute('href'))
      .filter((href) => !/^(https?:|mailto:|tel:|#)/.test(href)));
    for (const href of hrefs) {
      const status = await page.evaluate(async (target) => (await fetch(target)).status, href);
      assert.equal(status, 200, `${file} -> ${href}`);
    }
  }
});

// Criterion 3: home page content.
test('home page has an intro, at least three staff picks and an events teaser (criterion 3)', async () => {
  const { page } = await openSite(browser, site.origin, 'index.html');
  const intro = await page.locator('main p').first().textContent();
  assert.ok(intro.trim().length >= 100, 'intro paragraph is substantive');
  const picks = page.locator('main section[aria-labelledby]').filter({ has: page.getByRole('heading', { name: 'Staff picks' }) });
  assert.equal(await picks.count(), 1);
  assert.ok(await picks.locator('article').count() >= 3, 'at least three staff picks');
  const teaser = page.locator('main a[href="events.html"]');
  assert.ok(await teaser.count() >= 1, 'teaser links to events.html');
  assert.match(await page.locator('main').innerText(), /\b(Dec|December|Jan|January|Feb|February)\b/, 'teaser names a date');
});

// No lorem ipsum anywhere (criterion 3).
test('no lorem ipsum or placeholder text on any page (criterion 3)', async () => {
  for (const { file } of PAGES) {
    const { page } = await openSite(browser, site.origin, file);
    const text = await page.evaluate(() => document.body.innerText);
    assert.doesNotMatch(text, /lorem|ipsum/i, file);
    assert.doesNotMatch(text, /placeholder|TODO|TBD/i, file);
  }
});

// Criterion 13: README with run and test instructions.
test('README.md says what the site is, how to serve it and how to run tests (criterion 13)', () => {
  const readme = fs.readFileSync(path.join(__dirname, '..', 'README.md'), 'utf8');
  assert.match(readme, /Marginalia Books/);
  assert.match(readme, /npx http-server -p 8080 -s \.|python3? -m http\.server|static server/i);
  assert.match(readme, /NODE_PATH=\$\(npm root -g\) node --test tests\//);
});

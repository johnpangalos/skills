/*
 * Catalogue page: renders the books and the genre filter. The filter lives in
 * the ?genre= query string so a result can be bookmarked, shared and restored
 * with back and forward.
 */
(function () {
  'use strict';

  var Marginalia = window.Marginalia;
  var genres = Marginalia.genres(Marginalia.books);
  var optionsBox = document.getElementById('genre-options');
  var list = document.getElementById('book-list');
  var count = document.getElementById('result-count');

  // The first ?genre= value, matched case-insensitively. Anything unknown is All.
  function genreFromUrl() {
    var requested = (new URLSearchParams(window.location.search).get('genre') || '').trim().toLowerCase();
    var known = genres.some(function (genre) {
      return genre.slug === requested;
    });
    return known ? requested : 'all';
  }

  function buildOptions() {
    [{ name: 'All', slug: 'all' }].concat(genres).forEach(function (genre) {
      var wrapper = document.createElement('div');
      wrapper.className = 'genre-option';
      var input = document.createElement('input');
      input.type = 'radio';
      input.name = 'genre';
      input.id = 'genre-' + genre.slug;
      input.value = genre.slug;
      var label = document.createElement('label');
      label.htmlFor = input.id;
      label.textContent = genre.name;
      wrapper.appendChild(input);
      wrapper.appendChild(label);
      optionsBox.appendChild(wrapper);
    });
  }

  function bookCard(book) {
    var item = document.createElement('li');
    item.className = 'book-card';

    var title = document.createElement('h2');
    title.className = 'book-title';
    title.textContent = book.title;

    var author = document.createElement('p');
    author.className = 'book-author';
    author.textContent = 'by ' + book.author;

    var genre = document.createElement('p');
    genre.className = 'book-genre';
    genre.textContent = book.genre;

    var blurb = document.createElement('p');
    blurb.className = 'book-blurb';
    blurb.textContent = book.blurb;

    var price = document.createElement('p');
    price.className = 'book-price';
    price.textContent = '£' + book.price.toFixed(2);

    item.appendChild(title);
    item.appendChild(author);
    item.appendChild(genre);
    item.appendChild(blurb);
    item.appendChild(price);
    return item;
  }

  function render(slug) {
    var shown = Marginalia.books.filter(function (book) {
      return slug === 'all' || Marginalia.genreSlug(book.genre) === slug;
    });
    list.textContent = '';
    shown.forEach(function (book) {
      list.appendChild(bookCard(book));
    });
    document.getElementById('genre-' + slug).checked = true;
    count.textContent = 'Showing ' + shown.length + ' of ' + Marginalia.books.length + ' books';
  }

  // One history entry per real change: arrow keys move through the radios, and
  // choosing the genre the URL already names adds nothing.
  optionsBox.addEventListener('change', function (event) {
    var slug = event.target.value;
    if (slug === genreFromUrl()) return;
    var url = new URL(window.location.href);
    if (slug === 'all') {
      url.searchParams.delete('genre');
    } else {
      url.searchParams.set('genre', slug);
    }
    window.history.pushState({ genre: slug }, '', url.pathname + url.search);
    render(slug);
  });

  // Back and forward restore the control. If focus was on the group, it moves
  // to the radio that is now checked, so it never sits on an unchecked one.
  window.addEventListener('popstate', function () {
    var focusInGroup = optionsBox.contains(document.activeElement);
    var slug = genreFromUrl();
    render(slug);
    if (focusInGroup) document.getElementById('genre-' + slug).focus();
  });

  buildOptions();
  render(genreFromUrl());
})();

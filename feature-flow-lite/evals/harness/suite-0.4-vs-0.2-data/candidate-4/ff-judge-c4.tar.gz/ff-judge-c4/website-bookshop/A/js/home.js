/*
 * Home page: staff picks from the catalogue and the next events, both taken
 * from the shared data.
 */
(function () {
  'use strict';

  var Marginalia = window.Marginalia;

  function featuredItem(book) {
    var item = document.createElement('li');
    item.className = 'featured-item';

    var title = document.createElement('h3');
    title.textContent = book.title;

    var author = document.createElement('p');
    author.textContent = 'by ' + book.author;

    var link = document.createElement('a');
    var slug = Marginalia.genreSlug(book.genre);
    link.href = 'books.html?genre=' + encodeURIComponent(slug);
    link.textContent = 'More ' + book.genre.toLowerCase();

    item.appendChild(title);
    item.appendChild(author);
    item.appendChild(link);
    return item;
  }

  function nextEventItem(event) {
    var item = document.createElement('li');
    var when = document.createElement('time');
    when.setAttribute('datetime', event.date + 'T' + event.start);
    when.textContent = Marginalia.formatDate(event.date) + ', ' + event.start;
    var title = document.createElement('p');
    title.className = 'next-event-title';
    title.textContent = event.title;
    item.appendChild(when);
    item.appendChild(title);
    return item;
  }

  var featured = document.getElementById('featured-list');
  Marginalia.books.filter(function (book) {
    return book.featured;
  }).forEach(function (book) {
    featured.appendChild(featuredItem(book));
  });

  var next = document.getElementById('next-events');
  var today = Marginalia.localDateString(new Date());
  var upcoming = Marginalia.upcomingEvents(today);
  upcoming.slice(0, 2).forEach(function (event) {
    next.appendChild(nextEventItem(event));
  });
  next.hidden = upcoming.length === 0;
  document.getElementById('next-empty').hidden = upcoming.length > 0;

  // "Open Tuesday to Sunday, closed on Mondays." Hours are listed Monday first,
  // so the first and last open days give the range.
  var openDays = Marginalia.hours.filter(function (entry) {
    return entry.open;
  });
  var closedDays = Marginalia.hours.filter(function (entry) {
    return !entry.open;
  });
  document.getElementById('home-open-days').textContent =
    'Open ' + openDays[0].day + ' to ' + openDays[openDays.length - 1].day +
    ', closed on ' + closedDays.map(function (entry) { return entry.day + 's'; }).join(' and ') + '.';
})();

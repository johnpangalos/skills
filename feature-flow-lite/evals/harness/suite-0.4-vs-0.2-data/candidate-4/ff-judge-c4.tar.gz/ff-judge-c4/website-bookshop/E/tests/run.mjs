// Runs every tests/*.test.mjs file whose name contains the optional argument.
// Usage: node tests/run.mjs [file-substring]
import { readdir } from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath, pathToFileURL } from 'node:url';
import { startServer, launchBrowser, makeContext, ROOT } from './helpers.mjs';

const here = path.dirname(fileURLToPath(import.meta.url));
const filter = process.argv[2] ?? '';
const TEST_TIMEOUT_MS = 90000;

const files = (await readdir(here))
  .filter((name) => name.endsWith('.test.mjs') && name.includes(filter))
  .sort();

if (files.length === 0) {
  console.error(`No test files match "${filter}"`);
  process.exit(1);
}

function withTimeout(promise, ms) {
  let timer;
  const timeout = new Promise((_, reject) => {
    timer = setTimeout(() => reject(new Error(`timed out after ${ms} ms`)), ms);
  });
  return Promise.race([promise, timeout]).finally(() => clearTimeout(timer));
}

const server = await startServer(ROOT);
const browser = await launchBrowser();
let passed = 0;
let failed = 0;

try {
  for (const file of files) {
    const { tests } = await import(pathToFileURL(path.join(here, file)).href);
    console.log(`# ${file}`);
    for (const test of tests) {
      const ctx = makeContext(browser, server.baseUrl);
      try {
        await withTimeout(test.run(ctx), TEST_TIMEOUT_MS);
        passed += 1;
        console.log(`ok - ${test.name}`);
      } catch (error) {
        failed += 1;
        const lines = String(error?.message ?? error).split('\n').slice(0, 8);
        console.log(`not ok - ${test.name}\n    ${lines.join('\n    ')}`);
      } finally {
        await Promise.all(ctx.contexts.map((context) => context.close().catch(() => {})));
      }
    }
  }
} finally {
  await browser.close();
  await server.close();
}

console.log(`\n${passed} passed, ${failed} failed`);
process.exit(failed > 0 ? 1 : 0);

'use strict';

const { test, before, after } = require('node:test');
const assert = require('node:assert/strict');
const { chromium } = require('playwright');
const { startServer } = require('./server');

const DAYS = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'];

let server;
let browser;

before(async () => {
  server = await startServer();
  browser = await chromium.launch();
});

after(async () => {
  await browser.close();
  await server.close();
});

async function openVisit() {
  const page = await browser.newPage();
  await page.goto(`${server.origin}/visit.html`);
  return page;
}

test('opening hours table lists every day of the week in order with hours', async () => {
  const page = await openVisit();
  const rows = await page.$$eval('main table tbody tr', (trs) =>
    trs.map((tr) => ({
      day: tr.querySelector('th')?.textContent.trim() || '',
      hours: tr.querySelector('td')?.textContent.trim() || '',
    })),
  );
  assert.deepEqual(rows.map((r) => r.day), DAYS);
  rows.forEach((r) => assert.match(r.hours, /\d/, `hours for ${r.day}`));
  await page.close();
});

test('street address is in an address element', async () => {
  const page = await openVisit();
  const address = page.locator('main address');
  assert.equal(await address.count(), 1);
  assert.match(await address.textContent(), /Lantern Row/);
  await page.close();
});

test('directions and transport notes are present under a Getting here heading', async () => {
  const page = await openVisit();
  const heading = page.getByRole('heading', { name: 'Getting here', level: 2 });
  assert.equal(await heading.count(), 1);
  const text = (await page.locator('main').innerText()).toLowerCase();
  assert.ok(text.includes('by bus'), 'bus notes');
  assert.ok(text.includes('by train'), 'train notes');
  assert.ok(text.includes('by car'), 'car notes');
  await page.close();
});

test('contact form has visible labels for name, email, subject and message, with required fields marked in text', async () => {
  const page = await openVisit();
  for (const name of ['Name', 'Email', 'Subject', 'Message']) {
    assert.equal(await page.getByLabel(name, { exact: false }).count(), 1, name);
  }
  for (const name of ['Name', 'Email', 'Message']) {
    const label = await page.locator(`label[for="${name.toLowerCase()}"]`).textContent();
    assert.match(label, /required/i, `${name} label marks required in text`);
  }
  await page.close();
});

'use strict';

// Node 22 cannot run a bare directory with `node --test tests/`, so this entry
// file loads every suite and the documented command runs the whole set.
require('./a11y.test.js');
require('./books.test.js');
require('./events.test.js');
require('./pages.test.js');
require('./responsive.test.js');
require('./visit.test.js');

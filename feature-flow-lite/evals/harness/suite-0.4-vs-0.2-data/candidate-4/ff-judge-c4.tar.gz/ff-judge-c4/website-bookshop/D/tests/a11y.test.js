'use strict';

const { test } = require('node:test');
const assert = require('node:assert/strict');
const { setupSuite, openTracked, visit, PAGES } = require('./helpers');

const suite = setupSuite();

async function openPage(name, options = {}) {
  const t = await openTracked(suite, options);
  await visit(t, `${suite.base}/${name}`);
  return t;
}

test('every page has lang, a unique descriptive title, one h1, no skipped levels and the landmarks', async () => {
  const titles = new Set();
  for (const name of PAGES) {
    const t = await openPage(name);
    const { page } = t;
    const info = await page.evaluate(() => ({
      lang: document.documentElement.lang,
      title: document.title,
      h1: document.querySelectorAll('h1').length,
      levels: [...document.querySelectorAll('h1,h2,h3,h4,h5,h6')].map((h) => Number(h.tagName[1])),
      header: document.querySelectorAll('body > header, header').length,
      nav: document.querySelectorAll('nav').length,
      main: document.querySelectorAll('main').length,
      footer: document.querySelectorAll('footer').length,
    }));
    assert.equal(info.lang, 'en', name);
    assert.ok(info.title.length >= 10, `${name} title "${info.title}"`);
    assert.equal(titles.has(info.title), false, `${name} title is unique`);
    titles.add(info.title);
    assert.equal(info.h1, 1, `${name} h1 count`);
    assert.equal(info.levels[0], 1, `${name} first heading is h1`);
    for (let i = 1; i < info.levels.length; i += 1) {
      assert.ok(info.levels[i] <= info.levels[i - 1] + 1, `${name} heading level skip at ${i}`);
    }
    assert.ok(info.header >= 1 && info.nav >= 1 && info.main === 1 && info.footer >= 1, `${name} landmarks`);
    assert.deepEqual(t.problems, [], name);
    await t.context.close();
  }
});

test('the skip link is the first tab stop, is visible on focus, and moves focus to main', async () => {
  for (const name of PAGES) {
    const t = await openPage(name);
    const { page } = t;
    await page.keyboard.press('Tab');
    const skip = page.locator('.skip-link');
    assert.equal(await page.evaluate(() => document.activeElement.className), 'skip-link', `${name} first tab stop`);
    assert.equal(await skip.textContent(), 'Skip to main content');
    const box = await skip.boundingBox();
    assert.ok(box.width > 0 && box.x >= 0 && box.y >= 0, `${name} skip link visible on focus`);
    await page.keyboard.press('Enter');
    assert.equal(await page.evaluate(() => document.activeElement.id), 'main', `${name} focus moved to main`);
    await t.context.close();
  }
});

test('every interactive control is reachable by Tab and shows a visible focus outline', async () => {
  for (const name of PAGES) {
    const t = await openPage(name);
    const { page } = t;
    // Check the focus ring at the moment each element receives focus.
    await page.evaluate(() => {
      window.__tabbed = new Set();
      window.__unseen = [];
      document.addEventListener('focusin', (event) => {
        const el = event.target;
        window.__tabbed.add(el);
        const style = getComputedStyle(el);
        if (!el.matches(':focus-visible') || style.outlineStyle === 'none' || parseFloat(style.outlineWidth) === 0) {
          window.__unseen.push(el.outerHTML.slice(0, 60));
        }
      }, true);
    });
    for (let i = 0; i < 120; i += 1) {
      await page.keyboard.press('Tab');
    }
    const result = await page.evaluate(() => {
      const interactive = [...document.querySelectorAll('a[href], button, input:not([type=hidden]), select, textarea')]
        .filter((el) => !el.disabled && el.getClientRects().length > 0)
        .filter((el) => !(el.type === 'radio' && !el.checked && el.name && document.querySelector(`input[name="${el.name}"]:checked`)));
      const unreached = interactive.filter((el) => !window.__tabbed.has(el)).map((el) => el.outerHTML.slice(0, 60));
      return { total: interactive.length, unreached, unseen: window.__unseen };
    });
    assert.ok(result.total > 0, `${name} has interactive controls`);
    assert.deepEqual(result.unreached, [], `${name} unreachable controls`);
    assert.deepEqual(result.unseen, [], `${name} controls without visible focus`);
    await t.context.close();
  }
});

test('the keyboard focus order of the catalogue filter follows the page order', async () => {
  const t = await openPage('books.html');
  const { page } = t;
  // Tab order: skip link, site name, four nav links, then the filter radio group (one stop).
  for (let i = 0; i < 7; i += 1) {
    await page.keyboard.press('Tab');
  }
  const active = await page.evaluate(() => ({ tag: document.activeElement.tagName, name: document.activeElement.name }));
  assert.deepEqual(active, { tag: 'INPUT', name: 'genre' });
  await t.context.close();
});

test('decorative SVG is hidden from assistive technology', async () => {
  for (const name of PAGES) {
    const t = await openPage(name);
    assert.equal(await t.page.locator('main').count(), 1, `${name} rendered`);
    const unlabelled = await t.page.$$eval('svg', (nodes) =>
      nodes.filter((node) => node.getAttribute('aria-hidden') !== 'true' && !node.getAttribute('aria-label') && !node.querySelector('title')).length,
    );
    assert.equal(unlabelled, 0, `${name} svg without aria-hidden or alt text`);
    await t.context.close();
  }
});

test('ids are unique and every aria reference and label for= resolves on every page', async () => {
  for (const name of PAGES) {
    const t = await openPage(name);
    assert.equal(await t.page.locator('main').count(), 1, `${name} rendered`);
    const problems = await t.page.evaluate(() => {
      const found = [];
      const ids = [...document.querySelectorAll('[id]')].map((el) => el.id);
      for (const id of new Set(ids)) {
        if (ids.filter((other) => other === id).length > 1) found.push(`duplicate id ${id}`);
      }
      const refs = [];
      for (const attr of ['aria-controls', 'aria-describedby', 'aria-labelledby', 'aria-owns', 'aria-errormessage']) {
        document.querySelectorAll(`[${attr}]`).forEach((el) => {
          el.getAttribute(attr).split(/\s+/).filter(Boolean).forEach((token) => refs.push(token));
        });
      }
      document.querySelectorAll('label[for]').forEach((label) => refs.push(label.getAttribute('for')));
      document.querySelectorAll('a[href^="#"]').forEach((link) => refs.push(link.getAttribute('href').slice(1)));
      for (const ref of refs) {
        if (!document.getElementById(ref)) found.push(`missing target ${ref}`);
      }
      return found;
    });
    assert.deepEqual(problems, [], name);
    await t.context.close();
  }
});

test('the markup has no duplicate attributes on any element', async () => {
  for (const name of PAGES) {
    const t = await openTracked(suite);
    const response = await t.page.request.get(`${suite.base}/${name}`);
    assert.equal(response.status(), 200, name);
    const html = await response.text();
    assert.ok(html.includes('<main'), `${name} has main`);
    const duplicates = [];
    const tagPattern = /<([a-zA-Z][^\s/>]*)((?:\s+[^\s"'>\/=]+(?:\s*=\s*(?:"[^"]*"|'[^']*'|[^\s"'=<>`]+))?)*)\s*\/?>/g;
    let match;
    while ((match = tagPattern.exec(html))) {
      // Drop attribute values first, so words inside quoted text are not read as attribute names.
      const attributeNames = match[2].replace(/=\s*("[^"]*"|'[^']*'|[^\s"'=<>`]+)/g, '');
      const names = [...attributeNames.matchAll(/[^\s"'>/=]+/g)].map((m) => m[0].toLowerCase());
      const seen = new Set();
      for (const attr of names) {
        if (seen.has(attr)) duplicates.push(`${name}: ${match[1]} ${attr}`);
        seen.add(attr);
      }
    }
    assert.deepEqual(duplicates, []);
    await t.context.close();
  }
});

test('prefers-reduced-motion removes transitions and animations', async () => {
  const normal = await openPage('index.html');
  const normalDurations = await normal.page.locator('header nav a').first().evaluate((a) => getComputedStyle(a).transitionDuration);
  assert.notEqual(normalDurations, '0s', 'normal motion keeps a transition to be removed');
  await normal.context.close();

  const reduced = await openPage('index.html', { reducedMotion: 'reduce' });
  const durations = await reduced.page.evaluate(() => {
    const els = [...document.querySelectorAll('header nav a, .button, .book-card, a')];
    return els.map((el) => [getComputedStyle(el).transitionDuration, getComputedStyle(el).animationDuration]);
  });
  for (const [transition, animation] of durations) {
    assert.equal(transition, '0s');
    assert.ok(animation === '0s' || animation === 'normal' || animation === '0.001s', `animation ${animation}`);
  }
  await reduced.context.close();
});

test('every text colour pair on every page meets 4.5:1, or 3:1 for large text', async () => {
  const failures = [];
  for (const name of PAGES) {
    const t = await openPage(name);
    assert.equal(await t.page.locator('main').count(), 1, `${name} rendered`);
    const results = await t.page.evaluate(() => {
      const parse = (value) => {
        const parts = value.match(/[\d.]+/g).map(Number);
        return { r: parts[0], g: parts[1], b: parts[2], a: parts.length > 3 ? parts[3] : 1 };
      };
      const luminance = ({ r, g, b }) => {
        const channel = (c) => {
          const s = c / 255;
          return s <= 0.03928 ? s / 12.92 : Math.pow((s + 0.055) / 1.055, 2.4);
        };
        return 0.2126 * channel(r) + 0.7152 * channel(g) + 0.0722 * channel(b);
      };
      const backgroundOf = (el) => {
        for (let node = el; node; node = node.parentElement) {
          const bg = parse(getComputedStyle(node).backgroundColor);
          if (bg.a === 1) return bg;
        }
        return { r: 255, g: 255, b: 255, a: 1 };
      };
      const out = [];
      for (const el of document.querySelectorAll('body *')) {
        const hasText = [...el.childNodes].some((n) => n.nodeType === 3 && n.textContent.trim());
        if (!hasText || el.getClientRects().length === 0) continue;
        const style = getComputedStyle(el);
        const fg = parse(style.color);
        const bg = backgroundOf(el);
        const l1 = luminance(fg);
        const l2 = luminance(bg);
        const ratio = (Math.max(l1, l2) + 0.05) / (Math.min(l1, l2) + 0.05);
        const size = parseFloat(style.fontSize);
        const bold = parseInt(style.fontWeight, 10) >= 700;
        const large = size >= 24 || (size >= 18.66 && bold);
        const needed = large ? 3 : 4.5;
        if (ratio < needed) out.push(`${el.tagName.toLowerCase()} "${el.textContent.trim().slice(0, 30)}" ${ratio.toFixed(2)}:1`);
      }
      return out;
    });
    failures.push(...results.map((r) => `${name} ${r}`));
    await t.context.close();
  }
  assert.deepEqual(failures, []);
});

'use strict';

const { test, before, after } = require('node:test');
const assert = require('node:assert/strict');
const { chromium } = require('playwright');
const { startServer } = require('./server');

let server;
let browser;

before(async () => {
  server = await startServer();
  browser = await chromium.launch();
});

after(async () => {
  await browser.close();
  await server.close();
});

async function openVisit() {
  const page = await browser.newPage();
  await page.goto(`${server.origin}/visit.html`);
  return page;
}

async function fillValid(page) {
  await page.fill('#name', 'Ada Reader');
  await page.fill('#email', 'reader@example.co.uk');
  await page.fill('#message', 'Do you stock poetry in large print?');
}

const submitButton = (page) => page.getByRole('button', { name: 'Send message' });

async function fieldState(page, id) {
  return page.evaluate((fieldId) => {
    const field = document.getElementById(fieldId);
    const errorId = `${fieldId}-error`;
    return {
      invalid: field.getAttribute('aria-invalid'),
      describedBy: (field.getAttribute('aria-describedby') || '').split(' '),
      error: document.getElementById(errorId).textContent.trim(),
      focused: document.activeElement === field,
    };
  }, id);
}

test('submitting an empty form marks each required field invalid with a linked message and focuses the first', async () => {
  const page = await openVisit();
  await submitButton(page).click();
  const name = await fieldState(page, 'name');
  assert.equal(name.invalid, 'true');
  assert.ok(name.describedBy.includes('name-error'));
  assert.equal(name.error, 'Please enter your name.');
  assert.equal((await fieldState(page, 'email')).error, 'Please enter your email address.');
  assert.equal((await fieldState(page, 'email')).invalid, 'true');
  assert.equal((await fieldState(page, 'message')).error, 'Please enter a message.');
  assert.equal((await fieldState(page, 'message')).invalid, 'true');
  assert.equal(name.focused, true, 'first invalid field has focus');
  await page.close();
});

test('whitespace-only name and message are invalid', async () => {
  const page = await openVisit();
  await page.fill('#name', '   ');
  await page.fill('#email', 'reader@example.co.uk');
  await page.fill('#message', '   \n  ');
  await submitButton(page).click();
  assert.equal((await fieldState(page, 'name')).invalid, 'true');
  assert.equal((await fieldState(page, 'message')).invalid, 'true');
  assert.equal((await fieldState(page, 'message')).error, 'Please enter a message.');
  await page.close();
});

test('invalid email addresses are rejected and reader@example.co.uk is accepted', async () => {
  const page = await openVisit();
  await page.fill('#name', 'Ada Reader');
  await page.fill('#message', 'Hello');
  for (const email of ['a@', 'a@b', '@b.com', 'a b@c.com']) {
    await page.fill('#email', email);
    await submitButton(page).click();
    const state = await fieldState(page, 'email');
    assert.equal(state.invalid, 'true', `"${email}" should be invalid`);
    assert.equal(state.error, 'Please enter an email address in the form name@example.com.', email);
    assert.equal(await page.getByRole('status').textContent(), '', `no confirmation for "${email}"`);
  }
  await page.fill('#email', 'reader@example.co.uk');
  await submitButton(page).click();
  assert.equal((await fieldState(page, 'email')).invalid, 'false');
  assert.match(await page.getByRole('status').textContent(), /demo/);
  await page.close();
});

test('errors clear when the field is fixed', async () => {
  const page = await openVisit();
  await submitButton(page).click();
  assert.equal((await fieldState(page, 'name')).invalid, 'true');
  await page.fill('#name', 'Ada');
  const state = await fieldState(page, 'name');
  assert.equal(state.invalid, 'false');
  assert.equal(state.error, '');
  await page.close();
});

test('a message over 1000 characters is rejected with the limit stated, not silently truncated', async () => {
  const page = await openVisit();
  await fillValid(page);
  const long = 'x'.repeat(5000);
  await page.fill('#message', long);
  await submitButton(page).click();
  const state = await fieldState(page, 'message');
  assert.equal(state.invalid, 'true');
  assert.equal(state.error, 'Your message is 5000 characters. Please keep it to 1,000 characters or fewer.');
  assert.equal(await page.inputValue('#message'), long, 'text is not truncated');
  assert.equal(await page.getByRole('status').textContent(), '');
  await page.close();
});

test('a valid submission shows a demo confirmation, sends nothing and does not navigate', async () => {
  const page = await openVisit();
  const requests = [];
  const navigations = [];
  page.on('request', (req) => requests.push(req.url()));
  page.on('framenavigated', (frame) => {
    if (frame === page.mainFrame()) navigations.push(frame.url());
  });
  await fillValid(page);
  await page.waitForLoadState('networkidle');
  const before = requests.length;
  const url = page.url();
  await submitButton(page).click();
  const status = page.getByRole('status');
  await status.filter({ hasText: 'demo' }).waitFor();
  await page.waitForLoadState('networkidle');
  const text = await status.textContent();
  assert.match(text, /This is a demo site, so your message wasn't sent anywhere/);
  assert.equal(await status.locator('a[href^="mailto:hello@marginalia.example"]').count(), 1);
  assert.equal(requests.length, before, 'no network request on submit');
  assert.deepEqual(navigations, []);
  assert.equal(page.url(), url);
  await page.close();
});

test('submitting twice quickly does not duplicate the confirmation', async () => {
  const page = await openVisit();
  await fillValid(page);
  await submitButton(page).dblclick();
  await page.getByRole('status').filter({ hasText: 'demo' }).waitFor();
  assert.equal(await page.getByRole('status').count(), 1);
  const text = await page.getByRole('status').textContent();
  assert.equal((text.match(/demo/g) || []).length, 1, 'confirmation appears once');
  await page.close();
});

test('the form says it is a demo next to the submit button', async () => {
  const page = await openVisit();
  const note = page.locator('#contact-form .form-note');
  assert.match(await note.textContent(), /demo/i);
  assert.equal(await note.isVisible(), true);
  await page.close();
});

test('keyboard Enter on submit with an invalid field moves focus to the first invalid field', async () => {
  const page = await openVisit();
  await page.fill('#name', 'Ada Reader');
  await page.fill('#email', 'a@b');
  await page.fill('#message', 'Hello');
  await submitButton(page).focus();
  await page.keyboard.press('Enter');
  assert.equal(await page.evaluate(() => document.activeElement.id), 'email');
  assert.equal((await fieldState(page, 'email')).error, 'Please enter an email address in the form name@example.com.');
  await page.close();
});

test('email addresses with consecutive, leading or trailing dots in the domain are rejected', async () => {
  for (const email of ['a@b..cc', 'a@b.c.', 'a@.b.com']) {
    const page = await openVisit();
    await fillValid(page);
    await page.fill('#email', email);
    await submitButton(page).click();
    const state = await fieldState(page, 'email');
    assert.equal(state.invalid, 'true', `"${email}" should be invalid`);
    assert.equal(state.error, 'Please enter an email address in the form name@example.com.', email);
    assert.equal(await page.getByRole('status').textContent(), '', `no confirmation for "${email}"`);
    await page.close();
  }
});

test('ordinary email addresses, including dotted, plus-tagged and multi-part domains, are accepted', async () => {
  for (const email of ['reader@example.co.uk', 'first.last+tag@mail.example.org', 'a@b.c.d']) {
    const page = await openVisit();
    await fillValid(page);
    await page.fill('#email', email);
    await submitButton(page).click();
    assert.equal((await fieldState(page, 'email')).invalid, 'false', `"${email}" should be valid`);
    assert.match(await page.getByRole('status').textContent(), /demo/, email);
    await page.close();
  }
});

test('message length counts characters, so 1000 emoji are accepted and 1001 are rejected with the limit stated', async () => {
  const page = await openVisit();
  await fillValid(page);
  await page.fill('#message', '😀'.repeat(1000));
  await submitButton(page).click();
  assert.equal((await fieldState(page, 'message')).invalid, 'false', '1000 emoji accepted');
  assert.match(await page.getByRole('status').textContent(), /demo/);
  await page.fill('#message', '😀'.repeat(1001));
  await submitButton(page).click();
  const state = await fieldState(page, 'message');
  assert.equal(state.invalid, 'true', '1001 emoji rejected');
  assert.equal(state.error, 'Your message is 1001 characters. Please keep it to 1,000 characters or fewer.');
  await page.close();
});

test('600 emoji (1200 UTF-16 code units) are accepted', async () => {
  const page = await openVisit();
  await fillValid(page);
  await page.fill('#message', '😀'.repeat(600));
  await submitButton(page).click();
  assert.equal((await fieldState(page, 'message')).invalid, 'false');
  assert.match(await page.getByRole('status').textContent(), /demo/);
  await page.close();
});

test('1000 ASCII characters are accepted and 1001 are rejected with the limit stated', async () => {
  const page = await openVisit();
  await fillValid(page);
  await page.fill('#message', 'x'.repeat(1000));
  await submitButton(page).click();
  assert.equal((await fieldState(page, 'message')).invalid, 'false', '1000 accepted');
  await page.fill('#message', 'x'.repeat(1001));
  await submitButton(page).click();
  const state = await fieldState(page, 'message');
  assert.equal(state.invalid, 'true', '1001 rejected');
  assert.equal(state.error, 'Your message is 1001 characters. Please keep it to 1,000 characters or fewer.');
  await page.close();
});

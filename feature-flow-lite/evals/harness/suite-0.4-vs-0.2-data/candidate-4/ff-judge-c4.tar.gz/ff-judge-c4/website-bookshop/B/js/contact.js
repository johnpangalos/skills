(function () {
  'use strict';

  const DEMO_MESSAGE = 'This is a demo site — your message was not sent. Please email or phone us instead.';
  const FIX_MESSAGE = 'Please fix the highlighted fields.';
  const EMAIL_PATTERN = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  const MAX_MESSAGE_LENGTH = 5000;

  const validators = {
    name: (value) => (value.trim() ? '' : 'Please enter your name.'),
    email: (value, field) => {
      const address = value.trim();
      if (!address) return 'Please enter your email address.';
      const valid = !field.validity.typeMismatch && EMAIL_PATTERN.test(address) && !address.includes('..');
      return valid ? '' : 'Please enter an email address like name@example.com.';
    },
    message: (value) => {
      if (!value.trim()) return 'Please write a message.';
      return value.length <= MAX_MESSAGE_LENGTH ? '' : 'Please keep your message to 5,000 characters or fewer.';
    },
  };

  const form = document.getElementById('contact-form');
  const statusMessage = document.getElementById('form-status');

  // The button ships disabled so a browser without JavaScript cannot submit the form as a GET request.
  form.querySelector('button[type="submit"]').disabled = false;

  function problemWith(field) {
    return validators[field.id](field.value, field);
  }

  function showProblem(field, message) {
    const error = document.getElementById(field.id + '-error');
    error.textContent = message;
    if (message) {
      field.setAttribute('aria-invalid', 'true');
      field.setAttribute('aria-describedby', error.id);
    } else {
      field.removeAttribute('aria-invalid');
      field.removeAttribute('aria-describedby');
    }
  }

  // Checks every field and returns the first invalid one, or null.
  function checkAll() {
    let first = null;
    form.querySelectorAll('input, textarea').forEach((field) => {
      const message = problemWith(field);
      showProblem(field, message);
      if (message && !first) first = field;
    });
    return first;
  }

  form.addEventListener('submit', (event) => {
    event.preventDefault();
    const firstInvalid = checkAll();
    if (firstInvalid) {
      firstInvalid.focus();
      statusMessage.textContent = FIX_MESSAGE;
      return;
    }
    statusMessage.textContent = DEMO_MESSAGE;
  });

  form.addEventListener('input', (event) => {
    const field = event.target;
    if (field.getAttribute('aria-invalid') === 'true') showProblem(field, problemWith(field));
    if (statusMessage.textContent === FIX_MESSAGE && !form.querySelector('[aria-invalid="true"]')) {
      statusMessage.textContent = '';
    }
  });
})();

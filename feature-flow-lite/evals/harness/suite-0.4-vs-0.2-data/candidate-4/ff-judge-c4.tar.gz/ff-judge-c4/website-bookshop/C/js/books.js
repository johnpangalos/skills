// Catalog page: renders the books, filters them by genre, and keeps the genre in the query string.
(function () {
  'use strict';

  var books = window.MARGINALIA_BOOKS || [];
  var select = document.getElementById('genre-filter');
  var list = document.getElementById('book-list');
  var count = document.getElementById('result-count');
  var empty = document.getElementById('no-books');
  if (!select || !list || !count || !empty) return;

  var genres = listGenres(books);

  function slugify(label) {
    return String(label).toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-+|-+$/g, '');
  }

  // Unique genres in data order, each with a URL slug and its display label.
  function listGenres(items) {
    var result = [];
    items.forEach(function (book) {
      var slug = slugify(book.genre);
      var known = result.some(function (genre) { return genre.slug === slug; });
      if (!known) result.push({ slug: slug, label: book.genre });
    });
    return result;
  }

  // Maps a raw query value to a known genre slug, ignoring case and spaces. Unknown values map to '' (All).
  function resolveGenre(raw) {
    var wanted = String(raw || '').trim().toLowerCase();
    var match = genres.find(function (genre) { return genre.slug === wanted; });
    return match ? match.slug : '';
  }

  function filterBooks(slug) {
    if (!slug) return books.slice();
    return books.filter(function (book) { return slugify(book.genre) === slug; });
  }

  function renderOptions() {
    genres.forEach(function (genre) {
      var option = document.createElement('option');
      option.value = genre.slug;
      option.textContent = genre.label;
      select.appendChild(option);
    });
  }

  function createCard(book) {
    var item = document.createElement('li');
    item.className = 'book';

    var cover = document.createElement('div');
    cover.className = 'cover genre-' + slugify(book.genre);
    cover.setAttribute('aria-hidden', 'true');
    cover.textContent = book.title;

    var title = document.createElement('h2');
    title.textContent = book.title;

    var author = document.createElement('p');
    author.className = 'book-author';
    author.textContent = 'by ' + book.author;

    var genre = document.createElement('p');
    genre.className = 'book-genre';
    genre.textContent = book.genre;

    var blurb = document.createElement('p');
    blurb.className = 'book-blurb';
    blurb.textContent = book.blurb;

    var price = document.createElement('p');
    price.className = 'book-price';
    price.textContent = '£' + book.price.toFixed(2);

    item.append(cover, title, author, genre, blurb, price);
    return item;
  }

  function renderBooks(items) {
    list.replaceChildren.apply(list, items.map(createCard));
  }

  function showGenre(slug) {
    var items = filterBooks(slug);
    select.value = slug;
    renderBooks(items);
    count.textContent = 'Showing ' + items.length + ' of ' + books.length + ' books';
    empty.hidden = items.length > 0;
  }

  // The page address for a genre: ?genre=slug, or no query for All.
  function urlFor(slug) {
    var url = new URL(window.location.href);
    if (slug) {
      url.searchParams.set('genre', slug);
    } else {
      url.searchParams.delete('genre');
    }
    return url.pathname + url.search;
  }

  function genreFromUrl() {
    return resolveGenre(new URLSearchParams(window.location.search).get('genre'));
  }

  renderOptions();
  var initial = genreFromUrl();
  window.history.replaceState(null, '', urlFor(initial));
  showGenre(initial);

  select.addEventListener('change', function () {
    var slug = select.value;
    window.history.pushState(null, '', urlFor(slug));
    showGenre(slug);
  });

  window.addEventListener('popstate', function () {
    showGenre(genreFromUrl());
  });
})();

// Collapses the site nav into a menu button on narrow screens.
(function () {
  var nav = document.getElementById('site-nav');
  var toggle = nav.querySelector('.nav-toggle');
  var wide = window.matchMedia('(min-width: 40rem)');

  function isOpen() {
    return toggle.getAttribute('aria-expanded') === 'true';
  }

  function setOpen(open) {
    nav.classList.toggle('is-open', open);
    toggle.setAttribute('aria-expanded', open ? 'true' : 'false');
  }

  toggle.addEventListener('click', function () {
    setOpen(!isOpen());
  });

  document.addEventListener('keydown', function (event) {
    if (event.key === 'Escape' && isOpen()) {
      setOpen(false);
      toggle.focus();
    }
  });

  // The inline nav takes over on desktop, so the menu state resets there.
  wide.addEventListener('change', function (event) {
    if (event.matches) setOpen(false);
  });

  // Hiding the focused toggle on desktop drops focus to BODY, so move it to the first link. The order of
  // this blur and the media query change varies, so the check lives here rather than in the change handler.
  toggle.addEventListener('blur', function () {
    if (wide.matches) nav.querySelector('.site-nav-list a').focus();
  });
})();

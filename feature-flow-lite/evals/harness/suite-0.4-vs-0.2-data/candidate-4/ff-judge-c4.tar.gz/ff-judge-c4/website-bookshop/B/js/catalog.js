(function () {
  'use strict';

  const books = window.MARGINALIA_BOOKS;
  const genres = [...new Set(books.map((book) => book.genre))];
  const filter = document.getElementById('genre-filter');
  const list = document.getElementById('book-list');
  const count = document.getElementById('result-count');

  function slugify(name) {
    return name.toLowerCase().replace(/&/g, 'and').replace(/[^a-z0-9]+/g, '-').replace(/^-+|-+$/g, '');
  }

  // Accepts a genre name or its slug in any case. Anything unknown means All genres.
  function genreFromParam(param) {
    const wanted = (param || '').trim().toLowerCase();
    if (!wanted) return '';
    return genres.find((genre) => genre.toLowerCase() === wanted || slugify(genre) === wanted) || '';
  }

  function genreFromUrl() {
    return genreFromParam(new URLSearchParams(location.search).get('genre'));
  }

  function urlFor(genre) {
    const params = new URLSearchParams(location.search);
    if (genre) params.set('genre', genre);
    else params.delete('genre');
    const query = params.toString();
    return location.pathname + (query ? '?' + query : '') + location.hash;
  }

  function textElement(tag, className, text) {
    const element = document.createElement(tag);
    element.className = className;
    element.textContent = text;
    return element;
  }

  function makeBookItem(book) {
    const item = document.createElement('li');
    item.className = 'book';
    item.append(
      textElement('h2', 'book-title', book.title),
      textElement('p', 'book-author', 'by ' + book.author),
      textElement('p', 'book-genre', book.genre),
      textElement('p', 'book-desc', book.description),
      textElement('p', 'book-price', book.price),
    );
    return item;
  }

  function makeOption(genre) {
    const id = 'genre-' + (genre ? slugify(genre) : 'all');
    const label = document.createElement('label');
    const input = document.createElement('input');
    input.type = 'radio';
    input.name = 'genre';
    input.id = id;
    input.value = genre;
    label.htmlFor = id;
    label.append(input, genre || 'All genres');
    return label;
  }

  function buildFilter() {
    const options = document.createElement('div');
    options.className = 'genre-options';
    options.append(...[''].concat(genres).map(makeOption));
    filter.append(options);
  }

  function render(genre) {
    const shown = genre ? books.filter((book) => book.genre === genre) : books;
    list.replaceChildren(...shown.map(makeBookItem));
    count.textContent = `Showing ${shown.length} of ${books.length} books`;
    filter.querySelectorAll('input').forEach((input) => {
      input.checked = input.value === genre;
    });
  }

  filter.addEventListener('change', (event) => {
    const genre = event.target.value;
    render(genre);
    history.pushState(null, '', urlFor(genre));
  });

  window.addEventListener('popstate', () => render(genreFromUrl()));

  buildFilter();
  const initial = genreFromUrl();
  render(initial);
  history.replaceState(null, '', urlFor(initial));
})();

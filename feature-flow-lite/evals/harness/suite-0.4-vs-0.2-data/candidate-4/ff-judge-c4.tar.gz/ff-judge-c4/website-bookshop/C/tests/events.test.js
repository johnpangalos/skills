'use strict';

const { test, before, after } = require('node:test');
const assert = require('node:assert/strict');
const { chromium } = require('playwright');
const { startServer } = require('./server');

const DAYS = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
const MONTHS = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];

let server;
let browser;

before(async () => {
  server = await startServer();
  browser = await chromium.launch();
});

after(async () => {
  await browser.close();
  await server.close();
});

async function openEvents(context) {
  const page = await context.newPage();
  const problems = [];
  page.on('console', (msg) => {
    if (msg.type() === 'error') problems.push(msg.text());
  });
  page.on('pageerror', (err) => problems.push(err.message));
  await page.goto(`${server.origin}/events.html`);
  await page.waitForSelector('#event-list time');
  return { page, problems };
}

test('lists at least five upcoming events, each with title, time element, description and audience', async () => {
  const context = await browser.newContext();
  const { page, problems } = await openEvents(context);
  const events = await page.$$eval('#event-list > li', (items) =>
    items.map((li) => ({
      title: li.querySelector('h2')?.textContent.trim() || '',
      time: li.querySelector('time')?.getAttribute('datetime') || '',
      when: li.querySelector('time')?.textContent.trim() || '',
      description: li.querySelector('.event-description')?.textContent.trim() || '',
      audience: li.querySelector('.event-for')?.textContent.trim() || '',
    })),
  );
  assert.ok(events.length >= 5, `only ${events.length} events`);
  for (const event of events) {
    assert.ok(event.title, 'title');
    assert.match(event.time, /^(2026-1[2-2]|2027-0[1-3])-\d{2}T\d{2}:\d{2}$/, `datetime for ${event.title}`);
    assert.doesNotMatch(event.when, /\d{4}-\d{2}-\d{2}/, 'date is shown in human-readable form');
    assert.match(event.when, /\d{1,2}:\d{2}(am|pm)/, 'time is shown');
    assert.ok(event.description.length >= 40, `description for ${event.title}`);
    assert.match(event.audience, /^For: \S/, `audience for ${event.title}`);
  }
  assert.deepEqual(problems, []);
  await context.close();
});

test('events are listed in date order', async () => {
  const context = await browser.newContext();
  const { page } = await openEvents(context);
  const stamps = await page.$$eval('#event-list time', (els) => els.map((el) => el.getAttribute('datetime')));
  assert.deepEqual(stamps, [...stamps].sort());
  await context.close();
});

// Timezone tests need the browser process itself in the zone: the timezoneId context option does not
// change Intl in this environment. Each zone gets its own Chromium, and the test fails if the zone is not applied.
const ZONES = [
  { timeZone: 'Pacific/Kiritimati', offset: '+14:00' },
  { timeZone: 'America/Los_Angeles', offset: '-08:00' },
];
const EVENT_DAY = '2026-12-05';
const EVENT_TITLE = 'Winter Reading Circle';
// Dated the day before EVENT_DAY. Injected into the events data so a bad day boundary has something to show.
const EARLIER_EVENT = {
  title: 'Earlier Day Fixture',
  start: '2026-12-04T10:00',
  description: 'A fixture dated the day before the event day, which must never be listed on the event day.',
  audience: 'everyone',
};

// Opens events.html in a browser running in timeZone with the clock at clockTime.
async function launchInZone(timeZone, clockTime) {
  const zoneBrowser = await chromium.launch({ env: { ...process.env, TZ: timeZone } });
  const page = await zoneBrowser.newPage();
  await page.clock.setFixedTime(clockTime);
  await page.route('**/js/events-data.js', async (route) => {
    const response = await route.fetch();
    const body = `${await response.text()}\nwindow.MARGINALIA_EVENTS.push(${JSON.stringify(EARLIER_EVENT)});`;
    await route.fulfill({ status: 200, contentType: 'text/javascript', body });
  });
  await page.goto(`${server.origin}/events.html`);
  await page.waitForSelector('#event-list time');
  const zone = await page.evaluate(() => Intl.DateTimeFormat().resolvedOptions().timeZone);
  assert.equal(zone, timeZone, 'the browser runs in the intended time zone');
  return { zoneBrowser, page };
}

for (const { timeZone, offset } of ZONES) {
  for (const time of ['23:30', '00:01']) {
    test(`in ${timeZone} at ${time} on the event day, that day's event is listed first on events and home, and the earlier one is not`, async () => {
      const { zoneBrowser, page } = await launchInZone(timeZone, new Date(`${EVENT_DAY}T${time}:00${offset}`));
      try {
        const titles = await page.$$eval('#event-list h2', (els) => els.map((el) => el.textContent.trim()));
        assert.equal(titles[0], EVENT_TITLE, 'event dated today is listed first');
        assert.ok(!titles.includes(EARLIER_EVENT.title), 'event dated yesterday is not listed');
        await page.goto(`${server.origin}/index.html`);
        await page.waitForSelector('#next-event a');
        assert.equal(await page.locator('#next-event a').textContent(), EVENT_TITLE, 'home shows the event dated today');
      } finally {
        await zoneBrowser.close();
      }
    });
  }

  test(`event dates show the same calendar day as their datetime in ${timeZone}`, async () => {
    const { zoneBrowser, page } = await launchInZone(timeZone, new Date(`${EVENT_DAY}T12:00:00${offset}`));
    try {
      const times = await page.$$eval('#event-list time', (els) =>
        els.map((el) => ({ datetime: el.getAttribute('datetime'), text: el.textContent.trim() })),
      );
      assert.ok(times.length >= 5);
      for (const { datetime, text } of times) {
        const [y, m, d] = datetime.slice(0, 10).split('-').map(Number);
        const weekday = DAYS[new Date(Date.UTC(y, m - 1, d)).getUTCDay()];
        assert.ok(text.startsWith(weekday), `"${text}" should start with ${weekday}`);
        assert.ok(text.includes(`${d} ${MONTHS[m - 1]} ${y}`), `"${text}" should include ${d} ${MONTHS[m - 1]} ${y}`);
      }
    } finally {
      await zoneBrowser.close();
    }
  });
}

test('an event dated today is still listed, and once the day has passed it is not', async () => {
  const context = await browser.newContext();
  const page = await context.newPage();
  await page.clock.setFixedTime(new Date(2026, 11, 5, 0, 30));
  await page.goto(`${server.origin}/events.html`);
  await page.waitForSelector('#event-list time');
  const todays = await page.evaluate(() => window.MARGINALIA_EVENTS.find((e) => e.start.startsWith('2026-12-05')).title);
  const firstTitle = await page.locator('#event-list h2').first().textContent();
  assert.equal(firstTitle, todays, 'event dated today is listed first');
  await page.clock.setFixedTime(new Date(2026, 11, 6, 9, 0));
  await page.reload();
  await page.waitForSelector('#event-list time');
  const titles = await page.$$eval('#event-list h2', (els) => els.map((el) => el.textContent));
  assert.ok(!titles.includes(todays), 'event dated yesterday is not listed');
  await context.close();
});

test('home next event follows the clock: it shows the second event once the first has passed', async () => {
  const context = await browser.newContext();
  const page = await context.newPage();
  await page.clock.setFixedTime(new Date(2026, 11, 5, 9, 0));
  await page.goto(`${server.origin}/index.html`);
  await page.waitForSelector('#next-event a');
  const [first, second] = await page.evaluate(() => window.MARGINALIA_EVENTS.slice().sort((a, b) => (a.start < b.start ? -1 : 1)).map((e) => e.title));
  assert.equal(await page.locator('#next-event a').textContent(), first, 'first event before its day');
  await page.clock.setFixedTime(new Date(2026, 11, 6, 9, 0));
  await page.reload();
  await page.waitForSelector('#next-event a');
  assert.equal(await page.locator('#next-event a').textContent(), second, 'second event after the first has passed');
  await context.close();
});

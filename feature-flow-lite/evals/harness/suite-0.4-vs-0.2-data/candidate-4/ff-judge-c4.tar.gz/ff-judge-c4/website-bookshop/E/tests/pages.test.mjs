// Criteria 1, 2, 3, 5, 11, 12: site structure, landmarks, requests, content, docs.
import assert from 'node:assert/strict';
import { readFile, readdir } from 'node:fs/promises';
import path from 'node:path';
import { PAGES, ROOT } from './helpers.mjs';

const SOURCE_FILES = ['index.html', 'books.html', 'events.html', 'visit.html', 'css/styles.css', 'js/nav.js', 'js/books.js', 'js/visit.js'];

async function pageInfo(page) {
  return page.evaluate(() => ({
    lang: document.documentElement.lang,
    title: document.title,
    viewport: document.querySelector('meta[name="viewport"]')?.content ?? '',
    h1: document.querySelectorAll('h1').length,
    header: document.querySelectorAll('header').length,
    nav: document.querySelectorAll('header nav').length,
    main: document.querySelectorAll('main').length,
    footer: document.querySelectorAll('footer').length,
  }));
}

export const tests = [
  {
    name: 'criterion 1: the four pages exist, index.html at the root',
    async run(ctx) {
      const { page } = await ctx.open();
      for (const file of PAGES) {
        const response = await page.goto(ctx.url(file));
        assert.equal(response.status(), 200, `${file} should load with status 200`);
      }
    },
  },
  {
    name: 'criterion 1: every page has the same nav with relative links and aria-current on its own link only',
    async run(ctx) {
      const { page } = await ctx.open();
      for (const file of PAGES) {
        await page.goto(ctx.url(file));
        const links = await page.evaluate(() => Array.from(document.querySelectorAll('header nav a'))
          .map((a) => ({ href: a.getAttribute('href'), current: a.getAttribute('aria-current') })));
        assert.deepEqual(links.map((l) => l.href), PAGES, `${file} nav hrefs`);
        const current = links.filter((l) => l.current !== null);
        assert.equal(current.length, 1, `${file} should have exactly one aria-current link`);
        assert.equal(current[0].current, 'page');
        assert.equal(current[0].href, file, `${file} aria-current should be on its own link`);
      }
    },
  },
  {
    name: 'criterion 1: every internal link and asset resolves to an existing file, fragments exist',
    async run(ctx) {
      const { page } = await ctx.open();
      const origin = new URL(ctx.baseUrl).origin;
      for (const file of PAGES) {
        await page.goto(ctx.url(file));
        const refs = await page.evaluate(() => Array.from(document.querySelectorAll('a[href], link[href], script[src]'))
          .map((el) => el.href || el.src));
        for (const ref of refs) {
          if (ref.startsWith('mailto:') || ref.startsWith('tel:')) continue;
          assert.ok(ref.startsWith(origin), `${file} links to a non-local URL: ${ref}`);
          const url = new URL(ref);
          const response = await page.request.get(url.origin + url.pathname);
          assert.equal(response.status(), 200, `${file} -> ${ref} should resolve`);
          if (url.hash) {
            const id = decodeURIComponent(url.hash.slice(1));
            const exists = await page.evaluate((target) => !!document.getElementById(target), id);
            assert.ok(exists || url.pathname !== new URL(ctx.url(file)).pathname, `${file} -> ${ref}: fragment target missing`);
          }
        }
      }
    },
  },
  {
    name: 'criterion 2: every page has lang, a unique title, viewport meta, one h1 and the landmarks',
    async run(ctx) {
      const { page } = await ctx.open();
      const titles = new Set();
      for (const file of PAGES) {
        await page.goto(ctx.url(file));
        const info = await pageInfo(page);
        assert.equal(info.lang, 'en', `${file} lang`);
        assert.ok(info.title.trim().length > 5, `${file} title`);
        titles.add(info.title);
        assert.ok(info.viewport.includes('width=device-width'), `${file} viewport meta`);
        assert.equal(info.h1, 1, `${file} h1 count`);
        assert.equal(info.header, 1, `${file} header`);
        assert.equal(info.nav, 1, `${file} nav inside header`);
        assert.equal(info.main, 1, `${file} main`);
        assert.equal(info.footer, 1, `${file} footer`);
      }
      assert.equal(titles.size, PAGES.length, 'page titles must be unique');
    },
  },
  {
    name: 'criterion 2: the skip link is hidden until focused, then visible, and activating it focuses main',
    async run(ctx) {
      const { page } = await ctx.open();
      for (const file of PAGES) {
        await page.goto(ctx.url(file));
        const before = await page.locator('a[href="#main"]').boundingBox();
        assert.ok(!before || before.y + before.height <= 0, `${file}: skip link should be off-screen before focus`);
        await page.keyboard.press('Tab');
        const focused = await page.evaluate(() => document.activeElement.getAttribute('href'));
        assert.equal(focused, '#main', `${file}: first Tab should reach the skip link`);
        const after = await page.locator('a[href="#main"]').boundingBox();
        assert.ok(after && after.y >= 0 && after.height > 0 && after.width > 0, `${file}: skip link should be visible on focus`);
        await page.keyboard.press('Enter');
        const target = await page.evaluate(() => document.activeElement.id);
        assert.equal(target, 'main', `${file}: focus should move to main`);
      }
    },
  },
  {
    name: 'criterion 2: headings start at one h1 and never skip a level',
    async run(ctx) {
      const { page } = await ctx.open();
      for (const file of PAGES) {
        await page.goto(ctx.url(file));
        const levels = await page.evaluate(() => Array.from(document.querySelectorAll('h1, h2, h3, h4, h5, h6'))
          .map((h) => Number(h.tagName[1])));
        assert.equal(levels[0], 1, `${file} first heading should be h1`);
        for (let i = 1; i < levels.length; i += 1) {
          assert.ok(levels[i] <= levels[i - 1] + 1, `${file}: heading level jumps from h${levels[i - 1]} to h${levels[i]}`);
        }
      }
    },
  },
  {
    name: 'criterion 3: loading each page makes no request outside its own origin',
    async run(ctx) {
      const { page, requests } = await ctx.open();
      const origin = new URL(ctx.baseUrl).origin;
      for (const file of PAGES) {
        requests.length = 0;
        await page.goto(ctx.url(file), { waitUntil: 'networkidle' });
        const foreign = requests.filter((url) => new URL(url).origin !== origin);
        assert.deepEqual(foreign, [], `${file} made requests off-origin`);
      }
    },
  },
  {
    name: 'criterion 3: no shipped source references a remote host, font, style or script',
    async run() {
      const remote = /(?:https?:)?\/\/[a-z0-9-]+(?:\.[a-z0-9-]+)+/i;
      for (const file of SOURCE_FILES) {
        const text = await readFile(path.join(ROOT, file), 'utf8');
        assert.ok(!remote.test(text), `${file} references a remote host`);
        assert.ok(!/@import|@font-face|googleapis|cdn/i.test(text), `${file} loads a remote resource`);
      }
      const js = (await readdir(path.join(ROOT, 'js'))).filter((f) => f.endsWith('.js'));
      assert.ok(js.length >= 1, 'js directory should hold the site scripts');
    },
  },
  {
    name: 'criterion 5: the home page has a real intro, featured books, the next event and a call to visit',
    async run(ctx) {
      const { page } = await ctx.open();
      await page.goto(ctx.url('index.html'));
      const main = page.locator('main');
      const intro = await main.locator('p').first().innerText();
      assert.ok(intro.length > 80, 'intro paragraph should be real copy');
      assert.ok(await main.locator('#featured li').count() >= 3, 'at least three featured books');
      assert.ok(await main.locator('#next-event time[datetime]').count() === 1, 'next event with a time element');
      assert.ok(await main.locator('a[href="visit.html"]').count() >= 1, 'call to visit links to visit.html');
      const text = await page.locator('body').innerText();
      assert.doesNotMatch(text, /lorem|ipsum|placeholder|coming soon|tbd|todo/i);
    },
  },
  {
    name: 'criterion 11: README describes the shop, how to run it and how to run the tests',
    async run() {
      const readme = await readFile(path.join(ROOT, 'README.md'), 'utf8');
      assert.ok(readme.length > 200, 'README should have real content');
      assert.ok(readme.includes('python3 -m http.server'), 'README should explain how to run locally');
      assert.ok(readme.includes('node tests/run.mjs'), 'README should explain how to run the tests');
    },
  },
  {
    name: 'criterion 12: every page shares one stylesheet and identical header and footer',
    async run(ctx) {
      const { page } = await ctx.open();
      const headers = [];
      const footers = [];
      for (const file of PAGES) {
        await page.goto(ctx.url(file));
        const shared = await page.evaluate(() => ({
          sheets: Array.from(document.querySelectorAll('link[rel="stylesheet"]')).map((l) => l.getAttribute('href')),
          styleTags: document.querySelectorAll('style').length,
          header: document.querySelector('header').outerHTML.replace(' aria-current="page"', ''),
          footer: document.querySelector('footer').outerHTML,
          footerHasAddress: /Example Row/.test(document.querySelector('footer').textContent),
          footerHasVisitLink: !!document.querySelector('footer a[href="visit.html"]'),
        }));
        assert.deepEqual(shared.sheets, ['css/styles.css'], `${file} stylesheets`);
        assert.equal(shared.styleTags, 0, `${file} should not use inline style blocks`);
        assert.ok(shared.footerHasAddress && shared.footerHasVisitLink, `${file} footer should show address and visit link`);
        headers.push(shared.header);
        footers.push(shared.footer);
      }
      assert.equal(new Set(headers).size, 1, 'header markup should match on every page');
      assert.equal(new Set(footers).size, 1, 'footer markup should match on every page');
    },
  },
  {
    name: 'finding 4: every footer shows the visit page address, with a believable postcode and no placeholder',
    async run(ctx) {
      const { page } = await ctx.open();
      await page.goto(ctx.url('visit.html'));
      const address = await page.locator('main address').innerText();
      const postcode = address.match(/[A-Z]{1,2}\d[A-Z\d]? \d[A-Z]{2}/)?.[0];
      assert.ok(postcode, `visit address should carry a UK-style postcode: ${JSON.stringify(address)}`);
      assert.doesNotMatch(address, /00000|ZZ/, 'no placeholder postcode');
      const line = `14 Example Row, Fernhollow ${postcode}`;
      for (const file of PAGES) {
        await page.goto(ctx.url(file));
        const footer = (await page.locator('footer').innerText()).replace(/\s+/g, ' ');
        assert.ok(footer.includes(line), `${file} footer should show "${line}"`);
      }
    },
  },
];

'use strict';

const { test } = require('node:test');
const assert = require('node:assert/strict');
const { setupSuite, openTracked, visit, PAGES } = require('./helpers');

const suite = setupSuite();

const WIDTHS = [360, 768, 1280];

// Tap targets named by the criteria: nav links, filter controls and form buttons.
const TAP_TARGETS = [
  'header nav a',
  '#genre-filter input[type=radio]',
  '#genre-filter label',
  'button',
  'input[type=submit]',
  '.site-footer a',
  '.section-more a',
];

async function openAt(width, path) {
  const t = await openTracked(suite, { viewport: { width, height: 800 } });
  await visit(t, `${suite.base}/${path}`);
  return t;
}

for (const name of PAGES) {
  for (const width of WIDTHS) {
    test(`${name} at ${width}px: no horizontal scroll, readable body text, tap targets of 24px+`, async () => {
      const t = await openAt(width, name);
      const { page } = t;
      const scroll = await page.evaluate(() => ({
        scrollWidth: document.documentElement.scrollWidth,
        innerWidth: window.innerWidth,
        bodyFont: parseFloat(getComputedStyle(document.body).fontSize),
      }));
      assert.ok(scroll.scrollWidth <= scroll.innerWidth, `scrollWidth ${scroll.scrollWidth} > ${scroll.innerWidth}`);
      assert.ok(scroll.bodyFont >= 16, `body font ${scroll.bodyFont}px`);

      const small = [];
      for (const selector of TAP_TARGETS) {
        const boxes = await page.locator(selector).evaluateAll((nodes) =>
          nodes
            .filter((node) => node.getClientRects().length > 0)
            .map((node) => {
              const rect = node.getBoundingClientRect();
              return { id: node.id || node.textContent.trim().slice(0, 30) || node.tagName, width: rect.width, height: rect.height };
            }),
        );
        for (const box of boxes) {
          if (box.width < 24 || box.height < 24) small.push(`${selector} ${box.id} ${box.width}x${box.height}`);
        }
      }
      assert.deepEqual(small, []);
      assert.deepEqual(t.problems, []);
      await t.context.close();
    });
  }
}

test('every page at 360px has footer links and section-more links, so the tap-target check is not vacuous', async () => {
  const counts = {};
  for (const name of PAGES) {
    const t = await openAt(360, name);
    counts[name] = {
      footer: await t.page.locator('.site-footer a').count(),
      more: await t.page.locator('.section-more a').count(),
    };
    assert.ok(counts[name].footer >= 1, `${name} has footer links`);
    await t.context.close();
  }
  assert.ok(counts['index.html'].more >= 3, `index.html section-more links: ${counts['index.html'].more}`);
  assert.ok(counts['visit.html'].more >= 1, `visit.html section-more links: ${counts['visit.html'].more}`);
});

test('the catalogue grid is one column on narrow screens and multiple columns on wide ones', async () => {
  const columns = {};
  for (const width of WIDTHS) {
    const t = await openAt(width, 'books.html');
    columns[width] = await t.page.locator('#book-list').evaluate((list) =>
      getComputedStyle(list).gridTemplateColumns.split(' ').filter(Boolean).length,
    );
    await t.context.close();
  }
  assert.equal(columns[360], 1);
  assert.ok(columns[768] >= 2, `768px has ${columns[768]} columns`);
  assert.ok(columns[1280] >= 3, `1280px has ${columns[1280]} columns`);
});

test('at 360px the hours table fits and long words and the email address do not overflow', async () => {
  const t = await openAt(360, 'visit.html');
  const { page } = t;
  const table = await page.locator('#hours').boundingBox();
  assert.ok(table.x >= 0 && table.x + table.width <= 360, 'hours table fits');
  const email = await page.locator('a[href^="mailto:"]').first().boundingBox();
  assert.ok(email.x + email.width <= 360, 'email fits');
  assert.equal(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth), true);
  await t.context.close();
});

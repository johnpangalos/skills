/*
 * Visit page: opening hours with today highlighted and an open or closed status
 * worked out from the visitor's local time, plus the contact form.
 */
(function () {
  'use strict';

  var Marginalia = window.Marginalia;
  var now = new Date();
  var hoursBody = document.getElementById('hours-body');
  var status = document.getElementById('open-status');

  function minutesOf(time) {
    var parts = time.split(':');
    return Number(parts[0]) * 60 + Number(parts[1]);
  }

  function hoursRow(entry) {
    var row = document.createElement('tr');

    var day = document.createElement('th');
    day.setAttribute('scope', 'row');
    day.textContent = entry.day;

    var hours = document.createElement('td');
    hours.textContent = entry.open ? entry.open + '–' + entry.close : 'Closed';

    if (entry.weekday === now.getDay()) {
      row.className = 'is-today';
      var label = document.createElement('span');
      label.className = 'today-label';
      label.textContent = ' (today)';
      day.appendChild(label);
    }
    row.appendChild(day);
    row.appendChild(hours);
    return row;
  }

  function openStatus() {
    var today = Marginalia.hours.filter(function (entry) {
      return entry.weekday === now.getDay();
    })[0];
    var minutes = now.getHours() * 60 + now.getMinutes();
    if (today.open && minutes >= minutesOf(today.open) && minutes < minutesOf(today.close)) {
      return 'Open now, until ' + today.close + ' today.';
    }
    return 'Closed now.';
  }

  Marginalia.hours.forEach(function (entry) {
    hoursBody.appendChild(hoursRow(entry));
  });
  status.textContent = openStatus();
})();

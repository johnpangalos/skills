/*
 * Events page: upcoming events, and past events in their own section. The
 * split uses the visitor's local date, so an event dated today stays upcoming
 * for the whole day.
 */
(function () {
  'use strict';

  var Marginalia = window.Marginalia;
  var bookingText = {
    free: 'Free entry, no booking needed',
    booking: 'Booking required'
  };

  function eventItem(event) {
    var item = document.createElement('li');
    item.className = 'event-card';

    var when = document.createElement('p');
    when.className = 'event-when';
    var time = document.createElement('time');
    time.setAttribute('datetime', event.date + 'T' + event.start);
    time.textContent = Marginalia.formatDate(event.date);
    when.appendChild(time);

    var range = document.createElement('p');
    range.className = 'event-time';
    range.textContent = event.start + '–' + event.end;

    var title = document.createElement('h3');
    title.textContent = event.title;

    var description = document.createElement('p');
    description.className = 'event-description';
    description.textContent = event.description;

    var booking = document.createElement('p');
    booking.className = 'event-booking';
    booking.textContent = bookingText[event.booking];

    item.appendChild(when);
    item.appendChild(range);
    item.appendChild(title);
    item.appendChild(description);
    item.appendChild(booking);
    return item;
  }

  var today = Marginalia.localDateString(new Date());
  var upcomingList = document.getElementById('upcoming-list');
  var pastList = document.getElementById('past-list');
  var pastSection = document.getElementById('past-section');

  var upcoming = Marginalia.upcomingEvents(today);
  upcoming.forEach(function (event) {
    upcomingList.appendChild(eventItem(event));
  });
  upcomingList.hidden = upcoming.length === 0;
  document.getElementById('upcoming-empty').hidden = upcoming.length > 0;

  var past = Marginalia.pastEvents(today);
  past.forEach(function (event) {
    pastList.appendChild(eventItem(event));
  });
  pastSection.hidden = past.length === 0;
})();

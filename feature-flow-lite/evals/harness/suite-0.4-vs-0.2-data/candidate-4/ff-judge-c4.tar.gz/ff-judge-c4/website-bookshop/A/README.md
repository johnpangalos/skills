# Marginalia Books

A fictional independent bookshop website: four pages (home, books, events, visit)
in plain HTML, CSS and JavaScript. There is no build step and no npm dependency
for the site itself. Nothing is loaded from a CDN, web font, or remote image.

## Pages

- `index.html`: intro, staff picks, next events, hours and address summary
- `books.html`: catalogue with a genre filter kept in the URL (`?genre=mystery`)
- `events.html`: upcoming events, and past events in their own section
- `visit.html`: opening hours with today highlighted, address, access notes and a contact form

The catalogue, events and opening hours live in `js/data.js`. Addresses, the
footer and the visit copy live in the HTML pages, so edit those there.

## Run it

The pages use `defer` scripts and can be opened directly from disk, but serving
them is the easiest way to check them. From the repository root, run either:

```sh
npx http-server . -p 8080
```

or

```sh
python3 -m http.server 8080
```

Then open <http://localhost:8080/>.

## Test it

The browser tests drive the real pages in headless Chrome through Playwright.
They use the system Chrome at `/usr/bin/google-chrome` and start their own local
static server, so no server needs to be running first.

```sh
NODE_PATH=/opt/node22/lib/node_modules node tests/site.test.cjs
```

To run a subset of tests by name, pass `--grep`:

```sh
NODE_PATH=/opt/node22/lib/node_modules node tests/site.test.cjs --grep AC5
```

The suite exits non-zero if any test fails.

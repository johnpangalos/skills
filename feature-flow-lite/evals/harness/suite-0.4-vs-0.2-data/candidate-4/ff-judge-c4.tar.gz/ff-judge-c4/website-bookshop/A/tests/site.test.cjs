'use strict';

// Browser tests for the Marginalia Books site.
// Drives the real pages in headless Chrome through Playwright, served by a
// local static server started here. Exits non-zero if any test fails.
//
//   NODE_PATH=/opt/node22/lib/node_modules node tests/site.test.cjs
//   NODE_PATH=/opt/node22/lib/node_modules node tests/site.test.cjs --grep AC5

const assert = require('assert');
const fs = require('fs');
const http = require('http');
const path = require('path');
const { chromium } = require('playwright');

const ROOT = path.resolve(__dirname, '..');
const PAGES = ['index.html', 'books.html', 'events.html', 'visit.html'];
const LOCAL_HOSTS = ['127.0.0.1', 'localhost'];
const LA = 'America/Los_Angeles';
const AUCKLAND = 'Pacific/Auckland';
// Tuesday 17 November 2026, midday in Los Angeles (PST, UTC-8).
const TODAY_LA = '2026-11-17T12:00:00-08:00';
const THANKS = "Thanks, Ada — this is a demo site, so your message wasn't sent anywhere.";
const MIME = {
  '.html': 'text/html; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.js': 'text/javascript; charset=utf-8',
  '.svg': 'image/svg+xml',
  '.png': 'image/png',
  '.md': 'text/markdown; charset=utf-8',
};

const tests = [];
function test(name, fn) {
  tests.push({ name, fn });
}

let browser;
let base;

function startServer() {
  return new Promise((resolve) => {
    const server = http.createServer((req, res) => {
      let pathname = decodeURIComponent(new URL(req.url, 'http://local').pathname);
      if (pathname.endsWith('/')) pathname += 'index.html';
      const file = path.normalize(path.join(ROOT, pathname));
      const blocked = file.startsWith(path.join(ROOT, 'tests') + path.sep) || file.startsWith(path.join(ROOT, '.git') + path.sep);
      if (!file.startsWith(ROOT + path.sep) || blocked) {
        res.writeHead(404, { 'Content-Type': 'text/plain' });
        return res.end('Not found');
      }
      fs.readFile(file, (error, data) => {
        if (error) {
          res.writeHead(404, { 'Content-Type': 'text/plain' });
          return res.end('Not found');
        }
        res.writeHead(200, { 'Content-Type': MIME[path.extname(file)] || 'application/octet-stream' });
        res.end(data);
      });
    });
    server.listen(0, '127.0.0.1', () => resolve(server));
  });
}

// Opens a fresh context with a fixed clock, recording requests, errors and dialogs.
async function open(route, options = {}) {
  const context = await browser.newContext({
    timezoneId: options.timezoneId || LA,
    viewport: { width: options.width || 1280, height: 900 },
  });
  const page = await context.newPage();
  const log = { requests: [], responses: [], errors: [], dialogs: 0 };
  page.on('request', (request) => log.requests.push({ url: request.url(), method: request.method() }));
  page.on('response', (response) => log.responses.push({ url: response.url(), status: response.status() }));
  page.on('console', (message) => {
    if (message.type() === 'error') log.errors.push(message.text());
  });
  page.on('pageerror', (error) => log.errors.push(error.message));
  page.on('dialog', (dialog) => {
    log.dialogs += 1;
    dialog.dismiss();
  });
  await page.clock.setFixedTime(new Date(options.now || TODAY_LA));
  await page.goto(base + route);
  return { context, page, log };
}

async function withPage(route, options, fn) {
  const session = await open(route, options);
  try {
    return await fn(session);
  } finally {
    await session.context.close();
  }
}

function assertLocalOnly(log) {
  const remote = log.requests
    .map((request) => request.url)
    .filter((url) => {
      const parsed = new URL(url);
      return parsed.protocol !== 'http:' || !LOCAL_HOSTS.includes(parsed.hostname);
    });
  assert.deepStrictEqual(remote, [], 'requests left the local server');
}

// Reads the data the pages render, so expectations follow the data file.
async function siteData(page) {
  return page.evaluate(() => ({
    books: window.Marginalia.books,
    events: window.Marginalia.events,
    hours: window.Marginalia.hours,
  }));
}

function genresIn(books) {
  return [...new Set(books.map((book) => book.genre))].sort();
}

async function shownTitles(page) {
  return page.$$eval('#book-list .book-title', (nodes) => nodes.map((node) => node.textContent));
}

async function shownGenres(page) {
  return page.$$eval('#book-list .book-genre', (nodes) => nodes.map((node) => node.textContent));
}

async function checkedGenre(page) {
  return page.$eval('#genre-options input:checked + label', (label) => label.textContent);
}

// Tab through the page with real key presses, recording each stop.
async function keyboardStops(page) {
  const stops = [];
  for (let i = 0; i < 120; i += 1) {
    await page.keyboard.press('Tab');
    const stop = await page.evaluate(() => {
      const el = document.activeElement;
      if (!el || el === document.body) return null;
      const style = getComputedStyle(el);
      return {
        label: el.tagName.toLowerCase() + (el.id ? '#' + el.id : ''),
        focusVisible: el.matches(':focus-visible'),
        outline: style.outlineStyle !== 'none' && parseFloat(style.outlineWidth) > 0,
        rendered: el.getClientRects().length > 0,
        inHidden: Boolean(el.closest('[hidden], [inert], [aria-hidden="true"]')),
        tabIndex: el.tabIndex,
      };
    });
    if (!stop) break;
    stops.push(stop);
  }
  return stops;
}

// Contrast ratios computed in the browser from getComputedStyle, walking up
// to the nearest opaque background for each text-bearing element.
function contrastRatios(page, selectors) {
  return page.evaluate((list) => {
    const parse = (value) => {
      const match = value.match(/rgba?\(([^)]+)\)/);
      if (!match) return null;
      const parts = match[1].split(/[ ,/]+/).filter(Boolean).map(Number);
      return { r: parts[0], g: parts[1], b: parts[2], a: parts.length > 3 ? parts[3] : 1 };
    };
    const luminance = ({ r, g, b }) => {
      const [R, G, B] = [r, g, b].map((channel) => {
        const c = channel / 255;
        return c <= 0.03928 ? c / 12.92 : Math.pow((c + 0.055) / 1.055, 2.4);
      });
      return 0.2126 * R + 0.7152 * G + 0.0722 * B;
    };
    const backgroundOf = (el) => {
      for (let node = el; node; node = node.parentElement) {
        const color = parse(getComputedStyle(node).backgroundColor);
        if (color && color.a > 0) return color;
      }
      return { r: 255, g: 255, b: 255, a: 1 };
    };
    const results = [];
    document.querySelectorAll(list.join(', ')).forEach((el) => {
      if (!el.textContent.trim() || el.getClientRects().length === 0) return;
      const fg = parse(getComputedStyle(el).color);
      const bg = backgroundOf(el);
      const [hi, lo] = [luminance(fg), luminance(bg)].sort((x, y) => y - x);
      results.push({ text: el.textContent.trim().slice(0, 40), ratio: (hi + 0.05) / (lo + 0.05) });
    });
    return results;
  }, selectors);
}

// ---------------------------------------------------------------- AC1

test('AC1 every page has lang en, a unique title, one h1 and the landmarks', async () => {
  const titles = [];
  for (const route of PAGES) {
    await withPage(route, {}, async ({ page }) => {
      const info = await page.evaluate(() => ({
        lang: document.documentElement.lang,
        title: document.title,
        h1: document.querySelectorAll('h1').length,
        header: document.querySelectorAll('body > header').length,
        nav: document.querySelectorAll('body > header nav[aria-label]').length,
        main: document.querySelectorAll('body > main').length,
        footer: document.querySelectorAll('body > footer').length,
      }));
      assert.strictEqual(info.lang, 'en', `${route} lang`);
      assert.ok(info.title.trim().length > 0, `${route} has no title`);
      assert.strictEqual(info.h1, 1, `${route} h1 count`);
      assert.strictEqual(info.header, 1, `${route} header landmark count`);
      assert.strictEqual(info.nav, 1, `${route} nav landmark with aria-label count`);
      assert.strictEqual(info.main, 1, `${route} main landmark count`);
      assert.strictEqual(info.footer, 1, `${route} footer landmark count`);
      titles.push(info.title);
    });
  }
  assert.strictEqual(new Set(titles).size, PAGES.length, `titles are not unique: ${titles}`);
});

test('AC1 skip link is the first tab stop and Enter moves focus into main', async () => {
  for (const route of PAGES) {
    await withPage(route, {}, async ({ page }) => {
      await page.keyboard.press('Tab');
      const first = await page.evaluate(() => ({
        href: document.activeElement.getAttribute('href'),
        text: document.activeElement.textContent.trim(),
        top: document.activeElement.getBoundingClientRect().top,
      }));
      assert.strictEqual(first.href, '#main', `${route} first tab stop href`);
      assert.ok(first.top >= 0, `${route} skip link is not visible when focused`);
      await page.keyboard.press('Enter');
      const focused = await page.evaluate(() => document.activeElement.id);
      assert.strictEqual(focused, 'main', `${route} focus after skip link`);
    });
  }
});

// ---------------------------------------------------------------- AC2

test('AC2 every page carries the same nav and marks only its own link as current', async () => {
  const navs = [];
  for (const route of PAGES) {
    await withPage(route, {}, async ({ page }) => {
      const result = await page.evaluate(() => {
        const nav = document.querySelector('body > header nav');
        const current = [...nav.querySelectorAll('a[aria-current]')];
        const clone = nav.cloneNode(true);
        clone.querySelectorAll('[aria-current]').forEach((el) => el.removeAttribute('aria-current'));
        return {
          html: clone.outerHTML,
          current: current.map((a) => ({ href: a.getAttribute('href'), value: a.getAttribute('aria-current') })),
          links: [...nav.querySelectorAll('a')].map((a) => a.getAttribute('href')),
        };
      });
      assert.deepStrictEqual(result.links, ['index.html', 'books.html', 'events.html', 'visit.html'], `${route} nav links`);
      assert.deepStrictEqual(result.current, [{ href: route, value: 'page' }], `${route} aria-current`);
      navs.push(result.html);
    });
  }
  assert.strictEqual(new Set(navs).size, 1, 'nav markup differs between pages');
});

test('AC2 every internal link and asset reference resolves to a 200 locally', async () => {
  for (const route of PAGES) {
    await withPage(route, {}, async ({ page }) => {
      const refs = await page.evaluate(() => {
        const found = [];
        document.querySelectorAll('a[href], link[href], script[src], img[src]').forEach((el) => {
          found.push(el.getAttribute('href') || el.getAttribute('src'));
        });
        return found;
      });
      assert.ok(refs.length > 5, `${route} has too few references`);
      for (const ref of refs) {
        if (ref.startsWith('mailto:') || ref.startsWith('tel:')) continue;
        if (ref.startsWith('#')) {
          const exists = await page.evaluate((id) => Boolean(document.getElementById(id.slice(1))), ref);
          assert.ok(exists, `${route} fragment ${ref} has no target`);
          continue;
        }
        assert.ok(!/^(\/|https?:)/.test(ref), `${route} uses a non-relative reference ${ref}`);
        const response = await fetch(new URL(ref, base + route));
        assert.strictEqual(response.status, 200, `${route} reference ${ref} returned ${response.status}`);
      }
    });
  }
});

test('AC2 clicking each nav link opens that page with the right current link', async () => {
  await withPage('index.html', {}, async ({ page, log }) => {
    const links = [['Books', 'books.html'], ['Events', 'events.html'], ['Visit', 'visit.html'], ['Home', 'index.html']];
    for (const [name, route] of links) {
      await page.locator('body > header nav').getByRole('link', { name, exact: true }).click();
      await page.waitForURL(`**/${route}`);
      const current = await page.getAttribute(`body > header nav a[href="${route}"]`, 'aria-current');
      assert.strictEqual(current, 'page', `${route} link not marked current`);
    }
    assert.deepStrictEqual(log.errors, []);
  });
});

// ---------------------------------------------------------------- AC3

// Interactions used by the external request and console checks.
async function exercise(route, page) {
  if (route === 'books.html') {
    await page.getByLabel('Mystery', { exact: true }).check();
    await page.goBack();
    await page.goForward();
  }
  if (route === 'visit.html') {
    await page.click('#contact-form button[type="submit"]');
    await page.fill('#name', 'Ada');
    await page.fill('#email', 'ada@example.com');
    await page.fill('#message', 'Do you stock local poetry?');
    await page.click('#contact-form button[type="submit"]');
  }
  if (route === 'index.html') {
    await page.locator('#featured-list a').first().click();
  }
}

test('AC3 loading and using every page makes no request outside the local server', async () => {
  for (const route of PAGES) {
    await withPage(route, {}, async ({ page, log }) => {
      await exercise(route, page);
      assert.ok(log.requests.length > 0, `${route} made no requests at all`);
      assertLocalOnly(log);
      const fonts = await page.evaluate(() => document.fonts.size);
      assert.strictEqual(fonts, 0, `${route} loads web fonts`);
    });
  }
});

test('AC3 no build step: every stylesheet and script is served byte for byte from the repo', async () => {
  assert.ok(!fs.existsSync(path.join(ROOT, 'package.json')), 'a package.json would imply a build step');
  for (const route of PAGES) {
    const html = fs.readFileSync(path.join(ROOT, route), 'utf8');
    const assets = [...html.matchAll(/(?:href|src)="([^"#?]+\.(?:css|js))"/g)].map((m) => m[1]);
    assert.ok(assets.length > 0, `${route} references no local assets`);
    for (const asset of assets) {
      const served = await fetch(base + asset);
      const body = Buffer.from(await served.arrayBuffer());
      assert.ok(body.equals(fs.readFileSync(path.join(ROOT, asset))), `${asset} served differently from the file`);
    }
  }
});

// ---------------------------------------------------------------- AC4

test('AC4 catalogue shows at least 12 books across at least 5 genres with every field', async () => {
  await withPage('books.html', {}, async ({ page }) => {
    const cards = await page.$$eval('#book-list .book-card', (nodes) => nodes.map((node) => ({
      title: node.querySelector('.book-title').textContent.trim(),
      author: node.querySelector('.book-author').textContent.trim(),
      genre: node.querySelector('.book-genre').textContent.trim(),
      blurb: node.querySelector('.book-blurb').textContent.trim(),
      price: node.querySelector('.book-price').textContent.trim(),
    })));
    assert.ok(cards.length >= 12, `only ${cards.length} books`);
    assert.ok(new Set(cards.map((c) => c.genre)).size >= 5, 'fewer than 5 genres');
    for (const card of cards) {
      assert.ok(card.title && card.author && card.genre, `missing field in ${JSON.stringify(card)}`);
      assert.ok(/^by \S/.test(card.author), `author not formatted: ${card.author}`);
      const sentences = card.blurb.match(/[.!?](\s|$)/g) || [];
      assert.ok(sentences.length >= 1 && sentences.length <= 2, `blurb is not one or two sentences: ${card.blurb}`);
      assert.ok(/^£\d+\.\d{2}$/.test(card.price), `price format: ${card.price}`);
    }
    const body = await page.textContent('body');
    assert.ok(!/lorem ipsum/i.test(body), 'placeholder text found');
  });
});

test('AC4 hostile titles with apostrophes, ampersands and quotes render as text', async () => {
  await withPage('books.html', {}, async ({ page, log }) => {
    const data = await siteData(page);
    const special = data.books.filter((book) => /['"&]/.test(book.title));
    assert.ok(special.length >= 3, 'data should include apostrophe, ampersand and quote titles');
    for (const book of special) {
      const shown = await page.$$eval('#book-list .book-title', (nodes, title) => nodes.filter((n) => n.textContent === title).map((n) => ({
        childElements: n.children.length,
        html: n.innerHTML,
      })), book.title);
      assert.strictEqual(shown.length, 1, `"${book.title}" not rendered exactly once`);
      assert.strictEqual(shown[0].childElements, 0, `"${book.title}" rendered markup`);
      if (book.title.includes('&')) assert.ok(shown[0].html.includes('&amp;'), 'ampersand not escaped as text');
    }
    assert.strictEqual(log.dialogs, 0);
  });
});

// ---------------------------------------------------------------- AC5

test('AC5 genre control offers All plus every genre in the data, with no empty genres', async () => {
  await withPage('books.html', {}, async ({ page }) => {
    const data = await siteData(page);
    const legend = await page.textContent('fieldset.genre-filter legend');
    assert.ok(legend.trim().length > 0, 'filter has no legend');
    const labels = await page.$$eval('#genre-options label', (nodes) => nodes.map((n) => n.textContent.trim()));
    assert.deepStrictEqual(labels, ['All', ...genresIn(data.books)]);
  });
});

test('AC5 choosing a genre shows only its books and announces the count', async () => {
  await withPage('books.html', {}, async ({ page }) => {
    const data = await siteData(page);
    await page.getByLabel('Mystery', { exact: true }).check();
    const genres = await shownGenres(page);
    const expected = data.books.filter((b) => b.genre === 'Mystery').length;
    assert.strictEqual(genres.length, expected, 'wrong number of mystery books');
    assert.ok(genres.every((g) => g === 'Mystery'), `non-mystery book shown: ${genres}`);
    const status = await page.textContent('#result-count');
    assert.strictEqual(status, `Showing ${expected} of ${data.books.length} books`);
    assert.strictEqual(await page.getAttribute('#result-count', 'role'), 'status');
    assert.strictEqual(await page.getAttribute('#result-count', 'aria-live'), 'polite');
    await page.getByLabel('All', { exact: true }).check();
    assert.strictEqual((await shownTitles(page)).length, data.books.length);
  });
});

test('AC5 choosing a genre pushes the URL and back and forward restore filter and control', async () => {
  await withPage('books.html', {}, async ({ page, log }) => {
    const before = await page.evaluate(() => history.length);
    await page.getByLabel('Poetry', { exact: true }).check();
    assert.ok(page.url().endsWith('/books.html?genre=poetry'), `url is ${page.url()}`);
    assert.strictEqual(await page.evaluate(() => history.length), before + 1, 'filter change did not push history');
    await page.goBack();
    assert.ok(page.url().endsWith('/books.html'), `back url is ${page.url()}`);
    assert.strictEqual(await checkedGenre(page), 'All');
    assert.strictEqual((await shownGenres(page)).length, (await siteData(page)).books.length);
    await page.goForward();
    assert.strictEqual(await checkedGenre(page), 'Poetry');
    assert.ok((await shownGenres(page)).every((g) => g === 'Poetry'));
    assert.strictEqual(log.dialogs, 0);
  });
});

test('AC5 loading books.html?genre=mystery shows only mystery with the control set to it', async () => {
  await withPage('books.html?genre=mystery', {}, async ({ page }) => {
    const genres = await shownGenres(page);
    assert.ok(genres.length > 0 && genres.every((g) => g === 'Mystery'), `shown: ${genres}`);
    assert.strictEqual(await checkedGenre(page), 'Mystery');
    assert.strictEqual(await page.textContent('#result-count'), `Showing ${genres.length} of ${(await siteData(page)).books.length} books`);
  });
});

test('AC5 hostile genre values fall back to All without errors or injected markup', async () => {
  const cases = ['unknown-thing', '', '%3Cscript%3Ealert(1)%3C%2Fscript%3E', '%3Cimg%20src%3Dx%20onerror%3Dalert(1)%3E'];
  for (const value of cases) {
    await withPage(`books.html?genre=${value}`, {}, async ({ page, log }) => {
      const data = await siteData(page);
      assert.strictEqual((await shownTitles(page)).length, data.books.length, `"${value}" did not fall back to All`);
      assert.strictEqual(await checkedGenre(page), 'All', `control does not show All for "${value}"`);
      assert.strictEqual(await page.$('#book-list script, #book-list img, #genre-options script'), null, 'markup injected');
      assert.strictEqual(log.dialogs, 0, 'script ran');
      assert.deepStrictEqual(log.errors, [], 'console errors');
    });
  }
});

test('AC5 hostile ?genre=MYSTERY matches case-insensitively', async () => {
  await withPage('books.html?genre=MYSTERY', {}, async ({ page, log }) => {
    const genres = await shownGenres(page);
    assert.ok(genres.length > 0 && genres.every((g) => g === 'Mystery'), `shown: ${genres}`);
    assert.strictEqual(await checkedGenre(page), 'Mystery');
    assert.deepStrictEqual(log.errors, []);
  });
});

test('AC5 hostile repeated genre parameters use the first one', async () => {
  await withPage('books.html?genre=history&genre=mystery', {}, async ({ page, log }) => {
    const genres = await shownGenres(page);
    assert.ok(genres.length > 0 && genres.every((g) => g === 'History'), `shown: ${genres}`);
    assert.strictEqual(await checkedGenre(page), 'History');
    assert.deepStrictEqual(log.errors, []);
  });
});

test('AC5 the genre filter is fully keyboard operable with a visible focus ring', async () => {
  await withPage('books.html', {}, async ({ page }) => {
    const data = await siteData(page);
    // Tab from the skip link until a genre radio button has keyboard focus.
    let focused = null;
    for (let i = 0; i < 40 && !focused; i += 1) {
      await page.keyboard.press('Tab');
      focused = await page.evaluate(() => (document.activeElement.name === 'genre' ? document.activeElement.id : null));
    }
    assert.ok(focused, 'genre control is not reachable by Tab');
    const ring = await page.evaluate(() => {
      const style = getComputedStyle(document.activeElement);
      return { visible: document.activeElement.matches(':focus-visible'), outline: style.outlineStyle, width: parseFloat(style.outlineWidth) };
    });
    assert.ok(ring.visible && ring.outline !== 'none' && ring.width > 0, `no visible focus: ${JSON.stringify(ring)}`);
    await page.keyboard.press('ArrowDown');
    assert.strictEqual(await page.evaluate(() => document.activeElement.name), 'genre', 'focus left the group');
    assert.ok(page.url().includes('genre='), 'arrow key did not update the URL');
    const shown = await shownGenres(page);
    assert.ok(shown.length > 0 && shown.length < data.books.length, 'arrow key did not filter');
    assert.strictEqual(await page.textContent('#result-count'), `Showing ${shown.length} of ${data.books.length} books`);
  });
});

test('AC5 back moves focus off an unchecked radio onto the checked one', async () => {
  await withPage('books.html', {}, async ({ page, log }) => {
    await page.locator('#genre-poetry').check();
    assert.strictEqual(await page.evaluate(() => document.activeElement.id), 'genre-poetry', 'poetry radio not focused');
    await page.goBack();
    const focused = await page.evaluate(() => ({ id: document.activeElement.id, checked: document.activeElement.checked }));
    assert.deepStrictEqual(focused, { id: 'genre-all', checked: true }, 'focus did not move to the checked radio');
    assert.deepStrictEqual(log.errors, []);
  });
});

test('AC5 each real filter change pushes exactly one history entry, and re-selecting the current genre pushes none', async () => {
  await withPage('books.html', {}, async ({ page, log }) => {
    await page.focus('#genre-all');
    const start = await page.evaluate(() => history.length);
    await page.keyboard.press('ArrowDown');
    assert.strictEqual(await page.evaluate(() => history.length), start + 1, 'first arrow press did not push exactly one entry');
    await page.keyboard.press('ArrowDown');
    assert.strictEqual(await page.evaluate(() => history.length), start + 2, 'second arrow press did not push exactly one entry');
    const current = await page.evaluate(() => history.length);
    await page.$eval('input[name="genre"]:checked', (radio) => radio.dispatchEvent(new Event('change', { bubbles: true })));
    assert.strictEqual(await page.evaluate(() => history.length), current, 're-selecting the current genre pushed an entry');
    assert.deepStrictEqual(log.errors, []);
  });
});

// ---------------------------------------------------------------- AC6

test('AC6 events page lists at least five upcoming events with date, time, title, description and booking', async () => {
  await withPage('events.html', {}, async ({ page }) => {
    const events = await page.$$eval('#upcoming-list > li', (nodes) => nodes.map((node) => ({
      datetime: node.querySelector('time').getAttribute('datetime'),
      time: node.querySelector('.event-time').textContent.trim(),
      title: node.querySelector('h3').textContent.trim(),
      description: node.querySelector('.event-description').textContent.trim(),
      booking: node.querySelector('.event-booking').textContent.trim(),
    })));
    assert.ok(events.length >= 5, `only ${events.length} upcoming events`);
    for (const event of events) {
      assert.ok(/^(2026|2027)-\d{2}-\d{2}T?/.test(event.datetime), `bad datetime ${event.datetime}`);
      assert.ok(/\d{2}:\d{2}/.test(event.time), `no time: ${event.time}`);
      assert.ok(event.title && event.description, 'missing title or description');
      assert.ok(/free|booking/i.test(event.booking), `booking status unclear: ${event.booking}`);
    }
  });
});

test('AC6 every weekday named in an event title or description matches the weekday of its date', async () => {
  const weekdays = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
  const weekdayWord = /\b(Sunday|Monday|Tuesday|Wednesday|Thursday|Friday|Saturday)s?\b/gi;
  await withPage('events.html', {}, async ({ page }) => {
    const data = await siteData(page);
    const events = await page.$$eval('#upcoming-list .event-card, #past-list .event-card', (nodes) => nodes.map((node) => ({
      datetime: node.querySelector('time').getAttribute('datetime'),
      text: node.querySelector('h3').textContent + ' ' + node.querySelector('.event-description').textContent,
    })));
    assert.strictEqual(events.length, data.events.length, 'not every event is rendered');
    let named = 0;
    for (const event of events) {
      const [year, month, day] = event.datetime.slice(0, 10).split('-').map(Number);
      const weekday = weekdays[new Date(Date.UTC(year, month - 1, day)).getUTCDay()];
      for (const match of event.text.matchAll(weekdayWord)) {
        named += 1;
        assert.strictEqual(match[1].toLowerCase(), weekday.toLowerCase(), `${event.datetime} names ${match[1]} but falls on ${weekday}`);
      }
    }
    assert.ok(named >= 2, `only ${named} weekday words found, so the check did not run`);
  });
});

test('AC6 past events are removed from upcoming and listed under Past events', async () => {
  await withPage('events.html', {}, async ({ page }) => {
    const data = await siteData(page);
    const past = data.events.filter((e) => e.date < '2026-11-17');
    assert.ok(past.length > 0, 'data needs a past event');
    assert.strictEqual(await page.isVisible('#past-section'), true, 'past section hidden');
    const pastTitles = await page.$$eval('#past-list h3', (nodes) => nodes.map((n) => n.textContent));
    assert.deepStrictEqual(pastTitles, past.map((e) => e.title).reverse());
    const upcomingTitles = await page.$$eval('#upcoming-list h3', (nodes) => nodes.map((n) => n.textContent));
    assert.ok(upcomingTitles.every((t) => !pastTitles.includes(t)), 'a past event is also upcoming');
  });
});

test('AC6 upcoming and past split uses the local date, not UTC', async () => {
  // 23:30 UTC on 17 November is 12:30 on 18 November in Auckland, but 15:30 on 17 November in Los Angeles.
  const instant = '2026-11-17T23:30:00Z';
  await withPage('events.html', { timezoneId: AUCKLAND, now: instant }, async ({ page }) => {
    const data = await siteData(page);
    const todayEvent = data.events.find((e) => e.date === '2026-11-17');
    assert.ok(todayEvent, 'data needs an event dated 17 November');
    const upcoming = await page.$$eval('#upcoming-list h3', (nodes) => nodes.map((n) => n.textContent));
    assert.ok(!upcoming.includes(todayEvent.title), 'Auckland (already 18 Nov) still shows yesterday as upcoming');
  });
  await withPage('events.html', { timezoneId: LA, now: instant }, async ({ page }) => {
    const data = await siteData(page);
    const todayEvent = data.events.find((e) => e.date === '2026-11-17');
    const upcoming = await page.$$eval('#upcoming-list h3', (nodes) => nodes.map((n) => n.textContent));
    assert.ok(upcoming.includes(todayEvent.title), 'Los Angeles (still 17 Nov) hides an event dated today');
  });
});

test('AC6 hostile: an event dated today stays upcoming at 00:01 and 23:59 local time', async () => {
  for (const now of ['2026-11-17T00:01:00-08:00', '2026-11-17T23:59:00-08:00']) {
    await withPage('events.html', { now }, async ({ page }) => {
      const data = await siteData(page);
      const todayEvent = data.events.find((e) => e.date === '2026-11-17');
      const upcoming = await page.$$eval('#upcoming-list h3', (nodes) => nodes.map((n) => n.textContent));
      assert.ok(upcoming.includes(todayEvent.title), `event dated today hidden at ${now}`);
    });
  }
});

test('AC6 with no upcoming events, the list is replaced by a plain message', async () => {
  await withPage('events.html', { now: '2027-06-01T12:00:00-07:00' }, async ({ page, log }) => {
    assert.strictEqual(await page.locator('#upcoming-list > li').count(), 0, 'empty list still has items');
    assert.strictEqual(await page.isVisible('#upcoming-list'), false, 'empty list is still shown');
    assert.strictEqual(await page.isVisible('#upcoming-empty'), true, 'empty message is hidden');
    assert.strictEqual(await page.textContent('#upcoming-empty'), 'No events scheduled right now. Check back soon.');
    assert.strictEqual(await page.isVisible('#past-section'), true, 'past events are not listed');
    assert.deepStrictEqual(log.errors, []);
  });
});

// ---------------------------------------------------------------- AC7

test('AC7 visit page shows a semantic hours table with all seven days', async () => {
  await withPage('visit.html', {}, async ({ page }) => {
    const rows = await page.$$eval('table#hours-table tbody tr, table tbody tr', (nodes) => nodes.map((row) => ({
      day: row.querySelector('th').textContent.replace(/\(today\)/, '').trim(),
      hours: row.querySelector('td').textContent.trim(),
    })));
    assert.deepStrictEqual(rows.map((r) => r.day), ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday']);
    assert.ok(rows.every((r) => r.hours.length > 0), 'a day has no hours text');
    assert.strictEqual(await page.isVisible('table caption'), true, 'table has no caption');
  });
});

test('AC7 visit page has an address, example-domain contact details, access notes and a contact form', async () => {
  await withPage('visit.html', {}, async ({ page }) => {
    const address = await page.textContent('address');
    assert.ok(address.trim().length > 10, 'address is empty');
    const tel = await page.getAttribute('a[href^="tel:"]', 'href');
    const mailto = await page.getAttribute('a[href^="mailto:"]', 'href');
    assert.ok(tel, 'no tel link');
    assert.ok(/^mailto:[^@]+@marginalia\.example$/.test(mailto), `email not on example domain: ${mailto}`);
    const body = await page.textContent('main');
    assert.ok(/access/i.test(body) && /step-free|level|ramp/i.test(body), 'no accessibility notes');
    assert.ok(/getting here|directions/i.test(body), 'no directions');
    assert.strictEqual(await page.locator('form#contact-form').count(), 1, 'contact form missing');
  });
});

test('AC7 today is highlighted from the local day of week', async () => {
  await withPage('visit.html', {}, async ({ page }) => {
    const today = await page.$$eval('tr.is-today', (nodes) => nodes.map((n) => n.querySelector('th').textContent));
    assert.strictEqual(today.length, 1, 'expected exactly one highlighted day');
    assert.ok(today[0].startsWith('Tuesday'), `highlighted ${today[0]}`);
  });
  // The same instant is Monday evening in Los Angeles.
  await withPage('visit.html', { timezoneId: LA, now: '2026-11-17T02:00:00Z' }, async ({ page }) => {
    const today = await page.$$eval('tr.is-today', (nodes) => nodes.map((n) => n.querySelector('th').textContent));
    assert.ok(today[0].startsWith('Monday'), `Los Angeles highlighted ${today[0]}`);
  });
});

test('AC7 open status is computed from local time: open, closed on a Monday, and closed after close', async () => {
  const cases = [
    { now: '2026-11-17T12:00:00-08:00', timezoneId: LA, expect: /^Open now/ },
    { now: '2026-11-16T12:00:00-08:00', timezoneId: LA, expect: /^Closed now/ },
    { now: '2026-11-17T20:00:00-08:00', timezoneId: LA, expect: /^Closed now/ },
    { now: '2026-11-17T02:00:00Z', timezoneId: AUCKLAND, expect: /^Open now/ },
  ];
  for (const { now, timezoneId, expect } of cases) {
    await withPage('visit.html', { now, timezoneId }, async ({ page }) => {
      const status = await page.textContent('#open-status');
      assert.match(status.trim(), expect, `status at ${now} in ${timezoneId} was "${status}"`);
    });
  }
});

// ---------------------------------------------------------------- AC8

test('AC8 every form field has a visible label, and the form is novalidate', async () => {
  await withPage('visit.html', {}, async ({ page }) => {
    for (const id of ['name', 'email', 'topic', 'message']) {
      const text = await page.$eval(`label[for="${id}"]`, (label) => label.textContent.trim()).catch(() => '');
      assert.ok(text.length > 0, `no visible label for ${id}`);
    }
    assert.strictEqual(await page.getAttribute('#contact-form', 'novalidate') !== null, true, 'form is not novalidate');
    assert.strictEqual(await page.getAttribute('#topic', 'name'), 'topic');
  });
});

test('AC8 invalid submit marks fields, links errors with aria-describedby and focuses the first invalid field', async () => {
  await withPage('visit.html', {}, async ({ page, log }) => {
    await page.click('#contact-form button[type="submit"]');
    for (const id of ['name', 'email', 'message']) {
      assert.strictEqual(await page.getAttribute(`#${id}`, 'aria-invalid'), 'true', `${id} not aria-invalid`);
      const describedBy = await page.getAttribute(`#${id}`, 'aria-describedby');
      assert.ok(describedBy && describedBy.split(' ').includes(`${id}-error`), `${id} not described by its error`);
      const message = await page.textContent(`#${id}-error`);
      assert.ok(message.trim().length > 0, `${id} error message empty`);
    }
    assert.strictEqual(await page.getAttribute('#topic', 'aria-invalid'), null, 'topic should not be invalid');
    assert.strictEqual(await page.evaluate(() => document.activeElement.id), 'name', 'focus not on first invalid field');
    assert.strictEqual(await page.getAttribute('#form-summary', 'role'), 'alert');
    assert.match(await page.textContent('#form-summary'), /3 fields/);
    assert.deepStrictEqual(log.errors, []);
  });
});

test('AC8 keyboard submit with Enter also focuses the first invalid field', async () => {
  await withPage('visit.html', {}, async ({ page }) => {
    await page.focus('#message');
    await page.keyboard.press('Tab');
    assert.strictEqual(await page.evaluate(() => document.activeElement.textContent.trim()), 'Send message');
    await page.keyboard.press('Enter');
    assert.strictEqual(await page.evaluate(() => document.activeElement.id), 'name');
  });
});

test('AC8 hostile whitespace-only name and message are invalid', async () => {
  await withPage('visit.html', {}, async ({ page }) => {
    await page.fill('#name', '     ');
    await page.fill('#email', 'ada@example.com');
    await page.fill('#message', '          ');
    await page.click('#contact-form button[type="submit"]');
    assert.strictEqual(await page.getAttribute('#name', 'aria-invalid'), 'true');
    assert.strictEqual(await page.getAttribute('#message', 'aria-invalid'), 'true');
    assert.strictEqual(await page.getAttribute('#email', 'aria-invalid'), null);
    assert.strictEqual(await page.getAttribute('#form-result', 'role'), 'status');
    assert.strictEqual(await page.textContent('#form-result'), '');
  });
});

test('AC8 hostile malformed emails "a@b" and "foo@" are invalid, a real address is valid', async () => {
  await withPage('visit.html', {}, async ({ page }) => {
    for (const bad of ['a@b', 'foo@', 'no-at-sign.example']) {
      await page.fill('#email', bad);
      await page.click('#contact-form button[type="submit"]');
      assert.strictEqual(await page.getAttribute('#email', 'aria-invalid'), 'true', `"${bad}" accepted`);
    }
    await page.fill('#email', 'ada@example.com');
    await page.click('#contact-form button[type="submit"]');
    assert.strictEqual(await page.getAttribute('#email', 'aria-invalid'), null, 'valid email rejected');
  });
});

test('AC8 hostile message under 10 characters is invalid and exactly 10 is accepted', async () => {
  await withPage('visit.html', {}, async ({ page }) => {
    await page.fill('#name', 'Ada');
    await page.fill('#email', 'ada@example.com');
    await page.fill('#message', 'too short');
    await page.click('#contact-form button[type="submit"]');
    assert.strictEqual(await page.getAttribute('#message', 'aria-invalid'), 'true', '9 characters accepted');
    await page.fill('#message', 'ten chars!');
    await page.click('#contact-form button[type="submit"]');
    assert.strictEqual(await page.getAttribute('#message', 'aria-invalid'), null, '10 characters rejected');
  });
});

test('AC8 valid submit makes no network request and shows a plain demo confirmation', async () => {
  await withPage('visit.html', {}, async ({ page, log }) => {
    await page.fill('#name', 'Ada');
    await page.fill('#email', 'ada@example.com');
    await page.fill('#message', 'Do you stock local poetry?');
    const before = log.requests.length;
    await page.click('#contact-form button[type="submit"]');
    await page.waitForFunction(() => document.getElementById('form-result').textContent.length > 0);
    assert.strictEqual(await page.textContent('#form-result'), THANKS);
    assert.strictEqual(await page.getAttribute('#form-result', 'role'), 'status');
    const after = log.requests.slice(before);
    assert.deepStrictEqual(after, [], 'valid submit made a request');
    assert.ok(!/sent|delivered/i.test((await page.textContent('#form-result')).replace("wasn't sent", '')), 'confirmation claims sending');
    assert.ok(page.url().endsWith('/visit.html'), 'submit navigated away');
  });
});

test('AC8 hostile name with markup is shown as text in the confirmation and never runs', async () => {
  await withPage('visit.html', {}, async ({ page, log }) => {
    const name = '<img src=x onerror=alert(1)>';
    await page.fill('#name', name);
    await page.fill('#email', 'ada@example.com');
    await page.fill('#message', 'Do you stock local poetry?');
    await page.click('#contact-form button[type="submit"]');
    const text = await page.textContent('#form-result');
    assert.ok(text.includes(name), `markup not shown as text: ${text}`);
    assert.strictEqual(await page.$('#form-result img'), null, 'img element was created');
    assert.strictEqual(log.dialogs, 0, 'onerror handler ran');
    assert.deepStrictEqual(log.errors, []);
  });
});

test('AC8 hostile 10,000 character message does not break the 360px layout', async () => {
  await withPage('visit.html', { width: 360 }, async ({ page }) => {
    await page.fill('#name', 'Ada');
    await page.fill('#email', 'ada@example.com');
    await page.fill('#message', 'a'.repeat(10000));
    await page.click('#contact-form button[type="submit"]');
    await page.waitForFunction(() => document.getElementById('form-result').textContent.length > 0);
    const widths = await page.evaluate(() => ({ scroll: document.documentElement.scrollWidth, inner: window.innerWidth }));
    assert.ok(widths.scroll <= widths.inner, `page scrolls sideways: ${widths.scroll} > ${widths.inner}`);
  });
});

test('AC8 hostile double submit shows one confirmation, not stacked copies', async () => {
  await withPage('visit.html', {}, async ({ page }) => {
    await page.fill('#name', 'Ada');
    await page.fill('#email', 'ada@example.com');
    await page.fill('#message', 'Do you stock local poetry?');
    await page.dblclick('#contact-form button[type="submit"]');
    await page.waitForFunction(() => document.getElementById('form-result').textContent.length > 0);
    assert.strictEqual(await page.textContent('#form-result'), THANKS);
    const copies = await page.$$eval('[role="status"]', (nodes) => nodes.filter((n) => n.textContent.includes('demo site')).length);
    assert.strictEqual(copies, 1, `${copies} confirmations shown`);
  });
});

test('AC8 fixing an invalid field clears its error and leaves the others', async () => {
  await withPage('visit.html', {}, async ({ page }) => {
    await page.click('#contact-form button[type="submit"]');
    await page.fill('#name', 'Ada');
    assert.notStrictEqual(await page.getAttribute('#name', 'aria-invalid'), 'true', 'name error not cleared');
    assert.strictEqual(await page.textContent('#name-error'), '');
    assert.strictEqual(await page.getAttribute('#email', 'aria-invalid'), 'true', 'email error cleared by mistake');
  });
});

// ---------------------------------------------------------------- AC9

test('AC9 every page scrolls no wider than the viewport at 360, 768 and 1280 px', async () => {
  for (const width of [360, 768, 1280]) {
    for (const route of PAGES) {
      await withPage(route, { width }, async ({ page }) => {
        const sizes = await page.evaluate(() => ({ scroll: document.documentElement.scrollWidth, inner: window.innerWidth }));
        assert.ok(sizes.scroll <= sizes.inner, `${route} at ${width}px scrolls: ${sizes.scroll} > ${sizes.inner}`);
      });
    }
  }
});

test('AC9 the nav stays fully on screen and usable at 360px', async () => {
  await withPage('index.html', { width: 360 }, async ({ page }) => {
    const boxes = await page.$$eval('body > header nav a', (nodes) => nodes.map((n) => {
      const r = n.getBoundingClientRect();
      return { left: r.left, right: r.right, height: r.height, width: window.innerWidth };
    }));
    assert.strictEqual(boxes.length, 4);
    for (const box of boxes) {
      assert.ok(box.left >= 0 && box.right <= box.width && box.height > 0, `nav link off screen: ${JSON.stringify(box)}`);
    }
    await page.getByRole('navigation', { name: 'Main' }).getByRole('link', { name: 'Visit' }).click();
    await page.waitForURL('**/visit.html');
  });
});

test('AC9 hostile long unbroken words and URLs do not overflow at 360px', async () => {
  await withPage('books.html', { width: 360 }, async ({ page }) => {
    await page.evaluate(() => {
      const blurb = document.querySelector('.book-blurb');
      blurb.textContent = 'x'.repeat(400);
      const author = document.querySelector('.book-author');
      author.textContent = 'by https://example.com/' + 'a'.repeat(300);
    });
    const sizes = await page.evaluate(() => ({ scroll: document.documentElement.scrollWidth, inner: window.innerWidth }));
    assert.ok(sizes.scroll <= sizes.inner, `long text overflows: ${sizes.scroll} > ${sizes.inner}`);
  });
});

// ---------------------------------------------------------------- AC10

test('AC10 body text, links, nav, buttons and labels meet 4.5:1 contrast', async () => {
  const selectors = [
    'main p', 'main li', 'main h1', 'main h2', 'main h3', 'main th', 'main td', 'main label',
    'main legend', 'main a', 'main button', 'main address', 'header a', 'nav a', 'footer p', 'footer a',
  ];
  for (const route of PAGES) {
    await withPage(route, {}, async ({ page }) => {
      const results = await contrastRatios(page, selectors);
      assert.ok(results.length > 0, `${route} has no measured text`);
      const failing = results.filter((r) => r.ratio < 4.5);
      assert.deepStrictEqual(failing, [], `${route} low contrast`);
    });
  }
});

test('AC10 every tab stop shows a visible focus style, and tab order never reaches hidden content', async () => {
  for (const route of PAGES) {
    await withPage(route, {}, async ({ page }) => {
      const stops = await keyboardStops(page);
      assert.ok(stops.length >= 4, `${route} has only ${stops.length} tab stops`);
      for (const stop of stops) {
        assert.ok(stop.focusVisible && stop.outline, `${route} ${stop.label} has no visible focus`);
        assert.ok(stop.rendered && !stop.inHidden, `${route} tab stop ${stop.label} is hidden`);
        assert.ok(stop.tabIndex >= 0, `${route} ${stop.label} is tabindex -1 but reachable`);
      }
    });
  }
});

test('AC10 headings never skip a level, images have alt text, and no positive tabindex', async () => {
  for (const route of PAGES) {
    await withPage(route, {}, async ({ page }) => {
      const info = await page.evaluate(() => ({
        levels: [...document.querySelectorAll('main h1, main h2, main h3, main h4, main h5, main h6')]
          .map((h) => Number(h.tagName.slice(1))),
        imagesWithoutAlt: [...document.querySelectorAll('img')].filter((img) => !img.hasAttribute('alt')).length,
        positiveTabindex: [...document.querySelectorAll('[tabindex]')].filter((el) => Number(el.getAttribute('tabindex')) > 0).length,
      }));
      assert.strictEqual(info.levels[0], 1, `${route} first heading in main is not the h1`);
      for (let i = 1; i < info.levels.length; i += 1) {
        assert.ok(info.levels[i] <= info.levels[i - 1] + 1, `${route} heading level jumps to h${info.levels[i]}`);
      }
      assert.strictEqual(info.imagesWithoutAlt, 0, `${route} has images without alt`);
      assert.strictEqual(info.positiveTabindex, 0, `${route} has a positive tabindex`);
    });
  }
});

test('AC10 text resized to 200% keeps the 360px layout free of sideways scrolling', async () => {
  for (const route of PAGES) {
    await withPage(route, { width: 360 }, async ({ page }) => {
      await page.evaluate(() => {
        document.documentElement.style.fontSize = '200%';
      });
      const sizes = await page.evaluate(() => ({ scroll: document.documentElement.scrollWidth, inner: window.innerWidth }));
      assert.ok(sizes.scroll <= sizes.inner, `${route} overflows at 200% text: ${sizes.scroll} > ${sizes.inner}`);
    });
  }
});

test('AC10 no animations or transitions run, so reduced motion is respected', async () => {
  for (const route of PAGES) {
    await withPage(route, {}, async ({ page }) => {
      await page.emulateMedia({ reducedMotion: 'reduce' });
      const moving = await page.evaluate(() => [...document.querySelectorAll('body *')]
        .filter((el) => getComputedStyle(el).animationName !== 'none' || getComputedStyle(el).transitionDuration !== '0s')
        .map((el) => el.tagName));
      assert.deepStrictEqual(moving, [], `${route} animates`);
    });
  }
});

// ---------------------------------------------------------------- AC11

test('AC11 home has an intro, featured books linking to filtered catalogue, next events and hours linking to visit', async () => {
  await withPage('index.html', {}, async ({ page }) => {
    const intro = await page.$$eval('main > p', (nodes) => nodes.map((n) => n.textContent.trim()).filter((t) => t.length > 80));
    assert.ok(intro.length >= 1, 'no real intro paragraph');
    const featured = await page.$$eval('#featured-list a[href^="books.html?genre="]', (nodes) => nodes.map((n) => n.getAttribute('href')));
    assert.ok(featured.length >= 2, `only ${featured.length} featured book links`);
    const next = await page.$$eval('#next-events time', (nodes) => nodes.map((n) => n.getAttribute('datetime')));
    assert.ok(next.length >= 1, 'no upcoming event on home');
    assert.ok(next[0].startsWith('2026-11-17'), `next event should be today, got ${next[0]}`);
    assert.ok((await page.locator('main a[href="visit.html"]').count()) >= 1, 'no link to visit');
    assert.match(await page.textContent('#home-hours'), /Tallow Street/);
    await page.locator('#featured-list a').first().click();
    await page.waitForURL(/books\.html\?genre=/);
    const genres = await shownGenres(page);
    assert.ok(genres.length > 0 && new Set(genres).size === 1, 'featured link did not filter the catalogue');
  });
});

// ---------------------------------------------------------------- AC12

test('AC11 with no upcoming events, home shows a plain message and a link to events, not an empty list', async () => {
  await withPage('index.html', { now: '2027-06-01T12:00:00-07:00' }, async ({ page, log }) => {
    assert.strictEqual(await page.locator('#next-events > li').count(), 0, 'empty list still has items');
    assert.strictEqual(await page.isVisible('#next-events'), false, 'empty list is still shown');
    assert.strictEqual(await page.isVisible('#next-empty'), true, 'empty message is hidden');
    assert.strictEqual(await page.textContent('#next-empty'), 'No events scheduled right now. Check back soon.');
    assert.strictEqual(await page.isVisible('section[aria-labelledby="coming-up-heading"] a[href="events.html"]'), true, 'no link to events');
    assert.deepStrictEqual(log.errors, []);
  });
});

test('AC12 no console errors, uncaught exceptions or local responses of 400+ once the network settles', async () => {
  for (const route of PAGES) {
    await withPage(route, {}, async ({ page, log }) => {
      await exercise(route, page);
      await page.waitForLoadState('networkidle');
      await page.waitForTimeout(300);
      assert.deepStrictEqual(log.errors, [], `${route} console errors`);
      assert.deepStrictEqual(log.responses.filter((r) => r.status >= 400), [], `${route} failed responses`);
    });
  }
});

test('AC12 every page links a local SVG favicon that is served, so the browser never asks for a missing favicon', async () => {
  for (const route of PAGES) {
    await withPage(route, {}, async ({ page, log }) => {
      const icons = await page.$$eval('link[rel="icon"]', (nodes) => nodes.map((n) => ({ href: n.getAttribute('href'), type: n.getAttribute('type') })));
      assert.deepStrictEqual(icons, [{ href: 'favicon.svg', type: 'image/svg+xml' }], `${route} favicon link`);
      await page.waitForLoadState('networkidle');
      assert.deepStrictEqual(log.responses.filter((r) => r.status >= 400), [], `${route} favicon or asset missing`);
    });
  }
  const response = await fetch(base + 'favicon.svg');
  assert.strictEqual(response.status, 200, 'favicon.svg not served');
  assert.strictEqual(response.headers.get('content-type'), 'image/svg+xml');
});

// ---------------------------------------------------------------- AC13

test('AC13 README explains how to run the site locally and how to run the tests', async () => {
  const readme = fs.readFileSync(path.join(ROOT, 'README.md'), 'utf8');
  assert.ok(/http-server|http\.server/.test(readme), 'no local static server command');
  assert.ok(readme.includes('tests/site.test.cjs'), 'no test command');
  assert.ok(readme.includes('NODE_PATH'), 'no NODE_PATH instruction');
});

test('AC13 README says where content lives, without claiming all of it is in data.js', async () => {
  const readme = fs.readFileSync(path.join(ROOT, 'README.md'), 'utf8');
  assert.ok(!/all content/i.test(readme), 'README still says all content is in data.js');
  assert.match(readme, /addresses?[^.]*HTML|HTML[^.]*addresses?/i, 'README does not say addresses live in the HTML');
});

// ---------------------------------------------------------------- AC14 and triggered focus checks

test('AC14 the test suite serves its own pages and drives headless Chrome', async () => {
  assert.ok(base.startsWith('http://127.0.0.1:'), 'suite did not start its own local server');
  const browserName = browser.version();
  assert.ok(browserName.length > 0, 'no browser version');
});

test('FOCUS no overlay, menu or modal exists, so nothing traps focus or needs Escape', async () => {
  for (const route of PAGES) {
    await withPage(route, {}, async ({ page }) => {
      const layers = await page.$$eval('dialog, [role="dialog"], [role="menu"], [aria-modal="true"]', (nodes) => nodes.length);
      assert.strictEqual(layers, 0, `${route} has an overlay layer`);
    });
  }
});

test('FOCUS focus moves on submit and skip link stay inside the page after keyboard use', async () => {
  await withPage('visit.html', {}, async ({ page }) => {
    await page.fill('#name', 'Ada');
    await page.fill('#email', 'nope');
    await page.focus('#message');
    await page.keyboard.press('Tab');
    await page.keyboard.press('Enter');
    assert.strictEqual(await page.evaluate(() => document.activeElement.id), 'email', 'focus did not move to the first invalid field');
    const stops = await keyboardStops(page);
    assert.ok(stops.every((s) => s.rendered && !s.inHidden), 'focus reached hidden content');
  });
});

// ---------------------------------------------------------------- runner

async function main() {
  const grepAt = process.argv.indexOf('--grep');
  const filter = grepAt === -1 ? null : process.argv[grepAt + 1];
  const selected = tests.filter((t) => !filter || t.name.includes(filter));
  if (selected.length === 0) {
    console.error(`No tests match "${filter}"`);
    process.exitCode = 1;
    return;
  }
  const server = await startServer();
  base = `http://127.0.0.1:${server.address().port}/`;
  browser = await chromium.launch({ executablePath: '/usr/bin/google-chrome', headless: true });
  let failed = 0;
  try {
    for (const t of selected) {
      try {
        await t.fn();
        console.log(`ok    ${t.name}`);
      } catch (error) {
        failed += 1;
        const detail = String(error.message).split('\n').slice(0, 4).join('\n        ');
        console.log(`FAIL  ${t.name}\n        ${detail}`);
      }
    }
  } finally {
    await browser.close();
    server.closeAllConnections();
    server.close();
  }
  console.log(`\n${selected.length - failed} passed, ${failed} failed`);
  process.exitCode = failed === 0 ? 0 : 1;
}

main().catch((error) => {
  console.error(error);
  process.exitCode = 1;
});

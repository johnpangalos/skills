'use strict';

// Entry point for `node --test tests/`. Node 22 runs a directory argument as a module,
// so this file loads every suite and the runner executes them all in one process.
require('./structure.test.js');
require('./books.test.js');
require('./events.test.js');
require('./visit.test.js');
require('./contact.test.js');
require('./layout.test.js');
require('./network.test.js');

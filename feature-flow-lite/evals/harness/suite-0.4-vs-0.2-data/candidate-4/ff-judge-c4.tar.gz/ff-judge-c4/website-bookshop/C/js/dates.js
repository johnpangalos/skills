// Date helpers shared by the home and events pages.
// Dates are parsed from their parts so they are read as the user's local day, never as UTC midnight.
(function () {
  'use strict';

  var DAYS = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
  var MONTHS = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];

  function pad(n) {
    return n < 10 ? '0' + n : String(n);
  }

  // Splits 'YYYY-MM-DD' or 'YYYY-MM-DDTHH:MM' into numeric parts.
  function parts(stamp) {
    var halves = stamp.split('T');
    var date = halves[0].split('-').map(Number);
    var time = halves[1] ? halves[1].split(':').map(Number) : [0, 0];
    return { year: date[0], month: date[1] - 1, day: date[2], hour: time[0], minute: time[1] };
  }

  // The user's local calendar day as 'YYYY-MM-DD'.
  function dayKey(date) {
    return date.getFullYear() + '-' + pad(date.getMonth() + 1) + '-' + pad(date.getDate());
  }

  function formatDay(stamp) {
    var p = parts(stamp);
    var weekday = DAYS[new Date(p.year, p.month, p.day).getDay()];
    return weekday + ' ' + p.day + ' ' + MONTHS[p.month] + ' ' + p.year;
  }

  function formatTime(stamp) {
    var p = parts(stamp);
    var hour = p.hour % 12 || 12;
    return hour + ':' + pad(p.minute) + (p.hour < 12 ? 'am' : 'pm');
  }

  function formatWhen(stamp) {
    return formatDay(stamp) + ', ' + formatTime(stamp);
  }

  // Events on or after today's local day, earliest first. An event dated today counts as upcoming.
  function upcoming(events) {
    var today = dayKey(new Date());
    return events
      .filter(function (event) { return event.start.slice(0, 10) >= today; })
      .sort(function (a, b) { return a.start < b.start ? -1 : 1; });
  }

  window.MarginaliaDates = {
    formatWhen: formatWhen,
    upcoming: upcoming,
  };
})();

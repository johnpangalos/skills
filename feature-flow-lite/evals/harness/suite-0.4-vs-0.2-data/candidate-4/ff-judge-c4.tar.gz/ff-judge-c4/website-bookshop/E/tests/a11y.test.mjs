// Criterion 10: keyboard order, visible focus, contrast, decorative graphics, motion, affordances.
import assert from 'node:assert/strict';
import { PAGES, auditContrast, contrastRatio } from './helpers.mjs';

const TEXT_SELECTORS = [
  'main p', 'main h1', 'main h2', 'main h3', 'main a', 'main button', 'main label', 'main th', 'main td',
  'main caption', 'nav a', 'nav button', '[aria-current="page"]', 'header .brand', 'footer', 'footer a',
  '.skip-link',
];

async function tabTo(page, selector, limit = 60) {
  for (let i = 0; i < limit; i += 1) {
    await page.keyboard.press('Tab');
    if (await page.evaluate((sel) => document.activeElement.matches(sel), selector)) return;
  }
  throw new Error(`Tab never reached ${selector}`);
}

async function focusStyle(page) {
  return page.evaluate(() => {
    const el = document.activeElement;
    const cs = getComputedStyle(el);
    return {
      visible: el.matches(':focus-visible'),
      style: cs.outlineStyle,
      width: parseFloat(cs.outlineWidth),
      color: cs.outlineColor,
      bg: (() => {
        for (let node = el; node; node = node.parentElement) {
          const c = getComputedStyle(node).backgroundColor;
          if (!/rgba\(\s*\d+,\s*\d+,\s*\d+,\s*0\)|transparent/.test(c)) return c;
        }
        return 'rgb(255, 255, 255)';
      })(),
    };
  });
}

function rgb(text) {
  return text.match(/\d+(\.\d+)?/g).slice(0, 3).map(Number);
}

export const tests = [
  {
    name: 'criterion 10: every control on the visit form is reachable by Tab in logical order',
    async run(ctx) {
      const { page } = await ctx.open();
      await page.goto(ctx.url('visit.html'));
      const order = [];
      for (let i = 0; i < 80; i += 1) {
        await page.keyboard.press('Tab');
        const id = await page.evaluate(() => document.activeElement.id || document.activeElement.textContent.trim());
        order.push(id);
        if (id === 'Send message') break;
      }
      const seen = ['name', 'email', 'subject', 'message', 'Send message'].map((id) => order.indexOf(id));
      assert.ok(seen.every((n) => n >= 0), `all fields reachable, saw ${order.join(', ')}`);
      assert.deepEqual(seen, [...seen].sort((a, b) => a - b), 'fields are reached in reading order');
    },
  },
  {
    name: 'criterion 10: a visible focus style shows on links, buttons and form fields',
    async run(ctx) {
      const { page } = await ctx.open();
      await page.goto(ctx.url('visit.html'));
      await tabTo(page, 'a[href="index.html"]');
      let f = await focusStyle(page);
      assert.equal(f.visible, true, 'link matches :focus-visible');
      assert.ok(f.style !== 'none' && f.width >= 2, `link outline ${f.style} ${f.width}px`);
      assert.ok(contrastRatio(rgb(f.color), rgb(f.bg)) >= 3, 'focus ring contrast at least 3:1');
      await tabTo(page, '#name');
      f = await focusStyle(page);
      assert.ok(f.visible && f.style !== 'none' && f.width >= 2, 'form field focus ring');
      await tabTo(page, 'button[type="submit"]');
      f = await focusStyle(page);
      assert.ok(f.visible && f.style !== 'none' && f.width >= 2, 'button focus ring');
    },
  },
  {
    name: 'criterion 10: text, links, buttons, current nav item, error text and focus ring meet contrast on every page',
    async run(ctx) {
      const { page } = await ctx.open();
      for (const file of PAGES) {
        await page.goto(ctx.url(file));
        const pairs = await auditContrast(page, TEXT_SELECTORS);
        assert.ok(pairs.length > 10, `${file} should have measurable text`);
        for (const pair of pairs) {
          assert.ok(pair.ratio >= 4.5, `${file}: "${pair.text}" (${pair.sel}) contrast ${pair.ratio.toFixed(2)}:1`);
        }
      }
      await page.goto(ctx.url('visit.html'));
      await page.locator('#contact-form button[type="submit"]').click();
      const errors = await auditContrast(page, ['.field-error']);
      assert.ok(errors.length >= 4, 'error messages shown');
      for (const pair of errors) assert.ok(pair.ratio >= 4.5, `error text contrast ${pair.ratio.toFixed(2)}:1`);
    },
  },
  {
    name: 'criterion 10: the nav menu button meets contrast when collapsed at 360px',
    async run(ctx) {
      const { page } = await ctx.open({ viewport: { width: 360, height: 740 } });
      await page.goto(ctx.url('books.html'));
      await page.getByRole('button', { name: 'Menu' }).click();
      const pairs = await auditContrast(page, ['nav button', 'nav a', '.skip-link', 'main h1']);
      assert.ok(pairs.length >= 6, `menu button and open menu links are measured (${pairs.length})`);
      for (const pair of pairs) assert.ok(pair.ratio >= 4.5, `${pair.sel} "${pair.text}" ${pair.ratio.toFixed(2)}:1`);
    },
  },
  {
    name: 'criterion 10: decorative SVG is hidden from assistive technology and every image has alt text',
    async run(ctx) {
      const { page } = await ctx.open();
      let svgs = 0;
      for (const file of PAGES) {
        await page.goto(ctx.url(file));
        const audit = await page.evaluate(() => ({
          svgs: Array.from(document.querySelectorAll('svg')).map((s) => s.getAttribute('aria-hidden')),
          imgsWithoutAlt: Array.from(document.querySelectorAll('img')).filter((i) => !i.hasAttribute('alt')).length,
        }));
        svgs += audit.svgs.length;
        assert.deepEqual(audit.svgs.filter((v) => v !== 'true'), [], `${file} has an SVG not aria-hidden`);
        assert.equal(audit.imgsWithoutAlt, 0, `${file} has an image without alt`);
      }
      assert.ok(svgs >= 1, 'the site uses at least one decorative SVG for this check to mean something');
    },
  },
  {
    name: 'criterion 10: transitions are removed when the user prefers reduced motion',
    async run(ctx) {
      const motion = async (reducedMotion) => {
        const { page } = await ctx.open({ reducedMotion });
        await page.goto(ctx.url('visit.html'));
        return page.evaluate(() => parseFloat(getComputedStyle(document.querySelector('#contact-form button[type="submit"]')).transitionDuration));
      };
      assert.ok((await motion('no-preference')) > 0, 'button has a transition by default');
      assert.equal(await motion('reduce'), 0, 'transition removed under prefers-reduced-motion: reduce');
    },
  },
  {
    name: 'criterion 10: nothing looks clickable unless it is a link, button or form control',
    async run(ctx) {
      const { page } = await ctx.open();
      for (const file of PAGES) {
        await page.goto(ctx.url(file));
        const offenders = await page.evaluate(() => Array.from(document.querySelectorAll('body *'))
          .filter((el) => getComputedStyle(el).cursor === 'pointer')
          .filter((el) => !el.closest('a[href], button, select, input, textarea, label, summary'))
          .map((el) => el.tagName.toLowerCase() + '.' + el.className));
        assert.deepEqual(offenders, [], `${file} shows a pointer cursor on non-controls`);
      }
    },
  },
];

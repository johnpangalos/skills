// Home page: fills in the staff picks and the next upcoming event from the shared data.
(function () {
  'use strict';

  var picks = document.getElementById('staff-picks');
  var next = document.getElementById('next-event');
  var dates = window.MarginaliaDates;

  function createPick(book) {
    var item = document.createElement('li');
    item.className = 'card';

    var title = document.createElement('p');
    var link = document.createElement('a');
    link.href = 'books.html';
    link.textContent = book.title;
    title.appendChild(link);

    var meta = document.createElement('p');
    meta.textContent = 'by ' + book.author + ' · £' + book.price.toFixed(2);

    item.append(title, meta);
    return item;
  }

  if (picks && window.MARGINALIA_BOOKS) {
    var featured = window.MARGINALIA_BOOKS.filter(function (book) { return book.featured; });
    picks.replaceChildren.apply(picks, featured.map(createPick));
  }

  if (next && dates) {
    var event = dates.upcoming(window.MARGINALIA_EVENTS || [])[0];
    next.textContent = '';
    if (event) {
      var link = document.createElement('a');
      link.href = 'events.html';
      link.textContent = event.title;
      next.append(link, ' on ' + dates.formatWhen(event.start) + '.');
    } else {
      next.textContent = 'There are no upcoming events at the moment. Please check back soon.';
    }
  }
})();

'use strict';

const { test, before, after } = require('node:test');
const assert = require('node:assert/strict');
const { startSite, launchBrowser, openSite, closeContexts } = require('./helpers');

const PAGES = ['index.html', 'books.html', 'events.html', 'visit.html'];

let site;
let browser;

before(async () => {
  site = await startSite();
  browser = await launchBrowser();
});

after(async () => {
  await closeContexts();
  await browser.close();
  await site.close();
});

// Criterion 11: body text and links reach 4.5:1 against their background.
test('body text and links have at least 4.5:1 contrast on every page (criterion 11)', async () => {
  for (const file of PAGES) {
    const { page } = await openSite(browser, site.origin, file);
    const failures = await page.evaluate(() => {
      const parse = (value) => value.match(/[\d.]+/g).slice(0, 3).map(Number);
      const luminance = ([r, g, b]) => {
        const [R, G, B] = [r, g, b].map((c) => {
          const s = c / 255;
          return s <= 0.03928 ? s / 12.92 : Math.pow((s + 0.055) / 1.055, 2.4);
        });
        return 0.2126 * R + 0.7152 * G + 0.0722 * B;
      };
      const background = (el) => {
        for (let node = el; node; node = node.parentElement) {
          const value = getComputedStyle(node).backgroundColor;
          if (value && !/rgba\(.*,\s*0\)$/.test(value) && value !== 'transparent') return parse(value);
        }
        return [255, 255, 255];
      };
      const selector = 'main p, main li, main a, main label, main td, main th, main h1, main h2, main h3, main legend, main caption, nav a, footer p, footer a, footer li';
      const bad = [];
      let checked = 0;
      for (const el of document.querySelectorAll(selector)) {
        if (el.getClientRects().length === 0 || !el.textContent.trim()) continue;
        checked++;
        const fg = parse(getComputedStyle(el).color);
        const bg = background(el);
        const [hi, lo] = [luminance(fg), luminance(bg)].sort((a, b) => b - a);
        const ratio = (hi + 0.05) / (lo + 0.05);
        if (ratio < 4.5) bad.push(`${el.tagName} "${el.textContent.trim().slice(0, 30)}" ${ratio.toFixed(2)}`);
      }
      return { checked, bad };
    });
    assert.ok(failures.checked >= 20, `${file} checked ${failures.checked} text elements`);
    assert.deepEqual(failures.bad, [], file);
  }
});

// Criterion 11: visible focus indicator on every interactive element reached by keyboard.
test('every element reached by Tab has a visible :focus-visible outline (criterion 11)', async () => {
  for (const file of PAGES) {
    const { page } = await openSite(browser, site.origin, file);
    const reached = [];
    const problems = [];
    for (let i = 0; i < 60; i++) {
      await page.keyboard.press('Tab');
      const state = await page.evaluate(() => {
        const el = document.activeElement;
        const style = getComputedStyle(el);
        return {
          label: el.tagName + ':' + (el.textContent.trim().slice(0, 25) || el.id || el.name),
          focusVisible: el.matches(':focus-visible'),
          outline: style.outlineStyle !== 'none' && parseFloat(style.outlineWidth) > 0,
        };
      });
      if (state.label.startsWith('BODY') || (reached.length && reached[0] === state.label)) break;
      reached.push(state.label);
      if (!state.focusVisible || !state.outline) problems.push(state.label);
    }
    assert.ok(reached.length >= 5, `${file} keyboard stops: ${reached.length}`);
    assert.deepEqual(problems, [], file);
  }
});

// Criterion 11: heading levels never skip.
test('heading levels never skip and each page has one h1 (criterion 11)', async () => {
  for (const file of PAGES) {
    const { page } = await openSite(browser, site.origin, file);
    const levels = await page.$$eval('h1, h2, h3, h4, h5, h6', (hs) => hs.map((h) => Number(h.tagName[1])));
    assert.equal(levels[0], 1, `${file} starts at h1`);
    assert.equal(levels.filter((l) => l === 1).length, 1, `${file} one h1`);
    for (let i = 1; i < levels.length; i++) {
      assert.ok(levels[i] <= levels[i - 1] + 1, `${file} heading ${i} jumps from h${levels[i - 1]} to h${levels[i]}`);
    }
  }
});

// Criterion 11: no animation or transition runs (so reduced motion has nothing to override).
test('no CSS animation or transition runs unless reduced motion is respected (criterion 11)', async () => {
  for (const file of PAGES) {
    const { page } = await openSite(browser, site.origin, file);
    const moving = await page.evaluate(() => [...document.querySelectorAll('*')]
      .filter((el) => {
        const style = getComputedStyle(el);
        return style.animationName !== 'none' || parseFloat(style.transitionDuration) > 0;
      })
      .map((el) => el.tagName));
    assert.deepEqual(moving, [], file);
  }
});

// Criterion 12: no external requests, no console errors, every page loads cleanly.
test('every page makes requests only to the local origin with no errors (criterion 12)', async () => {
  for (const file of PAGES) {
    const { page, log } = await openSite(browser, site.origin, file);
    await page.waitForLoadState('networkidle');
    const foreign = log.requests.filter((url) => !url.startsWith(site.origin + '/'));
    assert.deepEqual(foreign, [], `${file} foreign requests`);
    assert.deepEqual(log.failed, [], `${file} failed responses`);
    assert.deepEqual(log.consoleErrors, [], `${file} console errors`);
    assert.deepEqual(log.pageErrors, [], `${file} page errors`);
  }
});

test('no element points at an http(s) or protocol-relative URL, and fonts are system stacks (criterion 12)', async () => {
  for (const file of PAGES) {
    const { page } = await openSite(browser, site.origin, file);
    const remote = await page.evaluate(() => [...document.querySelectorAll('[src], [href]')]
      .map((el) => el.getAttribute('src') || el.getAttribute('href'))
      .filter((value) => /^(https?:)?\/\//i.test(value)));
    assert.deepEqual(remote, [], file);
    const webFonts = await page.evaluate(() => document.fonts.size);
    assert.equal(webFonts, 0, `${file} web fonts`);
  }
});

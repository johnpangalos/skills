// Criterion 9: contact form labels, validation, focus, demo message, no network on submit.
import assert from 'node:assert/strict';

const FIELDS = ['name', 'email', 'subject', 'message'];
const VALID = { name: 'Ada Lovelace', email: 'ada@example.com', subject: 'Book order', message: 'Do you have the Glass Hour in hardback?' };

async function fill(page, values) {
  for (const [id, value] of Object.entries(values)) {
    await page.fill(`#${id}`, value);
  }
}

async function fieldState(page, id) {
  return page.evaluate((fid) => {
    const field = document.getElementById(fid);
    const describedBy = field.getAttribute('aria-describedby');
    const error = describedBy ? document.getElementById(describedBy) : null;
    return {
      invalid: field.getAttribute('aria-invalid'),
      describedBy,
      errorText: error ? error.textContent.trim() : '',
      errorVisible: error ? !error.hidden : false,
    };
  }, id);
}

async function statusText(page) {
  return page.evaluate(() => document.getElementById('form-status').textContent.trim());
}

// The status message is set a moment after submit so screen readers announce repeats.
async function waitForStatus(page) {
  await page.waitForFunction(() => document.getElementById('form-status').textContent.trim() !== '');
}

export const tests = [
  {
    name: 'criterion 9: every field has a programmatic label and required fields are marked in the text',
    async run(ctx) {
      const { page } = await ctx.open();
      await page.goto(ctx.url('visit.html'));
      for (const id of FIELDS) {
        const labels = await page.evaluate((fid) => Array.from(document.getElementById(fid).labels).map((l) => l.textContent), id);
        assert.equal(labels.length, 1, `${id} needs exactly one label`);
        assert.match(labels[0], /\(required\)/, `${id} label marks it required in text`);
      }
      assert.equal(await page.evaluate(() => document.getElementById('contact-form').noValidate), true, 'form uses novalidate');
    },
  },
  {
    name: 'criterion 9: submitting empty required fields marks each invalid, describes it and focuses the first one',
    async run(ctx) {
      const { page } = await ctx.open();
      await page.goto(ctx.url('visit.html'));
      await page.locator('#contact-form button[type="submit"]').click();
      for (const id of FIELDS) {
        const state = await fieldState(page, id);
        assert.equal(state.invalid, 'true', `${id} aria-invalid`);
        assert.ok(state.describedBy, `${id} needs aria-describedby`);
        assert.ok(state.errorText.length > 0 && state.errorVisible, `${id} error message visible and linked`);
      }
      assert.equal(await page.evaluate(() => document.activeElement.id), 'name', 'focus moves to the first invalid field');
    },
  },
  {
    name: 'criterion 9: an error clears as soon as its field is fixed',
    async run(ctx) {
      const { page } = await ctx.open();
      await page.goto(ctx.url('visit.html'));
      await page.locator('#contact-form button[type="submit"]').click();
      await page.fill('#name', 'Ada');
      const state = await fieldState(page, 'name');
      assert.equal(state.invalid, 'false');
      assert.equal(state.describedBy, null);
      assert.equal(state.errorVisible, false);
    },
  },
  {
    name: 'criterion 9 hostile: whitespace-only name and message are invalid',
    async run(ctx) {
      const { page } = await ctx.open();
      await page.goto(ctx.url('visit.html'));
      await fill(page, { ...VALID, name: '     ', message: '\n \t  \n' });
      await page.locator('#contact-form button[type="submit"]').click();
      assert.equal((await fieldState(page, 'name')).invalid, 'true');
      assert.equal((await fieldState(page, 'message')).invalid, 'true');
      assert.equal(await statusText(page), '', 'no demo message for invalid input');
    },
  },
  {
    name: 'criterion 9 hostile: malformed email addresses are rejected and a well-formed one is accepted',
    async run(ctx) {
      const { page } = await ctx.open();
      await page.goto(ctx.url('visit.html'));
      for (const bad of ['a@', 'a@b', '@b.com', 'a b@c.com']) {
        await fill(page, { ...VALID, email: bad });
        await page.locator('#contact-form button[type="submit"]').click();
        assert.equal((await fieldState(page, 'email')).invalid, 'true', `"${bad}" should be invalid`);
        assert.equal(await statusText(page), '', `"${bad}" must not show a success message`);
      }
      await fill(page, { ...VALID, email: 'ada@example.com' });
      await page.locator('#contact-form button[type="submit"]').click();
      assert.equal((await fieldState(page, 'email')).invalid, 'false', 'well-formed email accepted');
    },
  },
  {
    name: 'criterion 9 hostile: a 5000-character message is accepted',
    async run(ctx) {
      const { page } = await ctx.open();
      await page.goto(ctx.url('visit.html'));
      await fill(page, { ...VALID, message: 'a'.repeat(5000) });
      await page.locator('#contact-form button[type="submit"]').click();
      await waitForStatus(page);
      assert.equal((await fieldState(page, 'message')).invalid, 'false');
      assert.match(await statusText(page), /demo/i);
    },
  },
  {
    name: 'criterion 9: pressing Enter in a field submits and validates the form',
    async run(ctx) {
      const { page } = await ctx.open();
      await page.goto(ctx.url('visit.html'));
      await page.fill('#name', 'Ada');
      await page.focus('#name');
      await page.keyboard.press('Enter');
      assert.equal((await fieldState(page, 'email')).invalid, 'true', 'Enter submitted and flagged the empty email');
      assert.equal(await page.evaluate(() => document.activeElement.id), 'email', 'focus moves to first invalid field');
    },
  },
  {
    name: 'criterion 9: a valid submit says plainly the demo did not send the message, with no network request',
    async run(ctx) {
      const { page, requests } = await ctx.open();
      await page.goto(ctx.url('visit.html'));
      await fill(page, VALID);
      const before = requests.length;
      const urlBefore = page.url();
      await page.locator('#contact-form button[type="submit"]').click();
      await page.waitForTimeout(400);
      const status = page.getByRole('status');
      assert.equal(await status.count(), 1, 'one status region');
      const text = await statusText(page);
      assert.match(text, /demo/i);
      assert.match(text, /wasn.t sent|was not sent/i);
      assert.doesNotMatch(text, /(has been|was|been) sent|thank you for (your|writing)|we('ve| have) received/i);
      assert.equal(requests.length, before, 'submit made no network request');
      assert.equal(page.url(), urlBefore, 'submit did not navigate');
    },
  },
  {
    name: 'criterion 9 hostile: submitting twice does not duplicate the status message',
    async run(ctx) {
      const { page } = await ctx.open();
      await page.goto(ctx.url('visit.html'));
      await fill(page, VALID);
      await page.locator('#contact-form button[type="submit"]').click();
      await page.locator('#contact-form button[type="submit"]').click();
      await waitForStatus(page);
      const text = await statusText(page);
      assert.equal(text.match(/demo/gi).length, 1, 'demo message appears once');
      assert.equal(await page.evaluate(() => document.querySelectorAll('#form-status').length), 1);
    },
  },
  {
    name: 'finding 2: with JavaScript off the send button is disabled, so Enter and clicks leave the URL alone',
    async run(ctx) {
      const { page } = await ctx.open({ javaScriptEnabled: false });
      await page.goto(ctx.url('visit.html'));
      const urlBefore = page.url();
      await fill(page, VALID);
      const send = page.locator('#contact-form button[type="submit"]');
      assert.equal(await send.isDisabled(), true, 'send button is disabled without JavaScript');
      await page.focus('#subject');
      await page.keyboard.press('Enter');
      await send.click({ force: true });
      await page.waitForTimeout(400);
      assert.equal(page.url(), urlBefore, 'typed data must not appear in the URL');
    },
  },
  {
    name: 'finding 2: the form note says nothing is sent whether or not JavaScript runs',
    async run(ctx) {
      for (const javaScriptEnabled of [true, false]) {
        const { page } = await ctx.open({ javaScriptEnabled });
        await page.goto(ctx.url('visit.html'));
        const note = await page.locator('.form-note').innerText();
        assert.match(note, /nothing you type here is sent/i, `form note with JavaScript ${javaScriptEnabled ? 'on' : 'off'}`);
      }
    },
  },
  {
    name: 'finding 5: emails with consecutive dots or a dot at the edge of a part are rejected, ordinary dotted emails accepted',
    async run(ctx) {
      const { page } = await ctx.open();
      await page.goto(ctx.url('visit.html'));
      for (const bad of ['a@b..c', 'a..b@c.com', '.a@b.com', 'a.@b.com', 'a@.b.com', 'a@b.com.', 'a@b.c..']) {
        await fill(page, { ...VALID, email: bad });
        await page.locator('#contact-form button[type="submit"]').click();
        assert.equal((await fieldState(page, 'email')).invalid, 'true', `"${bad}" should be invalid`);
        assert.equal(await statusText(page), '', `"${bad}" must not show a success message`);
      }
      for (const good of ['first.last@example.co.uk', 'ada+books@example.com']) {
        await fill(page, { ...VALID, email: good });
        await page.locator('#contact-form button[type="submit"]').click();
        assert.equal((await fieldState(page, 'email')).invalid, 'false', `"${good}" should be accepted`);
      }
    },
  },
  {
    name: 'finding 7: a repeat valid submit clears the status, then sets the same message again in one element',
    async run(ctx) {
      const { page } = await ctx.open();
      await page.goto(ctx.url('visit.html'));
      await fill(page, VALID);
      await page.locator('#contact-form button[type="submit"]').click();
      await waitForStatus(page);
      await page.evaluate(() => {
        window.statusHistory = [];
        new MutationObserver(() => window.statusHistory.push(document.getElementById('form-status').textContent))
          .observe(document.getElementById('form-status'), { childList: true, characterData: true, subtree: true });
      });
      await page.locator('#contact-form button[type="submit"]').click();
      await page.waitForTimeout(300);
      const history = await page.evaluate(() => window.statusHistory);
      assert.ok(history.includes(''), `status should be cleared before it is set again, saw ${JSON.stringify(history)}`);
      assert.match(history[history.length - 1], /demo/i, 'the message is set again after the clear');
      assert.equal(await page.evaluate(() => document.querySelectorAll('#form-status').length), 1);
    },
  },
];

'use strict';

// Tiny static file server for the test suite. Serves the repository root on a random
// local port, with correct content types, and answers 404 for anything missing.

const http = require('node:http');
const fs = require('node:fs');
const path = require('node:path');

const ROOT = path.resolve(__dirname, '..');

const CONTENT_TYPES = {
  '.html': 'text/html; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.js': 'text/javascript; charset=utf-8',
  '.svg': 'image/svg+xml',
  '.png': 'image/png',
  '.ico': 'image/x-icon',
  '.json': 'application/json; charset=utf-8',
  '.txt': 'text/plain; charset=utf-8',
  '.md': 'text/markdown; charset=utf-8',
};

function sendNotFound(res) {
  res.writeHead(404, { 'Content-Type': 'text/plain; charset=utf-8' });
  res.end('Not found');
}

function resolveFile(rawPath) {
  let pathname;
  try {
    pathname = decodeURIComponent(rawPath);
  } catch (error) {
    return null;
  }
  // Refuse dot segments and dotfiles (such as .git and ..), so only the site itself is served.
  if (pathname.split('/').some((segment) => segment.startsWith('.'))) return null;
  if (pathname.endsWith('/')) pathname += 'index.html';
  const file = path.normalize(path.join(ROOT, pathname));
  if (!file.startsWith(ROOT + path.sep)) return null;
  return file;
}

function startServer() {
  const server = http.createServer((req, res) => {
    const file = resolveFile(new URL(req.url, 'http://localhost').pathname);
    if (!file) {
      sendNotFound(res);
      return;
    }
    fs.readFile(file, (error, data) => {
      if (error) {
        sendNotFound(res);
        return;
      }
      res.writeHead(200, {
        'Content-Type': CONTENT_TYPES[path.extname(file)] || 'application/octet-stream',
        'Cache-Control': 'no-store',
      });
      res.end(req.method === 'HEAD' ? undefined : data);
    });
  });

  return new Promise((resolve, reject) => {
    server.once('error', reject);
    server.listen(0, '127.0.0.1', () => {
      const { port } = server.address();
      resolve({
        url: `http://127.0.0.1:${port}`,
        close: () => new Promise((done) => server.close(done)),
      });
    });
  });
}

module.exports = { startServer, ROOT };

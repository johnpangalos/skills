'use strict';

const { test } = require('node:test');
const assert = require('node:assert/strict');
const { setupSuite, openTracked, visit } = require('./helpers');

const suite = setupSuite();

// Opens the events page with the browser clock and time zone set, and returns which
// section each listed event landed in.
async function openEvents({ now, timezoneId = 'UTC', viewport } = {}) {
  const t = await openTracked(suite, { now: now ? new Date(now) : undefined, timezoneId, viewport });
  await visit(t, `${suite.base}/events.html`);
  const listed = await t.page.evaluate(() =>
    [...document.querySelectorAll('#upcoming-list li.event, #past-list li.event')].map((item) => ({
      section: item.closest('#upcoming-list') ? 'upcoming' : 'past',
      name: item.querySelector('h3').textContent.trim(),
      datetime: item.querySelector('time').getAttribute('datetime'),
    })),
  );
  return { t, listed };
}

test('at least four events, each with name, time element with datetime, description and admission', async () => {
  const { t, listed } = await openEvents();
  assert.ok(listed.length >= 4, `expected 4+ events, got ${listed.length}`);
  const details = await t.page.$$eval('li.event', (items) =>
    items.map((item) => ({
      name: item.querySelector('h3')?.textContent.trim(),
      datetime: item.querySelector('time')?.getAttribute('datetime'),
      admission: item.querySelector('.event-admission')?.textContent.trim(),
      description: item.querySelector('.event-description')?.textContent.trim(),
    })),
  );
  for (const event of details) {
    assert.ok(event.name, 'name missing');
    assert.match(event.datetime, /^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}$/, `datetime for ${event.name}`);
    assert.match(event.admission, /Free|Ticketed|Booking/, `admission for ${event.name}`);
    assert.ok(event.description.length > 40, `description for ${event.name}`);
  }
  assert.deepEqual(t.problems, []);
  await t.context.close();
});

test('events are sorted by date within each section', async () => {
  const { t, listed } = await openEvents({ now: '2026-11-17T12:00:00Z' });
  const upcoming = listed.filter((event) => event.section === 'upcoming').map((event) => event.datetime);
  const past = listed.filter((event) => event.section === 'past').map((event) => event.datetime);
  assert.ok(upcoming.length >= 4);
  assert.deepEqual(upcoming, [...upcoming].sort());
  assert.deepEqual(past, [...past].sort());
  await t.context.close();
});

test('upcoming events extend well into 2027', async () => {
  const { t, listed } = await openEvents({ now: '2026-11-17T12:00:00Z' });
  assert.ok(listed.some((event) => event.section === 'upcoming' && event.datetime.startsWith('2027-')));
  await t.context.close();
});

test('past events sit in their own section and the upcoming section starts from today', async () => {
  const { t, listed } = await openEvents({ now: '2026-11-17T12:00:00Z' });
  const { page } = t;
  const past = listed.filter((event) => event.section === 'past');
  assert.ok(past.length >= 1, 'expected at least one past event');
  assert.ok(past.every((event) => event.datetime < '2026-11-17'));
  assert.equal(await page.locator('#past-section').isVisible(), true);
  assert.equal(await page.getByRole('heading', { name: 'Past events' }).count(), 1);
  const firstUpcoming = listed.find((event) => event.section === 'upcoming');
  assert.ok(firstUpcoming.datetime.startsWith('2026-11-21'), `first upcoming was ${firstUpcoming.datetime}`);
  await t.context.close();
});

// Day boundaries are local: an event on 2026-12-05 is upcoming for the whole of that local
// day and becomes past just after local midnight. Parsing with new Date('2026-12-05') would
// be UTC and wrong in these zones.
const BOUNDARY_CASES = [
  { timezoneId: 'Pacific/Auckland', now: '2026-12-05T00:01:00+13:00', section: 'upcoming' },
  { timezoneId: 'Pacific/Auckland', now: '2026-12-05T23:59:00+13:00', section: 'upcoming' },
  { timezoneId: 'Pacific/Auckland', now: '2026-12-06T00:01:00+13:00', section: 'past' },
  { timezoneId: 'America/Los_Angeles', now: '2026-12-04T23:59:00-08:00', section: 'upcoming' },
  { timezoneId: 'America/Los_Angeles', now: '2026-12-05T23:59:00-08:00', section: 'upcoming' },
  { timezoneId: 'America/Los_Angeles', now: '2026-12-06T00:01:00-08:00', section: 'past' },
];

for (const boundary of BOUNDARY_CASES) {
  test(`2026-12-05 event is ${boundary.section} at ${boundary.now} in ${boundary.timezoneId}`, async () => {
    const { t, listed } = await openEvents(boundary);
    const event = listed.find((item) => item.datetime.startsWith('2026-12-05'));
    assert.ok(event, 'the 2026-12-05 event is listed');
    assert.equal(event.section, boundary.section);
    assert.deepEqual(t.problems, []);
    await t.context.close();
  });
}

test('when every event has passed, the upcoming section shows a plain no-upcoming message', async () => {
  const { t, listed } = await openEvents({ now: '2027-12-01T10:00:00Z' });
  const { page } = t;
  assert.equal(listed.filter((event) => event.section === 'upcoming').length, 0);
  const message = page.locator('#upcoming-empty');
  assert.equal(await message.isVisible(), true);
  assert.match(await message.textContent(), /no upcoming events/i);
  assert.equal(await page.getByRole('heading', { name: 'Upcoming events' }).isVisible(), true);
  assert.equal(await page.locator('#upcoming-list li').count(), 0);
  await t.context.close();
});

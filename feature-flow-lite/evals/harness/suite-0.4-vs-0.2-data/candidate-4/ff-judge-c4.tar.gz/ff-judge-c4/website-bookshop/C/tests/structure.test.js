'use strict';

const { test, before, after } = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const { chromium } = require('playwright');
const { startServer, ROOT } = require('./server');

const PAGES = [
  { file: 'index.html', label: 'Home' },
  { file: 'books.html', label: 'Books' },
  { file: 'events.html', label: 'Events' },
  { file: 'visit.html', label: 'Visit' },
];

let server;
let browser;

before(async () => {
  server = await startServer();
  browser = await chromium.launch();
});

after(async () => {
  await browser.close();
  await server.close();
});

async function openPage(file) {
  const page = await browser.newPage();
  await page.goto(`${server.origin}/${file}`);
  return page;
}

test('the four pages are served from the repo root', async () => {
  for (const { file } of PAGES) {
    const res = await fetch(`${server.origin}/${file}`);
    assert.equal(res.status, 200, file);
  }
});

for (const { file } of PAGES) {
  test(`${file} has lang, landmarks, one h1 and no skipped heading levels`, async () => {
    const page = await openPage(file);
    const facts = await page.evaluate(() => ({
      lang: document.documentElement.lang,
      title: document.title,
      h1: document.querySelectorAll('h1').length,
      levels: [...document.querySelectorAll('h1, h2, h3, h4, h5, h6')].map((h) => Number(h.tagName.slice(1))),
      header: !!document.querySelector('body > header'),
      main: !!document.querySelector('main#main'),
      footer: !!document.querySelector('body > footer'),
      skip: !!document.querySelector('a[href="#main"]'),
    }));
    assert.equal(facts.lang, 'en');
    assert.ok(facts.title.length > 0, 'title is not empty');
    assert.equal(facts.h1, 1);
    assert.equal(facts.levels[0], 1, 'first heading is h1');
    facts.levels.forEach((level, i) => {
      if (i > 0) assert.ok(level <= facts.levels[i - 1] + 1, `h${level} follows a higher level skip`);
    });
    assert.ok(facts.header && facts.main && facts.footer && facts.skip);
    await page.close();
  });
}

test('page titles are unique across the four pages', async () => {
  const titles = [];
  for (const { file } of PAGES) {
    const page = await openPage(file);
    titles.push(await page.title());
    await page.close();
  }
  assert.equal(new Set(titles).size, PAGES.length, titles.join(' | '));
});

test('every page has the same main nav in order, with aria-current on the current page only', async () => {
  for (const { file, label } of PAGES) {
    const page = await openPage(file);
    const nav = page.getByRole('navigation', { name: 'Main' });
    const links = nav.getByRole('link');
    assert.deepEqual(await links.allTextContents(), ['Home', 'Books', 'Events', 'Visit'], file);
    assert.deepEqual(
      await links.evaluateAll((els) => els.map((el) => el.getAttribute('href'))),
      ['index.html', 'books.html', 'events.html', 'visit.html'],
      file,
    );
    assert.deepEqual(await nav.locator('[aria-current="page"]').allTextContents(), [label], file);
    await page.close();
  }
});

test('skip link is off-screen until focused, then visible, and Enter moves focus to main', async () => {
  const page = await openPage('books.html');
  const skip = page.getByRole('link', { name: 'Skip to main content' });
  const hidden = await skip.evaluate((el) => {
    const r = el.getBoundingClientRect();
    return r.right <= 0 || r.bottom <= 0;
  });
  assert.ok(hidden, 'skip link is off-screen before focus');
  await page.keyboard.press('Tab');
  assert.equal(await page.evaluate(() => document.activeElement.textContent.trim()), 'Skip to main content');
  const shown = await skip.evaluate((el) => {
    const r = el.getBoundingClientRect();
    return r.left >= 0 && r.top >= 0 && r.width > 0 && r.height > 0;
  });
  assert.ok(shown, 'skip link is on-screen when focused');
  await page.keyboard.press('Enter');
  assert.equal(await page.evaluate(() => document.activeElement.id), 'main');
  await page.close();
});

test('home page has an intro, staff picks, next event and visit details with real content', async () => {
  const page = await openPage('index.html');
  await page.waitForSelector('#staff-picks li');
  await page.waitForSelector('#next-event a');
  const main = page.locator('main');
  assert.ok((await main.locator('#staff-picks li').count()) >= 3, 'at least three staff picks');
  for (const href of ['books.html', 'events.html', 'visit.html']) {
    assert.ok((await main.locator(`a[href="${href}"]`).count()) >= 1, `links to ${href}`);
  }
  const expected = await page.evaluate(() => {
    const sorted = window.MARGINALIA_EVENTS.slice().sort((a, b) => (a.start < b.start ? -1 : 1));
    return sorted[0].title;
  });
  assert.equal(await page.locator('#next-event a').textContent(), expected);
  const sections = page.locator('main section');
  assert.ok((await sections.count()) >= 3, 'at least three sections');
  const lengths = await sections.evaluateAll((els) => els.map((el) => el.innerText.length));
  lengths.forEach((n) => assert.ok(n >= 100, `section too short: ${n} characters`));
  const text = (await main.innerText()).toLowerCase();
  assert.ok(!text.includes('lorem'), 'no lorem ipsum');
  await page.close();
});

test('README describes the site, how to run it, how to test it, and that the form is a demo', () => {
  const text = fs.readFileSync(path.join(ROOT, 'README.md'), 'utf8').toLowerCase();
  for (const phrase of ['python3 -m http.server', 'node --test tests/', 'demo']) {
    assert.ok(text.includes(phrase), `README mentions "${phrase}"`);
  }
});

'use strict';

const { test } = require('node:test');
const assert = require('node:assert/strict');
const { setupSuite, openTracked, visit, PAGES } = require('./helpers');

const suite = setupSuite();

const NAV = [
  { label: 'Home', href: 'index.html' },
  { label: 'Books', href: 'books.html' },
  { label: 'Events', href: 'events.html' },
  { label: 'Visit', href: 'visit.html' },
];

test('every page has the same four-link header nav with aria-current on its own link only', async () => {
  for (const pageName of PAGES) {
    const t = await openTracked(suite);
    await visit(t, `${suite.base}/${pageName}`);
    const links = await t.page.$$eval('header nav a', (anchors) =>
      anchors.map((anchor) => ({
        label: anchor.textContent.trim(),
        href: anchor.getAttribute('href'),
        current: anchor.getAttribute('aria-current'),
      })),
    );
    assert.deepEqual(links.map(({ label, href }) => ({ label, href })), NAV, `${pageName} nav links`);
    const current = links.filter((link) => link.current !== null);
    const own = NAV.find((link) => link.href === pageName);
    assert.deepEqual(current.map((link) => [link.href, link.current]), [[own.href, 'page']], `${pageName} aria-current`);
    assert.deepEqual(t.problems, [], `${pageName} problems`);
    await t.context.close();
  }
});

test('every nav link resolves to a page that exists', async () => {
  const t = await openTracked(suite);
  await visit(t, `${suite.base}/index.html`);
  for (const link of NAV) {
    const response = await t.page.request.get(`${suite.base}/${link.href}`);
    assert.equal(response.status(), 200, `${link.href} status`);
  }
  await t.context.close();
});

test('the site name links home from every page and works by click', async () => {
  const t = await openTracked(suite);
  await visit(t, `${suite.base}/visit.html`);
  const brand = t.page.locator('header a', { hasText: 'Marginalia Books' });
  assert.equal(await brand.count(), 1);
  assert.equal(await brand.getAttribute('href'), 'index.html');
  await brand.click();
  await t.page.waitForURL(/\/index\.html$/);
  assert.deepEqual(t.problems, []);
  await t.context.close();
});

test('at 360px all four nav links are visible and inside the viewport', async () => {
  const t = await openTracked(suite, { viewport: { width: 360, height: 800 } });
  await visit(t, `${suite.base}/books.html`);
  for (const link of NAV) {
    const locator = t.page.locator(`header nav a[href="${link.href}"]`);
    assert.equal(await locator.isVisible(), true, `${link.label} visible`);
    const box = await locator.boundingBox();
    assert.ok(box.width > 0 && box.height > 0, `${link.label} has size`);
    assert.ok(box.x >= 0 && box.x + box.width <= 360, `${link.label} inside 360px`);
  }
  await t.context.close();
});

test('the current page link is distinguished from the others', async () => {
  const t = await openTracked(suite);
  await visit(t, `${suite.base}/events.html`);
  const current = await t.page.locator('header nav a[aria-current="page"]').evaluate((anchor) => {
    const style = getComputedStyle(anchor);
    return { weight: style.fontWeight, underline: style.textDecorationLine };
  });
  const other = await t.page.locator('header nav a[href="visit.html"]').evaluate((anchor) => {
    const style = getComputedStyle(anchor);
    return { weight: style.fontWeight, underline: style.textDecorationLine };
  });
  assert.notDeepEqual(current, other);
  await t.context.close();
});

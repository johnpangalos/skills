// Contact form: client-side checks only. The form is a demo and never sends anything.
(function () {
  'use strict';

  var MAX_MESSAGE_LENGTH = 1000;
  // The domain may not start with a dot, contain two dots in a row, or end with one.
  var EMAIL_PATTERN = /^[^\s@]+@(?!\.)(?![^\s@]*\.\.)(?![^\s@]*\.$)[^\s@]+\.[^\s@]{2,}$/;

  var form = document.getElementById('contact-form');
  var status = document.getElementById('form-status');
  if (!form || !status) return;

  var VALIDATORS = {
    name: checkName,
    email: checkEmail,
    message: checkMessage,
  };

  // Each checker returns an error message, or '' when the value is acceptable.
  function checkName(value) {
    return value.trim() ? '' : 'Please enter your name.';
  }

  function checkEmail(value) {
    var email = value.trim();
    if (!email) return 'Please enter your email address.';
    if (!EMAIL_PATTERN.test(email)) return 'Please enter an email address in the form name@example.com.';
    return '';
  }

  // Counts characters as code points, so an emoji is one character, not two UTF-16 code units.
  function checkMessage(value) {
    var length = Array.from(value).length;
    if (!value.trim()) return 'Please enter a message.';
    if (length > MAX_MESSAGE_LENGTH) {
      return 'Your message is ' + length + ' characters. Please keep it to 1,000 characters or fewer.';
    }
    return '';
  }

  // Checks one field, sets its error text and aria-invalid, and returns the message ('' when valid).
  function validateField(id) {
    var message = VALIDATORS[id](document.getElementById(id).value);
    document.getElementById(id + '-error').textContent = message;
    document.getElementById(id).setAttribute('aria-invalid', message ? 'true' : 'false');
    return message;
  }

  function showConfirmation() {
    var link = document.createElement('a');
    link.href = 'mailto:hello@marginalia.example';
    link.textContent = 'hello@marginalia.example';
    status.replaceChildren(
      "This is a demo site, so your message wasn't sent anywhere. To reach us, email ",
      link,
      ' or call 01632 960123.',
    );
  }

  form.addEventListener('submit', function (event) {
    event.preventDefault();
    var firstInvalid = null;
    Object.keys(VALIDATORS).forEach(function (id) {
      var message = validateField(id);
      if (message && !firstInvalid) firstInvalid = document.getElementById(id);
    });
    if (firstInvalid) {
      status.replaceChildren();
      firstInvalid.focus();
      return;
    }
    showConfirmation();
  });

  // Once a field is marked invalid, re-check it as the reader types so the error clears when fixed.
  Object.keys(VALIDATORS).forEach(function (id) {
    document.getElementById(id).addEventListener('input', function () {
      if (document.getElementById(id).getAttribute('aria-invalid') === 'true') validateField(id);
    });
  });
})();

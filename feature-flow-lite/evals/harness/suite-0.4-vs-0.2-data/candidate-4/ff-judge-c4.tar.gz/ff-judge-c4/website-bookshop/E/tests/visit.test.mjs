// Criterion 8: opening hours, address, contact links, directions, local-day highlight.
import assert from 'node:assert/strict';

const DAYS = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'];

export const tests = [
  {
    name: 'criterion 8: opening hours table lists every day of the week in order with hours',
    async run(ctx) {
      const { page } = await ctx.open();
      await page.goto(ctx.url('visit.html'));
      const table = page.locator('main table');
      assert.ok((await table.locator('caption').textContent()).trim().length > 0, 'table needs a caption');
      assert.equal(await table.locator('thead th').count(), 2, 'column headers for day and hours');
      const rows = await table.locator('tbody tr').evaluateAll((trs) => trs.map((tr) => ({
        day: tr.querySelector('th')?.textContent.replace(/\(today\)/i, '').trim(),
        hours: tr.querySelector('td')?.textContent.trim() ?? '',
      })));
      assert.deepEqual(rows.map((r) => r.day), ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday']);
      for (const row of rows) assert.match(row.hours, /\d{1,2}:\d{2}.*\d{1,2}:\d{2}/, `hours for ${row.day}`);
    },
  },
  {
    name: 'criterion 8: address element, tel and mailto links and directions text, with no map embed',
    async run(ctx) {
      const { page } = await ctx.open();
      await page.goto(ctx.url('visit.html'));
      const address = await page.locator('main address').innerText();
      assert.match(address, /Example Row/);
      const tel = await page.locator('main a[href^="tel:"]').first().getAttribute('href');
      assert.match(tel, /^tel:\+?1?555/, 'phone should be a tel: link with a 555 number');
      const mail = await page.locator('main a[href^="mailto:"]').first().getAttribute('href');
      assert.match(mail, /^mailto:[^@\s]+@[^@\s]+\.test$/, 'email should be a mailto: link on a .test domain');
      const directions = await page.locator('#directions').innerText();
      assert.ok(directions.length > 80, 'directions text is present');
      assert.equal(await page.locator('iframe').count(), 0, 'no iframe map embed');
    },
  },
  {
    name: 'criterion 8 hostile: late Sunday evening in Los Angeles is Sunday even though UTC is already Monday',
    async run(ctx) {
      // 2026-11-22 23:30 in Los Angeles (PST, UTC-8) is 2026-11-23 07:30 UTC.
      const { page } = await ctx.open({ timezoneId: 'America/Los_Angeles' });
      await page.clock.setFixedTime(new Date('2026-11-23T07:30:00Z'));
      await page.goto(ctx.url('visit.html'));
      const today = await page.locator('main tr.is-today');
      assert.equal(await today.count(), 1, 'exactly one row highlighted as today');
      const day = (await today.locator('th').textContent()).replace(/\(today\)/i, '').trim();
      assert.equal(day, 'Sunday', 'highlighted day should use the local clock');
    },
  },
  {
    name: 'criterion 8: today is highlighted on a weekday in local time',
    async run(ctx) {
      const { page } = await ctx.open({ timezoneId: 'Europe/London' });
      // 2026-11-17 is a Tuesday in London.
      await page.clock.setFixedTime(new Date('2026-11-17T12:00:00Z'));
      await page.goto(ctx.url('visit.html'));
      const day = (await page.locator('main tr.is-today th').textContent()).replace(/\(today\)/i, '').trim();
      assert.equal(day, DAYS[1]);
    },
  },
];

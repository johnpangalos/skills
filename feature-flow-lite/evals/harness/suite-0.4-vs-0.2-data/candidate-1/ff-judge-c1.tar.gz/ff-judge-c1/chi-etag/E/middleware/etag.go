package middleware

import (
	"bufio"
	"bytes"
	"crypto/sha256"
	"encoding/hex"
	"errors"
	"net"
	"net/http"
	"strings"
)

// ETag buffers the whole response of each GET and HEAD request in memory, so it is
// meant for small responses, not large or streamed ones. When the handler returns 200
// without setting an ETag header, ETag sets a strong one hashed from the body. When the
// request's If-None-Match matches the response's ETag, ETag answers 304 Not Modified
// with an empty body. Other methods and non-200 statuses pass through unchanged.
//
// Register ETag before Compress (r.Use(ETag) ahead of r.Use(Compress(...))) so the tag
// covers the encoded bytes and differs for each content encoding.
func ETag(next http.Handler) http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		if r.Method != http.MethodGet && r.Method != http.MethodHead {
			next.ServeHTTP(w, r)
			return
		}
		// Copied before next runs, so an inner middleware that deletes the header cannot hide it.
		inm := append([]string(nil), r.Header.Values("If-None-Match")...)
		ew := &etagResponseWriter{ResponseWriter: w, method: r.Method}
		next.ServeHTTP(ew, r)
		ew.finish(inm)
	})
}

// etagResponseWriter holds a 200 response until the handler returns. Any other final
// status, and any hijacked connection, is written straight through to the underlying writer.
type etagResponseWriter struct {
	http.ResponseWriter
	method      string
	buf         bytes.Buffer
	wroteHeader bool            // a final status has been recorded
	passthrough bool            // writes and flushes go straight to the underlying writer
	held        map[string]bool // declared trailers absent when the final status was recorded
}

func (w *etagResponseWriter) WriteHeader(code int) {
	if w.passthrough {
		w.ResponseWriter.WriteHeader(code)
		return
	}
	if w.wroteHeader {
		return
	}
	if code >= 100 && code <= 199 && code != http.StatusSwitchingProtocols {
		w.ResponseWriter.WriteHeader(code)
		return
	}
	w.wroteHeader = true
	if code != http.StatusOK {
		w.passthrough = true
		w.ResponseWriter.WriteHeader(code)
		return
	}
	w.snapshotTrailers()
}

func (w *etagResponseWriter) Write(p []byte) (int, error) {
	if !w.wroteHeader {
		w.WriteHeader(http.StatusOK)
	}
	if w.passthrough {
		return w.ResponseWriter.Write(p)
	}
	return w.buf.Write(p)
}

func (w *etagResponseWriter) Flush() {
	if w.passthrough {
		if f, ok := w.ResponseWriter.(http.Flusher); ok {
			f.Flush()
		}
		return
	}
	if !w.wroteHeader {
		w.WriteHeader(http.StatusOK)
	}
}

func (w *etagResponseWriter) Hijack() (net.Conn, *bufio.ReadWriter, error) {
	hj, ok := w.ResponseWriter.(http.Hijacker)
	if !ok {
		return nil, nil, errors.New("chi/middleware: http.Hijacker is unavailable on the writer")
	}
	// A buffered 200 goes out unchanged, without an ETag or 304, before the connection is taken.
	if !w.passthrough && w.wroteHeader {
		w.ResponseWriter.WriteHeader(http.StatusOK)
		w.ResponseWriter.Write(w.buf.Bytes())
	}
	w.passthrough = true
	return hj.Hijack()
}

func (w *etagResponseWriter) Push(target string, opts *http.PushOptions) error {
	if ps, ok := w.ResponseWriter.(http.Pusher); ok {
		return ps.Push(target, opts)
	}
	return errors.New("chi/middleware: http.Pusher is unavailable on the writer")
}

func (w *etagResponseWriter) Unwrap() http.ResponseWriter {
	return w.ResponseWriter
}

// finish runs after the handler returns and answers the buffered 200, if there is one.
func (w *etagResponseWriter) finish(inm []string) {
	if w.passthrough {
		return
	}
	if !w.wroteHeader {
		w.snapshotTrailers()
	}
	w.wroteHeader = true
	h := w.Header()
	if len(h.Values("ETag")) == 0 && (w.method == http.MethodGet || w.buf.Len() > 0) {
		sum := sha256.Sum256(w.buf.Bytes())
		h.Set("ETag", `"`+hex.EncodeToString(sum[:])+`"`)
	}
	if etagAnyLineMatches(inm, h.Get("ETag")) {
		for k := range w.held {
			h.Del(k)
		}
		h.Del("Content-Type")
		h.Del("Content-Length")
		h.Del("Content-Encoding")
		h.Del("Last-Modified")
		w.ResponseWriter.WriteHeader(http.StatusNotModified)
		return
	}
	trailers := etagHoldTrailers(h, w.held)
	w.ResponseWriter.WriteHeader(http.StatusOK)
	w.ResponseWriter.Write(w.buf.Bytes())
	// Put the held trailers back after the body so net/http sends them as trailers.
	for k, v := range trailers {
		h[k] = v
	}
}

// snapshotTrailers records each trailer declared in the Trailer header that is not yet set. Raw
// net/http sends a declared key set before the final status in the header block, and a later one
// only as a trailer. The ETag key is never held, so it always stays in the header block.
func (w *etagResponseWriter) snapshotTrailers() {
	h := w.Header()
	w.held = map[string]bool{}
	for _, decl := range h.Values("Trailer") {
		for _, k := range strings.Split(decl, ",") {
			k = http.CanonicalHeaderKey(strings.TrimSpace(k))
			if _, ok := h[k]; !ok && k != "" && k != http.CanonicalHeaderKey("ETag") {
				w.held[k] = true
			}
		}
	}
}

// etagHoldTrailers removes the values of the held keys from h and returns them, so WriteHeader
// does not send them in the header block.
func etagHoldTrailers(h http.Header, held map[string]bool) http.Header {
	out := http.Header{}
	for k := range held {
		if v, ok := h[k]; ok {
			out[k] = v
			delete(h, k)
		}
	}
	return out
}

// etagAnyLineMatches reports whether any If-None-Match field line matches etag. Each line is a
// list of its own, so lines are not joined before matching.
func etagAnyLineMatches(lines []string, etag string) bool {
	for _, line := range lines {
		if etagNoneMatch(line, etag) {
			return true
		}
	}
	return false
}

// etagNoneMatch reports whether an If-None-Match value matches etag under weak comparison.
// A "*" matches any response that has an ETag. The scan stops at the first malformed member.
func etagNoneMatch(inm, etag string) bool {
	for {
		inm = strings.Trim(inm, " \t")
		switch {
		case inm == "":
			return false
		case inm[0] == ',':
			inm = inm[1:]
		case inm[0] == '*':
			return etag != ""
		default:
			tag, rest := scanETag(inm)
			if tag == "" {
				return false
			}
			if strings.TrimPrefix(tag, "W/") == strings.TrimPrefix(etag, "W/") {
				return true
			}
			inm = rest
		}
	}
}

// scanETag returns the entity-tag at the start of s, with its optional W/ prefix, and the
// text after it. It returns "", "" when s does not start with a valid entity-tag (RFC 9110 8.8.3).
func scanETag(s string) (tag, rest string) {
	start := 0
	if strings.HasPrefix(s, "W/") {
		start = 2
	}
	if len(s[start:]) < 2 || s[start] != '"' {
		return "", ""
	}
	for i := start + 1; i < len(s); i++ {
		c := s[i]
		switch {
		case c == 0x21 || c >= 0x23 && c <= 0x7E || c >= 0x80:
		case c == '"':
			return s[:i+1], s[i+1:]
		default:
			return "", ""
		}
	}
	return "", ""
}

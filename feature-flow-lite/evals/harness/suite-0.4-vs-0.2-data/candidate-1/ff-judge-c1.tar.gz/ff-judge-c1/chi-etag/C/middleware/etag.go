package middleware

import (
	"bufio"
	"bytes"
	"crypto/sha256"
	"encoding/hex"
	"errors"
	"net"
	"net/http"
	"strings"
)

// ETag buffers the whole body of 200 responses to GET and HEAD requests in
// memory, sets a strong ETag computed from that body when the handler set
// none, and answers 304 Not Modified when If-None-Match matches (RFC 9110
// section 13.1.2). Nothing is sent until the handler returns. Other methods
// and other statuses pass through unchanged. Place ETag before (outside)
// Compress so the ETag matches the bytes sent.
func ETag(next http.Handler) http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		if r.Method != http.MethodGet && r.Method != http.MethodHead {
			next.ServeHTTP(w, r)
			return
		}
		ew := &etagResponseWriter{
			ResponseWriter: w,
			head:           r.Method == http.MethodHead,
			ifNoneMatch:    r.Header.Values("If-None-Match"),
		}
		next.ServeHTTP(ew, r)
		ew.finish()
	})
}

type etagResponseWriter struct {
	http.ResponseWriter
	head        bool
	ifNoneMatch []string
	body        bytes.Buffer
	wrote       bool // the handler called Write, so finish must call Write too
	// implicitHeader: the first call was Write, so the 200 is implicit and the body
	// is written without a WriteHeader first, letting the writer sniff Content-Type.
	implicitHeader bool
	status         int  // final status; 0 until WriteHeader, Write or Flush
	sent           bool // the buffered 200 went to the underlying writer (by Hijack)
	hijacked       bool
	flushed        bool // the handler called Flush while the 200 was buffered
	flushedLen     int  // body bytes written before the last such Flush
}

// passthrough reports whether writes go straight to the underlying writer: a
// final status other than 200 was set, or the buffered 200 was already sent.
func (w *etagResponseWriter) passthrough() bool {
	return w.sent || w.status != 0 && w.status != http.StatusOK
}

func (w *etagResponseWriter) WriteHeader(code int) {
	if w.hijacked {
		return
	}
	if code >= 100 && code <= 199 && code != http.StatusSwitchingProtocols {
		w.ResponseWriter.WriteHeader(code) // informational: forwarded, not final
		return
	}
	if w.status != 0 {
		return // only the first final status counts
	}
	w.status = code
	if code != http.StatusOK {
		w.ResponseWriter.WriteHeader(code)
	}
}

func (w *etagResponseWriter) Write(p []byte) (int, error) {
	if w.hijacked {
		return 0, http.ErrHijacked
	}
	if w.status == 0 {
		w.status = http.StatusOK
		w.implicitHeader = true
	}
	if w.passthrough() {
		return w.ResponseWriter.Write(p)
	}
	w.wrote = true
	return w.body.Write(p)
}

func (w *etagResponseWriter) Flush() {
	if w.hijacked {
		return
	}
	if w.status == 0 {
		w.status = http.StatusOK // as in net/http, Flush implies WriteHeader(200)
	}
	if !w.passthrough() {
		// A buffered 200 is held back until the handler returns. Record how much
		// body this Flush covers, for Hijack.
		w.flushed = true
		w.flushedLen = w.body.Len()
		return
	}
	if f, ok := w.ResponseWriter.(http.Flusher); ok {
		f.Flush()
	}
}

// Hijack first sends a buffered 200 as net/http would have kept it, so the
// client sees what the unwrapped handler's Hijack would show. It computes no ETag.
func (w *etagResponseWriter) Hijack() (net.Conn, *bufio.ReadWriter, error) {
	hj, ok := w.ResponseWriter.(http.Hijacker)
	if !ok {
		return nil, nil, errors.New("chi/middleware: http.Hijacker is unavailable on the writer")
	}
	if w.status == http.StatusOK && !w.sent {
		w.sendForHijack()
	}
	conn, rw, err := hj.Hijack()
	if err == nil {
		w.hijacked = true
	}
	return conn, rw, err
}

// sendForHijack writes the buffered 200 as it stands at Hijack. The body up to
// the last Flush is written and flushed. The rest is written unflushed, so the
// underlying Hijack discards it, as it does for an unflushed net/http response.
func (w *etagResponseWriter) sendForHijack() {
	w.sent = true
	if !w.implicitHeader {
		w.ResponseWriter.WriteHeader(http.StatusOK)
	}
	w.ResponseWriter.Write(w.body.Bytes()[:w.flushedLen])
	if f, ok := w.ResponseWriter.(http.Flusher); ok && w.flushed {
		f.Flush()
	}
	w.ResponseWriter.Write(w.body.Bytes()[w.flushedLen:])
}

func (w *etagResponseWriter) Push(target string, opts *http.PushOptions) error {
	if ps, ok := w.ResponseWriter.(http.Pusher); ok {
		return ps.Push(target, opts)
	}
	return errors.New("chi/middleware: http.Pusher is unavailable on the writer")
}

func (w *etagResponseWriter) Unwrap() http.ResponseWriter {
	return w.ResponseWriter
}

// finish sends the buffered 200 response, or a 304 when If-None-Match matches.
// It is not deferred, so a panicking handler leaves nothing written.
func (w *etagResponseWriter) finish() {
	if w.passthrough() || w.hijacked {
		return
	}
	// A HEAD response with no body bytes gets no computed ETag, so no
	// validator comes from an empty body.
	if len(w.Header().Values("ETag")) == 0 && (!w.head || w.body.Len() > 0) {
		w.Header().Set("ETag", etagStrong(w.body.Bytes()))
	}
	if matchesIfNoneMatch(w.ifNoneMatch, w.Header().Get("ETag")) {
		writeNotModified(w.ResponseWriter)
		return
	}
	w.sendBuffered()
}

// sendBuffered writes the buffered 200 to the underlying writer as it stands:
// the status line unless the 200 was implicit, then the body if the handler wrote one.
func (w *etagResponseWriter) sendBuffered() {
	w.sent = true
	if !w.implicitHeader {
		w.ResponseWriter.WriteHeader(http.StatusOK)
	}
	if w.wrote {
		w.ResponseWriter.Write(w.body.Bytes())
	}
}

// etagStrong returns the strong entity-tag for body: its SHA-256 in quotes.
func etagStrong(body []byte) string {
	sum := sha256.Sum256(body)
	return `"` + hex.EncodeToString(sum[:]) + `"`
}

// writeNotModified sends a 304 with the same header clean-up as net/http's ServeContent.
func writeNotModified(w http.ResponseWriter) {
	h := w.Header()
	h.Del("Content-Type")
	h.Del("Content-Length")
	h.Del("Content-Encoding")
	if h.Get("ETag") != "" {
		h.Del("Last-Modified")
	}
	w.WriteHeader(http.StatusNotModified)
}

// matchesIfNoneMatch reports whether the If-None-Match header lines match etag
// ("" when the response has none), using weak comparison. The lines are joined
// with commas. As in net/http's checkIfNoneMatch, the scan stops at the first
// malformed member.
func matchesIfNoneMatch(lines []string, etag string) bool {
	list := strings.Join(lines, ",")
	for {
		list = strings.Trim(list, " \t")
		if list == "" {
			return false
		}
		if list[0] == ',' {
			list = list[1:]
			continue
		}
		if list[0] == '*' {
			return true
		}
		tag, rest := scanETag(list)
		if tag == "" {
			return false
		}
		if strings.TrimPrefix(tag, "W/") == strings.TrimPrefix(etag, "W/") {
			return true
		}
		list = rest
	}
}

// scanETag reads one entity-tag (W/"x" or "x") at the start of s. It returns
// the tag and the text after it, or "", "" when s does not start with a valid
// entity-tag.
func scanETag(s string) (tag, rest string) {
	start := 0
	if strings.HasPrefix(s, "W/") {
		start = 2
	}
	if start+1 >= len(s) || s[start] != '"' {
		return "", ""
	}
	for i := start + 1; i < len(s); i++ {
		c := s[i]
		switch {
		case c == 0x21 || c >= 0x23 && c <= 0x7E || c >= 0x80: // etagc
		case c == '"':
			return s[:i+1], s[i+1:]
		default:
			return "", ""
		}
	}
	return "", ""
}

package middleware

import (
	"bufio"
	"bytes"
	"crypto/sha256"
	"encoding/hex"
	"errors"
	"net"
	"net/http"
	"slices"
	"strconv"
	"strings"
)

// ETag adds a strong ETag to GET and HEAD responses and answers conditional
// requests with 304 Not Modified.
//
// For GET and HEAD requests, ETag buffers the whole response body in memory
// until the handler returns, so it is not suitable for large or streamed
// bodies. While the body is buffered, Flush is a no-op. Register ETag before
// Compress (outside of it), so the tag is computed from the bytes actually sent.
//
// When the handler responds 200 and sets no ETag header, ETag sets the quoted
// hex SHA-256 of the body as a strong tag. A HEAD response with an empty body
// gets no tag. If the If-None-Match request header matches the response ETag,
// the response becomes 304 Not Modified with no body. Matching follows RFC 9110
// section 13.1.2: weak comparison, comma-separated lists across header lines,
// and "*" matches any 200 response. Other methods and non-200 responses pass
// through unchanged.
func ETag(next http.Handler) http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		if r.Method != http.MethodGet && r.Method != http.MethodHead {
			next.ServeHTTP(w, r)
			return
		}
		ew := &etagResponseWriter{ResponseWriter: w}
		next.ServeHTTP(ew, r)
		ew.finish(r)
	})
}

type etagResponseWriter struct {
	http.ResponseWriter

	// status is the final status code, or 0 if none was set yet.
	status int
	// buf holds a 200 response body until the handler returns. It is nil
	// unless the response is being held.
	buf *bytes.Buffer
	// passthrough is set once calls go straight to the underlying writer.
	passthrough bool
	// contentLength is the Content-Length declared when the held 200 was
	// committed, or -1 if none. written counts the bytes the handler wrote.
	// Both mirror net/http, which rejects writes beyond the declared length.
	contentLength int64
	written       int64
	// lengthHeader is the Content-Length header values as they were when the
	// 200 was committed, or nil if absent. finish restores them so a late
	// Content-Length never reaches the client.
	lengthHeader []string
}

func (ew *etagResponseWriter) WriteHeader(code int) {
	if ew.passthrough {
		ew.ResponseWriter.WriteHeader(code)
		return
	}
	if code >= 100 && code <= 199 && code != http.StatusSwitchingProtocols {
		if ew.status == 0 {
			ew.ResponseWriter.WriteHeader(code)
		}
		return
	}
	if ew.status != 0 {
		return
	}
	ew.status = code
	if code != http.StatusOK {
		ew.passthrough = true
		ew.ResponseWriter.WriteHeader(code)
		return
	}
	ew.buf = &bytes.Buffer{}
	ew.contentLength = declaredLength(ew.Header())
	ew.lengthHeader = slices.Clone(ew.Header()["Content-Length"])
}

func (ew *etagResponseWriter) Write(p []byte) (int, error) {
	if ew.status == 0 {
		ew.WriteHeader(http.StatusOK)
	}
	if ew.passthrough {
		return ew.ResponseWriter.Write(p)
	}
	if len(p) == 0 {
		return 0, nil
	}
	ew.written += int64(len(p))
	if ew.contentLength != -1 && ew.written > ew.contentLength {
		return 0, http.ErrContentLength
	}
	return ew.buf.Write(p)
}

// declaredLength returns the Content-Length that net/http would enforce for h,
// or -1 when there is none or it is not a non-negative integer.
func declaredLength(h http.Header) int64 {
	n, err := strconv.ParseInt(h.Get("Content-Length"), 10, 64)
	if err != nil || n < 0 {
		return -1
	}
	return n
}

func (ew *etagResponseWriter) Flush() {
	if ew.status == 0 {
		ew.WriteHeader(http.StatusOK)
	}
	if !ew.passthrough {
		return
	}
	if f, ok := ew.ResponseWriter.(http.Flusher); ok {
		f.Flush()
	}
}

func (ew *etagResponseWriter) Hijack() (net.Conn, *bufio.ReadWriter, error) {
	hj, ok := ew.ResponseWriter.(http.Hijacker)
	if !ok {
		return nil, nil, errors.New("chi/middleware: http.Hijacker is unavailable on the writer")
	}
	if ew.buf != nil {
		ew.restoreLength()
		ew.ResponseWriter.WriteHeader(http.StatusOK)
		ew.ResponseWriter.Write(ew.buf.Bytes())
	}
	ew.buf = nil
	ew.passthrough = true
	return hj.Hijack()
}

func (ew *etagResponseWriter) Push(target string, opts *http.PushOptions) error {
	if ps, ok := ew.ResponseWriter.(http.Pusher); ok {
		return ps.Push(target, opts)
	}
	return errors.New("chi/middleware: http.Pusher is unavailable on the writer")
}

func (ew *etagResponseWriter) Unwrap() http.ResponseWriter {
	return ew.ResponseWriter
}

// finish sends a held 200 response, adding or keeping the ETag and answering 304
// when If-None-Match matches. It does nothing once the response was passed through.
func (ew *etagResponseWriter) finish(r *http.Request) {
	if ew.passthrough {
		return
	}
	if ew.status == 0 {
		ew.WriteHeader(http.StatusOK)
	}
	body := ew.buf.Bytes()
	h := ew.Header()
	etags := handlerETags(h)
	if len(etags) == 0 && (r.Method == http.MethodGet || len(body) > 0) {
		sum := sha256.Sum256(body)
		etag := `"` + hex.EncodeToString(sum[:]) + `"`
		h.Set("ETag", etag)
		etags = []string{etag}
	}
	if ifNoneMatchMatches(r.Header.Values("If-None-Match"), etags) {
		h.Del("Content-Length")
		ew.ResponseWriter.WriteHeader(http.StatusNotModified)
		return
	}
	ew.restoreLength()
	ew.ResponseWriter.WriteHeader(http.StatusOK)
	if len(body) > 0 {
		ew.ResponseWriter.Write(body)
	}
}

// restoreLength puts back the Content-Length header as it was when the 200 was
// committed, deleting it if there was none.
func (ew *etagResponseWriter) restoreLength() {
	h := ew.Header()
	if ew.lengthHeader == nil {
		h.Del("Content-Length")
		return
	}
	h["Content-Length"] = ew.lengthHeader
}

// handlerETags returns every ETag value the handler set, whatever the case of
// the header key, so a handler that writes w.Header()["ETag"] is still seen.
func handlerETags(h http.Header) []string {
	var etags []string
	for k, v := range h {
		if strings.EqualFold(k, "ETag") {
			etags = append(etags, v...)
		}
	}
	return etags
}

// ifNoneMatchMatches reports whether any If-None-Match field line matches one of
// etags by weak comparison, or is "*". Malformed etags never match.
func ifNoneMatchMatches(lines []string, etags []string) bool {
	for _, line := range lines {
		if strings.Trim(line, " \t") == "*" {
			return true
		}
		for _, tag := range entityTags(line) {
			for _, etag := range etags {
				if opaque, ok := etagOpaque(etag); ok && tag == opaque {
					return true
				}
			}
		}
	}
	return false
}

// entityTags returns the opaque tags of the well-formed entity-tags in one
// If-None-Match field line. Malformed members are skipped. A quoted tag may
// contain commas, so members are parsed rather than split on commas.
func entityTags(line string) []string {
	var tags []string
	for rest := strings.TrimLeft(line, " \t,"); rest != ""; rest = strings.TrimLeft(rest, " \t,") {
		body := strings.TrimPrefix(rest, "W/")
		if !strings.HasPrefix(body, `"`) {
			rest = skipMember(rest)
			continue
		}
		end := strings.IndexByte(body[1:], '"')
		if end < 0 {
			break
		}
		tag := body[1 : end+1]
		after := strings.TrimLeft(body[end+2:], " \t")
		if !validOpaqueTag(tag) || (after != "" && after[0] != ',') {
			rest = skipMember(rest)
			continue
		}
		tags = append(tags, tag)
		rest = after
	}
	return tags
}

// skipMember drops the list member at the start of s, up to the next comma.
func skipMember(s string) string {
	if i := strings.IndexByte(s, ','); i >= 0 {
		return s[i+1:]
	}
	return ""
}

// validOpaqueTag reports whether tag only contains etagc characters (RFC 9110 8.8.3).
func validOpaqueTag(tag string) bool {
	for i := 0; i < len(tag); i++ {
		if c := tag[i]; c < 0x21 || c == 0x22 || c == 0x7f {
			return false
		}
	}
	return true
}

// etagOpaque returns the opaque tag of an entity-tag set by the handler, without
// its W/ prefix. It reports false when the value is not a well-formed entity-tag.
func etagOpaque(etag string) (string, bool) {
	etag = strings.TrimPrefix(strings.Trim(etag, " \t"), "W/")
	if len(etag) < 2 || etag[0] != '"' || etag[len(etag)-1] != '"' {
		return "", false
	}
	tag := etag[1 : len(etag)-1]
	return tag, validOpaqueTag(tag)
}

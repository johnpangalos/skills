package middleware

import (
	"bufio"
	"bytes"
	"crypto/sha256"
	"encoding/hex"
	"errors"
	"maps"
	"net"
	"net/http"
	"strings"
)

// ETag adds a strong ETag to GET and HEAD responses and answers 304 Not
// Modified when If-None-Match matches it, so clients can revalidate a cached
// copy without downloading the body again.
//
// A 200 response is buffered in memory until the handler returns, so streaming
// handlers lose incremental flushing: Flush does nothing while a 200 is
// buffered. Responses with any other status, and requests with any other
// method, pass through unchanged and stream as usual.
//
// Trailers the handler sets are sent as net/http would send them. A handler-set
// ETag is kept as it is. Generated tags are the SHA-256 of the body, so to get
// a distinct tag per content encoding, register ETag before Compress (ETag
// outside Compress), which hashes the encoded bytes.
func ETag(next http.Handler) http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		if r.Method != http.MethodGet && r.Method != http.MethodHead {
			next.ServeHTTP(w, r)
			return
		}
		ew := &etagWriter{ResponseWriter: w, header: w.Header().Clone()}
		next.ServeHTTP(ew, r)
		ew.finish(r)
	})
}

// etagWriter holds a GET or HEAD response until the handler returns. It has its
// own header map; the copy taken when the status is committed is what is sent.
type etagWriter struct {
	http.ResponseWriter
	header      http.Header // what the handler sees through Header()
	final       http.Header // snapshot taken when the final status is committed
	body        bytes.Buffer
	wroteHeader bool // the final status has been committed
	committed   bool // the handler committed the status with WriteHeader or Flush
	streaming   bool // the status is sent, so writes go straight through
	hijacked    bool
}

func (ew *etagWriter) Header() http.Header {
	return ew.header
}

func (ew *etagWriter) WriteHeader(code int) {
	if ew.hijacked {
		return
	}
	// Informational responses are sent right away and are not the final status.
	if code >= 100 && code <= 199 && code != http.StatusSwitchingProtocols {
		if !ew.wroteHeader {
			ew.sendHeader(code, ew.header)
		}
		return
	}
	if ew.wroteHeader {
		return
	}
	ew.committed = true
	ew.commitStatus(code)
}

// commitStatus records the final status and its header snapshot. Anything but
// 200 is sent to the underlying writer now and streamed from then on.
func (ew *etagWriter) commitStatus(code int) {
	ew.wroteHeader = true
	ew.final = ew.header.Clone()
	if code != http.StatusOK {
		ew.streaming = true
		ew.sendHeader(code, ew.final)
	}
}

func (ew *etagWriter) Write(p []byte) (int, error) {
	if ew.hijacked {
		return 0, http.ErrHijacked
	}
	if !ew.wroteHeader {
		ew.commitStatus(http.StatusOK)
	}
	if ew.streaming {
		return ew.ResponseWriter.Write(p)
	}
	return ew.body.Write(p)
}

func (ew *etagWriter) Flush() {
	if ew.hijacked {
		return
	}
	if !ew.wroteHeader {
		ew.committed = true
		ew.commitStatus(http.StatusOK)
	}
	// A buffered 200 is not sent until the handler returns.
	if !ew.streaming {
		return
	}
	if f, ok := ew.ResponseWriter.(http.Flusher); ok {
		f.Flush()
	}
}

func (ew *etagWriter) Hijack() (net.Conn, *bufio.ReadWriter, error) {
	hj, ok := ew.ResponseWriter.(http.Hijacker)
	if !ok {
		return nil, nil, errors.New("chi/middleware: http.Hijacker is unavailable on the writer")
	}
	// A buffered 200 goes out first, as net/http would have sent it.
	if ew.wroteHeader && !ew.streaming {
		ew.sendBuffered()
	}
	conn, rw, err := hj.Hijack()
	if err == nil {
		ew.hijacked = true
	}
	return conn, rw, err
}

func (ew *etagWriter) Push(target string, opts *http.PushOptions) error {
	if ps, ok := ew.ResponseWriter.(http.Pusher); ok {
		return ps.Push(target, opts)
	}
	return errors.New("chi/middleware: http.Pusher is unavailable on the writer")
}

func (ew *etagWriter) Unwrap() http.ResponseWriter {
	return ew.ResponseWriter
}

// finish sends the buffered 200 once the handler has returned: with a generated
// ETag when the handler set none, or as a 304 when If-None-Match matches.
func (ew *etagWriter) finish(r *http.Request) {
	if ew.hijacked {
		return
	}
	if ew.streaming {
		ew.copyTrailers()
		return
	}
	if !ew.wroteHeader {
		ew.commitStatus(http.StatusOK)
	}
	h := ew.final
	etags := etagValues(h)
	if len(etags) == 0 && (r.Method == http.MethodGet || ew.body.Len() > 0) {
		h.Set("ETag", etagOf(ew.body.Bytes()))
		etags = h.Values("ETag")
	}
	if notModified(r, etags) {
		dropRepresentationHeaders(h)
		ew.sendHeader(http.StatusNotModified, h)
		return
	}
	copyPrefixedTrailers(ew.final, ew.header)
	ew.sendBuffered()
	ew.copyTrailers()
}

// sendBuffered writes the buffered 200 to the underlying writer, with its header
// snapshot, status and body, as net/http would have. Writes stream from then on.
// An implicit status is left to the first body Write, as the handler would have.
func (ew *etagWriter) sendBuffered() {
	ew.streaming = true
	ew.setHeader(ew.final)
	if ew.committed || ew.body.Len() == 0 {
		ew.ResponseWriter.WriteHeader(http.StatusOK)
	}
	if ew.body.Len() > 0 {
		ew.ResponseWriter.Write(ew.body.Bytes())
	}
}

// setHeader makes the underlying writer's header map exactly h.
func (ew *etagWriter) setHeader(h http.Header) {
	dst := ew.ResponseWriter.Header()
	clear(dst)
	maps.Copy(dst, h)
}

// sendHeader makes the underlying header map exactly h and writes the status.
func (ew *etagWriter) sendHeader(code int, h http.Header) {
	ew.setHeader(h)
	ew.ResponseWriter.WriteHeader(code)
}

// dropRepresentationHeaders removes the headers that describe a body, which a
// 304 does not carry.
func dropRepresentationHeaders(h http.Header) {
	h.Del("Content-Length")
	h.Del("Content-Type")
	h.Del("Content-Encoding")
	h.Del("Transfer-Encoding")
}

// copyTrailers gives the underlying writer the trailer values the handler set
// after the status was committed. net/http reads them when the response ends.
func (ew *etagWriter) copyTrailers() {
	dst := ew.ResponseWriter.Header()
	copyPrefixedTrailers(dst, ew.header)
	for _, name := range trailerNames(ew.final) {
		if v, ok := ew.header[name]; ok {
			dst[name] = v
		}
	}
}

// copyPrefixedTrailers copies the keys that carry the http.TrailerPrefix from src
// to dst. net/http leaves them out of the header block, sends them as trailers,
// and chunks the response for them, so they must be in place before the header
// is written.
func copyPrefixedTrailers(dst, src http.Header) {
	for k, v := range src {
		if strings.HasPrefix(k, http.TrailerPrefix) {
			dst[k] = v
		}
	}
}

// trailerNames returns the canonical names listed in the Trailer header of h.
func trailerNames(h http.Header) []string {
	var names []string
	for _, line := range h.Values("Trailer") {
		for _, name := range strings.Split(line, ",") {
			if name = strings.TrimSpace(name); name != "" {
				names = append(names, http.CanonicalHeaderKey(name))
			}
		}
	}
	return names
}

// etagOf returns the strong entity-tag for body: its SHA-256 in hex, quoted.
func etagOf(body []byte) string {
	sum := sha256.Sum256(body)
	return `"` + hex.EncodeToString(sum[:]) + `"`
}

// etagValues returns the values of every header key that names ETag, whatever
// its case, so a handler that set the header through a non-canonical key counts.
func etagValues(h http.Header) []string {
	var values []string
	for k, v := range h {
		if strings.EqualFold(k, "ETag") {
			values = append(values, v...)
		}
	}
	return values
}

// notModified reports whether If-None-Match in r matches any of etags. With no
// etags only "*" can match.
func notModified(r *http.Request, etags []string) bool {
	lines := r.Header.Values("If-None-Match")
	if len(etags) == 0 {
		return ifNoneMatch(lines, "")
	}
	for _, etag := range etags {
		if ifNoneMatch(lines, etag) {
			return true
		}
	}
	return false
}

// ifNoneMatch reports whether any member of the If-None-Match header lines
// matches etag under the weak comparison of RFC 9110 section 13.1.2. A "*"
// member matches any response.
func ifNoneMatch(lines []string, etag string) bool {
	want, wellFormed := entityTagOpaque(etag)
	for _, line := range lines {
		for more := true; more; {
			var member string
			member, line, more = cutListMember(line)
			member = strings.Trim(member, " \t")
			if member == "*" {
				return true
			}
			if opaque, ok := entityTagOpaque(member); ok && wellFormed && opaque == want {
				return true
			}
		}
	}
	return false
}

// cutListMember splits off the first member of a comma-separated list. Commas
// inside a quoted string do not separate members.
func cutListMember(list string) (member, rest string, more bool) {
	inQuote := false
	for i := 0; i < len(list); i++ {
		switch list[i] {
		case '"':
			inQuote = !inQuote
		case ',':
			if !inQuote {
				return list[:i], list[i+1:], true
			}
		}
	}
	return list, "", false
}

// entityTagOpaque returns the opaque-tag of a well-formed entity-tag, with any
// W/ prefix removed.
func entityTagOpaque(tag string) (string, bool) {
	tag = strings.TrimPrefix(tag, "W/")
	if len(tag) < 2 || tag[0] != '"' || tag[len(tag)-1] != '"' {
		return "", false
	}
	opaque := tag[1 : len(tag)-1]
	if strings.Contains(opaque, `"`) {
		return "", false
	}
	return opaque, true
}

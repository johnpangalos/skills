package middleware

import (
	"bufio"
	"bytes"
	"crypto/sha256"
	"encoding/hex"
	"errors"
	"net"
	"net/http"
	"strings"
)

// ETag sets a strong ETag on GET and HEAD responses and answers a matching
// If-None-Match request with 304 Not Modified.
//
// A 200 response is buffered until the handler returns, so the ETag can be
// computed from the complete body. While it is buffered, Flush does nothing
// and no headers or body reach the client. The ETag is the hex SHA-256 of the
// body. A handler-set ETag is kept as it is. For HEAD, an ETag is computed only
// when the handler wrote body bytes, so an empty HEAD response never gets a
// validator. Once a non-200 status is written, writes and Flush go straight to
// the underlying writer. Other methods are passed through unchanged. If the
// handler panics, the panic propagates and nothing buffered is written.
func ETag(next http.Handler) http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		if r.Method != http.MethodGet && r.Method != http.MethodHead {
			next.ServeHTTP(w, r)
			return
		}
		ew := &etagResponseWriter{ResponseWriter: w}
		next.ServeHTTP(ew, r)
		ew.finish(r)
	})
}

type etagResponseWriter struct {
	http.ResponseWriter
	status    int         // final status once decided; 0 before that
	header    http.Header // headers the handler sees once a 200 is decided
	body      bytes.Buffer
	explicit  bool // the handler committed the status with WriteHeader or Flush
	hijacked  bool
	committed bool // the buffered 200 was sent to the underlying writer early, by Hijack
}

func (w *etagResponseWriter) Header() http.Header {
	if w.buffering() {
		return w.header
	}
	return w.ResponseWriter.Header()
}

// buffering reports whether a 200 is decided and has not been sent to the underlying writer yet.
func (w *etagResponseWriter) buffering() bool {
	return w.status == http.StatusOK && !w.committed
}

func (w *etagResponseWriter) WriteHeader(code int) {
	if w.hijacked {
		w.ResponseWriter.WriteHeader(code)
		return
	}
	if code >= 100 && code <= 199 && code != http.StatusSwitchingProtocols {
		w.ResponseWriter.WriteHeader(code)
		return
	}
	if w.status != 0 {
		return
	}
	w.explicit = true
	w.decide(code)
}

// decide records the final status. Headers set after this point are not sent, as with net/http.
func (w *etagResponseWriter) decide(code int) {
	w.status = code
	if code != http.StatusOK {
		w.ResponseWriter.WriteHeader(code)
		return
	}
	w.header = w.ResponseWriter.Header().Clone()
}

func (w *etagResponseWriter) Write(p []byte) (int, error) {
	if w.hijacked {
		return w.ResponseWriter.Write(p)
	}
	if w.status == 0 {
		w.decide(http.StatusOK)
	}
	if !w.buffering() {
		return w.ResponseWriter.Write(p)
	}
	return w.body.Write(p)
}

func (w *etagResponseWriter) Flush() {
	_ = w.FlushError()
}

func (w *etagResponseWriter) FlushError() error {
	if w.hijacked {
		return http.NewResponseController(w.ResponseWriter).Flush()
	}
	if w.status == 0 {
		w.WriteHeader(http.StatusOK)
	}
	if w.buffering() {
		return nil
	}
	return http.NewResponseController(w.ResponseWriter).Flush()
}

func (w *etagResponseWriter) Hijack() (net.Conn, *bufio.ReadWriter, error) {
	hj, ok := w.ResponseWriter.(http.Hijacker)
	if !ok {
		return nil, nil, errors.New("chi/middleware: http.Hijacker is unavailable on the writer")
	}
	// The status line and body must reach the connection before it is taken over.
	if w.buffering() {
		w.commit()
	}
	conn, rw, err := hj.Hijack()
	if err == nil {
		w.hijacked = true
	}
	return conn, rw, err
}

func (w *etagResponseWriter) Push(target string, opts *http.PushOptions) error {
	if ps, ok := w.ResponseWriter.(http.Pusher); ok {
		return ps.Push(target, opts)
	}
	return errors.New("chi/middleware: http.Pusher is unavailable on the writer")
}

func (w *etagResponseWriter) Unwrap() http.ResponseWriter {
	return w.ResponseWriter
}

// commit sends the buffered 200 to the underlying writer, as the handler would have without the middleware.
// Without an explicit WriteHeader, the underlying Write commits the status,
// so content sniffing matches what the handler would have produced.
func (w *etagResponseWriter) commit() {
	w.committed = true
	if w.explicit {
		w.ResponseWriter.WriteHeader(http.StatusOK)
	}
	// A 200 decided by Write has no WriteHeader call, so that Write must commit it even with an empty body.
	decidedByWrite := w.status == http.StatusOK && !w.explicit
	if decidedByWrite || w.body.Len() > 0 {
		w.ResponseWriter.Write(w.body.Bytes())
	}
}

// finish sends the buffered 200 response, or a 304 when the request matches it.
func (w *etagResponseWriter) finish(r *http.Request) {
	// A non-200 status has already been written through, and a hijacked or committed response is already on the wire.
	if w.committed || w.hijacked || (w.status != 0 && w.status != http.StatusOK) {
		return
	}
	h := w.ResponseWriter.Header()
	etag, ok := etagHandlerETag(h)
	if !ok && (r.Method == http.MethodGet || w.body.Len() > 0) {
		sum := sha256.Sum256(w.body.Bytes())
		etag = `"` + hex.EncodeToString(sum[:]) + `"`
		h.Set("ETag", etag)
	}
	if etagIfNoneMatch(r.Header.Values("If-None-Match"), etag) {
		// Drop representation headers from a 304, as net/http does in writeNotModified.
		h.Del("Content-Type")
		h.Del("Content-Length")
		h.Del("Content-Encoding")
		if etag != "" {
			h.Del("Last-Modified")
		}
		w.ResponseWriter.WriteHeader(http.StatusNotModified)
		return
	}
	w.commit()
	etagCopyTrailers(h, w.header)
}

// etagHandlerETag returns the value of an ETag header set under any key spelling, and whether there is one.
func etagHandlerETag(h http.Header) (string, bool) {
	for key, values := range h {
		if strings.EqualFold(key, "ETag") && len(values) > 0 {
			return values[0], true
		}
	}
	return "", false
}

// etagCopyTrailers copies the trailers the handler set after the 200 was decided into the
// underlying header, where net/http reads them when the response ends. A trailer is a key
// named in the Trailer header of dst, or a key with the TrailerPrefix.
func etagCopyTrailers(dst, src http.Header) {
	declared := make(map[string]bool)
	for _, v := range dst.Values("Trailer") {
		for _, name := range strings.Split(v, ",") {
			declared[http.CanonicalHeaderKey(strings.TrimSpace(name))] = true
		}
	}
	for key, values := range src {
		if declared[key] || strings.HasPrefix(key, http.TrailerPrefix) {
			dst[key] = values
		}
	}
}

// etagIfNoneMatch reports whether any If-None-Match member matches etag, using
// weak comparison (RFC 9110 section 13.1.2). etag is "" when there is none.
// Each header line is parsed on its own. Parsing a line stops at its first
// malformed member, and a `*` member matches any response. A tag followed by
// anything other than optional whitespace and a comma or the end of the line
// is malformed.
func etagIfNoneMatch(lines []string, etag string) bool {
	for _, line := range lines {
		buf := line
		for {
			buf = strings.Trim(buf, " \t")
			if buf == "" {
				break
			}
			if buf[0] == ',' {
				buf = buf[1:]
				continue
			}
			if buf[0] == '*' {
				if len(buf) == 1 || strings.IndexByte(", \t", buf[1]) >= 0 {
					return true
				}
				break
			}
			member, rest := etagScanTag(buf)
			if member == "" {
				break
			}
			rest = strings.TrimLeft(rest, " \t")
			if rest != "" && rest[0] != ',' {
				break
			}
			if strings.TrimPrefix(member, "W/") == strings.TrimPrefix(etag, "W/") {
				return true
			}
			buf = rest
		}
	}
	return false
}

// etagScanTag returns the entity tag at the start of s and the text after it.
// It returns "", "" when s does not start with a well-formed entity tag.
func etagScanTag(s string) (tag, rest string) {
	start := 0
	if strings.HasPrefix(s, "W/") {
		start = 2
	}
	if len(s) < start+2 || s[start] != '"' {
		return "", ""
	}
	for i := start + 1; i < len(s); i++ {
		c := s[i]
		switch {
		case c == 0x21 || c >= 0x23 && c <= 0x7E || c >= 0x80:
		case c == '"':
			return s[:i+1], s[i+1:]
		default:
			return "", ""
		}
	}
	return "", ""
}

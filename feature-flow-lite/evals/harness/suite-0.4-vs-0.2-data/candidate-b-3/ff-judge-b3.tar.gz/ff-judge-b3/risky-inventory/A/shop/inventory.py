"""Stock on hand with thread-safe reservations."""

import threading
from dataclasses import dataclass

from shop.catalog import lookup


class OutOfStock(ValueError):
    pass


class ReservationError(ValueError):
    pass


@dataclass(frozen=True, eq=False)  # eq=False: settlement is tracked by identity
class Reservation:
    sku: str
    qty: int


class Inventory:
    def __init__(self, stock):
        self._lock = threading.Lock()
        self._on_hand = {}
        self._held = {}  # sku -> units held by open reservations
        self._open = {}  # id(reservation) -> (reservation, sku, qty) as granted
        for sku, units in stock.items():
            lookup(sku)
            if type(units) is not int or units < 0:
                raise ValueError(f"stock for {sku} must be an int >= 0")
            self._on_hand[sku] = units

    def available(self, sku):
        lookup(sku)
        with self._lock:
            return self._available(sku)

    def reserve(self, sku, qty):
        lookup(sku)
        if type(qty) is not int or qty < 1:
            raise ValueError("qty must be an int >= 1")
        with self._lock:
            avail = self._available(sku)
            if qty > avail:
                raise OutOfStock(f"{sku}: need {qty}, {avail} available")
            reservation = Reservation(sku, qty)
            self._open[id(reservation)] = (reservation, sku, qty)
            self._held[sku] = self._held.get(sku, 0) + qty
            return reservation

    def commit(self, reservation):
        with self._lock:
            sku, qty = self._close(reservation)
            self._on_hand[sku] -= qty

    def release(self, reservation):
        with self._lock:
            self._close(reservation)

    def _available(self, sku):  # caller holds the lock
        return self._on_hand.get(sku, 0) - self._held.get(sku, 0)

    def _close(self, reservation):  # caller holds the lock; returns the granted (sku, qty)
        entry = self._open.get(id(reservation))
        if entry is None or entry[0] is not reservation:
            raise ReservationError("reservation is not open in this inventory")
        del self._open[id(reservation)]
        _, sku, qty = entry
        self._held[sku] -= qty
        return sku, qty

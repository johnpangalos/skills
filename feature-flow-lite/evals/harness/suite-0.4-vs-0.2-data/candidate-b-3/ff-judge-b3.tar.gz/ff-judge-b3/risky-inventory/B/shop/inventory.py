"""Stock on hand, with reservations that are committed or released."""

import threading

from shop.catalog import lookup


class OutOfStock(ValueError):
    pass


class ReservationError(ValueError):
    pass


class Reservation:
    def __init__(self, sku, qty):
        self._sku = sku
        self._qty = qty

    @property
    def sku(self):
        return self._sku

    @property
    def qty(self):
        return self._qty


def _is_count(value, minimum):
    return type(value) is int and value >= minimum


class Inventory:
    def __init__(self, stock):
        for sku, units in stock.items():
            lookup(sku)
            if not _is_count(units, 0):
                raise ValueError(f"units on hand for {sku} must be an int >= 0")
        self._lock = threading.Lock()
        self._on_hand = dict(stock)
        self._held = {}
        self._open = set()

    def _free(self, sku):
        return self._on_hand.get(sku, 0) - self._held.get(sku, 0)

    def available(self, sku):
        lookup(sku)
        with self._lock:
            return self._free(sku)

    def reserve(self, sku, qty):
        lookup(sku)
        if not _is_count(qty, 1):
            raise ValueError("qty must be an int >= 1")
        with self._lock:
            free = self._free(sku)
            if free < qty:
                raise OutOfStock(f"{sku}: {qty} requested, {free} available")
            reservation = Reservation(sku, qty)
            self._held[sku] = self._held.get(sku, 0) + qty
            self._open.add(reservation)
            return reservation

    def commit(self, reservation):
        with self._lock:
            self._settle(reservation)
            self._on_hand[reservation.sku] -= reservation.qty

    def release(self, reservation):
        with self._lock:
            self._settle(reservation)

    def _settle(self, reservation):
        if not isinstance(reservation, Reservation) or reservation not in self._open:
            raise ReservationError("reservation is not open in this inventory")
        self._open.remove(reservation)
        self._held[reservation.sku] -= reservation.qty

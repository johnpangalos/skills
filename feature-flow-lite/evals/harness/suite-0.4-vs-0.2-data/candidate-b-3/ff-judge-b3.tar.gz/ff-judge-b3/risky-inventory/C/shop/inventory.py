"""Stock on hand and reservations, safe to share across checkout threads."""

import threading
from dataclasses import dataclass

from shop.catalog import PRODUCTS, lookup


class OutOfStock(ValueError):
    pass


class ReservationError(ValueError):
    pass


@dataclass(frozen=True, eq=False)  # identity equality: each reservation settles once
class Reservation:
    sku: str
    qty: int


class Inventory:
    def __init__(self, stock):
        self._lock = threading.Lock()
        self._on_hand = dict.fromkeys(PRODUCTS, 0)
        self._held = dict.fromkeys(PRODUCTS, 0)
        self._open = set()
        for sku, units in stock.items():
            lookup(sku)
            if type(units) is not int or units < 0:
                raise ValueError("on hand must be a non-negative int")
            self._on_hand[sku] = units

    def available(self, sku):
        """Return units on hand not held by open reservations."""
        lookup(sku)
        with self._lock:
            return self._on_hand[sku] - self._held[sku]

    def reserve(self, sku, qty):
        """Hold qty units of sku for checkout."""
        lookup(sku)
        if type(qty) is not int or qty < 1:
            raise ValueError("qty must be a positive int")
        with self._lock:
            if self._on_hand[sku] - self._held[sku] < qty:
                raise OutOfStock(sku)
            reservation = Reservation(sku, qty)
            self._held[sku] += qty
            self._open.add(reservation)
            return reservation

    def commit(self, reservation):
        """Remove a held reservation's units from stock for good."""
        with self._lock:
            self._close(reservation)
            self._on_hand[reservation.sku] -= reservation.qty

    def release(self, reservation):
        """Return a held reservation's units to available stock."""
        with self._lock:
            self._close(reservation)

    def _close(self, reservation):
        """Settle an open reservation; the caller holds the lock."""
        if not isinstance(reservation, Reservation) or reservation not in self._open:
            raise ReservationError("reservation is not open")
        self._open.remove(reservation)
        self._held[reservation.sku] -= reservation.qty

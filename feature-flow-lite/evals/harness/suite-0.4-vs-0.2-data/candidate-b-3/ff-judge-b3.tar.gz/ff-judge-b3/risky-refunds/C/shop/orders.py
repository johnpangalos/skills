"""Orders and refunds (in-memory, thread-safe)."""

import threading
import uuid
from dataclasses import dataclass
from decimal import Decimal

from shop.money import CENT, to_cents


class RefundError(ValueError):
    pass


@dataclass(frozen=True)
class Refund:
    order_id: str
    amount: Decimal
    key: str


class Order:
    def __init__(self, total):
        self.id = uuid.uuid4().hex
        self.total = total
        self._lock = threading.Lock()
        self._refunds = {}  # key -> Refund

    def refunded(self):
        with self._lock:
            return self._refunded_unlocked()

    def refundable(self):
        return self.total - self.refunded()

    def _refunded_unlocked(self):
        return sum((r.amount for r in self._refunds.values()), Decimal("0.00"))

    def _record_refund(self, amount, key):
        """Check the cap and record atomically. amount is already validated."""
        with self._lock:
            existing = self._refunds.get(key)
            if existing is not None:
                if existing.amount != amount:
                    raise RefundError("key already used for a different amount")
                return existing
            if amount > self.total - self._refunded_unlocked():
                raise RefundError("amount exceeds refundable balance")
            record = Refund(self.id, amount, key)
            self._refunds[key] = record
            return record


def place_order(cart):
    """Create an Order for the cart's current total."""
    if not cart.items:
        raise ValueError("cart is empty")
    return Order(to_cents(cart.total()))


def refund(order, amount, key):
    """Refund amount from order. A repeated key returns the original Refund."""
    if not isinstance(amount, Decimal) or not amount.is_finite():
        raise RefundError("amount must be a finite Decimal")
    if amount <= 0:
        raise RefundError("amount must be positive")
    if amount > order.total:
        raise RefundError("amount exceeds order total")
    if amount != amount.quantize(CENT):
        raise RefundError("amount must be whole cents")
    return order._record_refund(to_cents(amount), key)

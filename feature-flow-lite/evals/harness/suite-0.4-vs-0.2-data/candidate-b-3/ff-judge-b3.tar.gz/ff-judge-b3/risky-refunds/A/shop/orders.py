"""Orders and partial refunds (per-order lock, idempotent by key)."""

import itertools
import threading
from dataclasses import dataclass, field
from decimal import Decimal, InvalidOperation

from shop.money import CENT

BAD_AMOUNT = "amount must be a positive whole-cent Decimal"

_order_ids = itertools.count(1)
_order_ids_lock = threading.Lock()


class RefundError(ValueError):
    pass


@dataclass(eq=False)
class Order:
    """A placed order; its refunds are kept on it, keyed by idempotency key."""

    id: int
    total: Decimal
    refunds: dict = field(default_factory=dict)
    lock: threading.Lock = field(default_factory=threading.Lock, repr=False)

    def refunded(self):
        """Sum of this order's refunds."""
        # snapshot so a concurrent refund() cannot resize the dict mid-sum
        return sum((r.amount for r in list(self.refunds.values())), Decimal("0.00"))

    def refundable(self):
        """Amount that can still be refunded."""
        return self.total - self.refunded()


@dataclass(frozen=True)
class Refund:
    """One refund against an order."""

    order_id: int
    amount: Decimal
    key: str


def place_order(cart):
    """Freeze the cart's current total into a new Order."""
    if not cart.items:
        raise ValueError("cart is empty")
    with _order_ids_lock:
        order_id = next(_order_ids)
    return Order(order_id, cart.total())


def _whole_cents(amount):
    """Return amount as a whole-cent Decimal, or raise RefundError."""
    if not isinstance(amount, Decimal) or not amount.is_finite() or amount <= 0:
        raise RefundError(BAD_AMOUNT)
    try:
        cents = amount.quantize(CENT)
    except InvalidOperation:
        raise RefundError(BAD_AMOUNT) from None
    if cents != amount:
        raise RefundError(BAD_AMOUNT)
    return cents


def refund(order, amount, key):
    """Refund part of an order. A key already used returns its original Refund."""
    cents = _whole_cents(amount)
    with order.lock:
        earlier = order.refunds.get(key)
        if earlier is not None:
            if earlier.amount != cents:
                raise RefundError("key already used for a different amount")
            return earlier
        if order.refunded() + cents > order.total:
            raise RefundError("amount exceeds refundable balance")
        record = Refund(order.id, cents, key)
        order.refunds[key] = record
        return record

"""Orders and partial, idempotent refunds (in-memory)."""

import threading
import uuid
from dataclasses import dataclass
from decimal import MAX_PREC, Decimal, localcontext

from shop.money import CENT

# Amounts with more integer digits than this are refused before quantizing:
# quantizing something like 9E+999999999 to cents would build a huge coefficient.
MAX_INTEGER_DIGITS = 100


class RefundError(ValueError):
    pass


@dataclass(frozen=True)
class Refund:
    order_id: str
    amount: Decimal
    key: str


class Order:
    def __init__(self, order_id, total):
        self.id = order_id
        self.total = total
        self._by_key = {}  # insertion-ordered: key -> Refund
        self._lock = threading.Lock()

    @property
    def refunds(self):
        """Refunds recorded so far, oldest first."""
        with self._lock:
            return tuple(self._by_key.values())

    def refunded(self):
        """Sum of this order's refunds."""
        with self._lock:
            return self._sum()

    def refundable(self):
        """Amount of the total not yet refunded."""
        refunded = self.refunded()
        with localcontext(prec=MAX_PREC):
            return self.total - refunded

    def _sum(self):
        with localcontext(prec=MAX_PREC):
            return sum((r.amount for r in self._by_key.values()), Decimal("0.00"))


def place_order(cart):
    """Freeze the cart's current total into a new Order."""
    if not cart.items:
        raise ValueError("cannot place an order for an empty cart")
    return Order(uuid.uuid4().hex, cart.total())


def refund(order, amount, key):
    """Refund amount from order. Repeating a key with the same amount returns the original Refund."""
    if not isinstance(key, str) or not key:
        raise RefundError("key must be a non-empty string")
    amount = _whole_cents(amount)
    with order._lock:
        prior = order._by_key.get(key)
        if prior is not None:
            if prior.amount != amount:
                raise RefundError("key was already used for a different amount")
            return prior
        with localcontext(prec=MAX_PREC):
            over_total = order._sum() + amount > order.total
        if over_total:
            raise RefundError("refund would exceed the order total")
        record = Refund(order.id, amount, key)
        order._by_key[key] = record
        return record


def _whole_cents(amount):
    """Return amount as Decimal cents, or raise RefundError if it is not a positive whole number of cents."""
    if not isinstance(amount, Decimal) or not amount.is_finite() or amount <= 0:
        raise RefundError("amount must be a positive, finite Decimal")
    if amount.adjusted() > MAX_INTEGER_DIGITS:
        raise RefundError("amount is out of range")
    # Quantize under MAX_PREC so wide whole-cent amounts do not hit the default 28-digit limit.
    with localcontext(prec=MAX_PREC):
        cents = amount.quantize(CENT)
    if cents != amount:
        raise RefundError("amount must be a whole number of cents")
    return cents

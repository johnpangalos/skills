# shop

Checkout logic for a small online coffee shop: catalog, cart totals, receipts,
orders with partial refunds, and password-reset tokens. Standard library only.
Refunds are whole cents, may be repeated up to the order total, and a repeated key returns its original refund.

    ./check.sh        # lint + unit tests (run before every commit)

Money is `Decimal` dollars, rounded to cents half-up (`shop/money.py`).
Shipping is a flat $7.95, free once the merchandise subtotal reaches $75.
Sales tax is 8.25% of merchandise only; shipping is not taxed.

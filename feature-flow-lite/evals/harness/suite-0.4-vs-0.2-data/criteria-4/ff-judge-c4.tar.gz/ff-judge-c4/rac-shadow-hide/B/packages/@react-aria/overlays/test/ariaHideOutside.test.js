/*
 * Copyright 2020 Adobe. All rights reserved.
 * This file is licensed to you under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License. You may obtain a copy
 * of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software distributed under
 * the License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR REPRESENTATIONS
 * OF ANY KIND, either express or implied. See the License for the specific language
 * governing permissions and limitations under the License.
 */

import {act, createShadowRoot, render, waitFor} from '@react-spectrum/test-utils-internal';
import {ariaHideOutside} from '../src';
import {enableShadowDOM} from '@react-stately/flags';
import {keepVisible} from '../src/ariaHideOutside';
import React, {useRef, useState} from 'react';

describe('ariaHideOutside', function () {
  it('should hide everything except the provided element [button]', function () {
    let {getByRole, getAllByRole} = render(
      <>
        <input type="checkbox" />
        <button>Button</button>
        <input type="checkbox" />
      </>
    );

    let checkboxes = getAllByRole('checkbox');
    let button = getByRole('button');

    let revert = ariaHideOutside([button]);

    expect(checkboxes[0]).toHaveAttribute('aria-hidden', 'true');
    expect(checkboxes[1]).toHaveAttribute('aria-hidden', 'true');
    expect(button).not.toHaveAttribute('aria-hidden');

    expect(() => getAllByRole('checkbox')).toThrow();
    expect(() => getByRole('button')).not.toThrow();

    revert();

    expect(checkboxes[0]).not.toHaveAttribute('aria-hidden');
    expect(checkboxes[1]).not.toHaveAttribute('aria-hidden');
    expect(button).not.toHaveAttribute('aria-hidden');

    expect(() => getAllByRole('checkbox')).not.toThrow();
    expect(() => getByRole('button')).not.toThrow();
  });

  it('should hide everything except multiple elements', function () {
    let {getByRole, getAllByRole, queryByRole, queryAllByRole} = render(
      <>
        <input type="checkbox" />
        <button>Button</button>
        <input type="checkbox" />
      </>
    );

    let checkboxes = getAllByRole('checkbox');
    let button = getByRole('button');

    let revert = ariaHideOutside(checkboxes);

    expect(checkboxes[0]).not.toHaveAttribute('aria-hidden', 'true');
    expect(checkboxes[1]).not.toHaveAttribute('aria-hidden', 'true');
    expect(button).toHaveAttribute('aria-hidden');

    expect(queryAllByRole('checkbox')).not.toBeNull();
    expect(queryByRole('button')).toBeNull();

    revert();

    expect(checkboxes[0]).not.toHaveAttribute('aria-hidden');
    expect(checkboxes[1]).not.toHaveAttribute('aria-hidden');
    expect(button).not.toHaveAttribute('aria-hidden');

    expect(() => getAllByRole('checkbox')).not.toThrow();
    expect(() => getByRole('button')).not.toThrow();
  });

  it('should not traverse into an already hidden container', function () {
    let {getByRole, getAllByRole} = render(
      <>
        <div>
          <input type="checkbox" />
        </div>
        <button>Button</button>
        <input type="checkbox" />
      </>
    );

    let checkboxes = getAllByRole('checkbox');
    let button = getByRole('button');

    let revert = ariaHideOutside([button]);

    expect(checkboxes[0].parentElement).toHaveAttribute('aria-hidden', 'true');
    expect(checkboxes[1]).toHaveAttribute('aria-hidden', 'true');
    expect(button).not.toHaveAttribute('aria-hidden');

    expect(() => getAllByRole('checkbox')).toThrow();
    expect(() => getByRole('button')).not.toThrow();

    revert();

    expect(checkboxes[0].parentElement).not.toHaveAttribute('aria-hidden');
    expect(checkboxes[1]).not.toHaveAttribute('aria-hidden');
    expect(button).not.toHaveAttribute('aria-hidden');

    expect(() => getAllByRole('checkbox')).not.toThrow();
    expect(() => getByRole('button')).not.toThrow();
  });

  it('should not overwrite an existing aria-hidden prop', function () {
    let {getByRole, getAllByRole} = render(
      <>
        <input type="checkbox" aria-hidden="true" />
        <button>Button</button>
        <input type="checkbox" />
      </>
    );

    let checkboxes = getAllByRole('checkbox');
    let button = getByRole('button');

    let revert = ariaHideOutside([button]);

    expect(checkboxes).toHaveLength(1);
    expect(checkboxes[0]).toHaveAttribute('aria-hidden', 'true');
    expect(button).not.toHaveAttribute('aria-hidden');

    expect(() => getAllByRole('checkbox')).toThrow();
    expect(() => getByRole('button')).not.toThrow();

    revert();

    checkboxes = getAllByRole('checkbox');
    expect(checkboxes).toHaveLength(1);
    expect(checkboxes[0]).not.toHaveAttribute('aria-hidden');
    expect(button).not.toHaveAttribute('aria-hidden');

    expect(() => getAllByRole('checkbox')).not.toThrow();
    expect(() => getByRole('button')).not.toThrow();
  });

  it('should handle when a new element is added outside while active', async function () {
    let Test = props => (
      <>
        {props.show && <input type="checkbox" />}
        <button>Button</button>
        {props.show && <input type="checkbox" />}
      </>
    );

    let {getByRole, getAllByRole, rerender} = render(<Test />);

    let button = getByRole('button');
    expect(() => getAllByRole('checkbox')).toThrow();

    let revert = ariaHideOutside([button]);

    rerender(<Test show />);

    // MutationObserver is async
    await waitFor(() => expect(() => getAllByRole('checkbox')).toThrow());
    expect(() => getByRole('button')).not.toThrow();

    revert();

    expect(getAllByRole('checkbox')).toHaveLength(2);
  });

  it('should handle when a new element is added to an already hidden container', async function () {
    let Test = props => (
      <>
        <div data-testid="test">
          {props.show && <input type="checkbox" />}
        </div>
        <button>Button</button>
        {props.show && <input type="checkbox" />}
      </>
    );

    let {getByRole, getAllByRole, getByTestId, rerender} = render(<Test />);

    let button = getByRole('button');
    let test = getByTestId('test');
    expect(() => getAllByRole('checkbox')).toThrow();

    let revert = ariaHideOutside([button]);

    expect(test).toHaveAttribute('aria-hidden');

    rerender(<Test show />);

    // MutationObserver is async
    await waitFor(() => expect(() => getAllByRole('checkbox')).toThrow());
    expect(() => getByRole('button')).not.toThrow();

    let checkboxes = getAllByRole('checkbox', {hidden: true});
    expect(test).toHaveAttribute('aria-hidden');
    expect(checkboxes[0]).not.toHaveAttribute('aria-hidden');
    expect(checkboxes[1]).toHaveAttribute('aria-hidden', 'true');

    revert();

    expect(getAllByRole('checkbox')).toHaveLength(2);
  });

  it('should handle when a new element is added along with a top layer element', async function () {
    let Test = props => (
      <>
        <button>Button</button>
        {props.show && <div>
          <div role="alert" data-react-aria-top-layer="true">Top layer</div>
          <input type="checkbox" />
        </div>}
      </>
    );

    let {getByRole, queryByRole, getAllByRole, rerender} = render(<Test />);

    let button = getByRole('button');
    expect(queryByRole('checkbox')).toBeNull();

    let revert = ariaHideOutside([button]);

    rerender(<Test show />);

    // MutationObserver is async
    await waitFor(() => queryByRole('checkbox') == null);
    expect(queryByRole('button')).not.toBeNull();
    expect(getByRole('alert')).toHaveTextContent('Top layer');

    revert();

    expect(getAllByRole('checkbox')).toHaveLength(1);
  });

  it('should handle when a new element is added inside a target element', async function () {
    let Test = props => (
      <>
        <input type="checkbox" />
        <div data-testid="test">
          <button>Button</button>
          {props.show && <input type="radio" />}
        </div>
        <input type="checkbox" />
      </>
    );

    let {queryByRole, getByRole, getAllByRole, getByTestId, rerender} = render(<Test />);

    let test = getByTestId('test');
    let revert = ariaHideOutside([test]);

    expect(() => getAllByRole('checkbox')).toThrow();
    expect(queryByRole('radio')).toBeNull();
    expect(queryByRole('button')).not.toBeNull();
    expect(() => getByTestId('test')).not.toThrow();

    rerender(<Test show />);

    // Wait for mutation observer tick
    await Promise.resolve();
    expect(() => getAllByRole('checkbox')).toThrow();
    expect(() => getByRole('radio')).not.toThrow();
    expect(() => getByRole('button')).not.toThrow();
    expect(() => getByTestId('test')).not.toThrow();

    revert();

    expect(() => getAllByRole('checkbox')).not.toThrow();
    expect(() => getByRole('radio')).not.toThrow();
    expect(() => getByRole('button')).not.toThrow();
    expect(() => getByTestId('test')).not.toThrow();
  });

  it('should handle when a new element is added and then reparented', async function () {

    let Test = () => {
      const ref = useRef(null);
      const mutate = () => {
        let parent = document.createElement('ul');
        let child = document.createElement('li');
        ref.current.append(parent);
        parent.appendChild(child);
        parent.remove(); // this results in a mutation record for a disconnected ul with a connected li (through the new ul parent) in `addedNodes`
        let newParent = document.createElement('ul');
        newParent.appendChild(child);
        ref.current.append(newParent);
      };

      return (
        <>
          <div data-testid="test" ref={ref}>
            <button onClick={mutate}>Mutate</button>
          </div>
        </>
      );
    };

    let {queryByRole, getAllByRole, getByTestId} = render(<Test />);

    ariaHideOutside([getByTestId('test')]);

    queryByRole('button').click();
    await Promise.resolve(); // Wait for mutation observer tick

    expect(getAllByRole('listitem')).toHaveLength(1);
  });

  it('should handle when a new element is added and then reparented to a hidden container', async function () {

    let Test = () => {
      const ref = useRef(null);
      const mutate = () => {
        let parent = document.createElement('ul');
        let child = document.createElement('li');
        ref.current.append(parent);
        parent.appendChild(child);
        parent.remove(); // this results in a mutation record for a disconnected ul with a connected li (through the new ul parent) in `addedNodes`
        let newParent = document.createElement('ul');
        newParent.appendChild(child);
        ref.current.append(newParent);
      };

      return (
        <>
          <div data-testid="test">
            <button onClick={mutate}>Mutate</button>
          </div>
          <div data-testid="sibling" ref={ref} />
        </>
      );
    };

    let {queryByRole, queryAllByRole, getByTestId} = render(<Test />);

    ariaHideOutside([getByTestId('test')]);

    queryByRole('button').click();
    await Promise.resolve(); // Wait for mutation observer tick

    expect(queryAllByRole('listitem')).toHaveLength(0);
  });


  it('work when called multiple times', function () {
    let {getByRole, getAllByRole} = render(
      <>
        <input type="checkbox" />
        <input type="radio" />
        <button>Button</button>
        <input type="radio" />
        <input type="checkbox" />
      </>
    );

    let radios = getAllByRole('radio');
    let button = getByRole('button');

    let revert1 = ariaHideOutside([button, ...radios]);

    expect(() => getAllByRole('checkbox')).toThrow();
    expect(() => getAllByRole('radio')).not.toThrow();
    expect(() => getByRole('button')).not.toThrow();

    let revert2 = ariaHideOutside([button]);

    expect(() => getAllByRole('checkbox')).toThrow();
    expect(() => getAllByRole('radio')).toThrow();
    expect(() => getByRole('button')).not.toThrow();

    revert2();

    expect(() => getAllByRole('checkbox')).toThrow();
    expect(() => getAllByRole('radio')).not.toThrow();
    expect(() => getByRole('button')).not.toThrow();

    revert1();

    expect(() => getAllByRole('checkbox')).not.toThrow();
    expect(() => getAllByRole('radio')).not.toThrow();
    expect(() => getByRole('button')).not.toThrow();
  });

  it('work when called multiple times and restored out of order', function () {
    let {getByRole, getAllByRole} = render(
      <>
        <input type="checkbox" />
        <input type="radio" />
        <button>Button</button>
        <input type="radio" />
        <input type="checkbox" />
      </>
    );

    let radios = getAllByRole('radio');
    let button = getByRole('button');

    let revert1 = ariaHideOutside([button, ...radios]);

    expect(() => getAllByRole('checkbox')).toThrow();
    expect(() => getAllByRole('radio')).not.toThrow();
    expect(() => getByRole('button')).not.toThrow();

    let revert2 = ariaHideOutside([button]);

    expect(() => getAllByRole('checkbox')).toThrow();
    expect(() => getAllByRole('radio')).toThrow();
    expect(() => getByRole('button')).not.toThrow();

    revert1();

    expect(() => getAllByRole('checkbox')).toThrow();
    expect(() => getAllByRole('radio')).toThrow();
    expect(() => getByRole('button')).not.toThrow();

    revert2();

    expect(() => getAllByRole('checkbox')).not.toThrow();
    expect(() => getAllByRole('radio')).not.toThrow();
    expect(() => getByRole('button')).not.toThrow();
  });

  it('should hide everything except the provided element [row]', function () {
    let {getAllByRole, getByTestId} = render(
      <div role="grid">
        <div role="row">
          <div role="gridcell">
            <span data-testid="test-span">
              Cell 1
            </span></div>
        </div>
        <div role="row">
          <div role="gridcell">Cell 2</div>
        </div>
      </div>
    );

    let cells = getAllByRole('gridcell');
    let rows = getAllByRole('row');
    let span = getByTestId('test-span');

    let revert = ariaHideOutside([rows[1]]);

    // Applies aria-hidden to the row and cell despite recursive nature of aria-hidden
    // for https://bugs.webkit.org/show_bug.cgi?id=222623
    expect(rows[0]).toHaveAttribute('aria-hidden', 'true');
    expect(cells[0]).toHaveAttribute('aria-hidden', 'true');
    expect(span).not.toHaveAttribute('aria-hidden');
    expect(rows[1]).not.toHaveAttribute('aria-hidden', 'true');
    expect(cells[1]).not.toHaveAttribute('aria-hidden', 'true');

    revert();

    expect(rows[0]).not.toHaveAttribute('aria-hidden', 'true');
    expect(cells[0]).not.toHaveAttribute('aria-hidden', 'true');
    expect(rows[1]).not.toHaveAttribute('aria-hidden', 'true');
    expect(cells[1]).not.toHaveAttribute('aria-hidden', 'true');
    expect(span).not.toHaveAttribute('aria-hidden');
  });

  it('should unhide after item reorder', async function () {
    function Item(props) {
      return (
        <div role="presentation">
          <div data-testid={props.testid} role="row">
            <div role="gridcell" />
          </div>
        </div>
      );
    }

    function Test() {
      let [count, setCount] = useState(0);
      let items = ['row1', 'row2', 'row3', 'row4', 'row5'];
      if (count === 1) {
        items = ['row2', 'row1', 'row3', 'row4', 'row5'];
      } else if (count === 2) {
        items = ['row2', 'row3', 'row1', 'row4', 'row5'];
      }

      return (
        <>
          <button onClick={() => setCount((old) => old + 1)}>press</button>
          {items.map((item) => <Item testid={item} key={item} />)}
        </>

      );
    }

    let {getByRole, getByTestId} = render(
      <Test />
    );

    let button = getByRole('button');
    let row = getByTestId('row1');
    let revert = ariaHideOutside([button]);

    act(() => button.click());
    await Promise.resolve();
    act(() => button.click());
    await Promise.resolve();
    revert();
    expect(row.parentElement).not.toHaveAttribute('aria-hidden', 'true');
  });

  it('should not hide or observe shadow root contents when shadowDOM is disabled', async function () {
    let shadow = createShadowRoot();
    let target = document.createElement('button');
    let sibling = document.createElement('input');
    sibling.type = 'checkbox';
    shadow.shadowRoot.append(target, sibling);

    let revert = ariaHideOutside([target]);
    expect(sibling).not.toHaveAttribute('aria-hidden');

    let added = document.createElement('input');
    added.type = 'radio';
    shadow.shadowRoot.appendChild(added);
    await Promise.resolve();
    expect(added).not.toHaveAttribute('aria-hidden');

    revert();
    shadow.cleanup();
  });
});

describe('ariaHideOutside with Shadow DOM', function () {
  beforeAll(() => {
    enableShadowDOM();
  });

  it('should hide siblings at every shadow level and keep the hosts on the path visible', function () {
    let outer = createShadowRoot();
    let outerSibling = document.createElement('input');
    outerSibling.type = 'checkbox';
    outer.shadowRoot.appendChild(outerSibling);

    let inner = createShadowRoot(outer.shadowRoot);
    let innerSibling = document.createElement('input');
    innerSibling.type = 'radio';
    inner.shadowRoot.appendChild(innerSibling);
    let target = document.createElement('button');
    inner.shadowRoot.appendChild(target);

    let revert = ariaHideOutside([target]);

    expect(outerSibling).toHaveAttribute('aria-hidden', 'true');
    expect(innerSibling).toHaveAttribute('aria-hidden', 'true');
    expect(outer.shadowHost).not.toHaveAttribute('aria-hidden');
    expect(inner.shadowHost).not.toHaveAttribute('aria-hidden');
    expect(target).not.toHaveAttribute('aria-hidden');

    revert();

    expect(outerSibling).not.toHaveAttribute('aria-hidden');
    expect(innerSibling).not.toHaveAttribute('aria-hidden');
    expect(outer.shadowHost).not.toHaveAttribute('aria-hidden');
    expect(inner.shadowHost).not.toHaveAttribute('aria-hidden');
    outer.cleanup();
  });

  it('should hide a sibling host without marking the contents of its shadow root', function () {
    let shadow = createShadowRoot();
    let target = document.createElement('button');
    shadow.shadowRoot.appendChild(target);

    let siblingShadow = createShadowRoot(shadow.shadowRoot);
    let siblingChild = document.createElement('input');
    siblingShadow.shadowRoot.appendChild(siblingChild);

    let revert = ariaHideOutside([target]);

    expect(siblingShadow.shadowHost).toHaveAttribute('aria-hidden', 'true');
    expect(siblingChild).not.toHaveAttribute('aria-hidden');
    expect(target).not.toHaveAttribute('aria-hidden');

    revert();

    expect(siblingShadow.shadowHost).not.toHaveAttribute('aria-hidden');
    shadow.cleanup();
  });

  it('should keep an existing aria-hidden inside a shadow root after revert', function () {
    let shadow = createShadowRoot();
    let target = document.createElement('button');
    let hidden = document.createElement('input');
    hidden.setAttribute('aria-hidden', 'true');
    shadow.shadowRoot.append(target, hidden);

    let revert = ariaHideOutside([target]);
    expect(hidden).toHaveAttribute('aria-hidden', 'true');

    revert();
    expect(hidden).toHaveAttribute('aria-hidden', 'true');
    shadow.cleanup();
  });

  it('should keep live announcers and top layer elements in a shadow root visible', function () {
    let shadow = createShadowRoot();
    let target = document.createElement('button');
    let announcer = document.createElement('div');
    announcer.dataset.liveAnnouncer = 'true';
    let topLayer = document.createElement('div');
    topLayer.dataset.reactAriaTopLayer = 'true';
    shadow.shadowRoot.append(target, announcer, topLayer);

    let revert = ariaHideOutside([target]);

    expect(announcer).not.toHaveAttribute('aria-hidden');
    expect(topLayer).not.toHaveAttribute('aria-hidden');

    revert();
    shadow.cleanup();
  });

  it('should hide content added to a shadow root and keep announcers visible', async function () {
    let shadow = createShadowRoot();
    let target = document.createElement('button');
    let hiddenContainer = document.createElement('div');
    shadow.shadowRoot.append(target, hiddenContainer);

    let revert = ariaHideOutside([target]);

    let added = document.createElement('input');
    shadow.shadowRoot.appendChild(added);
    let announcer = document.createElement('div');
    announcer.dataset.liveAnnouncer = 'true';
    shadow.shadowRoot.appendChild(announcer);
    let nested = document.createElement('span');
    hiddenContainer.appendChild(nested);
    await Promise.resolve();

    expect(added).toHaveAttribute('aria-hidden', 'true');
    expect(announcer).not.toHaveAttribute('aria-hidden');
    expect(nested).not.toHaveAttribute('aria-hidden');
    expect(target).not.toHaveAttribute('aria-hidden');

    revert();
    shadow.cleanup();
  });

  it('should not hide content added inside a target in a shadow root', async function () {
    let shadow = createShadowRoot();
    let target = document.createElement('div');
    shadow.shadowRoot.appendChild(target);

    let revert = ariaHideOutside([target]);

    let added = document.createElement('input');
    target.appendChild(added);
    await Promise.resolve();

    expect(added).not.toHaveAttribute('aria-hidden');

    revert();
    shadow.cleanup();
  });

  it('should handle an element added in a shadow root and then reparented into a target', async function () {
    let shadow = createShadowRoot();
    let target = document.createElement('div');
    shadow.shadowRoot.appendChild(target);

    let revert = ariaHideOutside([target]);

    let wrapper = document.createElement('div');
    let input = document.createElement('input');
    wrapper.appendChild(input);
    shadow.shadowRoot.appendChild(wrapper);
    target.appendChild(input);
    await Promise.resolve();

    expect(wrapper).toHaveAttribute('aria-hidden', 'true');
    expect(input).not.toHaveAttribute('aria-hidden');

    revert();
    shadow.cleanup();
  });

  it('should keep targets in different shadow roots and light DOM visible and hide their siblings', async function () {
    let first = createShadowRoot();
    let input = document.createElement('input');
    let firstSibling = document.createElement('button');
    first.shadowRoot.append(input, firstSibling);

    let second = createShadowRoot();
    let popover = document.createElement('div');
    let secondSibling = document.createElement('button');
    second.shadowRoot.append(popover, secondSibling);

    let lightTarget = document.createElement('button');
    let lightSibling = document.createElement('button');
    document.body.append(lightTarget, lightSibling);

    let revert = ariaHideOutside([input, popover, lightTarget]);

    expect(first.shadowHost).not.toHaveAttribute('aria-hidden');
    expect(second.shadowHost).not.toHaveAttribute('aria-hidden');
    expect(input).not.toHaveAttribute('aria-hidden');
    expect(popover).not.toHaveAttribute('aria-hidden');
    expect(lightTarget).not.toHaveAttribute('aria-hidden');
    expect(firstSibling).toHaveAttribute('aria-hidden', 'true');
    expect(secondSibling).toHaveAttribute('aria-hidden', 'true');
    expect(lightSibling).toHaveAttribute('aria-hidden', 'true');

    let firstAdded = document.createElement('input');
    let secondAdded = document.createElement('input');
    first.shadowRoot.appendChild(firstAdded);
    second.shadowRoot.appendChild(secondAdded);
    await Promise.resolve();

    expect(firstAdded).toHaveAttribute('aria-hidden', 'true');
    expect(secondAdded).toHaveAttribute('aria-hidden', 'true');

    revert();

    expect(firstSibling).not.toHaveAttribute('aria-hidden');
    expect(secondSibling).not.toHaveAttribute('aria-hidden');
    expect(lightSibling).not.toHaveAttribute('aria-hidden');
    expect(firstAdded).not.toHaveAttribute('aria-hidden');
    expect(secondAdded).not.toHaveAttribute('aria-hidden');
    first.cleanup();
    second.cleanup();
    lightTarget.remove();
    lightSibling.remove();
  });

  it('should restore shadow root content out of order and stop observing it after revert', async function () {
    let shadow = createShadowRoot();
    let target1 = document.createElement('button');
    let target2 = document.createElement('button');
    let sibling = document.createElement('input');
    shadow.shadowRoot.append(target1, target2, sibling);

    let revert1 = ariaHideOutside([target1]);
    let revert2 = ariaHideOutside([target2]);
    expect(sibling).toHaveAttribute('aria-hidden', 'true');
    expect(target1).toHaveAttribute('aria-hidden', 'true');

    revert1();
    expect(sibling).toHaveAttribute('aria-hidden', 'true');
    expect(target1).toHaveAttribute('aria-hidden', 'true');

    revert2();
    expect(sibling).not.toHaveAttribute('aria-hidden');
    expect(target1).not.toHaveAttribute('aria-hidden');
    expect(target2).not.toHaveAttribute('aria-hidden');

    let added = document.createElement('input');
    shadow.shadowRoot.appendChild(added);
    await Promise.resolve();
    expect(added).not.toHaveAttribute('aria-hidden');
    shadow.cleanup();
  });

  it('should keep elements in a shadow root visible with keepVisible', async function () {
    let shadow = createShadowRoot();
    let target = document.createElement('button');
    shadow.shadowRoot.appendChild(target);

    let revert = ariaHideOutside([target]);

    let popover = document.createElement('div');
    shadow.shadowRoot.appendChild(popover);
    let undo = keepVisible(popover);
    await Promise.resolve();
    expect(popover).not.toHaveAttribute('aria-hidden');

    undo();
    revert();
    shadow.cleanup();
  });

  it('should only walk and observe shadow roots inside root', async function () {
    let shadow = createShadowRoot();
    let rootElement = document.createElement('div');
    let target = document.createElement('button');
    let sibling = document.createElement('input');
    rootElement.append(target, sibling);
    shadow.shadowRoot.appendChild(rootElement);

    let outsideBody = document.createElement('input');
    document.body.appendChild(outsideBody);

    let revert = ariaHideOutside([target], rootElement);

    expect(sibling).toHaveAttribute('aria-hidden', 'true');
    expect(target).not.toHaveAttribute('aria-hidden');
    expect(outsideBody).not.toHaveAttribute('aria-hidden');

    let added = document.createElement('input');
    shadow.shadowRoot.appendChild(added);
    await Promise.resolve();
    expect(added).not.toHaveAttribute('aria-hidden');

    revert();
    shadow.cleanup();
    outsideBody.remove();
  });

  it('should not hide a slot whose slotted light DOM target is visible', function () {
    let shadow = createShadowRoot();
    let slot = document.createElement('slot');
    let shadowTarget = document.createElement('button');
    shadow.shadowRoot.append(slot, shadowTarget);
    let slotted = document.createElement('button');
    shadow.shadowHost.appendChild(slotted);
    let outside = document.createElement('input');
    document.body.appendChild(outside);

    let revert = ariaHideOutside([shadowTarget, slotted]);

    expect(slot).not.toHaveAttribute('aria-hidden');
    expect(slotted).not.toHaveAttribute('aria-hidden');
    expect(shadowTarget).not.toHaveAttribute('aria-hidden');
    expect(shadow.shadowHost).not.toHaveAttribute('aria-hidden');
    expect(outside).toHaveAttribute('aria-hidden', 'true');

    revert();

    expect(slot).not.toHaveAttribute('aria-hidden');
    expect(slotted).not.toHaveAttribute('aria-hidden');
    expect(outside).not.toHaveAttribute('aria-hidden');
    outside.remove();
    shadow.cleanup();
  });

  it('should hide shadow only content of a host with a slotted target, including later additions', async function () {
    let shadow = createShadowRoot();
    let slot = document.createElement('slot');
    let chrome = document.createElement('button');
    shadow.shadowRoot.append(slot, chrome);
    let slotted = document.createElement('button');
    shadow.shadowHost.appendChild(slotted);

    let revert = ariaHideOutside([slotted]);

    expect(chrome).toHaveAttribute('aria-hidden', 'true');
    expect(slot).not.toHaveAttribute('aria-hidden');
    expect(shadow.shadowHost).not.toHaveAttribute('aria-hidden');
    expect(slotted).not.toHaveAttribute('aria-hidden');

    let added = document.createElement('input');
    shadow.shadowRoot.appendChild(added);
    await Promise.resolve();

    expect(added).toHaveAttribute('aria-hidden', 'true');
    expect(slot).not.toHaveAttribute('aria-hidden');
    expect(slotted).not.toHaveAttribute('aria-hidden');

    revert();

    expect(chrome).not.toHaveAttribute('aria-hidden');
    expect(added).not.toHaveAttribute('aria-hidden');
    expect(slot).not.toHaveAttribute('aria-hidden');
    expect(shadow.shadowHost).not.toHaveAttribute('aria-hidden');
    shadow.cleanup();
  });

  it('should keep a target visible through nested slot forwarding and hide siblings in the inner shadow root', function () {
    let shadow = createShadowRoot();
    let innerComp = document.createElement('inner-comp');
    let outerSlot = document.createElement('slot');
    innerComp.appendChild(outerSlot);
    shadow.shadowRoot.appendChild(innerComp);
    let innerRoot = innerComp.attachShadow({mode: 'open'});
    let innerSlot = document.createElement('slot');
    let innerChild = document.createElement('i');
    innerRoot.append(innerChild, innerSlot);
    let target = document.createElement('button');
    shadow.shadowHost.appendChild(target);

    let revert = ariaHideOutside([target]);

    expect(shadow.shadowHost).not.toHaveAttribute('aria-hidden');
    expect(innerComp).not.toHaveAttribute('aria-hidden');
    expect(outerSlot).not.toHaveAttribute('aria-hidden');
    expect(innerSlot).not.toHaveAttribute('aria-hidden');
    expect(innerChild).toHaveAttribute('aria-hidden', 'true');
    expect(target).not.toHaveAttribute('aria-hidden');

    revert();

    expect(innerChild).not.toHaveAttribute('aria-hidden');
    expect(innerComp).not.toHaveAttribute('aria-hidden');
    shadow.cleanup();
  });
});

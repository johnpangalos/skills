/*
 * Copyright 2020 Adobe. All rights reserved.
 * This file is licensed to you under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License. You may obtain a copy
 * of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software distributed under
 * the License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR REPRESENTATIONS
 * OF ANY KIND, either express or implied. See the License for the specific language
 * governing permissions and limitations under the License.
 */

import {act, render, waitFor} from '@react-spectrum/test-utils-internal';
import {ariaHideOutside} from '../src';
import {enableShadowDOM} from '@react-stately/flags';
import {keepVisible} from '../src/ariaHideOutside';
import React, {useRef, useState} from 'react';

describe('ariaHideOutside', function () {
  it('should hide everything except the provided element [button]', function () {
    let {getByRole, getAllByRole} = render(
      <>
        <input type="checkbox" />
        <button>Button</button>
        <input type="checkbox" />
      </>
    );

    let checkboxes = getAllByRole('checkbox');
    let button = getByRole('button');

    let revert = ariaHideOutside([button]);

    expect(checkboxes[0]).toHaveAttribute('aria-hidden', 'true');
    expect(checkboxes[1]).toHaveAttribute('aria-hidden', 'true');
    expect(button).not.toHaveAttribute('aria-hidden');

    expect(() => getAllByRole('checkbox')).toThrow();
    expect(() => getByRole('button')).not.toThrow();

    revert();

    expect(checkboxes[0]).not.toHaveAttribute('aria-hidden');
    expect(checkboxes[1]).not.toHaveAttribute('aria-hidden');
    expect(button).not.toHaveAttribute('aria-hidden');

    expect(() => getAllByRole('checkbox')).not.toThrow();
    expect(() => getByRole('button')).not.toThrow();
  });

  it('should hide everything except multiple elements', function () {
    let {getByRole, getAllByRole, queryByRole, queryAllByRole} = render(
      <>
        <input type="checkbox" />
        <button>Button</button>
        <input type="checkbox" />
      </>
    );

    let checkboxes = getAllByRole('checkbox');
    let button = getByRole('button');

    let revert = ariaHideOutside(checkboxes);

    expect(checkboxes[0]).not.toHaveAttribute('aria-hidden', 'true');
    expect(checkboxes[1]).not.toHaveAttribute('aria-hidden', 'true');
    expect(button).toHaveAttribute('aria-hidden');

    expect(queryAllByRole('checkbox')).not.toBeNull();
    expect(queryByRole('button')).toBeNull();

    revert();

    expect(checkboxes[0]).not.toHaveAttribute('aria-hidden');
    expect(checkboxes[1]).not.toHaveAttribute('aria-hidden');
    expect(button).not.toHaveAttribute('aria-hidden');

    expect(() => getAllByRole('checkbox')).not.toThrow();
    expect(() => getByRole('button')).not.toThrow();
  });

  it('should not traverse into an already hidden container', function () {
    let {getByRole, getAllByRole} = render(
      <>
        <div>
          <input type="checkbox" />
        </div>
        <button>Button</button>
        <input type="checkbox" />
      </>
    );

    let checkboxes = getAllByRole('checkbox');
    let button = getByRole('button');

    let revert = ariaHideOutside([button]);

    expect(checkboxes[0].parentElement).toHaveAttribute('aria-hidden', 'true');
    expect(checkboxes[1]).toHaveAttribute('aria-hidden', 'true');
    expect(button).not.toHaveAttribute('aria-hidden');

    expect(() => getAllByRole('checkbox')).toThrow();
    expect(() => getByRole('button')).not.toThrow();

    revert();

    expect(checkboxes[0].parentElement).not.toHaveAttribute('aria-hidden');
    expect(checkboxes[1]).not.toHaveAttribute('aria-hidden');
    expect(button).not.toHaveAttribute('aria-hidden');

    expect(() => getAllByRole('checkbox')).not.toThrow();
    expect(() => getByRole('button')).not.toThrow();
  });

  it('should not overwrite an existing aria-hidden prop', function () {
    let {getByRole, getAllByRole} = render(
      <>
        <input type="checkbox" aria-hidden="true" />
        <button>Button</button>
        <input type="checkbox" />
      </>
    );

    let checkboxes = getAllByRole('checkbox');
    let button = getByRole('button');

    let revert = ariaHideOutside([button]);

    expect(checkboxes).toHaveLength(1);
    expect(checkboxes[0]).toHaveAttribute('aria-hidden', 'true');
    expect(button).not.toHaveAttribute('aria-hidden');

    expect(() => getAllByRole('checkbox')).toThrow();
    expect(() => getByRole('button')).not.toThrow();

    revert();

    checkboxes = getAllByRole('checkbox');
    expect(checkboxes).toHaveLength(1);
    expect(checkboxes[0]).not.toHaveAttribute('aria-hidden');
    expect(button).not.toHaveAttribute('aria-hidden');

    expect(() => getAllByRole('checkbox')).not.toThrow();
    expect(() => getByRole('button')).not.toThrow();
  });

  it('should handle when a new element is added outside while active', async function () {
    let Test = props => (
      <>
        {props.show && <input type="checkbox" />}
        <button>Button</button>
        {props.show && <input type="checkbox" />}
      </>
    );

    let {getByRole, getAllByRole, rerender} = render(<Test />);

    let button = getByRole('button');
    expect(() => getAllByRole('checkbox')).toThrow();

    let revert = ariaHideOutside([button]);

    rerender(<Test show />);

    // MutationObserver is async
    await waitFor(() => expect(() => getAllByRole('checkbox')).toThrow());
    expect(() => getByRole('button')).not.toThrow();

    revert();

    expect(getAllByRole('checkbox')).toHaveLength(2);
  });

  it('should handle when a new element is added to an already hidden container', async function () {
    let Test = props => (
      <>
        <div data-testid="test">
          {props.show && <input type="checkbox" />}
        </div>
        <button>Button</button>
        {props.show && <input type="checkbox" />}
      </>
    );

    let {getByRole, getAllByRole, getByTestId, rerender} = render(<Test />);

    let button = getByRole('button');
    let test = getByTestId('test');
    expect(() => getAllByRole('checkbox')).toThrow();

    let revert = ariaHideOutside([button]);

    expect(test).toHaveAttribute('aria-hidden');

    rerender(<Test show />);

    // MutationObserver is async
    await waitFor(() => expect(() => getAllByRole('checkbox')).toThrow());
    expect(() => getByRole('button')).not.toThrow();

    let checkboxes = getAllByRole('checkbox', {hidden: true});
    expect(test).toHaveAttribute('aria-hidden');
    expect(checkboxes[0]).not.toHaveAttribute('aria-hidden');
    expect(checkboxes[1]).toHaveAttribute('aria-hidden', 'true');

    revert();

    expect(getAllByRole('checkbox')).toHaveLength(2);
  });

  it('should handle when a new element is added along with a top layer element', async function () {
    let Test = props => (
      <>
        <button>Button</button>
        {props.show && <div>
          <div role="alert" data-react-aria-top-layer="true">Top layer</div>
          <input type="checkbox" />
        </div>}
      </>
    );

    let {getByRole, queryByRole, getAllByRole, rerender} = render(<Test />);

    let button = getByRole('button');
    expect(queryByRole('checkbox')).toBeNull();

    let revert = ariaHideOutside([button]);

    rerender(<Test show />);

    // MutationObserver is async
    await waitFor(() => queryByRole('checkbox') == null);
    expect(queryByRole('button')).not.toBeNull();
    expect(getByRole('alert')).toHaveTextContent('Top layer');

    revert();

    expect(getAllByRole('checkbox')).toHaveLength(1);
  });

  it('should handle when a new element is added inside a target element', async function () {
    let Test = props => (
      <>
        <input type="checkbox" />
        <div data-testid="test">
          <button>Button</button>
          {props.show && <input type="radio" />}
        </div>
        <input type="checkbox" />
      </>
    );

    let {queryByRole, getByRole, getAllByRole, getByTestId, rerender} = render(<Test />);

    let test = getByTestId('test');
    let revert = ariaHideOutside([test]);

    expect(() => getAllByRole('checkbox')).toThrow();
    expect(queryByRole('radio')).toBeNull();
    expect(queryByRole('button')).not.toBeNull();
    expect(() => getByTestId('test')).not.toThrow();

    rerender(<Test show />);

    // Wait for mutation observer tick
    await Promise.resolve();
    expect(() => getAllByRole('checkbox')).toThrow();
    expect(() => getByRole('radio')).not.toThrow();
    expect(() => getByRole('button')).not.toThrow();
    expect(() => getByTestId('test')).not.toThrow();

    revert();

    expect(() => getAllByRole('checkbox')).not.toThrow();
    expect(() => getByRole('radio')).not.toThrow();
    expect(() => getByRole('button')).not.toThrow();
    expect(() => getByTestId('test')).not.toThrow();
  });

  it('should handle when a new element is added and then reparented', async function () {

    let Test = () => {
      const ref = useRef(null);
      const mutate = () => {
        let parent = document.createElement('ul');
        let child = document.createElement('li');
        ref.current.append(parent);
        parent.appendChild(child);
        parent.remove(); // this results in a mutation record for a disconnected ul with a connected li (through the new ul parent) in `addedNodes`
        let newParent = document.createElement('ul');
        newParent.appendChild(child);
        ref.current.append(newParent);
      };

      return (
        <>
          <div data-testid="test" ref={ref}>
            <button onClick={mutate}>Mutate</button>
          </div>
        </>
      );
    };

    let {queryByRole, getAllByRole, getByTestId} = render(<Test />);

    ariaHideOutside([getByTestId('test')]);

    queryByRole('button').click();
    await Promise.resolve(); // Wait for mutation observer tick

    expect(getAllByRole('listitem')).toHaveLength(1);
  });

  it('should handle when a new element is added and then reparented to a hidden container', async function () {

    let Test = () => {
      const ref = useRef(null);
      const mutate = () => {
        let parent = document.createElement('ul');
        let child = document.createElement('li');
        ref.current.append(parent);
        parent.appendChild(child);
        parent.remove(); // this results in a mutation record for a disconnected ul with a connected li (through the new ul parent) in `addedNodes`
        let newParent = document.createElement('ul');
        newParent.appendChild(child);
        ref.current.append(newParent);
      };

      return (
        <>
          <div data-testid="test">
            <button onClick={mutate}>Mutate</button>
          </div>
          <div data-testid="sibling" ref={ref} />
        </>
      );
    };

    let {queryByRole, queryAllByRole, getByTestId} = render(<Test />);

    ariaHideOutside([getByTestId('test')]);

    queryByRole('button').click();
    await Promise.resolve(); // Wait for mutation observer tick

    expect(queryAllByRole('listitem')).toHaveLength(0);
  });


  it('work when called multiple times', function () {
    let {getByRole, getAllByRole} = render(
      <>
        <input type="checkbox" />
        <input type="radio" />
        <button>Button</button>
        <input type="radio" />
        <input type="checkbox" />
      </>
    );

    let radios = getAllByRole('radio');
    let button = getByRole('button');

    let revert1 = ariaHideOutside([button, ...radios]);

    expect(() => getAllByRole('checkbox')).toThrow();
    expect(() => getAllByRole('radio')).not.toThrow();
    expect(() => getByRole('button')).not.toThrow();

    let revert2 = ariaHideOutside([button]);

    expect(() => getAllByRole('checkbox')).toThrow();
    expect(() => getAllByRole('radio')).toThrow();
    expect(() => getByRole('button')).not.toThrow();

    revert2();

    expect(() => getAllByRole('checkbox')).toThrow();
    expect(() => getAllByRole('radio')).not.toThrow();
    expect(() => getByRole('button')).not.toThrow();

    revert1();

    expect(() => getAllByRole('checkbox')).not.toThrow();
    expect(() => getAllByRole('radio')).not.toThrow();
    expect(() => getByRole('button')).not.toThrow();
  });

  it('work when called multiple times and restored out of order', function () {
    let {getByRole, getAllByRole} = render(
      <>
        <input type="checkbox" />
        <input type="radio" />
        <button>Button</button>
        <input type="radio" />
        <input type="checkbox" />
      </>
    );

    let radios = getAllByRole('radio');
    let button = getByRole('button');

    let revert1 = ariaHideOutside([button, ...radios]);

    expect(() => getAllByRole('checkbox')).toThrow();
    expect(() => getAllByRole('radio')).not.toThrow();
    expect(() => getByRole('button')).not.toThrow();

    let revert2 = ariaHideOutside([button]);

    expect(() => getAllByRole('checkbox')).toThrow();
    expect(() => getAllByRole('radio')).toThrow();
    expect(() => getByRole('button')).not.toThrow();

    revert1();

    expect(() => getAllByRole('checkbox')).toThrow();
    expect(() => getAllByRole('radio')).toThrow();
    expect(() => getByRole('button')).not.toThrow();

    revert2();

    expect(() => getAllByRole('checkbox')).not.toThrow();
    expect(() => getAllByRole('radio')).not.toThrow();
    expect(() => getByRole('button')).not.toThrow();
  });

  it('should hide everything except the provided element [row]', function () {
    let {getAllByRole, getByTestId} = render(
      <div role="grid">
        <div role="row">
          <div role="gridcell">
            <span data-testid="test-span">
              Cell 1
            </span></div>
        </div>
        <div role="row">
          <div role="gridcell">Cell 2</div>
        </div>
      </div>
    );

    let cells = getAllByRole('gridcell');
    let rows = getAllByRole('row');
    let span = getByTestId('test-span');

    let revert = ariaHideOutside([rows[1]]);

    // Applies aria-hidden to the row and cell despite recursive nature of aria-hidden
    // for https://bugs.webkit.org/show_bug.cgi?id=222623
    expect(rows[0]).toHaveAttribute('aria-hidden', 'true');
    expect(cells[0]).toHaveAttribute('aria-hidden', 'true');
    expect(span).not.toHaveAttribute('aria-hidden');
    expect(rows[1]).not.toHaveAttribute('aria-hidden', 'true');
    expect(cells[1]).not.toHaveAttribute('aria-hidden', 'true');

    revert();

    expect(rows[0]).not.toHaveAttribute('aria-hidden', 'true');
    expect(cells[0]).not.toHaveAttribute('aria-hidden', 'true');
    expect(rows[1]).not.toHaveAttribute('aria-hidden', 'true');
    expect(cells[1]).not.toHaveAttribute('aria-hidden', 'true');
    expect(span).not.toHaveAttribute('aria-hidden');
  });

  it('should unhide after item reorder', async function () {
    function Item(props) {
      return (
        <div role="presentation">
          <div data-testid={props.testid} role="row">
            <div role="gridcell" />
          </div>
        </div>
      );
    }

    function Test() {
      let [count, setCount] = useState(0);
      let items = ['row1', 'row2', 'row3', 'row4', 'row5'];
      if (count === 1) {
        items = ['row2', 'row1', 'row3', 'row4', 'row5'];
      } else if (count === 2) {
        items = ['row2', 'row3', 'row1', 'row4', 'row5'];
      }

      return (
        <>
          <button onClick={() => setCount((old) => old + 1)}>press</button>
          {items.map((item) => <Item testid={item} key={item} />)}
        </>

      );
    }

    let {getByRole, getByTestId} = render(
      <Test />
    );

    let button = getByRole('button');
    let row = getByTestId('row1');
    let revert = ariaHideOutside([button]);

    act(() => button.click());
    await Promise.resolve();
    act(() => button.click());
    await Promise.resolve();
    revert();
    expect(row.parentElement).not.toHaveAttribute('aria-hidden', 'true');
  });
});

describe('ariaHideOutside with Shadow DOM', function () {
  let container;
  let revertPlaceholder;

  let createElement = (parent, attributes = {}) => {
    let element = document.createElement('div');
    for (let name in attributes) {
      element.setAttribute(name, attributes[name]);
    }
    parent.appendChild(element);
    return element;
  };

  let createShadowHost = (parent) => {
    let host = createElement(parent);
    return {host, shadow: host.attachShadow({mode: 'open'})};
  };

  beforeAll(() => {
    enableShadowDOM();
  });

  beforeEach(() => {
    container = document.createElement('div');
    document.body.appendChild(container);
    // Earlier tests in this file leave ariaHideOutside calls active, and their observers watch document.body.
    // Keep the container visible to a placeholder call so those observers don't hide the test DOM.
    revertPlaceholder = ariaHideOutside([container]);
  });

  afterEach(() => {
    container.remove();
    revertPlaceholder();
  });

  it('should hide siblings in a shadow root and keep the shadow host and target visible', function () {
    let outside = createElement(container);
    let {host, shadow} = createShadowHost(container);
    let sibling = createElement(shadow);
    let target = createElement(shadow);

    let revert = ariaHideOutside([target]);

    expect(outside).toHaveAttribute('aria-hidden', 'true');
    expect(container).not.toHaveAttribute('aria-hidden');
    expect(host).not.toHaveAttribute('aria-hidden');
    expect(sibling).toHaveAttribute('aria-hidden', 'true');
    expect(target).not.toHaveAttribute('aria-hidden');

    revert();

    expect(outside).not.toHaveAttribute('aria-hidden');
    expect(sibling).not.toHaveAttribute('aria-hidden');
  });

  it('should hide siblings at every shadow level and keep each host visible', function () {
    let {host: hostA, shadow: shadowA} = createShadowHost(container);
    let siblingA = createElement(shadowA);
    let {host: hostB, shadow: shadowB} = createShadowHost(shadowA);
    let siblingB = createElement(shadowB);
    let target = createElement(shadowB);

    let revert = ariaHideOutside([target]);

    expect(siblingA).toHaveAttribute('aria-hidden', 'true');
    expect(hostA).not.toHaveAttribute('aria-hidden');
    expect(siblingB).toHaveAttribute('aria-hidden', 'true');
    expect(hostB).not.toHaveAttribute('aria-hidden');
    expect(target).not.toHaveAttribute('aria-hidden');

    revert();

    expect(siblingA).not.toHaveAttribute('aria-hidden');
    expect(siblingB).not.toHaveAttribute('aria-hidden');
  });

  it('should keep the shadow content of a target host visible', function () {
    let sibling = createElement(container);
    let {host, shadow} = createShadowHost(container);
    let content = createElement(shadow);

    let revert = ariaHideOutside([host]);

    expect(sibling).toHaveAttribute('aria-hidden', 'true');
    expect(host).not.toHaveAttribute('aria-hidden');
    expect(content).not.toHaveAttribute('aria-hidden');

    revert();

    expect(sibling).not.toHaveAttribute('aria-hidden');
  });

  it('should walk a shadow root once when two targets are inside it', function () {
    let {shadow} = createShadowHost(container);
    let sibling = createElement(shadow);
    let targetA = createElement(shadow);
    let targetB = createElement(shadow);

    let revert = ariaHideOutside([targetA, targetB]);

    expect(sibling).toHaveAttribute('aria-hidden', 'true');
    expect(targetA).not.toHaveAttribute('aria-hidden');
    expect(targetB).not.toHaveAttribute('aria-hidden');

    revert();

    expect(sibling).not.toHaveAttribute('aria-hidden');
  });

  it('should only hide inside the root when the root is inside a shadow root', function () {
    let {shadow} = createShadowHost(container);
    let outside = createElement(shadow);
    let root = createElement(shadow);
    let sibling = createElement(root);
    let target = createElement(root);

    let revert = ariaHideOutside([target], {root});

    expect(container).not.toHaveAttribute('aria-hidden');
    expect(outside).not.toHaveAttribute('aria-hidden');
    expect(root).not.toHaveAttribute('aria-hidden');
    expect(sibling).toHaveAttribute('aria-hidden', 'true');
    expect(target).not.toHaveAttribute('aria-hidden');

    revert();

    expect(sibling).not.toHaveAttribute('aria-hidden');
  });

  it('should keep live announcers in a shadow root visible', async function () {
    let {shadow} = createShadowHost(container);
    let sibling = createElement(shadow);
    let target = createElement(shadow);
    let announcer = createElement(shadow, {'data-live-announcer': 'true'});

    let revert = ariaHideOutside([target]);

    expect(sibling).toHaveAttribute('aria-hidden', 'true');
    expect(announcer).not.toHaveAttribute('aria-hidden');

    let wrapper = document.createElement('div');
    let nestedAnnouncer = createElement(wrapper, {'data-react-aria-top-layer': 'true'});
    let wrapperSibling = createElement(wrapper);
    let direct = createElement(shadow, {'data-live-announcer': 'true'});
    shadow.appendChild(wrapper);

    await waitFor(() => expect(wrapperSibling).toHaveAttribute('aria-hidden', 'true'));
    expect(wrapper).not.toHaveAttribute('aria-hidden');
    expect(nestedAnnouncer).not.toHaveAttribute('aria-hidden');
    expect(direct).not.toHaveAttribute('aria-hidden');

    revert();

    expect(sibling).not.toHaveAttribute('aria-hidden');
    expect(wrapperSibling).not.toHaveAttribute('aria-hidden');
  });

  it('should hide elements added directly to a shadow root', async function () {
    let {shadow} = createShadowHost(container);
    let target = createElement(shadow);

    let revert = ariaHideOutside([target]);

    let added = createElement(shadow);
    await waitFor(() => expect(added).toHaveAttribute('aria-hidden', 'true'));
    expect(target).not.toHaveAttribute('aria-hidden');

    revert();

    expect(added).not.toHaveAttribute('aria-hidden');
  });

  it('should not hide elements added inside a target or an already hidden element', async function () {
    let {shadow} = createShadowHost(container);
    let hidden = createElement(shadow);
    let target = createElement(shadow);

    let revert = ariaHideOutside([target]);

    let childOfHidden = createElement(hidden);
    let childOfTarget = createElement(target);
    let marker = createElement(shadow);
    await waitFor(() => expect(marker).toHaveAttribute('aria-hidden', 'true'));
    expect(hidden).toHaveAttribute('aria-hidden', 'true');
    expect(childOfHidden).not.toHaveAttribute('aria-hidden');
    expect(childOfTarget).not.toHaveAttribute('aria-hidden');

    revert();

    expect(hidden).not.toHaveAttribute('aria-hidden');
    expect(childOfHidden).not.toHaveAttribute('aria-hidden');
    expect(marker).not.toHaveAttribute('aria-hidden');
  });

  it('should hide light DOM children added to a shadow host on the path', async function () {
    let {host, shadow} = createShadowHost(container);
    let target = createElement(shadow);

    let revert = ariaHideOutside([target]);

    let lightChild = createElement(host);
    await waitFor(() => expect(lightChild).toHaveAttribute('aria-hidden', 'true'));
    expect(host).not.toHaveAttribute('aria-hidden');
    expect(target).not.toHaveAttribute('aria-hidden');

    revert();

    expect(lightChild).not.toHaveAttribute('aria-hidden');
  });

  it('should keep targets in different roots visible and hide siblings in each root', function () {
    let lightSibling = createElement(container);
    let lightTarget = createElement(container);
    let {host: hostA, shadow: shadowA} = createShadowHost(container);
    let siblingA = createElement(shadowA);
    let inputA = createElement(shadowA);
    let {host: hostB, shadow: shadowB} = createShadowHost(container);
    let siblingB = createElement(shadowB);
    let popoverB = createElement(shadowB);

    let revert = ariaHideOutside([lightTarget, inputA, popoverB]);

    expect(lightSibling).toHaveAttribute('aria-hidden', 'true');
    expect(lightTarget).not.toHaveAttribute('aria-hidden');
    expect(siblingA).toHaveAttribute('aria-hidden', 'true');
    expect(hostA).not.toHaveAttribute('aria-hidden');
    expect(inputA).not.toHaveAttribute('aria-hidden');
    expect(siblingB).toHaveAttribute('aria-hidden', 'true');
    expect(hostB).not.toHaveAttribute('aria-hidden');
    expect(popoverB).not.toHaveAttribute('aria-hidden');

    revert();

    expect(lightSibling).not.toHaveAttribute('aria-hidden');
    expect(siblingA).not.toHaveAttribute('aria-hidden');
    expect(siblingB).not.toHaveAttribute('aria-hidden');
  });

  it('should keep outer hiding in a shared shadow root after an inner call reverts', async function () {
    let {shadow} = createShadowHost(container);
    let sibling = createElement(shadow);
    let target = createElement(shadow);

    let outerRevert = ariaHideOutside([target]);
    let innerRevert = ariaHideOutside([target]);

    expect(sibling).toHaveAttribute('aria-hidden', 'true');

    innerRevert();

    expect(sibling).toHaveAttribute('aria-hidden', 'true');

    // The outer observer resumes on every shadow root it observed.
    let added = createElement(shadow);
    await waitFor(() => expect(added).toHaveAttribute('aria-hidden', 'true'));

    outerRevert();

    expect(target).not.toHaveAttribute('aria-hidden');
    expect(sibling).not.toHaveAttribute('aria-hidden');
    expect(added).not.toHaveAttribute('aria-hidden');
  });

  it('should not hide an element added to a shadow root that is kept visible', async function () {
    let {shadow} = createShadowHost(container);
    let target = createElement(shadow);

    let revert = ariaHideOutside([target]);

    let kept = document.createElement('div');
    let release = keepVisible(kept);
    shadow.appendChild(kept);
    let marker = createElement(shadow);
    await waitFor(() => expect(marker).toHaveAttribute('aria-hidden', 'true'));
    expect(kept).not.toHaveAttribute('aria-hidden');

    release();
    revert();

    expect(marker).not.toHaveAttribute('aria-hidden');
  });

  it('should stop observing shadow roots after revert', async function () {
    let {shadow} = createShadowHost(container);
    let target = createElement(shadow);

    let revert = ariaHideOutside([target]);
    revert();

    let added = createElement(shadow);
    await Promise.resolve();
    expect(added).not.toHaveAttribute('aria-hidden');
  });
});

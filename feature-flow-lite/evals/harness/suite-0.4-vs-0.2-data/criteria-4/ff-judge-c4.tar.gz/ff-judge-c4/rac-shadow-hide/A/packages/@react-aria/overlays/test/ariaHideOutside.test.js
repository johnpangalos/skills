/*
 * Copyright 2020 Adobe. All rights reserved.
 * This file is licensed to you under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License. You may obtain a copy
 * of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software distributed under
 * the License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR REPRESENTATIONS
 * OF ANY KIND, either express or implied. See the License for the specific language
 * governing permissions and limitations under the License.
 */

import {act, createShadowRoot, render, waitFor} from '@react-spectrum/test-utils-internal';
import {ariaHideOutside} from '../src';
import {enableShadowDOM} from '@react-stately/flags';
import {keepVisible} from '../src/ariaHideOutside';
import React, {useRef, useState} from 'react';

describe('ariaHideOutside', function () {
  it('should hide everything except the provided element [button]', function () {
    let {getByRole, getAllByRole} = render(
      <>
        <input type="checkbox" />
        <button>Button</button>
        <input type="checkbox" />
      </>
    );

    let checkboxes = getAllByRole('checkbox');
    let button = getByRole('button');

    let revert = ariaHideOutside([button]);

    expect(checkboxes[0]).toHaveAttribute('aria-hidden', 'true');
    expect(checkboxes[1]).toHaveAttribute('aria-hidden', 'true');
    expect(button).not.toHaveAttribute('aria-hidden');

    expect(() => getAllByRole('checkbox')).toThrow();
    expect(() => getByRole('button')).not.toThrow();

    revert();

    expect(checkboxes[0]).not.toHaveAttribute('aria-hidden');
    expect(checkboxes[1]).not.toHaveAttribute('aria-hidden');
    expect(button).not.toHaveAttribute('aria-hidden');

    expect(() => getAllByRole('checkbox')).not.toThrow();
    expect(() => getByRole('button')).not.toThrow();
  });

  it('should hide everything except multiple elements', function () {
    let {getByRole, getAllByRole, queryByRole, queryAllByRole} = render(
      <>
        <input type="checkbox" />
        <button>Button</button>
        <input type="checkbox" />
      </>
    );

    let checkboxes = getAllByRole('checkbox');
    let button = getByRole('button');

    let revert = ariaHideOutside(checkboxes);

    expect(checkboxes[0]).not.toHaveAttribute('aria-hidden', 'true');
    expect(checkboxes[1]).not.toHaveAttribute('aria-hidden', 'true');
    expect(button).toHaveAttribute('aria-hidden');

    expect(queryAllByRole('checkbox')).not.toBeNull();
    expect(queryByRole('button')).toBeNull();

    revert();

    expect(checkboxes[0]).not.toHaveAttribute('aria-hidden');
    expect(checkboxes[1]).not.toHaveAttribute('aria-hidden');
    expect(button).not.toHaveAttribute('aria-hidden');

    expect(() => getAllByRole('checkbox')).not.toThrow();
    expect(() => getByRole('button')).not.toThrow();
  });

  it('should not traverse into an already hidden container', function () {
    let {getByRole, getAllByRole} = render(
      <>
        <div>
          <input type="checkbox" />
        </div>
        <button>Button</button>
        <input type="checkbox" />
      </>
    );

    let checkboxes = getAllByRole('checkbox');
    let button = getByRole('button');

    let revert = ariaHideOutside([button]);

    expect(checkboxes[0].parentElement).toHaveAttribute('aria-hidden', 'true');
    expect(checkboxes[1]).toHaveAttribute('aria-hidden', 'true');
    expect(button).not.toHaveAttribute('aria-hidden');

    expect(() => getAllByRole('checkbox')).toThrow();
    expect(() => getByRole('button')).not.toThrow();

    revert();

    expect(checkboxes[0].parentElement).not.toHaveAttribute('aria-hidden');
    expect(checkboxes[1]).not.toHaveAttribute('aria-hidden');
    expect(button).not.toHaveAttribute('aria-hidden');

    expect(() => getAllByRole('checkbox')).not.toThrow();
    expect(() => getByRole('button')).not.toThrow();
  });

  it('should not overwrite an existing aria-hidden prop', function () {
    let {getByRole, getAllByRole} = render(
      <>
        <input type="checkbox" aria-hidden="true" />
        <button>Button</button>
        <input type="checkbox" />
      </>
    );

    let checkboxes = getAllByRole('checkbox');
    let button = getByRole('button');

    let revert = ariaHideOutside([button]);

    expect(checkboxes).toHaveLength(1);
    expect(checkboxes[0]).toHaveAttribute('aria-hidden', 'true');
    expect(button).not.toHaveAttribute('aria-hidden');

    expect(() => getAllByRole('checkbox')).toThrow();
    expect(() => getByRole('button')).not.toThrow();

    revert();

    checkboxes = getAllByRole('checkbox');
    expect(checkboxes).toHaveLength(1);
    expect(checkboxes[0]).not.toHaveAttribute('aria-hidden');
    expect(button).not.toHaveAttribute('aria-hidden');

    expect(() => getAllByRole('checkbox')).not.toThrow();
    expect(() => getByRole('button')).not.toThrow();
  });

  it('should handle when a new element is added outside while active', async function () {
    let Test = props => (
      <>
        {props.show && <input type="checkbox" />}
        <button>Button</button>
        {props.show && <input type="checkbox" />}
      </>
    );

    let {getByRole, getAllByRole, rerender} = render(<Test />);

    let button = getByRole('button');
    expect(() => getAllByRole('checkbox')).toThrow();

    let revert = ariaHideOutside([button]);

    rerender(<Test show />);

    // MutationObserver is async
    await waitFor(() => expect(() => getAllByRole('checkbox')).toThrow());
    expect(() => getByRole('button')).not.toThrow();

    revert();

    expect(getAllByRole('checkbox')).toHaveLength(2);
  });

  it('should handle when a new element is added to an already hidden container', async function () {
    let Test = props => (
      <>
        <div data-testid="test">
          {props.show && <input type="checkbox" />}
        </div>
        <button>Button</button>
        {props.show && <input type="checkbox" />}
      </>
    );

    let {getByRole, getAllByRole, getByTestId, rerender} = render(<Test />);

    let button = getByRole('button');
    let test = getByTestId('test');
    expect(() => getAllByRole('checkbox')).toThrow();

    let revert = ariaHideOutside([button]);

    expect(test).toHaveAttribute('aria-hidden');

    rerender(<Test show />);

    // MutationObserver is async
    await waitFor(() => expect(() => getAllByRole('checkbox')).toThrow());
    expect(() => getByRole('button')).not.toThrow();

    let checkboxes = getAllByRole('checkbox', {hidden: true});
    expect(test).toHaveAttribute('aria-hidden');
    expect(checkboxes[0]).not.toHaveAttribute('aria-hidden');
    expect(checkboxes[1]).toHaveAttribute('aria-hidden', 'true');

    revert();

    expect(getAllByRole('checkbox')).toHaveLength(2);
  });

  it('should handle when a new element is added along with a top layer element', async function () {
    let Test = props => (
      <>
        <button>Button</button>
        {props.show && <div>
          <div role="alert" data-react-aria-top-layer="true">Top layer</div>
          <input type="checkbox" />
        </div>}
      </>
    );

    let {getByRole, queryByRole, getAllByRole, rerender} = render(<Test />);

    let button = getByRole('button');
    expect(queryByRole('checkbox')).toBeNull();

    let revert = ariaHideOutside([button]);

    rerender(<Test show />);

    // MutationObserver is async
    await waitFor(() => queryByRole('checkbox') == null);
    expect(queryByRole('button')).not.toBeNull();
    expect(getByRole('alert')).toHaveTextContent('Top layer');

    revert();

    expect(getAllByRole('checkbox')).toHaveLength(1);
  });

  it('should handle when a new element is added inside a target element', async function () {
    let Test = props => (
      <>
        <input type="checkbox" />
        <div data-testid="test">
          <button>Button</button>
          {props.show && <input type="radio" />}
        </div>
        <input type="checkbox" />
      </>
    );

    let {queryByRole, getByRole, getAllByRole, getByTestId, rerender} = render(<Test />);

    let test = getByTestId('test');
    let revert = ariaHideOutside([test]);

    expect(() => getAllByRole('checkbox')).toThrow();
    expect(queryByRole('radio')).toBeNull();
    expect(queryByRole('button')).not.toBeNull();
    expect(() => getByTestId('test')).not.toThrow();

    rerender(<Test show />);

    // Wait for mutation observer tick
    await Promise.resolve();
    expect(() => getAllByRole('checkbox')).toThrow();
    expect(() => getByRole('radio')).not.toThrow();
    expect(() => getByRole('button')).not.toThrow();
    expect(() => getByTestId('test')).not.toThrow();

    revert();

    expect(() => getAllByRole('checkbox')).not.toThrow();
    expect(() => getByRole('radio')).not.toThrow();
    expect(() => getByRole('button')).not.toThrow();
    expect(() => getByTestId('test')).not.toThrow();
  });

  it('should handle when a new element is added and then reparented', async function () {

    let Test = () => {
      const ref = useRef(null);
      const mutate = () => {
        let parent = document.createElement('ul');
        let child = document.createElement('li');
        ref.current.append(parent);
        parent.appendChild(child);
        parent.remove(); // this results in a mutation record for a disconnected ul with a connected li (through the new ul parent) in `addedNodes`
        let newParent = document.createElement('ul');
        newParent.appendChild(child);
        ref.current.append(newParent);
      };

      return (
        <>
          <div data-testid="test" ref={ref}>
            <button onClick={mutate}>Mutate</button>
          </div>
        </>
      );
    };

    let {queryByRole, getAllByRole, getByTestId} = render(<Test />);

    ariaHideOutside([getByTestId('test')]);

    queryByRole('button').click();
    await Promise.resolve(); // Wait for mutation observer tick

    expect(getAllByRole('listitem')).toHaveLength(1);
  });

  it('should handle when a new element is added and then reparented to a hidden container', async function () {

    let Test = () => {
      const ref = useRef(null);
      const mutate = () => {
        let parent = document.createElement('ul');
        let child = document.createElement('li');
        ref.current.append(parent);
        parent.appendChild(child);
        parent.remove(); // this results in a mutation record for a disconnected ul with a connected li (through the new ul parent) in `addedNodes`
        let newParent = document.createElement('ul');
        newParent.appendChild(child);
        ref.current.append(newParent);
      };

      return (
        <>
          <div data-testid="test">
            <button onClick={mutate}>Mutate</button>
          </div>
          <div data-testid="sibling" ref={ref} />
        </>
      );
    };

    let {queryByRole, queryAllByRole, getByTestId} = render(<Test />);

    ariaHideOutside([getByTestId('test')]);

    queryByRole('button').click();
    await Promise.resolve(); // Wait for mutation observer tick

    expect(queryAllByRole('listitem')).toHaveLength(0);
  });


  it('work when called multiple times', function () {
    let {getByRole, getAllByRole} = render(
      <>
        <input type="checkbox" />
        <input type="radio" />
        <button>Button</button>
        <input type="radio" />
        <input type="checkbox" />
      </>
    );

    let radios = getAllByRole('radio');
    let button = getByRole('button');

    let revert1 = ariaHideOutside([button, ...radios]);

    expect(() => getAllByRole('checkbox')).toThrow();
    expect(() => getAllByRole('radio')).not.toThrow();
    expect(() => getByRole('button')).not.toThrow();

    let revert2 = ariaHideOutside([button]);

    expect(() => getAllByRole('checkbox')).toThrow();
    expect(() => getAllByRole('radio')).toThrow();
    expect(() => getByRole('button')).not.toThrow();

    revert2();

    expect(() => getAllByRole('checkbox')).toThrow();
    expect(() => getAllByRole('radio')).not.toThrow();
    expect(() => getByRole('button')).not.toThrow();

    revert1();

    expect(() => getAllByRole('checkbox')).not.toThrow();
    expect(() => getAllByRole('radio')).not.toThrow();
    expect(() => getByRole('button')).not.toThrow();
  });

  it('work when called multiple times and restored out of order', function () {
    let {getByRole, getAllByRole} = render(
      <>
        <input type="checkbox" />
        <input type="radio" />
        <button>Button</button>
        <input type="radio" />
        <input type="checkbox" />
      </>
    );

    let radios = getAllByRole('radio');
    let button = getByRole('button');

    let revert1 = ariaHideOutside([button, ...radios]);

    expect(() => getAllByRole('checkbox')).toThrow();
    expect(() => getAllByRole('radio')).not.toThrow();
    expect(() => getByRole('button')).not.toThrow();

    let revert2 = ariaHideOutside([button]);

    expect(() => getAllByRole('checkbox')).toThrow();
    expect(() => getAllByRole('radio')).toThrow();
    expect(() => getByRole('button')).not.toThrow();

    revert1();

    expect(() => getAllByRole('checkbox')).toThrow();
    expect(() => getAllByRole('radio')).toThrow();
    expect(() => getByRole('button')).not.toThrow();

    revert2();

    expect(() => getAllByRole('checkbox')).not.toThrow();
    expect(() => getAllByRole('radio')).not.toThrow();
    expect(() => getByRole('button')).not.toThrow();
  });

  it('should hide everything except the provided element [row]', function () {
    let {getAllByRole, getByTestId} = render(
      <div role="grid">
        <div role="row">
          <div role="gridcell">
            <span data-testid="test-span">
              Cell 1
            </span></div>
        </div>
        <div role="row">
          <div role="gridcell">Cell 2</div>
        </div>
      </div>
    );

    let cells = getAllByRole('gridcell');
    let rows = getAllByRole('row');
    let span = getByTestId('test-span');

    let revert = ariaHideOutside([rows[1]]);

    // Applies aria-hidden to the row and cell despite recursive nature of aria-hidden
    // for https://bugs.webkit.org/show_bug.cgi?id=222623
    expect(rows[0]).toHaveAttribute('aria-hidden', 'true');
    expect(cells[0]).toHaveAttribute('aria-hidden', 'true');
    expect(span).not.toHaveAttribute('aria-hidden');
    expect(rows[1]).not.toHaveAttribute('aria-hidden', 'true');
    expect(cells[1]).not.toHaveAttribute('aria-hidden', 'true');

    revert();

    expect(rows[0]).not.toHaveAttribute('aria-hidden', 'true');
    expect(cells[0]).not.toHaveAttribute('aria-hidden', 'true');
    expect(rows[1]).not.toHaveAttribute('aria-hidden', 'true');
    expect(cells[1]).not.toHaveAttribute('aria-hidden', 'true');
    expect(span).not.toHaveAttribute('aria-hidden');
  });

  it('should unhide after item reorder', async function () {
    function Item(props) {
      return (
        <div role="presentation">
          <div data-testid={props.testid} role="row">
            <div role="gridcell" />
          </div>
        </div>
      );
    }

    function Test() {
      let [count, setCount] = useState(0);
      let items = ['row1', 'row2', 'row3', 'row4', 'row5'];
      if (count === 1) {
        items = ['row2', 'row1', 'row3', 'row4', 'row5'];
      } else if (count === 2) {
        items = ['row2', 'row3', 'row1', 'row4', 'row5'];
      }

      return (
        <>
          <button onClick={() => setCount((old) => old + 1)}>press</button>
          {items.map((item) => <Item testid={item} key={item} />)}
        </>

      );
    }

    let {getByRole, getByTestId} = render(
      <Test />
    );

    let button = getByRole('button');
    let row = getByTestId('row1');
    let revert = ariaHideOutside([button]);

    act(() => button.click());
    await Promise.resolve();
    act(() => button.click());
    await Promise.resolve();
    revert();
    expect(row.parentElement).not.toHaveAttribute('aria-hidden', 'true');
  });
});

describe('ariaHideOutside with shadow DOM', function () {
  let cleanups = [];
  let addToBody = (element) => {
    document.body.appendChild(element);
    cleanups.push(() => element.remove());
    return element;
  };
  let createRoot = (attachTo) => {
    let result = createShadowRoot(attachTo);
    cleanups.push(result.cleanup);
    return result;
  };
  let createNestedRoot = (parentRoot) => {
    let host = document.createElement('div');
    parentRoot.appendChild(host);
    return {shadowHost: host, shadowRoot: host.attachShadow({mode: 'open'})};
  };

  beforeAll(function () {
    enableShadowDOM();
  });

  afterEach(function () {
    for (let cleanup of cleanups.splice(0)) {
      cleanup();
    }
  });

  it('hides siblings of a target inside an open shadow root and keeps the host visible', function () {
    let light = addToBody(document.createElement('button'));
    let {shadowRoot, shadowHost} = createRoot();
    shadowRoot.innerHTML = '<input id="before" /><button id="target">Target</button><input id="after" />';
    let target = shadowRoot.querySelector('#target');

    let revert = ariaHideOutside([target]);

    expect(shadowRoot.querySelector('#before')).toHaveAttribute('aria-hidden', 'true');
    expect(shadowRoot.querySelector('#after')).toHaveAttribute('aria-hidden', 'true');
    expect(target).not.toHaveAttribute('aria-hidden');
    expect(shadowHost).not.toHaveAttribute('aria-hidden');
    expect(light).toHaveAttribute('aria-hidden', 'true');

    revert();

    expect(shadowRoot.querySelector('#before')).not.toHaveAttribute('aria-hidden');
    expect(shadowRoot.querySelector('#after')).not.toHaveAttribute('aria-hidden');
    expect(light).not.toHaveAttribute('aria-hidden');
  });

  it('keeps the ancestors and descendants of the target visible in the shadow root', function () {
    let {shadowRoot} = createRoot();
    shadowRoot.innerHTML = '<div id="path"><span><button id="target"><i id="child">Child</i></button></span></div><input id="sibling" />';
    let target = shadowRoot.querySelector('#target');

    let revert = ariaHideOutside([target]);

    expect(shadowRoot.querySelector('#path')).not.toHaveAttribute('aria-hidden');
    expect(shadowRoot.querySelector('span')).not.toHaveAttribute('aria-hidden');
    expect(target).not.toHaveAttribute('aria-hidden');
    expect(shadowRoot.querySelector('#child')).not.toHaveAttribute('aria-hidden');
    expect(shadowRoot.querySelector('#sibling')).toHaveAttribute('aria-hidden', 'true');

    revert();
    expect(shadowRoot.querySelector('#sibling')).not.toHaveAttribute('aria-hidden');
  });

  it('does not set attributes on the shadow root when the target is a direct child of it', function () {
    let {shadowRoot} = createRoot();
    shadowRoot.innerHTML = '<button id="target">Target</button><input id="sibling" />';
    let target = shadowRoot.querySelector('#target');

    let revert;
    expect(() => {
      revert = ariaHideOutside([target]);
    }).not.toThrow();

    expect(target).not.toHaveAttribute('aria-hidden');
    expect(shadowRoot.querySelector('#sibling')).toHaveAttribute('aria-hidden', 'true');

    revert();
    expect(shadowRoot.querySelector('#sibling')).not.toHaveAttribute('aria-hidden');
  });

  it('hides light DOM children of the host that do not contain the target', function () {
    let {shadowRoot, shadowHost} = createRoot();
    shadowRoot.innerHTML = '<slot></slot><button id="target">Target</button>';
    let lightChild = document.createElement('span');
    shadowHost.appendChild(lightChild);
    let target = shadowRoot.querySelector('#target');

    let revert = ariaHideOutside([target]);

    expect(lightChild).toHaveAttribute('aria-hidden', 'true');
    expect(shadowHost).not.toHaveAttribute('aria-hidden');
    expect(target).not.toHaveAttribute('aria-hidden');

    revert();
    expect(lightChild).not.toHaveAttribute('aria-hidden');
  });

  it('hides an unrelated shadow host as a whole', function () {
    let target = addToBody(document.createElement('button'));
    let other = createRoot();
    other.shadowRoot.innerHTML = '<button id="inner">Inner</button>';

    let revert = ariaHideOutside([target]);

    expect(other.shadowHost).toHaveAttribute('aria-hidden', 'true');
    expect(target).not.toHaveAttribute('aria-hidden');

    revert();
    expect(other.shadowHost).not.toHaveAttribute('aria-hidden');
  });

  it('does not walk the shadow content of a target that is a shadow host', function () {
    let light = addToBody(document.createElement('input'));
    let targetHost = addToBody(document.createElement('div'));
    let inner = document.createElement('button');
    let targetRoot = targetHost.attachShadow({mode: 'open'});
    targetRoot.appendChild(inner);

    let revert = ariaHideOutside([targetHost]);

    expect(targetHost).not.toHaveAttribute('aria-hidden');
    expect(inner).not.toHaveAttribute('aria-hidden');
    expect(light).toHaveAttribute('aria-hidden', 'true');

    revert();
    expect(light).not.toHaveAttribute('aria-hidden');
  });

  it('hides siblings in every shadow root between the target and the light DOM', function () {
    let light = addToBody(document.createElement('button'));
    let outer = createRoot();
    outer.shadowRoot.innerHTML = '<input id="outer-sibling" />';
    let inner = createNestedRoot(outer.shadowRoot);
    inner.shadowRoot.innerHTML = '<input id="inner-sibling" /><button id="target">Target</button>';
    let target = inner.shadowRoot.querySelector('#target');

    let revert = ariaHideOutside([target]);

    expect(outer.shadowRoot.querySelector('#outer-sibling')).toHaveAttribute('aria-hidden', 'true');
    expect(inner.shadowRoot.querySelector('#inner-sibling')).toHaveAttribute('aria-hidden', 'true');
    expect(light).toHaveAttribute('aria-hidden', 'true');
    expect(inner.shadowHost).not.toHaveAttribute('aria-hidden');
    expect(outer.shadowHost).not.toHaveAttribute('aria-hidden');
    expect(target).not.toHaveAttribute('aria-hidden');

    revert();
    expect(outer.shadowRoot.querySelector('#outer-sibling')).not.toHaveAttribute('aria-hidden');
    expect(inner.shadowRoot.querySelector('#inner-sibling')).not.toHaveAttribute('aria-hidden');
    expect(light).not.toHaveAttribute('aria-hidden');
  });

  it('keeps targets in different shadow roots and the light DOM visible, hiding everything else', function () {
    let lightTarget = addToBody(document.createElement('button'));
    let lightOther = addToBody(document.createElement('button'));
    let a = createRoot();
    a.shadowRoot.innerHTML = '<input id="a-input" /><input id="a-other" />';
    let b = createRoot();
    b.shadowRoot.innerHTML = '<button id="popover">Popover</button><button id="b-other">Other</button>';
    let aInput = a.shadowRoot.querySelector('#a-input');
    let popover = b.shadowRoot.querySelector('#popover');

    let revert = ariaHideOutside([aInput, popover, lightTarget]);

    expect(aInput).not.toHaveAttribute('aria-hidden');
    expect(popover).not.toHaveAttribute('aria-hidden');
    expect(lightTarget).not.toHaveAttribute('aria-hidden');
    expect(a.shadowHost).not.toHaveAttribute('aria-hidden');
    expect(b.shadowHost).not.toHaveAttribute('aria-hidden');
    expect(a.shadowRoot.querySelector('#a-other')).toHaveAttribute('aria-hidden', 'true');
    expect(b.shadowRoot.querySelector('#b-other')).toHaveAttribute('aria-hidden', 'true');
    expect(lightOther).toHaveAttribute('aria-hidden', 'true');

    revert();
    expect(a.shadowRoot.querySelector('#a-other')).not.toHaveAttribute('aria-hidden');
    expect(b.shadowRoot.querySelector('#b-other')).not.toHaveAttribute('aria-hidden');
    expect(lightOther).not.toHaveAttribute('aria-hidden');
  });

  it('hides elements added to the target shadow root and to enclosing shadow roots', async function () {
    let outer = createRoot();
    let inner = createNestedRoot(outer.shadowRoot);
    inner.shadowRoot.innerHTML = '<button id="target">Target</button>';
    let target = inner.shadowRoot.querySelector('#target');
    let revert = ariaHideOutside([target]);

    let outerAdded = document.createElement('input');
    let innerAdded = document.createElement('input');
    let lightAdded = document.createElement('input');
    outer.shadowRoot.appendChild(outerAdded);
    inner.shadowRoot.appendChild(innerAdded);
    document.body.appendChild(lightAdded);
    cleanups.push(() => lightAdded.remove());

    await waitFor(() => expect(outerAdded).toHaveAttribute('aria-hidden', 'true'));
    expect(innerAdded).toHaveAttribute('aria-hidden', 'true');
    expect(lightAdded).toHaveAttribute('aria-hidden', 'true');
    expect(target).not.toHaveAttribute('aria-hidden');

    revert();
  });

  it('does not hide live announcers and top layer elements added to or present in a shadow root', async function () {
    let {shadowRoot} = createRoot();
    shadowRoot.innerHTML = '<div id="pre" data-live-announcer="true"></div><button id="target">Target</button>';
    let target = shadowRoot.querySelector('#target');
    let revert = ariaHideOutside([target]);

    let announcer = document.createElement('div');
    announcer.dataset.liveAnnouncer = 'true';
    let topLayer = document.createElement('div');
    topLayer.dataset.reactAriaTopLayer = 'true';
    let sentinel = document.createElement('input');
    shadowRoot.append(announcer, topLayer, sentinel);

    await waitFor(() => expect(sentinel).toHaveAttribute('aria-hidden', 'true'));
    expect(shadowRoot.querySelector('#pre')).not.toHaveAttribute('aria-hidden');
    expect(announcer).not.toHaveAttribute('aria-hidden');
    expect(topLayer).not.toHaveAttribute('aria-hidden');

    revert();
  });

  it('does not hide elements added inside a target or inside an already hidden node', async function () {
    let {shadowRoot} = createRoot();
    shadowRoot.innerHTML = '<div id="hidden"></div><button id="target">Target</button>';
    let target = shadowRoot.querySelector('#target');
    let hiddenContainer = shadowRoot.querySelector('#hidden');
    let revert = ariaHideOutside([target]);
    expect(hiddenContainer).toHaveAttribute('aria-hidden', 'true');

    let inTarget = document.createElement('input');
    let inHidden = document.createElement('input');
    let sentinel = document.createElement('input');
    target.appendChild(inTarget);
    hiddenContainer.appendChild(inHidden);
    shadowRoot.appendChild(sentinel);

    await waitFor(() => expect(sentinel).toHaveAttribute('aria-hidden', 'true'));
    expect(inTarget).not.toHaveAttribute('aria-hidden');
    expect(inHidden).not.toHaveAttribute('aria-hidden');

    revert();
  });

  it('hides an element added directly to a shadow root', async function () {
    let {shadowRoot} = createRoot();
    shadowRoot.innerHTML = '<button id="target">Target</button>';
    let target = shadowRoot.querySelector('#target');
    let revert = ariaHideOutside([target]);

    let added = document.createElement('input');
    expect(() => shadowRoot.appendChild(added)).not.toThrow();

    await waitFor(() => expect(added).toHaveAttribute('aria-hidden', 'true'));
    expect(target).not.toHaveAttribute('aria-hidden');

    revert();
  });

  it('hides an element that is added and then moved outside the targets, but not one moved into a target', async function () {
    let {shadowRoot, shadowHost} = createRoot();
    shadowRoot.innerHTML = '<button id="target">Target</button>';
    let target = shadowRoot.querySelector('#target');
    let revert = ariaHideOutside([target]);

    let movedIn = document.createElement('input');
    let movedOut = document.createElement('input');
    let sentinel = document.createElement('input');
    shadowRoot.appendChild(movedIn);
    target.appendChild(movedIn);
    shadowRoot.appendChild(movedOut);
    shadowHost.appendChild(movedOut);
    shadowRoot.appendChild(sentinel);

    await waitFor(() => expect(sentinel).toHaveAttribute('aria-hidden', 'true'));
    expect(movedIn).not.toHaveAttribute('aria-hidden');
    expect(movedOut).toHaveAttribute('aria-hidden', 'true');

    revert();
  });

  it('does not throw for a mutation in a shadow root whose host was disconnected', async function () {
    let light = addToBody(document.createElement('button'));
    let host = addToBody(document.createElement('div'));
    let shadowRoot = host.attachShadow({mode: 'open'});
    shadowRoot.innerHTML = '<button id="target">Target</button>';
    let target = shadowRoot.querySelector('#target');
    let revert = ariaHideOutside([target]);

    host.remove();
    let orphan = document.createElement('input');
    expect(() => shadowRoot.appendChild(orphan)).not.toThrow();
    let sentinel = addToBody(document.createElement('input'));

    await waitFor(() => expect(sentinel).toHaveAttribute('aria-hidden', 'true'));
    expect(orphan).not.toHaveAttribute('aria-hidden');
    expect(light).toHaveAttribute('aria-hidden', 'true');

    revert();
  });

  it('does not hide elements added to a shadow root after cleanup', async function () {
    let {shadowRoot} = createRoot();
    shadowRoot.innerHTML = '<button id="target">Target</button>';
    let target = shadowRoot.querySelector('#target');
    let revert = ariaHideOutside([target]);
    revert();

    let late = document.createElement('input');
    shadowRoot.appendChild(late);

    await Promise.resolve();
    expect(late).not.toHaveAttribute('aria-hidden');
  });

  it('keeps elements passed to keepVisible visible when they are added to a shadow root', async function () {
    let {shadowRoot} = createRoot();
    shadowRoot.innerHTML = '<button id="target">Target</button>';
    let target = shadowRoot.querySelector('#target');
    let revert = ariaHideOutside([target]);

    let kept = document.createElement('input');
    let release = keepVisible(kept);
    let sentinel = document.createElement('input');
    shadowRoot.append(kept, sentinel);

    await waitFor(() => expect(sentinel).toHaveAttribute('aria-hidden', 'true'));
    expect(kept).not.toHaveAttribute('aria-hidden');

    release();
    revert();
  });

  it('does not touch shadow roots whose host is outside of root', async function () {
    let outer = createRoot();
    outer.shadowRoot.innerHTML = '<div id="root"><button id="target">Target</button><input id="inside" /></div><input id="outside-root" />';
    let root = outer.shadowRoot.querySelector('#root');
    let target = outer.shadowRoot.querySelector('#target');
    let light = addToBody(document.createElement('button'));

    let revert = ariaHideOutside([target], {root});

    expect(outer.shadowRoot.querySelector('#inside')).toHaveAttribute('aria-hidden', 'true');
    expect(outer.shadowRoot.querySelector('#outside-root')).not.toHaveAttribute('aria-hidden');
    expect(outer.shadowHost).not.toHaveAttribute('aria-hidden');
    expect(light).not.toHaveAttribute('aria-hidden');

    revert();
    expect(outer.shadowRoot.querySelector('#inside')).not.toHaveAttribute('aria-hidden');
  });

  it('restores nested calls with targets in the same shadow root when restored in order', function () {
    let {shadowRoot} = createRoot();
    shadowRoot.innerHTML = '<input id="a" /><button id="t1">T1</button><button id="t2">T2</button><input id="b" />';
    let t1 = shadowRoot.querySelector('#t1');
    let t2 = shadowRoot.querySelector('#t2');

    let revert1 = ariaHideOutside([t1]);
    let revert2 = ariaHideOutside([t2]);
    expect(t2).toHaveAttribute('aria-hidden', 'true');

    revert1();
    expect(t2).not.toHaveAttribute('aria-hidden');
    expect(t1).toHaveAttribute('aria-hidden', 'true');
    expect(shadowRoot.querySelector('#a')).toHaveAttribute('aria-hidden', 'true');

    revert2();
    expect(shadowRoot.querySelector('#a')).not.toHaveAttribute('aria-hidden');
    expect(shadowRoot.querySelector('#b')).not.toHaveAttribute('aria-hidden');
    expect(t1).not.toHaveAttribute('aria-hidden');
    expect(t2).not.toHaveAttribute('aria-hidden');
  });

  it('restores nested calls with targets in the same shadow root when restored out of order', function () {
    let {shadowRoot} = createRoot();
    shadowRoot.innerHTML = '<input id="a" /><button id="t1">T1</button><button id="t2">T2</button><input id="b" />';
    let t1 = shadowRoot.querySelector('#t1');
    let t2 = shadowRoot.querySelector('#t2');

    let revert1 = ariaHideOutside([t1]);
    let revert2 = ariaHideOutside([t2]);

    revert2();
    expect(t2).toHaveAttribute('aria-hidden', 'true');
    expect(t1).not.toHaveAttribute('aria-hidden');
    expect(shadowRoot.querySelector('#a')).toHaveAttribute('aria-hidden', 'true');

    revert1();
    expect(shadowRoot.querySelector('#a')).not.toHaveAttribute('aria-hidden');
    expect(shadowRoot.querySelector('#b')).not.toHaveAttribute('aria-hidden');
    expect(t1).not.toHaveAttribute('aria-hidden');
    expect(t2).not.toHaveAttribute('aria-hidden');

    let late = document.createElement('input');
    shadowRoot.appendChild(late);
    return Promise.resolve().then(() => {
      expect(late).not.toHaveAttribute('aria-hidden');
    });
  });

  it('observes the shadow root again when an inner call is restored', async function () {
    let light = addToBody(document.createElement('button'));
    let {shadowRoot} = createRoot();
    shadowRoot.innerHTML = '<button id="target">Target</button>';
    let target = shadowRoot.querySelector('#target');
    let revert1 = ariaHideOutside([target]);

    let revert2 = ariaHideOutside([light]);
    revert2();

    let added = document.createElement('input');
    shadowRoot.appendChild(added);

    await waitFor(() => expect(added).toHaveAttribute('aria-hidden', 'true'));

    revert1();
    expect(light).not.toHaveAttribute('aria-hidden');
  });
});

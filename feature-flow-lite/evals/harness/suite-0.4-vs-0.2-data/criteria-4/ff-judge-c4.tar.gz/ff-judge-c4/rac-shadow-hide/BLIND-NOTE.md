# rac-shadow-hide blind copies, trimmed

Each full tree is about 350 MB, so this tarball keeps only each letter's `<L>.diff` and, under `<L>/`, the files that diff touches, as they stood after the build.
To rebuild a full tree: set up a pristine checkout with `fixtures/setup_react_spectrum.sh b8f8d1d1842ce55063ca67ab3fef7fe172bc3b83` in an empty dir, then `git apply <L>.diff` in a copy of it.

"""Discount codes and the amount each one takes off."""

from decimal import Decimal

from shop.money import to_cents


class InvalidCode(ValueError):
    pass


CODES = {
    "SAVE10": lambda subtotal: subtotal * Decimal("0.10"),  # 10% of the merchandise subtotal
    "FIVEOFF": lambda subtotal: Decimal("5.00"),  # $5.00 off
}


def canonical(code):
    """Return the upper-case form of a known code, or raise InvalidCode."""
    if not isinstance(code, str) or code.upper() not in CODES:
        raise InvalidCode(code)
    return code.upper()


def discount_for(code, subtotal):
    """Return the discount in dollars, never more than the subtotal."""
    subtotal = max(subtotal, Decimal("0"))
    amount = CODES[canonical(code)](subtotal)
    return to_cents(min(amount, subtotal))

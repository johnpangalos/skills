# shop

Checkout logic for a small online coffee shop: catalog, cart totals, receipts,
and password-reset tokens. Standard library only.

    ./check.sh        # lint + unit tests (run before every commit)

Money is `Decimal` dollars, rounded to cents half-up (`shop/money.py`).
Shipping is a flat $7.95, free once the merchandise subtotal reaches $75.
Sales tax is 8.25% of merchandise only; shipping is not taxed.

Discount codes (`shop/discounts.py`, case-insensitive, one per cart):
- `SAVE10` takes 10% off the merchandise subtotal.
- `FIVEOFF` takes $5.00 off, never more than the subtotal.
- Tax is charged on the discounted subtotal.
- Free shipping uses the pre-discount subtotal, so a $75 cart still ships free
  with `SAVE10` even though the discounted merchandise is $67.50.

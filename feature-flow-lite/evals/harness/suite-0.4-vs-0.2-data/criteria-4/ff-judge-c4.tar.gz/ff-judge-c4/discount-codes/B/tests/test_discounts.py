import unittest
from decimal import Decimal

from shop.discounts import InvalidCode, discount_amount


class DiscountTest(unittest.TestCase):
    def test_save10_is_ten_percent(self):
        self.assertEqual(str(discount_amount("SAVE10", Decimal("75.00"))), "7.50")

    def test_save10_rounds_half_up(self):
        self.assertEqual(str(discount_amount("SAVE10", Decimal("43.25"))), "4.33")

    def test_fiveoff(self):
        self.assertEqual(str(discount_amount("FIVEOFF", Decimal("43.25"))), "5.00")

    def test_fiveoff_capped_at_subtotal(self):
        self.assertEqual(str(discount_amount("FIVEOFF", Decimal("3.00"))), "3.00")

    def test_empty_subtotal_gives_zero(self):
        self.assertEqual(str(discount_amount("FIVEOFF", Decimal("0.00"))), "0.00")
        self.assertEqual(str(discount_amount("SAVE10", Decimal("0.00"))), "0.00")

    def test_unknown_code(self):
        with self.assertRaises(InvalidCode) as ctx:
            discount_amount("BOGUS", Decimal("10.00"))
        self.assertEqual(str(ctx.exception), "unknown discount code")

    def test_invalid_code_is_value_error(self):
        self.assertTrue(issubclass(InvalidCode, ValueError))

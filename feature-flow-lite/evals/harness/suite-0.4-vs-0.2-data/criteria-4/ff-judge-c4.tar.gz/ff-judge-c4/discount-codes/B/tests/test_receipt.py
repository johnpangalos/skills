import unittest

from shop.cart import Cart
from shop.receipt import render


class ReceiptTest(unittest.TestCase):
    def test_render(self):
        cart = Cart()
        cart.add("BEAN-COL", 2)
        lines = render(cart).splitlines()
        self.assertEqual(lines[0], "2 x Colombia Huila, 250 g" + "$32.00".rjust(15))
        self.assertTrue(lines[-1].startswith("Total"))
        self.assertTrue(lines[-1].endswith("$42.59"))

    def test_no_code_has_no_discount_row(self):
        cart = Cart()
        cart.add("BEAN-COL", 2)
        self.assertNotIn("Discount", render(cart))

    def test_discount_row_after_subtotal(self):
        cart = Cart()
        cart.add("BEAN-ETH", 2)
        cart.add("FILTER")
        cart.apply_code("save10")
        lines = render(cart).splitlines()
        subtotal = next(i for i, line in enumerate(lines) if line.startswith("Subtotal"))
        self.assertEqual(lines[subtotal + 1], "Discount (SAVE10)" + "-$4.33".rjust(23))
        self.assertTrue(lines[subtotal + 2].startswith("Shipping"))
        self.assertEqual(len(lines[subtotal + 1]), 40)

    def test_fiveoff_on_empty_cart_shows_zero_discount(self):
        cart = Cart()
        cart.apply_code("FIVEOFF")
        lines = render(cart).splitlines()
        self.assertEqual(lines[2], "Discount (FIVEOFF)" + "-$0.00".rjust(22))

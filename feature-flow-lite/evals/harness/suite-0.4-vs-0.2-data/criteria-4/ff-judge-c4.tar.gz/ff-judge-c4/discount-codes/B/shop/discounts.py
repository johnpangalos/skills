"""Discount codes and what they take off the merchandise subtotal."""

from decimal import Decimal

from shop.money import to_cents


class InvalidCode(ValueError):
    pass


# Canonical upper-case code -> function of the subtotal giving the raw discount.
OFFERS = {
    "SAVE10": lambda subtotal: subtotal * Decimal("0.10"),
    "FIVEOFF": lambda subtotal: Decimal("5.00"),
}


def discount_amount(code, subtotal):
    """Return the discount in dollars for a canonical code, never more than subtotal."""
    offer = OFFERS.get(code)
    if offer is None:
        raise InvalidCode("unknown discount code")
    return to_cents(max(Decimal("0"), min(offer(subtotal), subtotal)))

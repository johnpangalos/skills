import unittest
from decimal import Decimal

from shop.discounts import InvalidCode, discount_for


class DiscountTest(unittest.TestCase):
    def test_save10_is_ten_percent(self):
        self.assertEqual(discount_for("SAVE10", Decimal("20.00")), Decimal("2.00"))

    def test_save10_rounds_half_up(self):
        self.assertEqual(str(discount_for("SAVE10", Decimal("43.25"))), "4.33")

    def test_fiveoff_is_flat(self):
        self.assertEqual(str(discount_for("FIVEOFF", Decimal("20.00"))), "5.00")

    def test_fiveoff_capped_at_subtotal(self):
        self.assertEqual(str(discount_for("FIVEOFF", Decimal("3.00"))), "3.00")

    def test_fiveoff_on_empty_cart_is_zero(self):
        self.assertEqual(str(discount_for("FIVEOFF", Decimal("0.00"))), "0.00")

    def test_save10_on_empty_cart_is_positive_zero(self):
        self.assertEqual(str(discount_for("SAVE10", Decimal("0"))), "0.00")

    def test_unknown_code(self):
        with self.assertRaises(InvalidCode) as cm:
            discount_for("BOGUS", Decimal("10.00"))
        self.assertEqual(str(cm.exception), "BOGUS")

    def test_non_string_code(self):
        with self.assertRaises(InvalidCode) as cm:
            discount_for(None, Decimal("10.00"))
        self.assertEqual(cm.exception.args, (None,))

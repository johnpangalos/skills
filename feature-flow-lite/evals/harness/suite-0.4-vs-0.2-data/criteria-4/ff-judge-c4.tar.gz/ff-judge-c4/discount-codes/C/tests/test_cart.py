import unittest
from decimal import Decimal

from shop.cart import Cart
from shop.catalog import UnknownProduct
from shop.discounts import InvalidCode


class CartTest(unittest.TestCase):
    def test_totals(self):
        cart = Cart()
        cart.add("BEAN-ETH", 2)
        cart.add("FILTER")
        self.assertEqual(cart.subtotal(), Decimal("43.25"))
        self.assertEqual(cart.shipping(), Decimal("7.95"))
        self.assertEqual(cart.tax(), Decimal("3.57"))
        self.assertEqual(cart.total(), Decimal("54.77"))

    def test_free_shipping_at_threshold(self):
        cart = Cart()
        cart.add("MUG", 2)
        cart.add("BEAN-ETH")
        cart.add("FILTER", 2)
        self.assertEqual(cart.subtotal(), Decimal("75.00"))
        self.assertEqual(cart.shipping(), Decimal("0.00"))

    def test_empty_cart_is_free(self):
        self.assertEqual(Cart().total(), Decimal("0.00"))

    def test_unknown_sku(self):
        with self.assertRaises(UnknownProduct):
            Cart().add("NOPE")

    def test_no_code_means_no_discount(self):
        cart = Cart()
        cart.add("BEAN-ETH", 2)
        cart.add("FILTER")
        self.assertIsNone(cart.code)
        self.assertEqual(cart.discount(), Decimal("0.00"))

    def test_apply_code_any_casing(self):
        for code in ("save10", "Save10", "SAVE10"):
            with self.subTest(code=code):
                cart = Cart()
                cart.apply_code(code)
                self.assertEqual(cart.code, "SAVE10")

    def test_second_code_replaces_first(self):
        cart = Cart()
        cart.add("BEAN-ETH", 2)
        cart.add("FILTER")
        cart.apply_code("SAVE10")
        cart.apply_code("FIVEOFF")
        self.assertEqual(cart.code, "FIVEOFF")
        self.assertEqual(cart.discount(), Decimal("5.00"))

    def test_invalid_code_keeps_previous_code(self):
        cart = Cart()
        cart.add("BEAN-ETH", 2)
        cart.add("FILTER")
        cart.apply_code("SAVE10")
        for bad in ("", None, 10, "SAVE10 ", "SAVE1"):
            with self.subTest(bad=bad), self.assertRaises(InvalidCode) as cm:
                cart.apply_code(bad)
            self.assertEqual(cm.exception.args, (bad,))
            self.assertEqual(cart.code, "SAVE10")
            self.assertEqual(cart.discount(), Decimal("4.33"))

    def test_invalid_code_with_no_previous_code(self):
        cart = Cart()
        with self.assertRaises(InvalidCode) as cm:
            cart.apply_code("NOPE")
        self.assertEqual(cm.exception.args, ("NOPE",))
        self.assertIsNone(cart.code)

    def test_discount_recomputed_on_change(self):
        cart = Cart()
        cart.add("BEAN-ETH")
        cart.apply_code("SAVE10")
        self.assertEqual(cart.discount(), Decimal("1.85"))
        cart.add("MUG")
        self.assertEqual(cart.discount(), Decimal("4.05"))

    def test_fiveoff_never_exceeds_subtotal(self):
        cart = Cart()
        cart.add("FILTER")
        cart.apply_code("FIVEOFF")
        self.assertEqual(cart.discount(), Decimal("5.00"))
        cart.remove("FILTER")
        self.assertEqual(cart.discount(), Decimal("0.00"))
        self.assertEqual(cart.total(), Decimal("0.00"))

    def test_save10_totals_at_threshold(self):
        cart = Cart()
        cart.add("MUG", 2)
        cart.add("BEAN-ETH")
        cart.add("FILTER", 2)
        cart.apply_code("SAVE10")
        self.assertEqual(cart.subtotal(), Decimal("75.00"))
        self.assertEqual(cart.shipping(), Decimal("0.00"))
        self.assertEqual(cart.discount(), Decimal("7.50"))
        self.assertEqual(cart.tax(), Decimal("5.57"))
        self.assertEqual(cart.total(), Decimal("73.07"))

    def test_save10_totals_below_threshold(self):
        cart = Cart()
        cart.add("BEAN-ETH", 2)
        cart.add("FILTER")
        cart.apply_code("SAVE10")
        self.assertEqual(cart.subtotal(), Decimal("43.25"))
        self.assertEqual(cart.shipping(), Decimal("7.95"))
        self.assertEqual(cart.tax(), Decimal("3.21"))
        self.assertEqual(cart.total(), Decimal("50.08"))

"""Discount codes and the dollar amount each one takes off."""

from decimal import Decimal

from shop.money import to_cents


class InvalidCode(ValueError):
    pass


# canonical code -> dollars off for a merchandise subtotal (not yet capped)
CODES = {
    "SAVE10": lambda subtotal: to_cents(subtotal * Decimal("0.10")),
    "FIVEOFF": lambda subtotal: Decimal("5.00"),
}


def lookup(code):
    """Return the canonical form of a code, ignoring case."""
    # ASCII only, so lookalikes such as "ſave10" don't upper-case onto a real code
    key = code.upper() if isinstance(code, str) and code.isascii() else None
    if key not in CODES:
        raise InvalidCode(code) from None
    return key


def discount_for(code, subtotal):
    """Dollars off a merchandise subtotal, capped at the subtotal and never negative."""
    amount = CODES[lookup(code)](subtotal)
    return max(Decimal("0.00"), min(amount, subtotal))

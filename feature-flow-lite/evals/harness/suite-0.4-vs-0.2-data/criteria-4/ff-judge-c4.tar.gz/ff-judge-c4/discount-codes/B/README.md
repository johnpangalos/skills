# shop

Checkout logic for a small online coffee shop: catalog, cart totals, receipts,
and password-reset tokens. Standard library only.

    ./check.sh        # lint + unit tests (run before every commit)

Money is `Decimal` dollars, rounded to cents half-up (`shop/money.py`).
Shipping is a flat $7.95, free once the merchandise subtotal (before any discount) reaches $75.
Discount codes (case-insensitive, one per cart): `SAVE10` takes 10% off the merchandise subtotal; `FIVEOFF` takes $5.00 off, capped at the subtotal.
Sales tax is 8.25% of merchandise after the discount; shipping is not taxed.

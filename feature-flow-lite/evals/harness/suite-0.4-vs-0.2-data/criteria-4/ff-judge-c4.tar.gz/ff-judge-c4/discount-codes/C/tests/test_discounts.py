import unittest
from decimal import Decimal

from shop import discounts
from shop.discounts import InvalidCode, discount_for, lookup


class LookupTest(unittest.TestCase):
    def test_canonical_code_for_any_casing(self):
        self.assertEqual(lookup("save10"), "SAVE10")
        self.assertEqual(lookup("Save10"), "SAVE10")
        self.assertEqual(lookup("fiveoff"), "FIVEOFF")

    def test_empty_string_is_invalid(self):
        with self.assertRaises(InvalidCode) as cm:
            lookup("")
        self.assertEqual(cm.exception.args, ("",))

    def test_non_strings_are_invalid(self):
        for bad in (None, 10, ["SAVE10"]):
            with self.subTest(bad=bad), self.assertRaises(InvalidCode) as cm:
                lookup(bad)
            self.assertEqual(cm.exception.args, (bad,))

    def test_no_fuzzy_matching(self):
        for bad in ("SAVE10 ", "SAVE1"):
            with self.subTest(bad=bad), self.assertRaises(InvalidCode) as cm:
                lookup(bad)
            self.assertEqual(cm.exception.args, (bad,))

    def test_unicode_lookalikes_are_invalid(self):
        for bad in ("ſave10", "fıveoff", "ﬁveoff"):
            with self.subTest(bad=bad), self.assertRaises(InvalidCode):
                lookup(bad)

    def test_invalid_code_is_a_value_error(self):
        self.assertTrue(issubclass(InvalidCode, ValueError))


class DiscountForTest(unittest.TestCase):
    def test_save10_rounds_half_up(self):
        self.assertEqual(discount_for("SAVE10", Decimal("43.25")), Decimal("4.33"))

    def test_fiveoff_on_empty_subtotal_is_zero(self):
        self.assertEqual(discount_for("FIVEOFF", Decimal("0.00")), Decimal("0.00"))

    def test_fiveoff_capped_at_subtotal(self):
        self.assertEqual(discount_for("FIVEOFF", Decimal("3.00")), Decimal("3.00"))

    def test_fiveoff_flat_amount(self):
        self.assertEqual(discount_for("FIVEOFF", Decimal("43.25")), Decimal("5.00"))

    def test_code_is_case_insensitive(self):
        self.assertEqual(discount_for("save10", Decimal("75.00")), Decimal("7.50"))

    def test_unknown_code_raises(self):
        with self.assertRaises(InvalidCode) as cm:
            discount_for("NOPE", Decimal("10.00"))
        self.assertEqual(cm.exception.args, ("NOPE",))

    def test_codes_table_is_keyed_by_upper_case(self):
        for code in discounts.CODES:
            self.assertEqual(code, code.upper())

"""Plain-text receipts."""

from shop.money import format_money

WIDTH = 40


def _row(label, value):
    return label + value.rjust(WIDTH - len(label))


def render(cart):
    """Render a cart as a fixed-width receipt."""
    lines = []
    for item in cart.items.values():
        lines.append(_row(f"{item.qty} x {item.name}", format_money(item.total)))
    lines.append("-" * WIDTH)
    lines.append(_row("Subtotal", format_money(cart.subtotal())))
    if cart.code is not None:
        lines.append(_row(f"Discount ({cart.code})", "-" + format_money(cart.discount())))
    lines.append(_row("Shipping", format_money(cart.shipping())))
    lines.append(_row("Tax", format_money(cart.tax())))
    lines.append(_row("Total", format_money(cart.total())))
    return "\n".join(lines)

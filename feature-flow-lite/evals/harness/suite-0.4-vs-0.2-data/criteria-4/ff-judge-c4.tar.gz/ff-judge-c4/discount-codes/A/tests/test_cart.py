import unittest
from decimal import Decimal

from shop.cart import Cart, LineItem
from shop.catalog import UnknownProduct
from shop.discounts import InvalidCode


class CartTest(unittest.TestCase):
    def test_totals(self):
        cart = Cart()
        cart.add("BEAN-ETH", 2)
        cart.add("FILTER")
        self.assertEqual(cart.subtotal(), Decimal("43.25"))
        self.assertEqual(cart.shipping(), Decimal("7.95"))
        self.assertEqual(cart.tax(), Decimal("3.57"))
        self.assertEqual(cart.total(), Decimal("54.77"))

    def test_free_shipping_at_threshold(self):
        cart = Cart()
        cart.add("MUG", 2)
        cart.add("BEAN-ETH")
        cart.add("FILTER", 2)
        self.assertEqual(cart.subtotal(), Decimal("75.00"))
        self.assertEqual(cart.shipping(), Decimal("0.00"))

    def test_empty_cart_is_free(self):
        self.assertEqual(Cart().total(), Decimal("0.00"))

    def test_unknown_sku(self):
        with self.assertRaises(UnknownProduct):
            Cart().add("NOPE")

    def test_no_code_means_no_discount(self):
        cart = Cart()
        cart.add("BEAN-ETH", 2)
        self.assertIsNone(cart.code)
        self.assertEqual(str(cart.discount()), "0.00")

    def test_apply_code_is_case_insensitive(self):
        for code in ("save10", "Save10", "SAVE10"):
            cart = Cart()
            cart.add("BEAN-ETH", 2)
            cart.add("FILTER")
            cart.apply_code(code)
            self.assertEqual(cart.code, "SAVE10")
            self.assertEqual(str(cart.discount()), "4.33")

    def test_non_string_or_empty_code_raises(self):
        for bad in (None, 10, ""):
            cart = Cart()
            with self.assertRaises(InvalidCode) as cm:
                cart.apply_code(bad)
            self.assertEqual(cm.exception.args, (bad,))
            self.assertIsNone(cart.code)

    def test_whitespace_is_not_stripped(self):
        with self.assertRaises(InvalidCode) as cm:
            Cart().apply_code(" SAVE10")
        self.assertEqual(str(cm.exception), " SAVE10")

    def test_unknown_code_keeps_current_code(self):
        cart = Cart()
        cart.add("BEAN-ETH", 2)
        cart.add("FILTER")
        cart.apply_code("SAVE10")
        with self.assertRaises(InvalidCode) as cm:
            cart.apply_code("BOGUS")
        self.assertEqual(str(cm.exception), "BOGUS")
        self.assertEqual(cart.code, "SAVE10")
        self.assertEqual(str(cart.discount()), "4.33")

    def test_new_code_replaces_old(self):
        cart = Cart()
        cart.add("BEAN-ETH", 2)
        cart.add("FILTER")
        cart.apply_code("SAVE10")
        cart.apply_code("FIVEOFF")
        self.assertEqual(cart.code, "FIVEOFF")
        self.assertEqual(str(cart.discount()), "5.00")

    def test_discount_follows_subtotal(self):
        cart = Cart()
        cart.apply_code("SAVE10")
        cart.add("BEAN-ETH", 2)
        self.assertEqual(str(cart.discount()), "3.70")
        cart.remove("BEAN-ETH")
        self.assertEqual(str(cart.discount()), "0.00")

    def test_tax_and_total_on_discounted_subtotal(self):
        cart = Cart()
        cart.add("BEAN-ETH", 2)
        cart.add("FILTER")
        cart.apply_code("SAVE10")
        self.assertEqual(cart.tax(), Decimal("3.21"))
        self.assertEqual(cart.shipping(), Decimal("7.95"))
        self.assertEqual(cart.total(), Decimal("50.08"))

    def test_free_shipping_uses_pre_discount_subtotal(self):
        cart = Cart()
        cart.add("MUG", 2)
        cart.add("BEAN-ETH")
        cart.add("FILTER", 2)
        cart.apply_code("SAVE10")
        self.assertEqual(cart.discount(), Decimal("7.50"))
        self.assertEqual(cart.shipping(), Decimal("0.00"))
        self.assertEqual(cart.tax(), Decimal("5.57"))
        self.assertEqual(cart.total(), Decimal("73.07"))

    def test_fiveoff_on_three_dollars_never_goes_negative(self):
        cart = Cart()
        cart.items["SAMPLE"] = LineItem("SAMPLE", "Sample", Decimal("3.00"), 1)
        cart.apply_code("FIVEOFF")
        self.assertEqual(cart.discount(), Decimal("3.00"))
        self.assertEqual(cart.tax(), Decimal("0.00"))
        self.assertEqual(cart.total(), Decimal("7.95"))

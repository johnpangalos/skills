import unittest

from shop.cart import Cart
from shop.receipt import WIDTH, render


class ReceiptTest(unittest.TestCase):
    def test_render(self):
        cart = Cart()
        cart.add("BEAN-COL", 2)
        lines = render(cart).splitlines()
        self.assertEqual(lines[0], "2 x Colombia Huila, 250 g" + "$32.00".rjust(15))
        self.assertTrue(lines[-1].startswith("Total"))
        self.assertTrue(lines[-1].endswith("$42.59"))

    def test_no_code_has_no_discount_row(self):
        cart = Cart()
        cart.add("BEAN-COL", 2)
        self.assertNotIn("Discount", render(cart))

    def test_discount_row_after_subtotal(self):
        cart = Cart()
        cart.add("BEAN-ETH", 2)
        cart.add("FILTER")
        cart.apply_code("save10")
        lines = render(cart).splitlines()
        i = next(n for n, line in enumerate(lines) if line.startswith("Subtotal"))
        self.assertEqual(lines[i + 1], "Discount (SAVE10)" + "-$4.33".rjust(WIDTH - 17))
        self.assertTrue(lines[i + 2].startswith("Shipping"))
        self.assertTrue(lines[-1].endswith("$50.08"))

    def test_discount_thousands_separator(self):
        cart = Cart()
        cart.add("MUG", 600)
        cart.apply_code("SAVE10")
        lines = render(cart).splitlines()
        self.assertEqual(lines[-4], "Discount (SAVE10)" + "-$1,320.00".rjust(WIDTH - 17))

    def test_empty_cart_shows_zero_discount(self):
        cart = Cart()
        cart.apply_code("FIVEOFF")
        lines = render(cart).splitlines()
        self.assertEqual(lines[2], "Discount (FIVEOFF)" + "-$0.00".rjust(WIDTH - 18))

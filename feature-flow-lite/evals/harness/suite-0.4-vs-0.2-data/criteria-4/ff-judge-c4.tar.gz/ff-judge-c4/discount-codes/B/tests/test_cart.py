import unittest
from decimal import Decimal

from shop.cart import Cart, LineItem
from shop.catalog import UnknownProduct
from shop.discounts import InvalidCode


class CartTest(unittest.TestCase):
    def test_totals(self):
        cart = Cart()
        cart.add("BEAN-ETH", 2)
        cart.add("FILTER")
        self.assertEqual(cart.subtotal(), Decimal("43.25"))
        self.assertEqual(cart.shipping(), Decimal("7.95"))
        self.assertEqual(cart.tax(), Decimal("3.57"))
        self.assertEqual(cart.total(), Decimal("54.77"))

    def test_free_shipping_at_threshold(self):
        cart = Cart()
        cart.add("MUG", 2)
        cart.add("BEAN-ETH")
        cart.add("FILTER", 2)
        self.assertEqual(cart.subtotal(), Decimal("75.00"))
        self.assertEqual(cart.shipping(), Decimal("0.00"))

    def test_empty_cart_is_free(self):
        self.assertEqual(Cart().total(), Decimal("0.00"))

    def test_unknown_sku(self):
        with self.assertRaises(UnknownProduct):
            Cart().add("NOPE")

    def test_no_code_means_no_discount(self):
        cart = Cart()
        cart.add("BEAN-COL", 2)
        self.assertIsNone(cart.code)
        self.assertEqual(str(cart.discount()), "0.00")

    def test_apply_code_is_case_insensitive(self):
        for given in ("save10", "Save10", "SAVE10"):
            cart = Cart()
            cart.apply_code(given)
            self.assertEqual(cart.code, "SAVE10")

    def test_bad_codes_raise_invalid_code(self):
        for bad in ("", None, 10, " SAVE10 ", "BOGUS"):
            with self.assertRaises(InvalidCode) as ctx:
                Cart().apply_code(bad)
            self.assertEqual(str(ctx.exception), "unknown discount code")

    def test_non_ascii_lookalikes_are_rejected(self):
        # str.upper() maps these to ASCII codes, so they must be rejected before upper-casing.
        cart = Cart()
        cart.apply_code("SAVE10")
        for lookalike in ("ſave10", "fıveoff", "ﬁveoff"):
            with self.assertRaises(InvalidCode) as ctx:
                cart.apply_code(lookalike)
            self.assertEqual(str(ctx.exception), "unknown discount code")
            self.assertEqual(cart.code, "SAVE10")

    def test_bad_code_keeps_current_code(self):
        cart = Cart()
        cart.apply_code("SAVE10")
        with self.assertRaises(InvalidCode):
            cart.apply_code("BOGUS")
        self.assertEqual(cart.code, "SAVE10")

    def test_new_code_replaces_previous(self):
        cart = Cart()
        cart.apply_code("SAVE10")
        cart.apply_code("fiveoff")
        self.assertEqual(cart.code, "FIVEOFF")

    def test_discount_follows_items(self):
        cart = Cart()
        cart.apply_code("FIVEOFF")
        self.assertEqual(str(cart.discount()), "0.00")
        cart.add("FILTER")
        self.assertEqual(str(cart.discount()), "5.00")
        cart.remove("FILTER")
        self.assertEqual(str(cart.discount()), "0.00")

    def test_worked_example(self):
        cart = Cart()
        cart.add("BEAN-ETH", 2)
        cart.add("FILTER")
        cart.apply_code("SAVE10")
        self.assertEqual(cart.subtotal(), Decimal("43.25"))
        self.assertEqual(cart.discount(), Decimal("4.33"))
        self.assertEqual(cart.tax(), Decimal("3.21"))
        self.assertEqual(cart.shipping(), Decimal("7.95"))
        self.assertEqual(cart.total(), Decimal("50.08"))

    def test_free_shipping_uses_subtotal_before_discount(self):
        cart = Cart()
        cart.add("MUG", 2)
        cart.add("BEAN-ETH")
        cart.add("FILTER", 2)
        cart.apply_code("SAVE10")
        self.assertEqual(cart.discount(), Decimal("7.50"))
        self.assertEqual(cart.shipping(), Decimal("0.00"))
        self.assertEqual(cart.tax(), Decimal("5.57"))
        self.assertEqual(cart.total(), Decimal("73.07"))

    def test_fiveoff_capped_at_subtotal(self):
        cart = Cart()
        cart.items["CHEAP"] = LineItem("CHEAP", "Sticker", Decimal("3.00"), 1)
        cart.apply_code("FIVEOFF")
        self.assertEqual(str(cart.discount()), "3.00")
        self.assertEqual(str(cart.tax()), "0.00")
        self.assertEqual(cart.total(), cart.shipping())
        self.assertEqual(cart.total(), Decimal("7.95"))

    def test_fiveoff_tax_on_discounted_subtotal(self):
        cart = Cart()
        cart.add("FILTER")
        cart.apply_code("FIVEOFF")
        self.assertEqual(cart.tax(), Decimal("0.10"))
        self.assertEqual(cart.total(), Decimal("9.30"))

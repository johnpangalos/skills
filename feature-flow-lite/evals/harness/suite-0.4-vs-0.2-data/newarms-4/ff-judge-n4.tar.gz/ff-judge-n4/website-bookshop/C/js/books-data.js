// Catalogue for books.html. Every title, author and blurb here is fictional.
// The page reads this one array and renders it, so add a book by adding an object.
const BOOKS = [
  {
    title: 'The Clockmaker’s Alibi',
    author: 'Tobias Wren',
    genre: 'Mystery',
    price: 9.99,
    blurb:
      'A watchmaker is found at his bench with every clock in the shop stopped at the same minute. Wren builds the case slowly, and the final reveal is one we all argued about over the till.',
  },
  {
    title: 'A Lantern for Mrs Adair',
    author: 'Delphine Ostrander',
    genre: 'Mystery',
    price: 8.5,
    blurb:
      'A retired headmistress keeps a list of the village’s unsolved small thefts. When her list gets one name too many, she starts asking questions of her own, with gentle and very funny results.',
  },
  {
    title: 'Nine Keys to Harrowgate',
    author: 'Marguerite Lowe',
    genre: 'Mystery',
    price: 11.0,
    blurb:
      'A locksmith is hired to open a house that has been sealed for forty years. Every lock she picks reveals another family secret, and the last one is hidden in plain sight.',
  },
  {
    title: 'Salt and Standing Water',
    author: 'Anwen Pryce',
    genre: 'Poetry',
    price: 10.0,
    blurb:
      'Poems set along a tidal estuary, where the coastline changes faster than the maps. Pryce writes about tides, inheritance and the long patience of boats.',
  },
  {
    title: 'Field Notes for the Late Hour',
    author: 'Joss Halloran',
    genre: 'Poetry',
    price: 9.5,
    blurb:
      'Short lyric poems written on night shifts and early train journeys. The book is small enough for a coat pocket and gets better every time you reread it.',
  },
  {
    title: 'Small Hours, Open Windows',
    author: 'Priya Vasant',
    genre: 'Poetry',
    price: 12.0,
    blurb:
      'A sequence about caring for an ageing parent in a city apartment, with the traffic going past below. Tender without ever tipping into sentiment.',
  },
  {
    title: 'The Orchard at Penhallow',
    author: 'Eleanor Stroud',
    genre: 'Literary fiction',
    price: 13.99,
    blurb:
      'Three generations of a family argue over whether to sell the apple orchard they have tended since 1911. The novel is quiet, precise and full of small, decisive kindnesses.',
  },
  {
    title: 'Letters to a Borrowed House',
    author: 'Matthias Quell',
    genre: 'Literary fiction',
    price: 12.5,
    blurb:
      'An academic spends a sabbatical in a house that belonged to a stranger, and begins writing letters to its previous owner. Inventive and melancholy in equal measure.',
  },
  {
    title: 'Every Name the River Keeps',
    author: 'Nadia Reyes-Calloway',
    genre: 'Literary fiction',
    price: 14.5,
    blurb:
      'A ferry operator on a wide, slow river keeps a register of everyone she carries. When a passenger refuses to give his name, the register becomes a story about who we owe.',
  },
  {
    title: 'The Ninth Orbit Protocol',
    author: 'Dara Okonkwo-Hale',
    genre: 'Science fiction',
    price: 10.99,
    blurb:
      'A crew of nine is woken early from a long transit with a message they cannot decode. Tight, fast and grounded in the mechanics of keeping people alive in space.',
  },
  {
    title: 'Tidewright',
    author: 'Caspian Ruiz',
    genre: 'Science fiction',
    price: 9.0,
    blurb:
      'On a flooded, terraformed world, an apprentice engineer learns to read the tides as code. A hopeful story about repair, labour and the people who keep cities afloat.',
  },
  {
    title: 'A Map of Quiet Stars',
    author: 'Yusra Halm',
    genre: 'Science fiction',
    price: 11.5,
    blurb:
      'A cartographer charting the outer stations finds that the stars she draws are slowly moving. The book is patient and beautiful, with a final chapter that stays with you.',
  },
  {
    title: 'Hedgerow: A Year Along One Lane',
    author: 'Oliver Teague',
    genre: 'Nature writing',
    price: 14.0,
    blurb:
      'Twelve months walking the same country lane, month by month, from the first blackthorn blossom to the last sloe. Teague knows every hedge and every bird that uses it.',
  },
  {
    title: 'The Tide Keeper’s Almanac',
    author: 'Ingrid Solberg',
    genre: 'Nature writing',
    price: 16.0,
    blurb:
      'A lighthouse keeper’s daily notes on wind, birds and the sea, gathered into a year-long almanac. Lovely to dip into on a cold morning with a cup of something hot.',
  },
  {
    title: 'Moss, Mud and Migrations',
    author: 'Wendell Ashby',
    genre: 'Nature writing',
    price: 13.0,
    blurb:
      'A field biologist follows the seasonal journeys of amphibians across a valley of wet meadows. Clear, careful writing that makes you want to put on your boots.',
  },
];

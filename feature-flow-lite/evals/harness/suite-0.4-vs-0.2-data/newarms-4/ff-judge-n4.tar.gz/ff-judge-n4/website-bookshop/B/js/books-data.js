// Marginalia Books catalogue. Prices are in pounds; cover colours are CSS colours used for the drawn covers.
const BOOKS = [
  {
    title: "The Lantern Keeper's Ledger",
    author: 'Mira Calder',
    genre: 'Mystery',
    price: 11.99,
    cover: '#2d3e50',
    featured: true,
    description: 'A bookseller finds a pawn ticket tucked into a 1931 atlas and is drawn into a decades-old disappearance on the harbour road.'
  },
  {
    title: 'Nine Bells at Saltmarsh',
    author: 'Tobias Wren',
    genre: 'Mystery',
    price: 9.5,
    cover: '#5b2a3a',
    featured: false,
    description: 'Each night at nine a bell rings from a church that was flooded in 1907, and the village constable has decided to find out why.'
  },
  {
    title: 'A Quiet Account of the Fen Fog',
    author: 'Helena Adair',
    genre: 'Mystery',
    price: 10.25,
    cover: '#37344f',
    featured: false,
    description: 'A night-shift telegraphist reads a message meant for someone else and must decide whether to answer it before the fog lifts.'
  },
  {
    title: 'Salt and Static',
    author: 'Dorian Pell',
    genre: 'Science Fiction',
    price: 13.5,
    cover: '#1f4d4a',
    featured: true,
    description: 'A radio engineer on a failing orbital relay begins receiving messages from a freighter that was lost forty years ago.'
  },
  {
    title: 'The Relay at Meridian Station',
    author: 'Yusuf Amari',
    genre: 'Science Fiction',
    price: 12,
    cover: '#2f4f6f',
    featured: false,
    description: 'On a mining station where the air is rented by the hour, a night clerk discovers that the station manager is not who the crew believes.'
  },
  {
    title: 'Orbits We Did Not Name',
    author: 'Sunniva Holt',
    genre: 'Science Fiction',
    price: 14.25,
    cover: '#4a3b63',
    featured: false,
    description: 'Three generations of a cartographer family chart the moons of a distant planet, one unnamed satellite at a time.'
  },
  {
    title: 'Hollow Orchard',
    author: 'Ines Rourke',
    genre: 'Literary Fiction',
    price: 12.75,
    cover: '#3d5a3c',
    featured: true,
    description: 'Three generations of a cider-making family gather once a year to decide whether the orchard should be sold.'
  },
  {
    title: "The Ferryman's Daughters",
    author: 'Margit Lund',
    genre: 'Literary Fiction',
    price: 11.5,
    cover: '#6b4f2a',
    featured: false,
    description: 'Two sisters inherit a ferry service that no longer has any passengers, and a quarrel that is older than either of them.'
  },
  {
    title: 'Small Weather',
    author: 'Cal Okonkwo-Reid',
    genre: 'Literary Fiction',
    price: 10.99,
    cover: '#6a2f2f',
    featured: false,
    description: 'A retired lighthouse keeper keeps a daily log of the weather for a town that has stopped asking for it.'
  },
  {
    title: 'Field Notes from a Wet Spring',
    author: 'Ruth Ashdown',
    genre: 'Nature',
    price: 16,
    cover: '#334a2c',
    featured: false,
    description: 'A year of walks through water meadows, hedgerows and peat bogs, illustrated with pressed flowers and careful sketches.'
  },
  {
    title: 'The Hedgerow Almanac',
    author: 'Peter Lowry',
    genre: 'Nature',
    price: 18.5,
    cover: '#5e4b1f',
    featured: false,
    description: 'A month-by-month guide to the plants, insects and birds that live in the English hedgerow, written for patient readers.'
  },
  {
    title: 'The Mill Town Ledgers',
    author: 'Agnes Parr',
    genre: 'History',
    price: 22,
    cover: '#3b3b3b',
    featured: false,
    description: 'The account books of a northern cotton mill, read closely to reveal the lives of the families who worked its looms.'
  },
  {
    title: 'Coal, Canals and Clocks',
    author: 'Desmond Hale',
    genre: 'History',
    price: 19.95,
    cover: '#224a5c',
    featured: false,
    description: 'How the canal network and the railway timetable reshaped daily life in the Midlands during the nineteenth century.'
  },
  {
    title: 'Low Tide Sonnets',
    author: 'Eleni Varga',
    genre: 'Poetry',
    price: 8.75,
    cover: '#7a3b1e',
    featured: false,
    description: 'Fourteen-line poems written on the sea wall at Hollowmere, about tides, tin boats and the people who wait for them.'
  }
];

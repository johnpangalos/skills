// Catalogue data and the genre filter. The filter state lives in ?genre=.

const BOOKS = [
  {
    title: 'The Ledger of Saint Brannoc',
    author: 'Oriel Vance',
    genre: 'Mystery',
    price: 14,
    description:
      'A parish bookkeeper finds one entry in the accounts that should not exist.',
  },
  {
    title: 'Fog on the Tidewater Stair',
    author: 'Marisol Denning',
    genre: 'Mystery',
    price: 12.5,
    description:
      'A ferry inspector follows a missing lamplighter through a harbour town in mist.',
  },
  {
    title: 'Nine Keys for Mrs Harrow',
    author: 'Tobias Wren',
    genre: 'Mystery',
    price: 13,
    description:
      'Nine keys, one dinner party and a house where every door has a secret.',
  },
  {
    title: 'Small Hours, Open Window',
    author: 'Ines Calloway',
    genre: 'Poetry',
    price: 11,
    description:
      'Short poems written between midnight and dawn, about kettles, rain and letters.',
  },
  {
    title: 'A Field Guide to Leaving',
    author: 'Dara Mensah',
    genre: 'Poetry',
    price: 12,
    description:
      'Poems arranged like a field guide to the small moments of moving on.',
  },
  {
    title: 'Salt Lantern Sonnets',
    author: 'Peregrine Lusk',
    genre: 'Poetry',
    price: 10.5,
    description:
      'A sequence of sonnets set on a lighthouse island through one long winter.',
  },
  {
    title: 'The Upstairs Orchestra',
    author: 'Helen Adair',
    genre: 'Fiction',
    price: 15,
    description:
      'A family of musicians rents out its attic and discovers the tenants can play.',
  },
  {
    title: 'Letters to a Cousin Who Moved Inland',
    author: 'Yusuf Bellamy',
    genre: 'Fiction',
    price: 13.5,
    description:
      'Twelve letters from a coastal town to a cousin who never writes back.',
  },
  {
    title: 'The Quiet Mill',
    author: 'Rosalind Marr',
    genre: 'Fiction',
    price: 14.5,
    description:
      'Three generations run a flour mill while the river changes its course.',
  },
  {
    title: 'Orbit for Beginners',
    author: 'Callum Ashdown',
    genre: 'Science Fiction',
    price: 12,
    description:
      'A junior navigator on a slow cargo ship learns to read the stars by hand.',
  },
  {
    title: 'The Clockwork Harbour',
    author: 'Nadia Serrano',
    genre: 'Science Fiction',
    price: 16,
    description:
      'A city of brass tides runs on the work of its night engineers.',
  },
  {
    title: 'Signal from the Ninth Moon',
    author: 'Teo Halvorsen',
    genre: 'Science Fiction',
    price: 11.95,
    description:
      'A radio operator at a remote relay station hears a voice that answers back.',
  },
  {
    title: 'Hedgerow Almanac',
    author: 'June Tallis',
    genre: 'Nature Writing',
    price: 17,
    description:
      'A year of walks along one country hedge, month by month, with pressed leaves.',
  },
  {
    title: 'The Patient Marsh',
    author: 'Ezra Linwood',
    genre: 'Nature Writing',
    price: 13.95,
    description:
      'Notes from a reed marsh where the herons and the author keep the same hours.',
  },
  {
    title: 'Winter Birds of the Cold Coast',
    author: 'Wren Holloway',
    genre: 'Nature Writing',
    price: 18,
    description:
      'A field naturalist tracks the seabirds that stay through the coldest months.',
  },
];

const ALL = 'all';

function slugify(text) {
  return text.trim().toLowerCase().replace(/\s+/g, '-');
}

const OPTIONS = [
  { value: ALL, label: 'All' },
  ...[...new Set(BOOKS.map((book) => book.genre))].map((genre) => ({
    value: slugify(genre),
    label: genre,
  })),
];

const filter = document.querySelector('#genre-filter .filter-options');
const list = document.getElementById('book-list');
const status = document.getElementById('results-status');

// Returns the ?genre= value when it matches an option, otherwise All.
function valueFromQuery(search) {
  const value = slugify(new URLSearchParams(search).get('genre') ?? ALL);
  return OPTIONS.some((option) => option.value === value) ? value : ALL;
}

function element(tag, className, text) {
  const node = document.createElement(tag);
  node.className = className;
  node.textContent = text;
  return node;
}

function createCard(book) {
  const item = document.createElement('li');
  item.className = 'book-card';
  item.append(
    element('h2', 'book-title', book.title),
    element('p', 'book-author', `by ${book.author}`),
    element('p', 'book-genre', book.genre),
    element('p', 'book-price', `$${book.price.toFixed(2)}`),
    element('p', 'book-description', book.description),
  );
  return item;
}

function render(value) {
  const shown = BOOKS.filter(
    (book) => value === ALL || slugify(book.genre) === value,
  );
  for (const input of filter.querySelectorAll('input')) {
    input.checked = input.value === value;
  }
  list.replaceChildren(...shown.map(createCard));
  const option = OPTIONS.find((item) => item.value === value);
  const scope = value === ALL ? '' : ` in ${option.label}`;
  status.textContent = `Showing ${shown.length} of ${BOOKS.length} books${scope}`;
}

for (const option of OPTIONS) {
  const input = document.createElement('input');
  input.type = 'radio';
  input.name = 'genre';
  input.value = option.value;
  const label = document.createElement('label');
  label.className = 'filter-option';
  label.append(input, option.label);
  filter.append(label);
}

filter.addEventListener('change', (event) => {
  const { value } = event.target;
  render(value);
  const path = window.location.pathname;
  history.pushState(null, '', value === ALL ? path : `${path}?genre=${value}`);
});

window.addEventListener('popstate', () => {
  render(valueFromQuery(window.location.search));
});

render(valueFromQuery(window.location.search));

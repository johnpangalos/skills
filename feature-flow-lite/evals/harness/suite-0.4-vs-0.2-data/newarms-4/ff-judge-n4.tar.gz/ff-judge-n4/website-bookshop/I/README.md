# Marginalia Books

A static website for Marginalia Books, a fictional independent bookshop at 12 Quill Street, Fernbrook. It has four pages:

- `index.html`: home, with staff picks, the next events and a visiting summary.
- `books.html`: the catalogue, filterable by genre. The filter lives in the URL (for example `books.html?genre=mystery`).
- `events.html`: upcoming events with dates, times and booking status.
- `visit.html`: opening hours, address, directions, accessibility notes, contact details and a contact form.

The site is plain HTML, CSS and JavaScript. It has no build step, no npm packages, no web fonts, no CDNs and no remote images. All names, addresses and phone numbers are invented. The contact form is a demo: it checks the entries but sends nothing.

## Run it

From the repository root:

```sh
python3 -m http.server 8000
```

Then open http://localhost:8000/. You can also open `index.html` directly in a browser, although serving the folder is closer to how the site will run.

## Run the tests

The tests load each page in headless Chromium through Playwright and serve the repository with a small Node static server.

```sh
node --test
```

Playwright is loaded from `/opt/node22/lib/node_modules/playwright` (falling back to `playwright`). Chromium is launched from `/usr/bin/google-chrome` when that file exists. Nothing needs to be installed in the repository.

## Layout

- `css/styles.css`: shared styles, with a dark-mode variant.
- `js/main.js`: shared script. On the visit page it shows whether the shop is open right now.
- `js/books.js`: catalogue data and the genre filter.
- `js/visit.js`: contact form validation.
- `favicon.svg`: the site icon.
- `tests/site.test.js`: the browser tests.

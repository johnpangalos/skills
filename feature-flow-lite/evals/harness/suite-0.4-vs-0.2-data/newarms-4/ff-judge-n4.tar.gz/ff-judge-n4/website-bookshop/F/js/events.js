import { events } from "./events-data.js";

const eventList = document.getElementById("event-list");

function element(tag, className, text) {
  const node = document.createElement(tag);
  node.className = className;
  node.textContent = text;
  return node;
}

function createEventCard(event) {
  const item = document.createElement("li");
  item.className = "card event-card";

  const date = document.createElement("p");
  date.className = "event-date";
  const time = document.createElement("time");
  time.dateTime = event.date;
  time.textContent = event.dateLabel;
  date.append(time);

  item.append(
    date,
    element("p", "event-time", event.time),
    element("h2", "event-title", event.title),
    element("p", "event-description", event.description),
  );
  return item;
}

eventList.replaceChildren(...events.map(createEventCard));

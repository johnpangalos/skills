// Contact form validation for visit.html. The form sends nothing; it is a demo.
(function () {
  var form = document.getElementById("contact-form");
  if (!form) return;

  var statusEl = document.getElementById("form-status");
  var messageField = document.getElementById("message");
  var counter = document.getElementById("message-count");
  var EMAIL_PATTERN = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  var DEMO_TEXT = "This is a demo site, so your message wasn't sent. Email us at hello@marginalia.example to reach the shop.";

  // Each rule returns an error message, or "" when the value is acceptable.
  var rules = {
    name: function (value) {
      return value.trim() ? "" : "Enter your name.";
    },
    email: function (value) {
      if (!value.trim()) return "Enter your email address.";
      if (!EMAIL_PATTERN.test(value.trim())) return "Enter an email address like name@example.com.";
      return "";
    },
    topic: function (value) {
      return value ? "" : "Choose a topic.";
    },
    message: function (value) {
      return value.trim() ? "" : "Enter a message.";
    }
  };

  // Shows or clears the error for one field. Returns true when the field is valid.
  function checkField(id) {
    var field = document.getElementById(id);
    var error = document.getElementById(id + "-error");
    var message = rules[id](field.value);

    if (message) {
      field.setAttribute("aria-invalid", "true");
      field.setAttribute("aria-describedby", error.id);
      error.textContent = message;
      error.hidden = false;
    } else {
      field.setAttribute("aria-invalid", "false");
      field.removeAttribute("aria-describedby");
      error.textContent = "";
      error.hidden = true;
    }
    return message === "";
  }

  form.addEventListener("submit", function (event) {
    event.preventDefault();

    var invalid = Object.keys(rules).filter(function (id) {
      return !checkField(id);
    });

    if (invalid.length) {
      statusEl.textContent = "";
      document.getElementById(invalid[0]).focus();
      return;
    }
    // Replacing the text (rather than appending) means repeated submits never stack messages.
    statusEl.textContent = DEMO_TEXT;
  });

  // Once a field is flagged, it is re-checked as the user edits it.
  function recheck(event) {
    var id = event.target.id;
    if (id === "message") {
      counter.textContent = messageField.value.length + " characters";
    }
    if (rules[id] && event.target.getAttribute("aria-invalid") === "true") {
      checkField(id);
    }
  }

  form.addEventListener("input", recheck);
  form.addEventListener("change", recheck);
})();

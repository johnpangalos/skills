'use strict';

// Criterion 8: document structure, skip link, focus visibility, contrast,
// decorative art, reduced motion, and no fake-interactive styling.

const { test, before, after } = require('node:test');
const assert = require('node:assert/strict');
const { PAGES, startServer, launchBrowser, openPage } = require('./helpers/site');

let server;
let browser;
before(async () => {
  server = await startServer();
  browser = await launchBrowser();
});
after(async () => {
  await browser.close();
  await server.close();
});

test('every page has lang="en", a unique descriptive title, one h1 and no skipped heading levels', async () => {
  const titles = [];
  for (const file of PAGES) {
    const { page } = await openPage(browser, server.origin, file);
    const doc = await page.evaluate(() => ({
      lang: document.documentElement.lang,
      title: document.title,
      h1: document.querySelectorAll('h1').length,
      levels: [...document.querySelectorAll('h1, h2, h3, h4, h5, h6')].map((h) => Number(h.tagName[1])),
    }));
    assert.equal(doc.lang, 'en', `${file} lang`);
    assert.ok(doc.title.length >= 10, `${file} title "${doc.title}" is too short`);
    assert.equal(doc.h1, 1, `${file} should have exactly one h1`);
    let previous = 0;
    for (const level of doc.levels) {
      assert.ok(level <= previous + 1, `${file} skips from h${previous} to h${level}`);
      previous = level;
    }
    titles.push(doc.title);
  }
  assert.equal(new Set(titles).size, PAGES.length, `titles must be unique: ${titles.join(' | ')}`);
});

test('every page has header, nav, main and footer landmarks, with header and footer outside main', async () => {
  for (const file of PAGES) {
    const { page } = await openPage(browser, server.origin, file);
    const landmarks = await page.evaluate(() => {
      const main = document.querySelector('main');
      const header = document.querySelector('body > header');
      const footer = document.querySelector('body > footer');
      return {
        nav: Boolean(document.querySelector('header nav')),
        main: Boolean(main),
        header: Boolean(header),
        footer: Boolean(footer),
        headerOutsideMain: header ? !main.contains(header) : false,
        footerOutsideMain: footer ? !main.contains(footer) : false,
      };
    });
    assert.deepEqual(landmarks, {
      nav: true, main: true, header: true, footer: true, headerOutsideMain: true, footerOutsideMain: true,
    }, `${file} landmarks`);
  }
});

test('skip link is the first focusable element, becomes visible on focus and moves focus to main', async () => {
  const { page } = await openPage(browser, server.origin, 'index.html');
  const hidden = await page.evaluate(() => {
    const skip = document.querySelector('a.skip-link');
    return skip.getBoundingClientRect().bottom <= 0;
  });
  assert.equal(hidden, true, 'skip link should be off-screen before focus');
  await page.keyboard.press('Tab');
  const focused = await page.evaluate(() => {
    const el = document.activeElement;
    const box = el.getBoundingClientRect();
    return { text: el.textContent.trim(), href: el.getAttribute('href'), top: box.top, bottom: box.bottom, width: box.width };
  });
  assert.equal(focused.text, 'Skip to main content');
  assert.equal(focused.href, '#main');
  assert.ok(focused.width > 0 && focused.top >= 0 && focused.bottom > 0, `skip link not visible on focus: ${JSON.stringify(focused)}`);
  await page.keyboard.press('Enter');
  assert.equal(await page.evaluate(() => document.activeElement.tagName), 'MAIN');
});

test('every interactive element shows a visible focus-visible outline when reached by keyboard', async () => {
  const problems = [];
  for (const file of PAGES) {
    const { page } = await openPage(browser, server.origin, file);
    for (let i = 0; i < 100; i++) {
      await page.keyboard.press('Tab');
      const info = await page.evaluate(() => {
        const el = document.activeElement;
        if (!el || el === document.body) return null;
        const style = getComputedStyle(el);
        return {
          name: `${el.tagName.toLowerCase()} "${el.textContent.trim().slice(0, 25)}"`,
          focusVisible: el.matches(':focus-visible'),
          outlineStyle: style.outlineStyle,
          outlineWidth: parseFloat(style.outlineWidth),
        };
      });
      if (!info) break;
      if (!info.focusVisible || info.outlineStyle === 'none' || info.outlineWidth < 2) {
        problems.push(`${file}: ${info.name} outline ${info.outlineStyle} ${info.outlineWidth}px`);
      }
    }
  }
  assert.deepEqual(problems, []);
});

// Runs in the page: every text-bearing element against its nearest opaque background.
const CONTRAST_CHECK = () => {
  const channel = (v) => {
    const c = v / 255;
    return c <= 0.03928 ? c / 12.92 : ((c + 0.055) / 1.055) ** 2.4;
  };
  const luminance = ([r, g, b]) => 0.2126 * channel(r) + 0.7152 * channel(g) + 0.0722 * channel(b);
  const parse = (css) => css.match(/[\d.]+/g).map(Number);
  const backgroundOf = (el) => {
    for (let node = el; node; node = node.parentElement) {
      const rgba = parse(getComputedStyle(node).backgroundColor);
      if (rgba.length === 3 || rgba[3] > 0) return rgba.slice(0, 3);
    }
    return [255, 255, 255];
  };
  const results = [];
  for (const el of document.querySelectorAll('body *')) {
    const hasText = [...el.childNodes].some((n) => n.nodeType === Node.TEXT_NODE && n.textContent.trim());
    if (!hasText || !el.offsetParent) continue;
    const foreground = luminance(parse(getComputedStyle(el).color).slice(0, 3));
    const background = luminance(backgroundOf(el));
    const ratio = (Math.max(foreground, background) + 0.05) / (Math.min(foreground, background) + 0.05);
    results.push({ text: el.textContent.trim().slice(0, 30), ratio: Math.round(ratio * 100) / 100 });
  }
  return results;
};

test('all text meets WCAG AA contrast of 4.5:1 on every page', async () => {
  const failures = [];
  let checked = 0;
  for (const file of PAGES) {
    const { page } = await openPage(browser, server.origin, file);
    const results = await page.evaluate(CONTRAST_CHECK);
    checked += results.length;
    for (const r of results) {
      if (r.ratio < 4.5) failures.push(`${file}: ${r.ratio}:1 "${r.text}"`);
    }
  }
  assert.ok(checked > 50, `only ${checked} text elements checked`);
  assert.deepEqual(failures, []);
});

test('decorative book covers are aria-hidden and nothing decorative has a pointer cursor', async () => {
  const { page } = await openPage(browser, server.origin, 'books.html');
  const covers = await page.$$eval('.cover', (els) => els.map((el) => el.getAttribute('aria-hidden')));
  assert.ok(covers.length >= 12, `expected a cover per book, found ${covers.length}`);
  assert.ok(covers.every((v) => v === 'true'), 'every cover must be aria-hidden="true"');
  const pointers = await page.evaluate(() => [...document.querySelectorAll('body *')]
    .filter((el) => getComputedStyle(el).cursor === 'pointer')
    .filter((el) => !el.closest('a[href], button, input, label, select, textarea, summary'))
    .map((el) => `${el.tagName.toLowerCase()}.${el.className}`));
  assert.deepEqual(pointers, [], 'pointer cursor on non-interactive element');
});

test('prefers-reduced-motion removes transitions and animations, while normal motion keeps the transition', async () => {
  const normal = await openPage(browser, server.origin, 'index.html');
  const normalDuration = await normal.page.$eval('a.button', (el) => getComputedStyle(el).transitionDuration);
  assert.notEqual(normalDuration, '0s', 'button should animate normally so this test means something');

  const reduced = await openPage(browser, server.origin, 'index.html', 1280, { reducedMotion: 'reduce' });
  const durations = await reduced.page.evaluate(() => [...document.querySelectorAll('body *')].map((el) => {
    const s = getComputedStyle(el);
    return `${el.tagName.toLowerCase()} transition ${s.transitionDuration} animation ${s.animationDuration}`;
  }).filter((d) => !/transition 0s animation 0s$/.test(d)));
  assert.deepEqual(durations, []);
});

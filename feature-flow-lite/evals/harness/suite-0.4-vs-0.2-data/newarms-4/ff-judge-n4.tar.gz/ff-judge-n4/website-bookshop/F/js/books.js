import { books } from "./books-data.js";

const buttonGroup = document.getElementById("genre-buttons");
const bookList = document.getElementById("book-list");
const resultCount = document.getElementById("result-count");

function element(tag, className, text) {
  const node = document.createElement(tag);
  node.className = className;
  node.textContent = text;
  return node;
}

function slugify(name) {
  return name.trim().toLowerCase().replace(/\s+/g, "-");
}

function buildOptions() {
  const labels = new Map();
  for (const book of books) {
    const slug = slugify(book.genre);
    if (!labels.has(slug)) labels.set(slug, book.genre);
  }
  const genres = [...labels].map(([slug, label]) => ({ slug, label }));
  genres.sort((a, b) => a.label.localeCompare(b.label));
  return [{ slug: "all", label: "All" }, ...genres];
}

const options = buildOptions();

// Anything that is not a known genre slug (including empty or hostile values) means All.
function genreFromUrl() {
  const requested = slugify(
    new URLSearchParams(location.search).get("genre") ?? "",
  );
  return options.some((option) => option.slug === requested)
    ? requested
    : "all";
}

function urlForGenre(slug) {
  const url = new URL(location.href);
  if (slug === "all") {
    url.searchParams.delete("genre");
  } else {
    url.searchParams.set("genre", slug);
  }
  return url;
}

function createFilterButtons() {
  for (const option of options) {
    const button = document.createElement("button");
    button.type = "button";
    button.textContent = option.label;
    button.dataset.genre = option.slug;
    button.setAttribute("aria-pressed", "false");
    buttonGroup.append(button);
  }
}

function createBookCard(book) {
  const item = document.createElement("li");
  item.className = "card book-card";
  item.append(
    element("h2", "book-title", book.title),
    element("p", "book-author", `by ${book.author}`),
    element("p", "book-genre", `Genre: ${book.genre}`),
    element("p", "book-price", `Price: $${book.price.toFixed(2)}`),
    element("p", "book-description", book.description),
  );
  return item;
}

function renderBooks(slug) {
  const visible =
    slug === "all"
      ? books
      : books.filter((book) => slugify(book.genre) === slug);
  bookList.replaceChildren(...visible.map(createBookCard));
  resultCount.textContent = `Showing ${visible.length} of ${books.length} books`;
}

function markPressed(slug) {
  for (const button of buttonGroup.children) {
    button.setAttribute("aria-pressed", String(button.dataset.genre === slug));
  }
}

function showGenre(slug) {
  renderBooks(slug);
  markPressed(slug);
}

buttonGroup.addEventListener("click", (event) => {
  const button = event.target.closest("[data-genre]");
  if (!button) return;
  const url = urlForGenre(button.dataset.genre);
  if (url.href !== location.href) {
    history.pushState(null, "", url);
  }
  showGenre(button.dataset.genre);
});

window.addEventListener("popstate", () => {
  showGenre(genreFromUrl());
});

createFilterButtons();
showGenre(genreFromUrl());

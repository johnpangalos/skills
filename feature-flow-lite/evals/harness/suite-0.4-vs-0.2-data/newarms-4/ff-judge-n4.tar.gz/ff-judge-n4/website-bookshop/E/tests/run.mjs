// Headless browser tests for the Marginalia Books site.
// Run: NODE_PATH=$(npm root -g) node tests/run.mjs [--grep <name>]
// Starts its own static server on a free port, loads every page in Chromium and checks the acceptance criteria.

import assert from 'node:assert/strict';
import http from 'node:http';
import { readFile } from 'node:fs/promises';
import { createRequire } from 'node:module';
import path from 'node:path';
import { fileURLToPath, pathToFileURL } from 'node:url';

const require = createRequire(import.meta.url);
const { chromium } = require('playwright');

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const PAGES = ['index.html', 'books.html', 'events.html', 'visit.html'];
const NAV_HREFS = ['index.html', 'books.html', 'events.html', 'visit.html'];
const TYPES = {
  '.html': 'text/html; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.js': 'text/javascript; charset=utf-8',
  '.svg': 'image/svg+xml',
  '.png': 'image/png',
  '.jpg': 'image/jpeg'
};

function startServer() {
  const server = http.createServer(async (req, res) => {
    try {
      const urlPath = decodeURIComponent(new URL(req.url, 'http://localhost').pathname);
      const relative = urlPath === '/' ? 'index.html' : urlPath.replace(/^\/+/, '');
      const file = path.resolve(ROOT, relative);
      if (!file.startsWith(ROOT + path.sep)) {
        res.writeHead(403).end('Forbidden');
        return;
      }
      const body = await readFile(file);
      res.writeHead(200, { 'Content-Type': TYPES[path.extname(file)] || 'application/octet-stream' });
      res.end(body);
    } catch {
      res.writeHead(404).end('Not found');
    }
  });
  return new Promise((resolve) => server.listen(0, '127.0.0.1', () => resolve(server)));
}

const tests = [];
function test(name, fn) {
  tests.push({ name, fn });
}

// Opens a page in a fresh browser context and records console errors, requests and dialogs.
// Pass an absolute file: URL as pathName to test the file:// protocol.
async function open(ctx, pathName, { width = 1280, height = 800, clock } = {}) {
  const context = await ctx.browser.newContext({ viewport: { width, height } });
  ctx.contexts.push(context);
  const page = await context.newPage();
  const seen = { errors: [], requests: [], dialogs: [] };
  page.on('console', (message) => {
    if (message.type() === 'error') {
      seen.errors.push(message.text());
    }
  });
  page.on('pageerror', (error) => seen.errors.push(error.message));
  page.on('request', (request) => seen.requests.push(request.url()));
  page.on('dialog', (dialog) => {
    seen.dialogs.push(dialog.message());
    dialog.dismiss();
  });
  if (clock) {
    await page.clock.setFixedTime(clock);
  }
  const url = pathName.startsWith('file:') ? pathName : ctx.base + pathName;
  await page.goto(url);
  return { page, seen };
}

function assertLocalOnly(seen, base) {
  const external = seen.requests.filter((url) => {
    return !url.startsWith(base) && !url.startsWith('data:') && !url.startsWith('blob:') && !url.startsWith('file:');
  });
  assert.deepEqual(external, [], 'requests left the local origin');
}

function localDateIso() {
  const now = new Date();
  const pad = (n) => String(n).padStart(2, '0');
  return `${now.getFullYear()}-${pad(now.getMonth() + 1)}-${pad(now.getDate())}`;
}

function expectedTitles(page, genre) {
  return page.evaluate((name) => {
    return SITE_DATA.books.filter((book) => name === null || book.genre === name).map((book) => book.title);
  }, genre);
}

function shownTitles(page) {
  return page.$$eval('#book-list h3', (headings) => headings.map((heading) => heading.textContent));
}

function checkedGenre(page) {
  return page.$eval('input[name="genre"]:checked', (input) => input.value);
}

function resultText(page) {
  return page.textContent('#result-count');
}

test('pages-share-chrome-and-unique-titles', async (ctx) => {
  const footers = [];
  const titles = new Set();
  for (const file of PAGES) {
    const { page } = await open(ctx, '/' + file);
    const info = await page.evaluate(() => ({
      lang: document.documentElement.lang,
      title: document.title,
      viewport: document.querySelector('meta[name="viewport"]') !== null,
      description: document.querySelector('meta[name="description"]')?.content || '',
      brand: document.querySelector('header .brand')?.textContent,
      navLinks: [...document.querySelectorAll('#site-nav a')].map((link) => link.getAttribute('href')),
      current: [...document.querySelectorAll('#site-nav a[aria-current="page"]')].map((link) => link.getAttribute('href')),
      footer: document.querySelector('footer').innerHTML,
      footerAddress: document.querySelector('footer address') !== null
    }));
    assert.equal(info.lang, 'en', `${file} lang`);
    assert.ok(info.viewport, `${file} meta viewport`);
    assert.ok(info.description.length > 40, `${file} meta description`);
    assert.equal(info.brand, 'Marginalia Books', `${file} brand`);
    assert.deepEqual(info.navLinks, NAV_HREFS, `${file} nav links`);
    assert.deepEqual(info.current, [file], `${file} aria-current`);
    assert.ok(info.footerAddress, `${file} footer address`);
    titles.add(info.title);
    footers.push(info.footer);
  }
  assert.equal(titles.size, PAGES.length, 'every page needs a unique title');
  for (const footer of footers) {
    assert.equal(footer, footers[0], 'footer must be identical on every page');
  }
});

test('nav-and-content-links-resolve', async (ctx) => {
  const targets = new Set();
  for (const file of PAGES) {
    const { page } = await open(ctx, '/' + file);
    const hrefs = await page.$$eval('a[href]', (links) => links.map((link) => link.getAttribute('href')));
    for (const href of hrefs) {
      if (!/^(mailto:|tel:|#)/.test(href)) {
        targets.add(new URL(href, ctx.base + '/' + file).href);
      }
    }
  }
  assert.ok(targets.size >= 4, 'expected several internal links');
  const { page } = await open(ctx, '/index.html');
  for (const target of targets) {
    const response = await page.request.get(target);
    assert.equal(response.status(), 200, `${target} should resolve`);
  }
});

test('no-external-requests-or-form-actions', async (ctx) => {
  const requests = [];
  for (const file of PAGES) {
    const { page, seen } = await open(ctx, '/' + file);
    const actions = await page.$$eval('form', (forms) => forms.map((form) => form.action));
    for (const action of actions) {
      assert.ok(action.startsWith(ctx.base), `${file} form action ${action} must be local`);
    }
    requests.push(...seen.requests);
  }
  const { page, seen } = await open(ctx, '/books.html');
  await page.getByLabel('Mystery', { exact: true }).check();
  await page.goto(ctx.base + '/visit.html');
  await page.getByRole('button', { name: 'Send enquiry' }).click();
  requests.push(...seen.requests);
  assertLocalOnly({ requests }, ctx.base);
});

test('no-console-errors', async (ctx) => {
  for (const file of PAGES) {
    const { page, seen } = await open(ctx, '/' + file);
    await page.waitForLoadState('load');
    assert.deepEqual(seen.errors, [], `${file} console errors`);
    assert.deepEqual(seen.dialogs, [], `${file} dialogs`);
  }
});

test('no-horizontal-overflow-at-360', async (ctx) => {
  for (const file of PAGES) {
    const { page } = await open(ctx, '/' + file, { width: 360, height: 740 });
    const scrollWidth = await page.evaluate(() => document.documentElement.scrollWidth);
    assert.ok(scrollWidth <= 360, `${file} scrollWidth is ${scrollWidth}`);
  }
});

test('one-h1-no-skipped-headings-and-landmarks', async (ctx) => {
  for (const file of PAGES) {
    const { page } = await open(ctx, '/' + file);
    const info = await page.evaluate(() => ({
      h1: document.querySelectorAll('h1').length,
      levels: [...document.querySelectorAll('h1, h2, h3, h4, h5, h6')].map((h) => Number(h.tagName[1])),
      banner: document.querySelector('body > header') !== null,
      nav: document.querySelector('nav[aria-label]') !== null,
      main: document.querySelector('main#main') !== null,
      footer: document.querySelector('body > footer') !== null
    }));
    assert.equal(info.h1, 1, `${file} needs exactly one h1`);
    let previous = 0;
    for (const level of info.levels) {
      assert.ok(level <= previous + 1, `${file} skips a heading level (h${previous} to h${level})`);
      previous = level;
    }
    assert.ok(info.banner && info.nav && info.main && info.footer, `${file} is missing a landmark`);
  }
});

test('skip-link-is-first-focus-with-visible-ring', async (ctx) => {
  for (const file of PAGES) {
    const { page } = await open(ctx, '/' + file);
    await page.keyboard.press('Tab');
    const focused = await page.evaluate(() => {
      const element = document.activeElement;
      const style = getComputedStyle(element);
      return {
        className: element.className,
        href: element.getAttribute('href'),
        outlineStyle: style.outlineStyle,
        outlineWidth: parseFloat(style.outlineWidth),
        targetExists: document.getElementById('main') !== null
      };
    });
    assert.equal(focused.className, 'skip-link', `${file} first Tab should reach the skip link`);
    assert.equal(focused.href, '#main', `${file} skip link target`);
    assert.ok(focused.targetExists, `${file} #main must exist`);
    assert.equal(focused.outlineStyle, 'solid', `${file} skip link needs a focus ring`);
    assert.ok(focused.outlineWidth >= 2, `${file} focus ring too thin`);
    await page.keyboard.press('Enter');
    assert.equal(await page.evaluate(() => document.activeElement.id), 'main', `${file} skip link moves focus to main`);
  }
});

// WCAG relative luminance and contrast ratio for [r, g, b] colours.
function luminance(rgb) {
  const [r, g, b] = rgb.map((channel) => {
    const c = channel / 255;
    return c <= 0.03928 ? c / 12.92 : ((c + 0.055) / 1.055) ** 2.4;
  });
  return 0.2126 * r + 0.7152 * g + 0.0722 * b;
}

function contrast(a, b) {
  const [light, dark] = [luminance(a), luminance(b)].sort((x, y) => y - x);
  return (light + 0.05) / (dark + 0.05);
}

// Runs in the page: describes the focused element, its outline and the backgrounds it sits on.
function focusState() {
  const opaque = (node) => {
    for (let current = node; current; current = current.parentElement) {
      const parts = getComputedStyle(current).backgroundColor.match(/[\d.]+/g).map(Number);
      if (parts.length === 3 || parts[3] > 0) {
        return parts.slice(0, 3);
      }
    }
    return [255, 255, 255];
  };
  const element = document.activeElement;
  const style = getComputedStyle(element);
  const named = element.labels?.[0] ?? element;
  const box = element.closest('label') ?? element;
  return {
    tag: element.tagName,
    text: named.textContent.trim().slice(0, 40),
    value: element.type === 'radio' ? element.value : '',
    outlineStyle: style.outlineStyle,
    outlineWidth: parseFloat(style.outlineWidth),
    outlineColor: style.outlineColor,
    own: opaque(element),
    surface: opaque(box.parentElement)
  };
}

// The ring sits in the outline-offset gap, so it must contrast with the surface around the element.
function assertFocusRing(state, where) {
  assert.equal(state.outlineStyle, 'solid', `${where}: no focus outline`);
  assert.ok(state.outlineWidth >= 2, `${where}: focus outline too thin`);
  const ring = [...state.outlineColor.match(/[\d.]+/g).slice(0, 3).map(Number)];
  const ratio = contrast(ring, state.surface);
  assert.ok(ratio >= 3, `${where}: ring is ${ratio.toFixed(2)}:1 against the background behind it`);
}

// Presses Tab until focus leaves the page. With openMenu, the menu button is activated when reached.
async function tabStops(page, { openMenu = false } = {}) {
  const stops = [];
  for (let step = 0; step < 80; step += 1) {
    await page.keyboard.press('Tab');
    const state = await page.evaluate(focusState);
    if (state.tag === 'BODY') {
      break;
    }
    stops.push(state);
    if (openMenu && state.text === 'Menu') {
      await page.keyboard.press('Enter');
    }
  }
  return stops;
}

test('every-focusable-element-has-a-3to1-focus-ring', async (ctx) => {
  for (const [width, openMenu] of [[1280, false], [360, true]]) {
    for (const file of PAGES) {
      const { page } = await open(ctx, '/' + file, { width, height: 740 });
      const stops = await tabStops(page, { openMenu });
      assert.ok(stops.length >= 6, `${file} at ${width}px: only ${stops.length} tab stops (skip link, brand and four nav links at least)`);
      if (openMenu) {
        assert.ok(stops.some((state) => state.text === 'Visit'), `${file} at ${width}px: menu links are reachable`);
      }
      for (const state of stops) {
        assertFocusRing(state, `${file} at ${width}px, ${state.tag} "${state.text}"`);
      }
    }
  }
});

test('focus-ring-on-genre-chips-checked-or-not', async (ctx) => {
  const { page } = await open(ctx, '/books.html?genre=mystery');
  let state = {};
  for (let step = 0; step < 20 && state.value !== 'mystery'; step += 1) {
    await page.keyboard.press('Tab');
    state = await page.evaluate(focusState);
  }
  assert.equal(state.value, 'mystery', 'the checked Mystery chip gets keyboard focus');
  assertFocusRing(state, 'checked Mystery chip');
  assert.ok(contrast(state.outlineColor.match(/[\d.]+/g).slice(0, 3).map(Number), state.own) >= 3, 'ring is 3:1 against the chip fill');
  for (let step = 0; step < 7; step += 1) {
    await page.keyboard.press('ArrowRight');
    state = await page.evaluate(focusState);
    assert.equal(state.tag, 'INPUT', 'arrow keys move between chips');
    assertFocusRing(state, `chip "${state.text}"`);
    assert.ok(contrast(state.outlineColor.match(/[\d.]+/g).slice(0, 3).map(Number), state.own) >= 3, `chip "${state.text}" ring vs chip fill`);
  }
});

test('mobile-menu-keyboard-operation', async (ctx) => {
  const { page } = await open(ctx, '/books.html', { width: 360, height: 740 });
  await page.keyboard.press('Tab');
  await page.keyboard.press('Tab');
  await page.keyboard.press('Tab');
  assert.equal(await page.evaluate(() => document.activeElement.className), 'menu-toggle');
  assert.equal(await page.locator('#site-nav').isVisible(), false, 'menu starts closed and hidden');
  await page.keyboard.press('Enter');
  assert.equal(await page.getAttribute('.menu-toggle', 'aria-expanded'), 'true');
  assert.equal(await page.locator('#site-nav').isVisible(), true, 'menu visible after opening');
  await page.keyboard.press('Tab');
  assert.equal(await page.evaluate(() => document.activeElement.textContent), 'Home');
  await page.keyboard.press('Escape');
  assert.equal(await page.getAttribute('.menu-toggle', 'aria-expanded'), 'false');
  assert.equal(await page.locator('#site-nav').isVisible(), false, 'menu hidden after Escape');
  assert.equal(await page.evaluate(() => document.activeElement.className), 'menu-toggle', 'focus returns to the toggle');
});

test('layout-grid-at-768-and-1280', async (ctx) => {
  const { page } = await open(ctx, '/books.html', { width: 768, height: 900 });
  const columnCount = () => page.evaluate(() => {
    return getComputedStyle(document.querySelector('#book-list')).gridTemplateColumns.split(' ').length;
  });
  assert.equal(await columnCount(), 2, 'two columns at 768px');
  await page.setViewportSize({ width: 1280, height: 900 });
  assert.equal(await columnCount(), 3, 'three columns at 1280px');
  assert.equal(await page.locator('.menu-toggle').isVisible(), false, 'no menu button on wide screens');
});

test('books-catalogue-has-genres-and-fields', async (ctx) => {
  const { page } = await open(ctx, '/books.html');
  const info = await page.evaluate(() => {
    const counts = {};
    document.querySelectorAll('#book-list .genre-tag').forEach((tag) => {
      counts[tag.textContent] = (counts[tag.textContent] || 0) + 1;
    });
    const cards = [...document.querySelectorAll('#book-list .book-card')];
    return {
      total: cards.length,
      counts,
      complete: cards.every((card) => {
        return card.querySelector('h3')?.textContent &&
          card.querySelector('.book-author')?.textContent.startsWith('by ') &&
          /^£\d+\.\d{2}$/.test(card.querySelector('.book-price')?.textContent || '') &&
          card.querySelector('.book-blurb')?.textContent.length > 20;
      })
    };
  });
  assert.ok(info.total >= 12, `expected at least 12 books, found ${info.total}`);
  assert.ok(Object.keys(info.counts).length >= 5, 'at least 5 genres');
  for (const [genre, count] of Object.entries(info.counts)) {
    assert.ok(count >= 2, `${genre} needs at least 2 titles`);
  }
  assert.ok(info.complete, 'every card needs title, author, price and blurb');
});

test('books-filter-updates-list-count-and-url', async (ctx) => {
  const { page } = await open(ctx, '/books.html');
  const total = await page.evaluate(() => SITE_DATA.books.length);
  const everyTitle = await shownTitles(page);
  const mystery = await expectedTitles(page, 'Mystery');
  await page.getByLabel('Mystery', { exact: true }).check();
  assert.deepEqual(await shownTitles(page), mystery, 'only mystery books shown');
  assert.equal(await resultText(page), `Showing ${mystery.length} of ${total} books`);
  assert.equal(new URL(page.url()).searchParams.get('genre'), 'mystery', 'URL carries the genre');
  assert.equal(await checkedGenre(page), 'mystery');
  await page.getByLabel('All', { exact: true }).check();
  assert.deepEqual(await shownTitles(page), everyTitle, 'All shows every book');
  assert.equal(await resultText(page), `Showing ${total} of ${total} books`);
  assert.equal(new URL(page.url()).searchParams.get('genre'), null, 'All removes the genre parameter');
  assert.equal(await page.$eval('#result-count', (node) => node.closest('[role="status"]') !== null), true, 'count is a live region');
});

test('books-url-state-back-and-forward', async (ctx) => {
  const { page } = await open(ctx, '/books.html?genre=poetry');
  const poetry = await expectedTitles(page, 'Poetry');
  assert.equal(await checkedGenre(page), 'poetry', 'URL selects the control');
  assert.deepEqual(await shownTitles(page), poetry);
  await page.getByLabel('Nature Writing', { exact: true }).check();
  const nature = await expectedTitles(page, 'Nature Writing');
  assert.deepEqual(await shownTitles(page), nature);
  await page.goBack();
  assert.equal(await checkedGenre(page), 'poetry', 'back restores poetry');
  assert.deepEqual(await shownTitles(page), poetry);
  await page.goForward();
  assert.equal(await checkedGenre(page), 'nature-writing', 'forward restores nature writing');
  assert.deepEqual(await shownTitles(page), nature);
});

test('books-unknown-or-empty-genre-falls-back-to-all', async (ctx) => {
  const total = (await open(ctx, '/books.html')).page;
  const everyTitle = await shownTitles(total);
  for (const query of ['?genre=unknown-genre', '?genre=']) {
    const { page } = await open(ctx, '/books.html' + query);
    assert.equal(await checkedGenre(page), '', `${query} selects All`);
    assert.deepEqual(await shownTitles(page), everyTitle, `${query} shows every book`);
    assert.equal(await page.locator('#empty-state').isVisible(), false, `${query} has no empty state`);
  }
  const { page } = await open(ctx, '/books.html?genre=unknown-genre');
  assert.equal(await page.locator('#filter-note').isVisible(), true, 'unknown genre is explained');
  assert.ok((await page.textContent('#filter-note')).includes('unknown-genre'));
});

test('books-genre-without-letters-is-explained', async (ctx) => {
  const { page: catalogue } = await open(ctx, '/books.html');
  const count = await catalogue.evaluate(() => SITE_DATA.books.length);
  const { page } = await open(ctx, '/books.html?genre=' + encodeURIComponent('!!!'));
  assert.equal(await checkedGenre(page), '', '!!! selects All');
  assert.equal(await resultText(page), `Showing ${count} of ${count} books`);
  assert.equal(await page.locator('#filter-note').isVisible(), true, '!!! is explained');
  assert.equal(await page.textContent('#filter-note'), 'There is no genre called “!!!”, so every book is shown.');
  const blank = await open(ctx, '/books.html?genre=' + encodeURIComponent('  '));
  assert.equal(await blank.page.locator('#filter-note').isVisible(), false, 'a blank genre is not reported as unknown');
});

test('books-genre-case-and-spaces-are-tolerated', async (ctx) => {
  let { page } = await open(ctx, '/books.html?genre=MYSTERY');
  assert.equal(await checkedGenre(page), 'mystery', 'uppercase genre matches');
  assert.deepEqual(await shownTitles(page), await expectedTitles(page, 'Mystery'));
  ({ page } = await open(ctx, '/books.html?genre=Science%20Fiction'));
  assert.equal(await checkedGenre(page), 'science-fiction', 'spaced genre name matches');
  assert.deepEqual(await shownTitles(page), await expectedTitles(page, 'Science Fiction'));
});

test('books-genre-param-is-never-html', async (ctx) => {
  const payload = encodeURIComponent('<script>alert(1)</script>');
  const { page, seen } = await open(ctx, `/books.html?genre=${payload}`);
  const note = await page.textContent('#filter-note');
  assert.ok(note.includes('<script>alert(1)</script>'), 'the raw text is shown as text');
  assert.equal(await page.locator('#filter-note script').count(), 0, 'no script element injected');
  assert.equal(await page.locator('#book-list script, #genre-options script').count(), 0);
  assert.deepEqual(seen.dialogs, [], 'no alert fired');
  assert.deepEqual(seen.errors, [], 'no console errors');
  assert.equal(await checkedGenre(page), '', 'falls back to All');
});

test('books-empty-state-message-exists', async (ctx) => {
  const { page } = await open(ctx, '/books.html');
  const empty = await page.textContent('#empty-state');
  assert.ok(empty.includes('No books match this genre'), 'empty state wording');
  assert.equal(await page.locator('#empty-state').isVisible(), false, 'hidden when books are shown');
});

test('home-shows-picks-events-and-calls-to-action', async (ctx) => {
  const { page } = await open(ctx, '/index.html');
  const picks = await page.evaluate(() => SITE_DATA.books.filter((book) => book.staffPick).slice(0, 3).map((book) => book.title));
  assert.deepEqual(await page.$$eval('#staff-picks h3', (headings) => headings.map((h) => h.textContent)), picks);
  assert.ok(await page.locator('#home-events time').count() >= 1, 'home lists upcoming events');
  for (const href of ['books.html', 'events.html', 'visit.html']) {
    assert.ok(await page.locator(`main a[href="${href}"]`).count() >= 1, `call to action to ${href}`);
  }
  assert.ok(!/lorem ipsum/i.test(await page.textContent('body')), 'no placeholder text');
});

test('events-are-chronological-and-upcoming', async (ctx) => {
  const { page } = await open(ctx, '/events.html');
  const times = await page.$$eval('#event-list time', (nodes) => nodes.map((node) => node.getAttribute('datetime')));
  assert.ok(times.length >= 4, `expected at least 4 events, found ${times.length}`);
  assert.deepEqual(times, [...times].sort(), 'events in chronological order');
  const today = localDateIso();
  for (const time of times) {
    assert.ok(time.slice(0, 10) >= today, `${time} is in the past`);
    assert.ok(time >= '2026-11-20' && time <= '2027-02-28', `${time} outside the programme window`);
  }
  const details = await page.$$eval('#event-list li', (items) => items.map((item) => ({
    heading: item.querySelector('h3')?.textContent || '',
    text: item.querySelector('.event-text')?.textContent || '',
    booking: item.querySelector('.booking')?.textContent || ''
  })));
  for (const item of details) {
    assert.ok(item.heading && item.text.length > 20, 'title and description present');
    assert.ok(/booking/i.test(item.booking), 'booking status stated');
  }
  assert.equal(await page.locator('#events-empty').isVisible(), false);
});

test('events-include-event-on-local-midnight-of-its-day', async (ctx) => {
  const total = await (await open(ctx, '/events.html')).page.evaluate(() => SITE_DATA.events.length);
  // Local midnight of 21 Nov 2026 in each zone. A date-only string parsed as UTC would count that day as past.
  const zones = [
    { timezoneId: 'America/Los_Angeles', midnight: new Date('2026-11-21T00:00:00-08:00') },
    { timezoneId: 'Pacific/Auckland', midnight: new Date('2026-11-21T00:00:00+13:00') }
  ];
  for (const { timezoneId, midnight } of zones) {
    const context = await ctx.browser.newContext({ timezoneId, viewport: { width: 1280, height: 800 } });
    ctx.contexts.push(context);
    const page = await context.newPage();
    await page.clock.setFixedTime(midnight);
    await page.goto(ctx.base + '/events.html');
    const first = await page.$eval('#event-list time', (node) => node.getAttribute('datetime'));
    assert.equal(first, '2026-11-21T19:00', `${timezoneId}: an event on the local current day is not treated as past`);
    assert.equal(await page.locator('#event-list li').count(), total, `${timezoneId}: no event dropped`);
  }
});

test('events-empty-message-when-none-remain', async (ctx) => {
  const { page } = await open(ctx, '/events.html', { clock: new Date(2027, 2, 1, 9, 0, 0) });
  assert.equal(await page.locator('#event-list li').count(), 0, 'no past events shown');
  assert.equal(await page.locator('#events-empty').isVisible(), true, 'message shown');
  assert.ok((await page.textContent('#events-empty')).includes('no upcoming events'));
});

test('visit-hours-address-and-contact-links', async (ctx) => {
  const { page } = await open(ctx, '/visit.html');
  const hours = await page.$$eval('main table tbody tr', (rows) => rows.map((row) => row.querySelector('th').textContent));
  assert.deepEqual(hours, ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday']);
  assert.equal(await page.locator('main address').count(), 1, 'address element');
  assert.ok(await page.locator('main a[href^="tel:"]').count() >= 1, 'tel link');
  assert.ok(await page.locator('main a[href^="mailto:"]').count() >= 1, 'mailto link');
});

test('form-labels-are-bound-and-required', async (ctx) => {
  const { page } = await open(ctx, '/visit.html');
  for (const id of ['contact-name', 'contact-email', 'contact-message', 'contact-subject']) {
    assert.equal(await page.locator(`label[for="${id}"]`).count(), 1, `${id} has a bound label`);
  }
  for (const id of ['contact-name', 'contact-email', 'contact-message']) {
    assert.equal(await page.getAttribute('#' + id, 'required'), '', `${id} is required`);
  }
});

test('form-empty-submit-marks-fields-and-focuses-first', async (ctx) => {
  const { page } = await open(ctx, '/visit.html');
  await page.getByRole('button', { name: 'Send enquiry' }).click();
  for (const id of ['name', 'email', 'message']) {
    assert.equal(await page.getAttribute(`#contact-${id}`, 'aria-invalid'), 'true', `${id} invalid`);
    assert.equal(await page.getAttribute(`#contact-${id}`, 'aria-describedby'), `contact-${id}-error`);
    assert.equal(await page.locator(`#contact-${id}-error`).isVisible(), true, `${id} error visible`);
    assert.ok((await page.textContent(`#contact-${id}-error`)).length > 5, `${id} error has text`);
  }
  assert.equal(await page.evaluate(() => document.activeElement.id), 'contact-name', 'focus moves to first invalid field');
});

test('form-whitespace-and-invalid-email-rejected-then-cleared', async (ctx) => {
  const { page } = await open(ctx, '/visit.html');
  await page.fill('#contact-name', '   ');
  await page.fill('#contact-email', 'a@');
  await page.fill('#contact-message', '   \n  ');
  await page.getByRole('button', { name: 'Send enquiry' }).click();
  for (const id of ['name', 'email', 'message']) {
    assert.equal(await page.getAttribute(`#contact-${id}`, 'aria-invalid'), 'true', `${id} invalid`);
  }
  assert.ok((await page.textContent('#contact-email-error')).includes('email address'));
  await page.fill('#contact-name', 'Ada Reader');
  assert.equal(await page.getAttribute('#contact-name', 'aria-invalid'), 'false', 'name error clears');
  assert.equal(await page.locator('#contact-name-error').isVisible(), false);
  await page.fill('#contact-email', 'foo');
  assert.equal(await page.getAttribute('#contact-email', 'aria-invalid'), 'true', '"foo" is not an email');
  await page.fill('#contact-email', 'ada@example.com');
  assert.equal(await page.getAttribute('#contact-email', 'aria-invalid'), 'false', 'valid email clears');
  assert.equal(await page.locator('#contact-email-error').isVisible(), false);
  await page.fill('#contact-message', 'Do you hold book club sets?');
  assert.equal(await page.getAttribute('#contact-message', 'aria-invalid'), 'false', 'message error clears');
});

test('form-valid-submit-demo-never-claims-sent', async (ctx) => {
  const { page, seen } = await open(ctx, '/visit.html');
  await page.fill('#contact-name', 'Ada Reader');
  await page.fill('#contact-email', 'ada@example.com');
  await page.fill('#contact-subject', 'Book club');
  await page.fill('#contact-message', 'Do you hold book club sets?');
  await page.getByRole('button', { name: 'Send enquiry' }).click();
  const status = await page.textContent('#form-status');
  assert.ok(/demo/i.test(status) && /not sent/i.test(status), 'status says this is a demo and nothing was sent');
  assert.ok(!/(message sent|we.ll be in touch|thanks)/i.test(status), 'no delivery claim');
  assert.equal(await page.getAttribute('#form-status', 'role'), 'status', 'status is announced');
  const mailto = decodeURIComponent(await page.getAttribute('#mailto-link', 'href'));
  assert.ok(mailto.startsWith('mailto:hello@marginaliabooks.example?subject=Book club'), 'mailto prefilled with subject');
  assert.ok(mailto.includes('Do you hold book club sets?') && mailto.includes('ada@example.com'), 'mailto has the message');
  assert.ok(page.url().endsWith('/visit.html'), 'form does not navigate away');
  await page.getByRole('button', { name: 'Send enquiry' }).click();
  await page.getByRole('button', { name: 'Send enquiry' }).click();
  assert.ok(/demo/i.test(await page.textContent('#form-status')), 'double submit still shows the demo notice');
  assert.equal(await page.getAttribute('#contact-name', 'aria-invalid'), 'false');
  assert.deepEqual(seen.errors, [], 'no console errors on submit');
});

test('form-html-in-fields-is-text-only', async (ctx) => {
  const { page, seen } = await open(ctx, '/visit.html');
  const message = '<b>x</b><script>window.__x=1</script>';
  await page.fill('#contact-name', 'Ada Reader');
  await page.fill('#contact-email', 'ada@example.com');
  await page.fill('#contact-message', message);
  await page.getByRole('button', { name: 'Send enquiry' }).click();
  assert.match(await page.textContent('#form-status'), /demo/i, 'valid submit reached the demo notice');
  assert.equal(await page.evaluate(() => window.__x), undefined, 'script in the message never runs');
  assert.equal(await page.locator('b').count(), 0, 'no <b> element anywhere in the document');
  assert.deepEqual(seen.dialogs, [], 'no alert from message');
  const mailto = await page.getAttribute('#mailto-link', 'href');
  assert.ok(mailto.includes(encodeURIComponent(message)), 'mailto href carries the message encoded');
});

test('form-long-message-keeps-layout-at-360', async (ctx) => {
  const { page } = await open(ctx, '/visit.html', { width: 360, height: 740 });
  const long = 'Could you tell me about ' + 'a'.repeat(120) + ' and ' + 'word '.repeat(1000);
  await page.fill('#contact-name', 'Ada Reader');
  await page.fill('#contact-email', 'ada@example.com');
  await page.fill('#contact-message', long);
  await page.getByRole('button', { name: 'Send enquiry' }).click();
  assert.ok((await page.inputValue('#contact-message')).length >= 5000, 'long message kept in full');
  assert.ok(/demo/i.test(await page.textContent('#form-status')));
  const scrollWidth = await page.evaluate(() => document.documentElement.scrollWidth);
  assert.ok(scrollWidth <= 360, `long message widened the page to ${scrollWidth}px`);
});

test('file-protocol-renders-catalogue', async (ctx) => {
  const books = pathToFileURL(path.join(ROOT, 'books.html')).href;
  const { page, seen } = await open(ctx, books);
  assert.ok(await page.locator('#book-list .book-card').count() >= 12, 'catalogue renders from file://');
  const home = pathToFileURL(path.join(ROOT, 'index.html')).href;
  const home2 = await open(ctx, home);
  assert.equal(await home2.page.locator('#staff-picks .book-card').count(), 3, 'home picks render from file://');
  assert.deepEqual(seen.errors, [], 'no console errors from file://');
});

async function main() {
  const flag = process.argv.indexOf('--grep');
  const grep = flag === -1 ? null : process.argv[flag + 1];
  const selected = tests.filter((item) => !grep || item.name.includes(grep));
  if (selected.length === 0) {
    console.log(`No tests match "${grep}"`);
    process.exitCode = 1;
    return;
  }

  const server = await startServer();
  const base = `http://127.0.0.1:${server.address().port}`;
  const browser = await chromium.launch({ headless: true });
  const ctx = { base, browser, contexts: [] };
  let failures = 0;
  try {
    for (const item of selected) {
      try {
        await item.fn(ctx);
        console.log(`PASS ${item.name}`);
      } catch (error) {
        failures += 1;
        console.log(`FAIL ${item.name}`);
        console.log(`     ${String(error.message).split('\n')[0]}`);
      }
    }
  } finally {
    for (const context of ctx.contexts) {
      await context.close().catch(() => {});
    }
    await browser.close();
    server.close();
  }
  console.log(`\n${selected.length - failures} passed, ${failures} failed`);
  process.exitCode = failures > 0 ? 1 : 0;
}

main();

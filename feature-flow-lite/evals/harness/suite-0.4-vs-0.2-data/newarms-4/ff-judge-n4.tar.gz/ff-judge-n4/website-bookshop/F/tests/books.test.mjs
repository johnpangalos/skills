import { describe, it, before, after } from "node:test";
import assert from "node:assert/strict";
import { startServer } from "./server.mjs";
import { launchBrowser, openTracked } from "./helpers.mjs";

const ALL_COUNT = "Showing 14 of 14 books";

let server;
let browser;

before(async () => {
  server = await startServer();
  browser = await launchBrowser();
});

after(async () => {
  await browser.close();
  await server.close();
});

async function openBooks(query = "") {
  const tracked = await openTracked(browser);
  await tracked.page.goto(`${server.origin}/books.html${query}`, {
    waitUntil: "load",
  });
  return tracked;
}

function visibleTitles(page) {
  return page.$$eval("#book-list .book-title", (titles) =>
    titles.map((title) => title.textContent),
  );
}

function pressedGenres(page) {
  return page.$$eval("#genre-buttons button", (buttons) =>
    buttons
      .filter((button) => button.getAttribute("aria-pressed") === "true")
      .map((b) => b.textContent),
  );
}

function resultText(page) {
  return page.textContent("#result-count");
}

async function waitForResult(page, text) {
  await page.waitForFunction(
    (expected) =>
      document.querySelector("#result-count").textContent === expected,
    text,
  );
}

describe("catalogue", () => {
  it("renders at least 12 books across at least 5 genres with every field", async () => {
    const { page, problems, close } = await openBooks();
    try {
      const books = await page.$$eval("#book-list .book-card", (cards) =>
        cards.map((card) => ({
          title: card.querySelector(".book-title")?.textContent ?? "",
          author: card.querySelector(".book-author")?.textContent ?? "",
          genre: card.querySelector(".book-genre")?.textContent ?? "",
          price: card.querySelector(".book-price")?.textContent ?? "",
          description:
            card.querySelector(".book-description")?.textContent ?? "",
        })),
      );
      assert.ok(
        books.length >= 12,
        `expected at least 12 books, got ${books.length}`,
      );
      const genres = new Set(
        books.map((book) => book.genre.replace("Genre: ", "")),
      );
      assert.ok(
        genres.size >= 5,
        `expected at least 5 genres, got ${genres.size}`,
      );
      for (const book of books) {
        assert.notEqual(book.title, "");
        assert.match(book.author, /^by \S/);
        assert.match(book.price, /^Price: \$\d+\.\d{2}$/);
        assert.notEqual(book.description, "");
      }
      assert.equal(await resultText(page), ALL_COUNT);
      assert.deepEqual(problems, []);
    } finally {
      await close();
    }
  });

  it("exposes a labelled genre group with All plus every genre as toggle buttons", async () => {
    const { page, close } = await openBooks();
    try {
      const group = await page.evaluate(() => ({
        legend:
          document.querySelector("fieldset.genre-filter legend")?.textContent ??
          "",
        buttons: [...document.querySelectorAll("#genre-buttons button")].map(
          (button) => ({
            label: button.textContent,
            pressed: button.getAttribute("aria-pressed"),
          }),
        ),
      }));
      assert.equal(group.legend, "Filter by genre");
      assert.deepEqual(
        group.buttons.map((button) => button.label),
        [
          "All",
          "Fantasy",
          "History",
          "Literary Fiction",
          "Mystery",
          "Poetry",
          "Science Fiction",
        ],
      );
      assert.equal(group.buttons[0].pressed, "true");
      assert.ok(
        group.buttons.slice(1).every((button) => button.pressed === "false"),
      );
    } finally {
      await close();
    }
  });
});

describe("genre filter", () => {
  it("clicking Mystery shows only mystery books, announces the count and updates the URL", async () => {
    const { page, problems, close } = await openBooks();
    try {
      await page.click('#genre-buttons button:text-is("Mystery")');
      const titles = await visibleTitles(page);
      assert.deepEqual(titles, [
        "The Glass Orchard Murders",
        "Nine Keys to Harrow Street",
        "The Quiet Tenant",
      ]);
      assert.equal(await resultText(page), "Showing 3 of 14 books");
      assert.deepEqual(await pressedGenres(page), ["Mystery"]);
      assert.equal(new URL(page.url()).searchParams.get("genre"), "mystery");
      assert.deepEqual(problems, []);
    } finally {
      await close();
    }
  });

  it("loading ?genre=mystery shows only mystery and presses the Mystery button", async () => {
    const { page, close } = await openBooks("?genre=mystery");
    try {
      assert.equal((await visibleTitles(page)).length, 3);
      assert.equal(await resultText(page), "Showing 3 of 14 books");
      assert.deepEqual(await pressedGenres(page), ["Mystery"]);
    } finally {
      await close();
    }
  });

  it("switching back to All removes the genre from the URL", async () => {
    const { page, close } = await openBooks("?genre=poetry");
    try {
      await page.click('#genre-buttons button:text-is("All")');
      assert.equal(await resultText(page), ALL_COUNT);
      assert.equal(new URL(page.url()).searchParams.has("genre"), false);
      assert.deepEqual(await pressedGenres(page), ["All"]);
    } finally {
      await close();
    }
  });

  it("back restores the previous filter and forward re-applies it", async () => {
    const { page, problems, close } = await openBooks();
    try {
      await page.click('#genre-buttons button:text-is("Mystery")');
      await page.click('#genre-buttons button:text-is("Fantasy")');
      assert.equal(await resultText(page), "Showing 3 of 14 books");

      await page.goBack();
      await waitForResult(page, "Showing 3 of 14 books");
      assert.equal(new URL(page.url()).searchParams.get("genre"), "mystery");
      assert.deepEqual(await pressedGenres(page), ["Mystery"]);

      await page.goBack();
      await waitForResult(page, ALL_COUNT);
      assert.deepEqual(await pressedGenres(page), ["All"]);

      await page.goForward();
      await waitForResult(page, "Showing 3 of 14 books");
      assert.deepEqual(await pressedGenres(page), ["Mystery"]);
      assert.deepEqual(problems, []);
    } finally {
      await close();
    }
  });

  it("matches genre names case-insensitively", async () => {
    const { page, close } = await openBooks("?genre=FANTASY");
    try {
      assert.equal(await resultText(page), "Showing 3 of 14 books");
      assert.deepEqual(await pressedGenres(page), ["Fantasy"]);
    } finally {
      await close();
    }
  });

  for (const [name, query] of [
    ["an unknown genre", "?genre=Nonexistent"],
    ["an empty genre", "?genre="],
    ["a script tag", "?genre=%3Cscript%3Ealert(1)%3C%2Fscript%3E"],
  ]) {
    it(`falls back to All for ${name} without errors or injected markup`, async () => {
      const { page, problems, close } = await openBooks(query);
      try {
        assert.equal(await resultText(page), ALL_COUNT);
        assert.equal((await visibleTitles(page)).length, 14);
        assert.deepEqual(await pressedGenres(page), ["All"]);
        const injected = await page.evaluate(
          () =>
            document.querySelectorAll(
              "#book-list script, #genre-buttons script, #genre-buttons *:not(button)",
            ).length,
        );
        assert.equal(injected, 0);
        assert.equal(
          await page.evaluate(() =>
            document.body.innerHTML.includes("<script>alert"),
          ),
          false,
        );
        assert.deepEqual(problems, []);
      } finally {
        await close();
      }
    });
  }
});

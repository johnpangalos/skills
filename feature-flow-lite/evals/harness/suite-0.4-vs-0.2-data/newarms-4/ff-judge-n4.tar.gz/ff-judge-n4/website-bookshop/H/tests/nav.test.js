'use strict';

const { describe, it, before, after } = require('node:test');
const assert = require('node:assert/strict');
const { PAGES, NARROW, WIDE, startSite, openPage, tabStops } = require('./helpers');

async function navLinksVisible(page) {
  return page.$$eval('header nav a', (links) => links.some((a) => a.getClientRects().length > 0));
}

async function toggleVisible(page) {
  return page.$eval('.nav-toggle', (button) => button.getClientRects().length > 0);
}

describe('shared navigation (criterion 2)', () => {
  let site;
  before(async () => { site = await startSite(); });
  after(async () => { await site.close(); });

  it('has identical labels, order and relative hrefs on every page', async () => {
    for (const { file } of PAGES) {
      const page = await openPage(site, file);
      const links = await page.$$eval('header nav a', (as) => as.map((a) => ({
        text: a.textContent.trim(),
        href: a.getAttribute('href'),
      })));
      assert.deepEqual(links, PAGES.map(({ file: href, label }) => ({ text: label, href })), file);
    }
  });

  it('marks only the current page link with aria-current="page" and styles it distinctly', async () => {
    for (const { file } of PAGES) {
      const page = await openPage(site, file);
      const links = await page.$$eval('header nav a', (as) => as.map((a) => {
        const style = getComputedStyle(a);
        return {
          href: a.getAttribute('href'),
          current: a.getAttribute('aria-current'),
          underline: style.textDecorationLine.includes('underline'),
        };
      }));
      const current = links.filter((link) => link.current !== null);
      assert.deepEqual(current.map((link) => [link.href, link.current]), [[file, 'page']], file);
      assert.equal(current[0].underline, true, `${file} current link has no distinct style`);
      assert.ok(links.filter((link) => link.current === null).every((link) => !link.underline), `${file} other links look current`);
    }
  });
});

describe('mobile navigation (criterion 3)', () => {
  let site;
  before(async () => { site = await startSite(); });
  after(async () => { await site.close(); });

  it('collapses behind a real button with aria-expanded and aria-controls at narrow widths', async () => {
    const page = await openPage(site, 'index.html', { width: NARROW });
    const info = await page.evaluate(() => {
      const button = document.querySelector('.nav-toggle');
      const controlled = document.getElementById(button.getAttribute('aria-controls'));
      return {
        tag: button.tagName,
        expanded: button.getAttribute('aria-expanded'),
        visible: button.getClientRects().length > 0,
        controlled: controlled ? controlled.tagName : null,
      };
    });
    assert.deepEqual(info, { tag: 'BUTTON', expanded: 'false', visible: true, controlled: 'NAV' });
    assert.equal(await navLinksVisible(page), false, 'links are shown while closed');
  });

  it('toggles aria-expanded and shows or hides the links when the button is pressed', async () => {
    const page = await openPage(site, 'index.html', { width: NARROW });
    await page.click('.nav-toggle');
    assert.equal(await page.getAttribute('.nav-toggle', 'aria-expanded'), 'true');
    assert.equal(await navLinksVisible(page), true, 'links stay hidden when open');
    await page.click('.nav-toggle');
    assert.equal(await page.getAttribute('.nav-toggle', 'aria-expanded'), 'false');
    assert.equal(await navLinksVisible(page), false, 'links stay visible when closed');
  });

  it('closes on Escape and returns focus to the button', async () => {
    const page = await openPage(site, 'index.html', { width: NARROW });
    await page.click('.nav-toggle');
    await page.keyboard.press('Tab');
    assert.equal(await page.evaluate(() => document.activeElement.closest('header nav') !== null), true);
    await page.keyboard.press('Escape');
    assert.equal(await page.getAttribute('.nav-toggle', 'aria-expanded'), 'false');
    assert.equal(await navLinksVisible(page), false);
    assert.equal(await page.evaluate(() => document.activeElement.classList.contains('nav-toggle')), true);
  });

  it('keeps the links of a closed menu out of keyboard focus, and puts them in focus when open', async () => {
    const page = await openPage(site, 'index.html', { width: NARROW });
    const closed = await tabStops(page);
    assert.equal(closed.filter((stop) => stop.inNav).length, 0, 'closed menu links are focusable');

    const opened = await openPage(site, 'index.html', { width: NARROW });
    await opened.click('.nav-toggle');
    const open = await tabStops(opened);
    assert.equal(open.filter((stop) => stop.inNav).length, 4, 'open menu links are not focusable');
  });

  it('does not leave the nav hidden after resizing from a narrow open menu to wide', async () => {
    const page = await openPage(site, 'index.html', { width: NARROW });
    await page.click('.nav-toggle');
    await page.setViewportSize({ width: WIDE, height: 800 });
    await page.waitForFunction(() => document.querySelector('.nav-toggle').getClientRects().length === 0);
    assert.equal(await navLinksVisible(page), true, 'nav hidden at wide width');
    assert.equal(await toggleVisible(page), false, 'toggle shown at wide width');
  });

  it('shows the links without the button at wide widths', async () => {
    const page = await openPage(site, 'index.html', { width: WIDE });
    assert.equal(await navLinksVisible(page), true);
    assert.equal(await toggleVisible(page), false);
  });
});

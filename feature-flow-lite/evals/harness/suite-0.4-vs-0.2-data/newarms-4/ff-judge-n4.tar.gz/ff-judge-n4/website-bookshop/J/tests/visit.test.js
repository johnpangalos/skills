'use strict';

// Criterion 5: opening hours, address, phone and email links on the visit page.

const { test, before, after } = require('node:test');
const assert = require('node:assert/strict');
const { startServer, launchBrowser, openPage } = require('./helpers/site');

const DAYS = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'];

let server;
let browser;
before(async () => {
  server = await startServer();
  browser = await launchBrowser();
});
after(async () => {
  await browser.close();
  await server.close();
});

test('opening hours table has a row with hours for every day of the week', async () => {
  const { page } = await openPage(browser, server.origin, 'visit.html');
  const rows = await page.$$eval('main table tbody tr', (trs) => trs.map((tr) => ({
    day: tr.querySelector('th[scope="row"]')?.textContent.trim() ?? '',
    hours: tr.querySelector('td')?.textContent.trim() ?? '',
  })));
  assert.deepEqual(rows.map((r) => r.day), DAYS);
  for (const row of rows) {
    assert.ok(row.hours.length > 0, `no hours for ${row.day}`);
  }
  const headers = await page.$$eval('main table thead th', (ths) => ths.map((th) => th.textContent.trim()));
  assert.deepEqual(headers, ['Day', 'Hours']);
});

test('address is in an address element and includes a full street address and postcode', async () => {
  const { page } = await openPage(browser, server.origin, 'visit.html');
  const address = await page.$eval('main address', (a) => a.textContent.replace(/\s+/g, ' ').trim());
  assert.match(address, /\d+ [A-Z][a-z]+ [A-Za-z]+/, `street address in "${address}"`);
  assert.match(address, /[A-Z]{1,2}\d[A-Z\d]? \d[A-Z]{2}/, `postcode in "${address}"`);
});

test('phone and email are real tel: and mailto: links', async () => {
  const { page } = await openPage(browser, server.origin, 'visit.html');
  const tel = await page.$eval('main a[href^="tel:"]', (a) => a.getAttribute('href'));
  assert.match(tel, /^tel:\+?[\d ]+$/, `tel href ${tel}`);
  const mailto = await page.$eval('main a[href^="mailto:"]', (a) => a.getAttribute('href'));
  assert.match(mailto, /^mailto:[^\s@]+@[^\s@]+\.[^\s@]+$/, `mailto href ${mailto}`);
});

test('visit page has a contact form', async () => {
  const { page } = await openPage(browser, server.origin, 'visit.html');
  assert.equal(await page.locator('main form#contact-form').count(), 1);
});

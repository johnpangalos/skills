// The catalogue. Every book listed on books.html comes from this one array.
const BOOKS = [
  {
    title: "The Clockmaker's Alibi",
    author: 'Helena Varley',
    genre: 'Mystery',
    description: "When a watchmaker's apprentice finds the church clock stopped at ten past midnight, she has until the bells ring again to prove her master was asleep in his bed.",
    price: 9.99,
  },
  {
    title: 'Salt Road Murders',
    author: 'Tobias Quaye',
    genre: 'Mystery',
    description: 'A coastal customs inspector, a missing ledger and three funerals in one winter. The tide keeps washing up evidence that nobody wanted found.',
    price: 10.5,
  },
  {
    title: 'A Quiet Ledger',
    author: 'Imogen Fenn',
    genre: 'Mystery',
    description: "A retired bookkeeper keeps her own accounts on the town's secrets, until a debt she never recorded turns up on her doorstep.",
    price: 8.99,
  },
  {
    title: 'The Orchard at Lower Wyke',
    author: 'Margit Oduya',
    genre: 'Literary Fiction',
    description: 'Three generations of one farming family argue over the apple trees they planted, and over the land the trees have quietly been growing on.',
    price: 12,
  },
  {
    title: 'Letters to a Vanished Sister',
    author: 'Daniel Ferreira-Lowe',
    genre: 'Literary Fiction',
    description: 'Forty years of unsent letters, found in a biscuit tin, begin to change how two brothers remember the year their sister left home.',
    price: 11.5,
  },
  {
    title: 'Low Tide Sundays',
    author: 'Ada Kettering',
    genre: 'Literary Fiction',
    description: 'A week in a seaside guesthouse where the guests are slowly and politely falling in love with the same stubborn lighthouse keeper.',
    price: 10,
  },
  {
    title: 'The Long Signal',
    author: 'Rafe Anand-Clarke',
    genre: 'Science Fiction',
    description: 'A radio operator on a deep-space relay receives a message that began before her ship even launched, and it asks her to answer.',
    price: 13.99,
  },
  {
    title: 'Orbit of Small Things',
    author: 'Noor Sallis',
    genre: 'Science Fiction',
    description: "On a hydroponic station circling a dim red star, a gardener and a mechanic try to keep one stubborn plant alive for the crew's birthday.",
    price: 11.99,
  },
  {
    title: 'Pip and the Lighthouse Cat',
    author: 'Bea Holloway',
    genre: 'Young Readers',
    description: 'Pip finds a ginger cat on the rocks below the old lighthouse, and the two of them set off to return it home across the bay.',
    price: 6.5,
  },
  {
    title: 'The Secret Library Under the Stairs',
    author: 'Osei Brandt',
    genre: 'Young Readers',
    description: 'Hidden behind a broom cupboard, a library waits for readers who can solve its riddles. Eleven-year-old Mae is the first to try.',
    price: 7.25,
  },
  {
    title: 'Field Notes for a Rainy Year',
    author: 'Ruth Calloway',
    genre: 'Poetry',
    description: 'Short poems written in hedgerows, bus shelters and kitchen doorways over twelve months of weather, with a little rain on every page.',
    price: 9,
  },
  {
    title: 'Small Hours, Open Windows',
    author: 'Lucia Marrow',
    genre: 'Poetry',
    description: "Night poems about insomnia, neighbours' radios and the first birds of the morning, arranged so the book can be read from either end.",
    price: 8.5,
  },
  {
    title: 'The Hartsbridge Mills, 1790 to 1880',
    author: 'Edwin Porrit',
    genre: 'History',
    description: 'An illustrated account of the textile mills that built our town, drawn from ledgers, letters and the memories of the families who worked the looms.',
    price: 18,
  },
  {
    title: 'Ink and Empire',
    author: 'Sanjay Okafor-Hale',
    genre: 'History',
    description: 'How printed words travelled along trade routes from port cities into inland towns, and how local presses shaped what people believed about faraway places.',
    price: 16.5,
  },
];

const ALL = 'all';

function slugify(name) {
  return name.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '');
}

const GENRES = [...new Set(BOOKS.map((book) => book.genre))]
  .sort((a, b) => a.localeCompare(b))
  .map((name) => ({ name, slug: slugify(name) }));

const buttons = document.getElementById('genre-buttons');
const list = document.getElementById('book-list');
const count = document.getElementById('result-count');

// Maps a raw ?genre= value to a known genre slug. Empty or unknown values mean All.
function genreFromQuery(raw) {
  const wanted = (raw || '').trim().toLowerCase();
  const genre = GENRES.find((option) => option.slug === wanted);
  return genre ? genre.slug : ALL;
}

function paragraph(className, text) {
  const p = document.createElement('p');
  p.className = className;
  p.textContent = text;
  return p;
}

function bookItem(book) {
  const item = document.createElement('li');
  const article = document.createElement('article');
  article.className = 'book';
  const title = document.createElement('h2');
  title.textContent = book.title;
  article.append(
    title,
    paragraph('book-author', `by ${book.author}`),
    paragraph('book-genre', book.genre),
    paragraph('book-description', book.description),
    paragraph('book-price', `£${book.price.toFixed(2)}`),
  );
  item.append(article);
  return item;
}

function renderButtons(active) {
  const options = [{ name: 'All', slug: ALL }, ...GENRES];
  buttons.replaceChildren(...options.map((option) => {
    const button = document.createElement('button');
    button.type = 'button';
    button.className = 'genre-button';
    button.textContent = option.name;
    button.dataset.genre = option.slug;
    button.setAttribute('aria-pressed', String(option.slug === active));
    return button;
  }));
}

function renderBooks(active) {
  const shown = active === ALL ? BOOKS : BOOKS.filter((book) => slugify(book.genre) === active);
  list.replaceChildren(...shown.map(bookItem));
  const genre = GENRES.find((option) => option.slug === active);
  const suffix = genre ? ` in ${genre.name}` : '';
  count.textContent = `Showing ${shown.length} of ${BOOKS.length} books${suffix}`;
}

function show(active) {
  renderButtons(active);
  renderBooks(active);
}

// The filter lives in the query string: ?genre=<slug>, removed for All.
function urlFor(active) {
  const url = new URL(window.location.href);
  if (active === ALL) {
    url.searchParams.delete('genre');
  } else {
    url.searchParams.set('genre', active);
  }
  return url;
}

function choose(active) {
  show(active);
  const url = urlFor(active);
  if (url.href !== window.location.href) {
    window.history.pushState(null, '', url);
  }
}

buttons.addEventListener('click', (event) => {
  const button = event.target.closest('button');
  if (button) {
    choose(button.dataset.genre);
  }
});

window.addEventListener('popstate', () => {
  show(genreFromQuery(new URLSearchParams(window.location.search).get('genre')));
});

show(genreFromQuery(new URLSearchParams(window.location.search).get('genre')));

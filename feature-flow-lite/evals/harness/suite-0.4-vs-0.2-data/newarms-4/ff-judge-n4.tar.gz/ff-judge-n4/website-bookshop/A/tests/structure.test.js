"use strict";

const { test, before, after } = require("node:test");
const assert = require("node:assert/strict");
const fs = require("node:fs");
const path = require("node:path");
const { PAGES, ROOT, startSite } = require("./helpers/server");

const NAV = [
  ["Home", "index.html"],
  ["Books", "books.html"],
  ["Events", "events.html"],
  ["Visit", "visit.html"],
];

let site;

before(async () => {
  site = await startSite();
});

after(async () => {
  await site.close();
});

for (const name of PAGES) {
  test(`${name} is served with status 200`, async () => {
    const response = await fetch(`${site.origin}/${name}`);
    assert.equal(response.status, 200);
  });
}

test("header nav links all four pages in order, with aria-current only on the current page", async () => {
  for (const current of PAGES) {
    await site.withPage(current, {}, async (page) => {
      const links = await page.$$eval("header nav a", (anchors) =>
        anchors.map((a) => [
          a.textContent.trim(),
          a.getAttribute("href"),
          a.getAttribute("aria-current"),
        ]),
      );
      assert.deepEqual(
        links.map(([label, href]) => [label, href]),
        NAV,
        `${current} nav links`,
      );
      for (const [label, href, ariaCurrent] of links) {
        const expected = href === current ? "page" : null;
        assert.equal(
          ariaCurrent,
          expected,
          `${current}: aria-current on ${label}`,
        );
      }
    });
  }
});

test("header and footer markup is identical on every page apart from aria-current", async () => {
  const markup = {};
  for (const name of PAGES) {
    await site.withPage(name, {}, async (page) => {
      const pair = await page.evaluate(() => [
        document.querySelector("header").outerHTML,
        document.querySelector("footer").outerHTML,
      ]);
      markup[name] = pair.map((html) =>
        html.replace(/ aria-current="page"/, ""),
      );
    });
  }
  for (const name of PAGES) {
    assert.deepEqual(
      markup[name],
      markup["index.html"],
      `${name} shared chrome`,
    );
  }
});

test("every internal link on every page resolves to a 200 response", async () => {
  for (const name of PAGES) {
    await site.withPage(name, {}, async (page) => {
      const hrefs = await page.$$eval("a[href]", (anchors) =>
        anchors.map((a) => a.getAttribute("href")),
      );
      const targets = new Set();
      for (const href of hrefs) {
        if (href.startsWith("#") || /^(mailto|tel):/.test(href)) continue;
        const url = new URL(href, page.url());
        assert.equal(
          url.origin,
          site.origin,
          `${name} links off-site: ${href}`,
        );
        targets.add(url.href);
      }
      assert.ok(targets.size > 0, `${name} has no internal links to check`);
      for (const target of targets) {
        const response = await fetch(target);
        assert.equal(response.status, 200, `${name} -> ${target}`);
      }
    });
  }
});

test("README explains the site and how to run and test it; package.json defines the test script", () => {
  const readme = fs.readFileSync(path.join(ROOT, "README.md"), "utf8");
  assert.match(readme, /npm test/);
  assert.match(readme, /localhost:\d+/);
  const pkg = JSON.parse(
    fs.readFileSync(path.join(ROOT, "package.json"), "utf8"),
  );
  assert.match(pkg.scripts.test, /node --test "tests\/\*\*\/\*\.test\.js"/);
  assert.match(pkg.scripts.test, /NODE_PATH=\$\(npm root -g\)/);
  assert.deepEqual(Object.keys(pkg.devDependencies || {}), []);
});

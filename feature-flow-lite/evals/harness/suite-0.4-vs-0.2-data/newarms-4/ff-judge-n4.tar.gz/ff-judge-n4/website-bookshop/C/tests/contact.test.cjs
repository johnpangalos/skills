'use strict';

// Contact form on the visit page (criterion 10): labels, validation, errors, demo status and hostile input.

const { test, before, after } = require('node:test');
const assert = require('node:assert/strict');
const { chromium } = require('playwright');
const { startServer } = require('./server.cjs');

const VALID = { name: 'Ada Lovelace', email: 'reader@example.com', message: 'Do you hold book groups on Thursdays?' };
const MESSAGE_LIMIT = 2000;

let server;
let browser;

before(async () => {
  server = await startServer();
  browser = await chromium.launch();
});

after(async () => {
  await browser.close();
  await server.close();
});

async function openContact(width = 1280) {
  const context = await browser.newContext({ viewport: { width, height: 900 } });
  const page = await context.newPage();
  const errors = [];
  page.on('pageerror', (err) => errors.push(err.message));
  page.on('console', (msg) => {
    if (msg.type() === 'error') errors.push(msg.text());
  });
  await page.goto(`${server.origin}/visit.html`);
  await page.evaluate(() => {
    window.__marker = 'still here';
  });
  return { context, page, errors };
}

async function fillForm(page, values) {
  await page.fill('#name', values.name);
  await page.fill('#email', values.email);
  await page.fill('#message', values.message);
}

async function submit(page) {
  await page.click('#contact-form button[type="submit"]');
}

// Returns the visible error text for a field, or '' when no error is shown.
async function visibleError(page, field) {
  return page.$eval(`#${field}-error`, (el) => (el.hidden ? '' : el.textContent.trim()));
}

async function invalidState(page, field) {
  return page.$eval(`#${field}`, (el) => ({
    invalid: el.getAttribute('aria-invalid'),
    describedBy: el.getAttribute('aria-describedby'),
  }));
}

test('criterion 10: each field has a visible label, required fields are marked, and the form is novalidate', async () => {
  const { context, page } = await openContact();
  try {
    for (const field of ['name', 'email', 'message']) {
      const label = await page.$eval(`label[for="${field}"]`, (el) => el.textContent.trim());
      assert.match(label, /required/i, `${field} label should mark it required`);
      assert.equal(await page.$eval(`#${field}`, (el) => el.required), true, `${field} must have required`);
    }
    assert.ok(await page.$eval('label[for="subject"]', (el) => el.textContent.trim().length > 0));
    assert.ok(await page.$eval('#subject', (el) => el.tagName === 'SELECT'));
    assert.equal(await page.$eval('#contact-form', (el) => el.hasAttribute('novalidate')), true);
  } finally {
    await context.close();
  }
});

test('criterion 10: whitespace-only name and message are invalid and focus goes to the first invalid field', async () => {
  const { context, page } = await openContact();
  try {
    await fillForm(page, { name: '   ', email: VALID.email, message: '   ' });
    await submit(page);
    assert.equal(await page.evaluate(() => document.activeElement.id), 'name');
    assert.deepEqual(await invalidState(page, 'name'), { invalid: 'true', describedBy: 'name-error' });
    assert.equal(await invalidState(page, 'message').then((s) => s.invalid), 'true');
    assert.ok((await visibleError(page, 'name')).length > 0, 'name error text');
    assert.ok((await visibleError(page, 'message')).length > 0, 'message error text');
    assert.equal(await invalidState(page, 'email').then((s) => s.invalid), null);
  } finally {
    await context.close();
  }
});

for (const bad of ['a', 'a@', '@b.com', 'a b@c.com']) {
  test(`criterion 10: hostile email "${bad}" is rejected with an error linked to the field`, async () => {
    const { context, page } = await openContact();
    try {
      await fillForm(page, { ...VALID, email: bad });
      await submit(page);
      assert.equal(await page.evaluate(() => document.activeElement.id), 'email');
      assert.deepEqual(await invalidState(page, 'email'), { invalid: 'true', describedBy: 'email-error' });
      assert.ok((await visibleError(page, 'email')).length > 0);
      assert.equal(await page.locator('#form-status p').count(), 0, 'an invalid form must not show the demo status');
    } finally {
      await context.close();
    }
  });
}

test('criterion 10: email "reader@example.com" is accepted', async () => {
  const { context, page } = await openContact();
  try {
    await fillForm(page, VALID);
    await submit(page);
    assert.equal(await invalidState(page, 'email').then((s) => s.invalid), null);
    assert.equal(await visibleError(page, 'email'), '');
  } finally {
    await context.close();
  }
});

test('criterion 10: errors clear once the field is corrected', async () => {
  const { context, page } = await openContact();
  try {
    await fillForm(page, { ...VALID, name: '' });
    await submit(page);
    assert.ok((await visibleError(page, 'name')).length > 0);
    await page.fill('#name', 'Ada Lovelace');
    assert.equal(await visibleError(page, 'name'), '');
    assert.equal(await invalidState(page, 'name').then((s) => s.invalid), null);
    assert.equal(await invalidState(page, 'name').then((s) => s.describedBy), null);
  } finally {
    await context.close();
  }
});

test('criterion 10: a valid submit does not navigate, reload or claim the message was sent', async () => {
  const { context, page, errors } = await openContact();
  try {
    const before = page.url();
    await fillForm(page, VALID);
    await submit(page);
    const status = page.locator('[role="status"] p');
    await status.waitFor();
    const text = await status.textContent();
    assert.match(text, /demo/i);
    assert.match(text, /not sent/i);
    assert.equal(
      await page.$eval('[role="status"] a', (a) => a.getAttribute('href')),
      'mailto:hello@marginalia.example',
    );
    assert.equal(page.url(), before);
    assert.equal(await page.evaluate(() => window.__marker), 'still here', 'page must not reload');
    assert.deepEqual(errors, []);
  } finally {
    await context.close();
  }
});

test('criterion 10: a 10,000 character message is capped or rejected with a clear message and no overflow at 360px', async () => {
  const { context, page } = await openContact(360);
  try {
    await fillForm(page, { ...VALID, message: 'a'.repeat(10000) });
    await submit(page);
    const value = await page.$eval('#message', (el) => el.value);
    const error = await visibleError(page, 'message');
    const capped = value.length <= MESSAGE_LIMIT;
    assert.ok(
      capped || error === `Please keep your message to ${MESSAGE_LIMIT} characters or fewer.`,
      `message length ${value.length} neither capped nor rejected (error: "${error}")`,
    );
    // A capped message is valid and gets the demo notice; a rejected one gets no notice.
    assert.equal(await page.locator('#form-status p').count(), capped ? 1 : 0);
    const counter = await page.textContent('#message-count');
    assert.match(counter, new RegExp(`/ ${MESSAGE_LIMIT}`));
    const { scroll, client } = await page.evaluate(() => ({
      scroll: document.documentElement.scrollWidth,
      client: document.documentElement.clientWidth,
    }));
    assert.ok(scroll <= client, `layout overflows: ${scroll} > ${client}`);
  } finally {
    await context.close();
  }
});

test('criterion 10: pressing submit twice on an invalid form duplicates no error messages', async () => {
  const { context, page } = await openContact();
  try {
    await fillForm(page, { name: '', email: '', message: '' });
    await submit(page);
    await submit(page);
    const errorCount = await page.$$eval('#contact-form .field-error', (els) => els.length);
    assert.equal(errorCount, 3);
    const texts = await page.$$eval('#contact-form .field-error', (els) => els.map((e) => e.textContent.trim()));
    assert.equal(new Set(texts).size, 3, 'each field has its own message');
  } finally {
    await context.close();
  }
});

test('criterion 10: pressing submit twice on a valid form shows only one status message', async () => {
  const { context, page } = await openContact();
  try {
    await fillForm(page, VALID);
    await submit(page);
    await submit(page);
    assert.equal(await page.locator('[role="status"] p').count(), 1);
  } finally {
    await context.close();
  }
});

test('criterion 10: a demo note with the real email is visible above the form before any submit', async () => {
  const { context, page } = await openContact();
  try {
    const note = page.locator('#demo-note');
    assert.equal(await note.isVisible(), true);
    assert.match(await note.textContent(), /demo/i);
    assert.match(await note.textContent(), /doesn['’]t send messages/);
    assert.equal(await note.locator('a[href="mailto:hello@marginalia.example"]').count(), 1);
    const noteComesFirst = await page.$eval('#demo-note', (el) => {
      const form = document.getElementById('contact-form');
      return Boolean(el.compareDocumentPosition(form) & Node.DOCUMENT_POSITION_FOLLOWING);
    });
    assert.equal(noteComesFirst, true, 'the note sits before the form');
  } finally {
    await context.close();
  }
});

test('criterion 10: the submit button no longer promises to send the message', async () => {
  const { context, page } = await openContact();
  try {
    const label = (await page.textContent('#contact-form button[type="submit"]')).trim();
    assert.notEqual(label, 'Send message');
    assert.match(label, /check|demo/i);
  } finally {
    await context.close();
  }
});

test('criterion 10: the message counter is always described by the message field, with its error too while one shows', async () => {
  const { context, page } = await openContact();
  try {
    assert.equal((await invalidState(page, 'message')).describedBy, 'message-count');
    await fillForm(page, { ...VALID, message: '   ' });
    await submit(page);
    const whileInvalid = (await invalidState(page, 'message')).describedBy.split(' ');
    assert.deepEqual(whileInvalid.sort(), ['message-count', 'message-error']);
    await page.fill('#message', VALID.message);
    assert.equal((await invalidState(page, 'message')).describedBy, 'message-count');
  } finally {
    await context.close();
  }
});

test('criterion 10: with JavaScript off the form is method="post" and nothing lands in the URL', async () => {
  const context = await browser.newContext({ viewport: { width: 1280, height: 900 }, javaScriptEnabled: false });
  const page = await context.newPage();
  try {
    await page.goto(`${server.origin}/visit.html`);
    assert.equal(await page.getAttribute('#contact-form', 'method'), 'post');
    await fillForm(page, VALID);
    await Promise.all([page.waitForNavigation(), submit(page)]);
    assert.equal(new URL(page.url()).search, '');
    assert.equal(new URL(page.url()).pathname, '/visit.html');
  } finally {
    await context.close();
  }
});

test('criterion 9: the hours section has an h2 that also names the table, with no duplicate visible caption', async () => {
  const { context, page } = await openContact();
  try {
    assert.equal(await page.getByRole('heading', { level: 2, name: 'Opening hours', exact: true }).count(), 1);
    assert.equal(await page.locator('.hours-table caption').count(), 0);
    assert.equal(await page.getByRole('table', { name: 'Opening hours', exact: true }).count(), 1);
  } finally {
    await context.close();
  }
});

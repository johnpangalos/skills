'use strict';

// Visit page (criterion 9): opening hours, address, contact links and access information.

const { test, before, after } = require('node:test');
const assert = require('node:assert/strict');
const { chromium } = require('playwright');
const { startServer } = require('./server.cjs');

const DAYS = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'];

let server;
let browser;

before(async () => {
  server = await startServer();
  browser = await chromium.launch();
});

after(async () => {
  await browser.close();
  await server.close();
});

async function openVisit() {
  const context = await browser.newContext({ viewport: { width: 1280, height: 900 } });
  const page = await context.newPage();
  await page.goto(`${server.origin}/visit.html`);
  return { context, page };
}

test('criterion 9: opening hours table has a labelled row with hours for every day of the week', async () => {
  const { context, page } = await openVisit();
  try {
    assert.equal(await page.getByRole('table', { name: 'Opening hours', exact: true }).count(), 1);
    const body = await page.$$eval('.hours-table tbody tr', (els) =>
      els.map((el) => ({
        day: el.querySelector('th[scope="row"]')?.textContent.trim() || '',
        hours: el.querySelector('td')?.textContent.trim() || '',
      })),
    );
    assert.deepEqual(
      body.map((r) => r.day),
      DAYS,
    );
    for (const row of body) {
      assert.match(
        row.hours,
        /\d{1,2}(:\d{2})?\s?(am|pm)\s?(–|-)\s?\d{1,2}(:\d{2})?\s?(am|pm)/,
        `${row.day} hours: ${row.hours}`,
      );
    }
  } finally {
    await context.close();
  }
});

test('criterion 9: full address in an address element, with tel and mailto links', async () => {
  const { context, page } = await openVisit();
  try {
    const address = await page.$eval('main address', (el) => el.textContent.replace(/\s+/g, ' ').trim());
    assert.match(address, /27 Quill Street/);
    assert.match(address, /Ashfield Vale/);
    assert.match(address, /[A-Z]{1,2}\d[A-Z\d]? \d[A-Z]{2}/, 'address should include a postcode');
    const tel = await page.$eval('main a[href^="tel:"]', (el) => el.getAttribute('href'));
    assert.match(tel, /^tel:\+?[\d ]+$/);
    const mail = await page.$eval('main a[href^="mailto:"]', (el) => el.getAttribute('href'));
    assert.equal(mail, 'mailto:hello@marginalia.example');
  } finally {
    await context.close();
  }
});

test('criterion 9: directions and accessibility information including step-free access', async () => {
  const { context, page } = await openVisit();
  try {
    const headings = await page.$$eval('main h2', (els) => els.map((h) => h.textContent.trim()));
    assert.ok(headings.includes('Getting here'), 'directions section');
    assert.ok(headings.includes('Accessibility'), 'accessibility section');
    const access = await page.$eval('#accessibility', (el) => el.textContent);
    assert.match(access, /step-free/i);
    const directions = await page.$eval('#getting-here', (el) => el.textContent);
    assert.match(directions, /bus|train|car|parking/i);
  } finally {
    await context.close();
  }
});

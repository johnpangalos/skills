'use strict';

const { describe, it, before, after } = require('node:test');
const assert = require('node:assert/strict');
const { startSite, openPage } = require('./helpers');

const DAYS = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'];
const FIELDS = ['name', 'email', 'topic', 'message'];
const DEMO_EMAIL = 'hello@marginalia-books.example';
const DEMO_PHONE = '020 7946 0123';

async function submit(page) {
  await page.getByRole('button', { name: 'Send message', exact: true }).click();
}

async function fillValid(page) {
  await page.fill('#name', 'Jordan Reed');
  await page.fill('#email', 'jordan@example.co.uk');
  await page.selectOption('#topic', 'general');
  await page.fill('#message', 'Do you stock large print editions of the poetry titles?');
}

async function fieldState(page, id) {
  return page.evaluate((fieldId) => {
    const input = document.getElementById(fieldId);
    const errorId = `${fieldId}-error`;
    const error = document.getElementById(errorId);
    return {
      invalid: input.getAttribute('aria-invalid'),
      describedBy: (input.getAttribute('aria-describedby') || '').split(/\s+/).includes(errorId),
      errorText: error ? error.textContent.trim() : null,
    };
  }, id);
}

describe('visit page content (criterion 8)', () => {
  let site;
  before(async () => { site = await startSite(); });
  after(async () => { await site.close(); });

  it('shows opening hours for every day of the week in a table with row and column headers', async () => {
    const page = await openPage(site, 'visit.html');
    const tables = await page.$$eval('table', (found) => found.map((table) => ({
      caption: table.caption ? table.caption.textContent.trim() : '',
      columnHeaders: [...table.querySelectorAll('thead th')].map((th) => th.getAttribute('scope')),
      rows: [...table.querySelectorAll('tbody tr')].map((tr) => ({
        scope: tr.querySelector('th')?.getAttribute('scope') ?? null,
        day: tr.querySelector('th')?.textContent.trim() ?? '',
        hours: tr.querySelector('td')?.textContent.trim() ?? '',
      })),
    })));
    assert.equal(tables.length, 1, 'expected one hours table');
    const [table] = tables;
    assert.ok(table.caption.length > 0, 'hours table has no caption');
    assert.ok(table.columnHeaders.length >= 2 && table.columnHeaders.every((scope) => scope === 'col'), 'column headers lack scope');
    assert.deepEqual(table.rows.map((row) => row.day), DAYS);
    assert.ok(table.rows.every((row) => row.scope === 'row' && /\d/.test(row.hours)), 'a row lacks a row header or hours');
  });

  it('gives the postal address in an address element', async () => {
    const page = await openPage(site, 'visit.html');
    const text = await page.locator('address').first().textContent();
    assert.match(text, /Quill Lane/);
    assert.match(text, /HB4 2LN/);
  });

  it('links the phone number with tel: and the email with mailto:', async () => {
    const page = await openPage(site, 'visit.html');
    const tel = await page.$$eval('a[href^="tel:"]', (links) => links.map((a) => a.getAttribute('href')));
    const mailto = await page.$$eval('a[href^="mailto:"]', (links) => links.map((a) => a.getAttribute('href')));
    assert.ok(tel.length >= 1 && /^tel:\+[\d]+$/.test(tel[0]), `tel links: ${tel}`);
    assert.ok(mailto.length >= 1 && /^mailto:[^@\s]+@[^@\s]+$/.test(mailto[0]), `mailto links: ${mailto}`);
  });

  it('describes directions and step-free access, with no embedded maps or iframes', async () => {
    const page = await openPage(site, 'visit.html');
    const text = await page.locator('main').textContent();
    assert.match(text, /step-free/i);
    assert.match(text, /bus|train|car|parking/i);
    assert.equal(await page.locator('iframe, embed, object').count(), 0);
  });
});

describe('contact form (criteria 9 and 10)', () => {
  let site;
  before(async () => { site = await startSite(); });
  after(async () => { await site.close(); });

  it('labels each field and marks required fields in text, with novalidate on the form', async () => {
    const page = await openPage(site, 'visit.html');
    const fields = await page.evaluate((ids) => ids.map((id) => {
      const label = document.querySelector(`label[for="${id}"]`);
      const control = document.getElementById(id);
      return {
        id,
        label: label ? label.textContent.trim() : '',
        labelVisible: label ? label.getClientRects().length > 0 : false,
        tag: control ? control.tagName : '',
      };
    }), FIELDS);
    for (const field of fields) {
      assert.ok(field.label, `${field.id} has no label for=`);
      assert.match(field.label, /required/i, `${field.id} label does not say required`);
      assert.equal(field.labelVisible, true, `${field.id} label is hidden`);
    }
    assert.deepEqual(fields.map((field) => field.tag), ['INPUT', 'INPUT', 'SELECT', 'TEXTAREA']);
    assert.equal(await page.getAttribute('#contact-form', 'novalidate'), '');
  });

  it('flags every empty required field, ties each error to its field and moves focus to the first', async () => {
    const page = await openPage(site, 'visit.html');
    await submit(page);
    for (const id of FIELDS) {
      const state = await fieldState(page, id);
      assert.equal(state.invalid, 'true', `${id} is not aria-invalid`);
      assert.equal(state.describedBy, true, `${id} error is not in aria-describedby`);
      assert.ok(state.errorText, `${id} has no error text`);
    }
    assert.equal(await page.evaluate(() => document.activeElement.id), 'name');
    assert.ok((await page.textContent('#form-summary')).trim().length > 0, 'no error summary');
  });

  it('treats a whitespace-only name or message as empty', async () => {
    const page = await openPage(site, 'visit.html');
    await fillValid(page);
    await page.fill('#name', '   ');
    await page.fill('#message', '\n   \t');
    await submit(page);
    assert.equal((await fieldState(page, 'name')).invalid, 'true');
    assert.equal((await fieldState(page, 'message')).invalid, 'true');
    assert.equal((await page.textContent('#form-status')).trim(), '');
  });

  it('rejects the malformed emails a@b, foo@, "foo bar@x.com", a@b.c. and a@b..c and accepts jo@example.co.uk', async () => {
    const page = await openPage(site, 'visit.html');
    for (const bad of ['a@b', 'foo@', 'foo bar@x.com', 'a@b.c.', 'a@b..c']) {
      await page.fill('#email', bad);
      await submit(page);
      const state = await fieldState(page, 'email');
      assert.equal(state.invalid, 'true', `${bad} was accepted`);
      assert.ok(state.errorText, `${bad} has no error text`);
    }
    await page.fill('#email', 'jo@example.co.uk');
    await submit(page);
    const valid = await fieldState(page, 'email');
    assert.equal(valid.invalid, 'false', 'jo@example.co.uk was rejected');
    assert.equal(valid.errorText, '');
  });

  it('rejects a 5000-character message with a stated 2000-character limit and sends nothing', async () => {
    const page = await openPage(site, 'visit.html');
    await fillValid(page);
    await page.fill('#message', 'a'.repeat(5000));
    await submit(page);
    const state = await fieldState(page, 'message');
    assert.equal(state.invalid, 'true');
    assert.match(state.errorText, /2000/);
    assert.equal((await page.textContent('#form-status')).trim(), '');
  });

  it('clears each error once its field is corrected, and the summary once all are fixed', async () => {
    const page = await openPage(site, 'visit.html');
    await submit(page);
    await page.fill('#name', 'Jordan Reed');
    const name = await fieldState(page, 'name');
    assert.equal(name.invalid, 'false');
    assert.equal(name.errorText, '');
    await fillValid(page);
    for (const id of FIELDS) {
      assert.equal((await fieldState(page, id)).invalid, 'false', `${id} still invalid`);
    }
    assert.equal((await page.textContent('#form-summary')).trim(), '');
  });

  it('does not navigate or send a request on a valid submit, and says plainly the message was not sent', async () => {
    const page = await openPage(site, 'visit.html');
    await fillValid(page);
    const urlBefore = page.url();
    const requests = [];
    page.on('request', (request) => requests.push(request.url()));
    await submit(page);
    await page.waitForFunction(() => document.getElementById('form-status').textContent.trim() !== '');
    assert.equal(page.url(), urlBefore, 'the form navigated');
    assert.deepEqual(requests, [], 'the form made a request');
    assert.equal(await page.getAttribute('#form-status', 'role'), 'status');
    const text = (await page.textContent('#form-status')).trim();
    assert.match(text, /demo/i);
    assert.match(text, /NOT sent/);
    assert.doesNotMatch(text, /been sent|was sent|successfully sent/i);
    assert.ok(text.includes(DEMO_EMAIL), 'status does not suggest emailing');
    assert.ok(text.includes(DEMO_PHONE), 'status does not suggest phoning');
  });

  it('does not duplicate the status message when the form is submitted twice', async () => {
    const page = await openPage(site, 'visit.html');
    await fillValid(page);
    await submit(page);
    await submit(page);
    assert.equal(await page.locator('[role="status"]').count(), 1);
    const text = await page.textContent('main');
    assert.equal(text.split('NOT sent').length - 1, 1, 'status message repeated');
  });
});

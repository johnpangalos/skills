/* Home page: staff picks and the next two upcoming events, both from SITE_DATA. */
(function () {
  'use strict';

  const picks = SITE_DATA.books.filter(function (book) {
    return book.staffPick;
  }).slice(0, 3);
  const pickList = document.getElementById('staff-picks');
  picks.forEach(function (book) {
    const item = document.createElement('li');
    item.appendChild(Marginalia.createBookCard(book));
    pickList.appendChild(item);
  });

  const events = Marginalia.upcomingEvents().slice(0, 2);
  const eventList = document.getElementById('home-events');
  events.forEach(function (event) {
    eventList.appendChild(Marginalia.createEventItem(event));
  });
  document.getElementById('home-events-empty').hidden = events.length > 0;
})();

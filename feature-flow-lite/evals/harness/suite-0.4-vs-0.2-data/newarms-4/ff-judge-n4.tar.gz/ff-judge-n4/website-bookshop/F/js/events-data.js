// Upcoming events for events.html, in date order. Every event is fictional.
export const events = [
  {
    date: "2026-12-05",
    dateLabel: "Saturday, 5 December 2026",
    time: "6:30 pm to 8:00 pm",
    title: "Winter Reading Circle",
    description:
      "Our monthly book club meets by the fireplace this month to talk about The Glass Orchard Murders. New members are welcome, and the mulled cider is free.",
  },
  {
    date: "2026-12-12",
    dateLabel: "Saturday, 12 December 2026",
    time: "11:00 am to 11:45 am",
    title: "Children’s Storytime",
    description:
      "Picture books, songs and a short craft table for ages three to seven. Grown-ups stay with their children, and the reading corner is open afterwards.",
  },
  {
    date: "2026-12-19",
    dateLabel: "Saturday, 19 December 2026",
    time: "7:00 pm to 9:00 pm",
    title: "Solstice Poetry Open Mic",
    description:
      "Longest night, shortest poems. Each reader gets three minutes. Sign up at the counter when you arrive, or send us a note in advance if you would like a slot.",
  },
  {
    date: "2027-01-16",
    dateLabel: "Saturday, 16 January 2027",
    time: "7:00 pm to 8:30 pm",
    title: "An Evening with Imogen Strand",
    description:
      "The author of The Quiet Tenant reads from her next novel and takes questions from the floor. Signed copies of her earlier books will be on the table.",
  },
  {
    date: "2027-02-13",
    dateLabel: "Saturday, 13 February 2027",
    time: "2:00 pm to 4:30 pm",
    title: "Bookbinding Workshop",
    description:
      "Make a simple long-stitch notebook with paper, thread and a bone folder, all provided. Places are limited to twelve, so book early.",
  },
  {
    date: "2027-03-06",
    dateLabel: "Saturday, 6 March 2027",
    time: "10:00 am to 12:00 pm",
    title: "Spring Catalogue Preview",
    description:
      "A first look at the spring list, with tea and biscuits and a chance to pre-order before the titles go on general sale.",
  },
];

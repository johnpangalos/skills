// Catalogue page: genre filter, live result count, and the genre kept in the URL query.
(function () {
  const select = document.getElementById('genre');
  const list = document.getElementById('book-list');
  const empty = document.getElementById('no-books');
  const count = document.getElementById('result-count');
  const genres = [...new Set(BOOKS.map((book) => book.genre))].sort();

  // Case-insensitive, treats spaces and hyphens alike: "science-fiction" matches "Science Fiction".
  function normalize(text) {
    return text.trim().toLowerCase().replace(/[\s-]+/g, ' ');
  }

  function slugify(text) {
    return text.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '');
  }

  // Returns the first ?genre= value as a genre name from the data, or '' (All) when nothing matches.
  function genreFromQuery(search) {
    const raw = new URLSearchParams(search).get('genre');
    if (raw === null) return '';
    const key = normalize(raw);
    const match = genres.find((genre) => normalize(genre) === key);
    return match || '';
  }

  function bookCard(book) {
    const item = document.createElement('li');
    item.className = 'book';

    const cover = document.createElement('div');
    cover.className = 'cover';
    cover.setAttribute('aria-hidden', 'true');
    cover.style.setProperty('--cover', book.cover);
    cover.textContent = book.title;

    const title = document.createElement('h2');
    title.textContent = book.title;

    const meta = document.createElement('p');
    meta.className = 'book-meta';
    meta.textContent = `${book.author} · ${book.genre}`;

    const price = document.createElement('p');
    price.className = 'book-price';
    price.textContent = `£${book.price.toFixed(2)}`;

    const description = document.createElement('p');
    description.textContent = book.description;

    item.append(cover, title, meta, price, description);
    return item;
  }

  function show(genre) {
    select.value = genre;
    const shown = genre ? BOOKS.filter((book) => book.genre === genre) : BOOKS;
    list.replaceChildren(...shown.map(bookCard));
    empty.hidden = shown.length > 0;
    count.textContent = `Showing ${shown.length} of ${BOOKS.length} books${genre ? ' in ' + genre : ''}`;
  }

  select.append(new Option('All', ''), ...genres.map((genre) => new Option(genre, genre)));

  select.addEventListener('change', function () {
    const url = select.value ? `?genre=${slugify(select.value)}` : location.pathname;
    history.replaceState(null, '', url);
    show(select.value);
  });

  window.addEventListener('popstate', function () {
    show(genreFromQuery(location.search));
  });

  show(genreFromQuery(location.search));
})();

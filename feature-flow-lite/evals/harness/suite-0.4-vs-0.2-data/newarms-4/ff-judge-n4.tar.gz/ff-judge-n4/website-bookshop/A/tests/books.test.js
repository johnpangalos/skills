"use strict";

const { test, before, after } = require("node:test");
const assert = require("node:assert/strict");
const { startSite } = require("./helpers/server");

let site;

before(async () => {
  site = await startSite();
});

after(async () => {
  await site.close();
});

const visibleGenres = (page) =>
  page.$$eval(".book-card:not([hidden])", (cards) =>
    cards.map((card) => card.dataset.genre),
  );
const pressedLabels = (page) =>
  page.$$eval('.genre-filter button[aria-pressed="true"]', (buttons) =>
    buttons.map((b) => b.textContent.trim()),
  );
const statusText = (page) => page.textContent("#result-count");

test("catalogue has at least 12 books across 5 genres, each with all the card fields and a CSS cover", async () => {
  await site.withPage("books.html", {}, async (page) => {
    const report = await page.evaluate(() => {
      const cards = Array.from(document.querySelectorAll(".book-card"));
      const problems = [];
      for (const card of cards) {
        for (const selector of [
          "h2",
          ".book-card__author",
          ".book-card__genre",
          ".book-card__price",
          ".book-card__blurb",
          ".cover",
        ]) {
          if (
            !card.querySelector(selector) ||
            !card.querySelector(selector).textContent.trim()
          ) {
            if (selector !== ".cover")
              problems.push(`${card.dataset.genre}: missing ${selector}`);
          }
        }
        if (!card.querySelector(".cover")) problems.push("missing cover");
        if (
          !/^£\d+\.\d{2}$/.test(
            card.querySelector(".book-card__price").textContent.trim(),
          )
        ) {
          problems.push(
            `bad price: ${card.querySelector(".book-card__price").textContent}`,
          );
        }
      }
      return {
        count: cards.length,
        genres: new Set(cards.map((card) => card.dataset.genre)).size,
        images: document.querySelectorAll("img").length,
        problems,
      };
    });
    assert.ok(report.count >= 12, `only ${report.count} books`);
    assert.ok(report.genres >= 5, `only ${report.genres} genres`);
    assert.equal(
      report.images,
      0,
      "covers must not be remote or raster images",
    );
    assert.deepEqual(report.problems, []);
  });
});

test('selecting Mystery hides other books and announces "Showing 3 of 12 books — Mystery"', async () => {
  await site.withPage("books.html", {}, async (page) => {
    await page.getByRole("button", { name: "Mystery", exact: true }).click();
    assert.deepEqual(await visibleGenres(page), [
      "Mystery",
      "Mystery",
      "Mystery",
    ]);
    assert.equal(await statusText(page), "Showing 3 of 12 books — Mystery");
    assert.deepEqual(await pressedLabels(page), ["Mystery"]);
  });
});

test("the result count is a polite live region", async () => {
  await site.withPage("books.html", {}, async (page) => {
    const live = await page.getAttribute("#result-count", "aria-live");
    const role = await page.getAttribute("#result-count", "role");
    assert.equal(live, "polite");
    assert.equal(role, "status");
  });
});

test("the genre filter is a labelled group of toggle buttons", async () => {
  await site.withPage("books.html", {}, async (page) => {
    const group = await page.getByRole("group", { name: /genre/i }).count();
    assert.equal(group, 1);
    const buttons = await page.$$eval(".genre-filter button", (els) =>
      els.map((b) => b.textContent.trim()),
    );
    assert.equal(buttons[0], "All");
    for (const genre of [
      "Mystery",
      "Literary Fiction",
      "Science Fiction",
      "Poetry",
      "Nature Writing",
      "Food & Drink",
    ]) {
      assert.ok(buttons.includes(genre), `missing filter ${genre}`);
    }
  });
});

test("selecting a filter writes ?genre= into the URL and choosing All removes it", async () => {
  await site.withPage("books.html", {}, async (page) => {
    await page.getByRole("button", { name: "Mystery", exact: true }).click();
    assert.equal(new URL(page.url()).searchParams.get("genre"), "Mystery");
    await page.getByRole("button", { name: "All", exact: true }).click();
    assert.equal(new URL(page.url()).searchParams.has("genre"), false);
  });
});

test("?genre= with an empty value shows every book with All selected", async () => {
  await site.withPage("books.html?genre=", {}, async (page) => {
    assert.equal((await visibleGenres(page)).length, 12);
    assert.deepEqual(await pressedLabels(page), ["All"]);
  });
});

test("?genre=nonsense shows every book with All selected", async () => {
  await site.withPage("books.html?genre=nonsense", {}, async (page) => {
    assert.equal((await visibleGenres(page)).length, 12);
    assert.deepEqual(await pressedLabels(page), ["All"]);
    assert.equal(await statusText(page), "Showing 12 of 12 books — All genres");
  });
});

test("?genre=<script> is treated as plain text: shows all, runs nothing, injects nothing", async () => {
  const dialogs = [];
  const payload = encodeURIComponent("<script>alert(1)</script>");
  await site.withPage(
    `books.html?genre=${payload}`,
    {
      beforeGoto: (page) =>
        page.on("dialog", (dialog) => dialogs.push(dialog.message())),
    },
    async (page) => {
      assert.equal((await visibleGenres(page)).length, 12);
      assert.deepEqual(await pressedLabels(page), ["All"]);
      assert.equal((await page.content()).includes("alert(1)"), false);
    },
  );
  assert.deepEqual(dialogs, []);
});

test("?genre=MYSTERY matches case-insensitively", async () => {
  await site.withPage("books.html?genre=MYSTERY", {}, async (page) => {
    assert.deepEqual(await visibleGenres(page), [
      "Mystery",
      "Mystery",
      "Mystery",
    ]);
    assert.deepEqual(await pressedLabels(page), ["Mystery"]);
  });
});

test("?genre=Science%20Fiction (spaces) filters to Science Fiction", async () => {
  await site.withPage(
    "books.html?genre=Science%20Fiction",
    {},
    async (page) => {
      assert.deepEqual(await visibleGenres(page), [
        "Science Fiction",
        "Science Fiction",
      ]);
      assert.deepEqual(await pressedLabels(page), ["Science Fiction"]);
    },
  );
});

test("?genre=Food+%26+Drink (ampersand) filters to Food & Drink", async () => {
  await site.withPage("books.html?genre=Food+%26+Drink", {}, async (page) => {
    assert.deepEqual(await visibleGenres(page), ["Food & Drink"]);
    assert.deepEqual(await pressedLabels(page), ["Food & Drink"]);
  });
});

test("a genre with spaces and an ampersand survives a select, reload round trip", async () => {
  await site.withPage("books.html", {}, async (page) => {
    await page
      .getByRole("button", { name: "Food & Drink", exact: true })
      .click();
    assert.equal(new URL(page.url()).searchParams.get("genre"), "Food & Drink");
    await page.reload();
    assert.deepEqual(await visibleGenres(page), ["Food & Drink"]);
    assert.deepEqual(await pressedLabels(page), ["Food & Drink"]);
  });
});

test("back and forward restore the previous filter without reloading the page", async () => {
  await site.withPage("books.html", {}, async (page) => {
    await page.getByRole("button", { name: "Mystery", exact: true }).click();
    await page.getByRole("button", { name: "Poetry", exact: true }).click();
    await page.evaluate(() => {
      window.marker = "same-document";
    });

    await page.goBack();
    assert.equal(new URL(page.url()).searchParams.get("genre"), "Mystery");
    assert.deepEqual(await pressedLabels(page), ["Mystery"]);
    assert.equal((await visibleGenres(page)).length, 3);

    await page.goBack();
    assert.equal(new URL(page.url()).searchParams.has("genre"), false);
    assert.equal((await visibleGenres(page)).length, 12);
    assert.deepEqual(await pressedLabels(page), ["All"]);

    await page.goForward();
    assert.deepEqual(await pressedLabels(page), ["Mystery"]);
    assert.equal(await page.evaluate(() => window.marker), "same-document");
  });
});

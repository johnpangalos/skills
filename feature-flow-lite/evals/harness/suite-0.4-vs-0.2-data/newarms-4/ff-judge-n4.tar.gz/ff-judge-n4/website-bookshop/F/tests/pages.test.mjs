import { describe, it, before, after } from "node:test";
import assert from "node:assert/strict";
import { startServer } from "./server.mjs";
import { PAGES, launchBrowser, openTracked } from "./helpers.mjs";

const NAV = [
  { href: "index.html", label: "Home" },
  { href: "books.html", label: "Books" },
  { href: "events.html", label: "Events" },
  { href: "visit.html", label: "Visit" },
];

let server;
let browser;

before(async () => {
  server = await startServer();
  browser = await launchBrowser();
});

after(async () => {
  await browser.close();
  await server.close();
});

async function loadPage(path, options) {
  const tracked = await openTracked(browser, options);
  await tracked.page.goto(`${server.origin}/${path}`, { waitUntil: "load" });
  return tracked;
}

describe("shared navigation", () => {
  for (const current of PAGES) {
    it(`${current} links to all four pages and marks only itself as current`, async () => {
      const { page, close } = await loadPage(current);
      try {
        const links = await page.$$eval(".site-header nav a", (anchors) =>
          anchors.map((anchor) => ({
            href: anchor.getAttribute("href"),
            label: anchor.textContent.trim(),
            current: anchor.getAttribute("aria-current"),
          })),
        );
        assert.deepEqual(
          links.map(({ href, label }) => ({ href, label })),
          NAV,
        );
        const marked = links
          .filter((link) => link.current === "page")
          .map((link) => link.href);
        assert.deepEqual(marked, [current]);
      } finally {
        await close();
      }
    });
  }
});

describe("page structure", () => {
  for (const path of PAGES) {
    it(`${path} has lang, viewport, one h1, landmarks and no skipped heading levels`, async () => {
      const { page, close } = await loadPage(path);
      try {
        const facts = await page.evaluate(() => {
          const levels = [
            ...document.querySelectorAll("h1, h2, h3, h4, h5, h6"),
          ].map((heading) => Number(heading.tagName[1]));
          let skipped = levels.length > 0 && levels[0] !== 1;
          for (let index = 1; index < levels.length; index += 1) {
            if (levels[index] > levels[index - 1] + 1) skipped = true;
          }
          return {
            lang: document.documentElement.lang,
            viewport:
              document
                .querySelector('meta[name="viewport"]')
                ?.getAttribute("content") ?? null,
            h1Count: document.querySelectorAll("h1").length,
            skipped,
            landmarks: {
              header: document.querySelectorAll("body > header").length,
              nav: document.querySelectorAll("header nav").length,
              main: document.querySelectorAll("main").length,
              footer: document.querySelectorAll("body > footer").length,
            },
            skipHref:
              document.querySelector(".skip-link")?.getAttribute("href") ??
              null,
            mainId: document.querySelector("main")?.id ?? null,
          };
        });
        assert.equal(facts.lang, "en");
        assert.match(facts.viewport, /width=device-width/);
        assert.equal(facts.h1Count, 1);
        assert.equal(facts.skipped, false);
        assert.deepEqual(facts.landmarks, {
          header: 1,
          nav: 1,
          main: 1,
          footer: 1,
        });
        assert.equal(facts.skipHref, "#main");
        assert.equal(facts.mainId, "main");
      } finally {
        await close();
      }
    });
  }

  it("gives every page a distinct, non-empty title", async () => {
    const titles = [];
    for (const path of PAGES) {
      const { page, close } = await loadPage(path);
      titles.push(await page.title());
      await close();
    }
    assert.ok(titles.every((title) => title.trim().length > 0));
    assert.equal(new Set(titles).size, PAGES.length);
  });

  it("shows the skip link on keyboard focus and it moves to main", async () => {
    const { page, close } = await loadPage("index.html");
    try {
      await page.keyboard.press("Tab");
      const visible = await page.evaluate(() => {
        const link = document.activeElement;
        const box = link.getBoundingClientRect();
        return (
          link.classList.contains("skip-link") &&
          box.top >= 0 &&
          box.width > 0 &&
          box.height > 0
        );
      });
      assert.equal(visible, true);
      await page.keyboard.press("Enter");
      assert.equal(await page.evaluate(() => location.hash), "#main");
    } finally {
      await close();
    }
  });
});

describe("page content", () => {
  it("home has a hero, staff picks, an event teaser and links to the other pages", async () => {
    const { page, close } = await loadPage("index.html");
    try {
      const facts = await page.evaluate(() => ({
        hero: Boolean(document.querySelector(".hero h1")),
        picks: document.querySelectorAll(".card-list .card h3").length,
        teaser:
          document.querySelector("time")?.getAttribute("datetime") ?? null,
        links: ["books.html", "events.html", "visit.html"].filter((href) =>
          document.querySelector(`main a[href="${href}"]`),
        ),
        placeholder: /lorem ipsum/i.test(document.body.textContent),
      }));
      assert.equal(facts.hero, true);
      assert.equal(facts.picks, 3);
      assert.equal(facts.teaser, "2026-12-05");
      assert.deepEqual(facts.links, [
        "books.html",
        "events.html",
        "visit.html",
      ]);
      assert.equal(facts.placeholder, false);
    } finally {
      await close();
    }
  });

  it("events lists at least four events, all dated between December 2026 and March 2027", async () => {
    const { page, close } = await loadPage("events.html");
    try {
      const events = await page.$$eval("#event-list .event-card", (items) =>
        items.map((item) => ({
          datetime:
            item.querySelector("time")?.getAttribute("datetime") ?? null,
          time: item.querySelector(".event-time")?.textContent.trim() ?? "",
          title: item.querySelector("h2")?.textContent.trim() ?? "",
          description:
            item.querySelector(".event-description")?.textContent.trim() ?? "",
        })),
      );
      assert.ok(
        events.length >= 4,
        `expected at least 4 events, got ${events.length}`,
      );
      for (const event of events) {
        assert.match(event.datetime, /^\d{4}-\d{2}-\d{2}$/);
        assert.ok(
          event.datetime >= "2026-12-01" && event.datetime <= "2027-03-31",
          event.datetime,
        );
        assert.notEqual(event.time, "");
        assert.notEqual(event.title, "");
        assert.notEqual(event.description, "");
      }
    } finally {
      await close();
    }
  });

  it("visit has seven opening days, an address, tel and mailto links and labelled form fields", async () => {
    const { page, close } = await loadPage("visit.html");
    try {
      const facts = await page.evaluate(() => ({
        days: [...document.querySelectorAll(".hours tbody th")].map((cell) =>
          cell.textContent.trim(),
        ),
        address:
          document
            .querySelector("main address")
            ?.textContent.replace(/\s+/g, " ")
            .trim() ?? "",
        tel:
          document
            .querySelector('main a[href^="tel:"]')
            ?.getAttribute("href") ?? null,
        mailto:
          document
            .querySelector('main a[href^="mailto:"]')
            ?.getAttribute("href") ?? null,
        fields: ["name", "email", "message"].map((field) => {
          const input = document.getElementById(`contact-${field}`);
          const label = document.querySelector(`label[for="contact-${field}"]`);
          return {
            field,
            hasInput: Boolean(input),
            label: label?.textContent.trim() ?? "",
          };
        }),
      }));
      assert.deepEqual(facts.days, [
        "Monday",
        "Tuesday",
        "Wednesday",
        "Thursday",
        "Friday",
        "Saturday",
        "Sunday",
      ]);
      assert.match(facts.address, /14 Quill Lane/);
      assert.equal(facts.tel, "tel:+15550102345");
      assert.equal(facts.mailto, "mailto:hello@marginalia-books.example");
      for (const { field, hasInput, label } of facts.fields) {
        assert.equal(hasInput, true, `${field} input`);
        assert.match(label, /\(required\)$/, `${field} label`);
      }
    } finally {
      await close();
    }
  });
});

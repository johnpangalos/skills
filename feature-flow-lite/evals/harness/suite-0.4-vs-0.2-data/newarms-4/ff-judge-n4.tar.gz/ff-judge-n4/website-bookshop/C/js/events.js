// Renders events from events-data.js, sorted by date and split into upcoming and past
// using the reader's local calendar day.
(function () {
  'use strict';

  const DATE_FORMAT = { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric', timeZone: 'UTC' };

  function pad(n) {
    return String(n).padStart(2, '0');
  }

  function localToday() {
    const now = new Date();
    return `${now.getFullYear()}-${pad(now.getMonth() + 1)}-${pad(now.getDate())}`;
  }

  function startOrder(a, b) {
    return `${a.date}T${a.startTime}`.localeCompare(`${b.date}T${b.startTime}`);
  }

  function formatDate(isoDate) {
    const [year, month, day] = isoDate.split('-').map(Number);
    return new Date(Date.UTC(year, month - 1, day)).toLocaleDateString('en-GB', DATE_FORMAT);
  }

  function formatTime(startTime) {
    const [hour, minute] = startTime.split(':').map(Number);
    const clock = hour % 12 || 12;
    const suffix = hour < 12 ? 'am' : 'pm';
    return minute ? `${clock}:${pad(minute)}${suffix}` : `${clock}${suffix}`;
  }

  function eventItem(event) {
    const item = document.createElement('li');
    const heading = document.createElement('h3');
    heading.textContent = event.title;

    const when = document.createElement('p');
    when.className = 'event-when';
    const time = document.createElement('time');
    time.setAttribute('datetime', `${event.date}T${event.startTime}`);
    time.textContent = `${formatDate(event.date)}, ${formatTime(event.startTime)}`;
    when.appendChild(time);

    const description = document.createElement('p');
    description.className = 'event-description';
    description.textContent = event.description;

    const attendance = document.createElement('p');
    attendance.className = 'event-attendance';
    attendance.textContent = event.attendance;

    item.append(heading, when, description, attendance);
    return item;
  }

  function fillList(id, events) {
    document.getElementById(id).replaceChildren(...events.map(eventItem));
  }

  const today = localToday();
  const sorted = EVENTS.slice().sort(startOrder);
  const past = sorted.filter((event) => event.date < today);
  const upcoming = sorted.filter((event) => event.date >= today);

  fillList('upcoming-events', upcoming);
  fillList('past-events', past);
  document.getElementById('upcoming-events').hidden = upcoming.length === 0;
  document.getElementById('upcoming-empty').hidden = upcoming.length > 0;
  document.getElementById('past-section').hidden = past.length === 0;
})();

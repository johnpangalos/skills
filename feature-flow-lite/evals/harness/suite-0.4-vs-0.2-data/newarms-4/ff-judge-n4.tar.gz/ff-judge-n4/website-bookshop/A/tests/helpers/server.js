"use strict";

const fs = require("node:fs");
const http = require("node:http");
const path = require("node:path");
const { chromium } = require("playwright");

const ROOT = path.resolve(__dirname, "..", "..");
const PAGES = ["index.html", "books.html", "events.html", "visit.html"];
const TYPES = {
  ".html": "text/html; charset=utf-8",
  ".css": "text/css; charset=utf-8",
  ".js": "text/javascript; charset=utf-8",
  ".svg": "image/svg+xml",
};

function startServer() {
  const server = http.createServer((req, res) => {
    const { pathname } = new URL(req.url, "http://localhost");
    let decoded;
    try {
      decoded = decodeURIComponent(pathname);
    } catch {
      res.writeHead(400, { "Content-Type": "text/plain; charset=utf-8" });
      res.end("Bad request");
      return;
    }
    const file = path.join(ROOT, decoded.replace(/\/$/, "/index.html"));
    fs.readFile(file, (error, data) => {
      if (error || !file.startsWith(ROOT + path.sep)) {
        res.writeHead(404, { "Content-Type": "text/plain; charset=utf-8" });
        res.end("Not found");
        return;
      }
      res.writeHead(200, {
        "Content-Type": TYPES[path.extname(file)] || "application/octet-stream",
      });
      res.end(data);
    });
  });
  return new Promise((resolve) => {
    server.listen(0, "127.0.0.1", () => {
      const { port } = server.address();
      resolve({
        origin: `http://127.0.0.1:${port}`,
        close: () => new Promise((done) => server.close(done)),
      });
    });
  });
}

// Starts the local static server and one headless Chrome for a test file.
async function startSite() {
  const server = await startServer();
  const browser = await chromium.launch({
    executablePath: process.env.CHROME_PATH || "/usr/bin/google-chrome",
    args: ["--no-sandbox"],
  });

  return {
    origin: server.origin,
    // Opens a page on `name` (e.g. 'books.html?genre=Mystery') in a fresh context.
    // Options: viewport, timezoneId, reducedMotion, clock (fixed Date set before load),
    // beforeGoto(page) for attaching listeners before the first request.
    async withPage(name, { clock, beforeGoto, ...options } = {}, fn) {
      const context = await browser.newContext({
        viewport: { width: 1280, height: 900 },
        ...options,
      });
      try {
        const page = await context.newPage();
        if (clock) await page.clock.setFixedTime(clock);
        if (beforeGoto) beforeGoto(page);
        await page.goto(`${server.origin}/${name}`);
        return await fn(page);
      } finally {
        await context.close();
      }
    },
    async close() {
      await browser.close();
      await server.close();
    },
  };
}

module.exports = { PAGES, ROOT, startSite };

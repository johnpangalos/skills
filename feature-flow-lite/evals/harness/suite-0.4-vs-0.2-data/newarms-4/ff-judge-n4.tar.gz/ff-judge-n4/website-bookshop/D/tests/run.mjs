import assert from 'node:assert/strict';
import { execSync } from 'node:child_process';
import { readFile } from 'node:fs/promises';
import { createServer } from 'node:http';
import { createRequire } from 'node:module';
import { extname, join, resolve, sep } from 'node:path';
import { fileURLToPath } from 'node:url';

const require = createRequire(import.meta.url);
const { chromium } = require('playwright');

const ROOT = resolve(fileURLToPath(new URL('..', import.meta.url)));
const PAGES = ['index.html', 'books.html', 'events.html', 'visit.html'];
const WIDTHS = [360, 768, 1280];
const GENRES = [
  'Mystery',
  'Poetry',
  'Fiction',
  'Science Fiction',
  'Nature Writing',
];
const BOOK_TOTAL = 15;
const FORM_FIELDS = ['name', 'email', 'message'];
const MIME = {
  '.html': 'text/html; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.js': 'text/javascript; charset=utf-8',
  '.mjs': 'text/javascript; charset=utf-8',
  '.svg': 'image/svg+xml',
};

const slugOf = (genre) => genre.toLowerCase().replace(/\s+/g, '-');
const NAME_BY_SLUG = Object.fromEntries(GENRES.map((g) => [slugOf(g), g]));

const tests = [];
const test = (name, fn) => tests.push({ name, fn });

function startServer() {
  const server = createServer(async (req, res) => {
    try {
      const path = decodeURIComponent(new URL(req.url, 'http://x').pathname);
      const file = resolve(ROOT, path === '/' ? 'index.html' : `.${path}`);
      if (!file.startsWith(ROOT + sep)) {
        res.writeHead(403).end();
        return;
      }
      const body = await readFile(file);
      res.writeHead(200, {
        'Content-Type': MIME[extname(file)] ?? 'application/octet-stream',
      });
      res.end(body);
    } catch {
      res.writeHead(404).end('Not found');
    }
  });
  return new Promise((done) =>
    server.listen(0, '127.0.0.1', () => done(server)),
  );
}

async function open(browser, base, path, options = {}) {
  const { width = 1280, reducedMotion = 'no-preference' } = options;
  const context = await browser.newContext({
    viewport: { width, height: 900 },
    reducedMotion,
  });
  const page = await context.newPage();
  const problems = [];
  const requests = [];
  page.on('console', (msg) => {
    if (msg.type() === 'error') problems.push(`console error: ${msg.text()}`);
  });
  page.on('pageerror', (error) =>
    problems.push(`page error: ${error.message}`),
  );
  page.on('dialog', (dialog) => {
    problems.push(`dialog: ${dialog.message()}`);
    dialog.dismiss();
  });
  page.on('request', (req) => requests.push(req.url()));
  await page.goto(`${base}/${path}`, { waitUntil: 'load' });
  return { page, problems, requests, close: () => context.close() };
}

async function withPage(ctx, path, options, fn) {
  const session = await open(ctx.browser, ctx.base, path, options);
  try {
    return await fn(session);
  } finally {
    await session.close();
  }
}

function luminance(rgb) {
  const [r, g, b] = rgb.map((channel) => {
    const c = channel / 255;
    return c <= 0.03928 ? c / 12.92 : ((c + 0.055) / 1.055) ** 2.4;
  });
  return 0.2126 * r + 0.7152 * g + 0.0722 * b;
}

function contrastRatio(fgText, bgText) {
  const [fg, bg] = [fgText, bgText].map((text) =>
    text
      .match(/[\d.]+/g)
      .slice(0, 3)
      .map(Number),
  );
  const [a, b] = [luminance(fg), luminance(bg)].sort((x, y) => y - x);
  return (a + 0.05) / (b + 0.05);
}

function expectFilter(state, value) {
  const genre = NAME_BY_SLUG[value];
  assert.equal(state.checked, value, 'checked filter option');
  assert.equal(
    state.genres.length,
    genre ? 3 : BOOK_TOTAL,
    'visible book count',
  );
  if (genre) {
    assert.ok(
      state.genres.every((name) => name === genre),
      `only ${genre} books shown`,
    );
  }
  assert.equal(
    state.status,
    genre
      ? `Showing 3 of ${BOOK_TOTAL} books in ${genre}`
      : `Showing ${BOOK_TOTAL} of ${BOOK_TOTAL} books`,
  );
}

const filterState = (page) =>
  page.evaluate(() => ({
    checked:
      document.querySelector('#genre-filter input:checked')?.value ?? null,
    genres: [...document.querySelectorAll('#book-list .book-genre')].map((el) =>
      el.textContent.trim(),
    ),
    status: document.getElementById('results-status').textContent.trim(),
  }));

const fieldState = (page) =>
  page.evaluate((ids) => {
    const out = {};
    for (const id of ids) {
      const input = document.getElementById(id);
      out[id] = {
        invalid: input.getAttribute('aria-invalid'),
        error: document.getElementById(`${id}-error`).textContent.trim(),
        describedBy: input.getAttribute('aria-describedby') ?? '',
      };
    }
    out.status = document.getElementById('form-status').textContent.trim();
    out.active = document.activeElement.id;
    return out;
  }, FORM_FIELDS);

async function fillForm(page, values = {}) {
  const {
    name = 'Ada Lovelace',
    email = 'ada@example.com',
    message = 'Do you stock poetry chapbooks?',
  } = values;
  await page.fill('#name', name);
  await page.fill('#email', email);
  await page.fill('#message', message);
}

const submitForm = (page) => page.click('#contact-form button[type="submit"]');

// Home
test('c1 header nav links all four pages on every page', async (ctx) => {
  for (const path of PAGES) {
    await withPage(ctx, path, {}, async (s) => {
      const hrefs = await s.page.$$eval('header nav a', (links) =>
        links.map((a) => a.getAttribute('href')),
      );
      assert.deepEqual(hrefs, PAGES, `nav on ${path}`);
    });
  }
});

test('c1 header nav links resolve with status 200', async (ctx) => {
  for (const path of PAGES) {
    await withPage(ctx, path, {}, async (s) => {
      const hrefs = await s.page.$$eval('header nav a', (links) =>
        links.map((a) => a.getAttribute('href')),
      );
      assert.equal(hrefs.length, 4, `nav links on ${path}`);
      for (const href of hrefs) {
        const res = await fetch(new URL(href, `${ctx.base}/${path}`));
        assert.equal(res.status, 200, `${href} linked from ${path}`);
      }
    });
  }
});

test('c1 current page nav link has aria-current="page" and no other does', async (ctx) => {
  for (const path of PAGES) {
    await withPage(ctx, path, {}, async (s) => {
      const current = await s.page.$$eval(
        'header nav a[aria-current="page"]',
        (links) => links.map((a) => a.getAttribute('href')),
      );
      assert.deepEqual(current, [path], `aria-current on ${path}`);
    });
  }
});

test('c1 header and footer markup is identical on every page', async (ctx) => {
  const shells = [];
  for (const path of PAGES) {
    await withPage(ctx, path, {}, async (s) => {
      shells.push(
        await s.page.evaluate(() => {
          const header = document.querySelector('header').cloneNode(true);
          header
            .querySelectorAll('[aria-current]')
            .forEach((el) => el.removeAttribute('aria-current'));
          return {
            header: header.outerHTML,
            footer: document.querySelector('footer').outerHTML,
          };
        }),
      );
    });
  }
  for (const shell of shells) {
    assert.deepEqual(shell, shells[0]);
  }
});

test('c2 each page has lang en, a meta viewport and a unique title', async (ctx) => {
  const titles = new Set();
  for (const path of PAGES) {
    await withPage(ctx, path, {}, async (s) => {
      const meta = await s.page.evaluate(() => ({
        lang: document.documentElement.lang,
        title: document.title.trim(),
        viewport:
          document.querySelector('meta[name="viewport"]')?.content ?? '',
      }));
      assert.equal(meta.lang, 'en', `${path} lang`);
      assert.ok(meta.title.length > 0, `${path} title`);
      assert.match(meta.viewport, /width=device-width/, `${path} viewport`);
      titles.add(meta.title);
    });
  }
  assert.equal(titles.size, PAGES.length, 'titles must be unique');
});

test('c2 each page has one h1 and header, nav, main and footer landmarks', async (ctx) => {
  for (const path of PAGES) {
    await withPage(ctx, path, {}, async (s) => {
      const counts = await s.page.evaluate(() => ({
        h1: document.querySelectorAll('h1').length,
        header: document.querySelectorAll('body > header').length,
        nav: document.querySelectorAll('header nav').length,
        main: document.querySelectorAll('main').length,
        footer: document.querySelectorAll('body > footer').length,
      }));
      assert.deepEqual(
        counts,
        { h1: 1, header: 1, nav: 1, main: 1, footer: 1 },
        path,
      );
    });
  }
});

test('c2 headings never skip a level', async (ctx) => {
  for (const path of PAGES) {
    await withPage(ctx, path, {}, async (s) => {
      const levels = await s.page.$$eval('h1, h2, h3, h4, h5, h6', (els) =>
        els.map((el) => Number(el.tagName.slice(1))),
      );
      assert.equal(levels[0], 1, `${path} starts at h1`);
      levels.forEach((level, i) =>
        assert.ok(
          i === 0 || level <= levels[i - 1] + 1,
          `${path}: h${levels[i - 1]} followed by h${level}`,
        ),
      );
    });
  }
});

test('c2 skip link is the first focusable element and moves focus to main', async (ctx) => {
  for (const path of PAGES) {
    await withPage(ctx, path, {}, async (s) => {
      await s.page.keyboard.press('Tab');
      const href = await s.page.evaluate(() =>
        document.activeElement.getAttribute('href'),
      );
      assert.equal(href, '#main', `${path} first Tab`);
      await s.page.keyboard.press('Enter');
      const id = await s.page.evaluate(() => document.activeElement.id);
      assert.equal(id, 'main', `${path} focus after skip link`);
    });
  }
});

test('c3 home introduces the shop and links to books, events and visit', async (ctx) => {
  await withPage(ctx, 'index.html', {}, async (s) => {
    const info = await s.page.evaluate(() => {
      const main = document.querySelector('main');
      return {
        intro: main.querySelector('p').textContent.trim(),
        text: main.textContent,
        links: [...main.querySelectorAll('a')].map((a) =>
          a.getAttribute('href'),
        ),
        sections: main.querySelectorAll('section').length,
      };
    });
    assert.ok(info.intro.length > 80, 'real intro copy');
    assert.doesNotMatch(info.text, /lorem ipsum/i);
    assert.ok(info.sections >= 3, 'highlight sections');
    for (const target of ['books.html', 'events.html', 'visit.html']) {
      assert.ok(info.links.includes(target), `home links to ${target}`);
    }
  });
});

test('c4 books catalogue has 12+ titles across 5+ genres with 2+ each', async (ctx) => {
  await withPage(ctx, 'books.html', {}, async (s) => {
    const books = await s.page.$$eval('#book-list > li', (items) =>
      items.map((li) =>
        [
          'h2',
          '.book-author',
          '.book-genre',
          '.book-price',
          '.book-description',
        ].map((sel) => li.querySelector(sel)?.textContent.trim() ?? ''),
      ),
    );
    assert.ok(books.length >= 12, `only ${books.length} titles`);
    for (const fields of books) {
      assert.ok(fields.every(Boolean), `empty field in ${fields[0]}`);
      assert.match(fields[3], /^\$\d+\.\d{2}$/, `price of ${fields[0]}`);
    }
    const counts = {};
    for (const fields of books)
      counts[fields[2]] = (counts[fields[2]] ?? 0) + 1;
    assert.ok(Object.keys(counts).length >= 5, 'at least 5 genres');
    for (const count of Object.values(counts)) {
      assert.ok(count >= 2, 'at least 2 titles per genre');
    }
  });
});

test('c5 genre filter is a labelled radio group with All and each genre', async (ctx) => {
  await withPage(ctx, 'books.html', {}, async (s) => {
    const info = await s.page.evaluate(() => {
      const fieldset = document.querySelector('fieldset');
      const radios = [...fieldset.querySelectorAll('input[type="radio"]')];
      return {
        legend: fieldset.querySelector('legend')?.textContent.trim() ?? '',
        values: radios.map((r) => r.value),
        labels: radios.map((r) => r.labels[0]?.textContent.trim() ?? ''),
      };
    });
    assert.ok(info.legend.length > 0, 'legend');
    assert.deepEqual(info.labels, ['All', ...GENRES]);
    assert.deepEqual(info.values, ['all', ...GENRES.map(slugOf)]);
  });
});

test('c5 choosing a genre shows only its books and announces the count', async (ctx) => {
  await withPage(ctx, 'books.html', {}, async (s) => {
    const status = await s.page.evaluate(() => {
      const el = document.getElementById('results-status');
      return {
        role: el.getAttribute('role'),
        live: el.getAttribute('aria-live'),
      };
    });
    assert.equal(status.role, 'status');
    assert.equal(status.live, 'polite');
    await s.page.click('label:has(input[value="mystery"])');
    expectFilter(await filterState(s.page), 'mystery');
    await s.page.click('label:has(input[value="all"])');
    expectFilter(await filterState(s.page), 'all');
  });
});

test('c5 filter group is keyboard operable', async (ctx) => {
  await withPage(ctx, 'books.html', {}, async (s) => {
    await s.page.focus('input[value="all"]');
    await s.page.keyboard.press('ArrowDown');
    expectFilter(await filterState(s.page), 'mystery');
  });
});

test('c5 ?genre=mystery loads the filtered view with its option checked', async (ctx) => {
  await withPage(ctx, 'books.html?genre=mystery', {}, async (s) => {
    expectFilter(await filterState(s.page), 'mystery');
  });
});

test('c5 changing the filter updates the URL and back and forward restore it', async (ctx) => {
  await withPage(ctx, 'books.html', {}, async (s) => {
    await s.page.click('label:has(input[value="poetry"])');
    assert.equal(new URL(s.page.url()).searchParams.get('genre'), 'poetry');
    await s.page.goBack();
    assert.equal(new URL(s.page.url()).searchParams.get('genre'), null);
    expectFilter(await filterState(s.page), 'all');
    await s.page.goForward();
    expectFilter(await filterState(s.page), 'poetry');
  });
});

const HOSTILE_GENRE = [
  ['unknown value nonsense', 'nonsense', 'all'],
  ['empty value', '', 'all'],
  ['script tag', encodeURIComponent('<script>alert(1)</script>'), 'all'],
  [
    'attribute breakout',
    encodeURIComponent('"><img src=x onerror=alert(1)>'),
    'all',
  ],
  ['upper case MYSTERY', 'MYSTERY', 'mystery'],
  ['duplicate params', 'mystery&genre=poetry', 'mystery'],
];

for (const [label, query, expected] of HOSTILE_GENRE) {
  test(`c5 hostile genre: ${label}`, async (ctx) => {
    await withPage(ctx, `books.html?genre=${query}`, {}, async (s) => {
      expectFilter(await filterState(s.page), expected);
      const injected = await s.page.evaluate(() =>
        document.body.innerHTML.includes('alert(1)'),
      );
      assert.equal(injected, false, 'payload reached the DOM');
      assert.deepEqual(s.problems, []);
    });
  });
}

test('c5 book data is inserted as text, with no images or scripts from data', async (ctx) => {
  const payload = '<img src=x onerror="window.__xss=1">Injected';
  const context = await ctx.browser.newContext({
    viewport: { width: 1280, height: 900 },
  });
  try {
    const page = await context.newPage();
    await page.route('**/js/books.js', async (route) => {
      const source = await readFile(join(ROOT, 'js/books.js'), 'utf8');
      await route.fulfill({
        contentType: MIME['.js'],
        body: source.replace(
          "title: 'The Ledger of Saint Brannoc'",
          `title: '${payload}'`,
        ),
      });
    });
    await page.goto(`${ctx.base}/books.html`, { waitUntil: 'load' });
    const heading = await page.textContent('#book-list .book-title');
    assert.equal(heading, payload, 'heading shows the literal markup');
    const imgs = await page.evaluate(
      () => document.querySelectorAll('#book-list img').length,
    );
    assert.equal(imgs, 0, 'no image rendered from book data');
    const xss = await page.evaluate(() => window.__xss);
    assert.equal(xss, undefined, 'no script from book data ran');
  } finally {
    await context.close();
  }
});

// Events
test('c6 events list four or more dated, chronological events', async (ctx) => {
  await withPage(ctx, 'events.html', {}, async (s) => {
    const events = await s.page.$$eval('main article', (articles) =>
      articles.map((a) => ({
        title: a.querySelector('h2')?.textContent.trim() ?? '',
        times: [...a.querySelectorAll('time')].map((t) =>
          t.getAttribute('datetime'),
        ),
        booking: a.querySelector('.booking')?.textContent.trim() ?? '',
      })),
    );
    assert.ok(events.length >= 4, `only ${events.length} events`);
    for (const event of events) {
      assert.ok(event.title, 'event title');
      assert.equal(event.times.length, 2, `${event.title} date and time`);
      assert.match(event.times[0], /^202[67]-\d{2}-\d{2}$/, event.title);
      assert.match(event.times[1], /^\d{2}:\d{2}$/, event.title);
      assert.match(event.booking, /^(Booking needed|No booking needed)$/);
    }
    const days = events.map((e) => e.times[0]);
    assert.deepEqual(days, [...days].sort(), 'chronological order');
  });
});

test('c6 events page never labels anything as today or past', async (ctx) => {
  await withPage(ctx, 'events.html', {}, async (s) => {
    const text = await s.page.evaluate(
      () => document.querySelector('main').textContent,
    );
    assert.doesNotMatch(text, /\b(today|past)\b/i);
  });
});

// Visit
test('c7 opening hours table has a caption and scoped headers', async (ctx) => {
  await withPage(ctx, 'visit.html', {}, async (s) => {
    const table = await s.page.evaluate(() => {
      const el = document.querySelector('main table');
      return {
        caption: el?.caption?.textContent.trim() ?? '',
        rows: el?.querySelectorAll('tbody tr').length ?? 0,
        rowHeaders: [...(el?.querySelectorAll('tbody th') ?? [])].map((th) =>
          th.getAttribute('scope'),
        ),
        headers: [...(el?.querySelectorAll('thead th') ?? [])].map((th) =>
          th.getAttribute('scope'),
        ),
      };
    });
    assert.ok(table.caption.length > 0, 'caption');
    assert.equal(table.rows, 7, 'one row per day');
    assert.ok(table.rowHeaders.every((scope) => scope === 'row'));
    assert.ok(
      table.headers.length > 0 && table.headers.every((s) => s === 'col'),
    );
  });
});

test('c7 address, tel and mailto links are present', async (ctx) => {
  await withPage(ctx, 'visit.html', {}, async (s) => {
    const info = await s.page.evaluate(() => ({
      address: document.querySelector('main address')?.textContent ?? '',
      tel: document.querySelector('a[href^="tel:"]')?.textContent ?? '',
      mailto: document.querySelector(
        'a[href="mailto:hello@marginalia.example"]',
      )?.textContent,
    }));
    assert.match(info.address, /Quire Lane/);
    assert.match(info.address, /Hollowbrook/);
    assert.match(info.tel, /555/);
    assert.equal(info.mailto, 'hello@marginalia.example');
  });
});

test('c7 directions and accessibility information are given', async (ctx) => {
  await withPage(ctx, 'visit.html', {}, async (s) => {
    const headings = await s.page.$$eval('main h2', (els) =>
      els.map((el) => el.textContent),
    );
    assert.ok(
      headings.some((h) => /find us|directions/i.test(h)),
      'directions',
    );
    assert.ok(
      headings.some((h) => /accessib/i.test(h)),
      'accessibility',
    );
  });
});

// Contact form
test('c8 name, email and message are labelled and marked required in text', async (ctx) => {
  await withPage(ctx, 'visit.html', {}, async (s) => {
    const info = await s.page.evaluate(() =>
      ['name', 'email', 'message', 'subject'].map((id) => {
        const el = document.getElementById(id);
        return {
          id,
          required: el.required,
          label: el.labels[0]?.textContent.trim() ?? '',
        };
      }),
    );
    for (const field of info.filter((f) => f.id !== 'subject')) {
      assert.equal(field.required, true, `${field.id} required attribute`);
      assert.match(field.label, /\(required\)/, `${field.id} label`);
    }
    const subject = info.find((f) => f.id === 'subject');
    assert.equal(subject.required, false);
    assert.match(subject.label, /\(optional\)/);
  });
});

test('c8 a demo notice sits just above the form before anything is submitted', async (ctx) => {
  await withPage(ctx, 'visit.html', {}, async (s) => {
    const notice = await s.page.evaluate(
      () =>
        document.getElementById('contact-form').previousElementSibling
          .textContent,
    );
    assert.match(notice, /demo/i);
  });
});

test('c8 empty submit flags all three fields, links errors and sends nothing', async (ctx) => {
  await withPage(ctx, 'visit.html', {}, async (s) => {
    await submitForm(s.page);
    const state = await fieldState(s.page);
    for (const id of FORM_FIELDS) {
      assert.equal(state[id].invalid, 'true', `${id} aria-invalid`);
      assert.ok(state[id].error.length > 0, `${id} error text`);
      assert.ok(
        state[id].describedBy.split(' ').includes(`${id}-error`),
        `${id} described by its error`,
      );
    }
    assert.equal(state.status, '', 'no success message');
    assert.equal(state.active, 'name', 'focus on first invalid field');
  });
});

test('c8 whitespace-only name and message count as empty', async (ctx) => {
  await withPage(ctx, 'visit.html', {}, async (s) => {
    await fillForm(s.page, { name: '   ', message: '  \n\t  ' });
    await submitForm(s.page);
    const state = await fieldState(s.page);
    assert.equal(state.name.invalid, 'true');
    assert.equal(state.message.invalid, 'true');
    assert.equal(state.email.invalid, 'false');
    assert.equal(state.status, '');
  });
});

for (const email of ['foo', 'foo@', 'a@b', 'a@b..c', 'a@.b.c', 'a@b.c.']) {
  test(`c8 hostile email "${email}" is rejected`, async (ctx) => {
    await withPage(ctx, 'visit.html', {}, async (s) => {
      await fillForm(s.page, { email });
      await submitForm(s.page);
      const state = await fieldState(s.page);
      assert.equal(state.email.invalid, 'true');
      assert.equal(
        state.email.error,
        'Please enter an email address like name@example.com.',
      );
      assert.equal(state.status, '');
    });
  });
}

test('c8 email reader@example.com is accepted', async (ctx) => {
  await withPage(ctx, 'visit.html', {}, async (s) => {
    await fillForm(s.page, { email: 'reader@example.com' });
    await submitForm(s.page);
    const state = await fieldState(s.page);
    assert.equal(state.email.invalid, 'false');
    assert.equal(state.email.error, '');
  });
});

test('c8 email first.last@mail.example.co is accepted', async (ctx) => {
  await withPage(ctx, 'visit.html', {}, async (s) => {
    await fillForm(s.page, { email: 'first.last@mail.example.co' });
    await submitForm(s.page);
    const state = await fieldState(s.page);
    assert.equal(state.email.invalid, 'false');
    assert.equal(state.email.error, '');
  });
});

test('c8 a 10,000 character message is refused with a visible limit', async (ctx) => {
  await withPage(ctx, 'visit.html', {}, async (s) => {
    await fillForm(s.page);
    assert.equal(await s.page.$eval('#message', (el) => el.maxLength), 2000);
    await s.page.evaluate(() => {
      document.getElementById('message').value = 'x'.repeat(10000);
    });
    await submitForm(s.page);
    const state = await fieldState(s.page);
    assert.equal(state.message.invalid, 'true');
    assert.match(state.message.error, /2000/);
    assert.equal(state.status, '');
    const h1 = await s.page.textContent('h1');
    assert.equal(h1, 'Visit the shop');
  });
});

test('c8 markup typed into the message is shown as text, not injected', async (ctx) => {
  await withPage(ctx, 'visit.html', {}, async (s) => {
    const payload = '<img src=x onerror=alert(1)>';
    await fillForm(s.page, { message: payload });
    await submitForm(s.page);
    const state = await fieldState(s.page);
    assert.equal(state.status.includes("wasn't sent"), true);
    assert.equal(
      await s.page.evaluate(() => document.querySelectorAll('img').length),
      0,
    );
    assert.equal(await s.page.inputValue('#message'), payload);
    assert.deepEqual(s.problems, []);
  });
});

test('c8 valid submit shows an honest demo status, focuses it and does not navigate', async (ctx) => {
  await withPage(ctx, 'visit.html', {}, async (s) => {
    await s.page.evaluate(() => {
      window.__marker = 1;
    });
    await fillForm(s.page);
    await submitForm(s.page);
    await s.page.waitForFunction(
      () => document.getElementById('form-status').textContent.length > 0,
    );
    const state = await fieldState(s.page);
    assert.equal(state.active, 'form-status', 'status receives focus');
    assert.match(
      state.status,
      /This is a demo site, so your message wasn't sent\./,
    );
    assert.match(state.status, /hello@marginalia\.example/);
    assert.doesNotMatch(
      state.status,
      /\bwas sent\b|has been sent|thanks for your message|we('ve| have) received/i,
    );
    assert.equal(await s.page.evaluate(() => window.__marker), 1, 'no reload');
    assert.equal(new URL(s.page.url()).pathname, '/visit.html');
  });
});

test('c8 errors clear once the field is corrected', async (ctx) => {
  await withPage(ctx, 'visit.html', {}, async (s) => {
    await submitForm(s.page);
    await s.page.fill('#name', 'Ada');
    const state = await fieldState(s.page);
    assert.notEqual(state.name.invalid, 'true');
    assert.equal(state.name.error, '');
    assert.equal(state.email.invalid, 'true', 'other errors stay');
  });
});

// Responsive and touch
for (const width of WIDTHS) {
  test(`c9 no sideways scrolling at ${width}px on every page`, async (ctx) => {
    for (const path of PAGES) {
      await withPage(ctx, path, { width }, async (s) => {
        const sizes = await s.page.evaluate(() => ({
          scroll: document.documentElement.scrollWidth,
          client: document.documentElement.clientWidth,
        }));
        assert.ok(
          sizes.scroll <= sizes.client,
          `${path}: ${JSON.stringify(sizes)}`,
        );
      });
    }
  });
}

test('c9 book grid is a single column at 360px', async (ctx) => {
  await withPage(ctx, 'books.html', { width: 360 }, async (s) => {
    const lefts = await s.page.$$eval('#book-list > li', (items) =>
      items.map((li) => Math.round(li.getBoundingClientRect().left)),
    );
    assert.equal(lefts.length, BOOK_TOTAL);
    assert.equal(new Set(lefts).size, 1, 'all cards share one left edge');
  });
});

test('c9 nav is a disclosure button at 360px that Enter opens and Escape closes', async (ctx) => {
  await withPage(ctx, 'books.html', { width: 360 }, async (s) => {
    const p = s.page;
    const navShown = () =>
      p.$eval('#site-nav', (nav) => getComputedStyle(nav).display !== 'none');
    assert.equal(
      await p.getAttribute('.nav-toggle', 'aria-controls'),
      'site-nav',
    );
    assert.equal(await p.getAttribute('.nav-toggle', 'aria-expanded'), 'false');
    assert.equal(await navShown(), false, 'nav hidden when collapsed');
    await p.focus('.nav-toggle');
    await p.keyboard.press('Enter');
    assert.equal(await p.getAttribute('.nav-toggle', 'aria-expanded'), 'true');
    assert.equal(await navShown(), true, 'nav shown when expanded');
    await p.keyboard.press('Escape');
    assert.equal(await p.getAttribute('.nav-toggle', 'aria-expanded'), 'false');
    assert.equal(await navShown(), false, 'nav hidden after Escape');
    assert.equal(
      await p.evaluate(() => document.activeElement.matches('.nav-toggle')),
      true,
      'focus returns to the toggle',
    );
  });
});

test('c9 Escape with focus in the form closes the nav and keeps focus in the form', async (ctx) => {
  await withPage(ctx, 'visit.html', { width: 360 }, async (s) => {
    const p = s.page;
    await p.click('.nav-toggle');
    assert.equal(await p.getAttribute('.nav-toggle', 'aria-expanded'), 'true');
    await p.focus('#name');
    await p.keyboard.press('Escape');
    assert.equal(await p.getAttribute('.nav-toggle', 'aria-expanded'), 'false');
    assert.equal(await p.$eval('#site-nav', (nav) => nav.hidden), true);
    assert.equal(
      await p.evaluate(() => document.activeElement.id),
      'name',
      'focus stays where the user was',
    );
  });
});

test('c9 Escape with focus on a nav link closes the nav and returns focus to the toggle', async (ctx) => {
  await withPage(ctx, 'visit.html', { width: 360 }, async (s) => {
    const p = s.page;
    await p.click('.nav-toggle');
    await p.focus('#site-nav a');
    await p.keyboard.press('Escape');
    assert.equal(await p.getAttribute('.nav-toggle', 'aria-expanded'), 'false');
    assert.equal(
      await p.evaluate(() => document.activeElement.matches('.nav-toggle')),
      true,
      'focus returns to the toggle',
    );
  });
});

test('c9 crossing to desktop width resets the open nav to closed, and back again keeps it hidden', async (ctx) => {
  await withPage(ctx, 'books.html', { width: 360 }, async (s) => {
    const p = s.page;
    const afterResize = () =>
      p.evaluate(
        () =>
          new Promise((done) =>
            requestAnimationFrame(() => requestAnimationFrame(done)),
          ),
      );
    const navShown = () =>
      p.$eval('#site-nav', (nav) => getComputedStyle(nav).display !== 'none');
    await p.click('.nav-toggle');
    assert.equal(await p.getAttribute('.nav-toggle', 'aria-expanded'), 'true');
    await p.setViewportSize({ width: 1280, height: 900 });
    await afterResize();
    assert.equal(await p.getAttribute('.nav-toggle', 'aria-expanded'), 'false');
    assert.equal(await navShown(), true, 'nav visible on desktop');
    await p.setViewportSize({ width: 360, height: 900 });
    await afterResize();
    assert.equal(await p.$eval('#site-nav', (nav) => nav.hidden), true);
    assert.equal(await navShown(), false, 'nav hidden at 360px again');
  });
});

test('c9 nav and filter tap targets are at least 44px at 360px', async (ctx) => {
  await withPage(ctx, 'books.html', { width: 360 }, async (s) => {
    await s.page.click('.nav-toggle');
    const boxes = await s.page.$$eval(
      '.nav-toggle, #site-nav a, #genre-filter label',
      (els) =>
        els.map((el) => {
          const r = el.getBoundingClientRect();
          return { w: r.width, h: r.height, text: el.textContent.trim() };
        }),
    );
    assert.equal(boxes.length, 11, 'toggle, 4 nav links, 6 filter labels');
    for (const box of boxes) {
      assert.ok(box.w >= 44 && box.h >= 44, `${box.text}: ${box.w}x${box.h}`);
    }
    const overflow = await s.page.evaluate(
      () =>
        document.documentElement.scrollWidth -
        document.documentElement.clientWidth,
    );
    assert.ok(overflow <= 0, 'open nav does not overflow');
  });
});

// Accessibility
test('c10 every keyboard stop shows a visible focus indicator', async (ctx) => {
  for (const path of PAGES) {
    await withPage(ctx, path, {}, async (s) => {
      let checked = 0;
      for (let i = 0; i < 60; i += 1) {
        await s.page.keyboard.press('Tab');
        const info = await s.page.evaluate(() => {
          const el = document.activeElement;
          if (!el || el === document.body) return null;
          const style = getComputedStyle(el);
          return {
            name: el.tagName + (el.id ? `#${el.id}` : ''),
            focusVisible: el.matches(':focus-visible'),
            outlineStyle: style.outlineStyle,
            outlineWidth: parseFloat(style.outlineWidth),
          };
        });
        if (!info) break;
        checked += 1;
        assert.ok(
          info.focusVisible &&
            info.outlineStyle !== 'none' &&
            info.outlineWidth >= 2,
          `${path}: no visible focus on ${info.name}`,
        );
      }
      assert.ok(checked >= 3, `${path}: only ${checked} keyboard stops`);
    });
  }
});

test('c10 text, link, nav and button colour pairs meet 4.5:1', async (ctx) => {
  const checks = [
    [
      'index.html',
      [
        'main p',
        'main p a',
        'a.button',
        '.site-nav a',
        '.site-footer p',
        '.brand',
      ],
    ],
    [
      'books.html',
      [
        '#genre-filter legend',
        '#genre-filter label',
        '.book-card p',
        '.results-status',
      ],
    ],
    ['visit.html', ['#contact-form button', 'label', '.hint', '.notice']],
  ];
  const report = [];
  for (const [path, selectors] of checks) {
    await withPage(ctx, path, {}, async (s) => {
      const pairs = await s.page.evaluate(
        (list) =>
          list.map((selector) => {
            const el = document.querySelector(selector);
            if (!el) return { selector, missing: true };
            let node = el;
            let background = 'rgb(255, 255, 255)';
            while (node) {
              const bg = getComputedStyle(node).backgroundColor;
              if (bg !== 'rgba(0, 0, 0, 0)' && bg !== 'transparent') {
                background = bg;
                break;
              }
              node = node.parentElement;
            }
            return {
              selector,
              color: getComputedStyle(el).color,
              background,
            };
          }),
        selectors,
      );
      for (const pair of pairs) {
        assert.ok(!pair.missing, `${path}: ${pair.selector} not found`);
        const ratio = contrastRatio(pair.color, pair.background);
        assert.ok(
          ratio >= 4.5,
          `${path} ${pair.selector}: ${ratio.toFixed(2)}`,
        );
        report.push(`${pair.selector} ${ratio.toFixed(1)}`);
      }
    });
  }
  return report.join('; ');
});

test('c10 reduced motion removes transitions', async (ctx) => {
  const normal = await withPage(ctx, 'index.html', {}, (s) =>
    s.page.$eval('.site-nav a', (a) => getComputedStyle(a).transitionDuration),
  );
  assert.notEqual(normal, '0s', 'transition exists without the preference');
  await withPage(ctx, 'index.html', { reducedMotion: 'reduce' }, async (s) => {
    const durations = await s.page.$$eval('.site-nav a, .button', (els) =>
      els.map((el) => getComputedStyle(el).transitionDuration),
    );
    assert.ok(durations.length > 0);
    assert.ok(
      durations.every((d) => d === '0s'),
      `durations: ${durations}`,
    );
  });
});

test('c10 every image and SVG has alt text or is hidden from assistive tech', async (ctx) => {
  for (const path of PAGES) {
    await withPage(ctx, path, {}, async (s) => {
      const media = await s.page.$$eval('img, svg', (els) =>
        els.map(
          (el) =>
            el.getAttribute('aria-hidden') === 'true' ||
            el.hasAttribute('alt') ||
            el.hasAttribute('aria-label') ||
            el.querySelector('title') !== null,
        ),
      );
      assert.ok(media.length > 0, `${path}: no images or svgs found`);
      assert.ok(media.every(Boolean), `${path}: unlabelled image or svg`);
    });
  }
});

test('c10 no positive tabindex and every form control has an accessible name', async (ctx) => {
  for (const path of PAGES) {
    await withPage(ctx, path, {}, async (s) => {
      const result = await s.page.evaluate(() => ({
        positive: [...document.querySelectorAll('[tabindex]')]
          .filter((el) => Number(el.getAttribute('tabindex')) > 0)
          .map((el) => el.tagName),
        unnamed: [
          ...document.querySelectorAll(
            'input:not([type="hidden"]), select, textarea',
          ),
        ]
          .filter(
            (el) =>
              el.labels.length === 0 &&
              !el.hasAttribute('aria-label') &&
              !el.hasAttribute('aria-labelledby'),
          )
          .map((el) => el.id || el.name || el.tagName),
      }));
      assert.deepEqual(result.positive, [], `${path} positive tabindex`);
      assert.deepEqual(result.unnamed, [], `${path} unnamed controls`);
    });
  }
});

// Network and console
const ALL_LOADS = [
  ...PAGES,
  'books.html?genre=mystery',
  'books.html?genre=nonsense',
];

test('c11 every request stays on the local origin', async (ctx) => {
  for (const path of ALL_LOADS) {
    await withPage(ctx, path, {}, async (s) => {
      await s.page.waitForLoadState('networkidle');
      for (const url of s.requests) {
        assert.ok(
          url.startsWith(`${ctx.base}/`) || url.startsWith('data:'),
          `${path} requested ${url}`,
        );
      }
    });
  }
});

test('c11 no console errors or page errors on any page', async (ctx) => {
  for (const path of ALL_LOADS) {
    await withPage(ctx, path, {}, async (s) => {
      await s.page.waitForLoadState('networkidle');
      assert.deepEqual(s.problems, [], path);
    });
  }
});

// Docs and formatting
test('c12 README explains the site, how to view it and how to run the checks', async () => {
  const readme = await readFile(join(ROOT, 'README.md'), 'utf8');
  assert.match(readme, /Marginalia Books/);
  assert.match(readme, /http-server|http\.server/, 'static server command');
  assert.match(readme, /tests\/run\.mjs/, 'test command');
  assert.match(readme, /npx --no-install prettier --check/, 'prettier command');
});

test('c13 prettier check passes for html, css, js and mjs', () => {
  try {
    execSync('npx --no-install prettier --check "**/*.{html,css,js,mjs}"', {
      cwd: ROOT,
      stdio: 'pipe',
    });
  } catch (error) {
    const out = String(error.stderr || error.stdout || error.message);
    throw new Error(out.split('\n').slice(0, 3).join(' | '));
  }
});

// Runner
const filter = process.argv[2];
const server = await startServer();
const browser = await chromium.launch({
  executablePath: '/usr/bin/google-chrome',
});
const ctx = { browser, base: `http://127.0.0.1:${server.address().port}` };
let ran = 0;
let failures = 0;
try {
  for (const { name, fn } of tests) {
    if (filter && !name.includes(filter)) continue;
    ran += 1;
    try {
      const detail = await fn(ctx);
      console.log(`PASS ${name}${detail ? ` (${detail})` : ''}`);
    } catch (error) {
      failures += 1;
      console.log(`FAIL ${name}: ${String(error.message).split('\n')[0]}`);
    }
  }
} finally {
  await browser.close();
  server.close();
}
if (ran === 0) {
  console.log(`No tests match "${filter}"`);
  process.exit(1);
}
console.log(`${ran - failures}/${ran} passed`);
process.exit(failures ? 1 : 0);

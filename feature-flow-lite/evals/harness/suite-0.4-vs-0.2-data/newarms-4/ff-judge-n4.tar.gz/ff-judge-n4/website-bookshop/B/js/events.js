// Events page: splits events into upcoming and past using the visitor's local date.
(function () {
  const upcomingList = document.getElementById('upcoming-list');
  const noUpcoming = document.getElementById('no-upcoming');
  const pastSection = document.getElementById('past-events');
  const pastList = document.getElementById('past-list');

  function formatWhen(date, time) {
    const [year, month, day] = date.split('-').map(Number);
    const [hour, minute] = time.split(':').map(Number);
    return new Intl.DateTimeFormat('en-GB', {
      weekday: 'long',
      day: 'numeric',
      month: 'long',
      year: 'numeric',
      hour: 'numeric',
      minute: '2-digit'
    }).format(new Date(year, month - 1, day, hour, minute));
  }

  function eventItem(entry) {
    const item = document.createElement('li');
    item.className = 'event';

    const title = document.createElement('h3');
    title.textContent = entry.title;

    const when = document.createElement('p');
    when.className = 'event-when';
    const time = document.createElement('time');
    time.dateTime = `${entry.date}T${entry.time}`;
    time.textContent = formatWhen(entry.date, entry.time);
    when.append(time);

    const description = document.createElement('p');
    description.textContent = entry.description;

    const booking = document.createElement('p');
    booking.className = 'event-booking';
    booking.textContent = entry.bookingRequired ? 'Booking required' : 'No booking needed';

    item.append(title, when, description, booking);
    return item;
  }

  const today = todayIso();
  const sorted = [...EVENTS].sort((a, b) => (a.date + a.time).localeCompare(b.date + b.time));
  const upcoming = sorted.filter((entry) => entry.date >= today);
  const past = sorted.filter((entry) => entry.date < today).reverse();

  upcomingList.replaceChildren(...upcoming.map(eventItem));
  noUpcoming.hidden = upcoming.length > 0;
  pastList.replaceChildren(...past.map(eventItem));
  pastSection.hidden = past.length === 0;
})();

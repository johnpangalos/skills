'use strict';

// Criterion 10: the README says what the site is, how to run it and how to test it.

const { test } = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const { ROOT } = require('./helpers/site');

test('README.md describes the site, how to serve it locally and how to run the tests', () => {
  const readme = fs.readFileSync(path.join(ROOT, 'README.md'), 'utf8');
  assert.match(readme, /Marginalia Books/);
  assert.match(readme, /python3 -m http\.server/);
  assert.match(readme, /npm test|node --test tests\//);
  assert.match(readme, /playwright/i);
});

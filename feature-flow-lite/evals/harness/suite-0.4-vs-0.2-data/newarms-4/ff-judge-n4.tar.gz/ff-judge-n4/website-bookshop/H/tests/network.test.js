'use strict';

const { describe, it, before, after } = require('node:test');
const assert = require('node:assert/strict');
const { PAGES, startSite } = require('./helpers');

describe('network and console (criterion 13)', () => {
  let site;
  before(async () => { site = await startSite(); });
  after(async () => { await site.close(); });

  it('makes requests only to the local origin, with no failed loads, console errors or page errors', async () => {
    const localOrigin = new URL(site.base).origin;
    for (const { file } of PAGES) {
      const page = await site.newPage();
      const requests = [];
      const problems = [];
      page.on('request', (request) => requests.push(request.url()));
      page.on('response', (response) => {
        if (response.status() >= 400) problems.push(`${response.status()} ${response.url()}`);
      });
      page.on('console', (message) => {
        if (message.type() === 'error') problems.push(`console: ${message.text()}`);
      });
      page.on('pageerror', (error) => problems.push(`pageerror: ${error.message}`));

      await page.goto(site.url(file), { waitUntil: 'load' });
      if (file === 'books.html') {
        await page.getByRole('button', { name: 'Mystery', exact: true }).click();
      }
      if (file === 'visit.html') {
        await page.getByRole('button', { name: 'Send message', exact: true }).click();
      }

      assert.deepEqual(problems, [], `${file} reported problems`);
      const external = requests
        .filter((url) => url.startsWith('http'))
        .filter((url) => new URL(url).origin !== localOrigin);
      assert.deepEqual(external, [], `${file} made requests outside the local origin`);
    }
  });
});

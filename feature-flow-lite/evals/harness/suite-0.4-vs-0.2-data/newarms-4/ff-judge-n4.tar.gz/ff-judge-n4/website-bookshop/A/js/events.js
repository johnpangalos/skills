// Marks events whose date is before the visitor's local calendar day as past.
(function () {
  var now = new Date();
  var pad = function (value) {
    return String(value).padStart(2, "0");
  };
  var today =
    now.getFullYear() +
    "-" +
    pad(now.getMonth() + 1) +
    "-" +
    pad(now.getDate());

  document.querySelectorAll(".event").forEach(function (event) {
    var date = event
      .querySelector("time")
      .getAttribute("datetime")
      .slice(0, 10);
    if (date >= today) return;

    event.classList.add("event--past");
    var badge = document.createElement("span");
    badge.className = "event__badge";
    badge.textContent = "Past event";
    event.querySelector(".event__when").appendChild(badge);
  });
})();

'use strict';

// Criteria 1 (pages and shared nav) and 11 (home page content).

const { test, before, after } = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const { ROOT, startServer, launchBrowser, openPage } = require('./helpers/site');

const NAV = [
  ['Home', 'index.html'],
  ['Books', 'books.html'],
  ['Events', 'events.html'],
  ['Visit', 'visit.html'],
];

let server;
let browser;
before(async () => {
  server = await startServer();
  browser = await launchBrowser();
});
after(async () => {
  await browser.close();
  await server.close();
});

test('the four pages exist, with index.html at the repo root', () => {
  for (const [, file] of NAV) {
    assert.ok(fs.existsSync(path.join(ROOT, file)), `${file} is missing from the repo root`);
  }
});

for (const [, current] of NAV) {
  test(`${current} shows the shared nav and marks only its own link aria-current="page"`, async () => {
    const { page } = await openPage(browser, server.origin, current);
    const links = await page.$$eval('header nav a', (as) => as.map((a) => ({
      text: a.textContent.trim(),
      href: a.getAttribute('href'),
      current: a.getAttribute('aria-current'),
    })));
    assert.deepEqual(links.map((l) => l.href), NAV.map(([, file]) => file));
    assert.deepEqual(links.map((l) => l.text), NAV.map(([label]) => label));
    for (const link of links) {
      const expected = link.href === current ? 'page' : null;
      assert.equal(link.current, expected, `aria-current on ${link.href} while on ${current}`);
    }
  });
}

test('home page has a hero, staff picks linking into the catalog, an event teaser and visit info', async () => {
  const { page } = await openPage(browser, server.origin, 'index.html');
  const hero = await page.$eval('main .hero h1', (h) => h.textContent.trim());
  assert.ok(hero.length > 0, 'hero heading is empty');
  const picks = await page.$$eval('main .staff-picks article', (items) => items.length);
  assert.ok(picks >= 3, `expected at least 3 staff picks, found ${picks}`);
  const pickLinks = await page.$$eval('main .staff-picks a[href^="books.html"]', (as) => as.length);
  assert.ok(pickLinks >= 3, `expected staff picks to link into books.html, found ${pickLinks} links`);
  const eventLink = await page.$$eval('main .event-teaser a[href="events.html"]', (as) => as.length);
  assert.equal(eventLink, 1, 'event teaser should link to events.html');
  const visitLink = await page.$$eval('main a[href="visit.html"]', (as) => as.length);
  assert.ok(visitLink >= 1, 'home should link to visit.html');
  const visitInfo = await page.$eval('main .visit-teaser', (s) => s.textContent.trim());
  assert.ok(visitInfo.length > 0, 'visit info section is empty');
});

'use strict';

const { describe, it, before, after } = require('node:test');
const assert = require('node:assert/strict');
const { startSite, openPage } = require('./helpers');

describe('events listing (criterion 7)', () => {
  let site;
  before(async () => { site = await startSite(); });
  after(async () => { await site.close(); });

  it('lists at least four upcoming 2026-2027 events, chronologically, each with a time, description and booking note', async () => {
    const page = await openPage(site, 'events.html');
    const events = await page.$$eval('.event-list > li > article', (articles) => articles.map((a) => {
      const time = a.querySelector('time');
      return {
        title: a.querySelector('h2')?.textContent.trim() ?? '',
        datetime: time?.getAttribute('datetime') ?? '',
        whenText: time?.textContent.trim() ?? '',
        description: a.querySelector('.event-description')?.textContent.trim() ?? '',
        booking: a.querySelector('.event-booking')?.textContent.trim() ?? '',
      };
    }));
    assert.ok(events.length >= 4, `only ${events.length} events`);
    for (const event of events) {
      assert.ok(event.title, 'event without a title');
      assert.match(event.datetime, /^(2026|2027)-\d{2}-\d{2}T\d{2}:\d{2}$/, `${event.title} time`);
      assert.ok(!Number.isNaN(Date.parse(event.datetime)), `${event.title} has an invalid date`);
      assert.ok(event.datetime >= '2026-11-17T00:00', `${event.title} is not upcoming`);
      assert.ok(event.whenText.length > 0, `${event.title} has no visible date`);
      assert.ok(event.description.length >= 40, `${event.title} description`);
      assert.match(event.booking, /^(Booking required|No booking needed)$/, `${event.title} booking note`);
    }
    assert.deepEqual(events.map((event) => event.datetime), [...events.map((event) => event.datetime)].sort(), 'not chronological');
  });
});

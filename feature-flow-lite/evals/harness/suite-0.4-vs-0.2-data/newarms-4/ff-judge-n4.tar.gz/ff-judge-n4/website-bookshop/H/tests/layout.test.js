'use strict';

const { describe, it, before, after } = require('node:test');
const assert = require('node:assert/strict');
const { PAGES, NARROW, WIDE, startSite, openPage } = require('./helpers');

async function assertNoSideScroll(page, label) {
  const sizes = await page.evaluate(() => ({
    main: document.querySelector('main') !== null,
    scroll: document.documentElement.scrollWidth,
    client: document.documentElement.clientWidth,
  }));
  assert.ok(sizes.main, `${label}: the page has no main element`);
  assert.ok(sizes.scroll <= sizes.client, `${label}: scrollWidth ${sizes.scroll} > clientWidth ${sizes.client}`);
}

async function smallestHeight(page, selector) {
  return page.$$eval(selector, (els) => (els.length ? Math.min(...els.map((el) => el.getBoundingClientRect().height)) : 0));
}

describe('responsive layout (criterion 11)', () => {
  let site;
  before(async () => { site = await startSite(); });
  after(async () => { await site.close(); });

  it('has no horizontal scroll at 360px or 1280px on any page', async () => {
    for (const width of [NARROW, WIDE]) {
      for (const { file } of PAGES) {
        const page = await openPage(site, file, { width });
        await assertNoSideScroll(page, `${file} at ${width}px`);
      }
    }
  });

  it('has no horizontal scroll on the books page in every filter state at 360px', async () => {
    const page = await openPage(site, 'books.html', { width: NARROW });
    const labels = await page.locator('fieldset button').allTextContents();
    assert.ok(labels.length >= 6, `only ${labels.length} filter buttons`);
    for (const label of labels) {
      await page.getByRole('button', { name: label, exact: true }).click();
      await assertNoSideScroll(page, `books filter ${label}`);
    }
  });

  it('has no horizontal scroll on the visit page with errors shown at 360px', async () => {
    const page = await openPage(site, 'visit.html', { width: NARROW });
    await page.getByRole('button', { name: 'Send message', exact: true }).click();
    await assertNoSideScroll(page, 'visit with empty-field errors');
    await page.fill('#email', `${'x'.repeat(120)}@example.co.uk`);
    await page.fill('#message', 'y'.repeat(2500));
    await page.getByRole('button', { name: 'Send message', exact: true }).click();
    await assertNoSideScroll(page, 'visit with long email and message errors');
  });

  it('wraps long unbroken words, emails and URLs on every page at 360px', async () => {
    const long = `${'x'.repeat(300)} someone.${'y'.repeat(100)}@example.co.uk https://example.com/${'z'.repeat(200)}`;
    for (const { file } of PAGES) {
      const page = await openPage(site, file, { width: NARROW });
      await page.evaluate((text) => {
        const p = document.createElement('p');
        p.textContent = text;
        document.querySelector('main').append(p);
      }, long);
      await assertNoSideScroll(page, `${file} with long text`);
    }
  });

  it('gives nav links, filter buttons and form controls a 44px tap target at 360px', async () => {
    const books = await openPage(site, 'books.html', { width: NARROW });
    await books.click('.nav-toggle');
    assert.ok(await smallestHeight(books, '.nav-toggle') >= 44, 'nav toggle is under 44px');
    assert.ok(await smallestHeight(books, 'header nav a') >= 44, 'nav links are under 44px');
    assert.ok(await smallestHeight(books, 'fieldset button') >= 44, 'filter buttons are under 44px');

    const visit = await openPage(site, 'visit.html', { width: NARROW });
    const controls = 'form input, form select, form textarea, form button';
    assert.ok(await smallestHeight(visit, controls) >= 44, 'form controls are under 44px');
  });
});

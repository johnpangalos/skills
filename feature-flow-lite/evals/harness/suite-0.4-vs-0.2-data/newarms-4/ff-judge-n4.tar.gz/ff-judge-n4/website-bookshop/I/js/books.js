// Catalogue data and genre filter for books.html.
// The selected genre lives in the query string (?genre=slug), so a filtered view can be
// bookmarked, and Back and Forward move through the filter history.
(function () {
  var GENRES = [
    { id: "mystery", name: "Mystery" },
    { id: "literary", name: "Literary fiction" },
    { id: "poetry", name: "Poetry" },
    { id: "nature", name: "Nature & science" },
    { id: "children", name: "Children's" },
    { id: "history", name: "Local history" }
  ];

  var BOOKS = [
    { title: "The Clockmaker's Alibi", author: "Imogen Thorne", genre: "mystery", price: 16, color: "#5b2333", description: "A watchmaker is found dead in a locked shop, and the only clue is a clock that has stopped four minutes early." },
    { title: "A Quiet Ledger", author: "Samuel Ockwood", genre: "mystery", price: 14.5, color: "#2f3e4e", description: "An accountant who never takes a day off notices one entry in a family firm's books that should not exist." },
    { title: "Rain on Harbour Road", author: "Nell Ashdown", genre: "mystery", price: 15, color: "#3b3b5c", description: "A ferry-town detective follows a missing letter carrier through three weeks of wet, grey and very suspicious weather." },
    { title: "The Orchard Keeper's Daughters", author: "Mara Lindqvist", genre: "literary", price: 17, color: "#4a5a2a", description: "Two sisters inherit a failing apple orchard and a set of quarrels their mother never finished." },
    { title: "Salt and Small Hours", author: "Theo Varga", genre: "literary", price: 16.5, color: "#6a4a1f", description: "Over one winter night in a coastal diner, five strangers tell the truths they had planned to keep." },
    { title: "Letters Never Posted", author: "Greta Odum", genre: "literary", price: 15.95, color: "#55304a", description: "A retired postmistress sorts a drawer of undelivered letters and decides, at last, to deliver them herself." },
    { title: "Low Tide, High Noon", author: "Ines Carrow", genre: "poetry", price: 13, color: "#1f4f5a", description: "Poems about harbours, hospital corridors and the slow arithmetic of a coastal town." },
    { title: "A Field Guide to Leaving", author: "Rafe Immerman", genre: "poetry", price: 12.5, color: "#5a3a2a", description: "Short, exact poems about moving house, moving on and the objects that refuse to be packed." },
    { title: "Tidepool Almanac", author: "June Halvorsen", genre: "nature", price: 22, color: "#23394d", description: "A year of kneeling over rock pools, one month at a time, with notes on every creature that came to visit." },
    { title: "The Quiet Lives of Lichens", author: "Ansel Brandt", genre: "nature", price: 19.95, color: "#3d4a2e", description: "A plain-language tour of the slowest partnerships on Earth, with field sketches and a good deal of patience." },
    { title: "Mira and the Lantern Moth", author: "Pip Okafor", genre: "children", price: 9.99, color: "#7a2e2e", description: "A picture book for ages five to eight about a girl who follows a moth through the town after dark." },
    { title: "The Owl Who Kept Time", author: "Lottie Vance", genre: "children", price: 10.5, color: "#2d4a6b", description: "An early reader about an owl who keeps the town clock and has opinions about everyone who is late." },
    { title: "The Fernbrook Mill Ledgers", author: "Walter Pruitt", genre: "history", price: 24, color: "#4b3b2a", description: "Three generations of mill accounts show who built the town, who paid for it and who was left out." },
    { title: "Streetcars of Quill Street", author: "Ruth Ellery", genre: "history", price: 18, color: "#2e4a3e", description: "Photographs and memoirs of the trolley line that ran past the shop until its last car was sold for scrap in 1958." }
  ];

  var fieldset = document.getElementById("genre-filter");
  var list = document.getElementById("book-list");
  var resultCount = document.getElementById("result-count");
  if (!fieldset || !list || !resultCount) return;

  // Only genres that have books are offered, so every control leads to a non-empty list.
  var available = GENRES.filter(function (genre) {
    return booksIn(genre.id).length > 0;
  });

  function genreFromQuery(search) {
    var value = (new URLSearchParams(search).get("genre") || "").trim().toLowerCase();
    var known = available.some(function (genre) {
      return genre.id === value;
    });
    return known ? value : "";
  }

  function booksIn(genreId) {
    return BOOKS.filter(function (book) {
      return !genreId || book.genre === genreId;
    });
  }

  function genreName(genreId) {
    var match = GENRES.find(function (genre) {
      return genre.id === genreId;
    });
    return match ? match.name : "";
  }

  function addOption(id, name, count) {
    var inputId = "genre-" + (id || "all");

    var input = document.createElement("input");
    input.type = "radio";
    input.name = "genre";
    input.id = inputId;
    input.value = id;

    var label = document.createElement("label");
    label.htmlFor = inputId;
    label.textContent = name + " (" + count + ")";

    var wrapper = document.createElement("div");
    wrapper.className = "genre-option";
    wrapper.append(input, label);
    fieldset.append(wrapper);
  }

  function buildControls() {
    addOption("", "All", BOOKS.length);
    available.forEach(function (genre) {
      addOption(genre.id, genre.name, booksIn(genre.id).length);
    });
  }

  function bookItem(book) {
    var item = document.createElement("li");
    item.className = "book";
    item.dataset.genre = book.genre;

    var cover = document.createElement("div");
    cover.className = "cover";
    cover.setAttribute("aria-hidden", "true");
    cover.style.setProperty("--cover", book.color);
    cover.textContent = book.title;

    var title = document.createElement("h3");
    title.textContent = book.title;

    var author = document.createElement("p");
    author.className = "book-author";
    author.textContent = "by " + book.author;

    var meta = document.createElement("p");
    meta.className = "book-meta";
    meta.textContent = genreName(book.genre) + " · $" + book.price.toFixed(2);

    var description = document.createElement("p");
    description.className = "book-desc";
    description.textContent = book.description;

    item.append(cover, title, author, meta, description);
    return item;
  }

  function showGenre(genreId) {
    var books = booksIn(genreId);
    list.replaceChildren(...books.map(bookItem));
    resultCount.textContent = "Showing " + books.length + " of " + BOOKS.length + " books";
    document.getElementById("genre-" + (genreId || "all")).checked = true;
  }

  fieldset.addEventListener("change", function (event) {
    var genreId = event.target.value;
    showGenre(genreId);
    history.pushState(
      { genre: genreId },
      "",
      genreId ? "?genre=" + encodeURIComponent(genreId) : window.location.pathname
    );
  });

  window.addEventListener("popstate", function () {
    showGenre(genreFromQuery(window.location.search));
  });

  buildControls();
  showGenre(genreFromQuery(window.location.search));
})();

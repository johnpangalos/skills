# Marginalia Books

A static website for Marginalia Books, a fictional independent bookshop on Quill Lane in Hollowmere. Plain HTML, CSS and vanilla JavaScript with no build step and no external requests.

## Pages

- `index.html`: home, with an introduction, featured books and the next upcoming events.
- `books.html`: the catalogue of 14 titles across six genres, with a genre filter. The filter lives in the URL, for example `books.html?genre=mystery`.
- `events.html`: upcoming and past events, split by the visitor's local date.
- `visit.html`: opening hours, getting here, contact details and a contact form. The form is a demo and does not send anything.

## Layout

- `styles.css`: the shared stylesheet.
- `js/books-data.js` and `js/events-data.js`: the data the pages read from. Edit these to change books or events.
- `js/main.js`: the mobile navigation toggle, shared by every page.
- `js/home.js`, `js/books.js`, `js/events.js`, `js/visit.js`: one script per page.
- `tests/run.mjs`: headless browser tests. `tests/check-static.mjs`: static checks.

## Running the site

From the repository root:

```sh
python3 -m http.server 8000
```

Then open http://localhost:8000/. Opening `index.html` directly in a browser also works.

## Running the tests

The tests use Playwright and the system Chrome, which must be installed. Playwright is resolved from the environment and is not vendored here.

```sh
node tests/run.mjs            # all browser tests
node tests/run.mjs books      # only tests whose name contains "books"
node tests/check-static.mjs   # no external URLs, local references resolve, unique ids
```

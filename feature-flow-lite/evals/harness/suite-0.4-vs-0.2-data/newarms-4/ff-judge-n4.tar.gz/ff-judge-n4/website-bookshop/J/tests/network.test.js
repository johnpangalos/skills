'use strict';

// Criterion 9: no request leaves the local origin, and no console or page errors.

const { test, before, after } = require('node:test');
const assert = require('node:assert/strict');
const { PAGES, startServer, launchBrowser, openPage } = require('./helpers/site');

let server;
let browser;
before(async () => {
  server = await startServer();
  browser = await launchBrowser();
});
after(async () => {
  await browser.close();
  await server.close();
});

for (const file of PAGES) {
  test(`${file} loads with only local requests and no console or page errors`, async () => {
    const { page, log } = await openPage(browser, server.origin, file);
    await page.waitForLoadState('networkidle');
    const foreign = log.requests.filter((r) => !r.url.startsWith(`${server.origin}/`));
    assert.deepEqual(foreign, [], 'requests to other origins');
    assert.deepEqual(log.errors, [], 'console or page errors');
  });

  test(`${file} references only same-origin resources and mailto/tel/anchor links`, async () => {
    const { page } = await openPage(browser, server.origin, file);
    const external = await page.evaluate(() => [...document.querySelectorAll('[src], [href], [srcset]')]
      .map((el) => el.getAttribute('src') || el.getAttribute('href') || el.getAttribute('srcset'))
      .map((value) => new URL(value, location.href))
      .filter((url) => ['http:', 'https:'].includes(url.protocol) && url.origin !== location.origin)
      .map((url) => url.href));
    assert.deepEqual(external, []);
  });
}

test('interacting with the books filter and the contact form makes no foreign requests or errors', async () => {
  const books = await openPage(browser, server.origin, 'books.html');
  await books.page.getByRole('radio', { name: 'Science Fiction', exact: true }).check();
  const visit = await openPage(browser, server.origin, 'visit.html');
  await visit.page.click('#contact-form button[type="submit"]');
  for (const { log } of [books, visit]) {
    assert.deepEqual(log.requests.filter((r) => !r.url.startsWith(`${server.origin}/`)), []);
    assert.deepEqual(log.errors, []);
  }
});

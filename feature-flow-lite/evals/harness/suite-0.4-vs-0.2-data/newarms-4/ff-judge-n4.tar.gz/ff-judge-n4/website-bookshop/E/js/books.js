/* Books page: genre filter, result count and empty state. The selected genre lives in ?genre= so it can be bookmarked. */
(function () {
  'use strict';

  const books = SITE_DATA.books;
  const genreList = Marginalia.genres();
  const optionsBox = document.getElementById('genre-options');
  const list = document.getElementById('book-list');
  const countText = document.getElementById('result-count');
  const note = document.getElementById('filter-note');
  const emptyNote = document.getElementById('empty-state');

  function createOption(slug, name) {
    const input = document.createElement('input');
    input.type = 'radio';
    input.name = 'genre';
    input.value = slug;
    const label = document.createElement('label');
    label.appendChild(input);
    label.appendChild(document.createTextNode(name));
    return label;
  }

  function buildOptions() {
    optionsBox.appendChild(createOption('', 'All'));
    genreList.forEach(function (genre) {
      optionsBox.appendChild(createOption(genre.slug, genre.name));
    });
  }

  function checkOption(slug) {
    Array.prototype.forEach.call(optionsBox.querySelectorAll('input'), function (input) {
      input.checked = input.value === slug;
    });
  }

  function render(slug) {
    const shown = books.filter(function (book) {
      return slug === '' || Marginalia.slugify(book.genre) === slug;
    });
    list.replaceChildren();
    shown.forEach(function (book) {
      const item = document.createElement('li');
      item.appendChild(Marginalia.createBookCard(book));
      list.appendChild(item);
    });
    countText.textContent = 'Showing ' + shown.length + ' of ' + books.length + ' books';
    emptyNote.hidden = shown.length > 0;
    checkOption(slug);
  }

  // Unknown or empty ?genre= values mean All; any unknown non-blank value also gets a note, even if it has no letters or digits.
  function showGenre(raw) {
    const text = raw.trim();
    const slug = Marginalia.slugify(text);
    const known = genreList.some(function (genre) {
      return genre.slug === slug;
    });
    const unknown = text !== '' && !known;
    note.textContent = unknown
      ? 'There is no genre called “' + text + '”, so every book is shown.'
      : '';
    note.hidden = !unknown;
    render(known ? slug : '');
  }

  function urlFor(slug) {
    return slug === '' ? 'books.html' : 'books.html?genre=' + encodeURIComponent(slug);
  }

  function readParam() {
    return new URLSearchParams(window.location.search).get('genre') || '';
  }

  buildOptions();
  showGenre(readParam());

  optionsBox.addEventListener('change', function (event) {
    const slug = event.target.value;
    showGenre(slug);
    window.history.pushState({ genre: slug }, '', urlFor(slug));
  });

  window.addEventListener('popstate', function () {
    showGenre(readParam());
  });
})();

// Visit page: contact form validation. This is a demo, so nothing is sent anywhere.
(function () {
  const form = document.getElementById('contact-form');
  const summary = document.getElementById('form-summary');
  const status = document.getElementById('form-status');
  const MAX_MESSAGE = 2000;
  const EMAIL = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

  // Zero-width and invisible characters do not count as content, so a value made only of them is blank.
  function isBlank(value) {
    return value.replace(/[​‌‍⁠﻿]/g, '').trim() === '';
  }

  // Each rule returns an error message, or '' when the value is acceptable.
  const rules = {
    name: function (value) {
      return isBlank(value) ? 'Please enter your name.' : '';
    },
    email: function (value) {
      return EMAIL.test(value.trim()) ? '' : 'Please enter an email address like name@example.com.';
    },
    topic: function (value) {
      return value === '' ? 'Please choose a topic.' : '';
    },
    message: function (value) {
      if (isBlank(value)) return 'Please enter a message.';
      if (value.length > MAX_MESSAGE) return `Please keep your message to ${MAX_MESSAGE} characters or fewer.`;
      return '';
    }
  };

  function setError(field, message) {
    const error = document.getElementById(`${field.id}-error`);
    error.textContent = message;
    if (message) {
      field.setAttribute('aria-invalid', 'true');
      field.setAttribute('aria-describedby', error.id);
    } else {
      field.removeAttribute('aria-invalid');
      field.removeAttribute('aria-describedby');
    }
  }

  // Counts the fields still marked invalid, so the summary always matches what is on screen.
  function updateSummary() {
    const count = form.querySelectorAll('[aria-invalid="true"]').length;
    summary.hidden = count === 0;
    if (count > 0) {
      summary.textContent = count === 1
        ? 'Please fix 1 field before sending.'
        : `Please fix ${count} fields before sending.`;
    }
  }

  // Clears an error as soon as its field is fixed.
  function revalidate(event) {
    const field = event.target;
    if (!rules[field.name] || !field.hasAttribute('aria-invalid')) return;
    setError(field, rules[field.name](field.value));
    updateSummary();
  }

  function submit(event) {
    event.preventDefault();
    status.textContent = '';
    const invalid = [];
    for (const key of Object.keys(rules)) {
      const field = form.elements[key];
      const message = rules[key](field.value);
      setError(field, message);
      if (message) invalid.push(field);
    }
    updateSummary();
    if (invalid.length > 0) {
      invalid[0].focus();
      return;
    }
    const name = form.elements.name.value.trim();
    status.textContent = `Thanks, ${name}. This is a demo site, so your message wasn't sent. To reach us, email hello@marginalia-books.example.`;
    form.reset();
  }

  form.addEventListener('submit', submit);
  form.addEventListener('input', revalidate);
  form.addEventListener('change', revalidate);
})();

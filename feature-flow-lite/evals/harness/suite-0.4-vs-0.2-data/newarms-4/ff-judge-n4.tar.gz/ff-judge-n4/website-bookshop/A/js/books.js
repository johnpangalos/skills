// Genre filter for books.html. The selected genre lives in the ?genre= query parameter.
(function () {
  var ALL = "All";
  var buttons = Array.prototype.slice.call(
    document.querySelectorAll(".genre-filter button"),
  );
  var cards = Array.prototype.slice.call(
    document.querySelectorAll(".book-card"),
  );
  var count = document.getElementById("result-count");

  // Unknown, empty or malformed values fall back to All.
  function genreFromUrl() {
    var requested = new URLSearchParams(window.location.search).get("genre");
    if (!requested) return ALL;
    var wanted = requested.trim().toLowerCase();
    var match = buttons.find(function (button) {
      return button.dataset.genre.toLowerCase() === wanted;
    });
    return match ? match.dataset.genre : ALL;
  }

  function show(genre) {
    var visible = 0;
    buttons.forEach(function (button) {
      button.setAttribute(
        "aria-pressed",
        String(button.dataset.genre === genre),
      );
    });
    cards.forEach(function (card) {
      var match = genre === ALL || card.dataset.genre === genre;
      card.hidden = !match;
      if (match) visible += 1;
    });
    count.textContent =
      "Showing " +
      visible +
      " of " +
      cards.length +
      " books — " +
      (genre === ALL ? "All genres" : genre);
  }

  buttons.forEach(function (button) {
    button.addEventListener("click", function () {
      var genre = button.dataset.genre;
      show(genre);
      var url = new URL(window.location.href);
      url.searchParams.delete("genre");
      if (genre !== ALL) url.searchParams.set("genre", genre);
      if (url.href !== window.location.href) {
        history.pushState({ genre: genre }, "", url.href);
      }
    });
  });

  window.addEventListener("popstate", function () {
    show(genreFromUrl());
  });

  show(genreFromUrl());
})();

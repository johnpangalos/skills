// Shared behaviour for every page: the collapsible navigation and the footer year.

const toggle = document.querySelector('.nav-toggle');
const nav = document.getElementById('site-nav');

function setNavOpen(open) {
  toggle.setAttribute('aria-expanded', String(open));
  nav.hidden = !open;
}

toggle.addEventListener('click', () => {
  setNavOpen(nav.hidden);
});

document.addEventListener('keydown', (event) => {
  if (
    event.key === 'Escape' &&
    toggle.getAttribute('aria-expanded') === 'true'
  ) {
    const focusInNav =
      nav.contains(document.activeElement) || document.activeElement === toggle;
    setNavOpen(false);
    if (focusInNav) toggle.focus();
  }
});

// On desktop the links are always shown, so crossing the breakpoint closes the disclosure.
window.matchMedia('(min-width: 40rem)').addEventListener('change', () => {
  setNavOpen(false);
});

document.getElementById('year').textContent = String(new Date().getFullYear());

# Marginalia Books

A static website for Marginalia Books, a fictional independent bookshop in the made-up town of Hartsbridge. It has four pages: a home page, a books catalogue with a genre filter, an events listing, and a visit page with opening hours, the address, and a contact form.

The site is plain HTML, CSS and vanilla JavaScript. There is no build step, no npm dependencies, and no requests to any server other than the one that serves the site.

## Viewing the site

The pages load their scripts as ES modules, so open them through a local web server rather than directly from the file system. Either of these works from the repository root:

```sh
python3 -m http.server 8080
# or
npx http-server . -p 8080
```

Then visit <http://localhost:8080/>.

## File layout

```
index.html        home page
books.html        books catalogue with genre filter (?genre=<slug>)
events.html       events listing
visit.html        opening hours, address, directions and contact form
css/styles.css    shared stylesheet, colours are CSS custom properties
js/main.js        shared behaviour: mobile navigation and skip link
js/books.js       catalogue data (one array) and the genre filter
js/visit.js       contact form validation
tests/            headless-browser tests (Playwright, Node's built-in test runner)
package.json      the test script
```

Every page has the same header and navigation, so a new page should copy the header and footer from an existing one and set `aria-current="page"` on its own link.

## Running the tests

The tests use the globally installed Playwright and Chromium, so no packages are installed for them. From the repository root:

```sh
npm test
```

Each test file starts its own static server on a random port and drives the pages in headless Chromium. To run one file:

```sh
NODE_PATH="$(npm root -g)" node --test tests/books.test.js
```

# Marginalia Books

A static website for Marginalia Books, a fictional independent bookshop at
14 Quire Lane, Hollowbrook. It has four pages:

- **Home** introduces the shop and links to the other pages.
- **Books** is a catalogue of invented titles with a genre filter. The filter
  lives in the page address (`books.html?genre=mystery`), so it can be
  bookmarked and works with the browser's back and forward buttons.
- **Events** lists upcoming events with dates, times and whether booking is
  needed.
- **Visit** has opening hours, the address, directions, accessibility
  information and a contact form. The form is a demo and does not send
  anything.

The site is plain HTML, CSS and JavaScript with no build step, no frameworks
and no npm dependencies. It makes no requests outside its own origin.

## Viewing the site

Serve the repository root with any static server, then open the printed
address. For example, using `http-server` from npm:

```sh
npx http-server -p 8080 -c-1 .
```

Then open <http://localhost:8080/>.

## Tests

The tests drive the pages in headless Chrome through Playwright. They serve the
repository on a free local port, so Playwright must be installed and Chrome
must be at `/usr/bin/google-chrome`.

```sh
NODE_PATH=/opt/node22/lib/node_modules node tests/run.mjs
```

Pass a name fragment to run a subset, for example
`NODE_PATH=/opt/node22/lib/node_modules node tests/run.mjs c5`.

## Formatting

Every HTML, CSS and JavaScript file is checked with Prettier:

```sh
npx --no-install prettier --check "**/*.{html,css,js,mjs}"
```

## Layout

- `index.html`, `books.html`, `events.html`, `visit.html`: the pages.
- `css/styles.css`: the one stylesheet.
- `js/main.js`: navigation toggle and footer year, loaded on every page.
- `js/books.js`: catalogue data and the genre filter.
- `js/visit.js`: contact form validation.
- `tests/run.mjs`: browser tests, one or more per acceptance criterion.

// Events page: lists events dated today or later, using the visitor's local date.
(function () {
  var list = document.getElementById('event-list');
  var none = document.getElementById('no-events');
  var upcoming = upcomingEvents(window.MarginaliaData.events, localTodayISO());

  if (upcoming.length === 0) {
    list.hidden = true;
    none.hidden = false;
    return;
  }

  upcoming.forEach(function (event) {
    var item = makeElement('li');
    var article = makeElement('article', 'event');
    var when = makeElement('p', 'event__when');
    var time = makeElement('time', '', formatEventDate(event.date) + ', ' + formatClockTime(event.start));
    time.setAttribute('datetime', event.date + 'T' + event.start);
    when.appendChild(time);
    article.appendChild(makeElement('h2', '', event.title));
    article.appendChild(when);
    article.appendChild(makeElement('p', 'event__booking', event.booking ? 'Booking required' : 'No booking needed'));
    article.appendChild(makeElement('p', '', event.description));
    item.appendChild(article);
    list.appendChild(item);
  });
})();

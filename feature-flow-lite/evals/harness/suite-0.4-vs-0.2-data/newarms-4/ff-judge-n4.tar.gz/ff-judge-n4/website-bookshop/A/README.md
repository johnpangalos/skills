# Marginalia Books

A static website for Marginalia Books, a fictional independent bookshop in
Hollin Bridge. It has four pages:

- **Home** (`index.html`): a welcome, staff shelf notes and links onward.
- **Books** (`books.html`): twelve invented titles across six genres, with a genre
  filter. The selected genre is kept in the address bar (`?genre=Mystery`), so a
  filtered view can be bookmarked or shared, and back and forward restore it.
- **Events** (`events.html`): upcoming readings and events in date order. Events
  before your local date are marked as past.
- **Visit** (`visit.html`): opening hours, the address, directions, accessibility
  information and a contact form. The form validates in the browser and does not
  send anything, because this is a demo.

The site is plain HTML, CSS and JavaScript. It has no build step, no npm runtime
dependencies and no external requests: fonts are system fonts, and images are
inline SVG or local files.

## Run it locally

Serve the folder with any static server, for example:

```sh
npx serve -l 8080 .
```

or

```sh
python3 -m http.server 8080
```

Then open <http://localhost:8080/>.

## Run the tests

The tests use Node's built-in test runner to drive headless Chrome through
Playwright. Playwright must be installed globally, and Chrome is expected at
`/usr/bin/google-chrome` unless `CHROME_PATH` is set.

```sh
npm test
```

To run one file:

```sh
NODE_PATH=$(npm root -g) node --test tests/books.test.js
```

## Formatting

```sh
npx prettier --check .
```

## Layout

- `index.html`, `books.html`, `events.html`, `visit.html`: the pages.
- `css/styles.css`: the one stylesheet.
- `js/main.js`: the mobile navigation toggle, shared by every page.
- `js/books.js`, `js/events.js`, `js/visit.js`: page-specific behaviour.
- `tests/`: browser tests. `tests/helpers/server.js` starts the static server.

'use strict';

// Headless-browser tests for the Marginalia Books site.
// Run with: node --test tests/

const { test, before, after, describe } = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const http = require('node:http');
const path = require('node:path');

function loadPlaywright() {
  try {
    return require('/opt/node22/lib/node_modules/playwright');
  } catch (error) {
    return require('playwright');
  }
}

const { chromium } = loadPlaywright();

const ROOT = path.resolve(__dirname, '..');
const PAGES = ['index.html', 'books.html', 'events.html', 'visit.html'];
const CONTENT_TYPES = {
  '.html': 'text/html; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.js': 'text/javascript; charset=utf-8',
  '.svg': 'image/svg+xml'
};
const TODAY = '2026-11-17';
const BOOK_TOTAL = 14;
const DEMO_PATTERN = /This is a demo site, so your message wasn't sent\./;

let server;
let origin;
let browser;

function startServer() {
  return new Promise((resolve) => {
    const srv = http.createServer((req, res) => {
      const urlPath = new URL(req.url, 'http://localhost').pathname;
      const relative = urlPath === '/' ? 'index.html' : urlPath.slice(1);
      const file = path.resolve(ROOT, relative);
      const inRoot = file.startsWith(ROOT + path.sep);
      if (!inRoot || !fs.existsSync(file) || fs.statSync(file).isDirectory()) {
        res.writeHead(404, { 'Content-Type': 'text/plain; charset=utf-8' });
        res.end('Not found');
        return;
      }
      res.writeHead(200, { 'Content-Type': CONTENT_TYPES[path.extname(file)] || 'application/octet-stream' });
      fs.createReadStream(file).pipe(res);
    });
    srv.listen(0, '127.0.0.1', () => resolve(srv));
  });
}

async function openPage(urlPath, { width = 1280 } = {}) {
  const context = await browser.newContext({ viewport: { width, height: 900 } });
  const page = await context.newPage();
  const log = {
    consoleErrors: [],
    pageErrors: [],
    badResponses: [],
    failedRequests: [],
    offOrigin: [],
    requests: []
  };
  page.on('console', (message) => {
    if (message.type() === 'error') log.consoleErrors.push(message.text());
  });
  page.on('pageerror', (error) => log.pageErrors.push(error.message));
  page.on('request', (request) => {
    log.requests.push(request.url());
    if (!request.url().startsWith(origin + '/')) log.offOrigin.push(request.url());
  });
  page.on('response', (response) => {
    if (response.status() >= 400) log.badResponses.push(`${response.status()} ${response.url()}`);
  });
  page.on('requestfailed', (request) => log.failedRequests.push(request.url()));
  await page.goto(origin + '/' + urlPath);
  await page.waitForLoadState('load');
  return { context, page, log };
}

async function withPage(urlPath, options, fn) {
  const { context, page, log } = await openPage(urlPath, options);
  try {
    return await fn(page, log);
  } finally {
    await context.close();
  }
}

function assertClean(log) {
  assert.deepEqual(log.consoleErrors, [], 'console errors');
  assert.deepEqual(log.pageErrors, [], 'uncaught page errors');
  assert.deepEqual(log.badResponses, [], 'failed (4xx/5xx) responses');
  assert.deepEqual(log.failedRequests, [], 'failed requests');
  assert.deepEqual(log.offOrigin, [], 'requests outside the origin');
}

// Requests made by the page itself, ignoring the browser's favicon fetch.
function pageRequests(log) {
  return log.requests.filter((url) => !url.endsWith('/favicon.svg'));
}

async function visibleBooks(page) {
  return page.$$eval('#book-list li', (items) =>
    items.map((item) => ({ genre: item.dataset.genre, title: item.querySelector('h3').textContent }))
  );
}

async function checkedGenres(page) {
  return page.$$eval('input[name="genre"]:checked', (inputs) => inputs.map((input) => input.value));
}

async function fillValidForm(page) {
  await page.fill('#name', 'Ada Reader');
  await page.fill('#email', 'reader@example.com');
  await page.selectOption('#topic', 'visit');
  await page.fill('#message', 'Do you have a large-print copy of the mill ledgers?');
}

async function submitForm(page) {
  await page.click('#contact-form button[type="submit"]');
}

before(async () => {
  server = await startServer();
  origin = `http://127.0.0.1:${server.address().port}`;
  const launchOptions = { headless: true };
  if (fs.existsSync('/usr/bin/google-chrome')) {
    launchOptions.executablePath = '/usr/bin/google-chrome';
  }
  browser = await chromium.launch(launchOptions);
});

after(async () => {
  if (browser) await browser.close();
  if (server) server.close();
});

describe('page basics', () => {
  test('all four pages load with no console errors, failed requests or off-origin requests', async () => {
    for (const name of PAGES) {
      await withPage(name, {}, async (page, log) => {
        const status = await page.evaluate(() => document.readyState);
        assert.equal(status, 'complete', `${name} readyState`);
        assertClean(log);
      });
    }
  });

  test('each page has lang, a viewport meta, a unique title and exactly one h1', async () => {
    const titles = new Set();
    for (const name of PAGES) {
      await withPage(name, {}, async (page) => {
        const info = await page.evaluate(() => ({
          lang: document.documentElement.lang,
          viewport: Boolean(document.querySelector('meta[name="viewport"]')),
          title: document.title,
          h1Count: document.querySelectorAll('h1').length
        }));
        assert.equal(info.lang, 'en', `${name} lang`);
        assert.ok(info.viewport, `${name} viewport meta`);
        assert.ok(info.title.length > 0, `${name} title`);
        assert.equal(info.h1Count, 1, `${name} h1 count`);
        titles.add(info.title);
      });
    }
    assert.equal(titles.size, PAGES.length, 'titles are unique');
  });

  test('no page contains lorem ipsum', async () => {
    for (const name of PAGES) {
      await withPage(name, {}, async (page) => {
        const text = await page.evaluate(() => document.body.textContent);
        assert.doesNotMatch(text, /lorem ipsum/i, name);
      });
    }
  });

  test('shared nav links all four pages and only the current page has aria-current', async () => {
    for (const name of PAGES) {
      await withPage(name, {}, async (page) => {
        const links = await page.$$eval('nav[aria-label="Main"] a', (anchors) =>
          anchors.map((anchor) => ({ href: anchor.getAttribute('href'), current: anchor.getAttribute('aria-current') }))
        );
        assert.deepEqual(links.map((link) => link.href), PAGES, `${name} nav links`);
        const current = links.filter((link) => link.current === 'page').map((link) => link.href);
        assert.deepEqual(current, [name], `${name} aria-current`);
      });
    }
  });

  test('every page has a footer with the address and hours summary', async () => {
    for (const name of PAGES) {
      await withPage(name, {}, async (page) => {
        const footer = await page.textContent('footer');
        assert.match(footer, /12 Quill Street, Fernbrook/, name);
        assert.match(footer, /Closed Mondays/, name);
      });
    }
  });

  test('skip link is the first focusable element, is visible on focus and moves focus to main', async () => {
    for (const name of PAGES) {
      await withPage(name, {}, async (page) => {
        await page.keyboard.press('Tab');
        const href = await page.evaluate(() => document.activeElement.getAttribute('href'));
        assert.equal(href, '#main', `${name} first tab stop`);
        const box = await page.locator('.skip-link').boundingBox();
        assert.ok(box && box.y >= 0 && box.width > 0 && box.height > 0, `${name} skip link box ${JSON.stringify(box)}`);
        await page.keyboard.press('Enter');
        const activeId = await page.evaluate(() => document.activeElement.id);
        assert.equal(activeId, 'main', `${name} focus after skip`);
      });
    }
  });

  test('headings start at h1 and never skip a level', async () => {
    for (const name of PAGES) {
      await withPage(name, {}, async (page) => {
        const levels = await page.$$eval('h1, h2, h3, h4, h5, h6', (headings) =>
          headings.map((heading) => Number(heading.tagName[1]))
        );
        assert.equal(levels[0], 1, `${name} first heading`);
        let previous = 0;
        for (const level of levels) {
          assert.ok(level <= previous + 1, `${name}: h${level} follows h${previous}`);
          previous = level;
        }
      });
    }
  });

  test('every focusable control shows a visible focus indicator', async () => {
    for (const name of PAGES) {
      await withPage(name, {}, async (page) => {
        const stops = await page.evaluate(() => document.querySelectorAll('a[href], button, input, select, textarea').length);
        for (let i = 0; i < stops; i++) {
          await page.keyboard.press('Tab');
          const focus = await page.evaluate(() => {
            const element = document.activeElement;
            if (element === document.body) return null;
            return {
              id: element.id || element.tagName,
              focusVisible: element.matches(':focus-visible'),
              outlineStyle: getComputedStyle(element).outlineStyle
            };
          });
          if (focus === null) break;
          assert.ok(focus.focusVisible && focus.outlineStyle !== 'none', `${name}: ${focus.id} has no focus ring`);
        }
      });
    }
  });
});

describe('responsive layout', () => {
  test('no page scrolls sideways at 360px, and none at 1280px either', async () => {
    for (const name of PAGES) {
      for (const width of [360, 1280]) {
        await withPage(name, { width }, async (page) => {
          const scrollWidth = await page.evaluate(() => document.documentElement.scrollWidth);
          assert.ok(scrollWidth <= width, `${name} at ${width}px scrollWidth is ${scrollWidth}`);
        });
      }
    }
  });

  test('the nav stays usable at 360px (all four links visible inside the viewport)', async () => {
    await withPage('visit.html', { width: 360 }, async (page) => {
      const boxes = await page.$$eval('nav[aria-label="Main"] a', (anchors) =>
        anchors.map((anchor) => {
          const rect = anchor.getBoundingClientRect();
          return { left: rect.left, right: rect.right, height: rect.height };
        })
      );
      assert.equal(boxes.length, 4);
      for (const box of boxes) {
        assert.ok(box.left >= 0 && box.right <= 360 && box.height > 0, JSON.stringify(box));
      }
    });
  });
});

describe('books catalogue', () => {
  test('catalogue has at least 12 books across at least 5 genres with 2 or more books each', async () => {
    await withPage('books.html', {}, async (page, log) => {
      const books = await page.$$eval('#book-list li', (items) =>
        items.map((item) => ({
          genre: item.dataset.genre,
          title: item.querySelector('h3')?.textContent,
          author: item.querySelector('.book-author')?.textContent,
          meta: item.querySelector('.book-meta')?.textContent,
          description: item.querySelector('.book-desc')?.textContent
        }))
      );
      assert.equal(books.length, BOOK_TOTAL);
      for (const book of books) {
        assert.ok(book.title && book.author && book.description, `incomplete book ${JSON.stringify(book)}`);
        assert.match(book.meta, /\$\d+\.\d{2}/, `${book.title} price`);
      }
      const perGenre = {};
      for (const book of books) perGenre[book.genre] = (perGenre[book.genre] || 0) + 1;
      assert.ok(Object.keys(perGenre).length >= 5, 'at least 5 genres');
      for (const [genre, count] of Object.entries(perGenre)) {
        assert.ok(count >= 2, `${genre} has ${count} books`);
      }
      const radios = await page.$$eval('input[name="genre"]', (inputs) => inputs.map((input) => input.value));
      assert.deepEqual(radios.sort(), ['', ...Object.keys(perGenre)].sort(), 'genre controls match the data');
      assertClean(log);
    });
  });

  test('clicking a genre shows only its books, updates the URL and announces the count politely', async () => {
    await withPage('books.html', {}, async (page, log) => {
      await page.click('label[for="genre-mystery"]');
      const books = await visibleBooks(page);
      assert.equal(books.length, 3);
      assert.ok(books.every((book) => book.genre === 'mystery'));
      assert.equal(new URL(page.url()).searchParams.get('genre'), 'mystery');
      assert.equal(await page.textContent('#result-count'), `Showing 3 of ${BOOK_TOTAL} books`);
      assert.equal(await page.getAttribute('#result-count', 'aria-live'), 'polite');
      assert.deepEqual(await checkedGenres(page), ['mystery']);
      assertClean(log);
    });
  });

  test('loading a genre URL directly shows the filtered view with the matching control selected', async () => {
    await withPage('books.html?genre=poetry', {}, async (page, log) => {
      const books = await visibleBooks(page);
      assert.equal(books.length, 2);
      assert.ok(books.every((book) => book.genre === 'poetry'));
      assert.deepEqual(await checkedGenres(page), ['poetry']);
      assert.equal(await page.textContent('#result-count'), `Showing 2 of ${BOOK_TOTAL} books`);
      assertClean(log);
    });
  });

  test('Back and Forward restore the previous filter state', async () => {
    await withPage('books.html', {}, async (page, log) => {
      await page.click('label[for="genre-poetry"]');
      await page.click('label[for="genre-children"]');
      assert.equal(new URL(page.url()).searchParams.get('genre'), 'children');

      await page.goBack();
      assert.equal(new URL(page.url()).searchParams.get('genre'), 'poetry');
      assert.equal((await visibleBooks(page)).length, 2);
      assert.deepEqual(await checkedGenres(page), ['poetry']);

      await page.goBack();
      assert.equal(new URL(page.url()).searchParams.get('genre'), null);
      assert.equal((await visibleBooks(page)).length, BOOK_TOTAL);
      assert.deepEqual(await checkedGenres(page), ['']);

      await page.goForward();
      assert.equal(new URL(page.url()).searchParams.get('genre'), 'poetry');
      assert.equal((await visibleBooks(page)).length, 2);
      assertClean(log);
    });
  });

  test('"All" clears the genre from the URL and shows every book', async () => {
    await withPage('books.html?genre=history', {}, async (page, log) => {
      await page.click('label[for="genre-all"]');
      assert.equal(new URL(page.url()).searchParams.get('genre'), null);
      assert.equal((await visibleBooks(page)).length, BOOK_TOTAL);
      assert.equal(await page.textContent('#result-count'), `Showing ${BOOK_TOTAL} of ${BOOK_TOTAL} books`);
      assertClean(log);
    });
  });

  test('hostile genre values fall back to All or resolve case-insensitively, with no errors or injected HTML', async () => {
    const cases = [
      { query: 'genre=', expectGenre: '', expectCount: BOOK_TOTAL },
      { query: 'genre', expectGenre: '', expectCount: BOOK_TOTAL },
      { query: 'genre=NotAGenre', expectGenre: '', expectCount: BOOK_TOTAL },
      { query: 'genre=%3Cscript%3Ealert(1)%3C%2Fscript%3E', expectGenre: '', expectCount: BOOK_TOTAL },
      { query: 'genre=MYSTERY', expectGenre: 'mystery', expectCount: 3 },
      { query: 'genre=%20Poetry%20', expectGenre: 'poetry', expectCount: 2 },
      { query: 'genre=poetry&genre=mystery', expectGenre: 'poetry', expectCount: 2 }
    ];
    for (const hostile of cases) {
      await withPage(`books.html?${hostile.query}`, {}, async (page, log) => {
        const state = await page.evaluate(() => ({
          scriptCount: document.querySelectorAll('script').length,
          bodyHasPayload: document.body.textContent.includes('alert(1)'),
          announced: document.getElementById('result-count').textContent
        }));
        assert.equal(state.scriptCount, 2, `${hostile.query}: no script elements injected`);
        assert.equal(state.bodyHasPayload, false, `${hostile.query}: payload not rendered`);
        assert.deepEqual(await checkedGenres(page), [hostile.expectGenre], `${hostile.query}: control state`);
        assert.equal((await visibleBooks(page)).length, hostile.expectCount, `${hostile.query}: list size`);
        assert.equal(state.announced, `Showing ${hostile.expectCount} of ${BOOK_TOTAL} books`, hostile.query);
        assertClean(log);
      });
    }
  });
});

describe('events', () => {
  test('at least four upcoming events, each with title, time element, description and booking status', async () => {
    await withPage('events.html', {}, async (page, log) => {
      const events = await page.$$eval('.event-list .event', (items) =>
        items.map((item) => ({
          title: item.querySelector('h2')?.textContent,
          timeTag: item.querySelector('time')?.tagName,
          datetime: item.querySelector('time')?.getAttribute('datetime'),
          description: item.querySelector('.event-desc')?.textContent,
          booking: item.querySelector('.event-booking')?.textContent
        }))
      );
      assert.ok(events.length >= 4, `only ${events.length} events`);
      for (const event of events) {
        assert.ok(event.title, 'event title');
        assert.equal(event.timeTag, 'TIME', `${event.title} time element`);
        assert.match(event.datetime, /^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}$/, `${event.title} datetime`);
        assert.ok(event.datetime.slice(0, 10) > TODAY, `${event.title} is not after ${TODAY}`);
        assert.ok(event.description.length > 20, `${event.title} description`);
        assert.match(event.booking, /Booking: (needed|not needed)/, `${event.title} booking status`);
      }
      assertClean(log);
    });
  });
});

describe('visit page', () => {
  test('opening hours table lists every day of the week', async () => {
    await withPage('visit.html', {}, async (page) => {
      const days = await page.$$eval('#hours tbody th', (headers) => headers.map((header) => header.textContent.trim()));
      assert.deepEqual(days, ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday']);
      const caption = await page.textContent('#hours caption');
      assert.equal(caption.trim(), 'Opening hours');
    });
  });

  test('address element, tel and mailto links are present', async () => {
    await withPage('visit.html', {}, async (page) => {
      assert.match(await page.textContent('main address'), /12 Quill Street/);
      assert.match(await page.getAttribute('a[href^="tel:"]', 'href'), /555/);
      assert.equal(await page.getAttribute('a[href^="mailto:"]', 'href'), 'mailto:hello@marginalia.example');
    });
  });

  test('every form field has a visible label and required fields say so in text', async () => {
    await withPage('visit.html', {}, async (page) => {
      for (const id of ['name', 'email', 'topic', 'message']) {
        const labelText = await page.$eval(`label[for="${id}"]`, (label) => label.textContent);
        assert.match(labelText, /\(required\)/, `${id} label`);
        assert.ok(await page.$(`#${id}`), `${id} control`);
      }
    });
  });

  test('submitting an empty form marks all four fields invalid, links errors and focuses the first', async () => {
    await withPage('visit.html', {}, async (page, log) => {
      const before = pageRequests(log).length;
      await submitForm(page);
      const expected = {
        name: 'Enter your name.',
        email: 'Enter your email address.',
        topic: 'Choose a topic.',
        message: 'Enter a message.'
      };
      for (const [id, message] of Object.entries(expected)) {
        const invalid = await page.getAttribute(`#${id}`, 'aria-invalid');
        const describedBy = await page.getAttribute(`#${id}`, 'aria-describedby');
        assert.equal(invalid, 'true', `${id} aria-invalid`);
        assert.equal(describedBy, `${id}-error`, `${id} aria-describedby`);
        assert.equal(await page.textContent(`#${id}-error`), message, `${id} error text`);
        assert.equal(await page.$eval(`#${id}-error`, (element) => element.hidden), false, `${id} error shown`);
      }
      assert.equal(await page.evaluate(() => document.activeElement.id), 'name');
      assert.equal(await page.textContent('#form-status'), '');
      assert.equal(pageRequests(log).length, before, 'no request on invalid submit');
    });
  });

  test('all-whitespace name and message count as empty', async () => {
    await withPage('visit.html', {}, async (page, log) => {
      await page.fill('#name', '   ');
      await page.fill('#email', 'reader@example.com');
      await page.selectOption('#topic', 'visit');
      await page.fill('#message', '   \n   ');
      await submitForm(page);
      assert.equal(await page.getAttribute('#name', 'aria-invalid'), 'true');
      assert.equal(await page.textContent('#name-error'), 'Enter your name.');
      assert.equal(await page.getAttribute('#message', 'aria-invalid'), 'true');
      assert.equal(await page.textContent('#message-error'), 'Enter a message.');
      assert.equal(await page.getAttribute('#email', 'aria-invalid'), 'false');
      assert.equal(await page.evaluate(() => document.activeElement.id), 'name');
      assertClean(log);
    });
  });

  test('"a@b" and "not an email" are rejected with an exact message; "reader@example.com" is accepted', async () => {
    for (const bad of ['a@b', 'not an email']) {
      await withPage('visit.html', {}, async (page) => {
        await page.fill('#name', 'Ada');
        await page.fill('#email', bad);
        await page.selectOption('#topic', 'visit');
        await page.fill('#message', 'Hello');
        await submitForm(page);
        assert.equal(await page.getAttribute('#email', 'aria-invalid'), 'true', bad);
        assert.equal(await page.textContent('#email-error'), 'Enter an email address like name@example.com.', bad);
        assert.equal(await page.textContent('#form-status'), '', `${bad}: no success message`);
      });
    }
    await withPage('visit.html', {}, async (page) => {
      await fillValidForm(page);
      await submitForm(page);
      assert.equal(await page.getAttribute('#email', 'aria-invalid'), 'false');
      assert.equal(await page.$eval('#email-error', (element) => element.hidden), true);
    });
  });

  test('errors clear as soon as the field is corrected', async () => {
    await withPage('visit.html', {}, async (page) => {
      await submitForm(page);
      await page.fill('#name', 'Ada Reader');
      assert.equal(await page.getAttribute('#name', 'aria-invalid'), 'false');
      assert.equal(await page.getAttribute('#name', 'aria-describedby'), null);
      assert.equal(await page.$eval('#name-error', (element) => element.hidden), true);
      assert.equal(await page.textContent('#name-error'), '');

      await page.fill('#email', 'a@b');
      await page.locator('#email').blur();
      await page.fill('#email', 'a@b.co');
      assert.equal(await page.getAttribute('#email', 'aria-invalid'), 'false');
    });
  });

  test('a valid submit shows a demo notice in the status region and never claims the message was sent', async () => {
    await withPage('visit.html', {}, async (page, log) => {
      await fillValidForm(page);
      const urlBefore = page.url();
      await submitForm(page);
      assert.equal(await page.getAttribute('#form-status', 'role'), 'status');
      const text = await page.textContent('#form-status');
      assert.match(text, DEMO_PATTERN);
      assert.match(text, /hello@marginalia\.example/);
      assert.doesNotMatch(text.replace("wasn't sent", ''), /\bsent\b/i, 'no claim that the message was sent');
      assert.equal(page.url(), urlBefore, 'page did not navigate');
      assertClean(log);
    });
  });

  test('submitting a valid form makes no network request and does not navigate', async () => {
    await withPage('visit.html', {}, async (page, log) => {
      await fillValidForm(page);
      const before = pageRequests(log).length;
      await submitForm(page);
      await page.waitForFunction(() => document.getElementById('form-status').textContent.length > 0);
      await page.waitForTimeout(300);
      assert.equal(pageRequests(log).length, before, 'requests made on submit');
    });
  });

  test('submitting twice rapidly does not duplicate the demo message', async () => {
    await withPage('visit.html', {}, async (page) => {
      await fillValidForm(page);
      await page.dblclick('#contact-form button[type="submit"]');
      await submitForm(page);
      const text = await page.innerText('#form-status');
      assert.equal((text.match(/This is a demo site/g) || []).length, 1, 'one demo message');
    });
  });

  test('a very long message is accepted in full and its length is shown', async () => {
    await withPage('visit.html', {}, async (page, log) => {
      const longMessage = 'word '.repeat(1040).trim() + '!';
      assert.ok(longMessage.length >= 5000);
      await page.fill('#name', 'Ada Reader');
      await page.fill('#email', 'reader@example.com');
      await page.selectOption('#topic', 'other');
      await page.fill('#message', longMessage);
      assert.equal(await page.inputValue('#message'), longMessage, 'textarea keeps every character');
      assert.equal(await page.textContent('#message-count'), `${longMessage.length} characters`);
      await submitForm(page);
      assert.equal(await page.getAttribute('#message', 'aria-invalid'), 'false');
      assert.match(await page.textContent('#form-status'), DEMO_PATTERN);
      assert.equal(await page.inputValue('#message'), longMessage, 'message not truncated on submit');
      assertClean(log);
    });
  });
});

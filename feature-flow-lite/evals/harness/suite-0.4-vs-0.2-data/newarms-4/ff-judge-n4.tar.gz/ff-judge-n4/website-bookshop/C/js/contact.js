// Validates the contact form on visit.html. The form does not send anything: a valid
// submit only shows a notice that this is a demo site and the message was not sent.
(function () {
  'use strict';

  const MAX_MESSAGE = 2000;
  const EMAIL_PATTERN = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  const FIELDS = ['name', 'email', 'message'];
  // Hints that stay in aria-describedby whether or not the field has an error.
  const HINTS = { name: '', email: '', message: 'message-count' };

  const form = document.getElementById('contact-form');
  const status = document.getElementById('form-status');
  const messageInput = document.getElementById('message');
  const counter = document.getElementById('message-count');

  // Each check returns an error message, or an empty string when the value is acceptable.
  const checks = {
    name: (value) => (value.trim() ? '' : 'Please enter your name.'),
    email: (value) => {
      if (!value.trim()) return 'Please enter your email address.';
      return EMAIL_PATTERN.test(value.trim()) ? '' : 'Please enter an email address such as name@example.com.';
    },
    message: (value) => {
      if (!value.trim()) return 'Please enter a message.';
      return value.length > MAX_MESSAGE ? `Please keep your message to ${MAX_MESSAGE} characters or fewer.` : '';
    },
  };

  function setError(field, text) {
    const input = document.getElementById(field);
    const error = document.getElementById(`${field}-error`);
    error.textContent = text;
    error.hidden = text === '';
    const describedBy = [HINTS[field], text ? error.id : ''].filter(Boolean).join(' ');
    if (text) {
      input.setAttribute('aria-invalid', 'true');
    } else {
      input.removeAttribute('aria-invalid');
    }
    if (describedBy) {
      input.setAttribute('aria-describedby', describedBy);
    } else {
      input.removeAttribute('aria-describedby');
    }
    return text;
  }

  function checkField(field) {
    return setError(field, checks[field](document.getElementById(field).value));
  }

  function demoNotice() {
    const paragraph = document.createElement('p');
    const link = document.createElement('a');
    link.href = 'mailto:hello@marginalia.example';
    link.textContent = 'hello@marginalia.example';
    paragraph.append('This is a demo site, so your message was not sent. To reach Marginalia Books, email ', link, '.');
    return paragraph;
  }

  // Sets each field's starting state, including the counter hint on the message.
  FIELDS.forEach((field) => setError(field, ''));

  FIELDS.forEach((field) => {
    document.getElementById(field).addEventListener('input', () => {
      if (document.getElementById(field).getAttribute('aria-invalid') === 'true') checkField(field);
    });
  });

  messageInput.addEventListener('input', () => {
    counter.textContent = `${messageInput.value.length} / ${MAX_MESSAGE} characters`;
  });

  form.addEventListener('submit', (event) => {
    event.preventDefault();
    const invalid = FIELDS.filter((field) => checkField(field) !== '');
    if (invalid.length > 0) {
      status.replaceChildren();
      document.getElementById(invalid[0]).focus();
      return;
    }
    status.replaceChildren(demoNotice());
  });
})();

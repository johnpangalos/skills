import { describe, it, before, after } from "node:test";
import assert from "node:assert/strict";
import { startServer } from "./server.mjs";
import { launchBrowser, openTracked, externalRequests } from "./helpers.mjs";

const NAME_ERROR = "Please enter your name.";
const EMAIL_EMPTY = "Please enter your email address.";
const EMAIL_INVALID = "Please enter an email address like name@example.com.";
const MESSAGE_EMPTY = "Please enter a message.";
const MESSAGE_LONG = "Please keep your message to 1000 characters or fewer.";
const DEMO_NOTICE =
  "Thanks for writing. This is a demo site, so your message was NOT sent. To reach the shop for real, email hello@marginalia-books.example or call +1 (555) 010-2345.";

let server;
let browser;

before(async () => {
  server = await startServer();
  browser = await launchBrowser();
});

after(async () => {
  await browser.close();
  await server.close();
});

async function openVisit() {
  const tracked = await openTracked(browser);
  await tracked.page.goto(`${server.origin}/visit.html`, { waitUntil: "load" });
  return tracked;
}

async function fill(page, { name = "", email = "", message = "" }) {
  await page.fill("#contact-name", name);
  await page.fill("#contact-email", email);
  await page.fill("#contact-message", message);
}

async function submit(page) {
  await page.click('#contact-form button[type="submit"]');
}

function fieldState(page, field) {
  return page.evaluate((name) => {
    const input = document.getElementById(`contact-${name}`);
    const error = document.getElementById(`${name}-error`);
    return {
      invalid: input.getAttribute("aria-invalid"),
      describedBy: input.getAttribute("aria-describedby"),
      message: error.textContent,
    };
  }, field);
}

function statusText(page) {
  return page.textContent("#form-status");
}

describe("contact form validation", () => {
  it("submitting all fields empty marks each field invalid, links errors and focuses name", async () => {
    const { page, close } = await openVisit();
    try {
      await submit(page);
      assert.deepEqual(await fieldState(page, "name"), {
        invalid: "true",
        describedBy: "name-error",
        message: NAME_ERROR,
      });
      assert.deepEqual(await fieldState(page, "email"), {
        invalid: "true",
        describedBy: "email-error",
        message: EMAIL_EMPTY,
      });
      assert.deepEqual(await fieldState(page, "message"), {
        invalid: "true",
        describedBy: "message-error",
        message: MESSAGE_EMPTY,
      });
      assert.equal(
        await page.evaluate(() => document.activeElement.id),
        "contact-name",
      );
      assert.equal(await statusText(page), "");
    } finally {
      await close();
    }
  });

  it("treats whitespace-only name and message as empty", async () => {
    const { page, close } = await openVisit();
    try {
      await fill(page, {
        name: "   ",
        email: "ada@example.com",
        message: "  \n  ",
      });
      await submit(page);
      assert.equal((await fieldState(page, "name")).message, NAME_ERROR);
      assert.equal((await fieldState(page, "message")).message, MESSAGE_EMPTY);
      assert.deepEqual(await fieldState(page, "email"), {
        invalid: "false",
        describedBy: null,
        message: "",
      });
      assert.equal(
        await page.evaluate(() => document.activeElement.id),
        "contact-name",
      );
    } finally {
      await close();
    }
  });

  for (const email of ["foo@", "foo bar@x.com"]) {
    it(`rejects the email "${email}" with the exact message`, async () => {
      const { page, close } = await openVisit();
      try {
        await fill(page, { name: "Ada", email, message: "Hello" });
        await submit(page);
        assert.deepEqual(await fieldState(page, "email"), {
          invalid: "true",
          describedBy: "email-error",
          message: EMAIL_INVALID,
        });
        assert.equal(
          await page.evaluate(() => document.activeElement.id),
          "contact-email",
        );
        assert.equal(await statusText(page), "");
      } finally {
        await close();
      }
    });
  }

  it("rejects a message over 1000 characters and keeps the layout intact", async () => {
    const { page, close } = await openVisit();
    try {
      await fill(page, { name: "Ada", email: "ada@example.com" });
      // Set the value directly so the maxlength attribute cannot truncate it.
      await page.evaluate(() => {
        document.getElementById("contact-message").value = "x".repeat(5000);
      });
      await submit(page);
      assert.deepEqual(await fieldState(page, "message"), {
        invalid: "true",
        describedBy: "message-error",
        message: MESSAGE_LONG,
      });
      assert.equal(
        await page.evaluate(() => document.activeElement.id),
        "contact-message",
      );
      const overflow = await page.evaluate(
        () => document.documentElement.scrollWidth > window.innerWidth,
      );
      assert.equal(overflow, false);
    } finally {
      await close();
    }
  });

  it("clears an error as soon as the field is corrected", async () => {
    const { page, close } = await openVisit();
    try {
      await submit(page);
      await page.fill("#contact-name", "Ada Lovelace");
      assert.deepEqual(await fieldState(page, "name"), {
        invalid: "false",
        describedBy: null,
        message: "",
      });
      await page.fill("#contact-email", "foo@");
      assert.equal((await fieldState(page, "email")).message, EMAIL_INVALID);
      await page.fill("#contact-email", "foo@example.com");
      assert.deepEqual(await fieldState(page, "email"), {
        invalid: "false",
        describedBy: null,
        message: "",
      });
    } finally {
      await close();
    }
  });

  it("pressing submit twice with invalid input shows the same errors once and focuses name again", async () => {
    const { page, close } = await openVisit();
    try {
      await submit(page);
      await submit(page);
      assert.equal((await fieldState(page, "name")).message, NAME_ERROR);
      assert.equal((await fieldState(page, "message")).message, MESSAGE_EMPTY);
      assert.equal(
        await page.evaluate(() => document.activeElement.id),
        "contact-name",
      );
      assert.equal(await statusText(page), "");
    } finally {
      await close();
    }
  });
});

describe("contact form submission", () => {
  it("a valid message shows the demo notice and sends no request", async () => {
    const { page, requests, close } = await openVisit();
    try {
      const requestsBefore = requests.length;
      await fill(page, {
        name: "Ada",
        email: "ada@example.com",
        message: "Do you stock atlases?",
      });
      await submit(page);
      assert.equal(await statusText(page), DEMO_NOTICE);
      assert.equal(await page.getAttribute("#form-status", "role"), "status");
      assert.equal(
        await page.evaluate(() =>
          document
            .getElementById("form-status")
            .textContent.includes("NOT sent"),
        ),
        true,
      );
      const newRequests = requests
        .slice(requestsBefore)
        .filter(({ url }) => url.startsWith(server.origin));
      assert.deepEqual(
        newRequests.filter(({ method }) => method !== "GET"),
        [],
      );
      assert.deepEqual(externalRequests(requests, server.origin), []);
    } finally {
      await close();
    }
  });

  it("submitting a valid message twice keeps the same single demo notice", async () => {
    const { page, close } = await openVisit();
    try {
      await fill(page, {
        name: "Ada",
        email: "ada@example.com",
        message: "Hello",
      });
      await submit(page);
      await submit(page);
      assert.equal(await statusText(page), DEMO_NOTICE);
    } finally {
      await close();
    }
  });
});

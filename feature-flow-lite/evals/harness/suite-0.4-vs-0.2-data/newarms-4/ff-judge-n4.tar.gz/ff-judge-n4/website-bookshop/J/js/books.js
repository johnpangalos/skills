// Catalogue list and genre filter. The selected genre lives in ?genre=.
// Everything is built with createElement and textContent, never innerHTML,
// so query values can't inject markup.
(function () {
  'use strict';

  var ALL = '';
  var books = window.MARGINALIA_BOOKS || [];
  var genres = uniqueGenres(books);
  var filter = document.getElementById('genre-filter');
  var options = document.getElementById('genre-options');
  var list = document.getElementById('book-list');
  var count = document.getElementById('result-count');
  var noResults = document.getElementById('no-results');

  function uniqueGenres(items) {
    return items.reduce(function (names, book) {
      if (names.indexOf(book.genre) === -1) names.push(book.genre);
      return names;
    }, []);
  }

  function el(tag, className, text) {
    var node = document.createElement(tag);
    if (className) node.className = className;
    if (text !== undefined) node.textContent = text;
    return node;
  }

  // Matches a query value to a genre name ignoring case; anything else means All.
  function genreFromQuery(value) {
    var wanted = value.toLowerCase();
    for (var i = 0; i < genres.length; i++) {
      if (genres[i].toLowerCase() === wanted) return genres[i];
    }
    return ALL;
  }

  function queryGenre() {
    return genreFromQuery(new URLSearchParams(window.location.search).get('genre') || '');
  }

  function urlFor(genre) {
    if (genre === ALL) return window.location.pathname;
    return window.location.pathname + '?genre=' + encodeURIComponent(genre);
  }

  function buildOptions() {
    addOption('All', ALL);
    genres.forEach(function (name) {
      addOption(name, name);
    });
  }

  function addOption(label, value) {
    var wrapper = el('label', 'chip');
    var input = el('input');
    input.type = 'radio';
    input.name = 'genre';
    input.value = value;
    wrapper.appendChild(input);
    wrapper.appendChild(el('span', '', label));
    options.appendChild(wrapper);
  }

  function bookItem(book) {
    var item = el('li');
    var card = el('article', 'book-card');
    var cover = el('div', 'cover cover--' + book.tone, book.title);
    cover.setAttribute('aria-hidden', 'true');
    var body = el('div', 'book-body');
    var meta = el('p', 'meta');
    meta.appendChild(el('span', 'genre', book.genre));
    meta.appendChild(el('span', 'price', '£' + book.price.toFixed(2)));
    body.appendChild(meta);
    body.appendChild(el('h2', 'book-title', book.title));
    body.appendChild(el('p', 'author', 'by ' + book.author));
    body.appendChild(el('p', 'blurb', book.blurb));
    card.appendChild(cover);
    card.appendChild(body);
    item.appendChild(card);
    return item;
  }

  function renderList(genre) {
    var shown = books.filter(function (book) {
      return genre === ALL || book.genre === genre;
    });
    list.textContent = '';
    shown.forEach(function (book) {
      list.appendChild(bookItem(book));
    });
    count.textContent = 'Showing ' + shown.length + ' of ' + books.length + ' books';
    noResults.hidden = shown.length > 0;
  }

  function showGenre(genre) {
    var inputs = filter.querySelectorAll('input[name="genre"]');
    for (var i = 0; i < inputs.length; i++) {
      inputs[i].checked = inputs[i].value === genre;
    }
    renderList(genre);
  }

  buildOptions();
  showGenre(queryGenre());

  filter.addEventListener('change', function (event) {
    var genre = event.target.value;
    window.history.pushState({ genre: genre }, '', urlFor(genre));
    showGenre(genre);
  });

  window.addEventListener('popstate', function () {
    showGenre(queryGenre());
  });
})();

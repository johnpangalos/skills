"use strict";

const { test, before, after } = require("node:test");
const assert = require("node:assert/strict");
const { PAGES, startSite } = require("./helpers/server");

let site;

before(async () => {
  site = await startSite();
});

after(async () => {
  await site.close();
});

for (const name of PAGES) {
  test(`${name}: every request stays on the local origin and the console stays clean`, async () => {
    const requests = [];
    const problems = [];
    await site.withPage(
      name,
      {
        beforeGoto(page) {
          page.on("request", (request) => requests.push(request.url()));
          page.on("console", (message) => {
            if (message.type() === "error")
              problems.push(`console: ${message.text()}`);
          });
          page.on("pageerror", (error) =>
            problems.push(`pageerror: ${error.message}`),
          );
          page.on("requestfailed", (request) =>
            problems.push(`failed: ${request.url()}`),
          );
        },
      },
      (page) => page.waitForLoadState("networkidle"),
    );
    assert.ok(requests.length > 0, "no requests recorded");
    for (const url of requests) {
      assert.ok(url.startsWith(`${site.origin}/`), `external request: ${url}`);
    }
    assert.deepEqual(problems, []);
  });
}

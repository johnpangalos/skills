// Catalogue for books.html. Every title, author and price here is fictional.
export const books = [
  {
    title: "The Glass Orchard Murders",
    author: "Rosalind Hale",
    genre: "Mystery",
    price: 14.99,
    description:
      "A botanist is found dead among the roses in a greenhouse that was locked from the inside. The village has three suspects and one very patient gardener.",
  },
  {
    title: "Nine Keys to Harrow Street",
    author: "Tomas Eberly",
    genre: "Mystery",
    price: 12.5,
    description:
      "A locksmith’s apprentice inherits a ring of nine keys, each one opening a door somewhere in the city. Someone else has been trying the same locks.",
  },
  {
    title: "The Quiet Tenant",
    author: "Imogen Strand",
    genre: "Mystery",
    price: 11,
    description:
      "A lodger who has not left her room in ten years becomes the only witness to a theft on the floor below. She must decide whether to speak.",
  },
  {
    title: "The Hollow Crown of Ysel",
    author: "Marisol Fenn",
    genre: "Fantasy",
    price: 18,
    description:
      "An exiled cartographer is hired to map a kingdom that rearranges its borders every time she sleeps. The king wants the map finished by winter.",
  },
  {
    title: "Ember and Brine",
    author: "Oren Taskar",
    genre: "Fantasy",
    price: 13.99,
    description:
      "Two rival harbour witches are forced to share a boat when the tides begin running backwards. Their feud is the least of the harbour’s problems.",
  },
  {
    title: "The Last Lantern-Keeper",
    author: "Wren Adeyemi",
    genre: "Fantasy",
    price: 16.5,
    description:
      "On a mountain station where the signal lamps must never go dark, the lamp fails one night. The keeper’s apprentice has to climb the tower and find out why.",
  },
  {
    title: "Small Weather",
    author: "Nadia Kowal",
    genre: "Literary Fiction",
    price: 15.95,
    description:
      "Three generations of a seaside family argue over a house none of them wants to keep and all of them remember differently. A quiet, funny novel about inheritance.",
  },
  {
    title: "The Orchard Letters",
    author: "Peter Lindqvist",
    genre: "Literary Fiction",
    price: 14,
    description:
      "Two estranged brothers exchange letters across one long, unhappy summer on their late father’s farm. The letters say less than they mean.",
  },
  {
    title: "A Map of Bridges",
    author: "Dr Eleanor Pym",
    genre: "History",
    price: 22,
    description:
      "A historian traces how river crossings shaped the trade routes, markets and quarrels of a medieval river valley, using toll records and church ledgers.",
  },
  {
    title: "The Printers of Lowgate",
    author: "Samuel Okafor",
    genre: "History",
    price: 19.95,
    description:
      "The story of a family print shop that risked its name, and sometimes its neck, to publish pamphlets its city wanted silenced. Illustrated with facsimile pages.",
  },
  {
    title: "Field Notes in Winter",
    author: "June Castellano",
    genre: "Poetry",
    price: 12,
    description:
      "Short poems written on the walk to work across one hard winter: frost on the bus shelter, a heron on the canal, a neighbour’s dog that waits for no one.",
  },
  {
    title: "Salt and Paper",
    author: "Idris Quill",
    genre: "Poetry",
    price: 11.5,
    description:
      "A sequence about the sea, the post office at the end of the pier and the letters that were never delivered. Each poem ends with a postmark.",
  },
  {
    title: "The Long Transit",
    author: "Ruth Amsel",
    genre: "Science Fiction",
    price: 17.99,
    description:
      "The archivist of a generation ship discovers that the official logbooks have been edited, one page at a time, for three centuries. She has four years to decide what to do.",
  },
  {
    title: "Signal Drift",
    author: "Kofi Dane",
    genre: "Science Fiction",
    price: 15,
    description:
      "A radio operator on a lunar relay station picks up a voice that repeats her own name, a minute behind her every time she speaks.",
  },
];

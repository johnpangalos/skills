// Renders the catalogue and the genre filter. The filter lives in ?genre=<slug>.
(function () {
  'use strict';

  const ALL = 'all';
  const list = document.getElementById('book-list');
  const filter = document.querySelector('.genre-filter');
  const results = document.getElementById('results');

  function slugify(name) {
    return name.toLowerCase().replace(/\s+/g, '-');
  }

  function genreOptions() {
    const options = [{ slug: ALL, name: 'All' }];
    BOOKS.forEach((book) => {
      const slug = slugify(book.genre);
      if (!options.some((option) => option.slug === slug)) {
        options.push({ slug, name: book.genre });
      }
    });
    return options;
  }

  const OPTIONS = genreOptions();

  // Reads the first ?genre= value and slugifies it the same way as the genre names, so
  // "literary fiction", "Literary+Fiction" and "literary-fiction" all match. Unknown or empty values mean All.
  function genreFromUrl() {
    const raw = new URLSearchParams(window.location.search).get('genre');
    const slug = raw ? slugify(raw.trim()) : ALL;
    return OPTIONS.some((option) => option.slug === slug) ? slug : ALL;
  }

  function buildFilter() {
    OPTIONS.forEach((option) => {
      const label = document.createElement('label');
      const input = document.createElement('input');
      input.type = 'radio';
      input.name = 'genre';
      input.value = option.slug;
      label.appendChild(input);
      label.appendChild(document.createTextNode(option.name));
      filter.appendChild(label);
    });
  }

  function syncControls(slug) {
    filter.querySelectorAll('input').forEach((input) => {
      input.checked = input.value === slug;
    });
  }

  function bookCard(book) {
    const item = document.createElement('li');
    item.className = 'book-card';
    const fields = [
      ['h2', 'book-title', book.title],
      ['p', 'book-author', `by ${book.author}`],
      ['p', 'book-genre', book.genre],
      ['p', 'book-price', `£${book.price.toFixed(2)}`],
      ['p', 'book-blurb', book.blurb],
    ];
    fields.forEach(([tag, className, text]) => {
      const el = document.createElement(tag);
      el.className = className;
      el.textContent = text;
      item.appendChild(el);
    });
    return item;
  }

  function renderBooks(slug) {
    syncControls(slug);
    const shown = slug === ALL ? BOOKS : BOOKS.filter((book) => slugify(book.genre) === slug);
    list.replaceChildren(...shown.map(bookCard));
    const option = OPTIONS.find((o) => o.slug === slug);
    const inGenre = slug === ALL ? '' : ` in ${option.name}`;
    results.textContent = `Showing ${shown.length} of ${BOOKS.length} books${inGenre}`;
  }

  filter.addEventListener('change', (event) => {
    const slug = event.target.value;
    const url = slug === ALL ? window.location.pathname : `${window.location.pathname}?genre=${slug}`;
    window.history.pushState({ genre: slug }, '', url);
    renderBooks(slug);
  });

  window.addEventListener('popstate', () => {
    renderBooks(genreFromUrl());
  });

  buildFilter();
  renderBooks(genreFromUrl());
})();

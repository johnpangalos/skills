'use strict';

// Books catalogue (criterion 6) and genre filter state in the URL (criterion 7).

const { test, before, after } = require('node:test');
const assert = require('node:assert/strict');
const { chromium } = require('playwright');
const { startServer } = require('./server.cjs');

let server;
let browser;

before(async () => {
  server = await startServer();
  browser = await chromium.launch();
});

after(async () => {
  await browser.close();
  await server.close();
});

async function openBooks(query = '') {
  const context = await browser.newContext({ viewport: { width: 1280, height: 900 } });
  const page = await context.newPage();
  const errors = [];
  const dialogs = [];
  page.on('pageerror', (err) => errors.push(err.message));
  page.on('dialog', (dialog) => {
    dialogs.push(dialog.message());
    dialog.dismiss();
  });
  await page.goto(`${server.origin}/books.html${query}`);
  await page.waitForSelector('#book-list > li');
  return { context, page, errors, dialogs };
}

async function shownTitles(page) {
  return page.$$eval('#book-list > li h2', (els) => els.map((h) => h.textContent.trim()));
}

async function checkedGenre(page) {
  return page.$eval('.genre-filter input[type="radio"]:checked', (input) => input.value);
}

function sentenceCount(text) {
  return text
    .trim()
    .split(/(?<=[.!?])\s+/)
    .filter(Boolean).length;
}

// Criterion 6

test('criterion 6: catalogue has at least 12 books across at least 5 genres with 2 or more each', async () => {
  const { context, page } = await openBooks();
  try {
    const books = await page.$$eval('#book-list > li', (items) =>
      items.map((li) => ({
        title: li.querySelector('h2')?.textContent.trim() || '',
        author: li.querySelector('.book-author')?.textContent.trim() || '',
        genre: li.querySelector('.book-genre')?.textContent.trim() || '',
        price: li.querySelector('.book-price')?.textContent.trim() || '',
        blurb: li.querySelector('.book-blurb')?.textContent.trim() || '',
      })),
    );
    assert.ok(books.length >= 12, `expected at least 12 books, found ${books.length}`);
    const counts = {};
    for (const book of books) {
      counts[book.genre] = (counts[book.genre] || 0) + 1;
      assert.ok(book.title && book.author && book.genre && book.price && book.blurb, `incomplete book "${book.title}"`);
    }
    const genres = Object.keys(counts);
    assert.ok(genres.length >= 5, `expected at least 5 genres, found ${genres.length}`);
    for (const genre of genres) {
      assert.ok(counts[genre] >= 2, `genre ${genre} has only ${counts[genre]} book(s)`);
    }
  } finally {
    await context.close();
  }
});

test('criterion 6: each staff blurb is one or two sentences', async () => {
  const { context, page } = await openBooks();
  try {
    const blurbs = await page.$$eval('#book-list .book-blurb', (els) => els.map((el) => el.textContent));
    assert.ok(blurbs.length >= 12);
    for (const blurb of blurbs) {
      const count = sentenceCount(blurb);
      assert.ok(count >= 1 && count <= 2, `blurb has ${count} sentences: ${blurb}`);
    }
  } finally {
    await context.close();
  }
});

// Criterion 7

test('criterion 7: filter offers All plus one option per genre, generated from the data', async () => {
  const { context, page } = await openBooks();
  try {
    const legend = await page.$eval('.genre-filter legend', (el) => el.textContent.trim());
    assert.equal(legend, 'Genre');
    const options = await page.$$eval('.genre-filter label', (labels) =>
      labels.map((label) => ({
        text: label.textContent.trim(),
        value: label.querySelector('input').value,
      })),
    );
    assert.deepEqual(
      options.map((o) => o.text),
      ['All', 'Mystery', 'Poetry', 'Literary fiction', 'Science fiction', 'Nature writing'],
    );
    assert.deepEqual(
      options.map((o) => o.value),
      ['all', 'mystery', 'poetry', 'literary-fiction', 'science-fiction', 'nature-writing'],
    );
    assert.equal(await checkedGenre(page), 'all');
    const live = await page.$eval('[aria-live]', (el) => ({
      live: el.getAttribute('aria-live'),
      text: el.textContent.trim(),
    }));
    assert.equal(live.live, 'polite');
    assert.equal(live.text, 'Showing 15 of 15 books');
  } finally {
    await context.close();
  }
});

test('criterion 7: choosing a genre shows only its books, announces the count, and All restores every book', async () => {
  const { context, page } = await openBooks();
  try {
    await page.locator('.genre-filter label', { hasText: 'Mystery' }).click();
    const mystery = await shownTitles(page);
    assert.equal(mystery.length, 3);
    const genres = await page.$$eval('#book-list .book-genre', (els) => [
      ...new Set(els.map((e) => e.textContent.trim())),
    ]);
    assert.deepEqual(genres, ['Mystery']);
    assert.equal(await page.$eval('[aria-live]', (el) => el.textContent.trim()), 'Showing 3 of 15 books in Mystery');

    await page.locator('.genre-filter label', { hasText: 'All' }).click();
    assert.equal((await shownTitles(page)).length, 15);
    assert.equal(await page.$eval('[aria-live]', (el) => el.textContent.trim()), 'Showing 15 of 15 books');
  } finally {
    await context.close();
  }
});

test('criterion 7: filter changes push to the URL and Back and Forward restore filter and control', async () => {
  const { context, page } = await openBooks();
  try {
    await page.locator('.genre-filter label', { hasText: 'Mystery' }).click();
    assert.equal(new URL(page.url()).searchParams.get('genre'), 'mystery');
    await page.locator('.genre-filter label', { hasText: 'Poetry' }).click();
    assert.equal(new URL(page.url()).searchParams.get('genre'), 'poetry');

    await page.goBack();
    assert.equal(new URL(page.url()).searchParams.get('genre'), 'mystery');
    assert.equal(await checkedGenre(page), 'mystery');
    assert.equal((await shownTitles(page)).length, 3);

    await page.goBack();
    assert.equal(new URL(page.url()).searchParams.get('genre'), null);
    assert.equal(await checkedGenre(page), 'all');
    assert.equal((await shownTitles(page)).length, 15);

    await page.goForward();
    assert.equal(await checkedGenre(page), 'mystery');
    assert.equal((await shownTitles(page)).length, 3);
  } finally {
    await context.close();
  }
});

test('criterion 7: loading books.html?genre=mystery shows the filtered list with the control matching', async () => {
  const { context, page, errors } = await openBooks('?genre=mystery');
  try {
    assert.equal(await checkedGenre(page), 'mystery');
    assert.equal((await shownTitles(page)).length, 3);
    assert.deepEqual(errors, []);
  } finally {
    await context.close();
  }
});

test('criterion 7: hostile ?genre=MYSTERY (case) is treated as mystery', async () => {
  const { context, page } = await openBooks('?genre=MYSTERY');
  try {
    assert.equal(await checkedGenre(page), 'mystery');
    assert.equal((await shownTitles(page)).length, 3);
  } finally {
    await context.close();
  }
});

test('criterion 7: hostile unknown or empty genre shows all books with All selected', async () => {
  for (const query of ['?genre=nonexistent', '?genre=']) {
    const { context, page, errors } = await openBooks(query);
    try {
      assert.equal(await checkedGenre(page), 'all', query);
      assert.equal((await shownTitles(page)).length, 15, query);
      assert.equal(await page.$eval('[aria-live]', (el) => el.textContent.trim()), 'Showing 15 of 15 books', query);
      assert.deepEqual(errors, [], query);
    } finally {
      await context.close();
    }
  }
});

test('criterion 7: hostile script in ?genre is never injected as HTML and raises no dialog', async () => {
  const payload = encodeURIComponent('<script>alert(1)</script>');
  const { context, page, errors, dialogs } = await openBooks(`?genre=${payload}`);
  try {
    assert.equal(await checkedGenre(page), 'all');
    assert.equal((await shownTitles(page)).length, 15);
    const inlineScripts = await page.evaluate(() => document.querySelectorAll('script:not([src])').length);
    assert.equal(inlineScripts, 0, 'no inline script may be injected from the URL');
    const markup = await page.evaluate(() => document.querySelector('main').innerHTML);
    assert.ok(!markup.includes('<script'), 'catalogue markup must not contain a script tag');
    assert.deepEqual(dialogs, []);
    assert.deepEqual(errors, []);
  } finally {
    await context.close();
  }
});

test('criterion 5: the genre filter is operable with the arrow keys once its group is reached', async () => {
  const { context, page } = await openBooks();
  try {
    await page.locator('.genre-filter input[value="all"]').focus();
    await page.keyboard.press('ArrowRight');
    assert.equal(await checkedGenre(page), 'mystery');
    assert.equal(new URL(page.url()).searchParams.get('genre'), 'mystery');
    assert.equal((await shownTitles(page)).length, 3);
  } finally {
    await context.close();
  }
});

test('criterion 7: ?genre with a space or a plus sign selects the multi-word genre', async () => {
  for (const query of ['?genre=literary%20fiction', '?genre=Literary+Fiction']) {
    const { context, page, errors } = await openBooks(query);
    try {
      assert.equal(await checkedGenre(page), 'literary-fiction', query);
      const genres = await page.$$eval('#book-list .book-genre', (els) => els.map((e) => e.textContent.trim()));
      assert.equal(genres.length, 3, query);
      assert.ok(
        genres.every((genre) => genre === 'Literary fiction'),
        query,
      );
      assert.deepEqual(errors, []);
    } finally {
      await context.close();
    }
  }
});

test('criterion 7: repeated ?genre parameters use the first value', async () => {
  const { context, page, errors } = await openBooks('?genre=mystery&genre=poetry');
  try {
    assert.equal(await checkedGenre(page), 'mystery');
    assert.equal((await shownTitles(page)).length, 3);
    assert.deepEqual(errors, []);
  } finally {
    await context.close();
  }
});

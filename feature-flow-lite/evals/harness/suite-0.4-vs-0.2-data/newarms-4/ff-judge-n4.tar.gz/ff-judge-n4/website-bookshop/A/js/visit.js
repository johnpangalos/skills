// Contact form validation for visit.html. Nothing is sent anywhere: this is a demo.
(function () {
  var form = document.getElementById("contact-form");
  var status = document.getElementById("form-status");
  var MIN_MESSAGE_LENGTH = 20;
  var EMAIL_PATTERN = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  var FIELDS = ["name", "email", "topic", "message"];

  var rules = {
    name: function (value) {
      return value ? "" : "Please enter your name.";
    },
    email: function (value) {
      if (!value) return "Please enter your email address.";
      return EMAIL_PATTERN.test(value)
        ? ""
        : "Please enter an email address like name@example.com.";
    },
    topic: function (value) {
      return value ? "" : "Please choose a topic.";
    },
    message: function (value) {
      if (!value) return "Please tell us what you need.";
      return value.length >= MIN_MESSAGE_LENGTH
        ? ""
        : "Please write at least " +
            MIN_MESSAGE_LENGTH +
            " characters so we can help.";
    },
  };

  // Shows or clears the inline error for one field. Returns true when the field is valid.
  function validate(field) {
    var message = rules[field.name](field.value.trim());
    var error = document.getElementById(field.id + "-error");
    var hint = document.getElementById(field.id + "-hint");
    var described = [];
    if (hint) described.push(hint.id);

    error.textContent = message;
    error.hidden = !message;
    if (message) {
      described.push(error.id);
      field.setAttribute("aria-invalid", "true");
    } else {
      field.removeAttribute("aria-invalid");
    }

    if (described.length) {
      field.setAttribute("aria-describedby", described.join(" "));
    } else {
      field.removeAttribute("aria-describedby");
    }
    return message === "";
  }

  form.addEventListener("submit", function (event) {
    event.preventDefault();
    var fields = FIELDS.map(function (id) {
      return document.getElementById(id);
    });
    var invalid = fields.filter(function (field) {
      return !validate(field);
    });

    if (invalid.length) {
      status.textContent = "";
      invalid[0].focus();
      return;
    }

    // Built with textContent so the visitor's name is shown as plain text.
    var name = document.getElementById("name").value.trim();
    status.textContent =
      "Thanks, " +
      name +
      " — this is a demo site, so your message wasn't sent anywhere.";
  });

  // Errors clear as soon as the field is corrected.
  ["input", "change"].forEach(function (type) {
    form.addEventListener(type, function (event) {
      if (event.target.hasAttribute("aria-invalid")) validate(event.target);
    });
  });
})();

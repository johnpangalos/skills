// Home page: featured books and the next upcoming event, both taken from js/data.js.
(function () {
  var data = window.MarginaliaData;
  var featuredBox = document.getElementById('featured-books');
  var teaser = document.getElementById('next-event');

  data.books.filter(function (book) {
    return book.featured;
  }).forEach(function (book) {
    var genre = data.genres.find(function (entry) {
      return entry.slug === book.genre;
    });
    featuredBox.appendChild(createBookItem(book, genre ? genre.name : ''));
  });

  var next = upcomingEvents(data.events, localTodayISO())[0];
  if (!next) {
    teaser.appendChild(makeElement('p', '', 'No upcoming events right now. Check back soon.'));
    return;
  }

  var time = makeElement('time', '', formatEventDate(next.date) + ', ' + formatClockTime(next.start));
  time.setAttribute('datetime', next.date + 'T' + next.start);
  var when = makeElement('p', 'event__when');
  when.appendChild(time);
  teaser.appendChild(makeElement('h3', '', next.title));
  teaser.appendChild(when);
  teaser.appendChild(makeElement('p', '', next.description));
})();

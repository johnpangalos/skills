'use strict';

const fs = require('node:fs');
const http = require('node:http');
const path = require('node:path');
const { chromium } = require('playwright');

const ROOT = path.resolve(__dirname, '..');
const VIEWPORT_HEIGHT = 900;
const NARROW = 360;
const WIDE = 1280;

// Every page on the site, in nav order. A new page goes here too.
const PAGES = [
  { file: 'index.html', label: 'Home' },
  { file: 'books.html', label: 'Books' },
  { file: 'events.html', label: 'Events' },
  { file: 'visit.html', label: 'Visit' },
];

const CONTENT_TYPES = {
  '.html': 'text/html; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.js': 'text/javascript; charset=utf-8',
};

function sendNotFound(res) {
  res.writeHead(404, { 'Content-Type': 'text/plain; charset=utf-8' });
  res.end('Not found');
}

// Serves the repo root on 127.0.0.1 on a random port. basePath mounts the
// site under a subpath so links can be checked when it is not at the origin.
function startServer(basePath = '') {
  const server = http.createServer(async (req, res) => {
    let pathname;
    try {
      pathname = decodeURIComponent(new URL(req.url, 'http://localhost').pathname);
    } catch {
      sendNotFound(res);
      return;
    }
    if (basePath) {
      if (pathname !== basePath && !pathname.startsWith(`${basePath}/`)) {
        sendNotFound(res);
        return;
      }
      pathname = pathname.slice(basePath.length) || '/';
    }
    const file = path.join(ROOT, pathname.endsWith('/') ? `${pathname}index.html` : pathname);
    if (!file.startsWith(ROOT + path.sep) || file.startsWith(path.join(ROOT, '.git') + path.sep)) {
      sendNotFound(res);
      return;
    }
    try {
      const body = await fs.promises.readFile(file);
      res.writeHead(200, { 'Content-Type': CONTENT_TYPES[path.extname(file)] || 'application/octet-stream' });
      res.end(body);
    } catch {
      sendNotFound(res);
    }
  });

  return new Promise((resolve) => {
    server.listen(0, '127.0.0.1', () => {
      const { port } = server.address();
      resolve({
        origin: `http://127.0.0.1:${port}`,
        close: () => new Promise((done) => {
          server.close(done);
          server.closeAllConnections();
        }),
      });
    });
  });
}

// A static server plus one headless Chromium. Each newPage() is a fresh context.
async function startSite({ basePath = '' } = {}) {
  const server = await startServer(basePath);
  const browser = await chromium.launch();
  const base = `${server.origin}${basePath}`;
  return {
    base,
    url: (file, query = '') => `${base}/${file}${query}`,
    async newPage({ width = WIDE, height = VIEWPORT_HEIGHT, reducedMotion = 'no-preference' } = {}) {
      const context = await browser.newContext({ viewport: { width, height }, reducedMotion });
      return context.newPage();
    },
    async close() {
      await browser.close();
      await server.close();
    },
  };
}

async function openPage(site, file, { query = '', width = WIDE, reducedMotion } = {}) {
  const page = await site.newPage({ width, reducedMotion });
  await page.goto(site.url(file, query), { waitUntil: 'load' });
  return page;
}

// Presses Tab until focus leaves the page and describes each stop in order.
async function tabStops(page, limit = 200) {
  const stops = [];
  for (let i = 0; i < limit; i += 1) {
    await page.keyboard.press('Tab');
    const stop = await page.evaluate(() => {
      const el = document.activeElement;
      if (!el || el === document.body) return null;
      const style = getComputedStyle(el);
      const backgrounds = [];
      for (let node = el; node; node = node.parentElement) {
        backgrounds.push(getComputedStyle(node).backgroundColor);
      }
      return {
        tag: el.tagName.toLowerCase(),
        text: el.textContent.trim().slice(0, 60),
        href: el.getAttribute('href'),
        inNav: Boolean(el.closest('header nav')),
        focusVisible: el.matches(':focus-visible'),
        outlineStyle: style.outlineStyle,
        outlineWidth: style.outlineWidth,
        outlineColor: style.outlineColor,
        backgrounds,
      };
    });
    if (!stop) break;
    stops.push(stop);
  }
  return stops;
}

module.exports = { ROOT, PAGES, NARROW, WIDE, startServer, startSite, openPage, tabStops };

// Client-side checks for the contact form. Nothing is sent anywhere: this is a demo.
const MESSAGE_LIMIT = 1000;
const EMAIL_PATTERN = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
const FIELDS = ["name", "email", "message"];
const DEMO_NOTICE =
  "Thanks for writing. This is a demo site, so your message was NOT sent. To reach the shop for real, email hello@marginalia-books.example or call +1 (555) 010-2345.";

const form = document.getElementById("contact-form");
const formStatus = document.getElementById("form-status");

function findProblem(field, value) {
  const text = value.trim();
  if (field === "name") return text ? "" : "Please enter your name.";
  if (field === "email") {
    if (!text) return "Please enter your email address.";
    return EMAIL_PATTERN.test(text)
      ? ""
      : "Please enter an email address like name@example.com.";
  }
  if (!text) return "Please enter a message.";
  return text.length > MESSAGE_LIMIT
    ? `Please keep your message to ${MESSAGE_LIMIT} characters or fewer.`
    : "";
}

function showProblem(field, problem) {
  const input = form.elements.namedItem(field);
  const error = document.getElementById(`${field}-error`);
  error.textContent = problem;
  input.setAttribute("aria-invalid", String(problem !== ""));
  if (problem) {
    input.setAttribute("aria-describedby", error.id);
  } else {
    input.removeAttribute("aria-describedby");
  }
  return problem === "";
}

function checkField(field) {
  const input = form.elements.namedItem(field);
  return showProblem(field, findProblem(field, input.value));
}

form.addEventListener("submit", (event) => {
  event.preventDefault();
  const invalid = FIELDS.filter((field) => !checkField(field));
  if (invalid.length > 0) {
    formStatus.textContent = "";
    form.elements.namedItem(invalid[0]).focus();
    return;
  }
  formStatus.textContent = DEMO_NOTICE;
});

// Once a field has an error, re-check it on every edit so the error clears as soon as it is fixed.
form.addEventListener("input", (event) => {
  const field = event.target.name;
  if (
    FIELDS.includes(field) &&
    event.target.getAttribute("aria-invalid") === "true"
  ) {
    checkField(field);
  }
});

# Marginalia Books

A static website for Marginalia Books, a fictional independent bookshop in Bristol. It has four pages: home, books, events and visit. The books catalogue can be filtered by genre, the events page hides events that have already passed, and the visit page has opening hours and a contact form.

Plain HTML, CSS and JavaScript. No build step, no npm dependencies, and no requests to any other origin (no CDNs, web fonts, analytics or remote images).

## Running the site locally

Either open `index.html` directly in a browser, or serve the folder over HTTP (recommended, because the books filter uses the URL query string and history):

```sh
npx http-server -p 8080 -c-1 .
```

Then visit http://localhost:8080/.

## Running the tests

The tests drive a headless Chromium through Playwright and serve the site from a small built-in HTTP server, so nothing else needs to be running. They expect Playwright to be installed globally. If `import('playwright')` cannot resolve, the runner falls back to the global npm root automatically, so `NODE_PATH` is not needed.

```sh
node tests/run.mjs            # every test
node tests/run.mjs books      # one page's tests (home, books, events, visit)
node tests/run.mjs site       # cross-page tests: nav, titles, copy, requests, console
```

The script prints a PASS or FAIL line for each test and exits with status 1 if any test fails.

## File layout

```
index.html          home page
books.html          catalogue with genre filter (state in ?genre=<slug>)
events.html         upcoming events
visit.html          opening hours, address, contact form
css/styles.css      shared styles
js/data.js          books, genres and events (edit content here)
js/main.js          shared behaviour: nav toggle, skip link, render helpers
js/home.js          home page featured books and next event
js/books.js         books page filter and catalogue
js/events.js        events page list
js/visit.js         contact form validation
tests/run.mjs       headless-browser tests
```

## Notes

- The contact form is a demo. It checks the fields in the browser and then tells the visitor that nothing was sent. It does not send the message anywhere, and it makes no network request.
- Event dates are compared with the visitor's local date, so an event disappears from the list once its day has passed.

import { createRequire } from "node:module";

// Playwright is installed globally, not in this repo. PLAYWRIGHT_PATH and CHROME_PATH override the defaults.
const require = createRequire(
  process.env.PLAYWRIGHT_PATH ?? "/opt/node-tools/node_modules/",
);
const { chromium } = require("playwright");

export const PAGES = ["index.html", "books.html", "events.html", "visit.html"];

export function launchBrowser() {
  return chromium.launch({
    executablePath: process.env.CHROME_PATH ?? "/usr/bin/google-chrome",
  });
}

// A fresh context whose requests and console errors are recorded.
export async function openTracked(
  browser,
  { width = 1280, height = 900 } = {},
) {
  const context = await browser.newContext({ viewport: { width, height } });
  const page = await context.newPage();
  const requests = [];
  const problems = [];
  page.on("request", (request) =>
    requests.push({ url: request.url(), method: request.method() }),
  );
  page.on("console", (message) => {
    if (message.type() === "error") problems.push(message.text());
  });
  page.on("pageerror", (error) => problems.push(error.message));
  return { page, requests, problems, close: () => context.close() };
}

// Requests that went to any origin other than the test server (data: URLs are inline, not network).
export function externalRequests(requests, origin) {
  return requests.filter(({ url }) => {
    const { protocol, origin: requestOrigin } = new URL(url);
    const isNetwork = protocol === "http:" || protocol === "https:";
    return isNetwork && requestOrigin !== origin;
  });
}

"use strict";

const { test, before, after } = require("node:test");
const assert = require("node:assert/strict");
const { PAGES, startSite } = require("./helpers/server");

let site;

before(async () => {
  site = await startSite();
});

after(async () => {
  await site.close();
});

function luminance(rgb) {
  const [r, g, b] = rgb
    .match(/\d+(\.\d+)?/g)
    .slice(0, 3)
    .map((value) => Number(value) / 255)
    .map((c) => (c <= 0.03928 ? c / 12.92 : ((c + 0.055) / 1.055) ** 2.4));
  return 0.2126 * r + 0.7152 * g + 0.0722 * b;
}

function contrast(foreground, background) {
  const [light, dark] = [luminance(foreground), luminance(background)].sort(
    (a, b) => b - a,
  );
  return (light + 0.05) / (dark + 0.05);
}

// Reads the computed text colour and the nearest opaque background for a selector.
function colorsFor(selector) {
  return (page) =>
    page.evaluate((sel) => {
      const el = document.querySelector(sel);
      if (!el) return null;
      let background = null;
      for (let node = el; node && !background; node = node.parentElement) {
        const value = getComputedStyle(node).backgroundColor;
        if (value !== "rgba(0, 0, 0, 0)" && value !== "transparent")
          background = value;
      }
      return {
        color: getComputedStyle(el).color,
        background: background || "rgb(255, 255, 255)",
      };
    }, selector);
}

for (const name of PAGES) {
  test(`${name}: lang, unique descriptive title, one h1, no skipped heading levels`, async () => {
    const info = await site.withPage(name, {}, (page) =>
      page.evaluate(() => ({
        lang: document.documentElement.lang,
        title: document.title,
        h1Count: document.querySelectorAll("h1").length,
        levels: Array.from(document.querySelectorAll("h1,h2,h3,h4,h5,h6")).map(
          (h) => Number(h.tagName[1]),
        ),
      })),
    );
    assert.equal(info.lang, "en");
    assert.ok(info.title.length >= 10, `title too short: "${info.title}"`);
    assert.equal(info.h1Count, 1);
    assert.equal(info.levels[0], 1);
    for (let i = 1; i < info.levels.length; i += 1) {
      assert.ok(
        info.levels[i] <= info.levels[i - 1] + 1,
        `heading level jumps at index ${i}`,
      );
    }
  });

  test(`${name}: skip link is the first focusable element, goes to main#main and shows on focus`, async () => {
    await site.withPage(name, {}, async (page) => {
      await page.keyboard.press("Tab");
      const first = await page.evaluate(() => ({
        text: document.activeElement.textContent.trim(),
        href: document.activeElement.getAttribute("href"),
        className: document.activeElement.className,
        top: document.activeElement.getBoundingClientRect().top,
        mainId: document.querySelector("main")?.id,
      }));
      assert.equal(first.className, "skip-link");
      assert.equal(first.href, "#main");
      assert.equal(first.mainId, "main");
      assert.ok(first.top >= 0, "skip link is off-screen when focused");
    });
  });

  test(`${name}: has header, labelled nav, one main and footer landmarks`, async () => {
    const landmarks = await site.withPage(name, {}, (page) =>
      page.evaluate(() => ({
        header: document.querySelectorAll("body > header").length,
        navLabel: document
          .querySelector("header nav")
          ?.getAttribute("aria-label"),
        main: document.querySelectorAll("main").length,
        footer: document.querySelectorAll("body > footer").length,
      })),
    );
    assert.deepEqual(landmarks, {
      header: 1,
      navLabel: "Main",
      main: 1,
      footer: 1,
    });
  });

  test(`${name}: every img has alt text and every svg is aria-hidden or labelled`, async () => {
    const problems = await site.withPage(name, {}, (page) =>
      page.evaluate(() => {
        const badImages = Array.from(document.querySelectorAll("img"))
          .filter((img) => !img.hasAttribute("alt"))
          .map((img) => img.outerHTML.slice(0, 80));
        const badSvgs = Array.from(document.querySelectorAll("svg"))
          .filter((svg) => {
            const labelled =
              svg.getAttribute("role") === "img" &&
              (svg.getAttribute("aria-label") || svg.querySelector("title"));
            return svg.getAttribute("aria-hidden") !== "true" && !labelled;
          })
          .map((svg) => svg.outerHTML.slice(0, 80));
        return [...badImages, ...badSvgs];
      }),
    );
    assert.deepEqual(problems, []);
  });

  test(`${name}: body text and link colours meet 4.5:1 contrast`, async () => {
    await site.withPage(name, {}, async (page) => {
      for (const selector of ["main p", "main a", "header nav a", "footer p"]) {
        const colors = await colorsFor(selector)(page);
        if (!colors) continue;
        const ratio = contrast(colors.color, colors.background);
        assert.ok(ratio >= 4.5, `${name} ${selector}: ${ratio.toFixed(2)}:1`);
      }
    });
  });
}

test("keyboard focus shows a visible focus-visible outline on links", async () => {
  await site.withPage("index.html", {}, async (page) => {
    await page.keyboard.press("Tab");
    await page.keyboard.press("Tab");
    const focused = await page.evaluate(() => {
      const el = document.activeElement;
      const style = getComputedStyle(el);
      return {
        tag: el.tagName,
        outlineStyle: style.outlineStyle,
        outlineWidth: parseFloat(style.outlineWidth),
      };
    });
    assert.equal(focused.tag, "A");
    assert.notEqual(focused.outlineStyle, "none");
    assert.ok(
      focused.outlineWidth >= 2,
      `outline width ${focused.outlineWidth}px`,
    );
  });
});

test("prefers-reduced-motion removes transitions and animations", async () => {
  const durationOf = (page) =>
    page.evaluate(() =>
      parseFloat(
        getComputedStyle(document.querySelector(".button")).transitionDuration,
      ),
    );

  const normal = await site.withPage("index.html", {}, durationOf);
  const reduced = await site.withPage(
    "index.html",
    { reducedMotion: "reduce" },
    durationOf,
  );
  assert.ok(
    normal > 0,
    "the .button should animate normally, so the test means something",
  );
  assert.ok(reduced <= 0.001, `reduced-motion transition is ${reduced}s`);
});

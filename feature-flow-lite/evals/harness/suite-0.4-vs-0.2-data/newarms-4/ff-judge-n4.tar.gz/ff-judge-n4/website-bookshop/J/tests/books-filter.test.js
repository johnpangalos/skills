'use strict';

// Criterion 3: genre filter, URL state, back/forward, hostile query values,
// and the zero-result message.

const { test, before, after } = require('node:test');
const assert = require('node:assert/strict');
const { startServer, launchBrowser, openPage } = require('./helpers/site');

let server;
let browser;
before(async () => {
  server = await startServer();
  browser = await launchBrowser();
});
after(async () => {
  await browser.close();
  await server.close();
});

// What the filter and list look like right now.
function readState(page) {
  return page.evaluate(() => {
    const checked = document.querySelector('input[name="genre"]:checked');
    const count = document.getElementById('result-count');
    return {
      checked: checked ? checked.labels[0].textContent.trim() : null,
      cards: [...document.querySelectorAll('.book-card')].map((c) => c.querySelector('.genre').textContent.trim()),
      count: count.textContent.trim(),
      live: count.getAttribute('aria-live'),
      search: location.search,
    };
  });
}

test('genre filter is a labelled radio group with All plus one option per genre in the data', async () => {
  const { page } = await openPage(browser, server.origin, 'books.html');
  const legend = await page.$eval('fieldset legend', (l) => l.textContent.trim());
  assert.ok(legend.length > 0, 'filter fieldset needs a legend');
  const labels = await page.$$eval('input[name="genre"]', (inputs) => inputs.map((i) => i.labels[0].textContent.trim()));
  const genres = await page.$$eval('.book-card .genre', (els) => [...new Set(els.map((el) => el.textContent.trim()))]);
  assert.deepEqual(labels, ['All', ...genres]);
});

test('choosing a genre shows only its books, All shows every book, count is in a polite live region', async () => {
  const { page } = await openPage(browser, server.origin, 'books.html');
  const total = (await readState(page)).cards.length;
  let state = await readState(page);
  assert.equal(state.checked, 'All');
  assert.equal(state.count, `Showing ${total} of ${total} books`);
  assert.equal(state.live, 'polite');
  await page.getByRole('radio', { name: 'Mystery', exact: true }).check();
  state = await readState(page);
  assert.ok(state.cards.length >= 2 && state.cards.every((g) => g === 'Mystery'), `cards: ${state.cards}`);
  assert.equal(state.count, `Showing ${state.cards.length} of ${total} books`);
  assert.equal(await page.locator('#no-results').isVisible(), false, 'no-match message shown with results');
  await page.getByRole('radio', { name: 'All', exact: true }).check();
  state = await readState(page);
  assert.equal(state.cards.length, total);
  assert.equal(state.search, '');
});

test('filter state lives in the URL and back/forward restores it', async () => {
  const { page } = await openPage(browser, server.origin, 'books.html');
  await page.getByRole('radio', { name: 'Mystery', exact: true }).check();
  assert.equal((await readState(page)).search, '?genre=Mystery');
  await page.getByRole('radio', { name: 'Poetry & Essays', exact: true }).check();
  assert.equal((await readState(page)).search, '?genre=Poetry%20%26%20Essays');
  await page.goBack();
  await page.waitForFunction(() => document.querySelector('input[name="genre"]:checked').labels[0].textContent.trim() === 'Mystery');
  assert.equal((await readState(page)).checked, 'Mystery');
  await page.goForward();
  await page.waitForFunction(() => document.querySelector('input[name="genre"]:checked').labels[0].textContent.trim() === 'Poetry & Essays');
  const state = await readState(page);
  assert.ok(state.cards.length >= 2 && state.cards.every((g) => g === 'Poetry & Essays'), `cards: ${state.cards}`);
});

test('loading ?genre=mystery pre-selects Mystery and shows only its books', async () => {
  const { page, log } = await openPage(browser, server.origin, 'books.html?genre=mystery');
  const state = await readState(page);
  assert.equal(state.checked, 'Mystery');
  assert.ok(state.cards.length >= 2 && state.cards.every((g) => g === 'Mystery'), `cards: ${state.cards}`);
  assert.deepEqual(log.errors, []);
});

// Hostile and round-trip query values. Each row: [name, path, expected control, expected genre or null for All].
const QUERY_CASES = [
  ['an unknown genre falls back to All', 'books.html?genre=unknown-genre', 'All', null],
  ['an empty genre falls back to All', 'books.html?genre=', 'All', null],
  ['an upper-case genre matches case-insensitively', 'books.html?genre=MYSTERY', 'Mystery', 'Mystery'],
  ['a script tag falls back to All without injection', 'books.html?genre=%3Cscript%3Ealert(1)%3C%2Fscript%3E', 'All', null],
  ['a name with a space round-trips', 'books.html?genre=Science%20Fiction', 'Science Fiction', 'Science Fiction'],
  ['a plus-encoded space round-trips', 'books.html?genre=Science+Fiction', 'Science Fiction', 'Science Fiction'],
  ['a name with an ampersand round-trips', 'books.html?genre=Poetry%20%26%20Essays', 'Poetry & Essays', 'Poetry & Essays'],
];

for (const [name, target, control, genre] of QUERY_CASES) {
  test(`?genre query: ${name}`, async () => {
    const { page, log } = await openPage(browser, server.origin, target);
    const state = await readState(page);
    assert.equal(state.checked, control);
    if (genre === null) {
      assert.equal(state.count, `Showing ${state.cards.length} of ${state.cards.length} books`);
    } else {
      assert.ok(state.cards.length >= 2 && state.cards.every((g) => g === genre), `cards: ${state.cards}`);
    }
    assert.deepEqual(log.errors, [], 'no console or page errors');
    const html = await page.content();
    assert.doesNotMatch(html, /alert\(1\)/, 'query value must not be injected into the page');
  });
}

test('a filter with zero matches shows a "No books match" message instead of an empty area', async () => {
  const page = await browser.newPage({ viewport: { width: 1280, height: 900 } });
  await page.route('**/js/books-data.js', (route) => route.fulfill({
    contentType: 'text/javascript',
    body: 'window.MARGINALIA_BOOKS = [];',
  }));
  await page.goto(`${server.origin}/books.html?genre=Mystery`, { waitUntil: 'load' });
  assert.equal(await page.locator('#no-results').isVisible(), true);
  assert.equal(await page.locator('#no-results').textContent(), 'No books match this genre.');
  const state = await readState(page);
  assert.equal(state.count, 'Showing 0 of 0 books');
  await page.close();
});

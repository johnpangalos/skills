// Headless browser tests for the Marginalia Books site.
// Usage: node tests/run.mjs [name-filter]
import http from 'node:http';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const PAGES = ['index.html', 'books.html', 'events.html', 'visit.html'];
const WIDTHS = [320, 360, 768, 1280];
const TYPES = {
  '.html': 'text/html; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.js': 'text/javascript; charset=utf-8'
};

let chromium;
try {
  ({ chromium } = await import('playwright'));
} catch {
  ({ chromium } = await import(process.env.PLAYWRIGHT_MODULE ?? '/opt/node-tools/node_modules/playwright/index.mjs'));
}

function startServer() {
  const server = http.createServer((req, res) => {
    const urlPath = new URL(req.url, 'http://localhost').pathname;
    const file = path.resolve(ROOT, urlPath === '/' ? 'index.html' : urlPath.slice(1));
    if (!file.startsWith(ROOT + path.sep) || !fs.existsSync(file) || fs.statSync(file).isDirectory()) {
      res.writeHead(404, { 'Content-Type': 'text/plain' });
      res.end('Not found');
      return;
    }
    res.writeHead(200, { 'Content-Type': TYPES[path.extname(file)] ?? 'application/octet-stream' });
    fs.createReadStream(file).pipe(res);
  });
  return new Promise((resolve) => server.listen(0, '127.0.0.1', () => resolve(server)));
}

function eq(actual, expected, label) {
  const a = JSON.stringify(actual);
  const b = JSON.stringify(expected);
  if (a !== b) throw new Error(`${label}: expected ${b}, got ${a}`);
}

function ok(condition, label) {
  if (!condition) throw new Error(label);
}

// Opens a fresh browser context on a page and records requests, console errors and dialogs.
async function session(browser, base, target, { width = 1280, height = 900, clock, timezoneId = 'Europe/London', reducedMotion = 'no-preference' } = {}) {
  const context = await browser.newContext({
    viewport: { width, height },
    timezoneId,
    reducedMotion
  });
  const page = await context.newPage();
  const s = { context, page, errors: [], requests: [], dialogs: [] };
  page.on('console', (msg) => { if (msg.type() === 'error') s.errors.push(msg.text()); });
  page.on('pageerror', (error) => s.errors.push(error.message));
  page.on('request', (req) => s.requests.push({ url: req.url(), method: req.method() }));
  page.on('dialog', (dialog) => { s.dialogs.push(dialog.message()); dialog.dismiss(); });
  if (clock) await page.clock.setFixedTime(new Date(clock));
  await page.goto(base + target);
  return s;
}

async function cardTitles(page, selector) {
  return page.$$eval(`${selector} h2, ${selector} h3`, (els) => els.map((el) => el.textContent));
}

async function waitForCards(page, count) {
  await page.waitForFunction((n) => document.querySelectorAll('#book-list > li').length === n, count);
}

const tests = [];
function test(name, fn) {
  tests.push({ name, fn });
}

test('nav, landmarks and footer on every page', async ({ browser, base }) => {
  for (const name of PAGES) {
    const s = await session(browser, base, name);
    try {
      const page = s.page;
      eq(await page.locator('html').getAttribute('lang'), 'en', `${name} lang`);
      eq(await page.$$eval('.site-nav a', (as) => as.map((a) => a.getAttribute('href'))), PAGES, `${name} nav links`);
      eq(await page.$$eval('.site-nav a[aria-current="page"]', (as) => as.map((a) => a.getAttribute('href'))), [name], `${name} aria-current`);
      eq(await page.locator('header a.brand').getAttribute('href'), 'index.html', `${name} brand link`);
      eq(await page.locator('header a.brand').textContent(), 'Marginalia Books', `${name} shop name`);
      for (const landmark of ['header', 'nav[aria-label="Main"]', 'main', 'footer']) {
        eq(await page.locator(landmark).count(), 1, `${name} ${landmark} landmark`);
      }
      eq(await page.locator('h1').count(), 1, `${name} h1 count`);
      ok((await page.locator('footer').innerText()).includes('Quill Lane'), `${name} footer address`);
      ok((await page.locator('footer').innerText()).includes('Open Tuesday'), `${name} footer hours`);
    } finally {
      await s.context.close();
    }
  }
});

test('nav toggle at 360px: mouse, keyboard, Escape and resize', async ({ browser, base }) => {
  const s = await session(browser, base, 'index.html', { width: 360, height: 740 });
  try {
    const page = s.page;
    const toggle = page.locator('button.nav-toggle');
    const nav = page.locator('#site-nav');
    eq(await toggle.getAttribute('aria-controls'), 'site-nav', 'aria-controls');
    eq(await toggle.getAttribute('aria-expanded'), 'false', 'initial aria-expanded');
    eq(await nav.isVisible(), false, 'nav hidden at 360 when closed');

    await toggle.click();
    eq(await nav.isVisible(), true, 'nav visible after click');
    eq(await toggle.getAttribute('aria-expanded'), 'true', 'aria-expanded after click');
    await toggle.click();
    eq(await nav.isVisible(), false, 'nav hidden after second click');

    await page.focus('button.nav-toggle');
    await page.keyboard.press('Enter');
    eq(await nav.isVisible(), true, 'nav visible after Enter');
    await page.keyboard.press('Escape');
    eq(await nav.isVisible(), false, 'nav hidden after Escape');
    eq(await toggle.getAttribute('aria-expanded'), 'false', 'aria-expanded after Escape');
    eq(await page.evaluate(() => document.activeElement.classList.contains('nav-toggle')), true, 'focus returns to toggle');

    await toggle.click();
    await page.setViewportSize({ width: 1280, height: 800 });
    await page.waitForFunction(() => !document.getElementById('site-nav').hidden);
    eq(await nav.isVisible(), true, 'nav always visible at wide width');
    eq(await toggle.isVisible(), false, 'toggle hidden at wide width');
    eq(await toggle.getAttribute('aria-expanded'), 'false', 'aria-expanded false at wide width when not opened');
    await page.setViewportSize({ width: 360, height: 740 });
    await page.waitForFunction(() => document.getElementById('site-nav').hidden);
    eq(await nav.isVisible(), false, 'nav closed again after returning to narrow');
    eq(await toggle.getAttribute('aria-expanded'), 'false', 'aria-expanded after returning to narrow');
    await toggle.click();
    eq(await nav.isVisible(), true, 'toggle still works after resize round trip');
  } finally {
    await s.context.close();
  }
});

test('books filter, result count and URL state', async ({ browser, base }) => {
  const s = await session(browser, base, 'books.html');
  try {
    const page = s.page;
    eq(await page.locator('#book-list > li').count(), 14, 'all books shown initially');
    eq(await page.$$eval('#genre option', (os) => os.map((o) => o.textContent)),
      ['All', 'History', 'Literary Fiction', 'Mystery', 'Nature', 'Poetry', 'Science Fiction'], 'genre options');
    eq(await page.locator('#result-count').getAttribute('aria-live'), 'polite', 'live region');
    eq(await page.locator('#result-count').textContent(), 'Showing 14 of 14 books', 'initial count');
    const historyBefore = await page.evaluate(() => history.length);

    await page.selectOption('#genre', 'Mystery');
    await waitForCards(page, 3);
    ok(page.url().endsWith('books.html?genre=mystery'), `url after filter: ${page.url()}`);
    eq(await page.locator('#result-count').textContent(), 'Showing 3 of 14 books in Mystery', 'filtered count');
    ok((await page.locator('#book-list .book-meta').allTextContents()).every((t) => t.endsWith('Mystery')), 'only Mystery books');

    // Arrow keys on the closed select fire change on each step; they must not add history entries.
    await page.selectOption('#genre', '');
    await waitForCards(page, 14);
    await page.focus('#genre');
    for (let i = 0; i < 3; i++) await page.keyboard.press('ArrowDown');
    await waitForCards(page, 3);
    eq(await page.inputValue('#genre'), 'Mystery', 'three ArrowDown presses reach Mystery');
    ok(page.url().endsWith('books.html?genre=mystery'), `url follows arrow keys: ${page.url()}`);
    eq(await page.evaluate(() => history.length), historyBefore, 'arrow keys add no history entries');

    await page.reload();
    await waitForCards(page, 3);
    eq(await page.inputValue('#genre'), 'Mystery', 'reload restores the filter');
    eq(await page.locator('#result-count').textContent(), 'Showing 3 of 14 books in Mystery', 'count restored on reload');
    eq(s.errors, [], 'console errors');
  } finally {
    await s.context.close();
  }
});

test('books ?genre= hostile values fall back, normalise or stay text', async ({ browser, base }) => {
  const cases = [
    ['books.html?genre=nonsense', '', 14],
    ['books.html?genre=', '', 14],
    ['books.html?genre=MYSTERY', 'Mystery', 3],
    ['books.html?genre=science%20fiction', 'Science Fiction', 3],
    ['books.html?genre=science-fiction', 'Science Fiction', 3],
    ['books.html?genre=mystery&genre=history', 'Mystery', 3],
    ['books.html?genre=<img src=x onerror=alert(1)>', '', 14]
  ];
  for (const [target, genre, count] of cases) {
    const s = await session(browser, base, target);
    try {
      const page = s.page;
      await waitForCards(page, count);
      eq(await page.inputValue('#genre'), genre, `${target} select value`);
      eq(await page.locator('#book-list > li').count(), count, `${target} card count`);
      eq(s.dialogs, [], `${target} dialogs`);
      eq(await page.locator('#book-list img, [onerror]').count(), 0, `${target} no injected markup`);
      eq(s.errors, [], `${target} console errors`);
    } finally {
      await s.context.close();
    }
  }
});

test('events split into upcoming and past using a fixed local clock', async ({ browser, base }) => {
  const s = await session(browser, base, 'events.html', { clock: '2026-11-17T10:00:00Z' });
  try {
    const page = s.page;
    const upcoming = await cardTitles(page, '#upcoming-list');
    eq(upcoming.length, 6, 'upcoming count on 2026-11-17');
    eq(upcoming[0], 'Candlelit Poetry Open Mic', 'today counts as upcoming and sorts first');
    ok(!upcoming.includes("Founders' Reading Night"), 'past event not in upcoming');
    eq(await page.locator('#past-events').isVisible(), true, 'past section visible');
    eq(await cardTitles(page, '#past-list'), ["Founders' Reading Night"], 'past events');
    eq(await page.locator('#upcoming-list time').first().getAttribute('datetime'), '2026-11-17T18:30', 'time datetime');
    eq(await page.locator('#no-upcoming').isVisible(), false, 'no-upcoming hidden when events exist');
    eq(s.errors, [], 'console errors');
  } finally {
    await s.context.close();
  }

  const late = await session(browser, base, 'events.html', { clock: '2027-01-05T10:00:00Z' });
  try {
    const page = late.page;
    eq(await cardTitles(page, '#upcoming-list'), [], 'no upcoming events when all are past');
    eq(await page.locator('#no-upcoming').textContent(), 'No upcoming events. Check back soon, or sign up for our newsletter at the counter.', 'all-past message');
    eq(await page.locator('#no-upcoming').isVisible(), true, 'all-past message visible');
    eq(await cardTitles(page, '#past-list').then((t) => t.length), 7, 'all seven events listed as past');
  } finally {
    await late.context.close();
  }

  // 00:10 on 2026-11-17 in Auckland is still 16 Nov in UTC, so this checks the visitor's local day.
  const auckland = await session(browser, base, 'events.html', { clock: '2026-11-17T00:10:00+13:00', timezoneId: 'Pacific/Auckland' });
  try {
    const page = auckland.page;
    const upcoming = await cardTitles(page, '#upcoming-list');
    eq(upcoming[0], 'Candlelit Poetry Open Mic', 'Auckland: event dated today is upcoming');
    ok(!upcoming.includes("Founders' Reading Night"), 'Auckland: past event not upcoming');
    eq(await cardTitles(page, '#past-list'), ["Founders' Reading Night"], 'Auckland: past events');
    eq(auckland.errors, [], 'Auckland: console errors');
  } finally {
    await auckland.context.close();
  }
});

test('home shows a message and no event items when none are upcoming', async ({ browser, base }) => {
  const busy = await session(browser, base, 'index.html', { clock: '2026-11-17T10:00:00Z' });
  try {
    eq(await busy.page.locator('#upcoming-list > li').count(), 3, 'home lists upcoming events in 2026');
    eq(await busy.page.locator('#no-upcoming').isVisible(), false, 'home message hidden while events are upcoming');
  } finally {
    await busy.context.close();
  }

  const s = await session(browser, base, 'index.html', { clock: '2027-01-05T10:00:00Z' });
  try {
    const page = s.page;
    eq(await page.locator('#upcoming-list > li').count(), 0, 'home lists no events in 2027');
    eq(await page.locator('#no-upcoming').isVisible(), true, 'home message visible in 2027');
    eq(await page.locator('#no-upcoming').textContent(), 'No upcoming events right now — check back soon, or see past events on the events page.', 'home message text');
    eq(await page.locator('#no-upcoming a').getAttribute('href'), 'events.html', 'home message links to events');
    eq(s.errors, [], 'console errors');
  } finally {
    await s.context.close();
  }
});

test('visit form validation: empty, whitespace, bad emails and long message', async ({ browser, base }) => {
  const s = await session(browser, base, 'visit.html');
  try {
    const page = s.page;
    const submit = page.locator('#contact-form button[type="submit"]');
    const fields = ['contact-name', 'contact-email', 'contact-topic', 'contact-message'];

    await submit.click();
    for (const id of fields) {
      eq(await page.locator(`#${id}`).getAttribute('aria-invalid'), 'true', `${id} aria-invalid`);
      eq(await page.locator(`#${id}`).getAttribute('aria-describedby'), `${id}-error`, `${id} describedby`);
      ok((await page.locator(`#${id}-error`).textContent()).length > 0, `${id} error text`);
    }
    eq(await page.evaluate(() => document.activeElement.id), 'contact-name', 'focus on first invalid field');
    eq(await page.locator('#form-summary').isVisible(), true, 'error summary visible');
    eq(await page.locator('#form-status').textContent(), '', 'no status on invalid submit');

    await page.fill('#contact-name', 'Ada');
    eq(await page.locator('#contact-name').getAttribute('aria-invalid'), null, 'name error cleared when fixed');
    eq(await page.locator('#contact-name-error').textContent(), '', 'name error text cleared');
    eq(await page.locator('#contact-email').getAttribute('aria-invalid'), 'true', 'other errors remain');
    eq(await page.locator('#form-summary').textContent(), 'Please fix 3 fields before sending.', 'summary count drops after a fix');
    await page.fill('#contact-email', 'ada@example.com');
    await page.selectOption('#contact-topic', 'events');
    eq(await page.locator('#form-summary').textContent(), 'Please fix 1 field before sending.', 'summary count singular');
    await page.fill('#contact-message', 'Hello');
    eq(await page.locator('#form-summary').isVisible(), false, 'summary hidden when no field is invalid');

    await page.fill('#contact-name', '    ');
    await page.fill('#contact-message', '   ');
    await submit.click();
    eq(await page.locator('#contact-name').getAttribute('aria-invalid'), 'true', 'whitespace name invalid');
    eq(await page.locator('#contact-message').getAttribute('aria-invalid'), 'true', 'whitespace message invalid');

    await page.fill('#contact-name', '​‌‍⁠﻿');
    await page.fill('#contact-message', '​');
    await submit.click();
    eq(await page.locator('#contact-name').getAttribute('aria-invalid'), 'true', 'invisible-only name invalid');
    eq(await page.locator('#contact-message').getAttribute('aria-invalid'), 'true', 'zero-width-only message invalid');
    eq(await page.locator('#form-status').textContent(), '', 'no status for invisible-only values');

    await page.fill('#contact-name', 'Ada');
    await page.selectOption('#contact-topic', 'events');
    for (const email of ['a b@c', 'foo@', '@bar.com']) {
      await page.fill('#contact-email', email);
      await page.fill('#contact-message', 'Hello');
      await submit.click();
      eq(await page.locator('#contact-email').getAttribute('aria-invalid'), 'true', `email "${email}" invalid`);
      eq(await page.locator('#form-status').textContent(), '', `no status for email "${email}"`);
    }

    await page.fill('#contact-email', 'ada@example.com');
    await page.fill('#contact-message', 'x'.repeat(5000));
    await submit.click();
    eq(await page.locator('#contact-message').getAttribute('aria-invalid'), 'true', 'long message invalid');
    ok((await page.locator('#contact-message-error').textContent()).includes('2000'), 'long message error names the limit');
    eq(s.requests.filter((r) => r.method !== 'GET').length, 0, 'no POST during validation');
  } finally {
    await s.context.close();
  }
});

test('visit form: HTML is never injected and a valid submit makes no request', async ({ browser, base }) => {
  const s = await session(browser, base, 'visit.html');
  try {
    const page = s.page;
    await page.fill('#contact-name', '<img src=x onerror=alert(1)>');
    await page.fill('#contact-email', 'ada@example.com');
    await page.selectOption('#contact-topic', 'other');
    await page.fill('#contact-message', 'Do you stock <b>bold</b> poetry?');
    const before = s.requests.length;
    await page.locator('#contact-form button[type="submit"]').click();
    await page.waitForFunction(() => document.getElementById('form-status').textContent !== '');

    const status = await page.locator('#form-status').textContent();
    ok(status.includes('<img src=x onerror=alert(1)>'), 'name shown as text');
    ok(status.includes('demo site') && status.includes("wasn't sent"), `demo message: ${status}`);
    ok(!/message (was )?sent|has been sent|we have received/i.test(status), 'never claims the message was sent');
    eq(await page.locator('#form-status').getAttribute('role'), 'status', 'status role');
    eq(await page.locator('#form-status img, #contact-form img').count(), 0, 'no injected img elements');
    eq(s.dialogs, [], 'no dialogs');
    const after = s.requests.slice(before).filter((r) => r.method !== 'GET' || !r.url.startsWith(base));
    eq(after, [], 'no network request on valid submit');
  } finally {
    await s.context.close();
  }
});

test('visit form submits with Enter', async ({ browser, base }) => {
  const s = await session(browser, base, 'visit.html');
  try {
    const page = s.page;
    await page.fill('#contact-name', 'Ben');
    await page.fill('#contact-email', 'ben@example.com');
    await page.selectOption('#contact-topic', 'visiting');
    await page.fill('#contact-message', 'Is the side door step-free?');
    await page.focus('#contact-email');
    await page.keyboard.press('Enter');
    await page.waitForFunction(() => document.getElementById('form-status').textContent !== '');
    ok((await page.locator('#form-status').textContent()).includes('Thanks, Ben'), 'Enter submits the form');
  } finally {
    await s.context.close();
  }
});

test('no horizontal overflow at 320, 360, 768 and 1280 on every page', async ({ browser, base }) => {
  for (const name of PAGES) {
    for (const width of WIDTHS) {
      const s = await session(browser, base, name, { width });
      try {
        const overflow = await s.page.evaluate(() => ({
          scroll: document.documentElement.scrollWidth,
          client: document.documentElement.clientWidth
        }));
        ok(overflow.scroll <= overflow.client, `${name} at ${width}px scrolls sideways (${overflow.scroll} > ${overflow.client})`);
        if (name === 'books.html' && width === 360) {
          const columns = await s.page.$eval('#book-list', (el) => getComputedStyle(el).gridTemplateColumns.split(' ').length);
          eq(columns, 1, 'catalogue grid is one column at 360px');
        }
      } finally {
        await s.context.close();
      }
    }
  }
});

test('no horizontal overflow at 320 and 360 with 200% root font size', async ({ browser, base }) => {
  for (const name of PAGES) {
    for (const width of [320, 360]) {
      const s = await session(browser, base, name, { width });
      try {
        await s.page.addStyleTag({ content: 'html { font-size: 200% !important; }' });
        const overflow = await s.page.evaluate(() => ({
          scroll: document.documentElement.scrollWidth,
          client: document.documentElement.clientWidth
        }));
        ok(overflow.scroll <= overflow.client, `${name} at ${width}px with 200% text scrolls sideways (${overflow.scroll} > ${overflow.client})`);
        if (name === 'books.html') {
          const box = await s.page.locator('#genre').boundingBox();
          ok(box && box.x >= 0 && box.x + box.width <= width, `${name} at ${width}px with 200% text: genre filter fits (${JSON.stringify(box)})`);
        }
      } finally {
        await s.context.close();
      }
    }
  }
});

test('skip link is first, visible on focus and points at main', async ({ browser, base }) => {
  const s = await session(browser, base, 'index.html');
  try {
    const page = s.page;
    await page.keyboard.press('Tab');
    eq(await page.evaluate(() => document.activeElement.className), 'skip-link', 'skip link focused first');
    const box = await page.locator('.skip-link').boundingBox();
    ok(box && box.x >= 0 && box.width > 0 && box.height > 0, 'skip link visible on focus');
    await page.keyboard.press('Enter');
    eq(await page.evaluate(() => location.hash), '#main', 'skip link target');
    eq(await page.evaluate(() => [...document.querySelectorAll('[tabindex]')].filter((el) => Number(el.getAttribute('tabindex')) > 0).length), 0, 'no positive tabindex');
  } finally {
    await s.context.close();
  }
});

test('reduced motion disables transitions', async ({ browser, base }) => {
  const s = await session(browser, base, 'index.html', { reducedMotion: 'reduce' });
  try {
    eq(await s.page.locator('.nav-toggle').evaluate((el) => getComputedStyle(el).transitionDuration), '0s', 'transition duration');
  } finally {
    await s.context.close();
  }
});

test('no external requests and no console errors on any page', async ({ browser, base }) => {
  for (const name of PAGES) {
    const s = await session(browser, base, name);
    try {
      await s.page.waitForLoadState('networkidle');
      const external = s.requests.filter((r) => !r.url.startsWith(base) && !r.url.startsWith('data:'));
      eq(external, [], `${name} external requests`);
      eq(s.errors, [], `${name} console errors`);
    } finally {
      await s.context.close();
    }
  }
});

const filter = process.argv[2];
const selected = tests.filter((t) => !filter || t.name.includes(filter));
if (selected.length === 0) {
  console.error(`No tests match "${filter}"`);
  process.exit(1);
}

const server = await startServer();
const base = `http://127.0.0.1:${server.address().port}/`;
let browser;
try {
  browser = await chromium.launch({ channel: 'chrome' });
} catch {
  browser = await chromium.launch({ executablePath: '/usr/bin/google-chrome' });
}

let failed = 0;
for (const t of selected) {
  try {
    await t.fn({ browser, base });
    console.log(`PASS ${t.name}`);
  } catch (error) {
    failed++;
    console.log(`FAIL ${t.name}\n  ${String(error.message).split('\n')[0]}`);
  }
}

await browser.close();
server.close();
console.log(`${selected.length - failed}/${selected.length} tests passed`);
process.exit(failed > 0 ? 1 : 0);

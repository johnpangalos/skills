'use strict';

// Shared test harness: a tiny static server on a random local port and a
// headless Chrome launched from the system install.

const fs = require('node:fs');
const http = require('node:http');
const path = require('node:path');
const { chromium } = require('playwright');

const ROOT = path.resolve(__dirname, '..', '..');
const CHROME = '/usr/bin/google-chrome';
const PAGES = ['index.html', 'books.html', 'events.html', 'visit.html'];
const TYPES = {
  '.html': 'text/html; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.js': 'text/javascript; charset=utf-8',
  '.svg': 'image/svg+xml',
  '.md': 'text/markdown; charset=utf-8',
};

function startServer() {
  const server = http.createServer((req, res) => {
    const requested = decodeURIComponent(new URL(req.url, 'http://localhost').pathname);
    const file = path.join(ROOT, requested === '/' ? 'index.html' : requested);
    if (!file.startsWith(ROOT + path.sep)) {
      res.writeHead(403).end();
      return;
    }
    fs.readFile(file, (err, body) => {
      if (err) {
        res.writeHead(404, { 'Content-Type': 'text/plain' }).end('Not found');
        return;
      }
      res.writeHead(200, { 'Content-Type': TYPES[path.extname(file)] || 'application/octet-stream' });
      res.end(body);
    });
  });
  return new Promise((resolve) => {
    server.listen(0, '127.0.0.1', () => {
      const { port } = server.address();
      resolve({
        origin: `http://127.0.0.1:${port}`,
        close: () => new Promise((done) => server.close(done)),
      });
    });
  });
}

function launchBrowser() {
  // Containers often run as root, which Chrome refuses without --no-sandbox.
  return chromium.launch({ executablePath: CHROME, args: ['--no-sandbox'] });
}

// Opens a page, records console errors, page errors, failed responses and
// every request so tests can assert on them.
async function openPage(browser, origin, target, width = 1280, options = {}) {
  const page = await browser.newPage({ viewport: { width, height: 900 }, ...options });
  const log = { errors: [], requests: [] };
  page.on('console', (msg) => {
    if (msg.type() === 'error') log.errors.push(msg.text());
  });
  page.on('pageerror', (err) => log.errors.push(String(err)));
  page.on('response', (res) => {
    if (res.status() >= 400) log.errors.push(`HTTP ${res.status()} ${res.url()}`);
  });
  page.on('request', (req) => log.requests.push({ url: req.url(), method: req.method() }));
  await page.goto(`${origin}/${target}`, { waitUntil: 'load' });
  return { page, log };
}

module.exports = { ROOT, PAGES, startServer, launchBrowser, openPage };

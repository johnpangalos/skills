# Marginalia Books

A static website for Marginalia Books, a fictional independent bookshop on Lantern Row. It has four pages:

- **Home** (`index.html`): a welcome, staff picks, the next event and visit details.
- **Books** (`books.html`): a catalogue of 15 titles across five genres, with a genre filter. The selected genre is kept in the URL (`books.html?genre=Mystery`), so a filtered list can be bookmarked or shared.
- **Events** (`events.html`): upcoming talks, readings and swaps, with free or ticketed status.
- **Visit** (`visit.html`): opening hours, the address, phone and email, and a contact form.

The site is plain HTML, CSS and JavaScript. There is no build step and no npm dependency to install. It makes no requests outside its own origin: no CDNs, web fonts or remote images. Book covers are drawn with CSS.

The contact form is a demo. It checks the fields in the browser and says so plainly. It does not send anything.

## Running locally

From the repository root, start any static file server. For example:

```sh
python3 -m http.server 8000
```

Then open <http://localhost:8000/>.

## Running the tests

The tests use Node's built-in test runner and drive headless Chrome through Playwright. They start their own static server on a random local port.

Playwright is not installed by this repo. It is expected to be resolvable through `NODE_PATH`. The test helper loads `playwright` by that name, and Chrome is expected at `/usr/bin/google-chrome`.

```sh
NODE_PATH=/opt/node-tools/node_modules npm test
```

Or without npm:

```sh
NODE_PATH=/opt/node-tools/node_modules node --test tests/*.test.js
```

The test files live in `tests/`. Shared test setup lives in `tests/helpers/site.js`.

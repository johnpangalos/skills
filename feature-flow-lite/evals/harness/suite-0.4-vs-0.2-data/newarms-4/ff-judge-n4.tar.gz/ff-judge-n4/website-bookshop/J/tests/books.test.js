'use strict';

// Criterion 2: the catalog content.

const { test, before, after } = require('node:test');
const assert = require('node:assert/strict');
const { startServer, launchBrowser, openPage } = require('./helpers/site');

let server;
let browser;
before(async () => {
  server = await startServer();
  browser = await launchBrowser();
});
after(async () => {
  await browser.close();
  await server.close();
});

test('catalog has at least 12 books, each with title, author, genre, price and a 1-2 sentence blurb', async () => {
  const { page } = await openPage(browser, server.origin, 'books.html');
  const books = await page.$$eval('.book-card', (cards) => cards.map((card) => ({
    title: card.querySelector('h2')?.textContent.trim() ?? '',
    author: card.querySelector('.author')?.textContent.trim() ?? '',
    genre: card.querySelector('.genre')?.textContent.trim() ?? '',
    price: card.querySelector('.price')?.textContent.trim() ?? '',
    blurb: card.querySelector('.blurb')?.textContent.trim() ?? '',
  })));
  assert.ok(books.length >= 12, `expected at least 12 books, found ${books.length}`);
  for (const book of books) {
    assert.ok(book.title && book.author && book.genre && book.price && book.blurb,
      `incomplete book: ${JSON.stringify(book)}`);
    assert.match(book.price, /^£\d+\.\d{2}$/, `price format for ${book.title}`);
    const sentences = book.blurb.split(/[.!?]+(\s|$)/).filter((s) => s.trim()).length;
    assert.ok(sentences >= 1 && sentences <= 2, `blurb for ${book.title} has ${sentences} sentences`);
    assert.doesNotMatch(`${book.title} ${book.author} ${book.blurb}`, /lorem ipsum/i);
  }
});

test('catalog has at least 4 genres and each genre has at least 2 books', async () => {
  const { page } = await openPage(browser, server.origin, 'books.html');
  const genres = await page.$$eval('.book-card .genre', (els) => els.map((el) => el.textContent.trim()));
  const counts = {};
  for (const genre of genres) counts[genre] = (counts[genre] || 0) + 1;
  const names = Object.keys(counts);
  assert.ok(names.length >= 4, `expected at least 4 genres, found ${names.length}: ${names.join(', ')}`);
  for (const name of names) {
    assert.ok(counts[name] >= 2, `genre ${name} has only ${counts[name]} book(s)`);
  }
});

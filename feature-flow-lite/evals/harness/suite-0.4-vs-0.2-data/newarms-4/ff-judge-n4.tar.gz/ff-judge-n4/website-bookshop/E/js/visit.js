/* Visit page: contact form validation. There is no backend, so a valid submit only shows a demo notice and an optional mailto link. */
(function () {
  'use strict';

  const EMAIL_PATTERN = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  const form = document.getElementById('contact-form');
  const status = document.getElementById('form-status');
  const mailWrap = document.getElementById('mailto-wrap');
  const mailLink = document.getElementById('mailto-link');

  const rules = [
    {
      id: 'name',
      check: function (value) {
        return value === '' ? 'Please enter your name.' : '';
      }
    },
    {
      id: 'email',
      check: function (value) {
        if (value === '') {
          return 'Please enter your email address.';
        }
        return EMAIL_PATTERN.test(value) ? '' : 'Please enter an email address like name@example.com.';
      }
    },
    {
      id: 'message',
      check: function (value) {
        return value === '' ? 'Please write a message.' : '';
      }
    }
  ];

  function fieldOf(id) {
    return document.getElementById('contact-' + id);
  }

  function valueOf(id) {
    return fieldOf(id).value.trim();
  }

  function validateRule(rule) {
    const input = fieldOf(rule.id);
    const error = document.getElementById(input.id + '-error');
    const message = rule.check(valueOf(rule.id));
    if (message) {
      input.setAttribute('aria-invalid', 'true');
      input.setAttribute('aria-describedby', error.id);
      error.textContent = message;
      error.hidden = false;
    } else {
      input.setAttribute('aria-invalid', 'false');
      input.removeAttribute('aria-describedby');
      error.textContent = '';
      error.hidden = true;
    }
    return message === '';
  }

  function showDemo() {
    const subject = valueOf('subject') || 'Website enquiry';
    const body = 'From: ' + valueOf('name') + ' <' + valueOf('email') + '>\n\n' + valueOf('message');
    mailLink.href = 'mailto:' + SITE_DATA.shop.email +
      '?subject=' + encodeURIComponent(subject) +
      '&body=' + encodeURIComponent(body);
    mailWrap.hidden = false;
    status.textContent = 'Demo only: this website has no server, so your message was not sent. ' +
      'To reach the shop, open the message in your email app with the link below.';
  }

  form.addEventListener('submit', function (event) {
    event.preventDefault();
    const invalid = rules.filter(function (rule) {
      return !validateRule(rule);
    });
    if (invalid.length > 0) {
      status.textContent = '';
      mailWrap.hidden = true;
      fieldOf(invalid[0].id).focus();
      return;
    }
    showDemo();
  });

  rules.forEach(function (rule) {
    fieldOf(rule.id).addEventListener('input', function () {
      if (fieldOf(rule.id).getAttribute('aria-invalid') === 'true') {
        validateRule(rule);
      }
    });
  });
})();

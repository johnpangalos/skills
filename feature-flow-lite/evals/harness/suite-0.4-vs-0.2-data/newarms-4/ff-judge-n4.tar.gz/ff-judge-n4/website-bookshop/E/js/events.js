/* Events page: every event dated today or later, in date order, using the user's local day. */
(function () {
  'use strict';

  const events = Marginalia.upcomingEvents();
  const list = document.getElementById('event-list');
  events.forEach(function (event) {
    list.appendChild(Marginalia.createEventItem(event));
  });
  list.hidden = events.length === 0;
  document.getElementById('events-empty').hidden = events.length > 0;
})();

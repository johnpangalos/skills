// Contact form checks. Nothing is sent: this is a demo site.
const EMAIL_PATTERN = /^[^\s@]+@[^\s@.]+(\.[^\s@.]+)+$/;
const MESSAGE_LIMIT = 2000;
const DEMO_NOTICE = 'This is a demo site, so your message was NOT sent. To reach us, email hello@marginalia-books.example or call 020 7946 0123 instead.';

function checkEmail(value) {
  const email = value.trim();
  if (!email) {
    return 'Please enter your email address.';
  }
  if (!EMAIL_PATTERN.test(email)) {
    return 'Please enter an email address that looks like name@example.com.';
  }
  return '';
}

function checkMessage(value) {
  const message = value.trim();
  if (!message) {
    return 'Please enter your message.';
  }
  if (message.length > MESSAGE_LIMIT) {
    return `Please keep your message to ${MESSAGE_LIMIT} characters or fewer.`;
  }
  return '';
}

const FIELDS = [
  { id: 'name', check: (value) => (value.trim() ? '' : 'Please enter your name.') },
  { id: 'email', check: checkEmail },
  { id: 'topic', check: (value) => (value ? '' : 'Please choose a topic.') },
  { id: 'message', check: checkMessage },
];

const form = document.getElementById('contact-form');
const summary = document.getElementById('form-summary');
const status = document.getElementById('form-status');

// Validates one field, shows or clears its error, and reports whether it passed.
function checkField(field) {
  const input = document.getElementById(field.id);
  const message = field.check(input.value);
  document.getElementById(`${field.id}-error`).textContent = message;
  input.setAttribute('aria-invalid', String(message !== ''));
  return message === '';
}

function reportSummary() {
  const count = document.querySelectorAll('[aria-invalid="true"]').length;
  summary.textContent = count ? `Please correct ${count} ${count === 1 ? 'field' : 'fields'} below.` : '';
}

form.addEventListener('submit', (event) => {
  event.preventDefault();
  status.textContent = '';
  const invalid = FIELDS.filter((field) => !checkField(field));
  reportSummary();
  if (invalid.length > 0) {
    document.getElementById(invalid[0].id).focus();
    return;
  }
  status.textContent = DEMO_NOTICE;
});

// Once a field is flagged, it is rechecked as the visitor types or chooses, so its error clears when fixed.
for (const field of FIELDS) {
  const input = document.getElementById(field.id);
  for (const type of ['input', 'change']) {
    input.addEventListener(type, () => {
      if (input.getAttribute('aria-invalid') === 'true') {
        checkField(field);
        reportSummary();
      }
    });
  }
}

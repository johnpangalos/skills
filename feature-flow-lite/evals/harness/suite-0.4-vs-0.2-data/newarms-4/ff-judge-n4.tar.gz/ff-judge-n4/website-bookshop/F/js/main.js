// Shared behaviour for every page: mobile nav disclosure and the footer year.
const header = document.querySelector(".site-header");
const toggle = document.querySelector(".nav-toggle");

document.documentElement.classList.add("js");
document.getElementById("year").textContent = String(new Date().getFullYear());

function setNavOpen(open) {
  header.classList.toggle("nav-open", open);
  toggle.setAttribute("aria-expanded", String(open));
}

toggle.addEventListener("click", () => {
  setNavOpen(!header.classList.contains("nav-open"));
});

// The toggle is hidden at 700px and up (see css/style.css), so close the menu there.
matchMedia("(min-width: 700px)").addEventListener("change", (event) => {
  if (event.matches) setNavOpen(false);
});

document.addEventListener("keydown", (event) => {
  if (event.key === "Escape" && header.classList.contains("nav-open")) {
    setNavOpen(false);
    toggle.focus();
  }
});

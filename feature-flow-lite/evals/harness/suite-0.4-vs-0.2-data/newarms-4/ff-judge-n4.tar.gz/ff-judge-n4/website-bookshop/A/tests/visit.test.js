"use strict";

const { test, before, after } = require("node:test");
const assert = require("node:assert/strict");
const { startSite } = require("./helpers/server");

let site;

before(async () => {
  site = await startSite();
});

after(async () => {
  await site.close();
});

const DAYS = [
  "Monday",
  "Tuesday",
  "Wednesday",
  "Thursday",
  "Friday",
  "Saturday",
  "Sunday",
];

// Reads the state of one form field and its error text, the way assistive tech would see it.
const fieldState = (page, id) =>
  page.evaluate((fieldId) => {
    const field = document.getElementById(fieldId);
    const describedBy = (field.getAttribute("aria-describedby") || "")
      .split(/\s+/)
      .filter(Boolean);
    const errorIds = describedBy.filter((ref) => ref.endsWith("-error"));
    const errorEl = errorIds.length
      ? document.getElementById(errorIds[0])
      : null;
    return {
      invalid: field.getAttribute("aria-invalid"),
      describedByError: errorIds.length > 0,
      errorText: errorEl ? errorEl.textContent.trim() : "",
      errorVisible: errorEl ? !errorEl.hidden : false,
      errorEl: document.getElementById(`${fieldId}-error`)
        ? !document.getElementById(`${fieldId}-error`).hidden
        : false,
    };
  }, id);

async function fillValid(page, overrides = {}) {
  const values = {
    name: "Ada Lovelace",
    email: "ada@example.com",
    topic: "Order a book",
    message: "Do you have any Poetry by Ruth Abernathy in stock?",
    ...overrides,
  };
  await page.fill("#name", values.name);
  await page.fill("#email", values.email);
  await page.selectOption("#topic", values.topic);
  await page.fill("#message", values.message);
}

test("hours table lists every day of the week with its opening hours", async () => {
  await site.withPage("visit.html", {}, async (page) => {
    const rows = await page.$$eval("table caption ~ tbody tr", (trs) =>
      trs.map((tr) => [
        tr.querySelector("th").textContent.trim(),
        tr.querySelector("td").textContent.trim(),
      ]),
    );
    assert.deepEqual(
      rows.map(([day]) => day),
      DAYS,
    );
    for (const [day, hours] of rows) {
      assert.ok(hours.length > 0, `${day} has no hours`);
    }
  });
});

test("the hours caption does not claim the shop is open all year round", async () => {
  await site.withPage("visit.html", {}, async (page) => {
    const caption = await page.textContent("table.hours caption");
    assert.doesNotMatch(caption, /all year round/i);
  });
});

test("the form status region is rendered before any submit so screen readers catch the first message", async () => {
  await site.withPage("visit.html", {}, async (page) => {
    const style = await page.evaluate(() => {
      const computed = getComputedStyle(document.getElementById("form-status"));
      return { display: computed.display, visibility: computed.visibility };
    });
    assert.notEqual(style.display, "none");
    assert.notEqual(style.visibility, "hidden");
    assert.equal(await page.getByRole("status").count(), 1);
  });
});

test("address is in an <address> element and directions and accessibility info are present", async () => {
  await site.withPage("visit.html", {}, async (page) => {
    const address = await page.textContent("address");
    assert.match(address, /Thistle Lane/);
    assert.match(address, /NM3 2QA/);
    const headings = await page.$$eval("h2, h3", (els) =>
      els.map((h) => h.textContent.trim()),
    );
    assert.ok(
      headings.some((h) => /Getting here/.test(h)),
      "missing Getting here heading",
    );
    assert.ok(
      headings.some((h) => /Accessib/.test(h)),
      "missing accessibility heading",
    );
  });
});

test("contact form has name, email, topic and message, each with a visible label, and required fields are marked in text", async () => {
  await site.withPage("visit.html", {}, async (page) => {
    for (const id of ["name", "email", "topic", "message"]) {
      const label = await page.evaluate((fieldId) => {
        const el = document.querySelector(`label[for="${fieldId}"]`);
        if (!el) return null;
        const style = getComputedStyle(el);
        return {
          text: el.textContent,
          visible: style.display !== "none" && style.visibility !== "hidden",
        };
      }, id);
      assert.ok(label, `no label for ${id}`);
      assert.equal(label.visible, true);
      assert.match(
        label.text,
        /required/i,
        `label for ${id} does not say required`,
      );
    }
  });
});

test("submitting an empty form marks every required field invalid, tied to its error, and focuses the first one", async () => {
  await site.withPage("visit.html", {}, async (page) => {
    await page.click('button[type="submit"]');
    for (const id of ["name", "email", "topic", "message"]) {
      const state = await fieldState(page, id);
      assert.equal(state.invalid, "true", `${id} not aria-invalid`);
      assert.equal(
        state.describedByError,
        true,
        `${id} not described by its error`,
      );
      assert.ok(state.errorText.length > 0, `${id} has no error text`);
      assert.equal(state.errorVisible, true, `${id} error hidden`);
    }
    assert.equal(await page.evaluate(() => document.activeElement.id), "name");
  });
});

test("whitespace-only name and message are invalid", async () => {
  await site.withPage("visit.html", {}, async (page) => {
    await fillValid(page, { name: "   ", message: "                    " });
    await page.click('button[type="submit"]');
    assert.equal((await fieldState(page, "name")).invalid, "true");
    assert.equal((await fieldState(page, "message")).invalid, "true");
    assert.equal(await page.evaluate(() => document.activeElement.id), "name");
  });
});

for (const email of ["a@b", "foo@", "foo bar@x.com"]) {
  test(`email "${email}" is rejected with an inline message`, async () => {
    await site.withPage("visit.html", {}, async (page) => {
      await fillValid(page, { email });
      await page.click('button[type="submit"]');
      const state = await fieldState(page, "email");
      assert.equal(state.invalid, "true");
      assert.match(state.errorText, /email/i);
      assert.equal(
        await page.evaluate(() => document.activeElement.id),
        "email",
      );
    });
  });
}

test("a message shorter than 20 characters is rejected with the minimum length in the error", async () => {
  await site.withPage("visit.html", {}, async (page) => {
    await fillValid(page, { message: "Hi there" });
    await page.click('button[type="submit"]');
    const state = await fieldState(page, "message");
    assert.equal(state.invalid, "true");
    assert.match(state.errorText, /at least 20 characters/);
  });
});

test("errors clear as soon as the field is corrected", async () => {
  await site.withPage("visit.html", {}, async (page) => {
    await page.click('button[type="submit"]');
    assert.equal((await fieldState(page, "name")).invalid, "true");
    await page.fill("#name", "Ada");
    const state = await fieldState(page, "name");
    assert.notEqual(state.invalid, "true");
    assert.equal(state.errorVisible, false);
    assert.equal(state.describedByError, false);
  });
});

test("a valid submit makes no network request and says plainly that the demo did not send the message", async () => {
  const requests = [];
  await site.withPage(
    "visit.html",
    {
      beforeGoto: (page) =>
        page.on("request", (request) => requests.push(request.url())),
    },
    async (page) => {
      await fillValid(page);
      const before = requests.length;
      await page.click('button[type="submit"]');
      const status = page.getByRole("status").filter({ hasText: "demo" });
      await status.waitFor();
      assert.equal(requests.length, before, "submit made a request");
      const text = await status.textContent();
      assert.equal(
        text,
        "Thanks, Ada Lovelace — this is a demo site, so your message wasn't sent anywhere.",
      );
      assert.doesNotMatch(
        text,
        /has been sent|was sent|we.ve received|message sent/i,
      );
    },
  );
});

test("a name containing HTML is shown as text in the confirmation and never runs", async () => {
  const dialogs = [];
  await site.withPage(
    "visit.html",
    {
      beforeGoto: (page) =>
        page.on("dialog", (dialog) => dialogs.push(dialog.message())),
    },
    async (page) => {
      const payload = "<img src=x onerror=alert(1)>";
      await fillValid(page, { name: payload });
      await page.click('button[type="submit"]');
      const status = page.getByRole("status").filter({ hasText: "demo" });
      await status.waitFor();
      assert.equal(await status.locator("img").count(), 0);
      assert.ok((await status.textContent()).includes(payload));
    },
  );
  assert.deepEqual(dialogs, []);
});

test("double submit produces one confirmation, not two", async () => {
  await site.withPage("visit.html", {}, async (page) => {
    await fillValid(page);
    await page.dblclick('button[type="submit"]');
    const status = page.getByRole("status").filter({ hasText: "demo" });
    await status.waitFor();
    const text = await page.textContent("#form-status");
    assert.equal(text.split("demo site").length - 1, 1);
  });
});

// Home page: a few featured books and the next upcoming events, from the same data as the other pages.
(function () {
  const featuredList = document.getElementById('featured-list');
  const upcomingList = document.getElementById('upcoming-list');
  const noUpcoming = document.getElementById('no-upcoming');

  function formatWhen(date, time) {
    const [year, month, day] = date.split('-').map(Number);
    const [hour, minute] = time.split(':').map(Number);
    return new Intl.DateTimeFormat('en-GB', {
      weekday: 'long',
      day: 'numeric',
      month: 'long',
      hour: 'numeric',
      minute: '2-digit'
    }).format(new Date(year, month - 1, day, hour, minute));
  }

  function featuredItem(book) {
    const item = document.createElement('li');
    item.className = 'book';

    const cover = document.createElement('div');
    cover.className = 'cover';
    cover.setAttribute('aria-hidden', 'true');
    cover.style.setProperty('--cover', book.cover);
    cover.textContent = book.title;

    const title = document.createElement('h3');
    title.textContent = book.title;

    const meta = document.createElement('p');
    meta.className = 'book-meta';
    meta.textContent = `${book.author} · ${book.genre}`;

    item.append(cover, title, meta);
    return item;
  }

  function eventItem(entry) {
    const item = document.createElement('li');
    item.className = 'event';

    const title = document.createElement('h3');
    title.textContent = entry.title;

    const when = document.createElement('p');
    when.className = 'event-when';
    const time = document.createElement('time');
    time.dateTime = `${entry.date}T${entry.time}`;
    time.textContent = formatWhen(entry.date, entry.time);
    when.append(time);

    item.append(title, when);
    return item;
  }

  const today = todayIso();
  const featured = BOOKS.filter((book) => book.featured).slice(0, 3);
  const upcoming = EVENTS
    .filter((entry) => entry.date >= today)
    .sort((a, b) => (a.date + a.time).localeCompare(b.date + b.time))
    .slice(0, 3);

  featuredList.replaceChildren(...featured.map(featuredItem));
  upcomingList.replaceChildren(...upcoming.map(eventItem));
  noUpcoming.hidden = upcoming.length > 0;
})();

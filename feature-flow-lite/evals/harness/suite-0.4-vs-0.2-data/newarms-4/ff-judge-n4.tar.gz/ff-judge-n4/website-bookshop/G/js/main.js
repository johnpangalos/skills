// Shared behaviour for every page: nav toggle, skip link, and helpers used by page scripts.
document.documentElement.classList.add('js');

(function () {
  var toggle = document.querySelector('.nav-toggle');
  var nav = document.getElementById('site-nav');

  toggle.addEventListener('click', function () {
    var open = !nav.classList.contains('is-open');
    nav.classList.toggle('is-open', open);
    toggle.setAttribute('aria-expanded', open ? 'true' : 'false');
  });

  document.addEventListener('keydown', function (event) {
    if (event.key === 'Escape' && nav.classList.contains('is-open')) {
      nav.classList.remove('is-open');
      toggle.setAttribute('aria-expanded', 'false');
      toggle.focus();
    }
  });

  document.querySelector('.skip-link').addEventListener('click', function (event) {
    event.preventDefault();
    var main = document.getElementById('main');
    main.focus();
    main.scrollIntoView();
  });
})();

// Creates an element with optional class name and text content. Text is set with textContent only.
function makeElement(tag, className, text) {
  var element = document.createElement(tag);
  if (className) {
    element.className = className;
  }
  if (text !== undefined) {
    element.textContent = text;
  }
  return element;
}

// Returns the visitor's local date as YYYY-MM-DD.
function localTodayISO() {
  var now = new Date();
  var month = String(now.getMonth() + 1).padStart(2, '0');
  var day = String(now.getDate()).padStart(2, '0');
  return now.getFullYear() + '-' + month + '-' + day;
}

// Keeps events on or after the given YYYY-MM-DD date.
function upcomingEvents(events, todayISO) {
  return events.filter(function (event) {
    return event.date >= todayISO;
  });
}

function formatPrice(amount) {
  return '£' + amount.toFixed(2);
}

function formatEventDate(isoDate) {
  return new Date(isoDate + 'T00:00:00Z').toLocaleDateString('en-GB', {
    weekday: 'long',
    day: 'numeric',
    month: 'long',
    year: 'numeric',
    timeZone: 'UTC'
  });
}

// Turns 24-hour HH:MM into a display time such as 7:00pm.
function formatClockTime(hhmm) {
  var parts = hhmm.split(':');
  var hour = Number(parts[0]);
  var suffix = hour < 12 ? 'am' : 'pm';
  var hour12 = hour % 12 === 0 ? 12 : hour % 12;
  return hour12 + ':' + parts[1] + suffix;
}

// Builds one book entry: decorative cover, title, author, genre, price and blurb.
function createBookItem(book, genreName) {
  var item = makeElement('li', 'book');
  var cover = makeElement('div', 'book__cover cover--' + book.genre);
  cover.setAttribute('aria-hidden', 'true');
  var body = makeElement('div', 'book__body');
  var meta = makeElement('p', 'book__meta');
  meta.appendChild(makeElement('span', 'book__genre', genreName));
  meta.appendChild(document.createTextNode(' · '));
  meta.appendChild(makeElement('span', 'book__price', formatPrice(book.price)));
  body.appendChild(makeElement('h3', 'book__title', book.title));
  body.appendChild(makeElement('p', 'book__author', 'by ' + book.author));
  body.appendChild(meta);
  body.appendChild(makeElement('p', 'book__blurb', book.blurb));
  item.appendChild(cover);
  item.appendChild(body);
  return item;
}

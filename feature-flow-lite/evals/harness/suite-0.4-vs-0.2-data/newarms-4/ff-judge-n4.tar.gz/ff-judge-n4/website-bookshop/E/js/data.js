/* Single source of content for the site: the catalogue, the events and the shop contact details.
   Every book and event is invented. Prices are in pounds sterling. */
const SITE_DATA = {
  shop: {
    email: 'hello@marginaliabooks.example'
  },
  books: [
    {
      title: 'The Clockmaker’s Alibi',
      author: 'Harriet Lowe',
      genre: 'Mystery',
      price: 9.99,
      staffPick: true,
      blurb: 'A watchmaker is found at the foot of the church tower with every clock in town stopped at ten past three. Inspector Ada Brand has until the Sunday market to learn who wound them back.'
    },
    {
      title: 'Low Tide at Saltmarsh Cove',
      author: 'Tomas Reyner',
      genre: 'Mystery',
      price: 11.5,
      staffPick: false,
      blurb: 'When the tide pulls back from Saltmarsh Cove it leaves a red wool glove, and a name nobody in the village will say aloud.'
    },
    {
      title: 'The Lodger on Ferris Street',
      author: 'Imogen Quarrie',
      genre: 'Mystery',
      price: 8.75,
      staffPick: false,
      blurb: 'A quiet boarding-house lodger keeps a ledger of everyone who comes and goes, and the ledger begins to matter to people who would rather it stayed closed.'
    },
    {
      title: 'Orbit of Small Things',
      author: 'Priya Vennard',
      genre: 'Science Fiction',
      price: 13,
      staffPick: true,
      blurb: 'On a salvage station circling a dying moon, a repair engineer finds a sealed letter addressed to a crew that was never assigned to the ship.'
    },
    {
      title: 'The Long Lantern Protocol',
      author: 'Sol Ibarra-Finch',
      genre: 'Science Fiction',
      price: 12.25,
      staffPick: false,
      blurb: 'A generation ship’s archivist must decide whether to wake the sleepers early, now that the star charts no longer match the sky outside.'
    },
    {
      title: 'Salt Hymnal',
      author: 'Rosalind Teague',
      genre: 'Literary Fiction',
      price: 14.5,
      staffPick: true,
      blurb: 'Three generations of a fishing family gather for a funeral and a long-postponed argument about who owns the boat.'
    },
    {
      title: 'Where the Orchard Ends',
      author: 'Elin Marrow',
      genre: 'Literary Fiction',
      price: 12.99,
      staffPick: false,
      blurb: 'A widowed cider-maker teaches her grandson to graft apple trees while the fields around the farm are sold off, one hedge at a time.'
    },
    {
      title: 'A Tidy House',
      author: 'Jonah Pell',
      genre: 'Literary Fiction',
      price: 10.99,
      staffPick: false,
      blurb: 'A translator moves back into her childhood home to sort her father’s papers, and finds that he kept a second set of letters.'
    },
    {
      title: 'Notes from the Night Shift',
      author: 'Mariam Osei',
      genre: 'Poetry',
      price: 9.5,
      staffPick: false,
      blurb: 'Poems written between ten at night and six in the morning: hospital corridors, bakeries before dawn, and the small mercy of a kettle that boils.'
    },
    {
      title: 'Field Guide to Other Weather',
      author: 'Callum Strand',
      genre: 'Poetry',
      price: 10,
      staffPick: true,
      blurb: 'A slim collection arranged like a weather diary, moving from hard frost in January to a late and improbable spring.'
    },
    {
      title: 'The Hedgerow Year',
      author: 'Wendy Thorsby',
      genre: 'Nature Writing',
      price: 16,
      staffPick: false,
      blurb: 'Month by month through a single English hedge: the birds that nest in it, the insects that work its flowers, and the people who laid it.'
    },
    {
      title: 'Tidewrack',
      author: 'Idris Ola',
      genre: 'Nature Writing',
      price: 15,
      staffPick: false,
      blurb: 'A beachcomber’s notebook on the things the sea gives back: driftwood, sea glass, bird bones and the occasional message in a bottle.'
    },
    {
      title: 'The Printers of Wrenfield',
      author: 'Edmund Caddick',
      genre: 'History',
      price: 19.99,
      staffPick: false,
      blurb: 'How one family of compositors kept a provincial town in print through two wars, a great flood and the arrival of the telephone.'
    },
    {
      title: 'Ration Books and Rose Gardens',
      author: 'Margaret Ilse Dunmore',
      genre: 'History',
      price: 17.5,
      staffPick: false,
      blurb: 'Life on the home front, told through the allotment diaries of the women who fed their streets when the shops ran short.'
    },
    {
      title: 'Pim and the Lighthouse Cat',
      author: 'Bea Holloway',
      genre: 'Young Readers',
      price: 7.99,
      staffPick: true,
      blurb: 'Pim finds a cat who can open any door, and together they set out to return a stolen lantern before the storm season begins.'
    },
    {
      title: 'The Secret Life of Umbrellas',
      author: 'Nadia Crane',
      genre: 'Young Readers',
      price: 6.5,
      staffPick: false,
      blurb: 'On a rainy street the umbrellas hold a meeting to decide which of them will carry the sun home for the night.'
    }
  ],
  events: [
    {
      title: 'Winter Reading Night',
      date: '2026-11-21',
      time: '19:00',
      booking: true,
      description: 'Five local writers read short pieces about the dark half of the year, followed by mulled cider and a chance to talk with the authors afterwards.'
    },
    {
      title: 'Saturday Story Hour',
      date: '2026-11-28',
      time: '10:30',
      booking: true,
      description: 'Picture books, a song and a basket of props for children aged three to six. Grown-ups stay for tea in the back room.'
    },
    {
      title: 'Poetry Open Mic',
      date: '2026-12-12',
      time: '18:30',
      booking: false,
      description: 'Bring up to three minutes of your own verse, or sit back and listen. The sign-up sheet opens at six on the night.'
    },
    {
      title: 'Cold Case Book Club',
      date: '2027-01-16',
      time: '18:30',
      booking: true,
      description: 'This month we read The Clockmaker’s Alibi and argue about who really did it. Copies go on the front table from early January.'
    },
    {
      title: 'Seed Swap and Nature Talk',
      date: '2027-02-13',
      time: '11:00',
      booking: false,
      description: 'Bring seeds, cuttings or spare bulbs to swap, then hear Wendy Thorsby talk about a year in one hedge. Free entry.'
    }
  ]
};

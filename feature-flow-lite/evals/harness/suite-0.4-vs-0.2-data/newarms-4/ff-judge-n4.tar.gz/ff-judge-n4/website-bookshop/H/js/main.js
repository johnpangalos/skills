// Behaviour shared by every page: the collapsible navigation and the skip link.
const toggle = document.querySelector('.nav-toggle');
const nav = document.getElementById('site-nav');
const main = document.getElementById('main');
const wide = window.matchMedia('(min-width: 701px)');

function setMenuOpen(open) {
  nav.classList.toggle('is-open', open);
  toggle.setAttribute('aria-expanded', String(open));
}

toggle.addEventListener('click', () => {
  setMenuOpen(toggle.getAttribute('aria-expanded') !== 'true');
});

document.addEventListener('keydown', (event) => {
  if (event.key !== 'Escape' || toggle.getAttribute('aria-expanded') !== 'true') {
    return;
  }
  setMenuOpen(false);
  toggle.focus();
});

// CSS already shows the links at wide sizes; resetting the state keeps the button consistent.
wide.addEventListener('change', (event) => {
  if (event.matches) {
    setMenuOpen(false);
  }
});

document.querySelector('.skip-link').addEventListener('click', (event) => {
  event.preventDefault();
  main.focus();
});

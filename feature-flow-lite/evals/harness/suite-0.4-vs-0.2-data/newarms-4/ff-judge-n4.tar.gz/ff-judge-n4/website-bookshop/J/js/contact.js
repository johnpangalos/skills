// Contact form: validates in the browser and shows a demo status. Nothing is sent.
(function () {
  'use strict';

  var EMAIL_PATTERN = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  var form = document.getElementById('contact-form');
  var status = document.getElementById('contact-status');

  var FIELDS = [
    {
      id: 'contact-name',
      check: function (value) {
        return value.trim() ? '' : 'Please enter your name.';
      },
    },
    {
      id: 'contact-email',
      check: function (value) {
        if (!value.trim()) return 'Please enter your email address.';
        return EMAIL_PATTERN.test(value.trim()) ? '' : 'Please enter an email address like name@example.com.';
      },
    },
    {
      id: 'contact-message',
      check: function (value) {
        return value.trim() ? '' : 'Please enter a message.';
      },
    },
  ];

  function showError(field, message) {
    var input = document.getElementById(field.id);
    var error = document.getElementById(field.id + '-error');
    input.setAttribute('aria-invalid', 'true');
    input.setAttribute('aria-describedby', error.id);
    error.textContent = message;
    error.hidden = false;
  }

  function clearError(field) {
    var input = document.getElementById(field.id);
    var error = document.getElementById(field.id + '-error');
    input.removeAttribute('aria-invalid');
    input.removeAttribute('aria-describedby');
    error.textContent = '';
    error.hidden = true;
  }

  function showDemoStatus() {
    var link = document.createElement('a');
    link.href = 'mailto:hello@marginalia.example';
    link.textContent = 'hello@marginalia.example';
    status.textContent = 'This is a demo form, so nothing was sent. To reach us for real, email ';
    status.appendChild(link);
    status.appendChild(document.createTextNode('.'));
  }

  form.addEventListener('submit', function (event) {
    event.preventDefault();
    var firstInvalid = null;
    FIELDS.forEach(function (field) {
      var input = document.getElementById(field.id);
      var message = field.check(input.value);
      if (message) {
        showError(field, message);
        if (!firstInvalid) firstInvalid = input;
      } else {
        clearError(field);
      }
    });
    if (firstInvalid) {
      status.textContent = '';
      firstInvalid.focus();
      return;
    }
    showDemoStatus();
  });
})();

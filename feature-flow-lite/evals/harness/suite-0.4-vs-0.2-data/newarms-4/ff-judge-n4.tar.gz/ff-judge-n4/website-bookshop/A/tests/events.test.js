"use strict";

const { test, before, after } = require("node:test");
const assert = require("node:assert/strict");
const { startSite } = require("./helpers/server");

let site;

before(async () => {
  site = await startSite();
});

after(async () => {
  await site.close();
});

const eventsInfo = (page) =>
  page.evaluate(() =>
    Array.from(document.querySelectorAll(".event")).map((event) => ({
      title: event.querySelector("h2")?.textContent.trim() || "",
      datetime: event.querySelector("time")?.getAttribute("datetime") || "",
      timeText: event.querySelector("time")?.textContent.trim() || "",
      description:
        event.querySelector(".event__description")?.textContent.trim() || "",
      location:
        event.querySelector(".event__location")?.textContent.trim() || "",
      past: event.classList.contains("event--past"),
      badge: event.textContent.includes("Past event"),
    })),
  );

test("at least five events, each with title, <time datetime>, description and location", async () => {
  await site.withPage("events.html", {}, async (page) => {
    const events = await eventsInfo(page);
    assert.ok(events.length >= 5, `only ${events.length} events`);
    for (const event of events) {
      assert.ok(event.title, "missing title");
      assert.match(
        event.datetime,
        /^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}$/,
        `bad datetime for ${event.title}`,
      );
      assert.ok(event.timeText, `missing time text for ${event.title}`);
      assert.ok(
        event.description.length > 60,
        `thin description for ${event.title}`,
      );
      assert.ok(event.location, `missing location for ${event.title}`);
    }
  });
});

test("events are in chronological order and fall in 2026 to 2027", async () => {
  await site.withPage(
    "events.html",
    { clock: new Date("2026-11-17T09:00:00") },
    async (page) => {
      const events = await eventsInfo(page);
      const times = events.map((event) => Date.parse(event.datetime));
      assert.deepEqual(
        [...times].sort((a, b) => a - b),
        times,
      );
      for (const event of events) {
        assert.match(event.datetime, /^202[67]-/);
      }
    },
  );
});

test("on 2026-11-17 no event is marked past", async () => {
  await site.withPage(
    "events.html",
    { clock: new Date("2026-11-17T09:00:00") },
    async (page) => {
      const events = await eventsInfo(page);
      assert.equal(
        events.filter((event) => event.past || event.badge).length,
        0,
      );
    },
  );
});

test("events before the local date are marked past and later ones are not", async () => {
  await site.withPage(
    "events.html",
    { clock: new Date("2026-12-07T09:00:00") },
    async (page) => {
      const events = await eventsInfo(page);
      for (const event of events) {
        const expectedPast = event.datetime.slice(0, 10) < "2026-12-07";
        assert.equal(event.past, expectedPast, `${event.title} past flag`);
        assert.equal(event.badge, expectedPast, `${event.title} badge`);
      }
    },
  );
});

test("an event on the user local calendar day is upcoming, even when UTC has already moved on", async () => {
  // 2026-11-28 20:00 in Los Angeles is 2026-11-29 04:00 UTC.
  await site.withPage(
    "events.html",
    {
      timezoneId: "America/Los_Angeles",
      clock: new Date("2026-11-28T20:00:00-08:00"),
    },
    async (page) => {
      const events = await eventsInfo(page);
      const today = events.find((event) =>
        event.datetime.startsWith("2026-11-28"),
      );
      const yesterday = events.find((event) =>
        event.datetime.startsWith("2026-11-21"),
      );
      assert.ok(today, "expected an event on 2026-11-28");
      assert.equal(today.past, false, "local-today event marked past");
      assert.equal(today.badge, false, "local-today event has past badge");
      assert.equal(yesterday.past, true, "earlier event should be past");
    },
  );
});

// Headless-browser tests for Marginalia Books.
// Usage: node tests/run.mjs [site|home|books|events|visit]
// With no argument every test runs. Exits 1 if any test fails.
import http from 'node:http';
import fs from 'node:fs';
import path from 'node:path';
import { createRequire } from 'node:module';
import { execSync } from 'node:child_process';
import { fileURLToPath } from 'node:url';

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const GROUPS = ['site', 'home', 'books', 'events', 'visit'];
const PAGES = [
  { id: 'home', file: 'index.html' },
  { id: 'books', file: 'books.html' },
  { id: 'events', file: 'events.html' },
  { id: 'visit', file: 'visit.html' }
];
const NAV_FILES = ['index.html', 'books.html', 'events.html', 'visit.html'];
const MOBILE = 360;
const TABLET = 768;
const DESKTOP = 1280;
const VIEWPORT_HEIGHT = 900;
const TODAY_NOON = '2026-11-17T12:00:00';

const TYPES = {
  '.html': 'text/html; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.js': 'text/javascript; charset=utf-8',
  '.svg': 'image/svg+xml',
  '.png': 'image/png'
};

async function loadChromium() {
  try {
    const mod = await import('playwright');
    return mod.chromium ?? mod.default.chromium;
  } catch {
    const globalRoot = execSync('npm root -g', { encoding: 'utf8' }).trim();
    const mod = createRequire(import.meta.url)(path.join(globalRoot, 'playwright'));
    return mod.chromium ?? mod.default.chromium;
  }
}

// Serves the repo root over HTTP on a random local port.
function serve() {
  const server = http.createServer((req, res) => {
    let pathname;
    try {
      pathname = decodeURIComponent(new URL(req.url, 'http://localhost').pathname);
    } catch {
      res.writeHead(400, { 'Content-Type': 'text/plain' }).end('Bad request');
      return;
    }
    const file = path.join(ROOT, pathname === '/' ? 'index.html' : pathname);
    if (!file.startsWith(ROOT + path.sep) || !fs.existsSync(file) || !fs.statSync(file).isFile()) {
      res.writeHead(404, { 'Content-Type': 'text/plain' }).end('Not found');
      return;
    }
    res.writeHead(200, { 'Content-Type': TYPES[path.extname(file)] ?? 'application/octet-stream' });
    fs.createReadStream(file).pipe(res);
  });
  return new Promise((resolve) => server.listen(0, '127.0.0.1', () => resolve(server)));
}

const tests = [];
function test(group, name, fn) {
  tests.push({ group, name, fn });
}

function expect(condition, message) {
  if (!condition) {
    throw new Error(message);
  }
}

function equal(actual, expected, message) {
  if (actual !== expected) {
    throw new Error(`${message}: expected ${JSON.stringify(expected)}, got ${JSON.stringify(actual)}`);
  }
}

// Opens a fresh browser context with a fixed clock and records console errors, requests and dialogs.
async function openSession(browser, base, { width = DESKTOP, now = TODAY_NOON } = {}) {
  const context = await browser.newContext({ viewport: { width, height: VIEWPORT_HEIGHT } });
  const page = await context.newPage();
  const session = { context, page, base, errors: [], requests: [], dialogs: [] };
  page.on('console', (msg) => {
    if (msg.type() === 'error') {
      session.errors.push(msg.text());
    }
  });
  page.on('pageerror', (err) => session.errors.push(err.message));
  page.on('request', (req) => session.requests.push(req.url()));
  page.on('dialog', (dialog) => {
    session.dialogs.push(dialog.message());
    dialog.dismiss();
  });
  await page.clock.setFixedTime(new Date(now));
  return session;
}

// Same as openSession, but with JavaScript disabled, for checking the no-script fallbacks.
async function openNoScriptSession(browser, base, { width = DESKTOP } = {}) {
  const context = await browser.newContext({ viewport: { width, height: VIEWPORT_HEIGHT }, javaScriptEnabled: false });
  const page = await context.newPage();
  const session = { context, page, base, errors: [], requests: [], dialogs: [] };
  page.on('pageerror', (err) => session.errors.push(err.message));
  page.on('request', (req) => session.requests.push(req.url()));
  return session;
}

async function visit(session, target) {
  const response = await session.page.goto(`${session.base}/${target}`, { waitUntil: 'load' });
  return response;
}

async function chooseGenre(page, slug) {
  await page.locator(`label.filter__option:has(input[value="${slug}"])`).click();
}

async function waitForCheckedGenre(page, slug) {
  await page.waitForFunction((wanted) => {
    const checked = [...document.querySelectorAll('input[name="genre"]')].find((input) => input.checked);
    return checked && checked.value === wanted;
  }, slug);
}

function visibleBookCount(page) {
  return page.locator('#book-list > li').count();
}

// Browser-side contrast inspection: text colour against its real backdrop, and border colour if drawn.
function inspectContrast(selectors) {
  const parse = (value) => {
    const parts = value.match(/[\d.]+/g).map(Number);
    return { r: parts[0], g: parts[1], b: parts[2], a: parts.length > 3 ? parts[3] : 1 };
  };
  const luminance = ({ r, g, b }) => {
    const channel = (v) => {
      const s = v / 255;
      return s <= 0.03928 ? s / 12.92 : ((s + 0.055) / 1.055) ** 2.4;
    };
    return 0.2126 * channel(r) + 0.7152 * channel(g) + 0.0722 * channel(b);
  };
  const ratio = (a, b) => {
    const hi = Math.max(luminance(a), luminance(b));
    const lo = Math.min(luminance(a), luminance(b));
    return (hi + 0.05) / (lo + 0.05);
  };
  const backdrop = (el) => {
    for (let node = el; node; node = node.parentElement) {
      const colour = parse(getComputedStyle(node).backgroundColor);
      if (colour.a > 0) {
        return colour;
      }
    }
    return { r: 255, g: 255, b: 255, a: 1 };
  };
  return selectors.map((selector) => {
    const el = document.querySelector(selector);
    if (!el) {
      return { selector, found: false };
    }
    const cs = getComputedStyle(el);
    const drawsBorder = parseFloat(cs.borderTopWidth) > 0 && cs.borderTopStyle !== 'none';
    return {
      selector,
      found: true,
      text: ratio(parse(cs.color), backdrop(el)),
      // A border is a boundary against the surface around the control, not against its own fill.
      border: drawsBorder ? ratio(parse(cs.borderTopColor), backdrop(el.parentElement ?? el)) : null
    };
  });
}

const CONTRAST_SELECTORS = {
  home: ['main .lead', '.section-link', '.link-grid a', '#featured-books .book__author', '#featured-books .book__meta', '#featured-books .book__blurb', '#next-event .event__when'],
  books: ['.filter legend', '.filter__option:not(:has(input:checked))', '.filter__option:has(input:checked)', '.book-count', '.book__author', '.book__meta', '.book__blurb'],
  events: ['.event h2', '.event__when', '.event__booking', '.event p:last-child'],
  visit: ['main .lead', '.hours th', '.hours td', 'address', 'main a', '.field label', '.field__hint', '.field input', '.field textarea', '.button']
};

// Lists every element a keyboard user can reach, in DOM order, skipping hidden elements and unchecked radios.
function countTabbable() {
  return [...document.querySelectorAll('a[href], button:not([disabled]), input:not([type="hidden"]), textarea, select, [tabindex]:not([tabindex="-1"])')]
    .filter((el) => el.getClientRects().length > 0 && !(el.type === 'radio' && !el.checked)).length;
}

function describeFocus() {
  const el = document.activeElement;
  const cs = getComputedStyle(el);
  return {
    label: `${el.tagName.toLowerCase()}${el.id ? '#' + el.id : ''}${el.className && typeof el.className === 'string' ? '.' + el.className.split(' ')[0] : ''}`,
    outlineStyle: cs.outlineStyle,
    outlineWidth: cs.outlineWidth
  };
}

// ---------------------------------------------------------------- site-wide tests

test('site', 'all four pages load with a 200 response', async (ctx) => {
  const s = await ctx.open();
  for (const page of PAGES) {
    const response = await visit(s, page.file);
    equal(response.status(), 200, `${page.file} status`);
  }
});

test('site', 'each page has a unique, descriptive title', async (ctx) => {
  const s = await ctx.open();
  const titles = [];
  for (const page of PAGES) {
    await visit(s, page.file);
    titles.push(await s.page.title());
  }
  expect(titles.every((t) => t.length >= 12 && t.includes('Marginalia')), `titles too short or unbranded: ${titles.join(' | ')}`);
  equal(new Set(titles).size, PAGES.length, `duplicate titles: ${titles.join(' | ')}`);
});

test('site', 'the nav markup is identical on every page apart from aria-current', async (ctx) => {
  const s = await ctx.open();
  const navs = [];
  for (const page of PAGES) {
    await visit(s, page.file);
    navs.push(await s.page.evaluate(() => document.querySelector('.site-header').outerHTML.replace(/ aria-current="page"/, '')));
  }
  expect(navs.every((nav) => nav === navs[0]), 'nav markup differs between pages');
});

test('site', 'every nav link resolves and aria-current marks only the current page', async (ctx) => {
  const s = await ctx.open();
  for (const page of PAGES) {
    await visit(s, page.file);
    const links = await s.page.$$eval('.site-nav__list a', (els) => els.map((a) => ({
      href: a.getAttribute('href'),
      current: a.getAttribute('aria-current')
    })));
    equal(links.length, NAV_FILES.length, `${page.file} nav link count`);
    for (const link of links) {
      const response = await visit(s, link.href);
      equal(response.status(), 200, `nav link ${link.href} from ${page.file}`);
      const current = await s.page.$eval('.site-nav__list a[aria-current="page"]', (a) => a.getAttribute('href'));
      equal(current, link.href, `aria-current on ${link.href}`);
    }
  }
});

test('site', 'no lorem ipsum or placeholder copy on any page', async (ctx) => {
  const s = await ctx.open();
  for (const page of PAGES) {
    await visit(s, page.file);
    const text = await s.page.evaluate(() => document.body.innerText);
    expect(!/lorem|ipsum|placeholder|coming soon|TODO|xxx/i.test(text), `${page.file} contains placeholder copy`);
  }
});

test('site', 'every request across load, filter and form use stays on the origin', async (ctx) => {
  const s = await ctx.open();
  for (const page of PAGES) {
    await visit(s, page.file);
  }
  await visit(s, 'books.html');
  await chooseGenre(s.page, 'poetry');
  await chooseGenre(s.page, 'childrens');
  await visit(s, 'visit.html');
  await s.page.fill('#name', 'Ada');
  await s.page.fill('#email', 'ada@example.com');
  await s.page.fill('#message', 'Do you stock poetry?');
  await s.page.click('button[type="submit"]');
  await s.page.waitForFunction(() => document.getElementById('form-status').textContent.length > 0);
  const external = s.requests.filter((url) => !url.startsWith(s.base) && !url.startsWith('data:'));
  equal(external.length, 0, 'requests leaving the origin');
});

test('site', 'every page loads with no console errors or uncaught exceptions', async (ctx) => {
  const s = await ctx.open();
  for (const page of PAGES) {
    await visit(s, page.file);
    await s.page.waitForLoadState('load');
    expect(s.errors.length === 0, `${page.file} logged: ${s.errors.join(' | ')}`);
  }
});

test('site', 'with JavaScript disabled at 360px the menu toggle is hidden, all four nav links show and nothing scrolls sideways', async (ctx) => {
  const s = await ctx.openNoScript({ width: MOBILE });
  for (const page of PAGES) {
    await visit(s, page.file);
    equal(await s.page.isVisible('.nav-toggle'), false, `${page.file} toggle visibility`);
    equal(await s.page.locator('.site-nav__list a:visible').count(), 4, `${page.file} visible nav links`);
    const scrollWidth = await s.page.evaluate(() => document.documentElement.scrollWidth);
    expect(scrollWidth <= MOBILE, `${page.file} scrollWidth ${scrollWidth} exceeds ${MOBILE}px`);
  }
});

// ---------------------------------------------------------------- per-page tests

for (const page of PAGES) {
  const group = page.id;

  test(group, 'structure: lang, viewport, one h1, landmarks, heading levels in order', async (ctx) => {
    const s = await ctx.open();
    await visit(s, page.file);
    const info = await s.page.evaluate(() => ({
      lang: document.documentElement.lang,
      viewport: document.querySelector('meta[name="viewport"]')?.getAttribute('content') ?? '',
      h1: document.querySelectorAll('h1').length,
      landmarks: ['header', 'nav', 'main', 'footer'].map((tag) => document.querySelectorAll(tag).length),
      headings: [...document.querySelectorAll('h1, h2, h3, h4, h5, h6')].map((h) => Number(h.tagName[1]))
    }));
    equal(info.lang, 'en', 'html lang');
    expect(info.viewport.includes('width=device-width'), `viewport meta: ${info.viewport}`);
    equal(info.h1, 1, 'h1 count');
    equal(info.landmarks.join(','), '1,1,1,1', 'header, nav, main, footer counts');
    equal(info.headings[0], 1, 'first heading level');
    for (let i = 1; i < info.headings.length; i++) {
      expect(info.headings[i] <= info.headings[i - 1] + 1, `heading level skips at index ${i}`);
    }
  });

  test(group, 'skip link is the first focusable element, shows on focus and moves focus to main', async (ctx) => {
    const s = await ctx.open({ width: DESKTOP });
    await visit(s, page.file);
    const hiddenBefore = await s.page.$eval('.skip-link', (a) => a.getBoundingClientRect().bottom <= 0);
    expect(hiddenBefore, 'skip link should be off-screen before focus');
    await s.page.keyboard.press('Tab');
    equal(await s.page.evaluate(() => document.activeElement.className), 'skip-link', 'first Tab stop');
    const box = await s.page.$eval('.skip-link', (a) => {
      const r = a.getBoundingClientRect();
      return { top: r.top, bottom: r.bottom };
    });
    expect(box.top >= 0 && box.bottom <= VIEWPORT_HEIGHT, `skip link not visible on focus: ${JSON.stringify(box)}`);
    await s.page.keyboard.press('Enter');
    equal(await s.page.evaluate(() => document.activeElement.id), 'main', 'focus after activating skip link');
  });

  test(group, 'focus indicator is visible on every keyboard-reachable element', async (ctx) => {
    const s = await ctx.open({ width: DESKTOP });
    await visit(s, page.file);
    const count = await s.page.evaluate(countTabbable);
    expect(count > 5, `too few tabbable elements found: ${count}`);
    await s.page.evaluate(() => document.activeElement.blur());
    for (let i = 0; i < count; i++) {
      await s.page.keyboard.press('Tab');
      const info = await s.page.evaluate(describeFocus);
      expect(info.outlineStyle !== 'none' && info.outlineWidth !== '0px', `no focus outline on ${info.label}`);
    }
  });

  test(group, 'nav toggles at 360px: aria-expanded and aria-controls update, Escape closes and returns focus', async (ctx) => {
    const s = await ctx.open({ width: MOBILE });
    await visit(s, page.file);
    const toggle = s.page.locator('.nav-toggle');
    equal(await toggle.getAttribute('aria-expanded'), 'false', 'initial aria-expanded');
    const controls = await toggle.getAttribute('aria-controls');
    equal(controls, 'site-nav', 'aria-controls');
    equal(await s.page.evaluate(() => getComputedStyle(document.getElementById('site-nav')).display), 'none', 'nav hidden when closed');
    await toggle.focus();
    await s.page.keyboard.press('Enter');
    equal(await toggle.getAttribute('aria-expanded'), 'true', 'aria-expanded after Enter');
    for (const link of await s.page.locator('.site-nav__list a').all()) {
      expect(await link.isVisible(), 'every nav link should be visible when the menu is open');
    }
    await s.page.keyboard.press('Tab');
    expect(await s.page.evaluate(() => document.activeElement.closest('#site-nav') !== null), 'Tab did not move into the open menu');
    await s.page.keyboard.press('Escape');
    equal(await toggle.getAttribute('aria-expanded'), 'false', 'aria-expanded after Escape');
    equal(await s.page.evaluate(() => getComputedStyle(document.getElementById('site-nav')).display), 'none', 'nav hidden after Escape');
    equal(await s.page.evaluate(() => document.activeElement.className), 'nav-toggle', 'focus returns to toggle after Escape');
  });

  test(group, 'at 768px the nav links show without the toggle', async (ctx) => {
    const s = await ctx.open({ width: TABLET });
    await visit(s, page.file);
    equal(await s.page.evaluate(() => getComputedStyle(document.querySelector('.nav-toggle')).display), 'none', 'toggle display at 768px');
    for (const link of await s.page.locator('.site-nav__list a').all()) {
      expect(await link.isVisible(), 'nav link hidden at 768px');
    }
  });

  test(group, 'nav links and toggle are at least 44x44 CSS pixels at 360px', async (ctx) => {
    const s = await ctx.open({ width: MOBILE });
    await visit(s, page.file);
    await s.page.click('.nav-toggle');
    const boxes = await s.page.$$eval('.nav-toggle, .site-nav__list a', (els) => els.map((el) => {
      const r = el.getBoundingClientRect();
      return { w: r.width, h: r.height, label: el.textContent.trim() };
    }));
    for (const box of boxes) {
      expect(box.w >= 44 && box.h >= 44, `${box.label} is ${box.w}x${box.h}`);
    }
  });

  test(group, 'no horizontal scrolling at 360px and layout holds at 768px and 1280px', async (ctx) => {
    for (const width of [MOBILE, TABLET, DESKTOP]) {
      const s = await ctx.open({ width });
      await visit(s, page.file);
      const scrollWidth = await s.page.evaluate(() => document.documentElement.scrollWidth);
      expect(scrollWidth <= width, `scrollWidth ${scrollWidth} exceeds ${width}px`);
      const fontSize = await s.page.evaluate(() => parseFloat(getComputedStyle(document.body).fontSize));
      expect(fontSize >= 16, `body font size ${fontSize}px`);
      await s.context.close();
    }
  });

  test(group, 'text and UI meet WCAG AA contrast (4.5:1 text, 3:1 borders)', async (ctx) => {
    const s = await ctx.open({ width: DESKTOP });
    await visit(s, page.file);
    const selectors = ['h1', '.site-name', '.site-nav__list a', '.nav-toggle', '.site-footer p', ...(CONTRAST_SELECTORS[group] ?? [])];
    const rows = await s.page.evaluate(inspectContrast, selectors);
    for (const row of rows) {
      expect(row.found, `selector not found: ${row.selector}`);
      expect(row.text >= 4.5, `${row.selector} text contrast ${row.text.toFixed(2)}:1`);
      if (row.border !== null) {
        expect(row.border >= 3, `${row.selector} border contrast ${row.border.toFixed(2)}:1`);
      }
    }
  });

  test(group, 'current nav link is visually distinguished from the others', async (ctx) => {
    const s = await ctx.open({ width: DESKTOP });
    await visit(s, page.file);
    const styles = await s.page.$$eval('.site-nav__list a', (els) => els.map((a) => {
      const cs = getComputedStyle(a);
      return { current: a.getAttribute('aria-current') === 'page', weight: cs.fontWeight, colour: cs.color, underline: cs.borderBottomColor };
    }));
    const current = styles.filter((s2) => s2.current);
    equal(current.length, 1, 'number of aria-current links');
    const others = styles.filter((s2) => !s2.current);
    expect(others.every((o) => o.colour !== current[0].colour || o.weight !== current[0].weight), 'current link looks like the others');
    expect(others.every((o) => o.underline !== current[0].underline), 'current link has no distinct underline');
  });
}

// ---------------------------------------------------------------- home

test('home', 'welcome copy, featured books from the data, next event teaser and links to other pages', async (ctx) => {
  const s = await ctx.open();
  await visit(s, 'index.html');
  const h1 = await s.page.textContent('h1');
  expect(h1.includes('Welcome'), `h1 is "${h1}"`);
  const data = await s.page.evaluate(() => window.MarginaliaData);
  const featured = data.books.filter((b) => b.featured).map((b) => b.title);
  expect(featured.length >= 3, 'data should have at least three featured books');
  const shown = await s.page.$$eval('#featured-books h3', (els) => els.map((h) => h.textContent));
  equal(shown.join('|'), featured.join('|'), 'featured titles rendered from data');
  const teaserTime = await s.page.getAttribute('#next-event time', 'datetime');
  equal(teaserTime, '2026-11-21T19:00', 'next event teaser time');
  for (const target of ['books.html', 'events.html', 'visit.html']) {
    const count = await s.page.locator(`main a[href="${target}"]`).count();
    expect(count >= 1, `no link to ${target} from the home page main content`);
  }
});

test('home', 'next event teaser moves on once the event has passed and says so when none are left', async (ctx) => {
  const s = await ctx.open({ now: '2026-11-22T09:00:00' });
  await visit(s, 'index.html');
  equal(await s.page.textContent('#next-event h3'), 'Poetry Night: Voices from the Estuary', 'teaser after the 21 Nov event');
  const late = await ctx.open({ now: '2027-02-01T09:00:00' });
  await visit(late, 'index.html');
  expect((await late.page.textContent('#next-event')).includes('No upcoming events right now'), 'teaser message when nothing is left');
});

// ---------------------------------------------------------------- books

test('books', 'catalogue has at least 12 books across at least 5 genres, two or more in each', async (ctx) => {
  const s = await ctx.open();
  await visit(s, 'books.html');
  const data = await s.page.evaluate(() => window.MarginaliaData);
  expect(data.books.length >= 12, `only ${data.books.length} books in data`);
  equal(await visibleBookCount(s.page), data.books.length, 'books rendered with All selected');
  const perGenre = {};
  for (const book of data.books) {
    perGenre[book.genre] = (perGenre[book.genre] ?? 0) + 1;
  }
  expect(Object.keys(perGenre).length >= 5, `only ${Object.keys(perGenre).length} genres`);
  for (const [genre, n] of Object.entries(perGenre)) {
    expect(n >= 2, `genre ${genre} has only ${n} book(s)`);
  }
});

test('books', 'each book shows title, author, genre, price and blurb; covers are aria-hidden', async (ctx) => {
  const s = await ctx.open();
  await visit(s, 'books.html');
  const cards = await s.page.$$eval('#book-list > li', (items) => items.map((li) => ({
    title: li.querySelector('h3')?.textContent ?? '',
    author: li.querySelector('.book__author')?.textContent ?? '',
    genre: li.querySelector('.book__genre')?.textContent ?? '',
    price: li.querySelector('.book__price')?.textContent ?? '',
    blurb: li.querySelector('.book__blurb')?.textContent ?? '',
    coverHidden: li.querySelector('.book__cover')?.getAttribute('aria-hidden') === 'true',
    images: li.querySelectorAll('img, svg').length
  })));
  expect(cards.length >= 12, 'cards rendered');
  for (const card of cards) {
    expect(card.title.length > 0 && card.author.startsWith('by '), `title/author missing on ${card.title}`);
    expect(card.genre.length > 0 && /^£\d+\.\d{2}$/.test(card.price), `genre/price missing on ${card.title}`);
    expect(card.blurb.length > 20, `blurb too short on ${card.title}`);
    expect(card.coverHidden, `cover not aria-hidden on ${card.title}`);
    equal(card.images, 0, `images in card ${card.title}`);
  }
});

test('books', 'genre filter is a labelled fieldset offering All plus every genre in the data', async (ctx) => {
  const s = await ctx.open();
  await visit(s, 'books.html');
  equal(await s.page.textContent('fieldset legend'), 'Filter by genre', 'legend');
  const labels = await s.page.$$eval('fieldset input[name="genre"]', (inputs) => inputs.map((input) => ({
    value: input.value,
    text: input.closest('label').textContent.trim()
  })));
  const data = await s.page.evaluate(() => window.MarginaliaData);
  const expected = ['all', ...data.genres.map((g) => g.slug)];
  equal(labels.map((l) => l.value).join(','), expected.join(','), 'radio values');
  equal(labels[0].text, 'All', 'first option label');
  for (const genre of data.genres) {
    equal(labels.find((l) => l.value === genre.slug).text, genre.name, `label for ${genre.slug}`);
  }
});

test('books', 'choosing each genre shows only its books and announces the count in a live region', async (ctx) => {
  const s = await ctx.open();
  await visit(s, 'books.html');
  const data = await s.page.evaluate(() => window.MarginaliaData);
  const liveAttrs = await s.page.getAttribute('#book-count', 'aria-live');
  equal(liveAttrs, 'polite', 'aria-live on count');
  equal(await s.page.getAttribute('#book-count', 'role'), 'status', 'role on count');
  for (const genre of data.genres) {
    await chooseGenre(s.page, genre.slug);
    const expectedCount = data.books.filter((b) => b.genre === genre.slug).length;
    equal(await visibleBookCount(s.page), expectedCount, `books shown for ${genre.slug}`);
    const genresShown = await s.page.$$eval('#book-list .book__genre', (els) => [...new Set(els.map((e) => e.textContent))]);
    equal(genresShown.join(','), genre.name, `genres shown for ${genre.slug}`);
    equal(await s.page.textContent('#book-count'), `Showing ${expectedCount} of ${data.books.length} books in ${genre.name}`, 'count announcement');
  }
});

test('books', 'All shows every book again and removes the genre parameter', async (ctx) => {
  const s = await ctx.open();
  await visit(s, 'books.html');
  await chooseGenre(s.page, 'poetry');
  await chooseGenre(s.page, 'all');
  const data = await s.page.evaluate(() => window.MarginaliaData);
  equal(await visibleBookCount(s.page), data.books.length, 'all books after All');
  equal(await s.page.textContent('#book-count'), `Showing ${data.books.length} of ${data.books.length} books`, 'count after All');
  equal(new URL(s.page.url()).search, '', 'query string after All');
});

test('books', 'choosing a genre sets ?genre=<slug> in the URL', async (ctx) => {
  const s = await ctx.open();
  await visit(s, 'books.html');
  await chooseGenre(s.page, 'essays');
  equal(new URL(s.page.url()).searchParams.get('genre'), 'essays', 'genre param after choosing essays');
});

test('books', 'loading books.html?genre=<slug> selects and applies that filter', async (ctx) => {
  const s = await ctx.open();
  await visit(s, 'books.html?genre=essays');
  equal(await s.page.isChecked('#genre-essays'), true, 'essays radio checked');
  equal(await visibleBookCount(s.page), 3, 'essays books shown');
  equal(await s.page.textContent('#book-count'), 'Showing 3 of 15 books in Essays', 'count for loaded genre');
});

test('books', 'Back and Forward restore the previous filter', async (ctx) => {
  const s = await ctx.open();
  await visit(s, 'books.html');
  await chooseGenre(s.page, 'poetry');
  await chooseGenre(s.page, 'essays');
  await s.page.goBack();
  await waitForCheckedGenre(s.page, 'poetry');
  equal(await visibleBookCount(s.page), 3, 'poetry restored on Back');
  await s.page.goBack();
  await waitForCheckedGenre(s.page, 'all');
  equal(await visibleBookCount(s.page), 15, 'All restored on second Back');
  await s.page.goForward();
  await waitForCheckedGenre(s.page, 'poetry');
  equal(new URL(s.page.url()).searchParams.get('genre'), 'poetry', 'URL restored on Forward');
});

test('books', 'hostile ?genre= (empty) falls back to All', async (ctx) => {
  const s = await ctx.open();
  await visit(s, 'books.html?genre=');
  equal(await s.page.isChecked('#genre-all'), true, 'All checked');
  equal(await visibleBookCount(s.page), 15, 'all books for empty genre');
  expect(s.errors.length === 0, `console errors: ${s.errors.join(' | ')}`);
});

test('books', 'hostile ?genre=NoSuchGenre falls back to All with no console error and no blank list', async (ctx) => {
  const s = await ctx.open();
  await visit(s, 'books.html?genre=NoSuchGenre');
  equal(await s.page.isChecked('#genre-all'), true, 'All checked for unknown genre');
  equal(await visibleBookCount(s.page), 15, 'all books for unknown genre');
  expect(s.errors.length === 0, `console errors: ${s.errors.join(' | ')}`);
});

test('books', 'hostile ?genre=POETRY and mixed case match case-insensitively', async (ctx) => {
  const s = await ctx.open();
  await visit(s, 'books.html?genre=POETRY');
  equal(await s.page.isChecked('#genre-poetry'), true, 'poetry checked for POETRY');
  equal(await visibleBookCount(s.page), 3, 'poetry books for POETRY');
  await visit(s, 'books.html?genre=Children%27s');
  equal(await s.page.isChecked('#genre-childrens'), true, "childrens checked for Children's");
  equal(await visibleBookCount(s.page), 3, "books for Children's");
  expect(s.errors.length === 0, `console errors: ${s.errors.join(' | ')}`);
});

test('books', 'hostile ?genre=<script>alert(1)</script> is neither executed nor injected', async (ctx) => {
  const s = await ctx.open();
  await visit(s, `books.html?genre=${encodeURIComponent('<script>alert(1)</script>')}`);
  await s.page.waitForTimeout(200);
  equal(s.dialogs.length, 0, 'dialogs opened by script');
  equal(await s.page.locator('#book-list script').count(), 0, 'script elements in list');
  expect(!(await s.page.evaluate(() => document.body.innerHTML)).includes('alert(1)'), 'payload reached the DOM');
  equal(await s.page.isChecked('#genre-all'), true, 'All checked');
  equal(await visibleBookCount(s.page), 15, 'all books shown');
  expect(s.errors.length === 0, `console errors: ${s.errors.join(' | ')}`);
});

test('books', 'hostile repeated ?genre=a&genre=b does not crash and still shows books', async (ctx) => {
  const s = await ctx.open();
  await visit(s, 'books.html?genre=poetry&genre=essays');
  expect((await visibleBookCount(s.page)) > 0, 'list is empty');
  expect(s.errors.length === 0, `console errors: ${s.errors.join(' | ')}`);
});

test('books', 'every filter state loads with no console errors', async (ctx) => {
  const s = await ctx.open();
  await visit(s, 'books.html');
  const data = await s.page.evaluate(() => window.MarginaliaData);
  for (const genre of ['all', ...data.genres.map((g) => g.slug)]) {
    await chooseGenre(s.page, genre);
    expect(s.errors.length === 0, `errors on ${genre}: ${s.errors.join(' | ')}`);
  }
});

test('books', 'genre filter labels are at least 44x44 at 360px and the page does not scroll sideways after filtering', async (ctx) => {
  const s = await ctx.open({ width: MOBILE });
  await visit(s, 'books.html');
  const boxes = await s.page.$$eval('.filter__option', (els) => els.map((el) => {
    const r = el.getBoundingClientRect();
    return { w: r.width, h: r.height, label: el.textContent.trim() };
  }));
  equal(boxes.length, 6, 'filter options');
  for (const box of boxes) {
    expect(box.w >= 44 && box.h >= 44, `${box.label} is ${box.w}x${box.h}`);
  }
  await chooseGenre(s.page, 'mystery');
  const scrollWidth = await s.page.evaluate(() => document.documentElement.scrollWidth);
  expect(scrollWidth <= MOBILE, `scrollWidth ${scrollWidth} after filtering`);
});

// ---------------------------------------------------------------- events

test('events', 'lists at least four upcoming events with title, time element, description and booking status', async (ctx) => {
  const s = await ctx.open();
  await visit(s, 'events.html');
  const items = await s.page.$$eval('#event-list > li', (lis) => lis.map((li) => ({
    title: li.querySelector('h2')?.textContent ?? '',
    datetime: li.querySelector('time')?.getAttribute('datetime') ?? '',
    when: li.querySelector('time')?.textContent ?? '',
    booking: li.querySelector('.event__booking')?.textContent ?? '',
    description: li.querySelector('article > p:last-child')?.textContent ?? ''
  })));
  expect(items.length >= 4, `only ${items.length} upcoming events`);
  for (const item of items) {
    expect(item.title.length > 0 && item.when.length > 0, `title or time missing on ${item.title}`);
    expect(/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}$/.test(item.datetime), `bad datetime "${item.datetime}" on ${item.title}`);
    expect(['Booking required', 'No booking needed'].includes(item.booking), `booking status "${item.booking}" on ${item.title}`);
    expect(item.description.length > 20, `description missing on ${item.title}`);
  }
});

test('events', 'never shows an event dated before the visitor\'s local date', async (ctx) => {
  const s = await ctx.open();
  await visit(s, 'events.html');
  const data = await s.page.evaluate(() => window.MarginaliaData);
  const shownDates = await s.page.$$eval('#event-list time', (els) => els.map((t) => t.getAttribute('datetime').slice(0, 10)));
  expect(shownDates.every((d) => d >= '2026-11-17'), `past date shown: ${shownDates.join(', ')}`);
  for (const event of data.events.filter((e) => e.date < '2026-11-17')) {
    const titles = await s.page.textContent('#event-list');
    expect(!titles.includes(event.title), `past event shown: ${event.title}`);
  }
});

test('events', 'an event drops off the list once its date has passed on the visitor\'s clock', async (ctx) => {
  const s = await ctx.open({ now: '2026-11-22T09:00:00' });
  await visit(s, 'events.html');
  equal(await s.page.textContent('#event-list h2'), 'Poetry Night: Voices from the Estuary', 'first event after 21 Nov');
});

test('events', 'shows a clear "No upcoming events" message when every event is past', async (ctx) => {
  const s = await ctx.open({ now: '2027-06-01T09:00:00' });
  await visit(s, 'events.html');
  equal(await s.page.locator('#event-list li').count(), 0, 'event items');
  equal(await s.page.isVisible('#no-events'), true, 'no-events message visible');
  expect((await s.page.textContent('#no-events')).startsWith('No upcoming events'), 'message text');
});

test('events', 'with every event past, the hidden event list computes to display none and the message shows', async (ctx) => {
  const s = await ctx.open({ now: '2030-01-01T09:00:00' });
  await visit(s, 'events.html');
  equal(await s.page.$eval('#event-list', (el) => getComputedStyle(el).display), 'none', 'event list display');
  equal(await s.page.isVisible('#no-events'), true, 'no-events message visible');
  expect((await s.page.textContent('#no-events')).startsWith('No upcoming events'), 'message text');
});

// ---------------------------------------------------------------- visit and contact form

test('visit', 'opening hours table covers all seven days with headers', async (ctx) => {
  const s = await ctx.open();
  await visit(s, 'visit.html');
  const headers = await s.page.$$eval('.hours thead th', (ths) => ths.map((th) => th.textContent));
  equal(headers.join(','), 'Day,Hours', 'table headers');
  const days = await s.page.$$eval('.hours tbody th', (ths) => ths.map((th) => th.textContent));
  equal(days.join(','), 'Monday,Tuesday,Wednesday,Thursday,Friday,Saturday,Sunday', 'days in order');
});

test('visit', 'address is in an address element; phone and email are tel and mailto links', async (ctx) => {
  const s = await ctx.open();
  await visit(s, 'visit.html');
  expect((await s.page.locator('address').count()) === 1, 'address element');
  expect((await s.page.locator('a[href^="tel:"]').count()) >= 1, 'tel link');
  expect((await s.page.locator('a[href^="mailto:"]').count()) >= 1, 'mailto link');
});

test('visit', 'each form field has a visible label bound by for/id, required text, and autocomplete', async (ctx) => {
  const s = await ctx.open();
  await visit(s, 'visit.html');
  const fields = await s.page.evaluate(() => ['name', 'email', 'message'].map((id) => {
    const label = document.querySelector(`label[for="${id}"]`);
    const input = document.getElementById(id);
    return {
      id,
      labelText: label ? label.textContent : '',
      required: input.required,
      type: input.type,
      autocomplete: input.getAttribute('autocomplete')
    };
  }));
  for (const field of fields) {
    expect(field.labelText.includes('(required)'), `${field.id} label does not say required: "${field.labelText}"`);
    expect(field.required, `${field.id} not required`);
  }
  equal(fields[0].autocomplete, 'name', 'name autocomplete');
  equal(fields[1].type, 'email', 'email type');
  equal(fields[1].autocomplete, 'email', 'email autocomplete');
});

test('visit', 'submitting an empty form shows an error per field, sets aria-invalid, and focuses the first invalid field', async (ctx) => {
  const s = await ctx.open();
  await visit(s, 'visit.html');
  await s.page.click('button[type="submit"]');
  const state = await s.page.evaluate(() => ['name', 'email', 'message'].map((id) => {
    const input = document.getElementById(id);
    return {
      id,
      invalid: input.getAttribute('aria-invalid'),
      describedBy: input.getAttribute('aria-describedby') ?? '',
      error: document.getElementById(`${id}-error`).textContent
    };
  }));
  for (const field of state) {
    equal(field.invalid, 'true', `${field.id} aria-invalid`);
    expect(field.describedBy.split(' ').includes(`${field.id}-error`), `${field.id} not described by its error`);
    expect(field.error.length > 0, `${field.id} has no error text`);
  }
  equal(state[0].error, 'Please enter your name.', 'name error text');
  equal(state[2].error, 'Please enter a message.', 'message error text');
  equal(await s.page.evaluate(() => document.activeElement.id), 'name', 'focus on first invalid field');
});

test('visit', 'whitespace-only name and message are rejected with exact error text', async (ctx) => {
  const s = await ctx.open();
  await visit(s, 'visit.html');
  await s.page.fill('#name', '   ');
  await s.page.fill('#email', 'ada@example.com');
  await s.page.fill('#message', '   \n  ');
  await s.page.click('button[type="submit"]');
  equal(await s.page.getAttribute('#name', 'aria-invalid'), 'true', 'name aria-invalid');
  equal(await s.page.textContent('#name-error'), 'Please enter your name.', 'name error');
  equal(await s.page.getAttribute('#message', 'aria-invalid'), 'true', 'message aria-invalid');
  equal(await s.page.textContent('#message-error'), 'Please enter a message.', 'message error');
  equal(await s.page.getAttribute('#email', 'aria-invalid'), null, 'valid email not flagged');
  equal(await s.page.textContent('#form-status'), '', 'no confirmation for invalid form');
});

test('visit', 'malformed emails "a@" and "foo" are rejected with exact error text', async (ctx) => {
  const s = await ctx.open();
  await visit(s, 'visit.html');
  await s.page.fill('#name', 'Ada');
  await s.page.fill('#message', 'Hello');
  for (const bad of ['a@', 'foo']) {
    await s.page.fill('#email', bad);
    await s.page.click('button[type="submit"]');
    equal(await s.page.getAttribute('#email', 'aria-invalid'), 'true', `aria-invalid for "${bad}"`);
    equal(await s.page.textContent('#email-error'), 'Please enter an email address in the form name@example.com.', `error for "${bad}"`);
    equal(await s.page.evaluate(() => document.activeElement.id), 'email', `focus for "${bad}"`);
  }
});

test('visit', 'errors clear as soon as the field is fixed', async (ctx) => {
  const s = await ctx.open();
  await visit(s, 'visit.html');
  await s.page.click('button[type="submit"]');
  await s.page.fill('#name', 'Ada Lovelace');
  equal(await s.page.getAttribute('#name', 'aria-invalid'), null, 'aria-invalid cleared');
  equal(await s.page.textContent('#name-error'), '', 'error text cleared');
  equal(await s.page.getAttribute('#name', 'aria-describedby'), 'name-hint', 'describedby reset to hint');
});

test('visit', 'a 10,000-character message is rejected with the stated limit and does not break layout at 360px', async (ctx) => {
  const s = await ctx.open({ width: MOBILE });
  await visit(s, 'visit.html');
  equal(await s.page.getAttribute('#message', 'maxlength'), '2000', 'maxlength attribute');
  await s.page.fill('#name', 'Ada');
  await s.page.fill('#email', 'ada@example.com');
  await s.page.evaluate(() => {
    const message = document.getElementById('message');
    message.value = 'x'.repeat(10000);
    message.dispatchEvent(new Event('input', { bubbles: true }));
  });
  await s.page.click('button[type="submit"]');
  equal(await s.page.getAttribute('#message', 'aria-invalid'), 'true', 'message aria-invalid');
  equal(await s.page.textContent('#message-error'), 'Please keep your message to 2000 characters or fewer. It is currently 10000.', 'length error text');
  equal(await s.page.textContent('#form-status'), '', 'no confirmation for over-long message');
  const scrollWidth = await s.page.evaluate(() => document.documentElement.scrollWidth);
  expect(scrollWidth <= MOBILE, `scrollWidth ${scrollWidth} with long message`);
});

test('visit', 'a valid submit shows a plain demo confirmation, focuses it, and sends no request', async (ctx) => {
  const s = await ctx.open();
  await visit(s, 'visit.html');
  await s.page.fill('#name', 'Ada');
  await s.page.fill('#email', 'ada@example.com');
  await s.page.fill('#message', 'Do you have a copy of Low Tide Sonnets?');
  const before = s.requests.length;
  await s.page.click('button[type="submit"]');
  await s.page.waitForFunction(() => document.getElementById('form-status').textContent.length > 0);
  const text = await s.page.textContent('#form-status');
  equal(text, "Thanks, Ada — this is a demo site, so your message wasn't sent anywhere. To reach us, email hello@marginaliabooks.example.", 'confirmation text');
  expect(!/has been sent|was sent|message sent|we've received|successfully sent/i.test(text), 'confirmation claims the message was sent');
  equal(await s.page.getAttribute('#form-status', 'role'), 'status', 'status role');
  equal(await s.page.evaluate(() => document.activeElement.id), 'form-status', 'focus moved to confirmation');
  equal(s.requests.length - before, 0, 'requests made during submit');
});

test('visit', 'double-clicking submit produces one confirmation', async (ctx) => {
  const s = await ctx.open();
  await visit(s, 'visit.html');
  await s.page.fill('#name', 'Ada');
  await s.page.fill('#email', 'ada@example.com');
  await s.page.fill('#message', 'Hello there');
  await s.page.dblclick('button[type="submit"]');
  await s.page.waitForFunction(() => document.getElementById('form-status').textContent.length > 0);
  await s.page.waitForTimeout(200);
  const count = await s.page.evaluate(() => (document.body.innerText.match(/Thanks,/g) ?? []).length);
  equal(count, 1, 'confirmations on the page');
});

test('visit', 'contrast holds for the form error state and field borders', async (ctx) => {
  const s = await ctx.open({ width: DESKTOP });
  await visit(s, 'visit.html');
  await s.page.click('button[type="submit"]');
  const [row] = await s.page.evaluate(inspectContrast, ['#name-error', '#name']);
  expect(row.text >= 4.5, `error text contrast ${row.text.toFixed(2)}:1`);
});

test('visit', 'with JavaScript disabled the contact form and its submit button are hidden and the email address is shown', async (ctx) => {
  const s = await ctx.openNoScript();
  await visit(s, 'visit.html');
  equal(await s.page.isVisible('#contact-form'), false, 'contact form visible without JavaScript');
  equal(await s.page.getByRole('button', { name: 'Send message' }).isVisible(), false, 'submit button visible without JavaScript');
  equal(await s.page.evaluate(() => {
    const note = [...document.querySelectorAll('noscript p')].find((p) => p.textContent.includes('This form needs JavaScript'));
    return note !== undefined && note.getBoundingClientRect().height > 0 && getComputedStyle(note).display !== 'none';
  }), true, 'noscript note rendered');
  equal(await s.page.locator('a[href^="mailto:"]').first().isVisible(), true, 'email link visible');
});

// ---------------------------------------------------------------- runner

const only = process.argv[2];
if (only && !GROUPS.includes(only)) {
  console.error(`Unknown group "${only}". Use one of: ${GROUPS.join(', ')}.`);
  process.exit(2);
}

const selected = tests.filter((t) => !only || t.group === only);
const server = await serve();
const base = `http://127.0.0.1:${server.address().port}`;
const chromium = await loadChromium();
const browser = await chromium.launch();
let passed = 0;
let failed = 0;

try {
  for (const t of selected) {
    const sessions = [];
    const ctx = {
      open: async (options) => {
        const session = await openSession(browser, base, options);
        sessions.push(session);
        return session;
      },
      openNoScript: async (options) => {
        const session = await openNoScriptSession(browser, base, options);
        sessions.push(session);
        return session;
      }
    };
    try {
      await t.fn(ctx);
      passed++;
      console.log(`PASS [${t.group}] ${t.name}`);
    } catch (err) {
      failed++;
      console.log(`FAIL [${t.group}] ${t.name}`);
      console.log(`     ${err.message.split('\n')[0]}`);
    } finally {
      await Promise.all(sessions.map((s) => s.context.close()));
    }
  }
} finally {
  await browser.close();
  server.close();
}

console.log(`\n${passed} passed, ${failed} failed, ${selected.length} total${only ? ` (group: ${only})` : ''}`);
process.exit(failed > 0 ? 1 : 0);

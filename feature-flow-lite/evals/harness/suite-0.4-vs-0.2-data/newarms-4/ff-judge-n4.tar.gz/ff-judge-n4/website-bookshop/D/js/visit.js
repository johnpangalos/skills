// Contact form validation. This is a demo: nothing is sent to a server.

const EMAIL_PATTERN = /^[^\s@]+@[^\s@.]+(\.[^\s@.]+)+$/;
const MAX_MESSAGE_LENGTH = 2000;
const FIELD_IDS = ['name', 'email', 'message'];
const DEMO_STATUS =
  "This is a demo site, so your message wasn't sent. To reach us, email hello@marginalia.example.";

const validators = {
  name: (value) => (value.trim() === '' ? 'Please enter your name.' : ''),
  email: (value) => {
    const email = value.trim();
    if (email === '') return 'Please enter your email address.';
    return EMAIL_PATTERN.test(email)
      ? ''
      : 'Please enter an email address like name@example.com.';
  },
  message: (value) => {
    if (value.trim() === '') return 'Please enter a message.';
    return value.length > MAX_MESSAGE_LENGTH
      ? `Your message must be ${MAX_MESSAGE_LENGTH} characters or fewer.`
      : '';
  },
};

const form = document.getElementById('contact-form');
const status = document.getElementById('form-status');

// Shows or clears the error for one field and returns true when it is valid.
function validateField(id) {
  const input = document.getElementById(id);
  const message = validators[id](input.value);
  document.getElementById(`${id}-error`).textContent = message;
  input.setAttribute('aria-invalid', message === '' ? 'false' : 'true');
  return message === '';
}

form.addEventListener('submit', (event) => {
  event.preventDefault();
  const invalid = FIELD_IDS.filter((id) => !validateField(id));
  if (invalid.length > 0) {
    status.textContent = '';
    document.getElementById(invalid[0]).focus();
    return;
  }
  status.textContent = DEMO_STATUS;
  status.focus();
});

form.addEventListener('input', (event) => {
  const { id } = event.target;
  if (
    FIELD_IDS.includes(id) &&
    event.target.getAttribute('aria-invalid') === 'true'
  ) {
    validateField(id);
  }
});

'use strict';

const { describe, it, before, after } = require('node:test');
const assert = require('node:assert/strict');
const { PAGES, startSite, openPage, tabStops } = require('./helpers');

describe('page structure and skip link (criterion 1)', () => {
  let site;
  before(async () => { site = await startSite(); });
  after(async () => { await site.close(); });

  it('gives each page lang="en", a viewport meta, one h1 and the shared landmarks', async () => {
    for (const { file } of PAGES) {
      const page = await openPage(site, file);
      const info = await page.evaluate(() => ({
        lang: document.documentElement.lang,
        viewport: document.querySelector('meta[name="viewport"]')?.getAttribute('content') ?? '',
        counts: [
          document.querySelectorAll('h1').length,
          document.querySelectorAll('header').length,
          document.querySelectorAll('nav[aria-label]').length,
          document.querySelectorAll('main#main').length,
          document.querySelectorAll('footer').length,
        ],
      }));
      assert.equal(info.lang, 'en', `${file} lang`);
      assert.match(info.viewport, /width=device-width/, `${file} viewport meta`);
      assert.deepEqual(info.counts, [1, 1, 1, 1, 1], `${file} h1, header, nav, main, footer counts`);
    }
  });

  it('gives every page a non-empty, unique, descriptive title', async () => {
    const titles = [];
    for (const { file } of PAGES) {
      const page = await openPage(site, file);
      titles.push(await page.title());
    }
    assert.ok(titles.every((title) => title.length > 10 && title.includes('Marginalia')), `titles: ${titles}`);
    assert.equal(new Set(titles).size, PAGES.length, `titles are not unique: ${titles}`);
  });

  for (const { file } of PAGES) {
    it(`${file}: the skip link is the first tab stop and moves focus to main`, async () => {
      const page = await openPage(site, file);
      const [first] = await tabStops(page, 1);
      assert.equal(first.tag, 'a');
      assert.equal(first.text, 'Skip to main content');
      assert.equal(first.href, '#main');
      await page.keyboard.press('Enter');
      assert.equal(await page.evaluate(() => document.activeElement.id), 'main');
      assert.equal(await page.getAttribute('main', 'tabindex'), '-1');
    });

    it(`${file}: the skip link is off-screen until focused, then visible inside the viewport`, async () => {
      const page = await openPage(site, file);
      const hidden = await page.locator('.skip-link').boundingBox();
      assert.ok(
        !hidden || hidden.y + hidden.height <= 0 || hidden.x + hidden.width <= 0,
        `skip link is on screen before focus: ${JSON.stringify(hidden)}`,
      );
      await page.keyboard.press('Tab');
      const shown = await page.locator('.skip-link').boundingBox();
      assert.ok(shown && shown.width > 0 && shown.height > 0, `focused skip link has no size: ${JSON.stringify(shown)}`);
      assert.ok(
        shown.x >= 0 && shown.y >= 0 && shown.y + shown.height <= 900,
        `focused skip link is outside the viewport: ${JSON.stringify(shown)}`,
      );
    });
  }
});

describe('internal links resolve (criterion 2)', () => {
  let site;
  before(async () => { site = await startSite(); });
  after(async () => { await site.close(); });

  it('resolves every internal link on every page with a 200', async () => {
    const origin = new URL(site.base).origin;
    for (const { file } of PAGES) {
      const page = await openPage(site, file);
      const hrefs = await page.$$eval('a[href]', (links) => links.map((a) => a.href));
      const internal = [...new Set(hrefs.map((href) => {
        const url = new URL(href);
        url.hash = '';
        return url.href;
      }))].filter((href) => href.startsWith(`${origin}/`));
      assert.ok(internal.length >= 4, `${file} has only ${internal.length} internal links`);
      for (const url of internal) {
        const res = await fetch(url);
        assert.equal(res.status, 200, `${file} links to ${url}`);
      }
    }
  });

  it('keeps every internal link working when the site is served from a subpath', async () => {
    const sub = await startSite({ basePath: '/marginalia' });
    try {
      const page = await openPage(sub, 'visit.html');
      const nav = await page.$$eval('header nav a', (links) => links.map((a) => a.href));
      assert.deepEqual(nav, PAGES.map(({ file }) => `${sub.base}/${file}`));
      const hrefs = await page.$$eval('a[href]', (links) => links.map((a) => a.href));
      const internal = [...new Set(hrefs.filter((href) => href.startsWith(`${sub.base}/`)))];
      for (const href of internal) {
        const res = await fetch(href.split('#')[0]);
        assert.equal(res.status, 200, `subpath: ${href}`);
      }
    } finally {
      await sub.close();
    }
  });
});

# Marginalia Books

A static website for Marginalia Books, a fictional independent bookshop on Chandler Lane in Wrenfield. It has a home page, a browsable catalogue with a genre filter, an events list, and a visit page with opening hours, directions and a contact form.

Everything is plain HTML, CSS and vanilla JavaScript. There is no build step, no npm dependency and no network request to any other origin: no CDNs, web fonts, analytics or remote images. The site also works when `index.html` is opened straight from disk.

## File layout

```
index.html        Home: introduction, staff picks, next events, calls to action
books.html        Catalogue with a genre filter (state kept in ?genre=)
events.html       Upcoming events in date order
visit.html        Opening hours, address, directions, contact details and form
css/styles.css    All styling (mobile-first, paper and ink palette)
js/data.js        Books, events and shop contact details (edit content here)
js/site.js        Shared helpers and the mobile menu
js/home.js        Home page: staff picks and next events
js/books.js       Catalogue filter, result count and URL state
js/events.js      Events list with the upcoming filter
js/visit.js       Contact form validation and demo submit
tests/run.mjs    Headless Chromium tests for the acceptance criteria
```

Each page repeats the same header, navigation and footer markup. When you change one, change all four pages.

## Viewing the site

Any static server works. From the repository root, for example:

```sh
python3 -m http.server 8080
# or
npx http-server -p 8080 .
```

Then open http://localhost:8080/ in a browser. You can also open `index.html` directly from the file system.

## Running the tests

The tests use Playwright, which must already be installed globally. They start their own static server on a free port, load every page in headless Chromium and exit non-zero on any failure.

```sh
NODE_PATH=$(npm root -g) node tests/run.mjs
```

To run a subset, pass a part of a test name:

```sh
NODE_PATH=$(npm root -g) node tests/run.mjs --grep form
```

## Notes

- The contact form has no backend. A valid submission says plainly that nothing was sent and offers a prefilled `mailto:` link to open in the reader's own email app.
- All book and event content is invented. Prices are in pounds sterling.

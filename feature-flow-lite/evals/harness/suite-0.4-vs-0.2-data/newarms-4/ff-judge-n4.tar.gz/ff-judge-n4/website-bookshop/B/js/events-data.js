// Marginalia Books events. Dates are local (YYYY-MM-DD) and times are 24-hour (HH:MM).
const EVENTS = [
  {
    title: "Founders' Reading Night",
    date: '2026-11-10',
    time: '19:00',
    bookingRequired: false,
    description: 'An evening of short readings from the shop\'s first year, with mulled cider and the founders in the back room.'
  },
  {
    title: 'Candlelit Poetry Open Mic',
    date: '2026-11-17',
    time: '18:30',
    bookingRequired: false,
    description: 'Bring a poem of up to three minutes, or simply come and listen. Candles, a microphone and a very patient host.'
  },
  {
    title: 'Mystery Book Club: The Long Quiet',
    date: '2026-11-21',
    time: '19:00',
    bookingRequired: true,
    description: 'This month we read Salt and Static companions and argue about who really sent the last message. Ten places, booked in advance.'
  },
  {
    title: "Children's Saturday Storytime",
    date: '2026-11-28',
    time: '10:30',
    bookingRequired: true,
    description: 'Stories, songs and a craft table for children aged three to seven. Accompanying adults are welcome to sit in.'
  },
  {
    title: 'Nature Writing Workshop',
    date: '2026-12-05',
    time: '14:00',
    bookingRequired: true,
    description: 'A two-hour session on keeping field notes, led by Ruth Ashdown. Bring a notebook and waterproof boots.'
  },
  {
    title: 'Local History Walk: The Mill Road',
    date: '2026-12-12',
    time: '11:00',
    bookingRequired: true,
    description: 'A guided walk past the old mill sites and canal locks, with reading from The Mill Town Ledgers. Allow ninety minutes.'
  },
  {
    title: 'Winter Gift Afternoon',
    date: '2026-12-19',
    time: '13:00',
    bookingRequired: false,
    description: 'Gift wrapping, a table of staff picks and hot chocolate by the fire. Drop in at any point during the afternoon.'
  }
];

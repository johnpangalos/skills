"use strict";

const { test, before, after } = require("node:test");
const assert = require("node:assert/strict");
const { PAGES, startSite } = require("./helpers/server");

let site;

before(async () => {
  site = await startSite();
});

after(async () => {
  await site.close();
});

const NARROW = { width: 360, height: 740 };

for (const name of PAGES) {
  test(`${name}: no sideways scroll at 360px or 1280px`, async () => {
    for (const viewport of [NARROW, { width: 1280, height: 800 }]) {
      const width = await site.withPage(name, { viewport }, (page) =>
        page.evaluate(() => document.documentElement.scrollWidth),
      );
      assert.ok(
        width <= viewport.width,
        `${name} at ${viewport.width}px scrolls to ${width}px`,
      );
    }
  });

  test(`${name}: no sideways scroll at 320px with normal text`, async () => {
    const width = await site.withPage(
      name,
      { viewport: { width: 320, height: 640 } },
      (page) => page.evaluate(() => document.documentElement.scrollWidth),
    );
    assert.ok(width <= 320, `${name} at 320px scrolls to ${width}px`);
  });

  test(`${name}: no sideways scroll at 360px with root font size 200%`, async () => {
    const width = await site.withPage(name, { viewport: NARROW }, (page) =>
      page
        .addStyleTag({ content: "html{font-size:200%}" })
        .then(() => page.evaluate(() => document.documentElement.scrollWidth)),
    );
    assert.ok(
      width <= NARROW.width,
      `${name} at 360px with 200% text scrolls to ${width}px`,
    );
  });

  test(`${name}: full nav is shown without a toggle at 768px`, async () => {
    const state = await site.withPage(
      name,
      { viewport: { width: 768, height: 900 } },
      (page) =>
        page.evaluate(() => ({
          toggle: getComputedStyle(document.querySelector(".nav-toggle"))
            .display,
          nav: getComputedStyle(document.getElementById("site-nav")).display,
          links: Array.from(document.querySelectorAll("#site-nav a")).every(
            (a) => a.getBoundingClientRect().height > 0,
          ),
        })),
    );
    assert.equal(state.toggle, "none");
    assert.notEqual(state.nav, "none");
    assert.equal(state.links, true);
  });
}

test("a malformed percent-encoded path gets a 400 and the server keeps serving", async () => {
  const malformed = await fetch(`${site.origin}/%E0%A4%A`);
  assert.equal(malformed.status, 400);
  const home = await fetch(`${site.origin}/index.html`);
  assert.equal(home.status, 200);
});

test("at 360px the nav collapses behind a toggle that reports aria-expanded and controls the nav", async () => {
  await site.withPage("index.html", { viewport: NARROW }, async (page) => {
    const before = await page.evaluate(() => ({
      toggleDisplay: getComputedStyle(document.querySelector(".nav-toggle"))
        .display,
      expanded: document
        .querySelector(".nav-toggle")
        .getAttribute("aria-expanded"),
      controls: document
        .querySelector(".nav-toggle")
        .getAttribute("aria-controls"),
      navDisplay: getComputedStyle(document.getElementById("site-nav")).display,
    }));
    assert.notEqual(before.toggleDisplay, "none");
    assert.equal(before.expanded, "false");
    assert.equal(before.controls, "site-nav");
    assert.equal(before.navDisplay, "none");

    await page.click(".nav-toggle");
    assert.equal(
      await page.getAttribute(".nav-toggle", "aria-expanded"),
      "true",
    );
    assert.notEqual(
      await page.evaluate(
        () => getComputedStyle(document.getElementById("site-nav")).display,
      ),
      "none",
    );
    await page
      .getByRole("link", { name: "Books", exact: true })
      .waitFor({ state: "visible" });
  });
});

test("the nav toggle is keyboard operable and Escape closes it and returns focus to the toggle", async () => {
  await site.withPage("books.html", { viewport: NARROW }, async (page) => {
    await page.focus(".nav-toggle");
    await page.keyboard.press("Enter");
    assert.equal(
      await page.getAttribute(".nav-toggle", "aria-expanded"),
      "true",
    );

    await page.keyboard.press("Tab");
    const insideNav = await page.evaluate(
      () => !!document.activeElement.closest("#site-nav"),
    );
    assert.equal(insideNav, true, "Tab should move into the open nav");

    await page.keyboard.press("Escape");
    assert.equal(
      await page.getAttribute(".nav-toggle", "aria-expanded"),
      "false",
    );
    assert.equal(
      await page.evaluate(
        () => getComputedStyle(document.getElementById("site-nav")).display,
      ),
      "none",
    );
    assert.equal(
      await page.evaluate(() => document.activeElement.className),
      "nav-toggle",
    );
  });
});

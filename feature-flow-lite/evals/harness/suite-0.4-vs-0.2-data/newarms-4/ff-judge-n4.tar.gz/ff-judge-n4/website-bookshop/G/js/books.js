// Books page: renders the genre filter and catalogue from js/data.js.
// The selected genre lives in the URL as ?genre=<slug>, so it can be bookmarked and restored with Back/Forward.
(function () {
  var data = window.MarginaliaData;
  var optionsBox = document.getElementById('genre-options');
  var list = document.getElementById('book-list');
  var count = document.getElementById('book-count');

  function findGenre(slug) {
    return data.genres.find(function (genre) {
      return genre.slug === slug;
    });
  }

  // Reads ?genre= and returns a known slug, or 'all' for anything missing or unrecognised.
  // Matching is case-insensitive and the value is only ever compared, never rendered as HTML.
  function genreFromUrl(search) {
    var wanted = (new URLSearchParams(search).get('genre') || '').trim().toLowerCase();
    var match = data.genres.find(function (genre) {
      return genre.slug === wanted || genre.name.toLowerCase() === wanted;
    });
    return match ? match.slug : 'all';
  }

  function urlForGenre(slug) {
    return window.location.pathname + (slug === 'all' ? '' : '?genre=' + encodeURIComponent(slug));
  }

  function renderFilterOptions() {
    var genres = [{ slug: 'all', name: 'All' }].concat(data.genres);
    genres.forEach(function (genre) {
      var label = makeElement('label', 'filter__option');
      var input = makeElement('input');
      input.type = 'radio';
      input.name = 'genre';
      input.id = 'genre-' + genre.slug;
      input.value = genre.slug;
      label.appendChild(input);
      label.appendChild(document.createTextNode(genre.name));
      optionsBox.appendChild(label);
    });
  }

  function showGenre(slug) {
    var visible = slug === 'all' ? data.books : data.books.filter(function (book) {
      return book.genre === slug;
    });
    var inputs = optionsBox.querySelectorAll('input');
    Array.prototype.forEach.call(inputs, function (input) {
      input.checked = input.value === slug;
    });
    list.textContent = '';
    visible.forEach(function (book) {
      var genre = findGenre(book.genre);
      list.appendChild(createBookItem(book, genre ? genre.name : ''));
    });
    var suffix = slug === 'all' ? '' : ' in ' + findGenre(slug).name;
    count.textContent = 'Showing ' + visible.length + ' of ' + data.books.length + ' books' + suffix;
  }

  renderFilterOptions();

  optionsBox.addEventListener('change', function (event) {
    var slug = event.target.value;
    window.history.pushState(null, '', urlForGenre(slug));
    showGenre(slug);
  });

  window.addEventListener('popstate', function () {
    showGenre(genreFromUrl(window.location.search));
  });

  var initial = genreFromUrl(window.location.search);
  window.history.replaceState(null, '', urlForGenre(initial));
  showGenre(initial);
})();

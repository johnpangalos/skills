// Contact form on the visit page. This is a demo: nothing is sent anywhere.
(function () {
  var MAX_MESSAGE = 2000;
  var EMAIL_PATTERN = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  var form = document.getElementById('contact-form');
  var status = document.getElementById('form-status');
  var fields = ['name', 'email', 'message'].map(function (id) {
    return document.getElementById(id);
  });

  var rules = {
    name: function (value) {
      return value.trim() ? '' : 'Please enter your name.';
    },
    email: function (value) {
      return EMAIL_PATTERN.test(value.trim()) ? '' : 'Please enter an email address in the form name@example.com.';
    },
    message: function (value) {
      if (!value.trim()) {
        return 'Please enter a message.';
      }
      if (value.length > MAX_MESSAGE) {
        return 'Please keep your message to ' + MAX_MESSAGE + ' characters or fewer. It is currently ' + value.length + '.';
      }
      return '';
    }
  };

  // Shows or clears one field's error and links it to the field with aria-describedby.
  function showFieldState(field, message) {
    var error = document.getElementById(field.id + '-error');
    var hintId = field.id + '-hint';
    error.textContent = message;
    if (message) {
      field.setAttribute('aria-invalid', 'true');
      field.setAttribute('aria-describedby', hintId + ' ' + error.id);
    } else {
      field.removeAttribute('aria-invalid');
      field.setAttribute('aria-describedby', hintId);
    }
  }

  // Validates one field and returns true when it is valid.
  function validateField(field) {
    var message = rules[field.id](field.value);
    showFieldState(field, message);
    return message === '';
  }

  // Confirms the message was not sent. The text is set with textContent, never as HTML.
  function showDemoConfirmation(name) {
    status.textContent = 'Thanks, ' + name + ' — this is a demo site, so your message wasn\'t sent anywhere. ' +
      'To reach us, email hello@marginaliabooks.example.';
    status.focus();
  }

  form.addEventListener('submit', function (event) {
    event.preventDefault();
    var results = fields.map(validateField);
    var firstInvalid = fields[results.indexOf(false)];
    if (firstInvalid) {
      status.textContent = '';
      firstInvalid.focus();
      return;
    }
    showDemoConfirmation(fields[0].value.trim());
  });

  // Once a field is invalid, re-check it as the visitor types so the error clears when fixed.
  form.addEventListener('input', function (event) {
    if (event.target.getAttribute('aria-invalid') === 'true') {
      validateField(event.target);
    }
  });
})();

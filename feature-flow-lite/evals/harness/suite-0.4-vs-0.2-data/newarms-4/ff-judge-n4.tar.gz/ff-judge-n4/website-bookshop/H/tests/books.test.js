'use strict';

const { describe, it, before, after } = require('node:test');
const assert = require('node:assert/strict');
const { startSite, openPage } = require('./helpers');

const TOTAL = 14;

async function cards(page) {
  return page.$$eval('#book-list > li > article', (articles) => articles.map((a) => ({
    title: a.querySelector('h2')?.textContent.trim() ?? '',
    author: a.querySelector('.book-author')?.textContent.trim() ?? '',
    genre: a.querySelector('.book-genre')?.textContent.trim() ?? '',
    description: a.querySelector('.book-description')?.textContent.trim() ?? '',
    price: a.querySelector('.book-price')?.textContent.trim() ?? '',
  })));
}

async function filterLabels(page) {
  return page.locator('fieldset button').allTextContents();
}

async function pick(page, label) {
  await page.getByRole('button', { name: label, exact: true }).click();
}

async function pressed(page, label) {
  return page.getByRole('button', { name: label, exact: true }).getAttribute('aria-pressed');
}

describe('books catalogue (criterion 4)', () => {
  let site;
  before(async () => { site = await startSite(); });
  after(async () => { await site.close(); });

  it('lists at least 12 books, each with title, author, genre, description and price, across 5+ genres', async () => {
    const page = await openPage(site, 'books.html');
    const books = await cards(page);
    assert.ok(books.length >= 12, `found ${books.length} books`);
    for (const book of books) {
      assert.ok(book.title, 'book without a title');
      assert.match(book.author, /^by \S/, `author of ${book.title}`);
      assert.ok(book.genre, `genre of ${book.title}`);
      assert.ok(book.description.length >= 40, `description of ${book.title}`);
      assert.match(book.price, /^£\d+\.\d{2}$/, `price of ${book.title}`);
    }
    assert.ok(new Set(books.map((book) => book.genre)).size >= 5, 'fewer than 5 genres');
  });

  it('renders the books as a ul of li items, each holding an article', async () => {
    const page = await openPage(site, 'books.html');
    assert.equal(await page.evaluate(() => document.getElementById('book-list').tagName), 'UL');
    const items = await page.locator('#book-list > li').count();
    assert.ok(items >= 12, `only ${items} list items`);
    assert.equal(await page.locator('#book-list > li > article').count(), items);
  });
});

describe('genre filter (criteria 5 and 6)', () => {
  let site;
  before(async () => { site = await startSite(); });
  after(async () => { await site.close(); });

  it('offers All plus every genre in the data, sorted, in a labelled group of toggle buttons', async () => {
    const page = await openPage(site, 'books.html');
    assert.ok((await page.locator('fieldset legend').textContent()).trim().length > 0, 'filter has no legend');
    const labels = await filterLabels(page);
    const genres = [...new Set((await cards(page)).map((book) => book.genre))].sort((a, b) => a.localeCompare(b));
    assert.deepEqual(labels, ['All', ...genres]);
    const states = await page.locator('fieldset button').evaluateAll((buttons) => buttons.map((b) => b.getAttribute('aria-pressed')));
    assert.ok(states.every((state) => state === 'true' || state === 'false'), `aria-pressed values: ${states}`);
  });

  it('shows only the chosen genre, offers only genres that have books, and announces the count', async () => {
    const page = await openPage(site, 'books.html');
    const total = (await cards(page)).length;
    assert.equal(await page.getAttribute('#result-count', 'aria-live'), 'polite');
    const [, ...genres] = await filterLabels(page);
    for (const genre of genres) {
      await pick(page, genre);
      const shown = await cards(page);
      assert.ok(shown.length > 0, `${genre} has no books`);
      assert.ok(shown.every((book) => book.genre === genre), `${genre} shows books of another genre`);
      assert.equal(await page.textContent('#result-count'), `Showing ${shown.length} of ${total} books in ${genre}`);
    }
    await pick(page, 'All');
    assert.equal((await cards(page)).length, total);
    assert.equal(await page.textContent('#result-count'), `Showing ${total} of ${total} books`);
  });

  it('treats repeated clicks on the same filter as a no-op', async () => {
    const page = await openPage(site, 'books.html');
    await pick(page, 'Mystery');
    const historyBefore = await page.evaluate(() => history.length);
    const first = (await cards(page)).length;
    await pick(page, 'Mystery');
    await pick(page, 'Mystery');
    assert.equal((await cards(page)).length, first);
    assert.equal(await pressed(page, 'Mystery'), 'true');
    assert.equal(await page.evaluate(() => history.length), historyBefore, 'repeat clicks added history entries');
    assert.equal(new URL(page.url()).search, '?genre=mystery');
  });

  it('writes the filter to ?genre= with pushState without reloading, and removes it for All', async () => {
    const page = await openPage(site, 'books.html');
    await page.evaluate(() => { window.marker = 'same document'; });
    await pick(page, 'Poetry');
    assert.equal(new URL(page.url()).searchParams.get('genre'), 'poetry');
    assert.equal(await page.evaluate(() => window.marker), 'same document', 'page reloaded');
    await pick(page, 'All');
    assert.equal(new URL(page.url()).searchParams.has('genre'), false);
  });

  it('restores the filter from ?genre=mystery on load, with the control reflecting it', async () => {
    const page = await openPage(site, 'books.html', { query: '?genre=mystery' });
    const shown = await cards(page);
    assert.equal(shown.length, 3);
    assert.ok(shown.every((book) => book.genre === 'Mystery'));
    assert.equal(await pressed(page, 'Mystery'), 'true');
    assert.equal(await pressed(page, 'All'), 'false');
    assert.equal(await page.textContent('#result-count'), `Showing 3 of ${TOTAL} books in Mystery`);
  });

  it('restores the previous filter on back and forward', async () => {
    const page = await openPage(site, 'books.html');
    await pick(page, 'Mystery');
    await pick(page, 'Poetry');
    await page.goBack();
    await page.waitForFunction(() => new URL(location.href).searchParams.get('genre') === 'mystery');
    await page.waitForFunction((n) => document.querySelectorAll('#book-list > li').length === n, 3);
    assert.equal(await pressed(page, 'Mystery'), 'true');
    await page.goBack();
    await page.waitForFunction((n) => document.querySelectorAll('#book-list > li').length === n, TOTAL);
    assert.equal(await pressed(page, 'All'), 'true');
    await page.goForward();
    await page.waitForFunction((n) => document.querySelectorAll('#book-list > li').length === n, 3);
    assert.equal(await pressed(page, 'Mystery'), 'true');
  });

  const HOSTILE = [
    ['?genre=', 'an empty genre', TOTAL, 'All'],
    ['?genre=nonsense', 'an unknown genre', TOTAL, 'All'],
    ['?genre=MYSTERY', 'an upper-case genre', 3, 'Mystery'],
    [`?genre=${encodeURIComponent('<script>alert(1)</script>')}`, 'injected markup', TOTAL, 'All'],
  ];
  for (const [query, label, expected, pressedLabel] of HOSTILE) {
    it(`falls back safely for ${label} in the URL without errors or injected markup`, async () => {
      const page = await site.newPage();
      const dialogs = [];
      const problems = [];
      page.on('dialog', (dialog) => {
        dialogs.push(dialog.message());
        dialog.dismiss();
      });
      page.on('pageerror', (error) => problems.push(error.message));
      await page.goto(site.url('books.html', query), { waitUntil: 'load' });
      assert.equal((await cards(page)).length, expected, `${query} shows the wrong books`);
      assert.equal(await pressed(page, pressedLabel), 'true', `${query} does not reflect the filter`);
      assert.deepEqual(dialogs, [], 'an injected script ran');
      assert.deepEqual(problems, [], 'the page threw');
      assert.equal((await page.content()).includes('<script>alert(1)</script>'), false, 'markup from the URL was rendered');
    });
  }
});

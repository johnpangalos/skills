'use strict';

// Criterion 6: contact form labels, validation, demo status and hostile inputs.

const { test, before, after } = require('node:test');
const assert = require('node:assert/strict');
const { startServer, launchBrowser, openPage } = require('./helpers/site');

const VALID = {
  name: 'Ada Reader',
  email: 'ada@example.com',
  message: 'Do you run a book club on Thursdays?',
};

let server;
let browser;
before(async () => {
  server = await startServer();
  browser = await launchBrowser();
});
after(async () => {
  await browser.close();
  await server.close();
});

async function fill(page, values) {
  await page.fill('#contact-name', values.name ?? '');
  await page.fill('#contact-email', values.email ?? '');
  await page.fill('#contact-message', values.message ?? '');
}

function submit(page) {
  return page.click('#contact-form button[type="submit"]');
}

// The field's aria-invalid value and the text of every element it is described by.
function fieldState(page, id) {
  return page.evaluate((fieldId) => {
    const field = document.getElementById(fieldId);
    const ids = (field.getAttribute('aria-describedby') || '').split(/\s+/).filter(Boolean);
    const errorText = ids.map((i) => document.getElementById(i)?.textContent.trim() ?? '').join(' ').trim();
    return { invalid: field.getAttribute('aria-invalid'), errorText };
  }, id);
}

function statusText(page) {
  return page.locator('#contact-status').textContent().then((t) => t.trim());
}

test('name, email and message have visible labels, are required, and the form is novalidate', async () => {
  const { page } = await openPage(browser, server.origin, 'visit.html');
  const fields = await page.evaluate(() => ['contact-name', 'contact-email', 'contact-message'].map((id) => {
    const field = document.getElementById(id);
    const label = document.querySelector(`label[for="${id}"]`);
    return {
      id,
      hasLabel: Boolean(label),
      labelText: label ? label.textContent.trim() : '',
      required: field.required,
    };
  }));
  for (const field of fields) {
    assert.ok(field.hasLabel, `${field.id} has no <label for>`);
    assert.ok(field.labelText.includes('*') || /required/i.test(field.labelText), `${field.id} label does not mark it required: "${field.labelText}"`);
    assert.equal(field.required, true, `${field.id} should be required`);
  }
  assert.equal(await page.getAttribute('#contact-form', 'novalidate'), '');
});

test('submitting an empty form flags every field, focuses the first invalid one and sends nothing', async () => {
  const { page, log } = await openPage(browser, server.origin, 'visit.html');
  await page.evaluate(() => { window.__marker = 'still-here'; });
  await submit(page);
  for (const id of ['contact-name', 'contact-email', 'contact-message']) {
    const state = await fieldState(page, id);
    assert.equal(state.invalid, 'true', `${id} aria-invalid`);
    assert.ok(state.errorText.length > 0, `${id} has no linked error message`);
  }
  assert.equal(await page.evaluate(() => document.activeElement.id), 'contact-name');
  assert.equal(await statusText(page), '');
  assert.deepEqual(log.requests.filter((r) => r.method !== 'GET'), [], 'no form POST');
  assert.equal(await page.evaluate(() => window.__marker), 'still-here', 'page must not reload');
});

test('whitespace-only name and message are invalid', async () => {
  const { page } = await openPage(browser, server.origin, 'visit.html');
  await fill(page, { name: '   ', email: VALID.email, message: '\n\t  ' });
  await submit(page);
  assert.equal((await fieldState(page, 'contact-name')).invalid, 'true');
  assert.equal((await fieldState(page, 'contact-message')).invalid, 'true');
  assert.equal((await fieldState(page, 'contact-email')).invalid, null);
  assert.equal(await page.evaluate(() => document.activeElement.id), 'contact-name');
});

for (const bad of ['foo', 'foo@', '@bar.com']) {
  test(`malformed email "${bad}" is invalid`, async () => {
    const { page } = await openPage(browser, server.origin, 'visit.html');
    await fill(page, { ...VALID, email: bad });
    await submit(page);
    const state = await fieldState(page, 'contact-email');
    assert.equal(state.invalid, 'true');
    assert.ok(state.errorText.length > 0, 'email error message is empty');
    assert.equal(await statusText(page), '');
  });
}

test('a valid form shows a plain demo status without navigating, reloading or claiming a send', async () => {
  const { page, log } = await openPage(browser, server.origin, 'visit.html');
  await page.evaluate(() => { window.__marker = 'still-here'; });
  const before = page.url();
  await fill(page, VALID);
  await submit(page);
  const status = await statusText(page);
  assert.match(status, /demo/i);
  assert.match(status, /nothing was sent/i);
  assert.doesNotMatch(status, /(message|it|email) (has been|was successfully) sent|has been sent|we('ve| have) received|thank you for (your|contacting)/i);
  const role = await page.getAttribute('#contact-status', 'role');
  const live = await page.getAttribute('#contact-status', 'aria-live');
  assert.ok(role === 'status' || live === 'polite', 'status must be announced');
  assert.ok(await page.locator('#contact-status a[href^="mailto:"]').count() >= 1, 'status should offer the email address');
  assert.equal(page.url(), before, 'no navigation');
  assert.equal(await page.evaluate(() => window.__marker), 'still-here', 'no reload');
  assert.deepEqual(log.requests.filter((r) => r.method !== 'GET'), [], 'no form POST');
});

test('a 10,000 character message is accepted and does not break the 360px layout', async () => {
  const { page } = await openPage(browser, server.origin, 'visit.html', 360);
  const long = 'abcdefghij'.repeat(1000);
  await fill(page, { ...VALID, message: long });
  await submit(page);
  assert.match(await statusText(page), /nothing was sent/i);
  assert.equal(await page.inputValue('#contact-message'), long, 'message must not be truncated');
  const widths = await page.evaluate(() => ({ scroll: document.documentElement.scrollWidth, inner: window.innerWidth }));
  assert.ok(widths.scroll <= widths.inner, `scrollWidth ${widths.scroll} > innerWidth ${widths.inner}`);
});

test('HTML in the name is never injected into the page', async () => {
  const { page, log } = await openPage(browser, server.origin, 'visit.html');
  await fill(page, { ...VALID, name: '<b>x</b>' });
  await submit(page);
  assert.match(await statusText(page), /nothing was sent/i);
  assert.equal(await page.locator('main b').count(), 0, 'no <b> element may appear');
  assert.equal(await page.locator('main img, main svg[onload]').count(), 0);
  assert.deepEqual(log.errors, [], 'no console errors');
});

test('errors clear once the fields are corrected and the form is resubmitted', async () => {
  const { page } = await openPage(browser, server.origin, 'visit.html');
  await submit(page);
  assert.equal((await fieldState(page, 'contact-name')).invalid, 'true');
  await fill(page, { name: VALID.name, email: 'foo', message: VALID.message });
  await submit(page);
  const name = await fieldState(page, 'contact-name');
  assert.notEqual(name.invalid, 'true', 'name should no longer be invalid');
  assert.equal(name.errorText, '', 'name error text should be cleared');
  const email = await fieldState(page, 'contact-email');
  assert.equal(email.invalid, 'true', 'email is still invalid');
  await fill(page, { ...VALID });
  await submit(page);
  const email2 = await fieldState(page, 'contact-email');
  assert.notEqual(email2.invalid, 'true');
  assert.equal(email2.errorText, '');
  assert.match(await statusText(page), /nothing was sent/i);
});

// Static checks: no external URLs, every local reference resolves, ids are unique per page.
// Usage: node tests/check-static.mjs
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const SKIP_DIRS = new Set(['.git', 'node_modules', 'tests']);
const REMOTE = [/https?:\/\//i, /(?:src|href)\s*=\s*["']?\/\//i, /url\(\s*["']?\/\//i, /@import\s+["']?(?!\.)/i];

function walk(dir) {
  const files = [];
  for (const entry of fs.readdirSync(dir, { withFileTypes: true })) {
    if (entry.isDirectory()) {
      if (!SKIP_DIRS.has(entry.name)) files.push(...walk(path.join(dir, entry.name)));
    } else if (/\.(html|css|js)$/.test(entry.name)) {
      files.push(path.join(dir, entry.name));
    }
  }
  return files;
}

const failures = [];
const files = walk(ROOT);

for (const file of files) {
  const rel = path.relative(ROOT, file);
  const text = fs.readFileSync(file, 'utf8');

  for (const pattern of REMOTE) {
    const match = text.match(pattern);
    if (match) failures.push(`${rel}: remote reference "${match[0]}"`);
  }

  if (file.endsWith('.html')) {
    const ids = [...text.matchAll(/\sid="([^"]+)"/g)].map((m) => m[1]);
    for (const id of new Set(ids)) {
      if (ids.filter((other) => other === id).length > 1) failures.push(`${rel}: duplicate id "${id}"`);
    }
    if (/tabindex="([1-9]\d*)"/.test(text)) failures.push(`${rel}: positive tabindex`);

    const refs = [...text.matchAll(/\s(?:href|src)="([^"]+)"/g)].map((m) => m[1]);
    for (const ref of refs) {
      if (ref.startsWith('#') || /^(mailto|tel|data):/.test(ref)) continue;
      const target = ref.split(/[?#]/)[0];
      const resolved = path.resolve(ROOT, target.startsWith('/') ? target.slice(1) : path.join(path.dirname(file), target));
      if (!fs.existsSync(resolved)) failures.push(`${rel}: unresolved reference "${ref}"`);
    }
  }

  if (file.endsWith('.css')) {
    for (const [, ref] of text.matchAll(/url\(\s*["']?([^"')]+)["']?\s*\)/g)) {
      if (ref.startsWith('#') || ref.startsWith('data:')) continue;
      if (!fs.existsSync(path.resolve(path.dirname(file), ref))) failures.push(`${rel}: unresolved url(${ref})`);
    }
  }
}

if (failures.length > 0) {
  for (const failure of failures) console.log(`FAIL ${failure}`);
  console.log(`check-static: ${failures.length} problem(s) in ${files.length} files`);
  process.exit(1);
}
console.log(`check-static: ${files.length} files checked, no external references, all local references resolve, ids unique`);

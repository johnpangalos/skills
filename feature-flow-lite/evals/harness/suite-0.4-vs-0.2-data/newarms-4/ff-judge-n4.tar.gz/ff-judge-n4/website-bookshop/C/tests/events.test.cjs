'use strict';

// Events page (criterion 8): content, ordering and past/upcoming split by the user's local day.

const { test, before, after } = require('node:test');
const assert = require('node:assert/strict');
const { chromium } = require('playwright');
const { startServer } = require('./server.cjs');

let server;
let browser;

before(async () => {
  server = await startServer();
  browser = await chromium.launch();
});

after(async () => {
  await browser.close();
  await server.close();
});

async function openEvents({ now, timezoneId = 'UTC' }) {
  const context = await browser.newContext({ viewport: { width: 1280, height: 900 }, timezoneId });
  const page = await context.newPage();
  const errors = [];
  page.on('pageerror', (err) => errors.push(err.message));
  page.on('console', (msg) => {
    if (msg.type() === 'error') errors.push(msg.text());
  });
  await page.clock.setFixedTime(new Date(now));
  await page.goto(`${server.origin}/events.html`);
  await page.waitForSelector('#upcoming-events > li');
  return { context, page, errors };
}

async function listTitles(page, id) {
  return page.$$eval(`#${id} > li h3`, (els) => els.map((h) => h.textContent.trim()));
}

// Criterion 8

test('criterion 8: at least four events, each with title, time element with year, description and attendance note', async () => {
  const { context, page, errors } = await openEvents({ now: '2026-11-17T12:00:00Z' });
  try {
    const events = await page.$$eval('#upcoming-events > li, #past-events > li', (items) =>
      items.map((li) => ({
        title: li.querySelector('h3')?.textContent.trim() || '',
        time: li.querySelector('time')?.getAttribute('datetime') || '',
        timeText: li.querySelector('time')?.textContent.trim() || '',
        description: li.querySelector('.event-description')?.textContent.trim() || '',
        attendance: li.querySelector('.event-attendance')?.textContent.trim() || '',
      })),
    );
    assert.ok(events.length >= 4, `expected at least 4 events, found ${events.length}`);
    for (const event of events) {
      assert.ok(event.title, 'event needs a title');
      assert.match(event.time, /^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}$/, `${event.title} datetime attribute`);
      assert.match(event.timeText, /20\d{2}/, `${event.title} time text should include the year`);
      assert.ok(event.description.length > 40, `${event.title} needs a real description`);
      assert.match(event.attendance, /free|ticket/i, `${event.title} must say free or ticketed`);
      assert.match(event.attendance, /RSVP|book|booking|reserve/i, `${event.title} needs an RSVP note`);
    }
    assert.deepEqual(errors, []);
  } finally {
    await context.close();
  }
});

test('criterion 8: events are listed in ascending date order', async () => {
  const { context, page } = await openEvents({ now: '2026-11-17T12:00:00Z' });
  try {
    for (const id of ['upcoming-events', 'past-events']) {
      const times = await page.$$eval(`#${id} > li time`, (els) => els.map((t) => t.getAttribute('datetime')));
      assert.ok(times.length > 0, `${id} should list events`);
      assert.deepEqual(times, [...times].sort(), `${id} must be ascending by date`);
    }
  } finally {
    await context.close();
  }
});

test('criterion 8: past events sit under a Past events heading and most events are upcoming', async () => {
  const { context, page } = await openEvents({ now: '2026-11-17T12:00:00Z', timezoneId: 'UTC' });
  try {
    const heading = await page.$eval('#past-section h2', (el) => el.textContent.trim());
    assert.equal(heading, 'Past events');
    assert.ok(await page.isVisible('#past-section'));
    const past = await listTitles(page, 'past-events');
    const upcoming = await listTitles(page, 'upcoming-events');
    assert.ok(past.length >= 1, 'at least one past event');
    assert.ok(upcoming.length > past.length, 'most events should be upcoming');
    assert.ok(!past.includes('Open Shelf Night'), 'an event on today is upcoming');
    assert.ok(upcoming.includes('Open Shelf Night'), 'an event on today is upcoming');
  } finally {
    await context.close();
  }
});

test('criterion 8: in Auckland the local day has already moved on, so the 17 November event is past', async () => {
  // 12:00 UTC on 17 Nov is already 18 Nov in Auckland (UTC+13), while UTC still says 17 Nov.
  const { context, page } = await openEvents({ now: '2026-11-17T12:00:00Z', timezoneId: 'Pacific/Auckland' });
  try {
    const past = await listTitles(page, 'past-events');
    const upcoming = await listTitles(page, 'upcoming-events');
    assert.ok(past.includes('Open Shelf Night'), 'local date is 18 Nov, so 17 Nov is past');
    assert.ok(!upcoming.includes('Open Shelf Night'));
  } finally {
    await context.close();
  }
});

test('criterion 8: in Los Angeles an event on the local date 17 Nov still counts as upcoming', async () => {
  // 06:30 UTC on 18 Nov is 22:30 on 17 Nov in Los Angeles (UTC-8), while UTC already says 18 Nov.
  const { context, page } = await openEvents({ now: '2026-11-18T06:30:00Z', timezoneId: 'America/Los_Angeles' });
  try {
    const upcoming = await listTitles(page, 'upcoming-events');
    const past = await listTitles(page, 'past-events');
    assert.ok(upcoming.includes('Open Shelf Night'), 'local date is 17 Nov, so the event is upcoming');
    assert.ok(!past.includes('Open Shelf Night'));
  } finally {
    await context.close();
  }
});

test('criterion 8: with no upcoming events a helpful message replaces the empty list', async () => {
  // The last event is 13 Feb 2027, so on 10 March 2027 nothing is upcoming.
  const context = await browser.newContext({ viewport: { width: 1280, height: 900 } });
  const page = await context.newPage();
  try {
    await page.clock.setFixedTime(new Date('2027-03-10T12:00:00Z'));
    await page.goto(`${server.origin}/events.html`);
    assert.equal(await page.isVisible('#upcoming-empty'), true, 'the helpful message is shown');
    assert.match((await page.textContent('#upcoming-empty')).trim(), /^No events are scheduled right now\./);
    assert.equal(await page.isVisible('#upcoming-events'), false, 'the empty list is not shown');
    assert.equal(await page.locator('#upcoming-events > li').count(), 0);
  } finally {
    await context.close();
  }
});

test('criterion 8: Open Shelf Night does not say the shop stays open late when it starts at 6pm', async () => {
  const { context, page } = await openEvents({ now: '2026-11-01T12:00:00Z' });
  try {
    const event = page.locator('li', { has: page.locator('h3', { hasText: 'Open Shelf Night' }) });
    const description = await event.locator('.event-description').textContent();
    assert.doesNotMatch(description, /open late/i);
  } finally {
    await context.close();
  }
});

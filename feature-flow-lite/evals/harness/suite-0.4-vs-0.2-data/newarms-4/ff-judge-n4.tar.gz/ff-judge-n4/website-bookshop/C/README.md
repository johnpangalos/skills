# Marginalia Books

A static website for Marginalia Books, a fictional independent bookshop. It has four pages (home, books, events and visit), a filterable catalogue, an events list that separates upcoming from past events, and a contact form on the visit page. Everything is plain HTML, CSS and JavaScript with no build step, no dependencies to install and no requests to any server other than the one that serves the site.

The shop, its address, its phone number, its books and its events are all invented. The phone number uses the reserved drama range and every email address uses the `.example` domain.

## Viewing the site

Serve the folder with any static server and open the address it prints. Opening the HTML files straight from disk works for most pages but the catalogue and events depend on JavaScript loading correctly, so a server is the reliable option.

```sh
npx http-server . -p 8080
# or
python3 -m http.server 8080
```

Then open http://localhost:8080/.

## File layout

```
index.html        Home page
books.html        Filterable catalogue (filter state lives in ?genre=<slug>)
events.html       Events, split into upcoming and past by the reader's local date
visit.html        Opening hours, address, access information and the contact form
css/styles.css    Shared styles for every page
js/books-data.js  The catalogue: one array of books
js/books.js       Renders the catalogue and the genre filter
js/events-data.js The events: one array of events
js/events.js      Renders events, sorted by date
js/contact.js     Validates the contact form and shows the demo notice
tests/            Headless Chromium tests (Playwright) and a small static server
```

## Running the tests

The tests use the globally installed `playwright` package, so no install is needed in this folder. They start their own static server on a random local port and drive headless Chromium.

```sh
NODE_PATH=$(npm root -g) node --test tests/*.test.cjs
```

To run a single file, name it instead, for example `tests/books.test.cjs`.

## Notes

The contact form does not send anything. A valid submission shows a notice that this is a demo site and the message was not sent, with the shop's email address as the real way to get in touch.

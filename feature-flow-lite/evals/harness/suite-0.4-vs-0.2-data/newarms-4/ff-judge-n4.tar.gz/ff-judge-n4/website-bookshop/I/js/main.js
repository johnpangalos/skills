// Shared script for every page. Only the visit page has an open-now line.
(function () {
  var statusEl = document.querySelector("[data-open-status]");
  if (!statusEl) return;

  var now = new Date();
  var row = document.querySelector('#hours tr[data-day="' + now.getDay() + '"]');
  statusEl.textContent = describeOpen(row, now.getHours() * 60 + now.getMinutes());

  function describeOpen(row, minutes) {
    if (!row || !row.dataset.open) return "Closed today.";
    if (minutes < toMinutes(row.dataset.open)) {
      return "Closed right now. Opens today at " + row.dataset.open + ".";
    }
    if (minutes < toMinutes(row.dataset.close)) {
      return "Open now until " + row.dataset.close + ".";
    }
    return "Closed for the rest of today.";
  }

  function toMinutes(time) {
    var parts = time.split(":");
    return Number(parts[0]) * 60 + Number(parts[1]);
  }
})();

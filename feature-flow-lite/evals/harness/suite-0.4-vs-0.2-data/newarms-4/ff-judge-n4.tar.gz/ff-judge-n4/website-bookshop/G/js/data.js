// Shared content for Marginalia Books. Books and events are rendered from here.
// Events are kept in date order. Past events stay in the list and are hidden by
// the pages according to the visitor's local date.
window.MarginaliaData = {
  genres: [
    { slug: 'fiction', name: 'Fiction' },
    { slug: 'poetry', name: 'Poetry' },
    { slug: 'essays', name: 'Essays' },
    { slug: 'mystery', name: 'Mystery' },
    { slug: 'childrens', name: "Children's" }
  ],

  books: [
    {
      title: 'The Lantern Keeper',
      author: 'Mara Okonkwo-Hale',
      genre: 'fiction',
      price: 9.99,
      featured: true,
      blurb: 'A lighthouse keeper’s daughter finds a drawer of letters never posted, and sets out to deliver them.'
    },
    {
      title: 'Salt and Telegraph',
      author: 'Edwin Pardoe',
      genre: 'fiction',
      price: 11.5,
      featured: false,
      blurb: 'Two rival telegraph operators on a Cornish headland fall into a correspondence neither of them planned.'
    },
    {
      title: 'The Orchard Year',
      author: 'Inés Valtorta',
      genre: 'fiction',
      price: 10.25,
      featured: false,
      blurb: 'One family, one failing apple farm, and twelve months of decisions that cannot be put off until spring.'
    },
    {
      title: 'Low Tide Sonnets',
      author: 'Hana Reyes-Lindqvist',
      genre: 'poetry',
      price: 12,
      featured: true,
      blurb: 'Fourteen-line poems written on mudflats, ferry decks and the back steps of a seaside guesthouse.'
    },
    {
      title: 'Field Notes for the Living',
      author: 'Tomas Aldridge',
      genre: 'poetry',
      price: 10.5,
      featured: false,
      blurb: 'Short, plain-spoken poems about hedgerows, hospital waiting rooms and the weather in between.'
    },
    {
      title: 'A Grammar of Rain',
      author: 'Priya Sundaram',
      genre: 'poetry',
      price: 9.5,
      featured: false,
      blurb: 'A sequence of poems arranged like verb tables, conjugating grief, hope and the English word “wet”.'
    },
    {
      title: 'Against Tidiness',
      author: 'Jo Mallory',
      genre: 'essays',
      price: 13,
      featured: true,
      blurb: 'Essays in defence of messy desks, unfinished gardens and the untidy paths that lead somewhere good.'
    },
    {
      title: 'Kitchen Table Physics',
      author: 'Ruth Ellery',
      genre: 'essays',
      price: 12.75,
      featured: false,
      blurb: 'A physicist explains the everyday science of boiling kettles, cooling bread and why soup sticks to the spoon.'
    },
    {
      title: 'The Slow Map',
      author: 'Gideon Park',
      genre: 'essays',
      price: 14,
      featured: false,
      blurb: 'Notes on walking, cartography and the idea that a good map should make you slow down rather than hurry.'
    },
    {
      title: 'The Quiet Ferry',
      author: 'Lena Hartigan',
      genre: 'mystery',
      price: 8.99,
      featured: false,
      blurb: 'The last crossing of the night carries one passenger too many, and the harbour master wants to know who.'
    },
    {
      title: 'Nine Coins in the Canal',
      author: 'Samir Doyle',
      genre: 'mystery',
      price: 9.25,
      featured: false,
      blurb: 'A barge owner pulls nine old coins from the water, each one stamped with a date from the week he disappeared.'
    },
    {
      title: 'The Vicar’s Second Alibi',
      author: 'Agnes Prothero',
      genre: 'mystery',
      price: 8.5,
      featured: false,
      blurb: 'A village fete, a missing church bell and a retired detective who insists the vicar was not where he said.'
    },
    {
      title: 'Otter Takes the Train',
      author: 'Bea Lindgren',
      genre: 'childrens',
      price: 6.99,
      featured: false,
      blurb: 'Otter has never left the river before. A picture book about a first journey and a very long sandwich.'
    },
    {
      title: 'The Girl Who Counted Clouds',
      author: 'Fenella Ward',
      genre: 'childrens',
      price: 7.5,
      featured: false,
      blurb: 'Nell keeps a careful tally of every cloud over the allotments, until one cloud starts counting her back.'
    },
    {
      title: 'Moss and Marbles',
      author: 'Kwame Asante-Reid',
      genre: 'childrens',
      price: 6.5,
      featured: false,
      blurb: 'Two friends build a marble run through the woods, and learn what a forest does with things it is given.'
    }
  ],

  events: [
    {
      title: 'Autumn Poetry Open Mic',
      date: '2026-10-14',
      start: '19:00',
      booking: false,
      description: 'Five minutes each, any poem you like. Bring a poem to read or just come and listen.'
    },
    {
      title: 'Reading Group: The Quiet Ferry',
      date: '2026-11-07',
      start: '18:30',
      booking: true,
      description: 'Our monthly mystery group talks through the whole book, with tea and a few plausible suspects.'
    },
    {
      title: 'Bring Your Own Book Swap',
      date: '2026-11-21',
      start: '19:00',
      booking: false,
      description: 'Bring up to three books you have finished and take home three you have not. Everything is free.'
    },
    {
      title: 'Poetry Night: Voices from the Estuary',
      date: '2026-11-28',
      start: '18:30',
      booking: true,
      description: 'Four local poets read from new collections, followed by questions and a glass of something warm.'
    },
    {
      title: 'Saturday Storytime for Under-Fives',
      date: '2026-12-05',
      start: '11:00',
      booking: true,
      description: 'Songs, two picture books and a bit of craft. Forty-five minutes, with a grown-up for every child.'
    },
    {
      title: 'Essay Club: Against Tidiness',
      date: '2026-12-12',
      start: '19:30',
      booking: false,
      description: 'Jo Mallory joins us to talk about the essays and to hear what you think of your own untidy shelves.'
    },
    {
      title: 'Winter Mystery Night',
      date: '2027-01-16',
      start: '18:00',
      booking: true,
      description: 'A murder-mystery evening in the back room. Solve the case with the other guests before the pudding is served.'
    }
  ]
};

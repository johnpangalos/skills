/* Shared behaviour for every page: the mobile menu, the footer year and DOM helpers used by the page scripts. */
const Marginalia = (function () {
  'use strict';

  function makeElement(tag, className, text) {
    const element = document.createElement(tag);
    if (className) {
      element.className = className;
    }
    if (text !== undefined) {
      element.textContent = text;
    }
    return element;
  }

  function slugify(text) {
    return String(text).trim().toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-+|-+$/g, '');
  }

  function formatPrice(price) {
    return '£' + Number(price).toFixed(2);
  }

  function genres() {
    const names = [];
    SITE_DATA.books.forEach(function (book) {
      if (names.indexOf(book.genre) === -1) {
        names.push(book.genre);
      }
    });
    return names.map(function (name) {
      return { name: name, slug: slugify(name) };
    });
  }

  function todayIso() {
    const now = new Date();
    const month = String(now.getMonth() + 1).padStart(2, '0');
    const day = String(now.getDate()).padStart(2, '0');
    return now.getFullYear() + '-' + month + '-' + day;
  }

  function upcomingEvents() {
    const today = todayIso();
    return SITE_DATA.events
      .filter(function (event) {
        return event.date >= today;
      })
      .sort(function (a, b) {
        const x = a.date + 'T' + a.time;
        const y = b.date + 'T' + b.time;
        return x < y ? -1 : x > y ? 1 : 0;
      });
  }

  function formatClock(time) {
    const parts = time.split(':');
    const hour = Number(parts[0]);
    const suffix = hour >= 12 ? 'pm' : 'am';
    return (hour % 12 || 12) + ':' + parts[1] + suffix;
  }

  function formatWhen(event) {
    const parts = event.date.split('-');
    const day = new Date(Number(parts[0]), Number(parts[1]) - 1, Number(parts[2]));
    const dateText = day.toLocaleDateString('en-GB', {
      weekday: 'long',
      day: 'numeric',
      month: 'long',
      year: 'numeric'
    });
    return dateText + ', ' + formatClock(event.time);
  }

  function createBookCard(book) {
    const genreSlug = slugify(book.genre);
    const card = makeElement('article', 'book-card');
    const cover = makeElement('div', 'cover');
    cover.setAttribute('aria-hidden', 'true');
    cover.dataset.genre = genreSlug;
    card.appendChild(cover);
    if (book.staffPick) {
      card.appendChild(makeElement('p', 'badge', 'Staff pick'));
    }
    card.appendChild(makeElement('p', 'genre-tag', book.genre));
    card.appendChild(makeElement('h3', '', book.title));
    card.appendChild(makeElement('p', 'book-author', 'by ' + book.author));
    card.appendChild(makeElement('p', 'book-blurb', book.blurb));
    card.appendChild(makeElement('p', 'book-price', formatPrice(book.price)));
    return card;
  }

  function createEventItem(event) {
    const item = makeElement('li');
    const card = makeElement('article', 'event-card');
    const when = makeElement('time', 'event-when', formatWhen(event));
    when.setAttribute('datetime', event.date + 'T' + event.time);
    card.appendChild(when);
    card.appendChild(makeElement('h3', '', event.title));
    card.appendChild(makeElement('p', 'event-text', event.description));
    card.appendChild(makeElement('p', 'booking', event.booking ? 'Booking needed' : 'No booking needed'));
    item.appendChild(card);
    return item;
  }

  function setupMenu() {
    const toggle = document.querySelector('.menu-toggle');
    const nav = document.getElementById('site-nav');
    if (!toggle || !nav) {
      return;
    }
    document.documentElement.classList.add('js');
    toggle.addEventListener('click', function () {
      const open = !nav.classList.contains('is-open');
      nav.classList.toggle('is-open', open);
      toggle.setAttribute('aria-expanded', String(open));
    });
    document.addEventListener('keydown', function (event) {
      if (event.key === 'Escape' && nav.classList.contains('is-open')) {
        nav.classList.remove('is-open');
        toggle.setAttribute('aria-expanded', 'false');
        toggle.focus();
      }
    });
  }

  function setYear() {
    const year = document.getElementById('year');
    if (year) {
      year.textContent = String(new Date().getFullYear());
    }
  }

  setupMenu();
  setYear();

  return {
    makeElement: makeElement,
    slugify: slugify,
    formatPrice: formatPrice,
    genres: genres,
    todayIso: todayIso,
    upcomingEvents: upcomingEvents,
    createBookCard: createBookCard,
    createEventItem: createEventItem
  };
})();

import { describe, it, before, after } from "node:test";
import assert from "node:assert/strict";
import { startServer } from "./server.mjs";
import {
  PAGES,
  launchBrowser,
  openTracked,
  externalRequests,
} from "./helpers.mjs";

let server;
let browser;

before(async () => {
  server = await startServer();
  browser = await launchBrowser();
});

after(async () => {
  await browser.close();
  await server.close();
});

describe("zero external requests and console errors", () => {
  for (const path of PAGES) {
    it(`${path} loads with no request leaving the origin and no console errors`, async () => {
      const { page, requests, problems, close } = await openTracked(browser);
      try {
        await page.goto(`${server.origin}/${path}`, { waitUntil: "load" });
        await page.waitForLoadState("networkidle");
        assert.deepEqual(externalRequests(requests, server.origin), []);
        assert.deepEqual(problems, []);
      } finally {
        await close();
      }
    });
  }

  it("interacting with the filter and the contact form stays on the origin with no errors", async () => {
    const { page, requests, problems, close } = await openTracked(browser);
    try {
      await page.goto(`${server.origin}/books.html`, { waitUntil: "load" });
      await page.click('#genre-buttons button:text-is("Poetry")');
      await page.goto(`${server.origin}/visit.html`, { waitUntil: "load" });
      await page.fill("#contact-name", "Ada");
      await page.fill("#contact-email", "ada@example.com");
      await page.fill("#contact-message", "Hello");
      await page.click('#contact-form button[type="submit"]');
      await page.waitForLoadState("networkidle");
      assert.deepEqual(externalRequests(requests, server.origin), []);
      assert.deepEqual(
        requests.filter(({ method }) => method === "POST"),
        [],
      );
      assert.deepEqual(problems, []);
    } finally {
      await close();
    }
  });
});

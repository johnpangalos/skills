// Shared site behaviour: the mobile navigation toggle, and helpers used by the home and events pages.

// Today's date as YYYY-MM-DD in the visitor's local time zone.
function todayIso() {
  const now = new Date();
  const month = String(now.getMonth() + 1).padStart(2, '0');
  const day = String(now.getDate()).padStart(2, '0');
  return `${now.getFullYear()}-${month}-${day}`;
}

(function () {
  const toggle = document.querySelector('.nav-toggle');
  const nav = document.getElementById('site-nav');
  const wide = window.matchMedia('(min-width: 720px)');
  let open = false;

  function render() {
    nav.hidden = !wide.matches && !open;
    toggle.setAttribute('aria-expanded', String(open));
  }

  toggle.addEventListener('click', function () {
    open = !open;
    render();
  });

  document.addEventListener('keydown', function (event) {
    if (event.key === 'Escape' && open && !wide.matches) {
      open = false;
      render();
      toggle.focus();
    }
  });

  // Crossing the breakpoint in either direction starts from a closed menu.
  wide.addEventListener('change', function () {
    open = false;
    render();
  });

  render();
})();

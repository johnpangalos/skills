# Marginalia Books

A static, multi-page website for Marginalia Books, a fictional independent bookshop. It has four pages:

- `index.html`: home, with a hero, staff picks and a teaser for the next event.
- `books.html`: a 14-title catalogue with a genre filter. The filter state lives in the URL (`?genre=mystery`), so filtered views can be bookmarked and Back and Forward work.
- `events.html`: upcoming events from December 2026 to March 2027.
- `visit.html`: opening hours, address, phone and email, and a contact form.

The site is plain HTML, CSS and vanilla JavaScript. It has no build step, no npm dependencies, no web fonts, and makes no requests to any other origin.

## Running the site

Serve the repository root with any static server, then open the page in a browser:

```sh
python3 -m http.server 8000
# then visit http://localhost:8000/
```

Opening the HTML files directly from disk will not load the scripts, because browsers block ES module imports over `file://`. Use a server.

The contact form is a demonstration. It validates input in the browser and then says plainly that the message was not sent. Nothing is posted anywhere.

## Editing content

- Books: `js/books-data.js`. Each entry has `title`, `author`, `genre`, `price` and `description`. Genre names become filter slugs automatically.
- Events: `js/events-data.js`. Each entry has `date` (ISO format, used in the `<time>` element), `dateLabel`, `time`, `title` and `description`.

## Running the tests

The tests use Playwright and headless Chrome. Playwright is not a dependency of this repo. The tests load it from a global install:

```sh
node --test "tests/*.test.mjs"
```

Each test file starts its own static server on a random local port, so nothing else needs to be running.

Defaults and overrides:

- `PLAYWRIGHT_PATH`: directory the Playwright package is resolved from. Default `/opt/node-tools/node_modules/`.
- `CHROME_PATH`: Chrome or Chromium executable. Default `/usr/bin/google-chrome`.

```sh
PLAYWRIGHT_PATH=/path/to/node_modules CHROME_PATH=/usr/bin/chromium node --test "tests/*.test.mjs"
```

Formatting is checked with Prettier: `prettier --check .`

// Events for events.html. Dates are local calendar days (YYYY-MM-DD) and start times are 24-hour HH:MM.
// Every title and description here is fictional.
const EVENTS = [
  {
    title: 'Autumn Poetry Evening',
    date: '2026-10-22',
    startTime: '18:30',
    description:
      'Five local poets each read three poems from their new collections, followed by an open mic for anyone who has brought a page of their own. Chairs are set out in the long room, and mulled apple juice is served at the interval.',
    attendance: 'Free to attend. Drop in on the night, or RSVP by email if you would like a seat held at the front.',
  },
  {
    title: 'Open Shelf Night',
    date: '2026-11-17',
    startTime: '18:00',
    description:
      'An hour of browsing before we close, with staff picks laid out on the back tables and a ten-minute recommendation service at the counter. Bring a friend and leave with something you did not know you needed.',
    attendance:
      'Free and drop-in. No booking is needed, but you can RSVP by email if you are bringing a group of four or more.',
  },
  {
    title: 'Saturday Reading Circle',
    date: '2026-11-28',
    startTime: '10:30',
    description:
      'A relaxed morning group where everyone reads the same short story aloud and talks about it over coffee. This month’s story is a wintry piece of nature writing, and the group is open to readers of all levels.',
    attendance: 'Free. Please RSVP by email so we can order enough coffee for the table.',
  },
  {
    title: 'Mystery Book Club: The Clockmaker’s Alibi',
    date: '2026-12-05',
    startTime: '18:30',
    description:
      'Our monthly mystery group meets to pick apart the plot of Tobias Wren’s debut, with a guessing game about the murderer before the final chapter is read aloud. Spoilers are only permitted after the first cup of tea.',
    attendance:
      'Free to join. Book your place by email, and borrow a copy from the shop if you have not read the novel yet.',
  },
  {
    title: 'Children’s Winter Story Hour',
    date: '2026-12-12',
    startTime: '11:00',
    description:
      'Picture books, a paper lantern craft and a short puppet show for children aged three to seven, read in the children’s corner by the window. Grown-ups are welcome to sit in and join the songs.',
    attendance:
      'Free, but booking is required because places are limited to thirty children. Book at the counter or by email.',
  },
  {
    title: 'Translators’ Table',
    date: '2027-01-23',
    startTime: '19:00',
    description:
      'Two translators talk about the difficult choices they made while bringing novels from Portuguese and Norwegian into English. The evening includes a reading from each book and time for questions from the floor.',
    attendance:
      'Tickets £6, which include a glass of wine. Book in store or by email, as tickets are limited to forty.',
  },
  {
    title: 'An Evening with Hollis Marr',
    date: '2027-02-13',
    startTime: '19:00',
    description:
      'The author talks about her research on Cornish apple orchards and reads from her new book of linked stories. A signing follows, with every copy sold on the night personalised on request.',
    attendance:
      'Tickets £12, with a signed copy of the new book included. Book ahead by email, as this event is expected to sell out.',
  },
];

import { describe, it, before, after } from "node:test";
import assert from "node:assert/strict";
import { startServer } from "./server.mjs";
import { PAGES, launchBrowser, openTracked } from "./helpers.mjs";

const WIDTH = 360;

let server;
let browser;

before(async () => {
  server = await startServer();
  browser = await launchBrowser();
});

after(async () => {
  await browser.close();
  await server.close();
});

async function openAt(path) {
  const tracked = await openTracked(browser, { width: WIDTH, height: 740 });
  await tracked.page.goto(`${server.origin}/${path}`, { waitUntil: "load" });
  return tracked;
}

function scrollWidth(page) {
  return page.evaluate(() => document.documentElement.scrollWidth);
}

describe("360px layout", () => {
  for (const path of PAGES) {
    it(`${path} does not scroll sideways`, async () => {
      const { page, close } = await openAt(path);
      try {
        const width = await scrollWidth(page);
        assert.ok(width <= WIDTH, `scrollWidth ${width}`);
      } finally {
        await close();
      }
    });
  }

  it("books grid with the Science Fiction filter does not scroll sideways", async () => {
    const { page, close } = await openAt("books.html");
    try {
      await page.click('#genre-buttons button:text-is("Science Fiction")');
      assert.ok((await scrollWidth(page)) <= WIDTH);
    } finally {
      await close();
    }
  });

  it("visit page with the hours table and contact form does not scroll sideways", async () => {
    const { page, close } = await openAt("visit.html");
    try {
      await page.fill("#contact-message", "x".repeat(1000));
      await page.evaluate(() =>
        document.querySelector("#contact-form button").click(),
      );
      const width = await scrollWidth(page);
      assert.ok(width <= WIDTH, `scrollWidth ${width}`);
    } finally {
      await close();
    }
  });

  it("the mobile nav opens to a full list that does not scroll sideways", async () => {
    const { page, close } = await openAt("events.html");
    try {
      await page.click(".nav-toggle");
      assert.equal(
        await page.getAttribute(".nav-toggle", "aria-expanded"),
        "true",
      );
      assert.equal(
        await page.getAttribute(".nav-toggle", "aria-controls"),
        "site-nav",
      );
      assert.equal(await page.isVisible('#site-nav a:text-is("Visit")'), true);
      const width = await scrollWidth(page);
      assert.ok(width <= WIDTH, `scrollWidth ${width}`);
    } finally {
      await close();
    }
  });

  it("Escape closes the open mobile nav and returns focus to its toggle", async () => {
    const { page, close } = await openAt("index.html");
    try {
      await page.click(".nav-toggle");
      assert.equal(await page.isVisible('#site-nav a:text-is("Books")'), true);
      await page.keyboard.press("Escape");
      assert.equal(
        await page.getAttribute(".nav-toggle", "aria-expanded"),
        "false",
      );
      assert.equal(await page.isVisible('#site-nav a:text-is("Books")'), false);
      assert.equal(
        await page.evaluate(() => document.activeElement.className),
        "nav-toggle",
      );
    } finally {
      await close();
    }
  });
});

'use strict';

// Site-wide criteria: navigation, page structure, requests and errors, responsive layout,
// keyboard and accessibility basics. Every check loads the pages in headless Chromium.

const { test, before, after } = require('node:test');
const assert = require('node:assert/strict');
const { chromium } = require('playwright');
const { startServer } = require('./server.cjs');

const PAGES = ['index.html', 'books.html', 'events.html', 'visit.html'];
const INTERACTIVE = 'a[href], button, input, select, textarea';

let server;
let browser;

before(async () => {
  server = await startServer();
  browser = await chromium.launch();
});

after(async () => {
  await browser.close();
  await server.close();
});

async function openPage(width, pathname, options = {}) {
  const context = await browser.newContext({ viewport: { width, height: 800 }, ...options });
  const page = await context.newPage();
  const requests = [];
  const problems = [];
  page.on('request', (req) => requests.push(req.url()));
  page.on('console', (msg) => {
    if (msg.type() === 'error') problems.push(`console: ${msg.text()}`);
  });
  page.on('pageerror', (err) => problems.push(`pageerror: ${err.message}`));
  await page.goto(`${server.origin}/${pathname}`);
  await page.waitForLoadState('load');
  return { context, page, requests, problems };
}

function parseColor(value) {
  const parts = value
    .match(/rgba?\(([^)]+)\)/)[1]
    .split(/[\s,/]+/)
    .filter(Boolean)
    .map(Number);
  return { r: parts[0], g: parts[1], b: parts[2], a: parts.length > 3 ? parts[3] : 1 };
}

function luminance({ r, g, b }) {
  const channel = (v) => {
    const s = v / 255;
    return s <= 0.03928 ? s / 12.92 : ((s + 0.055) / 1.055) ** 2.4;
  };
  return 0.2126 * channel(r) + 0.7152 * channel(g) + 0.0722 * channel(b);
}

function contrastRatio(fgValue, bgValue) {
  const [hi, lo] = [luminance(parseColor(fgValue)), luminance(parseColor(bgValue))].sort((a, b) => b - a);
  return (hi + 0.05) / (lo + 0.05);
}

// Criterion 1

test('criterion 1: shared nav links to all four pages, aria-current only on the current page', async () => {
  for (const current of PAGES) {
    const { context, page } = await openPage(1280, current);
    try {
      const links = await page.$$eval('header nav a', (els) =>
        els.map((a) => ({
          href: a.getAttribute('href'),
          current: a.getAttribute('aria-current'),
        })),
      );
      assert.deepEqual(
        links.map((l) => l.href).sort(),
        [...PAGES].sort(),
        `${current} nav must link to all four pages`,
      );
      const marked = links.filter((l) => l.current !== null);
      assert.equal(marked.length, 1, `${current} must mark exactly one nav link`);
      assert.equal(marked[0].href, current);
      assert.equal(marked[0].current, 'page');
    } finally {
      await context.close();
    }
  }
});

test('criterion 1: every internal link and asset resolves without a 404', async () => {
  for (const pathname of PAGES) {
    const { context, page } = await openPage(1280, pathname);
    try {
      const targets = await page.$$eval('a[href], link[href], script[src], img[src]', (els) =>
        els.map((el) => el.getAttribute('href') || el.getAttribute('src')),
      );
      const local = [
        ...new Set(targets.filter((t) => t && !t.startsWith('#') && !t.startsWith('mailto:') && !t.startsWith('tel:'))),
      ];
      assert.ok(local.length > 0, `${pathname} should link to local resources`);
      for (const target of local) {
        const url = new URL(target, `${server.origin}/${pathname}`);
        assert.equal(url.origin, server.origin, `${pathname} links off-site: ${target}`);
        const response = await page.request.get(url.href);
        assert.equal(response.status(), 200, `${pathname} -> ${target} returned ${response.status()}`);
      }
    } finally {
      await context.close();
    }
  }
});

// Criterion 2

test('criterion 2: every page has lang, a unique title, one h1 and no skipped heading levels', async () => {
  const titles = [];
  for (const pathname of PAGES) {
    const { context, page } = await openPage(1280, pathname);
    try {
      const info = await page.evaluate(() => ({
        lang: document.documentElement.getAttribute('lang'),
        title: document.title.trim(),
        h1: document.querySelectorAll('h1').length,
        levels: [...document.querySelectorAll('h1, h2, h3, h4, h5, h6')].map((h) => Number(h.tagName[1])),
      }));
      assert.equal(info.lang, 'en', `${pathname} lang`);
      assert.ok(info.title.length > 0, `${pathname} needs a title`);
      titles.push(info.title);
      assert.equal(info.h1, 1, `${pathname} must have exactly one h1`);
      let previous = 0;
      for (const level of info.levels) {
        assert.ok(level <= previous + 1, `${pathname} skips from h${previous} to h${level}`);
        previous = level;
      }
    } finally {
      await context.close();
    }
  }
  assert.equal(new Set(titles).size, PAGES.length, 'page titles must be unique');
});

test('criterion 2: every page has header, nav, main and footer landmarks and a footer address and hours', async () => {
  for (const pathname of PAGES) {
    const { context, page } = await openPage(1280, pathname);
    try {
      const counts = await page.evaluate(() => ({
        header: document.querySelectorAll('body > header').length,
        nav: document.querySelectorAll('header nav').length,
        main: document.querySelectorAll('main').length,
        footer: document.querySelectorAll('body > footer').length,
        footerText: document.querySelector('body > footer').textContent,
      }));
      assert.equal(counts.header, 1, `${pathname} header`);
      assert.equal(counts.nav, 1, `${pathname} nav`);
      assert.equal(counts.main, 1, `${pathname} main`);
      assert.equal(counts.footer, 1, `${pathname} footer`);
      assert.match(counts.footerText, /Quill Street/, `${pathname} footer address`);
      assert.match(counts.footerText, /Mon.*Sat.*Sun/s, `${pathname} footer hours summary`);
    } finally {
      await context.close();
    }
  }
});

test('criterion 2: skip link is the first focusable element and moves focus to main', async () => {
  for (const pathname of PAGES) {
    const { context, page } = await openPage(1280, pathname);
    try {
      await page.keyboard.press('Tab');
      const first = await page.evaluate(() => ({
        text: document.activeElement.textContent.trim(),
        href: document.activeElement.getAttribute('href'),
      }));
      assert.equal(first.text, 'Skip to main content', `${pathname} first Tab stop`);
      assert.equal(first.href, '#main');
      await page.keyboard.press('Enter');
      const focused = await page.evaluate(() => document.activeElement.tagName + '#' + document.activeElement.id);
      assert.equal(focused, 'MAIN#main', `${pathname} focus after skip link`);
    } finally {
      await context.close();
    }
  }
});

// Criterion 3

test('criterion 3: no request leaves the local origin and no console or page errors, during load and interaction', async () => {
  for (const pathname of PAGES) {
    const { context, page, requests, problems } = await openPage(1280, pathname);
    try {
      for (let i = 0; i < 40; i += 1) await page.keyboard.press('Tab');
      const filter = page.locator('.genre-filter label').nth(1);
      if (await filter.count()) await filter.click();
      const submit = page.locator('button[type="submit"]');
      if (await submit.count()) await submit.click();
      await page.waitForTimeout(100);
      const offOrigin = requests.filter((url) => !url.startsWith(server.origin));
      assert.deepEqual(offOrigin, [], `${pathname} made off-origin requests`);
      assert.deepEqual(problems, [], `${pathname} reported errors`);
    } finally {
      await context.close();
    }
  }
});

// Criterion 4

test('criterion 4: no page scrolls sideways at 360px or 320px', async () => {
  for (const width of [360, 320]) {
    for (const pathname of PAGES) {
      const { context, page } = await openPage(width, pathname);
      try {
        const { scroll, client } = await page.evaluate(() => ({
          scroll: document.documentElement.scrollWidth,
          client: document.documentElement.clientWidth,
        }));
        assert.ok(scroll <= client, `${pathname} at ${width}px: scrollWidth ${scroll} > clientWidth ${client}`);
      } finally {
        await context.close();
      }
    }
  }
});

test('criterion 4: no page scrolls sideways at 1280px and nav stays on one visible row', async () => {
  for (const pathname of PAGES) {
    const { context, page } = await openPage(1280, pathname);
    try {
      const { scroll, client } = await page.evaluate(() => ({
        scroll: document.documentElement.scrollWidth,
        client: document.documentElement.clientWidth,
      }));
      assert.ok(scroll <= client, `${pathname} at 1280px overflows`);
      const tops = await page.$$eval('header nav a', (els) =>
        els.map((a) => Math.round(a.getBoundingClientRect().top)),
      );
      assert.equal(new Set(tops).size, 1, `${pathname} nav links should share one row at 1280px`);
    } finally {
      await context.close();
    }
  }
});

test('criterion 4: nav links and filter controls are at least 44x44 CSS px at 360px', async () => {
  for (const pathname of ['index.html', 'books.html']) {
    const { context, page } = await openPage(360, pathname);
    try {
      const boxes = await page.$$eval('header nav a, .genre-filter label', (els) =>
        els.map((el) => {
          const r = el.getBoundingClientRect();
          return { text: el.textContent.trim(), w: r.width, h: r.height };
        }),
      );
      const minimum = pathname === 'books.html' ? 10 : 4;
      assert.ok(boxes.length >= minimum, `${pathname} should have ${minimum}+ nav links and filter controls`);
      for (const box of boxes) {
        assert.ok(box.w >= 44 && box.h >= 44, `${pathname} tap target "${box.text}" is ${box.w}x${box.h}`);
      }
    } finally {
      await context.close();
    }
  }
});

test('criterion 4: body copy is at least 16px on every page at 360px', async () => {
  for (const pathname of PAGES) {
    const { context, page } = await openPage(360, pathname);
    try {
      const small = await page.evaluate(() =>
        [...document.querySelectorAll('body *')]
          .filter((el) => [...el.childNodes].some((n) => n.nodeType === Node.TEXT_NODE && n.textContent.trim()))
          .filter((el) => el.getClientRects().length > 0)
          .map((el) => ({
            tag: el.tagName,
            text: el.textContent.trim().slice(0, 40),
            size: parseFloat(getComputedStyle(el).fontSize),
          }))
          .filter((item) => item.size < 16),
      );
      assert.deepEqual(small, [], `${pathname} has text under 16px`);
    } finally {
      await context.close();
    }
  }
});

// Criterion 5

test('criterion 5: every interactive control is reached by Tab and shows a visible focus indicator', async () => {
  for (const pathname of PAGES) {
    const { context, page } = await openPage(1280, pathname);
    try {
      // A radio group takes one Tab stop (the checked radio); the others are reached with the arrow keys,
      // which books.test.cjs covers.
      const expected = await page.evaluate((selector) => {
        const els = [...document.querySelectorAll(selector)]
          .filter((el) => el.getClientRects().length > 0)
          .filter((el) => el.type !== 'radio' || el.checked);
        els.forEach((el, i) => el.setAttribute('data-probe', String(i)));
        return els.length;
      }, INTERACTIVE);
      const visited = new Set();
      for (let i = 0; i < 120; i += 1) {
        await page.keyboard.press('Tab');
        const state = await page.evaluate(() => {
          const el = document.activeElement;
          const style = getComputedStyle(el);
          return {
            probe: el.getAttribute('data-probe'),
            outline: style.outlineStyle,
            shadow: style.boxShadow,
            label: el.textContent.trim() || el.id || el.tagName,
          };
        });
        if (state.probe === null) continue;
        visited.add(state.probe);
        assert.ok(
          state.outline !== 'none' || state.shadow !== 'none',
          `${pathname}: no visible focus indicator on "${state.label}"`,
        );
      }
      assert.equal(visited.size, expected, `${pathname}: Tab reached ${visited.size} of ${expected} controls`);
    } finally {
      await context.close();
    }
  }
});

test('criterion 5: images and SVGs have alt text or are hidden from assistive tech', async () => {
  for (const pathname of PAGES) {
    const { context, page } = await openPage(1280, pathname);
    try {
      const problems = await page.evaluate(() => {
        const bad = [];
        document.querySelectorAll('img').forEach((img) => {
          if (!img.hasAttribute('alt')) bad.push(`img ${img.getAttribute('src')} without alt`);
        });
        document.querySelectorAll('svg').forEach((svg) => {
          const hidden = svg.getAttribute('aria-hidden') === 'true';
          const named =
            svg.getAttribute('role') === 'img' && (svg.getAttribute('aria-label') || svg.querySelector('title'));
          if (!hidden && !named) bad.push('svg without alt text or aria-hidden');
        });
        return bad;
      });
      assert.deepEqual(problems, [], `${pathname} image alternatives`);
    } finally {
      await context.close();
    }
  }
});

test('criterion 5: text, link and button colours meet WCAG AA contrast of 4.5:1', async () => {
  for (const pathname of PAGES) {
    const { context, page } = await openPage(1280, pathname);
    try {
      const pairs = await page.evaluate(() => {
        const selector =
          'header a, main p, main li, main td, main th, main dd, main dt, main label, main a, main button, main legend, footer p, footer a';
        const bgOf = (el) => {
          for (let node = el; node; node = node.parentElement) {
            const bg = getComputedStyle(node).backgroundColor;
            if (!/rgba\(\s*\d+,\s*\d+,\s*\d+,\s*0\s*\)/.test(bg) && bg !== 'transparent') return bg;
          }
          return 'rgb(255, 255, 255)';
        };
        return [...document.querySelectorAll(selector)]
          .filter((el) => el.getClientRects().length > 0 && el.textContent.trim())
          .map((el) => ({
            label: el.textContent.trim().slice(0, 30),
            fg: getComputedStyle(el).color,
            bg: bgOf(el),
          }));
      });
      assert.ok(pairs.length >= 8, `${pathname} should expose representative text`);
      for (const pair of pairs) {
        const ratio = contrastRatio(pair.fg, pair.bg);
        assert.ok(ratio >= 4.5, `${pathname} "${pair.label}" contrast ${ratio.toFixed(2)} (${pair.fg} on ${pair.bg})`);
      }
    } finally {
      await context.close();
    }
  }
});

test('criterion 5: transitions run normally and are all removed when reduced motion is requested', async () => {
  const normal = await openPage(1280, 'index.html');
  try {
    const animated = await normal.page.$$eval('header nav a', (els) =>
      els.some((a) => getComputedStyle(a).transitionDuration !== '0s'),
    );
    assert.ok(animated, 'nav links should have a transition when motion is allowed');
  } finally {
    await normal.context.close();
  }

  for (const pathname of PAGES) {
    const { context, page } = await openPage(1280, pathname, { reducedMotion: 'reduce' });
    try {
      const moving = await page.evaluate(() =>
        [...document.querySelectorAll('*')]
          .map((el) => {
            const s = getComputedStyle(el);
            return `${el.tagName} transition ${s.transitionDuration} animation ${s.animationDuration}`;
          })
          .filter((line) => !/transition 0s animation 0s$/.test(line)),
      );
      assert.deepEqual(moving, [], `${pathname} has motion under reduced-motion`);
    } finally {
      await context.close();
    }
  }
});

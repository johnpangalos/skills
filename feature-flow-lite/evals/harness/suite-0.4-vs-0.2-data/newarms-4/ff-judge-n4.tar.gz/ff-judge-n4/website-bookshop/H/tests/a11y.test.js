'use strict';

const { describe, it, before, after } = require('node:test');
const assert = require('node:assert/strict');
const { PAGES, WIDE, startSite, openPage, tabStops } = require('./helpers');

// WCAG relative luminance and contrast, computed from browser colours.
function parseColor(value) {
  const parts = value.match(/[\d.]+/g).map(Number);
  return { r: parts[0], g: parts[1], b: parts[2], a: parts.length > 3 ? parts[3] : 1 };
}

function luminance({ r, g, b }) {
  const [R, G, B] = [r, g, b].map((c) => {
    const s = c / 255;
    return s <= 0.03928 ? s / 12.92 : ((s + 0.055) / 1.055) ** 2.4;
  });
  return 0.2126 * R + 0.7152 * G + 0.0722 * B;
}

function contrastRatio(a, b) {
  const [hi, lo] = [luminance(a), luminance(b)].sort((x, y) => y - x);
  return (hi + 0.05) / (lo + 0.05);
}

// The first opaque background in an ancestor chain, starting at the element itself.
function backdrop(chain) {
  const opaque = chain.map(parseColor).find((color) => color.a > 0);
  return opaque && opaque.a === 1 ? opaque : { r: 255, g: 255, b: 255, a: 1 };
}

describe('accessibility (criterion 12)', () => {
  let site;
  before(async () => { site = await startSite(); });
  after(async () => { await site.close(); });

  it('shows a visible :focus-visible outline with 3:1 contrast on every tab stop of every page', async () => {
    for (const { file } of PAGES) {
      const page = await openPage(site, file);
      const stops = await tabStops(page);
      assert.ok(stops.length >= 5, `${file} has only ${stops.length} tab stops`);
      for (const stop of stops) {
        const label = `${file} ${stop.tag} "${stop.text}"`;
        assert.equal(stop.focusVisible, true, `${label} is not :focus-visible`);
        assert.notEqual(stop.outlineStyle, 'none', `${label} has no outline`);
        assert.ok(parseFloat(stop.outlineWidth) >= 2, `${label} outline is ${stop.outlineWidth}`);
        // The outline is drawn outside the element, so it is judged against what sits behind the element.
        const ratio = contrastRatio(parseColor(stop.outlineColor), backdrop(stop.backgrounds.slice(1)));
        assert.ok(ratio >= 3, `${label} outline contrast is ${ratio.toFixed(2)}`);
      }
    }
  });

  it('defines its palette as CSS custom properties', async () => {
    const page = await openPage(site, 'index.html');
    const values = await page.evaluate(() => {
      const styles = getComputedStyle(document.documentElement);
      return ['--paper', '--ink', '--link', '--forest'].map((name) => styles.getPropertyValue(name).trim());
    });
    assert.ok(values.every((value) => value.length > 0), `custom properties missing: ${values}`);
  });

  it('keeps body text and link colours at 4.5:1 contrast or better on every page', async () => {
    for (const { file } of PAGES) {
      const page = await openPage(site, file);
      const texts = await page.evaluate(() => {
        const chainOf = (el) => {
          const chain = [];
          for (let node = el; node; node = node.parentElement) chain.push(getComputedStyle(node).backgroundColor);
          return chain;
        };
        return [...document.querySelectorAll('body *')]
          .filter((el) => el.getClientRects().length > 0
            && [...el.childNodes].some((n) => n.nodeType === Node.TEXT_NODE && n.textContent.trim()))
          .map((el) => ({
            text: el.textContent.trim().slice(0, 40),
            color: getComputedStyle(el).color,
            backgrounds: chainOf(el),
          }));
      });
      assert.ok(texts.length > 10, `${file} has only ${texts.length} text elements`);
      for (const text of texts) {
        const ratio = contrastRatio(parseColor(text.color), backdrop(text.backgrounds));
        assert.ok(ratio >= 4.5, `${file} "${text.text}" contrast is ${ratio.toFixed(2)}`);
      }
    }
  });

  it('turns off transitions under prefers-reduced-motion but keeps them otherwise', async () => {
    const normal = await openPage(site, 'books.html', { reducedMotion: 'no-preference' });
    const duration = await normal.$eval('fieldset button', (el) => parseFloat(getComputedStyle(el).transitionDuration));
    assert.ok(duration > 0, 'buttons have no transition to suppress');

    const reduced = await openPage(site, 'books.html', { reducedMotion: 'reduce' });
    const offenders = await reduced.evaluate(() => [...document.querySelectorAll('*')]
      .filter((el) => {
        const style = getComputedStyle(el);
        return style.transitionDuration.split(',').some((d) => parseFloat(d) > 0)
          || style.animationDuration.split(',').some((d) => parseFloat(d) > 0);
      })
      .map((el) => el.tagName.toLowerCase()));
    assert.deepEqual(offenders, [], 'animated or transitioning elements under reduced motion');
  });

  it('hides decorative SVG from assistive tech and gives informative SVG a name', async () => {
    for (const { file } of PAGES) {
      const page = await openPage(site, file);
      const svgs = await page.$$eval('svg', (els) => els.map((svg) => ({
        hidden: svg.getAttribute('aria-hidden') === 'true',
        role: svg.getAttribute('role'),
        name: svg.getAttribute('aria-label') || (svg.querySelector('title') ? svg.querySelector('title').textContent.trim() : ''),
      })));
      if (file === 'index.html') {
        assert.ok(svgs.length >= 1, 'the home page has no decorative SVG to check');
      }
      for (const svg of svgs) {
        assert.ok(svg.hidden || (svg.role === 'img' && svg.name), `${file} has an SVG with no role: ${JSON.stringify(svg)}`);
      }
    }
  });

  it('has one h1 per page and never skips a heading level', async () => {
    for (const { file } of PAGES) {
      const page = await openPage(site, file);
      const levels = await page.$$eval('h1, h2, h3, h4, h5, h6', (headings) => headings.map((h) => Number(h.tagName[1])));
      assert.equal(levels.filter((level) => level === 1).length, 1, `${file} does not have exactly one h1`);
      let previous = 0;
      for (const level of levels) {
        assert.ok(level <= previous + 1, `${file} goes from h${previous} to h${level}`);
        previous = level;
      }
    }
  });

  it('is usable at 1280px with a full-width layout that still reads comfortably', async () => {
    const page = await openPage(site, 'books.html', { width: WIDE });
    const width = await page.$eval('main p', (p) => p.getBoundingClientRect().width);
    assert.ok(width <= 80 * 16, `body text line is ${width}px wide`);
  });
});

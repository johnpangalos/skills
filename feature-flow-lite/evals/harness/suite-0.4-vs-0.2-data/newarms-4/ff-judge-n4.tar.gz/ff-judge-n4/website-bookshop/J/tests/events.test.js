'use strict';

// Criterion 4: upcoming events with fixed 2027 dates.

const { test, before, after } = require('node:test');
const assert = require('node:assert/strict');
const { startServer, launchBrowser, openPage } = require('./helpers/site');

const WEEKDAYS = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];

let server;
let browser;
before(async () => {
  server = await startServer();
  browser = await launchBrowser();
});
after(async () => {
  await browser.close();
  await server.close();
});

test('events page lists at least 4 events with title, time element, description and free/ticketed status', async () => {
  const { page } = await openPage(browser, server.origin, 'events.html');
  const events = await page.$$eval('article.event', (items) => items.map((item) => ({
    title: item.querySelector('h2')?.textContent.trim() ?? '',
    datetime: item.querySelector('time')?.getAttribute('datetime') ?? '',
    when: item.querySelector('time')?.textContent.trim() ?? '',
    description: item.querySelector('.event-description')?.textContent.trim() ?? '',
    access: item.querySelector('.access')?.textContent.trim() ?? '',
  })));
  assert.ok(events.length >= 4, `expected at least 4 events, found ${events.length}`);
  for (const event of events) {
    assert.ok(event.title && event.description, `incomplete event: ${JSON.stringify(event)}`);
    assert.match(event.datetime, /^2027-\d{2}-\d{2}T\d{2}:\d{2}$/, `datetime for ${event.title}`);
    assert.match(event.access, /^(Free entry|Ticketed)\b/, `free/ticketed status for ${event.title}`);
    const [date] = event.datetime.split('T');
    const weekday = WEEKDAYS[new Date(`${date}T00:00:00Z`).getUTCDay()];
    assert.ok(event.when.includes(weekday), `"${event.when}" should name ${weekday}`);
  }
});

test('events page never labels anything "today" or "tomorrow"', async () => {
  const { page } = await openPage(browser, server.origin, 'events.html');
  const text = await page.evaluate(() => document.body.innerText);
  assert.doesNotMatch(text, /\b(today|tomorrow)\b/i);
});

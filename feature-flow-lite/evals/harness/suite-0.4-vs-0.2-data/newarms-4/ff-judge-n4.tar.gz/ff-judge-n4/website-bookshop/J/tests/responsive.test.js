'use strict';

// Criterion 7: no sideways scrolling at 360/768/1280, readable base font,
// and tap targets of at least 24x24 CSS px for nav links and filter controls.

const { test, before, after } = require('node:test');
const assert = require('node:assert/strict');
const { PAGES, startServer, launchBrowser, openPage } = require('./helpers/site');

let server;
let browser;
before(async () => {
  server = await startServer();
  browser = await launchBrowser();
});
after(async () => {
  await browser.close();
  await server.close();
});

for (const width of [360, 768, 1280]) {
  test(`no page scrolls horizontally at ${width}px`, async () => {
    const failures = [];
    for (const file of PAGES) {
      const { page } = await openPage(browser, server.origin, file, width);
      const { scroll, inner } = await page.evaluate(() => ({
        scroll: document.documentElement.scrollWidth,
        inner: window.innerWidth,
      }));
      if (scroll > inner) failures.push(`${file}: scrollWidth ${scroll} > innerWidth ${inner}`);
    }
    assert.deepEqual(failures, []);
  });
}

test('base font size is at least 16px on every page at 360px', async () => {
  for (const file of PAGES) {
    const { page } = await openPage(browser, server.origin, file, 360);
    const size = await page.evaluate(() => parseFloat(getComputedStyle(document.body).fontSize));
    assert.ok(size >= 16, `${file} base font is ${size}px`);
  }
});

test('nav links and filter controls are at least 24x24 CSS px at 360px', async () => {
  const { page } = await openPage(browser, server.origin, 'books.html', 360);
  const small = await page.evaluate(() => {
    const targets = [
      ...document.querySelectorAll('header nav a'),
      ...document.querySelectorAll('input[name="genre"]'),
      ...document.querySelectorAll('label:has(input[name="genre"])'),
    ];
    return targets
      .map((el) => ({ label: el.tagName + ' ' + el.textContent.trim().slice(0, 20), box: el.getBoundingClientRect() }))
      .filter(({ box }) => box.width < 24 || box.height < 24)
      .map(({ label, box }) => `${label} ${Math.round(box.width)}x${Math.round(box.height)}`);
  });
  assert.deepEqual(small, []);
});

test('nav links are at least 24x24 CSS px on every page at 360px', async () => {
  for (const file of PAGES) {
    const { page } = await openPage(browser, server.origin, file, 360);
    const small = await page.$$eval('header nav a', (as) => as
      .map((a) => a.getBoundingClientRect())
      .filter((box) => box.width < 24 || box.height < 24)
      .map((box) => `${Math.round(box.width)}x${Math.round(box.height)}`));
    assert.deepEqual(small, [], `${file} nav link sizes`);
  }
});

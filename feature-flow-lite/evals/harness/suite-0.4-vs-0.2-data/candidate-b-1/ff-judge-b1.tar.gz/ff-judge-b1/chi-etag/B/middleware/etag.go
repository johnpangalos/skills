package middleware

import (
	"bufio"
	"crypto/sha256"
	"encoding/hex"
	"errors"
	"maps"
	"net"
	"net/http"
	"strings"
)

// ETag adds a strong ETag to GET and HEAD responses that have status 200 and no
// ETag of their own, and answers 304 Not Modified when If-None-Match matches it.
//
// The response is buffered until the handler returns so the ETag can be computed
// from the body. Until then, Flush sends nothing to the client. The ETag is the
// hex SHA-256 digest of the body, quoted. On HEAD, a body-derived ETag is only
// set when the handler wrote a body, so an empty HEAD response never gets one.
// If-None-Match uses the weak comparison from RFC 9110 §13.1.2 and also accepts
// "*". Matching responses are sent as 304 with no body. Responses with any other
// status, and all other methods, pass through unchanged.
func ETag(next http.Handler) http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		if r.Method != http.MethodGet && r.Method != http.MethodHead {
			next.ServeHTTP(w, r)
			return
		}
		ew := &etagResponseWriter{ResponseWriter: w, req: r}
		next.ServeHTTP(ew, r)
		ew.finish()
	})
}

type etagResponseWriter struct {
	http.ResponseWriter
	req *http.Request

	// header is the snapshot of the handler's headers taken when status 200 was
	// written, so later header changes are not sent, as in net/http.
	header      http.Header
	body        []byte
	wroteHeader bool
	// passthrough is set once a non-200 final status is written. Writes and
	// Flush then go straight to the underlying writer.
	passthrough bool
	// flushed is set when the handler calls Flush while the 200 is buffered.
	flushed  bool
	hijacked bool
}

func (cw *etagResponseWriter) WriteHeader(code int) {
	if code >= 100 && code <= 199 && code != http.StatusSwitchingProtocols {
		// Informational responses are sent now and do not set the final status.
		cw.ResponseWriter.WriteHeader(code)
		return
	}
	if cw.wroteHeader {
		if cw.passthrough {
			cw.ResponseWriter.WriteHeader(code) // Let net/http report the superfluous call.
		}
		return
	}
	cw.wroteHeader = true
	if code != http.StatusOK {
		cw.passthrough = true
		cw.ResponseWriter.WriteHeader(code)
		return
	}
	cw.header = cw.ResponseWriter.Header().Clone()
}

func (cw *etagResponseWriter) Write(p []byte) (int, error) {
	if cw.hijacked {
		return 0, http.ErrHijacked
	}
	if !cw.wroteHeader {
		cw.WriteHeader(http.StatusOK)
	}
	if cw.passthrough {
		return cw.ResponseWriter.Write(p)
	}
	cw.body = append(cw.body, p...)
	return len(p), nil
}

func (cw *etagResponseWriter) Flush() {
	if !cw.wroteHeader {
		cw.WriteHeader(http.StatusOK)
	}
	if !cw.passthrough {
		cw.flushed = true
		return // A buffered 200 is held until the handler returns.
	}
	if f, ok := cw.ResponseWriter.(http.Flusher); ok {
		f.Flush()
	}
}

func (cw *etagResponseWriter) Hijack() (net.Conn, *bufio.ReadWriter, error) {
	hj, ok := cw.ResponseWriter.(http.Hijacker)
	if !ok {
		return nil, nil, errors.New("chi/middleware: http.Hijacker is unavailable on the writer")
	}
	if cw.wroteHeader && !cw.passthrough {
		// Send the buffered 200 as the handler wrote it, as the bare handler would.
		cw.sendBuffered()
		cw.passthrough = true
	}
	conn, rw, err := hj.Hijack()
	if err == nil {
		cw.hijacked = true
	}
	return conn, rw, err
}

func (cw *etagResponseWriter) Push(target string, opts *http.PushOptions) error {
	if ps, ok := cw.ResponseWriter.(http.Pusher); ok {
		return ps.Push(target, opts)
	}
	return errors.New("chi/middleware: http.Pusher is unavailable on the writer")
}

func (cw *etagResponseWriter) Unwrap() http.ResponseWriter {
	return cw.ResponseWriter
}

// finish sends the buffered 200 response, adding the ETag and answering 304 when
// If-None-Match matches.
func (cw *etagResponseWriter) finish() {
	if cw.passthrough || cw.hijacked {
		return
	}
	if !cw.wroteHeader {
		cw.WriteHeader(http.StatusOK)
	}
	trailers := cw.restoreHeader()

	h := cw.ResponseWriter.Header()
	if h.Get("ETag") == "" && (cw.req.Method == http.MethodGet || len(cw.body) > 0) {
		sum := sha256.Sum256(cw.body)
		h.Set("ETag", `"`+hex.EncodeToString(sum[:])+`"`)
	}

	if ifNoneMatchMatches(cw.req.Header.Values("If-None-Match"), h.Get("ETag")) {
		h.Del("Content-Type")
		h.Del("Content-Length")
		h.Del("Content-Encoding")
		h.Del("Transfer-Encoding")
		cw.ResponseWriter.WriteHeader(http.StatusNotModified)
		maps.Copy(h, trailers)
		return
	}

	cw.ResponseWriter.WriteHeader(http.StatusOK)
	maps.Copy(h, trailers)
	cw.ResponseWriter.Write(cw.body) // net/http drops the body of a HEAD response.
}

// sendBuffered sends the buffered 200 response as the handler wrote it, with no
// ETag and no 304 handling. If the handler flushed, it flushes too. Otherwise the
// body stays unsent, as in net/http, whose Hijack does not flush the response body.
func (cw *etagResponseWriter) sendBuffered() {
	trailers := cw.restoreHeader()
	cw.ResponseWriter.WriteHeader(http.StatusOK)
	maps.Copy(cw.ResponseWriter.Header(), trailers)
	cw.ResponseWriter.Write(cw.body)
	if f, ok := cw.ResponseWriter.(http.Flusher); ok && cw.flushed {
		f.Flush()
	}
}

// restoreHeader replaces the handler's headers with the snapshot taken when status
// 200 was written, and returns the trailers set since then. net/http reads the
// headers when the status is written, so the caller copies the trailers back only
// after that, where net/http reads them when the response ends.
func (cw *etagResponseWriter) restoreHeader() http.Header {
	h := cw.ResponseWriter.Header()
	trailers := make(http.Header)
	for k, v := range h {
		if strings.HasPrefix(k, http.TrailerPrefix) {
			trailers[k] = v
		}
	}
	for _, line := range cw.header.Values("Trailer") {
		for _, name := range strings.Split(line, ",") {
			key := http.CanonicalHeaderKey(strings.TrimSpace(name))
			if v, ok := h[key]; ok {
				trailers[key] = v
			}
		}
	}
	clear(h)
	maps.Copy(h, cw.header)
	return trailers
}

// ifNoneMatchMatches reports whether any member of the If-None-Match header lines
// matches etag by weak comparison (RFC 9110 §8.8.3.2). A "*" member matches any
// current representation. An empty etag matches only "*".
func ifNoneMatchMatches(lines []string, etag string) bool {
	current, ok := parseETag(etag)
	for _, line := range lines {
		for _, member := range etagListMembers(line) {
			if member == "*" {
				return true
			}
			if tag, valid := parseETag(member); ok && valid && tag == current {
				return true
			}
		}
	}
	return false
}

// etagListMembers returns the valid members of an If-None-Match line, as written.
// Commas and optional whitespace separate members. Malformed members are dropped.
func etagListMembers(line string) []string {
	var members []string
	rest := line
	for {
		rest = strings.TrimLeft(rest, " \t,")
		if rest == "" {
			return members
		}
		var member string
		var ok bool
		member, rest, ok = scanETagMember(rest)
		if ok {
			members = append(members, member)
		}
	}
}

// scanETagMember reads the If-None-Match member at the start of s, which begins
// with neither whitespace nor a comma. It returns the member, the text after it,
// and whether the member is valid. A malformed member is skipped up to the next
// comma. A malformed quoted member is skipped up to the first comma after its
// opening quote, so a quote without a closing quote cannot hide the members after it.
func scanETagMember(s string) (string, string, bool) {
	quoted := strings.TrimPrefix(s, "W/")
	if strings.HasPrefix(quoted, `"`) {
		if i := strings.IndexByte(quoted[1:], '"'); i >= 0 {
			if rest, ok := afterETagMember(quoted[i+2:]); ok {
				return s[:len(s)-len(quoted)+i+2], rest, true
			}
		}
		return "", afterComma(quoted), false
	}
	if s[0] == '*' {
		if rest, ok := afterETagMember(s[1:]); ok {
			return "*", rest, true
		}
	}
	return "", afterComma(s), false
}

// afterETagMember checks that tail, the text after a member, is empty or starts with
// a comma after optional whitespace. It returns the text after that comma.
func afterETagMember(tail string) (string, bool) {
	tail = strings.TrimLeft(tail, " \t")
	if tail == "" {
		return "", true
	}
	if tail[0] == ',' {
		return tail[1:], true
	}
	return "", false
}

// afterComma returns the text after the first comma in s, or "" if s has no comma.
func afterComma(s string) string {
	if i := strings.IndexByte(s, ','); i >= 0 {
		return s[i+1:]
	}
	return ""
}

// parseETag returns the opaque-tag of an entity-tag, with any weak prefix removed.
// The weak prefix is case-sensitive. The bool is false if s is not an entity-tag.
func parseETag(s string) (string, bool) {
	s = strings.TrimPrefix(s, "W/")
	if len(s) < 2 || s[0] != '"' || s[len(s)-1] != '"' {
		return "", false
	}
	opaque := s[1 : len(s)-1]
	if strings.Contains(opaque, `"`) {
		return "", false
	}
	return opaque, true
}

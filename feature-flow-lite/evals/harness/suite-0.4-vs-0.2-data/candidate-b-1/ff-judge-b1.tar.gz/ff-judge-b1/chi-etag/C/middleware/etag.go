package middleware

import (
	"bufio"
	"bytes"
	"crypto/sha256"
	"encoding/hex"
	"errors"
	"maps"
	"net"
	"net/http"
	"slices"
	"strings"
)

// ETag adds a strong ETag to 200 responses to GET and HEAD requests, and answers
// 304 Not Modified when the If-None-Match request header matches it.
//
// The ETag is derived from the response body, unless the handler sets its own
// ETag header, which is kept as it is. Responses to GET and HEAD are buffered in
// memory until the handler returns, so Flush sends nothing early. A HEAD response
// with no body and no handler ETag gets no ETag. Other methods pass through
// unchanged.
//
// ETag reads If-None-Match before it calls the next handler, so place it ahead of
// NoCache in the chain (r.Use(ETag) before r.Use(NoCache)). NoCache deletes that
// request header, so an ETag placed after it never sees the header and never
// answers 304.
func ETag(next http.Handler) http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		if r.Method != http.MethodGet && r.Method != http.MethodHead {
			next.ServeHTTP(w, r)
			return
		}
		// Copy If-None-Match before the handler runs, since the handler may delete it.
		ew := &etagResponseWriter{
			ResponseWriter: w,
			req:            r,
			ifNoneMatch:    slices.Clone(r.Header.Values("If-None-Match")),
		}
		next.ServeHTTP(ew, r)
		ew.send()
	})
}

type etagResponseWriter struct {
	http.ResponseWriter

	req         *http.Request
	ifNoneMatch []string
	// header is the header as it was at the first WriteHeader or Write, which is
	// what net/http would have sent.
	header      http.Header
	status      int
	body        bytes.Buffer
	wroteHeader bool
	hijacked    bool
}

func (ew *etagResponseWriter) WriteHeader(code int) {
	if ew.wroteHeader {
		return // The first code wins, as in net/http.
	}
	if code >= 100 && code <= 199 && code != http.StatusSwitchingProtocols {
		// An informational status is sent now and does not end the response, as in net/http.
		ew.ResponseWriter.WriteHeader(code)
		return
	}
	ew.wroteHeader = true
	ew.status = code
	ew.header = http.Header{}
	maps.Copy(ew.header, ew.ResponseWriter.Header())
}

func (ew *etagResponseWriter) Write(p []byte) (int, error) {
	if !ew.wroteHeader {
		ew.WriteHeader(http.StatusOK)
	}
	if len(p) > 0 && !bodyAllowedForStatus(ew.status) {
		return 0, http.ErrBodyNotAllowed
	}
	return ew.body.Write(p)
}

// Flush is a no-op: the response is sent when the handler returns.
func (ew *etagResponseWriter) Flush() {}

func (ew *etagResponseWriter) Hijack() (net.Conn, *bufio.ReadWriter, error) {
	hj, ok := ew.ResponseWriter.(http.Hijacker)
	if !ok {
		return nil, nil, errors.New("chi/middleware: http.Hijacker is unavailable on the writer")
	}
	conn, rw, err := hj.Hijack()
	if err == nil {
		ew.hijacked = true
	}
	return conn, rw, err
}

func (ew *etagResponseWriter) Push(target string, opts *http.PushOptions) error {
	if ps, ok := ew.ResponseWriter.(http.Pusher); ok {
		return ps.Push(target, opts)
	}
	return errors.New("chi/middleware: http.Pusher is unavailable on the writer")
}

func (ew *etagResponseWriter) Unwrap() http.ResponseWriter {
	return ew.ResponseWriter
}

// send writes the buffered response to the underlying writer, unless the
// connection was hijacked. The body goes out in one Write, so net/http sniffs
// the Content-Type from it exactly as it would for an unbuffered handler.
func (ew *etagResponseWriter) send() {
	if !ew.wroteHeader {
		ew.WriteHeader(http.StatusOK)
	}
	if ew.hijacked {
		return
	}
	h := ew.ResponseWriter.Header()
	clear(h)
	maps.Copy(h, ew.header)
	body := ew.body.Bytes()

	if ew.status == http.StatusOK {
		if h.Get("ETag") == "" && (ew.req.Method == http.MethodGet || len(body) > 0) {
			sum := sha256.Sum256(body)
			h.Set("ETag", `"`+hex.EncodeToString(sum[:16])+`"`)
		}
		if etagIfNoneMatch(ew.ifNoneMatch, h.Get("ETag")) {
			h.Del("Content-Type")
			h.Del("Content-Length")
			h.Del("Content-Encoding")
			ew.ResponseWriter.WriteHeader(http.StatusNotModified)
			return
		}
	}
	ew.ResponseWriter.WriteHeader(ew.status)
	if len(body) > 0 {
		ew.ResponseWriter.Write(body)
	}
}

// bodyAllowedForStatus reports whether a response with the status code may have
// a body, as net/http decides it.
func bodyAllowedForStatus(status int) bool {
	switch {
	case status >= 100 && status <= 199:
		return false
	case status == http.StatusNoContent, status == http.StatusNotModified:
		return false
	}
	return true
}

// etagIfNoneMatch reports whether the If-None-Match header values match etag
// under weak comparison (RFC 9110 section 13.1.2). A "*" member matches any
// current representation. Parsing stops at the first malformed member.
func etagIfNoneMatch(values []string, etag string) bool {
	list := strings.Join(values, ",")
	for {
		list = strings.TrimLeft(list, " \t")
		switch {
		case list == "":
			return false
		case list[0] == ',':
			list = list[1:]
		case list[0] == '*':
			return true
		default:
			tag, rest := etagScan(list)
			if tag == "" {
				return false
			}
			if strings.TrimPrefix(tag, "W/") == strings.TrimPrefix(etag, "W/") {
				return true
			}
			list = rest
		}
	}
}

// etagScan returns the entity-tag at the start of s and the text after it, or
// empty strings if s does not start with a well-formed entity-tag.
func etagScan(s string) (tag, rest string) {
	start := 0
	if strings.HasPrefix(s, "W/") {
		start = 2
	}
	if len(s) < start+2 || s[start] != '"' {
		return "", ""
	}
	for i := start + 1; i < len(s); i++ {
		switch c := s[i]; {
		case c == 0x21 || c >= 0x23 && c <= 0x7e || c >= 0x80:
		case c == '"':
			return s[:i+1], s[i+1:]
		default:
			return "", ""
		}
	}
	return "", ""
}

package middleware

import (
	"bufio"
	"bytes"
	"crypto/sha256"
	"encoding/hex"
	"errors"
	"net"
	"net/http"
	"sort"
	"strings"
)

// ETag sets a strong ETag on GET and HEAD responses and answers requests whose
// If-None-Match header matches it with 304 Not Modified.
//
// The response is buffered until the handler returns, so the ETag covers the
// whole body. A 200 response with no ETag set by the handler gets one: a strong
// tag made from the hex-encoded SHA-256 of the body. An ETag the handler set is
// left as it is. If If-None-Match matches the response's ETag (weak comparison;
// "*" matches any ETag), the response becomes a 304 with no body, and
// Content-Type, Content-Length and Content-Encoding are removed.
//
// A HEAD response with no body and no ETag set by the handler gets no ETag.
// Other methods pass straight through. So does any response once a status other
// than 200 is set: from then on writes and Flush reach the client directly.
//
// With Compress, mount ETag outside it: r.Use(middleware.ETag) before
// r.Use(middleware.Compress(...)). The computed tag then covers the encoded
// bytes, so the gzip and identity representations get different tags, as RFC
// 9110 section 8.8.3 requires. Mounted inside Compress, both would share a tag.
func ETag(next http.Handler) http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		if r.Method != http.MethodGet && r.Method != http.MethodHead {
			next.ServeHTTP(w, r)
			return
		}
		ew := &etagResponseWriter{ResponseWriter: w, head: r.Method == http.MethodHead}
		next.ServeHTTP(ew, r)
		ew.finish(r.Header)
	})
}

type etagResponseWriter struct {
	http.ResponseWriter

	head        bool // the request method is HEAD
	wroteHeader bool // the final status has been set
	status      int  // the final status, once wroteHeader is set
	streaming   bool // writes go straight through: the final status is not 200, or the connection was hijacked
	buf         bytes.Buffer
}

func (ew *etagResponseWriter) WriteHeader(code int) {
	// 1xx informational responses go out now and do not set the final status.
	if code >= 100 && code <= 199 && code != http.StatusSwitchingProtocols {
		ew.ResponseWriter.WriteHeader(code)
		return
	}
	if !ew.wroteHeader {
		ew.wroteHeader = true
		ew.status = code
		ew.streaming = code != http.StatusOK
	}
	// Once the status is fixed as non-200, later calls go to the underlying
	// writer, which logs them as superfluous.
	if ew.streaming {
		ew.ResponseWriter.WriteHeader(code)
	}
}

func (ew *etagResponseWriter) Write(p []byte) (int, error) {
	if !ew.wroteHeader {
		ew.WriteHeader(http.StatusOK)
	}
	if ew.streaming {
		return ew.ResponseWriter.Write(p)
	}
	return ew.buf.Write(p)
}

// Flush sends the response so far only when it is streaming. A buffered
// response is sent when the handler returns.
func (ew *etagResponseWriter) Flush() {
	if !ew.streaming {
		return
	}
	if f, ok := ew.ResponseWriter.(http.Flusher); ok {
		f.Flush()
	}
}

// Hijack sends what the handler has written so far, as net/http would, and then
// hands the connection over. Nothing is sent after that.
func (ew *etagResponseWriter) Hijack() (net.Conn, *bufio.ReadWriter, error) {
	hj, ok := ew.ResponseWriter.(http.Hijacker)
	if !ok {
		return nil, nil, errors.New("chi/middleware: http.Hijacker is unavailable on the writer")
	}
	if ew.wroteHeader && !ew.streaming {
		ew.ResponseWriter.WriteHeader(ew.status)
		ew.ResponseWriter.Write(ew.buf.Bytes())
	}
	// Set before hijacking, so finish does nothing and a later WriteHeader does
	// not start a new buffered response, even if the hijack fails.
	ew.wroteHeader = true
	ew.streaming = true
	return hj.Hijack()
}

func (ew *etagResponseWriter) Push(target string, opts *http.PushOptions) error {
	if ps, ok := ew.ResponseWriter.(http.Pusher); ok {
		return ps.Push(target, opts)
	}
	return errors.New("chi/middleware: http.Pusher is unavailable on the writer")
}

func (ew *etagResponseWriter) Unwrap() http.ResponseWriter {
	return ew.ResponseWriter
}

// finish sends the buffered response once the handler has returned.
func (ew *etagResponseWriter) finish(reqHeader http.Header) {
	if ew.streaming {
		return
	}
	h := ew.Header()
	body := ew.buf.Bytes()
	etag, set := handlerETag(h)
	// A HEAD response with no body says nothing about the resource, so it
	// gets no computed ETag.
	if !set && (!ew.head || len(body) > 0) {
		sum := sha256.Sum256(body)
		etag = `"` + hex.EncodeToString(sum[:]) + `"`
		h.Set("ETag", etag)
	}
	if etag != "" && ifNoneMatch(reqHeader, etag) {
		h.Del("Content-Type")
		h.Del("Content-Length")
		h.Del("Content-Encoding")
		ew.ResponseWriter.WriteHeader(http.StatusNotModified)
		return
	}
	ew.ResponseWriter.WriteHeader(http.StatusOK)
	ew.ResponseWriter.Write(body)
}

// handlerETag returns the ETag the handler set and whether it set one. The header
// map may hold the ETag under any letter case of the name, such as "etag" or
// "ETAG", so every key that equals "Etag" under strings.EqualFold counts. If
// there is more than one, "Etag" wins, then "ETag", then the rest in sorted order.
func handlerETag(h http.Header) (string, bool) {
	for _, key := range []string{"Etag", "ETag"} {
		if v := h[key]; len(v) > 0 {
			return v[0], true
		}
	}
	var keys []string
	for key, v := range h {
		if len(v) > 0 && strings.EqualFold(key, "Etag") {
			keys = append(keys, key)
		}
	}
	if len(keys) == 0 {
		return "", false
	}
	sort.Strings(keys)
	return h[keys[0]][0], true
}

// ifNoneMatch reports whether the If-None-Match lines in h match etag. The
// comparison is weak, as RFC 9110 section 13.1.2 requires for this header.
func ifNoneMatch(h http.Header, etag string) bool {
	etag = strings.TrimPrefix(etag, "W/")
	for _, line := range h.Values("If-None-Match") {
		for _, tag := range parseIfNoneMatch(line) {
			if tag == "*" || tag == etag {
				return true
			}
		}
	}
	return false
}

// parseIfNoneMatch returns the members of one If-None-Match line: "*" and the
// entity-tags, without their W/ prefixes. Empty members are skipped. Parsing
// stops at the first malformed member, so nothing after it is returned.
func parseIfNoneMatch(line string) []string {
	var tags []string
	for {
		line = strings.TrimLeft(line, " \t,")
		if line == "" {
			return tags
		}
		tag, rest, ok := scanIfNoneMatchMember(line)
		rest = strings.TrimLeft(rest, " \t")
		if !ok || (rest != "" && rest[0] != ',') {
			return tags
		}
		tags = append(tags, tag)
		line = rest
	}
}

// scanIfNoneMatchMember parses the "*" or entity-tag at the start of s and
// returns it with the rest of s. ok is false if s does not start with one.
func scanIfNoneMatchMember(s string) (tag, rest string, ok bool) {
	if strings.HasPrefix(s, "*") {
		return "*", s[1:], true
	}
	s = strings.TrimPrefix(s, "W/")
	if s == "" || s[0] != '"' {
		return "", s, false
	}
	closing := strings.IndexByte(s[1:], '"')
	if closing < 0 {
		return "", s, false
	}
	for i := 1; i <= closing; i++ {
		if !isETagc(s[i]) {
			return "", s, false
		}
	}
	return s[:closing+2], s[closing+2:], true
}

// isETagc reports whether c may appear between the quotes of an entity-tag:
// any visible ASCII character except '"', or obs-text.
func isETagc(c byte) bool {
	return c == 0x21 || (c >= 0x23 && c <= 0x7e) || c >= 0x80
}
